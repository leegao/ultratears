
/home/leegao/meh/ultratears-main/src/horizon2llvm/benchmark/samples/main_067_statickernel/results/main_067_statickernel_layer_21a_pass21_safe_default.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <f_8001161d0>:
       0:	55                   	push   %rbp
       1:	41 57                	push   %r15
       3:	41 56                	push   %r14
       5:	41 55                	push   %r13
       7:	41 54                	push   %r12
       9:	53                   	push   %rbx
       a:	48 83 ec 38          	sub    $0x38,%rsp
       e:	48 89 fb             	mov    %rdi,%rbx
      11:	48 bf ba e3 c0 02 08 	movabs $0x802c0e3ba,%rdi
      18:	00 00 00 
      1b:	48 8b 83 d8 00 00 00 	mov    0xd8(%rbx),%rax
      22:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
      29:	4c 8b b3 00 01 00 00 	mov    0x100(%rbx),%r14
      30:	49 8d b6 d0 fe ff ff 	lea    -0x130(%r14),%rsi
      37:	48 89 b3 00 01 00 00 	mov    %rsi,0x100(%rbx)
      3e:	49 8d 56 a0          	lea    -0x60(%r14),%rdx
      42:	49 89 4e a0          	mov    %rcx,-0x60(%r14)
      46:	48 8b 8b f0 00 00 00 	mov    0xf0(%rbx),%rcx
      4d:	49 89 4e a8          	mov    %rcx,-0x58(%r14)
      51:	48 8b 8b e0 00 00 00 	mov    0xe0(%rbx),%rcx
      58:	49 89 4e b0          	mov    %rcx,-0x50(%r14)
      5c:	49 89 46 b8          	mov    %rax,-0x48(%r14)
      60:	48 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%rax
      67:	49 89 46 c0          	mov    %rax,-0x40(%r14)
      6b:	48 8b 83 c8 00 00 00 	mov    0xc8(%rbx),%rax
      72:	49 89 46 c8          	mov    %rax,-0x38(%r14)
      76:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
      7d:	49 89 46 d0          	mov    %rax,-0x30(%r14)
      81:	48 8b 83 b8 00 00 00 	mov    0xb8(%rbx),%rax
      88:	49 89 46 d8          	mov    %rax,-0x28(%r14)
      8c:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
      93:	49 89 46 e0          	mov    %rax,-0x20(%r14)
      97:	48 8b 83 a8 00 00 00 	mov    0xa8(%rbx),%rax
      9e:	49 89 46 e8          	mov    %rax,-0x18(%r14)
      a2:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
      a9:	49 89 46 f0          	mov    %rax,-0x10(%r14)
      ad:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
      b4:	49 89 46 f8          	mov    %rax,-0x8(%r14)
      b8:	48 89 93 e8 00 00 00 	mov    %rdx,0xe8(%rbx)
      bf:	4c 8b 6b 10          	mov    0x10(%rbx),%r13
      c3:	4c 89 ab a8 00 00 00 	mov    %r13,0xa8(%rbx)
      ca:	4c 8b 13             	mov    (%rbx),%r10
      cd:	48 8b 53 08          	mov    0x8(%rbx),%rdx
      d1:	48 89 93 98 00 00 00 	mov    %rdx,0x98(%rbx)
      d8:	4c 89 93 a0 00 00 00 	mov    %r10,0xa0(%rbx)
      df:	48 8d 8a 14 29 00 00 	lea    0x2914(%rdx),%rcx
      e6:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
      ea:	41 f7 c5 e0 ff ff ff 	test   $0xffffffe0,%r13d
      f1:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
      f6:	74 14                	je     10c <f_8001161d0+0x10c>
      f8:	49 89 fc             	mov    %rdi,%r12
      fb:	31 c9                	xor    %ecx,%ecx
      fd:	41 83 fd 12          	cmp    $0x12,%r13d
     101:	b8 00 03 00 00       	mov    $0x300,%eax
     106:	48 0f 45 c1          	cmovne %rcx,%rax
     10a:	eb 20                	jmp    12c <f_8001161d0+0x12c>
     10c:	b8 1f 7d c3 f6       	mov    $0xf6c37d1f,%eax
     111:	44 0f a3 e8          	bt     %r13d,%eax
     115:	73 e1                	jae    f8 <f_8001161d0+0xf8>
     117:	44 89 e8             	mov    %r13d,%eax
     11a:	83 e0 1f             	and    $0x1f,%eax
     11d:	49 89 fc             	mov    %rdi,%r12
     120:	48 8b 84 c7 ce e5 15 	mov    0x15e5ce(%rdi,%rax,8),%rax
     127:	00 
     128:	48 c1 e0 08          	shl    $0x8,%rax
     12c:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
     133:	ff 7f ff 
     136:	49 bf ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r15
     13d:	ff 7f 7f 
     140:	48 bd 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rbp
     147:	00 80 3f 
     14a:	49 bb 00 00 00 00 01 	movabs $0x100000000,%r11
     151:	00 00 00 
     154:	48 89 14 24          	mov    %rdx,(%rsp)
     158:	0f be 8a 17 29 00 00 	movsbl 0x2917(%rdx),%ecx
     15f:	48 63 c9             	movslq %ecx,%rcx
     162:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
     167:	48 89 b3 c0 00 00 00 	mov    %rsi,0xc0(%rbx)
     16e:	41 8b 92 90 33 00 00 	mov    0x3390(%r10),%edx
     175:	4d 8b 82 98 33 00 00 	mov    0x3398(%r10),%r8
     17c:	4c 89 43 48          	mov    %r8,0x48(%rbx)
     180:	48 69 f1 48 07 00 00 	imul   $0x748,%rcx,%rsi
     187:	45 31 c9             	xor    %r9d,%r9d
     18a:	39 ca                	cmp    %ecx,%edx
     18c:	4c 0f 47 ce          	cmova  %rsi,%r9
     190:	48 c7 43 70 ff ff ff 	movq   $0xffffffffffffffff,0x70(%rbx)
     197:	ff 
     198:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 1a0 <f_8001161d0+0x1a0>
     19f:	00 
     1a0:	c4 c1 7c 11 86 d0 fe 	vmovups %ymm0,-0x130(%r14)
     1a7:	ff ff 
     1a9:	49 8d 73 ff          	lea    -0x1(%r11),%rsi
     1ad:	48 89 73 78          	mov    %rsi,0x78(%rbx)
     1b1:	4d 89 9e f0 fe ff ff 	mov    %r11,-0x110(%r14)
     1b8:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
     1bf:	ff ff ff 
     1c2:	49 89 8e f8 fe ff ff 	mov    %rcx,-0x108(%r14)
     1c9:	4d 01 c1             	add    %r8,%r9
     1cc:	4c 01 c8             	add    %r9,%rax
     1cf:	48 05 e8 01 00 00    	add    $0x1e8,%rax
     1d5:	48 89 83 b8 00 00 00 	mov    %rax,0xb8(%rbx)
     1dc:	49 89 b6 00 ff ff ff 	mov    %rsi,-0x100(%r14)
     1e3:	49 89 ae 08 ff ff ff 	mov    %rbp,-0xf8(%r14)
     1ea:	4c 89 7b 58          	mov    %r15,0x58(%rbx)
     1ee:	49 89 ae 10 ff ff ff 	mov    %rbp,-0xf0(%r14)
     1f5:	49 c7 86 18 ff ff ff 	movq   $0x0,-0xe8(%r14)
     1fc:	00 00 00 00 
     200:	4d 8b 8c 24 8e 00 d5 	mov    0xd5008e(%r12),%r9
     207:	00 
     208:	4c 89 4b 50          	mov    %r9,0x50(%rbx)
     20c:	49 8b 84 24 be d7 d3 	mov    0xd3d7be(%r12),%rax
     213:	00 
     214:	49 8d 51 10          	lea    0x10(%r9),%rdx
     218:	49 89 96 20 ff ff ff 	mov    %rdx,-0xe0(%r14)
     21f:	49 89 86 40 ff ff ff 	mov    %rax,-0xc0(%r14)
     226:	4d 8b 9c 24 c6 f8 d4 	mov    0xd4f8c6(%r12),%r11
     22d:	00 
     22e:	4c 89 5b 60          	mov    %r11,0x60(%rbx)
     232:	49 83 c3 10          	add    $0x10,%r11
     236:	4c 89 9b 80 00 00 00 	mov    %r11,0x80(%rbx)
     23d:	4d 89 be 48 ff ff ff 	mov    %r15,-0xb8(%r14)
     244:	49 89 be 50 ff ff ff 	mov    %rdi,-0xb0(%r14)
     24b:	48 8d 8d 00 00 80 c0 	lea    -0x3f800000(%rbp),%rcx
     252:	49 89 8e 74 ff ff ff 	mov    %rcx,-0x8c(%r14)
     259:	49 8b 84 24 d6 f7 d4 	mov    0xd4f7d6(%r12),%rax
     260:	00 
     261:	49 89 be 68 ff ff ff 	mov    %rdi,-0x98(%r14)
     268:	8b 38                	mov    (%rax),%edi
     26a:	48 89 7b 40          	mov    %rdi,0x40(%rbx)
     26e:	4d 89 9e 58 ff ff ff 	mov    %r11,-0xa8(%r14)
     275:	4d 89 be 60 ff ff ff 	mov    %r15,-0xa0(%r14)
     27c:	49 c7 46 80 00 00 00 	movq   $0x0,-0x80(%r14)
     283:	00 
     284:	41 c6 46 88 00       	movb   $0x0,-0x78(%r14)
     289:	41 c7 46 8c 00 00 00 	movl   $0x0,-0x74(%r14)
     290:	00 
     291:	41 89 be 70 ff ff ff 	mov    %edi,-0x90(%r14)
     298:	41 83 fd 21          	cmp    $0x21,%r13d
     29c:	0f 87 14 21 00 00    	ja     23b6 <f_8001161d0+0x23b6>
     2a2:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
     2a7:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
     2ac:	49 8d 86 48 ff ff ff 	lea    -0xb8(%r14),%rax
     2b3:	4d 8d be 60 ff ff ff 	lea    -0xa0(%r14),%r15
     2ba:	49 8d 6e 80          	lea    -0x80(%r14),%rbp
     2be:	4d 8d 86 70 ff ff ff 	lea    -0x90(%r14),%r8
     2c5:	49 8d 8c 24 86 e5 15 	lea    0x15e586(%r12),%rcx
     2cc:	00 
     2cd:	48 89 8b 88 00 00 00 	mov    %rcx,0x88(%rbx)
     2d4:	44 89 ea             	mov    %r13d,%edx
     2d7:	83 e2 3f             	and    $0x3f,%edx
     2da:	48 89 93 90 00 00 00 	mov    %rdx,0x90(%rbx)
     2e1:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
     2e6:	48 89 8b 80 00 00 00 	mov    %rcx,0x80(%rbx)
     2ed:	89 d1                	mov    %edx,%ecx
     2ef:	41 0f b7 8c 4c 86 e5 	movzwl 0x15e586(%r12,%rcx,2),%ecx
     2f6:	15 00 
     2f8:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     2fc:	4d 8d a4 8c 62 7f 50 	lea    -0x2af809e(%r12,%rcx,4),%r12
     303:	fd 
     304:	4c 89 23             	mov    %r12,(%rbx)
     307:	48 89 43 48          	mov    %rax,0x48(%rbx)
     30b:	4c 89 bb d0 00 00 00 	mov    %r15,0xd0(%rbx)
     312:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
     319:	ff ff ff 
     31c:	4c 89 83 c8 00 00 00 	mov    %r8,0xc8(%rbx)
     323:	48 89 ab d8 00 00 00 	mov    %rbp,0xd8(%rbx)
     32a:	48 83 c0 0f          	add    $0xf,%rax
     32e:	41 b8 ff ff 00 00    	mov    $0xffff,%r8d
     334:	81 f9 86 02 00 00    	cmp    $0x286,%ecx
     33a:	0f 8f 90 03 00 00    	jg     6d0 <f_8001161d0+0x6d0>
     340:	41 bf 08 00 00 00    	mov    $0x8,%r15d
     346:	81 f9 2d 01 00 00    	cmp    $0x12d,%ecx
     34c:	4c 89 d5             	mov    %r10,%rbp
     34f:	0f 8f f7 03 00 00    	jg     74c <f_8001161d0+0x74c>
     355:	83 f9 6f             	cmp    $0x6f,%ecx
     358:	0f 8f d5 06 00 00    	jg     a33 <f_8001161d0+0xa33>
     35e:	83 f9 04             	cmp    $0x4,%ecx
     361:	0f 87 94 0f 00 00    	ja     12fb <f_8001161d0+0x12fb>
     367:	89 c8                	mov    %ecx,%eax
     369:	4c 8d 05 00 00 00 00 	lea    0x0(%rip),%r8        # 370 <f_8001161d0+0x370>
     370:	49 63 04 80          	movslq (%r8,%rax,4),%rax
     374:	4c 01 c0             	add    %r8,%rax
     377:	4c 8b 44 24 20       	mov    0x20(%rsp),%r8
     37c:	ff e0                	jmp    *%rax
     37e:	41 0f b7 92 e4 0c 00 	movzwl 0xce4(%r10),%edx
     385:	00 
     386:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     38d:	00 00 00 
     390:	46 8d 04 28          	lea    (%rax,%r13,1),%r8d
     394:	41 ff c8             	dec    %r8d
     397:	4c 89 43 68          	mov    %r8,0x68(%rbx)
     39b:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
     3a0:	4c 89 4b 50          	mov    %r9,0x50(%rbx)
     3a4:	48 8b 04 24          	mov    (%rsp),%rax
     3a8:	0f b6 70 08          	movzbl 0x8(%rax),%esi
     3ac:	48 89 73 78          	mov    %rsi,0x78(%rbx)
     3b0:	49 c7 86 18 ff ff ff 	movq   $0x0,-0xe8(%r14)
     3b7:	00 00 00 00 
     3bb:	4d 89 8e 20 ff ff ff 	mov    %r9,-0xe0(%r14)
     3c2:	c4 c2 4b f7 82 fc 0d 	shrx   %esi,0xdfc(%r10),%eax
     3c9:	00 00 
     3cb:	41 8d 4d 08          	lea    0x8(%r13),%ecx
     3cf:	41 89 8e 00 ff ff ff 	mov    %ecx,-0x100(%r14)
     3d6:	45 89 86 04 ff ff ff 	mov    %r8d,-0xfc(%r14)
     3dd:	31 c9                	xor    %ecx,%ecx
     3df:	f7 c2 00 02 00 00    	test   $0x200,%edx
     3e5:	0f 94 c1             	sete   %cl
     3e8:	85 c8                	test   %ecx,%eax
     3ea:	41 8b 8a 20 0d 00 00 	mov    0xd20(%r10),%ecx
     3f1:	b8 01 00 00 00       	mov    $0x1,%eax
     3f6:	c4 62 39 f7 c8       	shlx   %r8d,%eax,%r9d
     3fb:	4c 89 4b 08          	mov    %r9,0x8(%rbx)
     3ff:	49 8b 82 28 0d 00 00 	mov    0xd28(%r10),%rax
     406:	41 ba 0f 00 00 00    	mov    $0xf,%r10d
     40c:	45 0f 45 d1          	cmovne %r9d,%r10d
     410:	48 89 fd             	mov    %rdi,%rbp
     413:	31 ff                	xor    %edi,%edi
     415:	39 f1                	cmp    %esi,%ecx
     417:	48 0f 46 f7          	cmovbe %rdi,%rsi
     41b:	48 89 43 70          	mov    %rax,0x70(%rbx)
     41f:	48 89 73 78          	mov    %rsi,0x78(%rbx)
     423:	48 69 ce b0 0b 00 00 	imul   $0xbb0,%rsi,%rcx
     42a:	31 f6                	xor    %esi,%esi
     42c:	f7 c2 00 40 00 00    	test   $0x4000,%edx
     432:	40 0f 94 c6          	sete   %sil
     436:	c1 e6 04             	shl    $0x4,%esi
     439:	c1 e2 06             	shl    $0x6,%edx
     43c:	81 e2 00 00 04 00    	and    $0x40000,%edx
     442:	01 f2                	add    %esi,%edx
     444:	81 c2 00 00 20 00    	add    $0x200000,%edx
     44a:	49 c7 46 80 00 00 00 	movq   $0x0,-0x80(%r14)
     451:	00 
     452:	48 c7 03 08 00 00 00 	movq   $0x8,(%rbx)
     459:	45 89 96 d0 fe ff ff 	mov    %r10d,-0x130(%r14)
     460:	41 8d 75 04          	lea    0x4(%r13),%esi
     464:	41 c7 86 d4 fe ff ff 	movl   $0x8,-0x12c(%r14)
     46b:	08 00 00 00 
     46f:	41 89 b6 d8 fe ff ff 	mov    %esi,-0x128(%r14)
     476:	41 89 96 dc fe ff ff 	mov    %edx,-0x124(%r14)
     47d:	49 c7 86 e0 fe ff ff 	movq   $0xffff,-0x120(%r14)
     484:	ff ff 00 00 
     488:	49 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%r15
     48f:	ff ff ff 
     492:	49 8d 57 02          	lea    0x2(%r15),%rdx
     496:	49 89 96 e8 fe ff ff 	mov    %rdx,-0x118(%r14)
     49d:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
     4a2:	4c 89 93 90 00 00 00 	mov    %r10,0x90(%rbx)
     4a9:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
     4b0:	00 00 00 
     4b3:	49 89 96 f0 fe ff ff 	mov    %rdx,-0x110(%r14)
     4ba:	4d 89 be f8 fe ff ff 	mov    %r15,-0x108(%r14)
     4c1:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
     4c8:	00 80 3f 
     4cb:	49 89 96 08 ff ff ff 	mov    %rdx,-0xf8(%r14)
     4d2:	49 89 96 10 ff ff ff 	mov    %rdx,-0xf0(%r14)
     4d9:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
     4e0:	00 00 00 
     4e3:	49 8d 94 24 c1 5f 0b 	lea    0xb5fc1(%r12),%rdx
     4ea:	00 
     4eb:	48 89 93 80 00 00 00 	mov    %rdx,0x80(%rbx)
     4f2:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     4f9:	ff 7f ff 
     4fc:	4c 89 83 88 00 00 00 	mov    %r8,0x88(%rbx)
     503:	4d 89 96 74 ff ff ff 	mov    %r10,-0x8c(%r14)
     50a:	48 be ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rsi
     511:	ff 7f 7f 
     514:	49 89 b6 48 ff ff ff 	mov    %rsi,-0xb8(%r14)
     51b:	4d 89 86 50 ff ff ff 	mov    %r8,-0xb0(%r14)
     522:	4d 89 86 68 ff ff ff 	mov    %r8,-0x98(%r14)
     529:	4d 89 9e 58 ff ff ff 	mov    %r11,-0xa8(%r14)
     530:	49 89 b6 60 ff ff ff 	mov    %rsi,-0xa0(%r14)
     537:	41 c6 46 88 00       	movb   $0x0,-0x78(%r14)
     53c:	41 89 ae 70 ff ff ff 	mov    %ebp,-0x90(%r14)
     543:	41 c7 46 8c 00 00 00 	movl   $0x0,-0x74(%r14)
     54a:	00 
     54b:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     54f:	c4 c1 78 11 86 28 ff 	vmovups %xmm0,-0xd8(%r14)
     556:	ff ff 
     558:	49 c7 86 38 ff ff ff 	movq   $0x0,-0xc8(%r14)
     55f:	00 00 00 00 
     563:	49 89 96 40 ff ff ff 	mov    %rdx,-0xc0(%r14)
     56a:	8b 94 01 d8 03 00 00 	mov    0x3d8(%rcx,%rax,1),%edx
     571:	8b b4 01 f8 03 00 00 	mov    0x3f8(%rcx,%rax,1),%esi
     578:	41 89 d1             	mov    %edx,%r9d
     57b:	41 c1 f9 1f          	sar    $0x1f,%r9d
     57f:	c4 62 30 f2 ca       	andn   %edx,%r9d,%r9d
     584:	85 d2                	test   %edx,%edx
     586:	0f 49 d7             	cmovns %edi,%edx
     589:	c5 82 2a c2          	vcvtsi2ss %edx,%xmm15,%xmm0
     58d:	89 f2                	mov    %esi,%edx
     58f:	c1 fa 1f             	sar    $0x1f,%edx
     592:	c4 e2 68 f2 d6       	andn   %esi,%edx,%edx
     597:	c5 82 2a ca          	vcvtsi2ss %edx,%xmm15,%xmm1
     59b:	85 f6                	test   %esi,%esi
     59d:	0f 49 f7             	cmovns %edi,%esi
     5a0:	c4 c1 02 2a d1       	vcvtsi2ss %r9d,%xmm15,%xmm2
     5a5:	c4 c1 7a 11 96 50 ff 	vmovss %xmm2,-0xb0(%r14)
     5ac:	ff ff 
     5ae:	c4 c1 7a 11 8e 54 ff 	vmovss %xmm1,-0xac(%r14)
     5b5:	ff ff 
     5b7:	c5 82 2a ce          	vcvtsi2ss %esi,%xmm15,%xmm1
     5bb:	c4 c1 7a 11 86 48 ff 	vmovss %xmm0,-0xb8(%r14)
     5c2:	ff ff 
     5c4:	c4 c1 7a 11 8e 4c ff 	vmovss %xmm1,-0xb4(%r14)
     5cb:	ff ff 
     5cd:	8b b4 01 d8 03 00 00 	mov    0x3d8(%rcx,%rax,1),%esi
     5d4:	8b 94 01 f8 03 00 00 	mov    0x3f8(%rcx,%rax,1),%edx
     5db:	41 89 ae 70 ff ff ff 	mov    %ebp,-0x90(%r14)
     5e2:	4d 89 96 74 ff ff ff 	mov    %r10,-0x8c(%r14)
     5e9:	41 89 f0             	mov    %esi,%r8d
     5ec:	41 c1 f8 1f          	sar    $0x1f,%r8d
     5f0:	c4 62 38 f2 c6       	andn   %esi,%r8d,%r8d
     5f5:	85 f6                	test   %esi,%esi
     5f7:	0f 49 f7             	cmovns %edi,%esi
     5fa:	c5 82 2a c6          	vcvtsi2ss %esi,%xmm15,%xmm0
     5fe:	c4 c1 02 2a c8       	vcvtsi2ss %r8d,%xmm15,%xmm1
     603:	c4 e3 79 17 c6 00    	vextractps $0x0,%xmm0,%esi
     609:	4c 89 43 68          	mov    %r8,0x68(%rbx)
     60d:	48 89 b3 10 02 00 00 	mov    %rsi,0x210(%rbx)
     614:	89 d6                	mov    %edx,%esi
     616:	c1 fe 1f             	sar    $0x1f,%esi
     619:	c4 e2 48 f2 f2       	andn   %edx,%esi,%esi
     61e:	c5 82 2a d6          	vcvtsi2ss %esi,%xmm15,%xmm2
     622:	c4 e3 79 17 ce 00    	vextractps $0x0,%xmm1,%esi
     628:	48 89 b3 00 02 00 00 	mov    %rsi,0x200(%rbx)
     62f:	85 d2                	test   %edx,%edx
     631:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
     638:	00 00 00 00 
     63c:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
     643:	00 00 00 00 
     647:	0f 48 fa             	cmovs  %edx,%edi
     64a:	c5 82 2a df          	vcvtsi2ss %edi,%xmm15,%xmm3
     64e:	c4 e3 79 17 d2 00    	vextractps $0x0,%xmm2,%edx
     654:	c4 e3 79 17 de 00    	vextractps $0x0,%xmm3,%esi
     65a:	48 89 b3 30 02 00 00 	mov    %rsi,0x230(%rbx)
     661:	48 89 93 20 02 00 00 	mov    %rdx,0x220(%rbx)
     668:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
     66f:	00 00 00 00 
     673:	48 c7 83 28 02 00 00 	movq   $0x0,0x228(%rbx)
     67a:	00 00 00 00 
     67e:	c4 c1 7a 11 8e 68 ff 	vmovss %xmm1,-0x98(%r14)
     685:	ff ff 
     687:	c4 c1 7a 11 96 6c ff 	vmovss %xmm2,-0x94(%r14)
     68e:	ff ff 
     690:	c4 c1 7a 11 86 60 ff 	vmovss %xmm0,-0xa0(%r14)
     697:	ff ff 
     699:	c4 c1 7a 11 9e 64 ff 	vmovss %xmm3,-0x9c(%r14)
     6a0:	ff ff 
     6a2:	31 d2                	xor    %edx,%edx
     6a4:	80 bc 01 58 04 00 00 	cmpb   $0x0,0x458(%rcx,%rax,1)
     6ab:	00 
     6ac:	49 c7 46 80 00 00 00 	movq   $0x0,-0x80(%r14)
     6b3:	00 
     6b4:	41 c7 46 8c 01 00 00 	movl   $0x1,-0x74(%r14)
     6bb:	00 
     6bc:	0f 94 c2             	sete   %dl
     6bf:	48 8d 04 55 59 00 00 	lea    0x59(,%rdx,2),%rax
     6c6:	00 
     6c7:	48 89 43 40          	mov    %rax,0x40(%rbx)
     6cb:	e9 e2 1c 00 00       	jmp    23b2 <f_8001161d0+0x23b2>
     6d0:	81 f9 6d 04 00 00    	cmp    $0x46d,%ecx
     6d6:	0f 8e f8 01 00 00    	jle    8d4 <f_8001161d0+0x8d4>
     6dc:	8d 81 92 fb ff ff    	lea    -0x46e(%rcx),%eax
     6e2:	83 f8 0c             	cmp    $0xc,%eax
     6e5:	0f 86 70 06 00 00    	jbe    d5b <f_8001161d0+0xd5b>
     6eb:	8d 81 36 fb ff ff    	lea    -0x4ca(%rcx),%eax
     6f1:	83 f8 16             	cmp    $0x16,%eax
     6f4:	0f 87 b1 0b 00 00    	ja     12ab <f_8001161d0+0x12ab>
     6fa:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 701 <f_8001161d0+0x701>
     701:	48 63 04 82          	movslq (%rdx,%rax,4),%rax
     705:	48 01 d0             	add    %rdx,%rax
     708:	ff e0                	jmp    *%rax
     70a:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
     711:	00 
     712:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
     717:	48 89 43 08          	mov    %rax,0x8(%rbx)
     71b:	48 8b 04 24          	mov    (%rsp),%rax
     71f:	48 89 43 10          	mov    %rax,0x10(%rbx)
     723:	49 81 c2 b0 1e 00 00 	add    $0x1eb0,%r10
     72a:	4c 89 13             	mov    %r10,(%rbx)
     72d:	48 c7 43 18 01 00 00 	movq   $0x1,0x18(%rbx)
     734:	00 
     735:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
     73c:	00 00 00 
     73f:	49 8d 84 24 a2 92 50 	lea    -0x2af6d5e(%r12),%rax
     746:	fd 
     747:	e9 6d 0f 00 00       	jmp    16b9 <f_8001161d0+0x16b9>
     74c:	81 f9 c7 01 00 00    	cmp    $0x1c7,%ecx
     752:	0f 8f 63 05 00 00    	jg     cbb <f_8001161d0+0xcbb>
     758:	81 f9 b1 01 00 00    	cmp    $0x1b1,%ecx
     75e:	0f 8f d7 08 00 00    	jg     103b <f_8001161d0+0x103b>
     764:	81 f9 2e 01 00 00    	cmp    $0x12e,%ecx
     76a:	0f 84 13 14 00 00    	je     1b83 <f_8001161d0+0x1b83>
     770:	81 f9 66 01 00 00    	cmp    $0x166,%ecx
     776:	0f 85 e0 0e 00 00    	jne    165c <f_8001161d0+0x165c>
     77c:	48 8b b5 c8 1e 00 00 	mov    0x1ec8(%rbp),%rsi
     783:	48 89 73 08          	mov    %rsi,0x8(%rbx)
     787:	48 c7 83 80 00 00 00 	movq   $0x3ce0,0x80(%rbx)
     78e:	e0 3c 00 00 
     792:	4c 89 5b 60          	mov    %r11,0x60(%rbx)
     796:	48 8b 04 24          	mov    (%rsp),%rax
     79a:	0f b6 40 08          	movzbl 0x8(%rax),%eax
     79e:	48 89 43 68          	mov    %rax,0x68(%rbx)
     7a2:	48 69 c8 e0 3c 00 00 	imul   $0x3ce0,%rax,%rcx
     7a9:	31 d2                	xor    %edx,%edx
     7ab:	39 46 08             	cmp    %eax,0x8(%rsi)
     7ae:	48 0f 47 d1          	cmova  %rcx,%rdx
     7b2:	49 89 f8             	mov    %rdi,%r8
     7b5:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
     7b9:	48 8b 94 17 40 3c 00 	mov    0x3c40(%rdi,%rdx,1),%rdx
     7c0:	00 
     7c1:	48 89 93 b0 00 00 00 	mov    %rdx,0xb0(%rbx)
     7c8:	45 89 86 70 ff ff ff 	mov    %r8d,-0x90(%r14)
     7cf:	4d 89 9e 58 ff ff ff 	mov    %r11,-0xa8(%r14)
     7d6:	49 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r9
     7dd:	ff 7f 7f 
     7e0:	4d 89 8e 60 ff ff ff 	mov    %r9,-0xa0(%r14)
     7e7:	49 c7 46 80 00 00 00 	movq   $0x0,-0x80(%r14)
     7ee:	00 
     7ef:	41 c6 46 88 00       	movb   $0x0,-0x78(%r14)
     7f4:	41 c7 46 8c 00 00 00 	movl   $0x0,-0x74(%r14)
     7fb:	00 
     7fc:	49 c7 86 18 ff ff ff 	movq   $0x0,-0xe8(%r14)
     803:	00 00 00 00 
     807:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
     80c:	49 89 be 20 ff ff ff 	mov    %rdi,-0xe0(%r14)
     813:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     817:	c4 c1 78 11 86 28 ff 	vmovups %xmm0,-0xd8(%r14)
     81e:	ff ff 
     820:	49 c7 86 00 ff ff ff 	movq   $0x8,-0x100(%r14)
     827:	08 00 00 00 
     82b:	48 bf 10 00 00 00 03 	movabs $0x300000010,%rdi
     832:	00 00 00 
     835:	49 89 be d0 fe ff ff 	mov    %rdi,-0x130(%r14)
     83c:	49 c7 86 d8 fe ff ff 	movq   $0x0,-0x128(%r14)
     843:	00 00 00 00 
     847:	49 c7 86 e0 fe ff ff 	movq   $0xffff,-0x120(%r14)
     84e:	ff ff 00 00 
     852:	49 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%r15
     859:	ff ff ff 
     85c:	49 8d 7f 0d          	lea    0xd(%r15),%rdi
     860:	49 89 be e8 fe ff ff 	mov    %rdi,-0x118(%r14)
     867:	48 bf 00 00 00 00 01 	movabs $0x100000000,%rdi
     86e:	00 00 00 
     871:	49 89 be f0 fe ff ff 	mov    %rdi,-0x110(%r14)
     878:	4d 89 be f8 fe ff ff 	mov    %r15,-0x108(%r14)
     87f:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
     884:	49 89 be 74 ff ff ff 	mov    %rdi,-0x8c(%r14)
     88b:	48 8d 7e 08          	lea    0x8(%rsi),%rdi
     88f:	48 83 c6 10          	add    $0x10,%rsi
     893:	49 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r8
     89a:	00 80 3f 
     89d:	4d 89 86 08 ff ff ff 	mov    %r8,-0xf8(%r14)
     8a4:	4d 89 86 10 ff ff ff 	mov    %r8,-0xf0(%r14)
     8ab:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
     8b2:	00 00 00 
     8b5:	4d 8d 84 24 9b 87 01 	lea    0x1879b(%r12),%r8
     8bc:	00 
     8bd:	4c 89 43 70          	mov    %r8,0x70(%rbx)
     8c1:	49 ba ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r10
     8c8:	ff 7f ff 
     8cb:	4c 89 53 78          	mov    %r10,0x78(%rbx)
     8cf:	e9 0f 14 00 00       	jmp    1ce3 <f_8001161d0+0x1ce3>
     8d4:	81 f9 d4 02 00 00    	cmp    $0x2d4,%ecx
     8da:	0f 8f 2c 04 00 00    	jg     d0c <f_8001161d0+0xd0c>
     8e0:	81 f9 b5 02 00 00    	cmp    $0x2b5,%ecx
     8e6:	0f 8f 8f 07 00 00    	jg     107b <f_8001161d0+0x107b>
     8ec:	81 f9 87 02 00 00    	cmp    $0x287,%ecx
     8f2:	0f 84 ff 14 00 00    	je     1df7 <f_8001161d0+0x1df7>
     8f8:	81 f9 97 02 00 00    	cmp    $0x297,%ecx
     8fe:	0f 85 58 0d 00 00    	jne    165c <f_8001161d0+0x165c>
     904:	41 89 be 70 ff ff ff 	mov    %edi,-0x90(%r14)
     90b:	49 c7 86 d0 fe ff ff 	movq   $0x40000000,-0x130(%r14)
     912:	00 00 00 40 
     916:	48 b8 00 00 00 00 00 	movabs $0x40000000000000,%rax
     91d:	00 40 00 
     920:	49 89 86 d8 fe ff ff 	mov    %rax,-0x128(%r14)
     927:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     92e:	00 
     92f:	49 c7 86 e0 fe ff ff 	movq   $0xffff,-0x120(%r14)
     936:	ff ff 00 00 
     93a:	49 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%r15
     941:	ff ff ff 
     944:	49 8d 47 14          	lea    0x14(%r15),%rax
     948:	49 89 86 e8 fe ff ff 	mov    %rax,-0x118(%r14)
     94f:	41 c6 46 88 00       	movb   $0x0,-0x78(%r14)
     954:	49 c7 46 80 00 00 00 	movq   $0x0,-0x80(%r14)
     95b:	00 
     95c:	41 c7 46 8c 00 00 00 	movl   $0x0,-0x74(%r14)
     963:	00 
     964:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     96b:	00 00 00 
     96e:	49 89 86 f0 fe ff ff 	mov    %rax,-0x110(%r14)
     975:	4d 89 be f8 fe ff ff 	mov    %r15,-0x108(%r14)
     97c:	48 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rsi
     983:	00 80 3f 
     986:	48 89 73 70          	mov    %rsi,0x70(%rbx)
     98a:	48 8d 40 ff          	lea    -0x1(%rax),%rax
     98e:	49 89 86 00 ff ff ff 	mov    %rax,-0x100(%r14)
     995:	49 89 b6 08 ff ff ff 	mov    %rsi,-0xf8(%r14)
     99c:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
     9a3:	00 00 00 
     9a6:	49 8d 84 24 90 87 01 	lea    0x18790(%r12),%rax
     9ad:	00 
     9ae:	49 89 86 40 ff ff ff 	mov    %rax,-0xc0(%r14)
     9b5:	48 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rax
     9bc:	ff 7f 7f 
     9bf:	49 89 86 48 ff ff ff 	mov    %rax,-0xb8(%r14)
     9c6:	48 b9 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rcx
     9cd:	ff 7f ff 
     9d0:	49 89 8e 50 ff ff ff 	mov    %rcx,-0xb0(%r14)
     9d7:	4d 89 9e 58 ff ff ff 	mov    %r11,-0xa8(%r14)
     9de:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
     9e3:	49 89 96 74 ff ff ff 	mov    %rdx,-0x8c(%r14)
     9ea:	49 89 b6 10 ff ff ff 	mov    %rsi,-0xf0(%r14)
     9f1:	49 c7 86 18 ff ff ff 	movq   $0x0,-0xe8(%r14)
     9f8:	00 00 00 00 
     9fc:	49 89 86 60 ff ff ff 	mov    %rax,-0xa0(%r14)
     a03:	49 89 8e 68 ff ff ff 	mov    %rcx,-0x98(%r14)
     a0a:	49 c7 86 38 ff ff ff 	movq   $0x0,-0xc8(%r14)
     a11:	00 00 00 00 
     a15:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
     a1a:	49 89 86 20 ff ff ff 	mov    %rax,-0xe0(%r14)
     a21:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     a25:	c4 c1 78 11 86 28 ff 	vmovups %xmm0,-0xd8(%r14)
     a2c:	ff ff 
     a2e:	e9 db 18 00 00       	jmp    230e <f_8001161d0+0x230e>
     a33:	81 f9 c8 00 00 00    	cmp    $0xc8,%ecx
     a39:	0f 8f 43 03 00 00    	jg     d82 <f_8001161d0+0xd82>
     a3f:	83 f9 70             	cmp    $0x70,%ecx
     a42:	49 89 ea             	mov    %rbp,%r10
     a45:	0f 84 15 0f 00 00    	je     1960 <f_8001161d0+0x1960>
     a4b:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
     a51:	0f 85 05 0c 00 00    	jne    165c <f_8001161d0+0x165c>
     a57:	49 8b 82 c8 1e 00 00 	mov    0x1ec8(%r10),%rax
     a5e:	48 89 43 08          	mov    %rax,0x8(%rbx)
     a62:	4c 89 5b 60          	mov    %r11,0x60(%rbx)
     a66:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
     a6d:	00 
     a6e:	48 8b 0c 24          	mov    (%rsp),%rcx
     a72:	0f b6 51 08          	movzbl 0x8(%rcx),%edx
     a76:	48 89 53 68          	mov    %rdx,0x68(%rbx)
     a7a:	49 89 f8             	mov    %rdi,%r8
     a7d:	8b 78 08             	mov    0x8(%rax),%edi
     a80:	4c 8b 48 10          	mov    0x10(%rax),%r9
     a84:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
     a8b:	00 
     a8c:	48 69 f2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rsi
     a93:	31 c9                	xor    %ecx,%ecx
     a95:	39 d7                	cmp    %edx,%edi
     a97:	bf 00 00 00 00       	mov    $0x0,%edi
     a9c:	48 0f 47 fe          	cmova  %rsi,%rdi
     aa0:	49 8b bc 39 40 3c 00 	mov    0x3c40(%r9,%rdi,1),%rdi
     aa7:	00 
     aa8:	48 89 bb b0 00 00 00 	mov    %rdi,0xb0(%rbx)
     aaf:	45 89 86 70 ff ff ff 	mov    %r8d,-0x90(%r14)
     ab6:	4d 89 9e 58 ff ff ff 	mov    %r11,-0xa8(%r14)
     abd:	49 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r9
     ac4:	ff 7f 7f 
     ac7:	4d 89 8e 60 ff ff ff 	mov    %r9,-0xa0(%r14)
     ace:	49 c7 46 80 00 00 00 	movq   $0x0,-0x80(%r14)
     ad5:	00 
     ad6:	41 c6 46 88 00       	movb   $0x0,-0x78(%r14)
     adb:	41 c7 46 8c 00 00 00 	movl   $0x0,-0x74(%r14)
     ae2:	00 
     ae3:	49 c7 86 18 ff ff ff 	movq   $0x0,-0xe8(%r14)
     aea:	00 00 00 00 
     aee:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
     af3:	4d 89 86 20 ff ff ff 	mov    %r8,-0xe0(%r14)
     afa:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     afe:	c4 c1 78 11 86 28 ff 	vmovups %xmm0,-0xd8(%r14)
     b05:	ff ff 
     b07:	49 c7 86 00 ff ff ff 	movq   $0x5,-0x100(%r14)
     b0e:	05 00 00 00 
     b12:	49 b8 10 00 00 00 03 	movabs $0x300000010,%r8
     b19:	00 00 00 
     b1c:	49 81 c0 f0 00 00 00 	add    $0xf0,%r8
     b23:	4d 89 86 d0 fe ff ff 	mov    %r8,-0x130(%r14)
     b2a:	49 b8 00 00 00 00 00 	movabs $0x60000000000000,%r8
     b31:	00 60 00 
     b34:	4d 89 86 d8 fe ff ff 	mov    %r8,-0x128(%r14)
     b3b:	48 89 3b             	mov    %rdi,(%rbx)
     b3e:	49 c7 86 e0 fe ff ff 	movq   $0xffff,-0x120(%r14)
     b45:	ff ff 00 00 
     b49:	49 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%r15
     b50:	ff ff ff 
     b53:	49 8d 7f 08          	lea    0x8(%r15),%rdi
     b57:	49 89 be e8 fe ff ff 	mov    %rdi,-0x118(%r14)
     b5e:	48 bf 00 00 00 00 01 	movabs $0x100000000,%rdi
     b65:	00 00 00 
     b68:	49 89 be f0 fe ff ff 	mov    %rdi,-0x110(%r14)
     b6f:	4d 89 be f8 fe ff ff 	mov    %r15,-0x108(%r14)
     b76:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
     b7b:	49 89 be 74 ff ff ff 	mov    %rdi,-0x8c(%r14)
     b82:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
     b89:	00 80 3f 
     b8c:	49 89 be 08 ff ff ff 	mov    %rdi,-0xf8(%r14)
     b93:	49 89 be 10 ff ff ff 	mov    %rdi,-0xf0(%r14)
     b9a:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
     ba1:	00 00 00 
     ba4:	49 8d bc 24 2d ce 08 	lea    0x8ce2d(%r12),%rdi
     bab:	00 
     bac:	48 89 7b 78          	mov    %rdi,0x78(%rbx)
     bb0:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     bb7:	ff 7f ff 
     bba:	4c 89 83 80 00 00 00 	mov    %r8,0x80(%rbx)
     bc1:	4d 89 86 68 ff ff ff 	mov    %r8,-0x98(%r14)
     bc8:	4d 89 8e 48 ff ff ff 	mov    %r9,-0xb8(%r14)
     bcf:	4d 89 86 50 ff ff ff 	mov    %r8,-0xb0(%r14)
     bd6:	49 c7 86 38 ff ff ff 	movq   $0x0,-0xc8(%r14)
     bdd:	00 00 00 00 
     be1:	49 89 be 40 ff ff ff 	mov    %rdi,-0xc0(%r14)
     be8:	48 8b 78 10          	mov    0x10(%rax),%rdi
     bec:	39 50 08             	cmp    %edx,0x8(%rax)
     bef:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     bf5:	4c 0f 47 c6          	cmova  %rsi,%r8
     bf9:	c4 c1 78 10 84 38 00 	vmovups 0x2e00(%r8,%rdi,1),%xmm0
     c00:	2e 00 00 
     c03:	c4 c1 78 11 86 48 ff 	vmovups %xmm0,-0xb8(%r14)
     c0a:	ff ff 
     c0c:	39 50 08             	cmp    %edx,0x8(%rax)
     c0f:	48 0f 47 ce          	cmova  %rsi,%rcx
     c13:	48 8b 40 10          	mov    0x10(%rax),%rax
     c17:	48 8b 94 01 80 30 00 	mov    0x3080(%rcx,%rax,1),%rdx
     c1e:	00 
     c1f:	48 8b b4 01 88 30 00 	mov    0x3088(%rcx,%rax,1),%rsi
     c26:	00 
     c27:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     c2b:	49 89 96 60 ff ff ff 	mov    %rdx,-0xa0(%r14)
     c32:	49 89 b6 68 ff ff ff 	mov    %rsi,-0x98(%r14)
     c39:	48 8b 94 01 90 30 00 	mov    0x3090(%rcx,%rax,1),%rdx
     c40:	00 
     c41:	48 89 53 48          	mov    %rdx,0x48(%rbx)
     c45:	8b 84 01 98 30 00 00 	mov    0x3098(%rcx,%rax,1),%eax
     c4c:	41 89 86 78 ff ff ff 	mov    %eax,-0x88(%r14)
     c53:	49 8d 46 97          	lea    -0x69(%r14),%rax
     c57:	48 89 43 40          	mov    %rax,0x40(%rbx)
     c5b:	49 89 96 70 ff ff ff 	mov    %rdx,-0x90(%r14)
     c62:	49 8d 84 24 66 82 50 	lea    -0x2af7d9a(%r12),%rax
     c69:	fd 
     c6a:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
     c71:	48 89 df             	mov    %rbx,%rdi
     c74:	c5 f8 77             	vzeroupper
     c77:	e8 00 00 00 00       	call   c7c <f_8001161d0+0xc7c>
     c7c:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     c83:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     c8a:	49 89 46 80          	mov    %rax,-0x80(%r14)
     c8e:	41 0f b6 4e 9f       	movzbl -0x61(%r14),%ecx
     c93:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     c9a:	48 8b 90 f8 15 00 00 	mov    0x15f8(%rax),%rdx
     ca1:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     ca7:	48 89 43 40          	mov    %rax,0x40(%rbx)
     cab:	41 88 4e 88          	mov    %cl,-0x78(%r14)
     caf:	49 89 96 ec fe ff ff 	mov    %rdx,-0x114(%r14)
     cb6:	e9 28 11 00 00       	jmp    1de3 <f_8001161d0+0x1de3>
     cbb:	81 f9 51 02 00 00    	cmp    $0x251,%ecx
     cc1:	0f 8f 01 04 00 00    	jg     10c8 <f_8001161d0+0x10c8>
     cc7:	81 f9 c8 01 00 00    	cmp    $0x1c8,%ecx
     ccd:	0f 84 59 11 00 00    	je     1e2c <f_8001161d0+0x1e2c>
     cd3:	81 f9 0f 02 00 00    	cmp    $0x20f,%ecx
     cd9:	0f 85 7d 09 00 00    	jne    165c <f_8001161d0+0x165c>
     cdf:	48 89 fe             	mov    %rdi,%rsi
     ce2:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
     ce9:	00 00 00 
     cec:	49 8d 8c 24 17 22 04 	lea    0x42217(%r12),%rcx
     cf3:	00 
     cf4:	49 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%r15
     cfb:	ff ff ff 
     cfe:	49 8d 47 0b          	lea    0xb(%r15),%rax
     d02:	ba 00 08 00 00       	mov    $0x800,%edx
     d07:	e9 a7 0c 00 00       	jmp    19b3 <f_8001161d0+0x19b3>
     d0c:	81 f9 ac 03 00 00    	cmp    $0x3ac,%ecx
     d12:	0f 8f 1a 05 00 00    	jg     1232 <f_8001161d0+0x1232>
     d18:	81 f9 d5 02 00 00    	cmp    $0x2d5,%ecx
     d1e:	0f 84 41 13 00 00    	je     2065 <f_8001161d0+0x2065>
     d24:	81 f9 f3 02 00 00    	cmp    $0x2f3,%ecx
     d2a:	0f 85 2c 09 00 00    	jne    165c <f_8001161d0+0x165c>
     d30:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
     d37:	00 00 00 
     d3a:	49 8d 8c 24 09 f5 fe 	lea    -0x10af7(%r12),%rcx
     d41:	ff 
     d42:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     d49:	ff ff ff 
     d4c:	48 8d 42 13          	lea    0x13(%rdx),%rax
     d50:	41 bf 00 02 00 00    	mov    $0x200,%r15d
     d56:	e9 a5 14 00 00       	jmp    2200 <f_8001161d0+0x2200>
     d5b:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # d62 <f_8001161d0+0xd62>
     d62:	48 63 04 82          	movslq (%rdx,%rax,4),%rax
     d66:	48 01 d0             	add    %rdx,%rax
     d69:	ff e0                	jmp    *%rax
     d6b:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
     d72:	00 00 00 
     d75:	49 8d 8c 24 f0 79 ff 	lea    -0x8610(%r12),%rcx
     d7c:	ff 
     d7d:	e9 d6 05 00 00       	jmp    1358 <f_8001161d0+0x1358>
     d82:	81 f9 c9 00 00 00    	cmp    $0xc9,%ecx
     d88:	0f 84 fd 0b 00 00    	je     198b <f_8001161d0+0x198b>
     d8e:	81 f9 d9 00 00 00    	cmp    $0xd9,%ecx
     d94:	0f 85 c2 08 00 00    	jne    165c <f_8001161d0+0x165c>
     d9a:	48 8b 85 c8 1e 00 00 	mov    0x1ec8(%rbp),%rax
     da1:	48 89 43 08          	mov    %rax,0x8(%rbx)
     da5:	4c 89 5b 60          	mov    %r11,0x60(%rbx)
     da9:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
     db0:	00 
     db1:	48 8b 0c 24          	mov    (%rsp),%rcx
     db5:	0f b6 51 08          	movzbl 0x8(%rcx),%edx
     db9:	48 89 53 70          	mov    %rdx,0x70(%rbx)
     dbd:	0f b7 b1 14 29 00 00 	movzwl 0x2914(%rcx),%esi
     dc4:	44 8b 48 08          	mov    0x8(%rax),%r9d
     dc8:	4c 8b 50 10          	mov    0x10(%rax),%r10
     dcc:	48 c7 43 78 e0 3c 00 	movq   $0x3ce0,0x78(%rbx)
     dd3:	00 
     dd4:	31 c9                	xor    %ecx,%ecx
     dd6:	41 39 d1             	cmp    %edx,%r9d
     dd9:	41 b9 00 00 00 00    	mov    $0x0,%r9d
     ddf:	4c 0f 47 ca          	cmova  %rdx,%r9
     de3:	4c 89 8b 88 00 00 00 	mov    %r9,0x88(%rbx)
     dea:	4d 69 c9 e0 3c 00 00 	imul   $0x3ce0,%r9,%r9
     df1:	4f 8b 8c 0a 40 3c 00 	mov    0x3c40(%r10,%r9,1),%r9
     df8:	00 
     df9:	4c 89 8b b0 00 00 00 	mov    %r9,0xb0(%rbx)
     e00:	49 89 fa             	mov    %rdi,%r10
     e03:	48 8b bd b8 1e 00 00 	mov    0x1eb8(%rbp),%rdi
     e0a:	45 89 96 70 ff ff ff 	mov    %r10d,-0x90(%r14)
     e11:	4d 89 9e 58 ff ff ff 	mov    %r11,-0xa8(%r14)
     e18:	49 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r8
     e1f:	ff 7f 7f 
     e22:	4d 89 86 60 ff ff ff 	mov    %r8,-0xa0(%r14)
     e29:	49 c7 46 80 00 00 00 	movq   $0x0,-0x80(%r14)
     e30:	00 
     e31:	41 c6 46 88 00       	movb   $0x0,-0x78(%r14)
     e36:	41 c7 46 8c 00 00 00 	movl   $0x0,-0x74(%r14)
     e3d:	00 
     e3e:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     e42:	c4 c1 78 11 86 28 ff 	vmovups %xmm0,-0xd8(%r14)
     e49:	ff ff 
     e4b:	80 bf b0 06 00 00 00 	cmpb   $0x0,0x6b0(%rdi)
     e52:	49 c7 86 18 ff ff ff 	movq   $0x0,-0xe8(%r14)
     e59:	00 00 00 00 
     e5d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
     e62:	49 89 be 20 ff ff ff 	mov    %rdi,-0xe0(%r14)
     e69:	49 c7 86 00 ff ff ff 	movq   $0x4,-0x100(%r14)
     e70:	04 00 00 00 
     e74:	4c 89 0b             	mov    %r9,(%rbx)
     e77:	40 0f 95 c7          	setne  %dil
     e7b:	83 e6 40             	and    $0x40,%esi
     e7e:	c1 ee 06             	shr    $0x6,%esi
     e81:	40 20 fe             	and    %dil,%sil
     e84:	40 0f b6 f6          	movzbl %sil,%esi
     e88:	c1 e6 1a             	shl    $0x1a,%esi
     e8b:	81 ce 01 00 40 00    	or     $0x400001,%esi
     e91:	41 c7 86 d8 fe ff ff 	movl   $0x0,-0x128(%r14)
     e98:	00 00 00 00 
     e9c:	41 89 b6 dc fe ff ff 	mov    %esi,-0x124(%r14)
     ea3:	48 be 10 00 00 00 03 	movabs $0x300000010,%rsi
     eaa:	00 00 00 
     ead:	49 89 b6 d0 fe ff ff 	mov    %rsi,-0x130(%r14)
     eb4:	49 c7 86 e0 fe ff ff 	movq   $0xffff,-0x120(%r14)
     ebb:	ff ff 00 00 
     ebf:	49 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%r15
     ec6:	ff ff ff 
     ec9:	49 8d 77 07          	lea    0x7(%r15),%rsi
     ecd:	49 89 b6 e8 fe ff ff 	mov    %rsi,-0x118(%r14)
     ed4:	48 be 00 00 00 00 01 	movabs $0x100000000,%rsi
     edb:	00 00 00 
     ede:	49 89 b6 f0 fe ff ff 	mov    %rsi,-0x110(%r14)
     ee5:	4d 89 be f8 fe ff ff 	mov    %r15,-0x108(%r14)
     eec:	48 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rsi
     ef3:	00 80 3f 
     ef6:	49 89 b6 08 ff ff ff 	mov    %rsi,-0xf8(%r14)
     efd:	49 89 b6 10 ff ff ff 	mov    %rsi,-0xf0(%r14)
     f04:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
     f0b:	00 00 00 
     f0e:	49 8d b4 24 10 ce 08 	lea    0x8ce10(%r12),%rsi
     f15:	00 
     f16:	48 89 73 68          	mov    %rsi,0x68(%rbx)
     f1a:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
     f1f:	49 89 be 74 ff ff ff 	mov    %rdi,-0x8c(%r14)
     f26:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
     f2d:	ff 7f ff 
     f30:	48 89 bb 80 00 00 00 	mov    %rdi,0x80(%rbx)
     f37:	4d 89 86 48 ff ff ff 	mov    %r8,-0xb8(%r14)
     f3e:	49 89 be 50 ff ff ff 	mov    %rdi,-0xb0(%r14)
     f45:	49 89 be 68 ff ff ff 	mov    %rdi,-0x98(%r14)
     f4c:	49 c7 86 38 ff ff ff 	movq   $0x0,-0xc8(%r14)
     f53:	00 00 00 00 
     f57:	49 89 b6 40 ff ff ff 	mov    %rsi,-0xc0(%r14)
     f5e:	48 8b 70 10          	mov    0x10(%rax),%rsi
     f62:	48 69 fa e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdi
     f69:	39 50 08             	cmp    %edx,0x8(%rax)
     f6c:	41 b8 00 00 00 00    	mov    $0x0,%r8d
     f72:	4c 0f 47 c7          	cmova  %rdi,%r8
     f76:	c4 c1 78 10 84 30 00 	vmovups 0x2e00(%r8,%rsi,1),%xmm0
     f7d:	2e 00 00 
     f80:	c4 c1 78 11 86 48 ff 	vmovups %xmm0,-0xb8(%r14)
     f87:	ff ff 
     f89:	39 50 08             	cmp    %edx,0x8(%rax)
     f8c:	48 0f 47 cf          	cmova  %rdi,%rcx
     f90:	48 8b 40 10          	mov    0x10(%rax),%rax
     f94:	48 8b 94 01 80 30 00 	mov    0x3080(%rcx,%rax,1),%rdx
     f9b:	00 
     f9c:	48 8b b4 01 88 30 00 	mov    0x3088(%rcx,%rax,1),%rsi
     fa3:	00 
     fa4:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     fa8:	49 89 96 60 ff ff ff 	mov    %rdx,-0xa0(%r14)
     faf:	49 89 b6 68 ff ff ff 	mov    %rsi,-0x98(%r14)
     fb6:	48 8b 94 01 90 30 00 	mov    0x3090(%rcx,%rax,1),%rdx
     fbd:	00 
     fbe:	48 89 53 48          	mov    %rdx,0x48(%rbx)
     fc2:	8b 84 01 98 30 00 00 	mov    0x3098(%rcx,%rax,1),%eax
     fc9:	41 89 86 78 ff ff ff 	mov    %eax,-0x88(%r14)
     fd0:	49 8d 46 97          	lea    -0x69(%r14),%rax
     fd4:	48 89 43 40          	mov    %rax,0x40(%rbx)
     fd8:	49 89 96 70 ff ff ff 	mov    %rdx,-0x90(%r14)
     fdf:	49 8d 84 24 f6 83 50 	lea    -0x2af7c0a(%r12),%rax
     fe6:	fd 
     fe7:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
     fee:	48 89 df             	mov    %rbx,%rdi
     ff1:	c5 f8 77             	vzeroupper
     ff4:	e8 00 00 00 00       	call   ff9 <f_8001161d0+0xff9>
     ff9:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    1000:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    1007:	49 89 46 80          	mov    %rax,-0x80(%r14)
    100b:	41 0f b6 46 9f       	movzbl -0x61(%r14),%eax
    1010:	48 8b 8b b0 00 00 00 	mov    0xb0(%rbx),%rcx
    1017:	48 8b 91 f8 15 00 00 	mov    0x15f8(%rcx),%rdx
    101e:	8b 89 00 16 00 00    	mov    0x1600(%rcx),%ecx
    1024:	41 88 46 88          	mov    %al,-0x78(%r14)
    1028:	49 89 96 ec fe ff ff 	mov    %rdx,-0x114(%r14)
    102f:	41 89 8e f4 fe ff ff 	mov    %ecx,-0x10c(%r14)
    1036:	e9 7b 13 00 00       	jmp    23b6 <f_8001161d0+0x23b6>
    103b:	81 f9 b2 01 00 00    	cmp    $0x1b2,%ecx
    1041:	49 89 ea             	mov    %rbp,%r10
    1044:	0f 84 48 11 00 00    	je     2192 <f_8001161d0+0x2192>
    104a:	81 f9 b8 01 00 00    	cmp    $0x1b8,%ecx
    1050:	0f 85 06 06 00 00    	jne    165c <f_8001161d0+0x165c>
    1056:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    105d:	00 00 00 
    1060:	49 8d 8c 24 bf a6 04 	lea    0x4a6bf(%r12),%rcx
    1067:	00 
    1068:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    106f:	ff ff ff 
    1072:	48 8d 42 15          	lea    0x15(%rdx),%rax
    1076:	e9 85 11 00 00       	jmp    2200 <f_8001161d0+0x2200>
    107b:	81 f9 b6 02 00 00    	cmp    $0x2b6,%ecx
    1081:	0f 84 57 11 00 00    	je     21de <f_8001161d0+0x21de>
    1087:	81 f9 c5 02 00 00    	cmp    $0x2c5,%ecx
    108d:	0f 85 c9 05 00 00    	jne    165c <f_8001161d0+0x165c>
    1093:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    109a:	00 00 00 
    109d:	49 8d 8c 24 98 55 0a 	lea    0xa5598(%r12),%rcx
    10a4:	00 
    10a5:	48 be 00 00 00 00 02 	movabs $0x80200000000,%rsi
    10ac:	08 00 00 
    10af:	49 bf 01 00 00 00 04 	movabs $0x400000001,%r15
    10b6:	00 00 00 
    10b9:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    10c0:	ff ff ff 
    10c3:	e9 42 11 00 00       	jmp    220a <f_8001161d0+0x220a>
    10c8:	81 f9 52 02 00 00    	cmp    $0x252,%ecx
    10ce:	0f 84 29 15 00 00    	je     25fd <f_8001161d0+0x25fd>
    10d4:	81 f9 61 02 00 00    	cmp    $0x261,%ecx
    10da:	0f 85 7c 05 00 00    	jne    165c <f_8001161d0+0x165c>
    10e0:	49 89 ea             	mov    %rbp,%r10
    10e3:	41 89 be 70 ff ff ff 	mov    %edi,-0x90(%r14)
    10ea:	48 b8 00 00 00 00 0f 	movabs $0xf00000000,%rax
    10f1:	00 00 00 
    10f4:	49 89 86 e4 fe ff ff 	mov    %rax,-0x11c(%r14)
    10fb:	48 b8 00 00 00 00 ff 	movabs $0xffff00000000,%rax
    1102:	ff 00 00 
    1105:	48 0d 00 00 40 08    	or     $0x8400000,%rax
    110b:	49 89 86 dc fe ff ff 	mov    %rax,-0x124(%r14)
    1112:	b8 00 00 02 00       	mov    $0x20000,%eax
    1117:	23 85 8c 3a 00 00    	and    0x3a8c(%rbp),%eax
    111d:	49 c7 86 d4 fe ff ff 	movq   $0x0,-0x12c(%r14)
    1124:	00 00 00 00 
    1128:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    112f:	00 00 00 
    1132:	48 ff c9             	dec    %rcx
    1135:	49 89 8e ec fe ff ff 	mov    %rcx,-0x114(%r14)
    113c:	41 c7 86 04 ff ff ff 	movl   $0x0,-0xfc(%r14)
    1143:	00 00 00 00 
    1147:	49 c7 46 80 00 00 00 	movq   $0x0,-0x80(%r14)
    114e:	00 
    114f:	c1 e8 08             	shr    $0x8,%eax
    1152:	0d 00 00 00 40       	or     $0x40000000,%eax
    1157:	49 c7 86 f4 fe ff ff 	movq   $0x1,-0x10c(%r14)
    115e:	01 00 00 00 
    1162:	41 c6 46 88 00       	movb   $0x0,-0x78(%r14)
    1167:	41 c7 46 8c 00 00 00 	movl   $0x0,-0x74(%r14)
    116e:	00 
    116f:	48 b9 ff ff ff ff 01 	movabs $0x1ffffffff,%rcx
    1176:	00 00 00 
    1179:	49 89 8e fc fe ff ff 	mov    %rcx,-0x104(%r14)
    1180:	41 89 86 d0 fe ff ff 	mov    %eax,-0x130(%r14)
    1187:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    118e:	00 00 00 
    1191:	4c 89 63 70          	mov    %r12,0x70(%rbx)
    1195:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    119c:	00 80 3f 
    119f:	49 89 86 08 ff ff ff 	mov    %rax,-0xf8(%r14)
    11a6:	49 89 86 10 ff ff ff 	mov    %rax,-0xf0(%r14)
    11ad:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    11b2:	49 89 86 74 ff ff ff 	mov    %rax,-0x8c(%r14)
    11b9:	48 b9 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rcx
    11c0:	ff 7f ff 
    11c3:	48 89 8b 80 00 00 00 	mov    %rcx,0x80(%rbx)
    11ca:	49 89 8e 68 ff ff ff 	mov    %rcx,-0x98(%r14)
    11d1:	48 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rax
    11d8:	ff 7f 7f 
    11db:	49 89 86 48 ff ff ff 	mov    %rax,-0xb8(%r14)
    11e2:	49 89 8e 50 ff ff ff 	mov    %rcx,-0xb0(%r14)
    11e9:	4d 89 9e 58 ff ff ff 	mov    %r11,-0xa8(%r14)
    11f0:	49 89 86 60 ff ff ff 	mov    %rax,-0xa0(%r14)
    11f7:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    11fb:	c4 c1 78 11 86 28 ff 	vmovups %xmm0,-0xd8(%r14)
    1202:	ff ff 
    1204:	49 c7 86 38 ff ff ff 	movq   $0x0,-0xc8(%r14)
    120b:	00 00 00 00 
    120f:	4d 89 a6 40 ff ff ff 	mov    %r12,-0xc0(%r14)
    1216:	49 c7 86 18 ff ff ff 	movq   $0x0,-0xe8(%r14)
    121d:	00 00 00 00 
    1221:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    1226:	49 89 86 20 ff ff ff 	mov    %rax,-0xe0(%r14)
    122d:	e9 dc 10 00 00       	jmp    230e <f_8001161d0+0x230e>
    1232:	81 f9 ad 03 00 00    	cmp    $0x3ad,%ecx
    1238:	0f 84 ef 13 00 00    	je     262d <f_8001161d0+0x262d>
    123e:	81 f9 12 04 00 00    	cmp    $0x412,%ecx
    1244:	0f 85 12 04 00 00    	jne    165c <f_8001161d0+0x165c>
    124a:	48 89 f9             	mov    %rdi,%rcx
    124d:	48 b8 ba e3 c0 02 08 	movabs $0x802c0e3ba,%rax
    1254:	00 00 00 
    1257:	4c 8d b8 10 7a ff ff 	lea    -0x85f0(%rax),%r15
    125e:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    1265:	ff ff ff 
    1268:	48 8d 6a 16          	lea    0x16(%rdx),%rbp
    126c:	b8 30 00 00 00       	mov    $0x30,%eax
    1271:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    1276:	b8 40 33 00 00       	mov    $0x3340,%eax
    127b:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    1280:	b8 48 33 00 00       	mov    $0x3348,%eax
    1285:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    128a:	be 30 33 00 00       	mov    $0x3330,%esi
    128f:	41 b9 38 33 00 00    	mov    $0x3338,%r9d
    1295:	41 bc b0 30 00 00    	mov    $0x30b0,%r12d
    129b:	41 bd b8 30 00 00    	mov    $0x30b8,%r13d
    12a1:	b8 02 00 00 00       	mov    $0x2,%eax
    12a6:	e9 cd 04 00 00       	jmp    1778 <f_8001161d0+0x1778>
    12ab:	81 f9 1a 05 00 00    	cmp    $0x51a,%ecx
    12b1:	0f 85 a5 03 00 00    	jne    165c <f_8001161d0+0x165c>
    12b7:	49 81 c2 e8 0a 00 00 	add    $0xae8,%r10
    12be:	4c 89 13             	mov    %r10,(%rbx)
    12c1:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    12c6:	48 89 43 08          	mov    %rax,0x8(%rbx)
    12ca:	48 8b 04 24          	mov    (%rsp),%rax
    12ce:	48 89 43 10          	mov    %rax,0x10(%rbx)
    12d2:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    12d9:	00 00 00 
    12dc:	49 8d 84 24 da 93 50 	lea    -0x2af6c26(%r12),%rax
    12e3:	fd 
    12e4:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    12eb:	48 89 df             	mov    %rbx,%rdi
    12ee:	c5 f8 77             	vzeroupper
    12f1:	e8 00 00 00 00       	call   12f6 <f_8001161d0+0x12f6>
    12f6:	e9 bb 10 00 00       	jmp    23b6 <f_8001161d0+0x23b6>
    12fb:	83 f9 61             	cmp    $0x61,%ecx
    12fe:	0f 85 58 03 00 00    	jne    165c <f_8001161d0+0x165c>
    1304:	49 89 ea             	mov    %rbp,%r10
    1307:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    130e:	00 00 00 
    1311:	49 8d 8c 24 bb 6c 0c 	lea    0xc6cbb(%r12),%rcx
    1318:	00 
    1319:	e9 d8 0e 00 00       	jmp    21f6 <f_8001161d0+0x21f6>
    131e:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    1325:	00 00 00 
    1328:	49 8d 8c 24 1b 4b 09 	lea    0x94b1b(%r12),%rcx
    132f:	00 
    1330:	eb 26                	jmp    1358 <f_8001161d0+0x1358>
    1332:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    1339:	00 00 00 
    133c:	49 8d 8c 24 3d 06 01 	lea    0x1063d(%r12),%rcx
    1343:	00 
    1344:	eb 12                	jmp    1358 <f_8001161d0+0x1358>
    1346:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    134d:	00 00 00 
    1350:	49 8d 8c 24 5b c9 09 	lea    0x9c95b(%r12),%rcx
    1357:	00 
    1358:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
    135c:	41 c7 86 d0 fe ff ff 	movl   $0x10000000,-0x130(%r14)
    1363:	00 00 00 10 
    1367:	49 8b 82 f0 31 00 00 	mov    0x31f0(%r10),%rax
    136e:	48 89 03             	mov    %rax,(%rbx)
    1371:	48 ba 10 00 00 00 03 	movabs $0x300000010,%rdx
    1378:	00 00 00 
    137b:	48 8d 72 f0          	lea    -0x10(%rdx),%rsi
    137f:	49 89 b6 e4 fe ff ff 	mov    %rsi,-0x11c(%r14)
    1386:	48 c7 43 78 01 00 00 	movq   $0x1,0x78(%rbx)
    138d:	00 
    138e:	48 83 c2 f6          	add    $0xfffffffffffffff6,%rdx
    1392:	49 89 96 d4 fe ff ff 	mov    %rdx,-0x12c(%r14)
    1399:	49 c7 86 fc fe ff ff 	movq   $0xffffffffffffffff,-0x104(%r14)
    13a0:	ff ff ff ff 
    13a4:	48 ba 00 00 00 00 ff 	movabs $0xffff00000000,%rdx
    13ab:	ff 00 00 
    13ae:	49 89 96 dc fe ff ff 	mov    %rdx,-0x124(%r14)
    13b5:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
    13bc:	ff 7f ff 
    13bf:	48 89 73 70          	mov    %rsi,0x70(%rbx)
    13c3:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
    13ca:	00 00 00 
    13cd:	48 ff ca             	dec    %rdx
    13d0:	49 89 96 ec fe ff ff 	mov    %rdx,-0x114(%r14)
    13d7:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
    13de:	00 80 3f 
    13e1:	49 89 96 08 ff ff ff 	mov    %rdx,-0xf8(%r14)
    13e8:	49 89 96 10 ff ff ff 	mov    %rdx,-0xf0(%r14)
    13ef:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    13f4:	4c 89 4b 48          	mov    %r9,0x48(%rbx)
    13f8:	49 c7 86 f4 fe ff ff 	movq   $0x1,-0x10c(%r14)
    13ff:	01 00 00 00 
    1403:	41 c7 86 04 ff ff ff 	movl   $0x0,-0xfc(%r14)
    140a:	00 00 00 00 
    140e:	4d 89 8e 74 ff ff ff 	mov    %r9,-0x8c(%r14)
    1415:	49 89 b6 68 ff ff ff 	mov    %rsi,-0x98(%r14)
    141c:	41 c6 46 88 00       	movb   $0x0,-0x78(%r14)
    1421:	49 c7 46 80 00 00 00 	movq   $0x0,-0x80(%r14)
    1428:	00 
    1429:	41 89 be 70 ff ff ff 	mov    %edi,-0x90(%r14)
    1430:	41 c7 46 8c 01 00 00 	movl   $0x1,-0x74(%r14)
    1437:	00 
    1438:	48 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rdx
    143f:	ff 7f 7f 
    1442:	49 89 96 48 ff ff ff 	mov    %rdx,-0xb8(%r14)
    1449:	49 89 b6 50 ff ff ff 	mov    %rsi,-0xb0(%r14)
    1450:	4d 89 9e 58 ff ff ff 	mov    %r11,-0xa8(%r14)
    1457:	49 89 96 60 ff ff ff 	mov    %rdx,-0xa0(%r14)
    145e:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1462:	c4 c1 78 11 86 28 ff 	vmovups %xmm0,-0xd8(%r14)
    1469:	ff ff 
    146b:	49 c7 86 38 ff ff ff 	movq   $0x0,-0xc8(%r14)
    1472:	00 00 00 00 
    1476:	49 89 8e 40 ff ff ff 	mov    %rcx,-0xc0(%r14)
    147d:	49 c7 86 18 ff ff ff 	movq   $0x0,-0xe8(%r14)
    1484:	00 00 00 00 
    1488:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    148d:	49 89 8e 20 ff ff ff 	mov    %rcx,-0xe0(%r14)
    1494:	48 85 c0             	test   %rax,%rax
    1497:	0f 84 19 0f 00 00    	je     23b6 <f_8001161d0+0x23b6>
    149d:	49 8b 8a c8 1e 00 00 	mov    0x1ec8(%r10),%rcx
    14a4:	48 8b 14 24          	mov    (%rsp),%rdx
    14a8:	0f b6 52 08          	movzbl 0x8(%rdx),%edx
    14ac:	8b 71 08             	mov    0x8(%rcx),%esi
    14af:	49 89 fa             	mov    %rdi,%r10
    14b2:	48 8b 79 10          	mov    0x10(%rcx),%rdi
    14b6:	48 c7 43 60 e0 3c 00 	movq   $0x3ce0,0x60(%rbx)
    14bd:	00 
    14be:	31 c9                	xor    %ecx,%ecx
    14c0:	39 d6                	cmp    %edx,%esi
    14c2:	be 00 00 00 00       	mov    $0x0,%esi
    14c7:	48 0f 47 f2          	cmova  %rdx,%rsi
    14cb:	48 89 73 58          	mov    %rsi,0x58(%rbx)
    14cf:	48 69 d6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rdx
    14d6:	48 8d 34 3a          	lea    (%rdx,%rdi,1),%rsi
    14da:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    14de:	c5 fa 10 8c 3a 08 2e 	vmovss 0x2e08(%rdx,%rdi,1),%xmm1
    14e5:	00 00 
    14e7:	c5 fa 10 94 3a 0c 2e 	vmovss 0x2e0c(%rdx,%rdi,1),%xmm2
    14ee:	00 00 
    14f0:	c5 f2 5c 9c 3a 00 2e 	vsubss 0x2e00(%rdx,%rdi,1),%xmm1,%xmm3
    14f7:	00 00 
    14f9:	c4 e1 fa 2c f3       	vcvttss2si %xmm3,%rsi
    14fe:	c5 f0 57 c9          	vxorps %xmm1,%xmm1,%xmm1
    1502:	c5 f8 2e d9          	vucomiss %xmm1,%xmm3
    1506:	0f 42 f1             	cmovb  %ecx,%esi
    1509:	c5 fa 10 25 00 00 00 	vmovss 0x0(%rip),%xmm4        # 1511 <f_8001161d0+0x1511>
    1510:	00 
    1511:	c5 f8 2e dc          	vucomiss %xmm4,%xmm3
    1515:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    151b:	41 0f 47 f0          	cmova  %r8d,%esi
    151f:	c5 ea 5c 94 3a 04 2e 	vsubss 0x2e04(%rdx,%rdi,1),%xmm2,%xmm2
    1526:	00 00 
    1528:	c4 e1 fa 2c d2       	vcvttss2si %xmm2,%rdx
    152d:	45 89 96 70 ff ff ff 	mov    %r10d,-0x90(%r14)
    1534:	c5 f8 2e d1          	vucomiss %xmm1,%xmm2
    1538:	0f 42 d1             	cmovb  %ecx,%edx
    153b:	c5 f8 2e d4          	vucomiss %xmm4,%xmm2
    153f:	41 0f 47 d0          	cmova  %r8d,%edx
    1543:	49 8d 7e 97          	lea    -0x69(%r14),%rdi
    1547:	c4 e1 82 2a d6       	vcvtsi2ss %rsi,%xmm15,%xmm2
    154c:	48 89 7b 40          	mov    %rdi,0x40(%rbx)
    1550:	4d 89 8e 74 ff ff ff 	mov    %r9,-0x8c(%r14)
    1557:	c5 ea 59 90 08 03 00 	vmulss 0x308(%rax),%xmm2,%xmm2
    155e:	00 
    155f:	c4 e1 82 2a da       	vcvtsi2ss %rdx,%xmm15,%xmm3
    1564:	c5 f9 7e d2          	vmovd  %xmm2,%edx
    1568:	c5 e2 59 98 0c 03 00 	vmulss 0x30c(%rax),%xmm3,%xmm3
    156f:	00 
    1570:	c5 f9 7e d8          	vmovd  %xmm3,%eax
    1574:	c5 f8 29 83 20 02 00 	vmovaps %xmm0,0x220(%rbx)
    157b:	00 
    157c:	c5 ea 5f c1          	vmaxss %xmm1,%xmm2,%xmm0
    1580:	c5 f9 7e c6          	vmovd  %xmm0,%esi
    1584:	48 89 b3 30 02 00 00 	mov    %rsi,0x230(%rbx)
    158b:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    1592:	00 00 00 00 
    1596:	c5 e2 5f e1          	vmaxss %xmm1,%xmm3,%xmm4
    159a:	c5 f9 7e e6          	vmovd  %xmm4,%esi
    159e:	c5 f8 2e d1          	vucomiss %xmm1,%xmm2
    15a2:	0f 47 d1             	cmova  %ecx,%edx
    15a5:	48 89 b3 40 02 00 00 	mov    %rsi,0x240(%rbx)
    15ac:	48 c7 83 48 02 00 00 	movq   $0x0,0x248(%rbx)
    15b3:	00 00 00 00 
    15b7:	48 89 93 00 02 00 00 	mov    %rdx,0x200(%rbx)
    15be:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    15c5:	00 00 00 00 
    15c9:	c4 c1 7a 11 86 50 ff 	vmovss %xmm0,-0xb0(%r14)
    15d0:	ff ff 
    15d2:	c4 c1 7a 11 a6 54 ff 	vmovss %xmm4,-0xac(%r14)
    15d9:	ff ff 
    15db:	c4 c1 7a 11 86 68 ff 	vmovss %xmm0,-0x98(%r14)
    15e2:	ff ff 
    15e4:	c4 c1 7a 11 a6 6c ff 	vmovss %xmm4,-0x94(%r14)
    15eb:	ff ff 
    15ed:	c5 f8 2e d9          	vucomiss %xmm1,%xmm3
    15f1:	0f 47 c1             	cmova  %ecx,%eax
    15f4:	48 89 83 10 02 00 00 	mov    %rax,0x210(%rbx)
    15fb:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    1602:	00 00 00 00 
    1606:	41 89 96 48 ff ff ff 	mov    %edx,-0xb8(%r14)
    160d:	41 89 86 4c ff ff ff 	mov    %eax,-0xb4(%r14)
    1614:	41 89 96 60 ff ff ff 	mov    %edx,-0xa0(%r14)
    161b:	41 89 86 64 ff ff ff 	mov    %eax,-0x9c(%r14)
    1622:	49 8d 84 24 6e 92 50 	lea    -0x2af6d92(%r12),%rax
    1629:	fd 
    162a:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    1631:	48 89 df             	mov    %rbx,%rdi
    1634:	c5 f8 77             	vzeroupper
    1637:	e8 00 00 00 00       	call   163c <f_8001161d0+0x163c>
    163c:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    1643:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    164a:	49 89 46 80          	mov    %rax,-0x80(%r14)
    164e:	41 0f b6 46 9f       	movzbl -0x61(%r14),%eax
    1653:	41 88 46 88          	mov    %al,-0x78(%r14)
    1657:	e9 5a 0d 00 00       	jmp    23b6 <f_8001161d0+0x23b6>
    165c:	4c 89 a3 08 01 00 00 	mov    %r12,0x108(%rbx)
    1663:	48 89 df             	mov    %rbx,%rdi
    1666:	48 83 c4 38          	add    $0x38,%rsp
    166a:	5b                   	pop    %rbx
    166b:	41 5c                	pop    %r12
    166d:	41 5d                	pop    %r13
    166f:	41 5e                	pop    %r14
    1671:	41 5f                	pop    %r15
    1673:	5d                   	pop    %rbp
    1674:	c5 f8 77             	vzeroupper
    1677:	e9 00 00 00 00       	jmp    167c <f_8001161d0+0x167c>
    167c:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    1683:	00 
    1684:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    1689:	48 89 43 08          	mov    %rax,0x8(%rbx)
    168d:	48 8b 04 24          	mov    (%rsp),%rax
    1691:	48 89 43 10          	mov    %rax,0x10(%rbx)
    1695:	49 81 c2 b0 1e 00 00 	add    $0x1eb0,%r10
    169c:	4c 89 13             	mov    %r10,(%rbx)
    169f:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
    16a6:	00 
    16a7:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    16ae:	00 00 00 
    16b1:	49 8d 84 24 be 92 50 	lea    -0x2af6d42(%r12),%rax
    16b8:	fd 
    16b9:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    16c0:	48 89 df             	mov    %rbx,%rdi
    16c3:	c5 f8 77             	vzeroupper
    16c6:	e8 00 00 00 00       	call   16cb <f_8001161d0+0x16cb>
    16cb:	e9 e6 0c 00 00       	jmp    23b6 <f_8001161d0+0x23b6>
    16d0:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    16d7:	00 
    16d8:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    16dd:	48 89 43 08          	mov    %rax,0x8(%rbx)
    16e1:	48 8b 04 24          	mov    (%rsp),%rax
    16e5:	48 89 43 10          	mov    %rax,0x10(%rbx)
    16e9:	49 81 c2 b0 1e 00 00 	add    $0x1eb0,%r10
    16f0:	4c 89 13             	mov    %r10,(%rbx)
    16f3:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    16fa:	00 00 00 
    16fd:	49 8d 84 24 de 92 50 	lea    -0x2af6d22(%r12),%rax
    1704:	fd 
    1705:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    170c:	48 89 df             	mov    %rbx,%rdi
    170f:	c5 f8 77             	vzeroupper
    1712:	e8 00 00 00 00       	call   1717 <f_8001161d0+0x1717>
    1717:	e9 9a 0c 00 00       	jmp    23b6 <f_8001161d0+0x23b6>
    171c:	48 89 f9             	mov    %rdi,%rcx
    171f:	48 b8 ba e3 c0 02 08 	movabs $0x802c0e3ba,%rax
    1726:	00 00 00 
    1729:	4c 8d b8 35 ee 0c 00 	lea    0xcee35(%rax),%r15
    1730:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    1737:	ff ff ff 
    173a:	48 8d 6a 17          	lea    0x17(%rdx),%rbp
    173e:	b8 3c 00 00 00       	mov    $0x3c,%eax
    1743:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
    1748:	b8 f0 35 00 00       	mov    $0x35f0,%eax
    174d:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
    1752:	b8 f8 35 00 00       	mov    $0x35f8,%eax
    1757:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
    175c:	be e0 35 00 00       	mov    $0x35e0,%esi
    1761:	41 b9 e8 35 00 00    	mov    $0x35e8,%r9d
    1767:	41 bc 60 33 00 00    	mov    $0x3360,%r12d
    176d:	41 bd 68 33 00 00    	mov    $0x3368,%r13d
    1773:	b8 04 00 00 00       	mov    $0x4,%eax
    1778:	49 8b ba c8 1e 00 00 	mov    0x1ec8(%r10),%rdi
    177f:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
    1783:	49 b8 00 00 00 00 01 	movabs $0x100000000,%r8
    178a:	00 00 00 
    178d:	4c 89 03             	mov    %r8,(%rbx)
    1790:	41 c6 46 88 00       	movb   $0x0,-0x78(%r14)
    1795:	49 89 86 d0 fe ff ff 	mov    %rax,-0x130(%r14)
    179c:	48 b8 00 00 00 00 00 	movabs $0x40000000000000,%rax
    17a3:	00 40 00 
    17a6:	48 ff c0             	inc    %rax
    17a9:	49 89 86 d8 fe ff ff 	mov    %rax,-0x128(%r14)
    17b0:	4d 89 86 f0 fe ff ff 	mov    %r8,-0x110(%r14)
    17b7:	49 89 96 f8 fe ff ff 	mov    %rdx,-0x108(%r14)
    17be:	4c 89 7b 68          	mov    %r15,0x68(%rbx)
    17c2:	49 ba ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r10
    17c9:	ff 7f ff 
    17cc:	4d 89 96 50 ff ff ff 	mov    %r10,-0xb0(%r14)
    17d3:	4d 89 9e 58 ff ff ff 	mov    %r11,-0xa8(%r14)
    17da:	48 c7 83 88 00 00 00 	movq   $0xffff,0x88(%rbx)
    17e1:	ff ff 00 00 
    17e5:	48 89 ab 90 00 00 00 	mov    %rbp,0x90(%rbx)
    17ec:	49 8d 40 ff          	lea    -0x1(%r8),%rax
    17f0:	48 89 83 80 00 00 00 	mov    %rax,0x80(%rbx)
    17f7:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    17fc:	4d 89 86 74 ff ff ff 	mov    %r8,-0x8c(%r14)
    1803:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
    180a:	ff 7f 7f 
    180d:	4d 89 9e 60 ff ff ff 	mov    %r11,-0xa0(%r14)
    1814:	4d 89 96 68 ff ff ff 	mov    %r10,-0x98(%r14)
    181b:	48 c7 43 78 03 00 00 	movq   $0x3,0x78(%rbx)
    1822:	00 
    1823:	49 c7 46 80 00 00 00 	movq   $0x0,-0x80(%r14)
    182a:	00 
    182b:	41 89 8e 70 ff ff ff 	mov    %ecx,-0x90(%r14)
    1832:	48 8b 0c 24          	mov    (%rsp),%rcx
    1836:	44 0f b6 41 08       	movzbl 0x8(%rcx),%r8d
    183b:	41 c7 46 8c 03 00 00 	movl   $0x3,-0x74(%r14)
    1842:	00 
    1843:	49 c7 86 e0 fe ff ff 	movq   $0xffff,-0x120(%r14)
    184a:	ff ff 00 00 
    184e:	49 89 ae e8 fe ff ff 	mov    %rbp,-0x118(%r14)
    1855:	49 c7 86 38 ff ff ff 	movq   $0x0,-0xc8(%r14)
    185c:	00 00 00 00 
    1860:	49 89 86 00 ff ff ff 	mov    %rax,-0x100(%r14)
    1867:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    186e:	00 80 3f 
    1871:	49 89 86 08 ff ff ff 	mov    %rax,-0xf8(%r14)
    1878:	49 89 86 10 ff ff ff 	mov    %rax,-0xf0(%r14)
    187f:	49 c7 86 18 ff ff ff 	movq   $0x0,-0xe8(%r14)
    1886:	00 00 00 00 
    188a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    188f:	49 89 86 20 ff ff ff 	mov    %rax,-0xe0(%r14)
    1896:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    189a:	c4 c1 78 11 86 28 ff 	vmovups %xmm0,-0xd8(%r14)
    18a1:	ff ff 
    18a3:	4d 89 be 40 ff ff ff 	mov    %r15,-0xc0(%r14)
    18aa:	4d 89 9e 48 ff ff ff 	mov    %r11,-0xb8(%r14)
    18b1:	49 69 c0 e0 3c 00 00 	imul   $0x3ce0,%r8,%rax
    18b8:	45 31 d2             	xor    %r10d,%r10d
    18bb:	44 39 47 08          	cmp    %r8d,0x8(%rdi)
    18bf:	41 bb 00 00 00 00    	mov    $0x0,%r11d
    18c5:	4c 0f 47 d8          	cmova  %rax,%r11
    18c9:	4c 03 5f 10          	add    0x10(%rdi),%r11
    18cd:	4f 8b 7c 1d 00       	mov    0x0(%r13,%r11,1),%r15
    18d2:	4f 8b 1c 1c          	mov    (%r12,%r11,1),%r11
    18d6:	4d 89 9e 48 ff ff ff 	mov    %r11,-0xb8(%r14)
    18dd:	4d 89 be 50 ff ff ff 	mov    %r15,-0xb0(%r14)
    18e4:	44 39 47 08          	cmp    %r8d,0x8(%rdi)
    18e8:	4c 0f 47 d0          	cmova  %rax,%r10
    18ec:	4c 03 57 10          	add    0x10(%rdi),%r10
    18f0:	4b 8b 04 11          	mov    (%r9,%r10,1),%rax
    18f4:	4a 8b 34 16          	mov    (%rsi,%r10,1),%rsi
    18f8:	49 89 b6 60 ff ff ff 	mov    %rsi,-0xa0(%r14)
    18ff:	49 89 86 68 ff ff ff 	mov    %rax,-0x98(%r14)
    1906:	48 8b 44 24 28       	mov    0x28(%rsp),%rax
    190b:	42 8b 04 10          	mov    (%rax,%r10,1),%eax
    190f:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
    1914:	4a 8b 0c 11          	mov    (%rcx,%r10,1),%rcx
    1918:	49 89 8e 70 ff ff ff 	mov    %rcx,-0x90(%r14)
    191f:	41 89 86 78 ff ff ff 	mov    %eax,-0x88(%r14)
    1926:	8b 47 44             	mov    0x44(%rdi),%eax
    1929:	48 89 43 40          	mov    %rax,0x40(%rbx)
    192d:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
    1932:	8b 0c 0f             	mov    (%rdi,%rcx,1),%ecx
    1935:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    1939:	41 88 46 80          	mov    %al,-0x80(%r14)
    193d:	41 c7 46 84 00 00 00 	movl   $0x0,-0x7c(%r14)
    1944:	00 
    1945:	41 c7 46 81 00 00 00 	movl   $0x0,-0x7f(%r14)
    194c:	00 
    194d:	41 88 4e 88          	mov    %cl,-0x78(%r14)
    1951:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    1958:	00 00 00 
    195b:	e9 56 0a 00 00       	jmp    23b6 <f_8001161d0+0x23b6>
    1960:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    1967:	00 00 00 
    196a:	49 8d 8c 24 b1 e9 fd 	lea    -0x2164f(%r12),%rcx
    1971:	ff 
    1972:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    1979:	ff ff ff 
    197c:	48 8d 42 13          	lea    0x13(%rdx),%rax
    1980:	41 bf 00 01 00 00    	mov    $0x100,%r15d
    1986:	e9 75 08 00 00       	jmp    2200 <f_8001161d0+0x2200>
    198b:	48 89 fe             	mov    %rdi,%rsi
    198e:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    1995:	00 00 00 
    1998:	49 8d 8c 24 c2 1e 03 	lea    0x31ec2(%r12),%rcx
    199f:	00 
    19a0:	49 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%r15
    19a7:	ff ff ff 
    19aa:	49 8d 47 0c          	lea    0xc(%r15),%rax
    19ae:	ba 00 10 00 00       	mov    $0x1000,%edx
    19b3:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    19ba:	00 
    19bb:	49 89 96 d0 fe ff ff 	mov    %rdx,-0x130(%r14)
    19c2:	49 c7 86 d8 fe ff ff 	movq   $0x1,-0x128(%r14)
    19c9:	01 00 00 00 
    19cd:	49 c7 86 e0 fe ff ff 	movq   $0xffff,-0x120(%r14)
    19d4:	ff ff 00 00 
    19d8:	49 89 86 e8 fe ff ff 	mov    %rax,-0x118(%r14)
    19df:	49 b8 00 00 00 00 01 	movabs $0x100000000,%r8
    19e6:	00 00 00 
    19e9:	4d 89 86 f0 fe ff ff 	mov    %r8,-0x110(%r14)
    19f0:	48 b8 00 00 00 00 ff 	movabs $0xffffffff00000000,%rax
    19f7:	ff ff ff 
    19fa:	49 89 86 f8 fe ff ff 	mov    %rax,-0x108(%r14)
    1a01:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
    1a08:	00 80 3f 
    1a0b:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
    1a0f:	49 8d 40 ff          	lea    -0x1(%r8),%rax
    1a13:	49 89 86 00 ff ff ff 	mov    %rax,-0x100(%r14)
    1a1a:	49 89 be 08 ff ff ff 	mov    %rdi,-0xf8(%r14)
    1a21:	41 89 b6 70 ff ff ff 	mov    %esi,-0x90(%r14)
    1a28:	49 8b 82 d0 2f 00 00 	mov    0x2fd0(%r10),%rax
    1a2f:	48 89 43 40          	mov    %rax,0x40(%rbx)
    1a33:	49 89 8e 40 ff ff ff 	mov    %rcx,-0xc0(%r14)
    1a3a:	48 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rcx
    1a41:	ff 7f 7f 
    1a44:	49 89 8e 48 ff ff ff 	mov    %rcx,-0xb8(%r14)
    1a4b:	48 ba ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdx
    1a52:	ff 7f ff 
    1a55:	48 89 53 68          	mov    %rdx,0x68(%rbx)
    1a59:	41 c6 46 88 00       	movb   $0x0,-0x78(%r14)
    1a5e:	49 c7 46 80 00 00 00 	movq   $0x0,-0x80(%r14)
    1a65:	00 
    1a66:	41 c7 46 8c 00 00 00 	movl   $0x0,-0x74(%r14)
    1a6d:	00 
    1a6e:	49 89 96 50 ff ff ff 	mov    %rdx,-0xb0(%r14)
    1a75:	4d 89 9e 58 ff ff ff 	mov    %r11,-0xa8(%r14)
    1a7c:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    1a81:	49 89 b6 74 ff ff ff 	mov    %rsi,-0x8c(%r14)
    1a88:	49 89 be 10 ff ff ff 	mov    %rdi,-0xf0(%r14)
    1a8f:	49 c7 86 18 ff ff ff 	movq   $0x0,-0xe8(%r14)
    1a96:	00 00 00 00 
    1a9a:	49 89 8e 60 ff ff ff 	mov    %rcx,-0xa0(%r14)
    1aa1:	49 89 96 68 ff ff ff 	mov    %rdx,-0x98(%r14)
    1aa8:	49 c7 86 38 ff ff ff 	movq   $0x0,-0xc8(%r14)
    1aaf:	00 00 00 00 
    1ab3:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    1ab8:	49 89 8e 20 ff ff ff 	mov    %rcx,-0xe0(%r14)
    1abf:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1ac3:	c4 c1 78 11 86 28 ff 	vmovups %xmm0,-0xd8(%r14)
    1aca:	ff ff 
    1acc:	48 85 c0             	test   %rax,%rax
    1acf:	0f 84 83 05 00 00    	je     2058 <f_8001161d0+0x2058>
    1ad5:	48 8b 0c 24          	mov    (%rsp),%rcx
    1ad9:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
    1add:	48 c7 43 68 e0 3c 00 	movq   $0x3ce0,0x68(%rbx)
    1ae4:	00 
    1ae5:	48 69 d1 60 0f 00 00 	imul   $0xf60,%rcx,%rdx
    1aec:	31 f6                	xor    %esi,%esi
    1aee:	39 48 10             	cmp    %ecx,0x10(%rax)
    1af1:	48 0f 46 d6          	cmovbe %rsi,%rdx
    1af5:	48 8b 40 18          	mov    0x18(%rax),%rax
    1af9:	8b 84 10 9c 02 00 00 	mov    0x29c(%rax,%rdx,1),%eax
    1b00:	4c 09 c0             	or     %r8,%rax
    1b03:	49 89 86 ec fe ff ff 	mov    %rax,-0x114(%r14)
    1b0a:	41 c7 46 8c 02 00 00 	movl   $0x2,-0x74(%r14)
    1b11:	00 
    1b12:	49 8b 82 c8 1e 00 00 	mov    0x1ec8(%r10),%rax
    1b19:	48 8b 50 10          	mov    0x10(%rax),%rdx
    1b1d:	48 69 f9 e0 3c 00 00 	imul   $0x3ce0,%rcx,%rdi
    1b24:	39 48 08             	cmp    %ecx,0x8(%rax)
    1b27:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    1b2d:	4c 0f 47 c7          	cmova  %rdi,%r8
    1b31:	c4 c1 78 10 84 10 b0 	vmovups 0x30b0(%r8,%rdx,1),%xmm0
    1b38:	30 00 00 
    1b3b:	c4 c1 78 11 86 48 ff 	vmovups %xmm0,-0xb8(%r14)
    1b42:	ff ff 
    1b44:	39 48 08             	cmp    %ecx,0x8(%rax)
    1b47:	48 0f 47 f7          	cmova  %rdi,%rsi
    1b4b:	48 8b 40 10          	mov    0x10(%rax),%rax
    1b4f:	c5 f8 10 84 06 30 33 	vmovups 0x3330(%rsi,%rax,1),%xmm0
    1b56:	00 00 
    1b58:	c4 c1 78 11 86 60 ff 	vmovups %xmm0,-0xa0(%r14)
    1b5f:	ff ff 
    1b61:	8b 8c 06 48 33 00 00 	mov    0x3348(%rsi,%rax,1),%ecx
    1b68:	48 8b 84 06 40 33 00 	mov    0x3340(%rsi,%rax,1),%rax
    1b6f:	00 
    1b70:	49 89 86 70 ff ff ff 	mov    %rax,-0x90(%r14)
    1b77:	41 89 8e 78 ff ff ff 	mov    %ecx,-0x88(%r14)
    1b7e:	e9 33 08 00 00       	jmp    23b6 <f_8001161d0+0x23b6>
    1b83:	48 8b b5 c8 1e 00 00 	mov    0x1ec8(%rbp),%rsi
    1b8a:	48 89 73 08          	mov    %rsi,0x8(%rbx)
    1b8e:	4c 89 5b 60          	mov    %r11,0x60(%rbx)
    1b92:	48 8b 04 24          	mov    (%rsp),%rax
    1b96:	0f b6 40 08          	movzbl 0x8(%rax),%eax
    1b9a:	48 89 43 68          	mov    %rax,0x68(%rbx)
    1b9e:	49 89 f8             	mov    %rdi,%r8
    1ba1:	48 8d 7e 08          	lea    0x8(%rsi),%rdi
    1ba5:	8b 56 08             	mov    0x8(%rsi),%edx
    1ba8:	4c 8b 4e 10          	mov    0x10(%rsi),%r9
    1bac:	48 83 c6 10          	add    $0x10,%rsi
    1bb0:	48 69 c8 e0 3c 00 00 	imul   $0x3ce0,%rax,%rcx
    1bb7:	45 31 d2             	xor    %r10d,%r10d
    1bba:	39 c2                	cmp    %eax,%edx
    1bbc:	4c 0f 47 d1          	cmova  %rcx,%r10
    1bc0:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
    1bc7:	00 
    1bc8:	4b 8b 94 11 40 3c 00 	mov    0x3c40(%r9,%r10,1),%rdx
    1bcf:	00 
    1bd0:	48 89 93 b0 00 00 00 	mov    %rdx,0xb0(%rbx)
    1bd7:	45 89 86 70 ff ff ff 	mov    %r8d,-0x90(%r14)
    1bde:	4d 89 9e 58 ff ff ff 	mov    %r11,-0xa8(%r14)
    1be5:	49 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r9
    1bec:	ff 7f 7f 
    1bef:	4d 89 8e 60 ff ff ff 	mov    %r9,-0xa0(%r14)
    1bf6:	49 c7 46 80 00 00 00 	movq   $0x0,-0x80(%r14)
    1bfd:	00 
    1bfe:	41 c6 46 88 00       	movb   $0x0,-0x78(%r14)
    1c03:	41 c7 46 8c 00 00 00 	movl   $0x0,-0x74(%r14)
    1c0a:	00 
    1c0b:	49 c7 86 18 ff ff ff 	movq   $0x0,-0xe8(%r14)
    1c12:	00 00 00 00 
    1c16:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    1c1b:	4d 89 86 20 ff ff ff 	mov    %r8,-0xe0(%r14)
    1c22:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1c26:	c4 c1 78 11 86 28 ff 	vmovups %xmm0,-0xd8(%r14)
    1c2d:	ff ff 
    1c2f:	49 c7 86 00 ff ff ff 	movq   $0x6,-0x100(%r14)
    1c36:	06 00 00 00 
    1c3a:	49 b8 10 00 00 00 03 	movabs $0x300000010,%r8
    1c41:	00 00 00 
    1c44:	49 83 c0 10          	add    $0x10,%r8
    1c48:	4d 89 86 d0 fe ff ff 	mov    %r8,-0x130(%r14)
    1c4f:	49 b8 00 00 00 00 01 	movabs $0x40000100000000,%r8
    1c56:	00 40 00 
    1c59:	4d 89 86 d8 fe ff ff 	mov    %r8,-0x128(%r14)
    1c60:	49 c7 86 e0 fe ff ff 	movq   $0xffff,-0x120(%r14)
    1c67:	ff ff 00 00 
    1c6b:	49 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%r15
    1c72:	ff ff ff 
    1c75:	4d 8d 47 09          	lea    0x9(%r15),%r8
    1c79:	4d 89 86 e8 fe ff ff 	mov    %r8,-0x118(%r14)
    1c80:	49 b8 00 00 00 00 01 	movabs $0x100000000,%r8
    1c87:	00 00 00 
    1c8a:	4d 89 86 f0 fe ff ff 	mov    %r8,-0x110(%r14)
    1c91:	4d 89 be f8 fe ff ff 	mov    %r15,-0x108(%r14)
    1c98:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    1c9d:	4d 89 86 74 ff ff ff 	mov    %r8,-0x8c(%r14)
    1ca4:	49 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r8
    1cab:	00 80 3f 
    1cae:	4d 89 86 08 ff ff ff 	mov    %r8,-0xf8(%r14)
    1cb5:	4d 89 86 10 ff ff ff 	mov    %r8,-0xf0(%r14)
    1cbc:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    1cc3:	00 00 00 
    1cc6:	4d 8d 84 24 bf 41 07 	lea    0x741bf(%r12),%r8
    1ccd:	00 
    1cce:	4c 89 43 78          	mov    %r8,0x78(%rbx)
    1cd2:	49 ba ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r10
    1cd9:	ff 7f ff 
    1cdc:	4c 89 93 80 00 00 00 	mov    %r10,0x80(%rbx)
    1ce3:	4d 89 96 68 ff ff ff 	mov    %r10,-0x98(%r14)
    1cea:	4d 89 8e 48 ff ff ff 	mov    %r9,-0xb8(%r14)
    1cf1:	4d 89 96 50 ff ff ff 	mov    %r10,-0xb0(%r14)
    1cf8:	49 c7 86 38 ff ff ff 	movq   $0x0,-0xc8(%r14)
    1cff:	00 00 00 00 
    1d03:	4d 89 86 40 ff ff ff 	mov    %r8,-0xc0(%r14)
    1d0a:	4c 8b 06             	mov    (%rsi),%r8
    1d0d:	45 31 c9             	xor    %r9d,%r9d
    1d10:	39 07                	cmp    %eax,(%rdi)
    1d12:	41 ba 00 00 00 00    	mov    $0x0,%r10d
    1d18:	4c 0f 47 d1          	cmova  %rcx,%r10
    1d1c:	c4 81 78 10 84 02 00 	vmovups 0x2e00(%r10,%r8,1),%xmm0
    1d23:	2e 00 00 
    1d26:	c4 c1 78 11 86 48 ff 	vmovups %xmm0,-0xb8(%r14)
    1d2d:	ff ff 
    1d2f:	39 07                	cmp    %eax,(%rdi)
    1d31:	48 8b 06             	mov    (%rsi),%rax
    1d34:	4c 0f 47 c9          	cmova  %rcx,%r9
    1d38:	49 8b 8c 01 80 30 00 	mov    0x3080(%r9,%rax,1),%rcx
    1d3f:	00 
    1d40:	48 89 13             	mov    %rdx,(%rbx)
    1d43:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
    1d4a:	00 
    1d4b:	49 8b 94 01 88 30 00 	mov    0x3088(%r9,%rax,1),%rdx
    1d52:	00 
    1d53:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    1d57:	49 89 8e 60 ff ff ff 	mov    %rcx,-0xa0(%r14)
    1d5e:	49 89 96 68 ff ff ff 	mov    %rdx,-0x98(%r14)
    1d65:	49 8b 8c 01 90 30 00 	mov    0x3090(%r9,%rax,1),%rcx
    1d6c:	00 
    1d6d:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    1d71:	41 8b 84 01 98 30 00 	mov    0x3098(%r9,%rax,1),%eax
    1d78:	00 
    1d79:	41 89 86 78 ff ff ff 	mov    %eax,-0x88(%r14)
    1d80:	49 8d 46 97          	lea    -0x69(%r14),%rax
    1d84:	48 89 43 40          	mov    %rax,0x40(%rbx)
    1d88:	49 89 8e 70 ff ff ff 	mov    %rcx,-0x90(%r14)
    1d8f:	49 8d 84 24 fa 85 50 	lea    -0x2af7a06(%r12),%rax
    1d96:	fd 
    1d97:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    1d9e:	48 89 df             	mov    %rbx,%rdi
    1da1:	c5 f8 77             	vzeroupper
    1da4:	e8 00 00 00 00       	call   1da9 <f_8001161d0+0x1da9>
    1da9:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    1db0:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    1db7:	49 89 46 80          	mov    %rax,-0x80(%r14)
    1dbb:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
    1dc2:	48 8b 88 04 16 00 00 	mov    0x1604(%rax),%rcx
    1dc9:	41 0f b6 56 9f       	movzbl -0x61(%r14),%edx
    1dce:	41 88 56 88          	mov    %dl,-0x78(%r14)
    1dd2:	49 89 8e ec fe ff ff 	mov    %rcx,-0x114(%r14)
    1dd9:	8b 80 0c 16 00 00    	mov    0x160c(%rax),%eax
    1ddf:	48 89 43 40          	mov    %rax,0x40(%rbx)
    1de3:	41 89 86 f4 fe ff ff 	mov    %eax,-0x10c(%r14)
    1dea:	41 c7 46 8c 02 00 00 	movl   $0x2,-0x74(%r14)
    1df1:	00 
    1df2:	e9 bf 05 00 00       	jmp    23b6 <f_8001161d0+0x23b6>
    1df7:	48 be 00 00 00 00 00 	movabs $0x60000000000000,%rsi
    1dfe:	00 60 00 
    1e01:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    1e08:	00 00 00 
    1e0b:	49 8d 8c 24 7d c9 09 	lea    0x9c97d(%r12),%rcx
    1e12:	00 
    1e13:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    1e1a:	ff ff ff 
    1e1d:	48 8d 42 12          	lea    0x12(%rdx),%rax
    1e21:	41 bf 80 00 00 00    	mov    $0x80,%r15d
    1e27:	e9 de 03 00 00       	jmp    220a <f_8001161d0+0x220a>
    1e2c:	48 8b 85 c8 1e 00 00 	mov    0x1ec8(%rbp),%rax
    1e33:	48 89 43 08          	mov    %rax,0x8(%rbx)
    1e37:	4c 89 5b 60          	mov    %r11,0x60(%rbx)
    1e3b:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
    1e42:	00 
    1e43:	48 8b 0c 24          	mov    (%rsp),%rcx
    1e47:	0f b6 51 08          	movzbl 0x8(%rcx),%edx
    1e4b:	48 89 53 68          	mov    %rdx,0x68(%rbx)
    1e4f:	49 89 f8             	mov    %rdi,%r8
    1e52:	8b 78 08             	mov    0x8(%rax),%edi
    1e55:	4c 8b 48 10          	mov    0x10(%rax),%r9
    1e59:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
    1e60:	00 
    1e61:	48 69 f2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rsi
    1e68:	31 c9                	xor    %ecx,%ecx
    1e6a:	39 d7                	cmp    %edx,%edi
    1e6c:	bf 00 00 00 00       	mov    $0x0,%edi
    1e71:	48 0f 47 fe          	cmova  %rsi,%rdi
    1e75:	49 8b bc 39 40 3c 00 	mov    0x3c40(%r9,%rdi,1),%rdi
    1e7c:	00 
    1e7d:	48 89 3b             	mov    %rdi,(%rbx)
    1e80:	45 89 86 70 ff ff ff 	mov    %r8d,-0x90(%r14)
    1e87:	4d 89 9e 58 ff ff ff 	mov    %r11,-0xa8(%r14)
    1e8e:	49 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r8
    1e95:	ff 7f 7f 
    1e98:	4d 89 86 60 ff ff ff 	mov    %r8,-0xa0(%r14)
    1e9f:	49 c7 46 80 00 00 00 	movq   $0x0,-0x80(%r14)
    1ea6:	00 
    1ea7:	41 c6 46 88 00       	movb   $0x0,-0x78(%r14)
    1eac:	41 c7 46 8c 00 00 00 	movl   $0x0,-0x74(%r14)
    1eb3:	00 
    1eb4:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1eb8:	c4 c1 78 11 86 28 ff 	vmovups %xmm0,-0xd8(%r14)
    1ebf:	ff ff 
    1ec1:	49 c7 86 d0 fe ff ff 	movq   $0x20,-0x130(%r14)
    1ec8:	20 00 00 00 
    1ecc:	48 bf 00 00 00 00 00 	movabs $0x42080000000000,%rdi
    1ed3:	08 42 00 
    1ed6:	49 89 be d8 fe ff ff 	mov    %rdi,-0x128(%r14)
    1edd:	49 c7 86 18 ff ff ff 	movq   $0x0,-0xe8(%r14)
    1ee4:	00 00 00 00 
    1ee8:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    1eed:	49 89 be 20 ff ff ff 	mov    %rdi,-0xe0(%r14)
    1ef4:	49 c7 86 00 ff ff ff 	movq   $0x7,-0x100(%r14)
    1efb:	07 00 00 00 
    1eff:	49 c7 86 e0 fe ff ff 	movq   $0xffff,-0x120(%r14)
    1f06:	ff ff 00 00 
    1f0a:	49 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%r9
    1f11:	ff ff ff 
    1f14:	49 8d 79 0a          	lea    0xa(%r9),%rdi
    1f18:	49 89 be e8 fe ff ff 	mov    %rdi,-0x118(%r14)
    1f1f:	48 bf 00 00 00 00 01 	movabs $0x100000000,%rdi
    1f26:	00 00 00 
    1f29:	49 89 be f0 fe ff ff 	mov    %rdi,-0x110(%r14)
    1f30:	4d 89 8e f8 fe ff ff 	mov    %r9,-0x108(%r14)
    1f37:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    1f3c:	49 89 be 74 ff ff ff 	mov    %rdi,-0x8c(%r14)
    1f43:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
    1f4a:	00 80 3f 
    1f4d:	49 89 be 08 ff ff ff 	mov    %rdi,-0xf8(%r14)
    1f54:	49 89 be 10 ff ff ff 	mov    %rdi,-0xf0(%r14)
    1f5b:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    1f62:	00 00 00 
    1f65:	49 8d bc 24 d5 5e 0b 	lea    0xb5ed5(%r12),%rdi
    1f6c:	00 
    1f6d:	48 89 7b 78          	mov    %rdi,0x78(%rbx)
    1f71:	49 b9 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r9
    1f78:	ff 7f ff 
    1f7b:	4c 89 8b 80 00 00 00 	mov    %r9,0x80(%rbx)
    1f82:	4d 89 8e 68 ff ff ff 	mov    %r9,-0x98(%r14)
    1f89:	4d 89 86 48 ff ff ff 	mov    %r8,-0xb8(%r14)
    1f90:	4d 89 8e 50 ff ff ff 	mov    %r9,-0xb0(%r14)
    1f97:	49 c7 86 38 ff ff ff 	movq   $0x0,-0xc8(%r14)
    1f9e:	00 00 00 00 
    1fa2:	49 89 be 40 ff ff ff 	mov    %rdi,-0xc0(%r14)
    1fa9:	48 8b 78 10          	mov    0x10(%rax),%rdi
    1fad:	39 50 08             	cmp    %edx,0x8(%rax)
    1fb0:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    1fb6:	4c 0f 47 c6          	cmova  %rsi,%r8
    1fba:	c4 c1 78 10 84 38 b0 	vmovups 0x30b0(%r8,%rdi,1),%xmm0
    1fc1:	30 00 00 
    1fc4:	c4 c1 78 11 86 48 ff 	vmovups %xmm0,-0xb8(%r14)
    1fcb:	ff ff 
    1fcd:	39 50 08             	cmp    %edx,0x8(%rax)
    1fd0:	48 0f 47 ce          	cmova  %rsi,%rcx
    1fd4:	48 8b 40 10          	mov    0x10(%rax),%rax
    1fd8:	48 8b 94 01 30 33 00 	mov    0x3330(%rcx,%rax,1),%rdx
    1fdf:	00 
    1fe0:	48 8b b4 01 38 33 00 	mov    0x3338(%rcx,%rax,1),%rsi
    1fe7:	00 
    1fe8:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    1fec:	49 89 96 60 ff ff ff 	mov    %rdx,-0xa0(%r14)
    1ff3:	49 89 b6 68 ff ff ff 	mov    %rsi,-0x98(%r14)
    1ffa:	48 8b 94 01 40 33 00 	mov    0x3340(%rcx,%rax,1),%rdx
    2001:	00 
    2002:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    2006:	8b 84 01 48 33 00 00 	mov    0x3348(%rcx,%rax,1),%eax
    200d:	41 89 86 78 ff ff ff 	mov    %eax,-0x88(%r14)
    2014:	49 8d 46 97          	lea    -0x69(%r14),%rax
    2018:	48 89 43 40          	mov    %rax,0x40(%rbx)
    201c:	49 89 96 70 ff ff ff 	mov    %rdx,-0x90(%r14)
    2023:	49 8d 84 24 82 87 50 	lea    -0x2af787e(%r12),%rax
    202a:	fd 
    202b:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    2032:	48 89 df             	mov    %rbx,%rdi
    2035:	c5 f8 77             	vzeroupper
    2038:	e8 00 00 00 00       	call   203d <f_8001161d0+0x203d>
    203d:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2044:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    204b:	49 89 46 80          	mov    %rax,-0x80(%r14)
    204f:	41 0f b6 46 9f       	movzbl -0x61(%r14),%eax
    2054:	41 88 46 88          	mov    %al,-0x78(%r14)
    2058:	41 c7 46 8c 02 00 00 	movl   $0x2,-0x74(%r14)
    205f:	00 
    2060:	e9 51 03 00 00       	jmp    23b6 <f_8001161d0+0x23b6>
    2065:	41 c6 46 88 00       	movb   $0x0,-0x78(%r14)
    206a:	49 c7 86 d0 fe ff ff 	movq   $0x1,-0x130(%r14)
    2071:	01 00 00 00 
    2075:	48 b8 00 00 00 00 00 	movabs $0x40000000000000,%rax
    207c:	00 40 00 
    207f:	49 89 86 d8 fe ff ff 	mov    %rax,-0x128(%r14)
    2086:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    208d:	00 
    208e:	49 c7 86 e0 fe ff ff 	movq   $0xffff,-0x120(%r14)
    2095:	ff ff 00 00 
    2099:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
    20a0:	ff ff ff 
    20a3:	48 8d 41 15          	lea    0x15(%rcx),%rax
    20a7:	49 89 86 e8 fe ff ff 	mov    %rax,-0x118(%r14)
    20ae:	49 c7 46 80 00 00 00 	movq   $0x0,-0x80(%r14)
    20b5:	00 
    20b6:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    20bd:	00 00 00 
    20c0:	49 89 86 f0 fe ff ff 	mov    %rax,-0x110(%r14)
    20c7:	49 89 8e f8 fe ff ff 	mov    %rcx,-0x108(%r14)
    20ce:	48 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rsi
    20d5:	00 80 3f 
    20d8:	48 89 73 70          	mov    %rsi,0x70(%rbx)
    20dc:	48 8d 40 ff          	lea    -0x1(%rax),%rax
    20e0:	49 89 86 00 ff ff ff 	mov    %rax,-0x100(%r14)
    20e7:	49 89 b6 08 ff ff ff 	mov    %rsi,-0xf8(%r14)
    20ee:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    20f5:	00 00 00 
    20f8:	49 8d 84 24 8c c9 09 	lea    0x9c98c(%r12),%rax
    20ff:	00 
    2100:	49 89 86 40 ff ff ff 	mov    %rax,-0xc0(%r14)
    2107:	48 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rax
    210e:	ff 7f 7f 
    2111:	49 89 86 48 ff ff ff 	mov    %rax,-0xb8(%r14)
    2118:	48 b9 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rcx
    211f:	ff 7f ff 
    2122:	49 89 8e 50 ff ff ff 	mov    %rcx,-0xb0(%r14)
    2129:	4d 89 9e 58 ff ff ff 	mov    %r11,-0xa8(%r14)
    2130:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    2135:	49 89 96 74 ff ff ff 	mov    %rdx,-0x8c(%r14)
    213c:	49 89 b6 10 ff ff ff 	mov    %rsi,-0xf0(%r14)
    2143:	49 c7 86 18 ff ff ff 	movq   $0x0,-0xe8(%r14)
    214a:	00 00 00 00 
    214e:	49 89 86 60 ff ff ff 	mov    %rax,-0xa0(%r14)
    2155:	49 89 8e 68 ff ff ff 	mov    %rcx,-0x98(%r14)
    215c:	49 c7 86 38 ff ff ff 	movq   $0x0,-0xc8(%r14)
    2163:	00 00 00 00 
    2167:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    216c:	49 89 86 20 ff ff ff 	mov    %rax,-0xe0(%r14)
    2173:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2177:	c4 c1 78 11 86 28 ff 	vmovups %xmm0,-0xd8(%r14)
    217e:	ff ff 
    2180:	48 c7 43 50 03 00 00 	movq   $0x3,0x50(%rbx)
    2187:	00 
    2188:	b8 03 00 00 00       	mov    $0x3,%eax
    218d:	e9 71 01 00 00       	jmp    2303 <f_8001161d0+0x2303>
    2192:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    2199:	00 
    219a:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    219f:	48 89 43 08          	mov    %rax,0x8(%rbx)
    21a3:	48 8b 04 24          	mov    (%rsp),%rax
    21a7:	48 89 43 10          	mov    %rax,0x10(%rbx)
    21ab:	49 81 c2 b0 1e 00 00 	add    $0x1eb0,%r10
    21b2:	4c 89 13             	mov    %r10,(%rbx)
    21b5:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    21bc:	00 00 00 
    21bf:	49 8d 84 24 3e 86 50 	lea    -0x2af79c2(%r12),%rax
    21c6:	fd 
    21c7:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    21ce:	48 89 df             	mov    %rbx,%rdi
    21d1:	c5 f8 77             	vzeroupper
    21d4:	e8 00 00 00 00       	call   21d9 <f_8001161d0+0x21d9>
    21d9:	e9 d8 01 00 00       	jmp    23b6 <f_8001161d0+0x23b6>
    21de:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    21e5:	00 00 00 
    21e8:	49 8d 8c 24 0b 2e 05 	lea    0x52e0b(%r12),%rcx
    21ef:	00 
    21f0:	41 bf 03 00 00 00    	mov    $0x3,%r15d
    21f6:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    21fd:	ff ff ff 
    2200:	48 be 00 00 00 00 00 	movabs $0x40000000000000,%rsi
    2207:	00 40 00 
    220a:	4c 89 43 78          	mov    %r8,0x78(%rbx)
    220e:	4d 89 be d0 fe ff ff 	mov    %r15,-0x130(%r14)
    2215:	49 89 b6 d8 fe ff ff 	mov    %rsi,-0x128(%r14)
    221c:	49 c7 86 e0 fe ff ff 	movq   $0xffff,-0x120(%r14)
    2223:	ff ff 00 00 
    2227:	49 89 86 e8 fe ff ff 	mov    %rax,-0x118(%r14)
    222e:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2235:	00 00 00 
    2238:	49 89 86 f0 fe ff ff 	mov    %rax,-0x110(%r14)
    223f:	49 89 96 f8 fe ff ff 	mov    %rdx,-0x108(%r14)
    2246:	48 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rsi
    224d:	00 80 3f 
    2250:	48 89 73 70          	mov    %rsi,0x70(%rbx)
    2254:	48 ff c8             	dec    %rax
    2257:	49 89 86 00 ff ff ff 	mov    %rax,-0x100(%r14)
    225e:	49 89 b6 08 ff ff ff 	mov    %rsi,-0xf8(%r14)
    2265:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
    2269:	49 89 8e 40 ff ff ff 	mov    %rcx,-0xc0(%r14)
    2270:	48 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rax
    2277:	ff 7f 7f 
    227a:	49 89 86 48 ff ff ff 	mov    %rax,-0xb8(%r14)
    2281:	41 c6 46 88 00       	movb   $0x0,-0x78(%r14)
    2286:	49 c7 46 80 00 00 00 	movq   $0x0,-0x80(%r14)
    228d:	00 
    228e:	48 b9 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rcx
    2295:	ff 7f ff 
    2298:	49 89 8e 50 ff ff ff 	mov    %rcx,-0xb0(%r14)
    229f:	4d 89 9e 58 ff ff ff 	mov    %r11,-0xa8(%r14)
    22a6:	49 89 b6 10 ff ff ff 	mov    %rsi,-0xf0(%r14)
    22ad:	49 c7 86 18 ff ff ff 	movq   $0x0,-0xe8(%r14)
    22b4:	00 00 00 00 
    22b8:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    22bd:	49 89 b6 74 ff ff ff 	mov    %rsi,-0x8c(%r14)
    22c4:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    22c9:	49 89 b6 20 ff ff ff 	mov    %rsi,-0xe0(%r14)
    22d0:	49 c7 86 28 ff ff ff 	movq   $0x0,-0xd8(%r14)
    22d7:	00 00 00 00 
    22db:	48 c7 43 50 02 00 00 	movq   $0x2,0x50(%rbx)
    22e2:	00 
    22e3:	49 89 86 60 ff ff ff 	mov    %rax,-0xa0(%r14)
    22ea:	49 89 8e 68 ff ff ff 	mov    %rcx,-0x98(%r14)
    22f1:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    22f5:	c4 c1 78 11 86 30 ff 	vmovups %xmm0,-0xd0(%r14)
    22fc:	ff ff 
    22fe:	b8 02 00 00 00       	mov    $0x2,%eax
    2303:	41 89 be 70 ff ff ff 	mov    %edi,-0x90(%r14)
    230a:	41 89 46 8c          	mov    %eax,-0x74(%r14)
    230e:	49 8b 82 c8 1e 00 00 	mov    0x1ec8(%r10),%rax
    2315:	48 8b 0c 24          	mov    (%rsp),%rcx
    2319:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
    231d:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2321:	48 69 f1 e0 3c 00 00 	imul   $0x3ce0,%rcx,%rsi
    2328:	31 ff                	xor    %edi,%edi
    232a:	39 48 08             	cmp    %ecx,0x8(%rax)
    232d:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    2333:	4c 0f 47 c6          	cmova  %rsi,%r8
    2337:	4d 8b 8c 10 08 2e 00 	mov    0x2e08(%r8,%rdx,1),%r9
    233e:	00 
    233f:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    2343:	49 8b 94 10 00 2e 00 	mov    0x2e00(%r8,%rdx,1),%rdx
    234a:	00 
    234b:	49 89 96 48 ff ff ff 	mov    %rdx,-0xb8(%r14)
    2352:	4d 89 8e 50 ff ff ff 	mov    %r9,-0xb0(%r14)
    2359:	48 8b 50 10          	mov    0x10(%rax),%rdx
    235d:	39 48 08             	cmp    %ecx,0x8(%rax)
    2360:	48 0f 47 fe          	cmova  %rsi,%rdi
    2364:	c5 f8 10 84 17 80 30 	vmovups 0x3080(%rdi,%rdx,1),%xmm0
    236b:	00 00 
    236d:	c4 c1 78 11 86 60 ff 	vmovups %xmm0,-0xa0(%r14)
    2374:	ff ff 
    2376:	8b 8c 17 98 30 00 00 	mov    0x3098(%rdi,%rdx,1),%ecx
    237d:	48 8b 94 17 90 30 00 	mov    0x3090(%rdi,%rdx,1),%rdx
    2384:	00 
    2385:	49 89 96 70 ff ff ff 	mov    %rdx,-0x90(%r14)
    238c:	41 89 8e 78 ff ff ff 	mov    %ecx,-0x88(%r14)
    2393:	0f b6 48 20          	movzbl 0x20(%rax),%ecx
    2397:	8b 40 24             	mov    0x24(%rax),%eax
    239a:	48 89 43 40          	mov    %rax,0x40(%rbx)
    239e:	41 c7 46 84 00 00 00 	movl   $0x0,-0x7c(%r14)
    23a5:	00 
    23a6:	41 c7 46 81 00 00 00 	movl   $0x0,-0x7f(%r14)
    23ad:	00 
    23ae:	41 88 4e 80          	mov    %cl,-0x80(%r14)
    23b2:	41 88 46 88          	mov    %al,-0x78(%r14)
    23b6:	48 8b b3 b8 00 00 00 	mov    0xb8(%rbx),%rsi
    23bd:	41 8b 86 d0 fe ff ff 	mov    -0x130(%r14),%eax
    23c4:	48 89 43 50          	mov    %rax,0x50(%rbx)
    23c8:	48 8d 4e 1c          	lea    0x1c(%rsi),%rcx
    23cc:	8b 56 1c             	mov    0x1c(%rsi),%edx
    23cf:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    23d3:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    23d7:	41 89 96 18 ff ff ff 	mov    %edx,-0xe8(%r14)
    23de:	48 8d 7e 2c          	lea    0x2c(%rsi),%rdi
    23e2:	44 8b 46 2c          	mov    0x2c(%rsi),%r8d
    23e6:	48 89 bb b0 00 00 00 	mov    %rdi,0xb0(%rbx)
    23ed:	4c 89 43 60          	mov    %r8,0x60(%rbx)
    23f1:	8b 76 14             	mov    0x14(%rsi),%esi
    23f4:	21 c6                	and    %eax,%esi
    23f6:	40 0f 95 c6          	setne  %sil
    23fa:	45 85 c0             	test   %r8d,%r8d
    23fd:	40 0f 9f c7          	setg   %dil
    2401:	40 20 f7             	and    %sil,%dil
    2404:	40 0f b6 f7          	movzbl %dil,%esi
    2408:	48 89 73 58          	mov    %rsi,0x58(%rbx)
    240c:	40 84 f6             	test   %sil,%sil
    240f:	0f 84 53 01 00 00    	je     2568 <f_8001161d0+0x2568>
    2415:	48 8b bb a0 00 00 00 	mov    0xa0(%rbx),%rdi
    241c:	4c 8b 83 a8 00 00 00 	mov    0xa8(%rbx),%r8
    2423:	48 8d b7 40 01 00 00 	lea    0x140(%rdi),%rsi
    242a:	48 89 b3 c0 00 00 00 	mov    %rsi,0xc0(%rbx)
    2431:	44 89 c6             	mov    %r8d,%esi
    2434:	4d 63 c0             	movslq %r8d,%r8
    2437:	49 c1 f8 1f          	sar    $0x1f,%r8
    243b:	49 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%r9
    2442:	ff ff ff 
    2445:	4d 21 c8             	and    %r9,%r8
    2448:	49 09 f0             	or     %rsi,%r8
    244b:	4c 89 83 c8 00 00 00 	mov    %r8,0xc8(%rbx)
    2452:	42 0f b6 bc 07 40 01 	movzbl 0x140(%rdi,%r8,1),%edi
    2459:	00 00 
    245b:	48 89 7b 58          	mov    %rdi,0x58(%rbx)
    245f:	40 f6 c7 01          	test   $0x1,%dil
    2463:	0f 84 ff 00 00 00    	je     2568 <f_8001161d0+0x2568>
    2469:	41 0f b6 be dc fe ff 	movzbl -0x124(%r14),%edi
    2470:	ff 
    2471:	48 89 7b 58          	mov    %rdi,0x58(%rbx)
    2475:	40 f6 c7 01          	test   $0x1,%dil
    2479:	74 09                	je     2484 <f_8001161d0+0x2484>
    247b:	48 09 c2             	or     %rax,%rdx
    247e:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    2482:	89 11                	mov    %edx,(%rcx)
    2484:	48 c7 43 40 d0 00 00 	movq   $0xd0,0x40(%rbx)
    248b:	00 
    248c:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
    2491:	48 89 43 08          	mov    %rax,0x8(%rbx)
    2495:	48 63 c6             	movslq %esi,%rax
    2498:	48 69 c0 d0 00 00 00 	imul   $0xd0,%rax,%rax
    249f:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    24a6:	48 8d 14 01          	lea    (%rcx,%rax,1),%rdx
    24aa:	48 89 93 d0 00 00 00 	mov    %rdx,0xd0(%rbx)
    24b1:	48 c7 43 10 c0 00 00 	movq   $0xc0,0x10(%rbx)
    24b8:	00 
    24b9:	48 8d 84 01 40 0d 00 	lea    0xd40(%rcx,%rax,1),%rax
    24c0:	00 
    24c1:	48 89 83 a8 00 00 00 	mov    %rax,0xa8(%rbx)
    24c8:	48 89 03             	mov    %rax,(%rbx)
    24cb:	49 8d 84 24 7e 8c 50 	lea    -0x2af7382(%r12),%rax
    24d2:	fd 
    24d3:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    24da:	48 89 df             	mov    %rbx,%rdi
    24dd:	c5 f8 77             	vzeroupper
    24e0:	e8 00 00 00 00       	call   24e5 <f_8001161d0+0x24e5>
    24e5:	48 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%rax
    24ec:	80 88 38 0d 00 00 01 	orb    $0x1,0xd38(%rax)
    24f3:	48 8b bb a0 00 00 00 	mov    0xa0(%rbx),%rdi
    24fa:	0f b6 87 81 3a 00 00 	movzbl 0x3a81(%rdi),%eax
    2501:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2505:	a8 40                	test   $0x40,%al
    2507:	74 5f                	je     2568 <f_8001161d0+0x2568>
    2509:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2510:	48 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%rcx
    2517:	0f b6 04 01          	movzbl (%rcx,%rax,1),%eax
    251b:	48 89 43 40          	mov    %rax,0x40(%rbx)
    251f:	a8 02                	test   $0x2,%al
    2521:	74 45                	je     2568 <f_8001161d0+0x2568>
    2523:	48 8b 87 60 3b 00 00 	mov    0x3b60(%rdi),%rax
    252a:	48 89 43 40          	mov    %rax,0x40(%rbx)
    252e:	48 85 c0             	test   %rax,%rax
    2531:	74 35                	je     2568 <f_8001161d0+0x2568>
    2533:	0f b6 87 85 3a 00 00 	movzbl 0x3a85(%rdi),%eax
    253a:	48 89 43 40          	mov    %rax,0x40(%rbx)
    253e:	a8 02                	test   $0x2,%al
    2540:	74 26                	je     2568 <f_8001161d0+0x2568>
    2542:	48 8b 83 a8 00 00 00 	mov    0xa8(%rbx),%rax
    2549:	48 8b 8b b8 00 00 00 	mov    0xb8(%rbx),%rcx
    2550:	8b 00                	mov    (%rax),%eax
    2552:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2556:	8b 49 10             	mov    0x10(%rcx),%ecx
    2559:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    255d:	c4 e2 70 f2 c0       	andn   %eax,%ecx,%eax
    2562:	0f 84 88 02 00 00    	je     27f0 <f_8001161d0+0x27f0>
    2568:	49 8b 46 f0          	mov    -0x10(%r14),%rax
    256c:	49 8b 4e f8          	mov    -0x8(%r14),%rcx
    2570:	48 89 83 a0 00 00 00 	mov    %rax,0xa0(%rbx)
    2577:	48 89 8b 98 00 00 00 	mov    %rcx,0x98(%rbx)
    257e:	49 8b 46 e0          	mov    -0x20(%r14),%rax
    2582:	49 8b 4e e8          	mov    -0x18(%r14),%rcx
    2586:	48 89 83 b0 00 00 00 	mov    %rax,0xb0(%rbx)
    258d:	48 89 8b a8 00 00 00 	mov    %rcx,0xa8(%rbx)
    2594:	49 8b 46 d0          	mov    -0x30(%r14),%rax
    2598:	49 8b 4e d8          	mov    -0x28(%r14),%rcx
    259c:	48 89 83 c0 00 00 00 	mov    %rax,0xc0(%rbx)
    25a3:	48 89 8b b8 00 00 00 	mov    %rcx,0xb8(%rbx)
    25aa:	49 8b 46 c0          	mov    -0x40(%r14),%rax
    25ae:	49 8b 4e c8          	mov    -0x38(%r14),%rcx
    25b2:	48 89 83 d0 00 00 00 	mov    %rax,0xd0(%rbx)
    25b9:	48 89 8b c8 00 00 00 	mov    %rcx,0xc8(%rbx)
    25c0:	49 8b 46 b0          	mov    -0x50(%r14),%rax
    25c4:	49 8b 4e b8          	mov    -0x48(%r14),%rcx
    25c8:	48 89 83 e0 00 00 00 	mov    %rax,0xe0(%rbx)
    25cf:	48 89 8b d8 00 00 00 	mov    %rcx,0xd8(%rbx)
    25d6:	c4 c1 78 10 46 a0    	vmovups -0x60(%r14),%xmm0
    25dc:	c5 f8 11 83 e8 00 00 	vmovups %xmm0,0xe8(%rbx)
    25e3:	00 
    25e4:	4c 89 b3 00 01 00 00 	mov    %r14,0x100(%rbx)
    25eb:	48 83 c4 38          	add    $0x38,%rsp
    25ef:	5b                   	pop    %rbx
    25f0:	41 5c                	pop    %r12
    25f2:	41 5d                	pop    %r13
    25f4:	41 5e                	pop    %r14
    25f6:	41 5f                	pop    %r15
    25f8:	5d                   	pop    %rbp
    25f9:	c5 f8 77             	vzeroupper
    25fc:	c3                   	ret
    25fd:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    2604:	00 00 00 
    2607:	49 8d 4c 24 e9       	lea    -0x17(%r12),%rcx
    260c:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    2613:	ff ff ff 
    2616:	48 8d 42 0e          	lea    0xe(%rdx),%rax
    261a:	41 bf 00 04 00 00    	mov    $0x400,%r15d
    2620:	31 f6                	xor    %esi,%esi
    2622:	49 89 c0             	mov    %rax,%r8
    2625:	49 89 ea             	mov    %rbp,%r10
    2628:	e9 dd fb ff ff       	jmp    220a <f_8001161d0+0x220a>
    262d:	49 89 ef             	mov    %rbp,%r15
    2630:	49 8b 82 c8 1e 00 00 	mov    0x1ec8(%r10),%rax
    2637:	48 89 83 b0 00 00 00 	mov    %rax,0xb0(%rbx)
    263e:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
    2645:	ff ff ff 
    2648:	48 8d 41 1a          	lea    0x1a(%rcx),%rax
    264c:	48 89 43 70          	mov    %rax,0x70(%rbx)
    2650:	41 c6 46 88 00       	movb   $0x0,-0x78(%r14)
    2655:	49 c7 86 d0 fe ff ff 	movq   $0x2000,-0x130(%r14)
    265c:	00 20 00 00 
    2660:	49 c7 86 d8 fe ff ff 	movq   $0x0,-0x128(%r14)
    2667:	00 00 00 00 
    266b:	49 c7 86 e0 fe ff ff 	movq   $0xffff,-0x120(%r14)
    2672:	ff ff 00 00 
    2676:	49 89 86 e8 fe ff ff 	mov    %rax,-0x118(%r14)
    267d:	48 8b 04 24          	mov    (%rsp),%rax
    2681:	48 89 43 08          	mov    %rax,0x8(%rbx)
    2685:	49 c7 46 80 00 00 00 	movq   $0x0,-0x80(%r14)
    268c:	00 
    268d:	41 89 be 70 ff ff ff 	mov    %edi,-0x90(%r14)
    2694:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    269b:	00 00 00 
    269e:	49 89 86 f0 fe ff ff 	mov    %rax,-0x110(%r14)
    26a5:	49 89 8e f8 fe ff ff 	mov    %rcx,-0x108(%r14)
    26ac:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
    26b3:	00 80 3f 
    26b6:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    26ba:	48 8d 40 ff          	lea    -0x1(%rax),%rax
    26be:	49 89 86 00 ff ff ff 	mov    %rax,-0x100(%r14)
    26c5:	49 89 be 08 ff ff ff 	mov    %rdi,-0xf8(%r14)
    26cc:	48 b9 ba e3 c0 02 08 	movabs $0x802c0e3ba,%rcx
    26d3:	00 00 00 
    26d6:	48 8d 81 a5 cd 08 00 	lea    0x8cda5(%rcx),%rax
    26dd:	49 89 86 40 ff ff ff 	mov    %rax,-0xc0(%r14)
    26e4:	48 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rax
    26eb:	ff 7f 7f 
    26ee:	49 89 86 48 ff ff ff 	mov    %rax,-0xb8(%r14)
    26f5:	48 ba ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdx
    26fc:	ff 7f ff 
    26ff:	49 89 96 50 ff ff ff 	mov    %rdx,-0xb0(%r14)
    2706:	4d 89 9e 58 ff ff ff 	mov    %r11,-0xa8(%r14)
    270d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    2712:	48 89 73 60          	mov    %rsi,0x60(%rbx)
    2716:	49 89 b6 74 ff ff ff 	mov    %rsi,-0x8c(%r14)
    271d:	49 89 86 60 ff ff ff 	mov    %rax,-0xa0(%r14)
    2724:	49 89 96 68 ff ff ff 	mov    %rdx,-0x98(%r14)
    272b:	48 c7 43 50 b0 1e 00 	movq   $0x1eb0,0x50(%rbx)
    2732:	00 
    2733:	49 81 c2 b0 1e 00 00 	add    $0x1eb0,%r10
    273a:	4c 89 13             	mov    %r10,(%rbx)
    273d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2742:	49 89 86 20 ff ff ff 	mov    %rax,-0xe0(%r14)
    2749:	49 c7 86 28 ff ff ff 	movq   $0x0,-0xd8(%r14)
    2750:	00 00 00 00 
    2754:	48 c7 43 48 03 00 00 	movq   $0x3,0x48(%rbx)
    275b:	00 
    275c:	41 c7 46 8c 03 00 00 	movl   $0x3,-0x74(%r14)
    2763:	00 
    2764:	49 89 be 10 ff ff ff 	mov    %rdi,-0xf0(%r14)
    276b:	49 c7 86 18 ff ff ff 	movq   $0x0,-0xe8(%r14)
    2772:	00 00 00 00 
    2776:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    277a:	c4 c1 78 11 86 30 ff 	vmovups %xmm0,-0xd0(%r14)
    2781:	ff ff 
    2783:	48 8d 81 a2 8e 50 fd 	lea    -0x2af715e(%rcx),%rax
    278a:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    2791:	48 89 df             	mov    %rbx,%rdi
    2794:	c5 f8 77             	vzeroupper
    2797:	e8 00 00 00 00       	call   279c <f_8001161d0+0x279c>
    279c:	48 8b 33             	mov    (%rbx),%rsi
    279f:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    27a6:	0f b6 50 08          	movzbl 0x8(%rax),%edx
    27aa:	48 89 53 40          	mov    %rdx,0x40(%rbx)
    27ae:	48 8b 8b b0 00 00 00 	mov    0xb0(%rbx),%rcx
    27b5:	48 69 c2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rax
    27bc:	31 ff                	xor    %edi,%edi
    27be:	39 51 08             	cmp    %edx,0x8(%rcx)
    27c1:	48 0f 47 f8          	cmova  %rax,%rdi
    27c5:	48 03 79 10          	add    0x10(%rcx),%rdi
    27c9:	40 f6 c6 01          	test   $0x1,%sil
    27cd:	0f 85 15 03 00 00    	jne    2ae8 <f_8001161d0+0x2ae8>
    27d3:	41 b8 5c 00 00 00    	mov    $0x5c,%r8d
    27d9:	41 b9 58 00 00 00    	mov    $0x58,%r9d
    27df:	41 ba 54 00 00 00    	mov    $0x54,%r10d
    27e5:	41 bb 50 00 00 00    	mov    $0x50,%r11d
    27eb:	e9 14 03 00 00       	jmp    2b04 <f_8001161d0+0x2b04>
    27f0:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
    27f7:	8b 08                	mov    (%rax),%ecx
    27f9:	44 8b 87 90 3b 00 00 	mov    0x3b90(%rdi),%r8d
    2800:	44 8b 8f 94 3b 00 00 	mov    0x3b94(%rdi),%r9d
    2807:	41 83 f8 01          	cmp    $0x1,%r8d
    280b:	44 89 c6             	mov    %r8d,%esi
    280e:	83 d6 00             	adc    $0x0,%esi
    2811:	89 c8                	mov    %ecx,%eax
    2813:	31 d2                	xor    %edx,%edx
    2815:	f7 f6                	div    %esi
    2817:	89 c6                	mov    %eax,%esi
    2819:	45 85 c0             	test   %r8d,%r8d
    281c:	41 0f 44 f0          	cmove  %r8d,%esi
    2820:	4c 89 4b 48          	mov    %r9,0x48(%rbx)
    2824:	44 39 ce             	cmp    %r9d,%esi
    2827:	41 0f 4d f1          	cmovge %r9d,%esi
    282b:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    282f:	85 f6                	test   %esi,%esi
    2831:	0f 84 31 fd ff ff    	je     2568 <f_8001161d0+0x2568>
    2837:	48 89 8b 88 00 00 00 	mov    %rcx,0x88(%rbx)
    283e:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2845:	00 00 00 
    2848:	01 f0                	add    %esi,%eax
    284a:	ff c8                	dec    %eax
    284c:	48 89 43 48          	mov    %rax,0x48(%rbx)
    2850:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
    2854:	85 f6                	test   %esi,%esi
    2856:	0f 8e 0c fd ff ff    	jle    2568 <f_8001161d0+0x2568>
    285c:	48 8d 43 50          	lea    0x50(%rbx),%rax
    2860:	48 8d 97 80 3b 00 00 	lea    0x3b80(%rdi),%rdx
    2867:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    286b:	c5 f8 29 00          	vmovaps %xmm0,(%rax)
    286f:	48 89 53 70          	mov    %rdx,0x70(%rbx)
    2873:	48 c7 43 78 28 00 00 	movq   $0x28,0x78(%rbx)
    287a:	00 
    287b:	48 c7 83 80 00 00 00 	movq   $0x3dcccccd,0x80(%rbx)
    2882:	cd cc cc 3d 
    2886:	89 c8                	mov    %ecx,%eax
    2888:	99                   	cltd
    2889:	f7 fe                	idiv   %esi
    288b:	48 89 53 60          	mov    %rdx,0x60(%rbx)
    288f:	48 81 c7 78 3b 00 00 	add    $0x3b78,%rdi
    2896:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    289a:	48 89 83 88 00 00 00 	mov    %rax,0x88(%rbx)
    28a1:	31 c9                	xor    %ecx,%ecx
    28a3:	48 ba 00 00 00 00 f8 	movabs $0xfffffff800000000,%rdx
    28aa:	ff ff ff 
    28ad:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    28b1:	c5 fa 10 0d 00 00 00 	vmovss 0x0(%rip),%xmm1        # 28b9 <f_8001161d0+0x28b9>
    28b8:	00 
    28b9:	be ff ff ff ff       	mov    $0xffffffff,%esi
    28be:	eb 23                	jmp    28e3 <f_8001161d0+0x28e3>
    28c0:	8b 43 50             	mov    0x50(%rbx),%eax
    28c3:	8b 7b 58             	mov    0x58(%rbx),%edi
    28c6:	ff c0                	inc    %eax
    28c8:	48 89 43 50          	mov    %rax,0x50(%rbx)
    28cc:	03 bb 88 00 00 00    	add    0x88(%rbx),%edi
    28d2:	48 89 7b 58          	mov    %rdi,0x58(%rbx)
    28d6:	3b 43 40             	cmp    0x40(%rbx),%eax
    28d9:	0f 84 89 fc ff ff    	je     2568 <f_8001161d0+0x2568>
    28df:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
    28e3:	8b 07                	mov    (%rdi),%eax
    28e5:	48 89 83 30 01 00 00 	mov    %rax,0x130(%rbx)
    28ec:	48 89 83 90 00 00 00 	mov    %rax,0x90(%rbx)
    28f3:	44 8d 40 01          	lea    0x1(%rax),%r8d
    28f7:	48 c7 83 28 01 00 00 	movq   $0xffffffffffffffff,0x128(%rbx)
    28fe:	ff ff ff ff 
    2902:	f0 44 0f b1 07       	lock cmpxchg %r8d,(%rdi)
    2907:	75 d6                	jne    28df <f_8001161d0+0x28df>
    2909:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
    2910:	44 8b 90 68 3b 00 00 	mov    0x3b68(%rax),%r10d
    2917:	8b 7b 50             	mov    0x50(%rbx),%edi
    291a:	3b 7b 48             	cmp    0x48(%rbx),%edi
    291d:	8b 7b 60             	mov    0x60(%rbx),%edi
    2920:	48 0f 45 f9          	cmovne %rcx,%rdi
    2924:	4c 8b 88 70 3b 00 00 	mov    0x3b70(%rax),%r9
    292b:	4c 89 0b             	mov    %r9,(%rbx)
    292e:	4c 8b 83 90 00 00 00 	mov    0x90(%rbx),%r8
    2935:	b8 00 00 00 00       	mov    $0x0,%eax
    293a:	45 39 c2             	cmp    %r8d,%r10d
    293d:	76 1a                	jbe    2959 <f_8001161d0+0x2959>
    293f:	45 89 c0             	mov    %r8d,%r8d
    2942:	49 63 c0             	movslq %r8d,%rax
    2945:	48 c1 f8 1f          	sar    $0x1f,%rax
    2949:	49 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%r10
    2950:	ff ff ff 
    2953:	4c 21 d0             	and    %r10,%rax
    2956:	4c 09 c0             	or     %r8,%rax
    2959:	48 89 43 08          	mov    %rax,0x8(%rbx)
    295d:	48 03 bb 88 00 00 00 	add    0x88(%rbx),%rdi
    2964:	41 89 f8             	mov    %edi,%r8d
    2967:	4c 89 83 88 00 00 00 	mov    %r8,0x88(%rbx)
    296e:	48 98                	cltq
    2970:	4c 63 53 78          	movslq 0x78(%rbx),%r10
    2974:	4c 0f af d0          	imul   %rax,%r10
    2978:	4b 8d 04 0a          	lea    (%r10,%r9,1),%rax
    297c:	48 89 83 90 00 00 00 	mov    %rax,0x90(%rbx)
    2983:	44 8b 5b 58          	mov    0x58(%rbx),%r11d
    2987:	49 89 ff             	mov    %rdi,%r15
    298a:	49 c1 e7 20          	shl    $0x20,%r15
    298e:	4d 09 df             	or     %r11,%r15
    2991:	4c 8b 9b 98 00 00 00 	mov    0x98(%rbx),%r11
    2998:	4f 89 1c 0a          	mov    %r11,(%r10,%r9,1)
    299c:	4c 8b 9b b8 00 00 00 	mov    0xb8(%rbx),%r11
    29a3:	4f 89 5c 0a 08       	mov    %r11,0x8(%r10,%r9,1)
    29a8:	4c 8b 9b a8 00 00 00 	mov    0xa8(%rbx),%r11
    29af:	4f 89 5c 0a 10       	mov    %r11,0x10(%r10,%r9,1)
    29b4:	4f 89 7c 0a 18       	mov    %r15,0x18(%r10,%r9,1)
    29b9:	45 8b 8b bc 00 00 00 	mov    0xbc(%r11),%r9d
    29c0:	41 83 f9 01          	cmp    $0x1,%r9d
    29c4:	74 5b                	je     2a21 <f_8001161d0+0x2a21>
    29c6:	41 83 f9 02          	cmp    $0x2,%r9d
    29ca:	75 70                	jne    2a3c <f_8001161d0+0x2a3c>
    29cc:	c5 82 2a d7          	vcvtsi2ss %edi,%xmm15,%xmm2
    29d0:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
    29d7:	41 89 f8             	mov    %edi,%r8d
    29da:	4c 89 83 10 02 00 00 	mov    %r8,0x210(%rbx)
    29e1:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    29e8:	00 00 00 00 
    29ec:	c5 f9 6e df          	vmovd  %edi,%xmm3
    29f0:	c5 ea 59 d3          	vmulss %xmm3,%xmm2,%xmm2
    29f4:	c5 f9 7e d7          	vmovd  %xmm2,%edi
    29f8:	48 89 bb 00 02 00 00 	mov    %rdi,0x200(%rbx)
    29ff:	c4 61 fa 2c c2       	vcvttss2si %xmm2,%r8
    2a04:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    2a0b:	00 00 00 00 
    2a0f:	c5 f8 2e d0          	vucomiss %xmm0,%xmm2
    2a13:	44 0f 42 c1          	cmovb  %ecx,%r8d
    2a17:	c5 f8 2e d1          	vucomiss %xmm1,%xmm2
    2a1b:	44 0f 47 c6          	cmova  %esi,%r8d
    2a1f:	eb 2b                	jmp    2a4c <f_8001161d0+0x2a4c>
    2a21:	41 89 f8             	mov    %edi,%r8d
    2a24:	41 c1 e8 1f          	shr    $0x1f,%r8d
    2a28:	41 01 f8             	add    %edi,%r8d
    2a2b:	44 89 c7             	mov    %r8d,%edi
    2a2e:	d1 ef                	shr    $1,%edi
    2a30:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
    2a37:	41 09 f8             	or     %edi,%r8d
    2a3a:	eb 10                	jmp    2a4c <f_8001161d0+0x2a4c>
    2a3c:	4c 89 43 10          	mov    %r8,0x10(%rbx)
    2a40:	41 83 f9 03          	cmp    $0x3,%r9d
    2a44:	75 0a                	jne    2a50 <f_8001161d0+0x2a50>
    2a46:	01 ff                	add    %edi,%edi
    2a48:	44 8d 04 bf          	lea    (%rdi,%rdi,4),%r8d
    2a4c:	4c 89 43 10          	mov    %r8,0x10(%rbx)
    2a50:	44 89 40 20          	mov    %r8d,0x20(%rax)
    2a54:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    2a5b:	00 00 00 00 00 
    2a60:	48 8b 7b 70          	mov    0x70(%rbx),%rdi
    2a64:	8b 07                	mov    (%rdi),%eax
    2a66:	48 89 83 30 01 00 00 	mov    %rax,0x130(%rbx)
    2a6d:	48 89 03             	mov    %rax,(%rbx)
    2a70:	44 8d 40 01          	lea    0x1(%rax),%r8d
    2a74:	48 c7 83 28 01 00 00 	movq   $0xffffffffffffffff,0x128(%rbx)
    2a7b:	ff ff ff ff 
    2a7f:	45 31 c9             	xor    %r9d,%r9d
    2a82:	f0 44 0f b1 07       	lock cmpxchg %r8d,(%rdi)
    2a87:	41 0f 95 c1          	setne  %r9b
    2a8b:	4c 89 4b 10          	mov    %r9,0x10(%rbx)
    2a8f:	75 cf                	jne    2a60 <f_8001161d0+0x2a60>
    2a91:	48 8b 03             	mov    (%rbx),%rax
    2a94:	48 8b bb a0 00 00 00 	mov    0xa0(%rbx),%rdi
    2a9b:	44 8b 87 84 3b 00 00 	mov    0x3b84(%rdi),%r8d
    2aa2:	4c 89 43 08          	mov    %r8,0x8(%rbx)
    2aa6:	41 39 c0             	cmp    %eax,%r8d
    2aa9:	0f 8e 11 fe ff ff    	jle    28c0 <f_8001161d0+0x28c0>
    2aaf:	48 8b bf 88 3b 00 00 	mov    0x3b88(%rdi),%rdi
    2ab6:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    2aba:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    2ac1:	00 
    2ac2:	48 98                	cltq
    2ac4:	48 21 d0             	and    %rdx,%rax
    2ac7:	4d 8d 8c 24 3e 1c 3f 	lea    -0x2c0e3c2(%r12),%r9
    2ace:	fd 
    2acf:	4d 21 c1             	and    %r8,%r9
    2ad2:	49 09 c1             	or     %rax,%r9
    2ad5:	4c 89 0b             	mov    %r9,(%rbx)
    2ad8:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
    2adf:	4a 89 04 0f          	mov    %rax,(%rdi,%r9,1)
    2ae3:	e9 d8 fd ff ff       	jmp    28c0 <f_8001161d0+0x28c0>
    2ae8:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    2aec:	41 b8 0c 2e 00 00    	mov    $0x2e0c,%r8d
    2af2:	41 b9 08 2e 00 00    	mov    $0x2e08,%r9d
    2af8:	41 ba 04 2e 00 00    	mov    $0x2e04,%r10d
    2afe:	41 bb 00 2e 00 00    	mov    $0x2e00,%r11d
    2b04:	4e 8d 24 17          	lea    (%rdi,%r10,1),%r12
    2b08:	4e 8d 2c 07          	lea    (%rdi,%r8,1),%r13
    2b0c:	4c 89 63 50          	mov    %r12,0x50(%rbx)
    2b10:	4c 89 6b 60          	mov    %r13,0x60(%rbx)
    2b14:	46 8b 1c 1f          	mov    (%rdi,%r11,1),%r11d
    2b18:	4c 89 9b 00 02 00 00 	mov    %r11,0x200(%rbx)
    2b1f:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    2b26:	00 00 00 00 
    2b2a:	46 8b 14 17          	mov    (%rdi,%r10,1),%r10d
    2b2e:	4c 89 93 10 02 00 00 	mov    %r10,0x210(%rbx)
    2b35:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    2b3c:	00 00 00 00 
    2b40:	46 8b 0c 0f          	mov    (%rdi,%r9,1),%r9d
    2b44:	4c 89 8b 20 02 00 00 	mov    %r9,0x220(%rbx)
    2b4b:	48 c7 83 28 02 00 00 	movq   $0x0,0x228(%rbx)
    2b52:	00 00 00 00 
    2b56:	48 c7 43 58 e0 3c 00 	movq   $0x3ce0,0x58(%rbx)
    2b5d:	00 
    2b5e:	42 8b 3c 07          	mov    (%rdi,%r8,1),%edi
    2b62:	48 89 bb 30 02 00 00 	mov    %rdi,0x230(%rbx)
    2b69:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    2b70:	00 00 00 00 
    2b74:	45 89 9e 48 ff ff ff 	mov    %r11d,-0xb8(%r14)
    2b7b:	45 89 96 4c ff ff ff 	mov    %r10d,-0xb4(%r14)
    2b82:	45 89 8e 50 ff ff ff 	mov    %r9d,-0xb0(%r14)
    2b89:	41 89 be 54 ff ff ff 	mov    %edi,-0xac(%r14)
    2b90:	31 ff                	xor    %edi,%edi
    2b92:	39 51 08             	cmp    %edx,0x8(%rcx)
    2b95:	48 0f 47 f8          	cmova  %rax,%rdi
    2b99:	48 03 79 10          	add    0x10(%rcx),%rdi
    2b9d:	48 89 7b 48          	mov    %rdi,0x48(%rbx)
    2ba1:	40 f6 c6 01          	test   $0x1,%sil
    2ba5:	75 1f                	jne    2bc6 <f_8001161d0+0x2bc6>
    2ba7:	be 40 00 00 00       	mov    $0x40,%esi
    2bac:	41 b8 38 00 00 00    	mov    $0x38,%r8d
    2bb2:	41 b9 30 00 00 00    	mov    $0x30,%r9d
    2bb8:	41 ba 28 00 00 00    	mov    $0x28,%r10d
    2bbe:	41 bb 20 00 00 00    	mov    $0x20,%r11d
    2bc4:	eb 1d                	jmp    2be3 <f_8001161d0+0x2be3>
    2bc6:	be f0 2d 00 00       	mov    $0x2df0,%esi
    2bcb:	41 b8 98 30 00 00    	mov    $0x3098,%r8d
    2bd1:	41 b9 90 30 00 00    	mov    $0x3090,%r9d
    2bd7:	41 ba 88 30 00 00    	mov    $0x3088,%r10d
    2bdd:	41 bb 80 30 00 00    	mov    $0x3080,%r11d
    2be3:	4e 8b 1c 1f          	mov    (%rdi,%r11,1),%r11
    2be7:	4e 8b 14 17          	mov    (%rdi,%r10,1),%r10
    2beb:	4c 8b a3 d0 00 00 00 	mov    0xd0(%rbx),%r12
    2bf2:	4d 89 1c 24          	mov    %r11,(%r12)
    2bf6:	4d 89 54 24 08       	mov    %r10,0x8(%r12)
    2bfb:	4e 8b 0c 0f          	mov    (%rdi,%r9,1),%r9
    2bff:	42 8b 3c 07          	mov    (%rdi,%r8,1),%edi
    2c03:	4c 8b 83 c8 00 00 00 	mov    0xc8(%rbx),%r8
    2c0a:	41 89 78 08          	mov    %edi,0x8(%r8)
    2c0e:	4d 89 08             	mov    %r9,(%r8)
    2c11:	31 ff                	xor    %edi,%edi
    2c13:	39 51 08             	cmp    %edx,0x8(%rcx)
    2c16:	48 0f 46 c7          	cmovbe %rdi,%rax
    2c1a:	48 03 71 10          	add    0x10(%rcx),%rsi
    2c1e:	48 8d 0c 06          	lea    (%rsi,%rax,1),%rcx
    2c22:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    2c26:	48 8b 44 30 20       	mov    0x20(%rax,%rsi,1),%rax
    2c2b:	48 85 c0             	test   %rax,%rax
    2c2e:	74 07                	je     2c37 <f_8001161d0+0x2c37>
    2c30:	0f b6 b8 c0 00 00 00 	movzbl 0xc0(%rax),%edi
    2c37:	49 bc ba e3 c0 02 08 	movabs $0x802c0e3ba,%r12
    2c3e:	00 00 00 
    2c41:	41 88 3f             	mov    %dil,(%r15)
    2c44:	48 8b 41 28          	mov    0x28(%rcx),%rax
    2c48:	48 85 c0             	test   %rax,%rax
    2c4b:	74 0d                	je     2c5a <f_8001161d0+0x2c5a>
    2c4d:	0f b6 80 c0 00 00 00 	movzbl 0xc0(%rax),%eax
    2c54:	48 89 43 48          	mov    %rax,0x48(%rbx)
    2c58:	eb 02                	jmp    2c5c <f_8001161d0+0x2c5c>
    2c5a:	31 c0                	xor    %eax,%eax
    2c5c:	41 88 46 81          	mov    %al,-0x7f(%r14)
    2c60:	48 8b 41 30          	mov    0x30(%rcx),%rax
    2c64:	48 85 c0             	test   %rax,%rax
    2c67:	74 09                	je     2c72 <f_8001161d0+0x2c72>
    2c69:	0f b6 80 c0 00 00 00 	movzbl 0xc0(%rax),%eax
    2c70:	eb 02                	jmp    2c74 <f_8001161d0+0x2c74>
    2c72:	31 c0                	xor    %eax,%eax
    2c74:	41 88 46 82          	mov    %al,-0x7e(%r14)
    2c78:	48 8b 41 38          	mov    0x38(%rcx),%rax
    2c7c:	48 85 c0             	test   %rax,%rax
    2c7f:	74 09                	je     2c8a <f_8001161d0+0x2c8a>
    2c81:	0f b6 80 c0 00 00 00 	movzbl 0xc0(%rax),%eax
    2c88:	eb 02                	jmp    2c8c <f_8001161d0+0x2c8c>
    2c8a:	31 c0                	xor    %eax,%eax
    2c8c:	41 88 46 83          	mov    %al,-0x7d(%r14)
    2c90:	48 8b 41 40          	mov    0x40(%rcx),%rax
    2c94:	48 85 c0             	test   %rax,%rax
    2c97:	74 0d                	je     2ca6 <f_8001161d0+0x2ca6>
    2c99:	0f b6 80 c0 00 00 00 	movzbl 0xc0(%rax),%eax
    2ca0:	48 89 43 48          	mov    %rax,0x48(%rbx)
    2ca4:	eb 02                	jmp    2ca8 <f_8001161d0+0x2ca8>
    2ca6:	31 c0                	xor    %eax,%eax
    2ca8:	41 88 46 84          	mov    %al,-0x7c(%r14)
    2cac:	48 8b 41 48          	mov    0x48(%rcx),%rax
    2cb0:	48 85 c0             	test   %rax,%rax
    2cb3:	74 09                	je     2cbe <f_8001161d0+0x2cbe>
    2cb5:	0f b6 80 c0 00 00 00 	movzbl 0xc0(%rax),%eax
    2cbc:	eb 02                	jmp    2cc0 <f_8001161d0+0x2cc0>
    2cbe:	31 c0                	xor    %eax,%eax
    2cc0:	41 88 46 85          	mov    %al,-0x7b(%r14)
    2cc4:	48 8b 41 50          	mov    0x50(%rcx),%rax
    2cc8:	48 85 c0             	test   %rax,%rax
    2ccb:	74 09                	je     2cd6 <f_8001161d0+0x2cd6>
    2ccd:	0f b6 80 c0 00 00 00 	movzbl 0xc0(%rax),%eax
    2cd4:	eb 02                	jmp    2cd8 <f_8001161d0+0x2cd8>
    2cd6:	31 c0                	xor    %eax,%eax
    2cd8:	41 88 46 86          	mov    %al,-0x7a(%r14)
    2cdc:	48 8b 41 58          	mov    0x58(%rcx),%rax
    2ce0:	48 85 c0             	test   %rax,%rax
    2ce3:	74 0d                	je     2cf2 <f_8001161d0+0x2cf2>
    2ce5:	0f b6 80 c0 00 00 00 	movzbl 0xc0(%rax),%eax
    2cec:	48 89 43 48          	mov    %rax,0x48(%rbx)
    2cf0:	eb 02                	jmp    2cf4 <f_8001161d0+0x2cf4>
    2cf2:	31 c0                	xor    %eax,%eax
    2cf4:	41 88 46 87          	mov    %al,-0x79(%r14)
    2cf8:	48 8b 41 60          	mov    0x60(%rcx),%rax
    2cfc:	48 85 c0             	test   %rax,%rax
    2cff:	74 10                	je     2d11 <f_8001161d0+0x2d11>
    2d01:	0f b6 80 c0 00 00 00 	movzbl 0xc0(%rax),%eax
    2d08:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2d0c:	e9 a1 f6 ff ff       	jmp    23b2 <f_8001161d0+0x23b2>
    2d11:	31 c0                	xor    %eax,%eax
    2d13:	e9 9a f6 ff ff       	jmp    23b2 <f_8001161d0+0x23b2>
