
/home/leegao/meh/ultratears-main/src/horizon2llvm/benchmark/samples/main_067_statickernel/results/main_067_statickernel_layer_17_pass17_nzcv_dfe.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <f_8001161d0>:
       0:	55                   	push   %rbp
       1:	41 57                	push   %r15
       3:	41 56                	push   %r14
       5:	41 55                	push   %r13
       7:	41 54                	push   %r12
       9:	53                   	push   %rbx
       a:	48 83 ec 18          	sub    $0x18,%rsp
       e:	48 89 fb             	mov    %rdi,%rbx
      11:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
      18:	00 00 00 
      1b:	48 8b 8f e8 00 00 00 	mov    0xe8(%rdi),%rcx
      22:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
      29:	48 8d 90 d0 fe ff ff 	lea    -0x130(%rax),%rdx
      30:	48 89 97 00 01 00 00 	mov    %rdx,0x100(%rdi)
      37:	48 8d 70 a0          	lea    -0x60(%rax),%rsi
      3b:	48 89 48 a0          	mov    %rcx,-0x60(%rax)
      3f:	48 8b 8f f0 00 00 00 	mov    0xf0(%rdi),%rcx
      46:	48 89 48 a8          	mov    %rcx,-0x58(%rax)
      4a:	48 8b 8f e0 00 00 00 	mov    0xe0(%rdi),%rcx
      51:	48 89 48 b0          	mov    %rcx,-0x50(%rax)
      55:	48 8b 8f d8 00 00 00 	mov    0xd8(%rdi),%rcx
      5c:	48 89 48 b8          	mov    %rcx,-0x48(%rax)
      60:	48 8b 8f d0 00 00 00 	mov    0xd0(%rdi),%rcx
      67:	48 89 48 c0          	mov    %rcx,-0x40(%rax)
      6b:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
      72:	48 89 48 c8          	mov    %rcx,-0x38(%rax)
      76:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
      7d:	48 89 48 d0          	mov    %rcx,-0x30(%rax)
      81:	48 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%rcx
      88:	48 89 48 d8          	mov    %rcx,-0x28(%rax)
      8c:	48 8b 8f b0 00 00 00 	mov    0xb0(%rdi),%rcx
      93:	48 89 48 e0          	mov    %rcx,-0x20(%rax)
      97:	48 8b 8f a8 00 00 00 	mov    0xa8(%rdi),%rcx
      9e:	48 89 48 e8          	mov    %rcx,-0x18(%rax)
      a2:	48 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%rcx
      a9:	48 89 48 f0          	mov    %rcx,-0x10(%rax)
      ad:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
      b4:	48 89 48 f8          	mov    %rcx,-0x8(%rax)
      b8:	48 89 b7 e8 00 00 00 	mov    %rsi,0xe8(%rdi)
      bf:	4c 8b 7f 10          	mov    0x10(%rdi),%r15
      c3:	4c 89 bf a8 00 00 00 	mov    %r15,0xa8(%rdi)
      ca:	4c 8b 27             	mov    (%rdi),%r12
      cd:	4c 8b 77 08          	mov    0x8(%rdi),%r14
      d1:	4c 89 b7 98 00 00 00 	mov    %r14,0x98(%rdi)
      d8:	4c 89 a7 a0 00 00 00 	mov    %r12,0xa0(%rdi)
      df:	49 8d 8e 14 29 00 00 	lea    0x2914(%r14),%rcx
      e6:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
      ea:	41 f7 c7 e0 ff ff ff 	test   $0xffffffe0,%r15d
      f1:	74 11                	je     104 <f_8001161d0+0x104>
      f3:	31 f6                	xor    %esi,%esi
      f5:	41 83 ff 12          	cmp    $0x12,%r15d
      f9:	b9 00 03 00 00       	mov    $0x300,%ecx
      fe:	48 0f 45 ce          	cmovne %rsi,%rcx
     102:	eb 1d                	jmp    121 <f_8001161d0+0x121>
     104:	b9 1f 7d c3 f6       	mov    $0xf6c37d1f,%ecx
     109:	44 0f a3 f9          	bt     %r15d,%ecx
     10d:	73 e4                	jae    f3 <f_8001161d0+0xf3>
     10f:	44 89 f9             	mov    %r15d,%ecx
     112:	83 e1 1f             	and    $0x1f,%ecx
     115:	49 8b 8c cd be 6b 16 	mov    0x166bbe(%r13,%rcx,8),%rcx
     11c:	00 
     11d:	48 c1 e1 08          	shl    $0x8,%rcx
     121:	49 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%r9
     128:	ff ff ff 
     12b:	49 ba ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r10
     132:	ff 7f ff 
     135:	48 bd ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rbp
     13c:	ff 7f 7f 
     13f:	41 0f be b6 17 29 00 	movsbl 0x2917(%r14),%esi
     146:	00 
     147:	48 63 f6             	movslq %esi,%rsi
     14a:	48 89 93 c0 00 00 00 	mov    %rdx,0xc0(%rbx)
     151:	48 69 fe 48 07 00 00 	imul   $0x748,%rsi,%rdi
     158:	45 31 c0             	xor    %r8d,%r8d
     15b:	41 39 b4 24 90 33 00 	cmp    %esi,0x3390(%r12)
     162:	00 
     163:	49 bb 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r11
     16a:	00 80 3f 
     16d:	4c 0f 47 c7          	cmova  %rdi,%r8
     171:	48 bf 00 00 00 00 01 	movabs $0x100000000,%rdi
     178:	00 00 00 
     17b:	4d 03 84 24 98 33 00 	add    0x3398(%r12),%r8
     182:	00 
     183:	48 c7 43 70 ff ff ff 	movq   $0xffffffffffffffff,0x70(%rbx)
     18a:	ff 
     18b:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 193 <f_8001161d0+0x193>
     192:	00 
     193:	c5 fc 11 80 d0 fe ff 	vmovups %ymm0,-0x130(%rax)
     19a:	ff 
     19b:	48 8d 77 ff          	lea    -0x1(%rdi),%rsi
     19f:	48 89 73 78          	mov    %rsi,0x78(%rbx)
     1a3:	48 89 b8 f0 fe ff ff 	mov    %rdi,-0x110(%rax)
     1aa:	4c 89 88 f8 fe ff ff 	mov    %r9,-0x108(%rax)
     1b1:	4a 8d 8c 01 e8 01 00 	lea    0x1e8(%rcx,%r8,1),%rcx
     1b8:	00 
     1b9:	48 89 8b b8 00 00 00 	mov    %rcx,0xb8(%rbx)
     1c0:	48 89 b0 00 ff ff ff 	mov    %rsi,-0x100(%rax)
     1c7:	4c 89 98 08 ff ff ff 	mov    %r11,-0xf8(%rax)
     1ce:	48 89 6b 58          	mov    %rbp,0x58(%rbx)
     1d2:	4c 89 98 10 ff ff ff 	mov    %r11,-0xf0(%rax)
     1d9:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     1e0:	00 00 00 00 
     1e4:	4d 8b 85 7e 86 d5 00 	mov    0xd5867e(%r13),%r8
     1eb:	4c 89 43 50          	mov    %r8,0x50(%rbx)
     1ef:	49 8b bd ae 5d d4 00 	mov    0xd45dae(%r13),%rdi
     1f6:	48 89 7b 48          	mov    %rdi,0x48(%rbx)
     1fa:	49 8d 48 10          	lea    0x10(%r8),%rcx
     1fe:	48 89 0c 24          	mov    %rcx,(%rsp)
     202:	48 89 88 20 ff ff ff 	mov    %rcx,-0xe0(%rax)
     209:	48 89 b8 40 ff ff ff 	mov    %rdi,-0xc0(%rax)
     210:	49 8b 8d b6 7e d5 00 	mov    0xd57eb6(%r13),%rcx
     217:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
     21b:	48 83 c1 10          	add    $0x10,%rcx
     21f:	48 89 8b 80 00 00 00 	mov    %rcx,0x80(%rbx)
     226:	48 89 a8 48 ff ff ff 	mov    %rbp,-0xb8(%rax)
     22d:	4c 89 90 50 ff ff ff 	mov    %r10,-0xb0(%rax)
     234:	49 81 c3 00 00 80 c0 	add    $0xffffffffc0800000,%r11
     23b:	4c 89 98 74 ff ff ff 	mov    %r11,-0x8c(%rax)
     242:	49 8b bd c6 7d d5 00 	mov    0xd57dc6(%r13),%rdi
     249:	4c 89 90 68 ff ff ff 	mov    %r10,-0x98(%rax)
     250:	44 8b 17             	mov    (%rdi),%r10d
     253:	4c 89 53 40          	mov    %r10,0x40(%rbx)
     257:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
     25c:	48 89 88 58 ff ff ff 	mov    %rcx,-0xa8(%rax)
     263:	48 89 a8 60 ff ff ff 	mov    %rbp,-0xa0(%rax)
     26a:	4c 89 cd             	mov    %r9,%rbp
     26d:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     274:	00 
     275:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     279:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     280:	44 89 90 70 ff ff ff 	mov    %r10d,-0x90(%rax)
     287:	41 83 ff 21          	cmp    $0x21,%r15d
     28b:	0f 87 f1 25 00 00    	ja     2882 <f_8001161d0+0x2882>
     291:	4c 89 5c 24 10       	mov    %r11,0x10(%rsp)
     296:	48 8d a8 48 ff ff ff 	lea    -0xb8(%rax),%rbp
     29d:	4c 8d 88 60 ff ff ff 	lea    -0xa0(%rax),%r9
     2a4:	4c 8d 58 80          	lea    -0x80(%rax),%r11
     2a8:	48 8d 88 70 ff ff ff 	lea    -0x90(%rax),%rcx
     2af:	49 8d bd 76 6b 16 00 	lea    0x166b76(%r13),%rdi
     2b6:	48 89 bb 88 00 00 00 	mov    %rdi,0x88(%rbx)
     2bd:	41 83 e7 3f          	and    $0x3f,%r15d
     2c1:	4c 89 bb 90 00 00 00 	mov    %r15,0x90(%rbx)
     2c8:	48 89 93 80 00 00 00 	mov    %rdx,0x80(%rbx)
     2cf:	44 89 fa             	mov    %r15d,%edx
     2d2:	41 0f b7 bc 55 76 6b 	movzwl 0x166b76(%r13,%rdx,2),%edi
     2d9:	16 00 
     2db:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
     2df:	49 8d 94 bd 52 05 51 	lea    -0x2aefaae(%r13,%rdi,4),%rdx
     2e6:	fd 
     2e7:	48 89 13             	mov    %rdx,(%rbx)
     2ea:	48 89 6b 48          	mov    %rbp,0x48(%rbx)
     2ee:	4c 89 8b d0 00 00 00 	mov    %r9,0xd0(%rbx)
     2f5:	48 89 8b c8 00 00 00 	mov    %rcx,0xc8(%rbx)
     2fc:	4c 89 9b d8 00 00 00 	mov    %r11,0xd8(%rbx)
     303:	81 ff 86 02 00 00    	cmp    $0x286,%edi
     309:	0f 8f 9c 03 00 00    	jg     6ab <f_8001161d0+0x6ab>
     30f:	81 ff 2d 01 00 00    	cmp    $0x12d,%edi
     315:	49 bd 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r13
     31c:	00 80 3f 
     31f:	0f 8f 15 04 00 00    	jg     73a <f_8001161d0+0x73a>
     325:	83 ff 6f             	cmp    $0x6f,%edi
     328:	0f 8f 33 07 00 00    	jg     a61 <f_8001161d0+0xa61>
     32e:	83 ff 04             	cmp    $0x4,%edi
     331:	0f 87 b9 12 00 00    	ja     15f0 <f_8001161d0+0x15f0>
     337:	89 ff                	mov    %edi,%edi
     339:	4c 8d 1d 00 00 00 00 	lea    0x0(%rip),%r11        # 340 <f_8001161d0+0x340>
     340:	49 63 3c bb          	movslq (%r11,%rdi,4),%rdi
     344:	4c 01 df             	add    %r11,%rdi
     347:	ff e7                	jmp    *%rdi
     349:	45 0f b7 bc 24 e4 0c 	movzwl 0xce4(%r12),%r15d
     350:	00 00 
     352:	4c 89 bb 90 00 00 00 	mov    %r15,0x90(%rbx)
     359:	8b 93 a8 00 00 00    	mov    0xa8(%rbx),%edx
     35f:	48 be 00 00 00 00 01 	movabs $0x100000000,%rsi
     366:	00 00 00 
     369:	01 f2                	add    %esi,%edx
     36b:	ff ca                	dec    %edx
     36d:	48 89 53 68          	mov    %rdx,0x68(%rbx)
     371:	4c 8b 04 24          	mov    (%rsp),%r8
     375:	4c 89 43 50          	mov    %r8,0x50(%rbx)
     379:	48 8b 93 98 00 00 00 	mov    0x98(%rbx),%rdx
     380:	0f b6 72 08          	movzbl 0x8(%rdx),%esi
     384:	48 89 73 78          	mov    %rsi,0x78(%rbx)
     388:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     38f:	00 00 00 00 
     393:	4c 89 80 20 ff ff ff 	mov    %r8,-0xe0(%rax)
     39a:	48 8b bb a0 00 00 00 	mov    0xa0(%rbx),%rdi
     3a1:	8b 8b a8 00 00 00    	mov    0xa8(%rbx),%ecx
     3a7:	8d 51 08             	lea    0x8(%rcx),%edx
     3aa:	c4 62 4b f7 9f fc 0d 	shrx   %esi,0xdfc(%rdi),%r11d
     3b1:	00 00 
     3b3:	89 90 00 ff ff ff    	mov    %edx,-0x100(%rax)
     3b9:	4c 8b 73 68          	mov    0x68(%rbx),%r14
     3bd:	44 89 b0 04 ff ff ff 	mov    %r14d,-0xfc(%rax)
     3c4:	8b 97 20 0d 00 00    	mov    0xd20(%rdi),%edx
     3ca:	31 ed                	xor    %ebp,%ebp
     3cc:	41 f7 c7 00 02 00 00 	test   $0x200,%r15d
     3d3:	40 0f 94 c5          	sete   %bpl
     3d7:	45 31 c0             	xor    %r8d,%r8d
     3da:	39 f2                	cmp    %esi,%edx
     3dc:	49 0f 46 f0          	cmovbe %r8,%rsi
     3e0:	48 69 d6 b0 0b 00 00 	imul   $0xbb0,%rsi,%rdx
     3e7:	45 31 e4             	xor    %r12d,%r12d
     3ea:	41 f7 c7 00 40 00 00 	test   $0x4000,%r15d
     3f1:	41 0f 94 c4          	sete   %r12b
     3f5:	41 c1 e7 06          	shl    $0x6,%r15d
     3f9:	41 81 e7 00 00 04 00 	and    $0x40000,%r15d
     400:	41 c1 e4 04          	shl    $0x4,%r12d
     404:	44 85 dd             	test   %r11d,%ebp
     407:	41 bb 01 00 00 00    	mov    $0x1,%r11d
     40d:	c4 42 09 f7 db       	shlx   %r14d,%r11d,%r11d
     412:	48 c7 43 48 01 00 00 	movq   $0x1,0x48(%rbx)
     419:	00 
     41a:	4c 89 5b 08          	mov    %r11,0x8(%rbx)
     41e:	48 8b bf 28 0d 00 00 	mov    0xd28(%rdi),%rdi
     425:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
     429:	48 89 73 78          	mov    %rsi,0x78(%rbx)
     42d:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     434:	00 
     435:	43 8d ac 3c 00 00 20 	lea    0x200000(%r12,%r15,1),%ebp
     43c:	00 
     43d:	48 c7 03 08 00 00 00 	movq   $0x8,(%rbx)
     444:	41 be 0f 00 00 00    	mov    $0xf,%r14d
     44a:	45 0f 45 f3          	cmovne %r11d,%r14d
     44e:	48 8b b3 00 01 00 00 	mov    0x100(%rbx),%rsi
     455:	44 89 36             	mov    %r14d,(%rsi)
     458:	c7 46 04 08 00 00 00 	movl   $0x8,0x4(%rsi)
     45f:	83 c1 04             	add    $0x4,%ecx
     462:	89 4e 08             	mov    %ecx,0x8(%rsi)
     465:	89 6e 0c             	mov    %ebp,0xc(%rsi)
     468:	48 c7 46 10 ff ff 00 	movq   $0xffff,0x10(%rsi)
     46f:	00 
     470:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     477:	ff ff ff 
     47a:	48 8d 4d 02          	lea    0x2(%rbp),%rcx
     47e:	48 89 4e 18          	mov    %rcx,0x18(%rsi)
     482:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
     487:	4c 89 bb 90 00 00 00 	mov    %r15,0x90(%rbx)
     48e:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     495:	00 00 00 
     498:	48 89 4e 20          	mov    %rcx,0x20(%rsi)
     49c:	48 89 6e 28          	mov    %rbp,0x28(%rsi)
     4a0:	4c 89 6e 38          	mov    %r13,0x38(%rsi)
     4a4:	4c 89 6e 40          	mov    %r13,0x40(%rsi)
     4a8:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     4af:	00 00 00 
     4b2:	4d 8d 9d b1 e5 0b 00 	lea    0xbe5b1(%r13),%r11
     4b9:	4c 89 9b 80 00 00 00 	mov    %r11,0x80(%rbx)
     4c0:	49 bc ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r12
     4c7:	ff 7f ff 
     4ca:	4c 89 a3 88 00 00 00 	mov    %r12,0x88(%rbx)
     4d1:	48 8b 8b c0 00 00 00 	mov    0xc0(%rbx),%rcx
     4d8:	4c 89 b9 a4 00 00 00 	mov    %r15,0xa4(%rcx)
     4df:	4c 8b 73 58          	mov    0x58(%rbx),%r14
     4e3:	4c 89 76 78          	mov    %r14,0x78(%rsi)
     4e7:	4c 89 a6 80 00 00 00 	mov    %r12,0x80(%rsi)
     4ee:	4c 89 a6 98 00 00 00 	mov    %r12,0x98(%rsi)
     4f5:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
     4fa:	4c 89 8e 88 00 00 00 	mov    %r9,0x88(%rsi)
     501:	4c 89 b6 90 00 00 00 	mov    %r14,0x90(%rsi)
     508:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     50c:	44 89 96 a0 00 00 00 	mov    %r10d,0xa0(%rsi)
     513:	c7 86 bc 00 00 00 00 	movl   $0x0,0xbc(%rsi)
     51a:	00 00 00 
     51d:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     521:	c5 f8 11 46 58       	vmovups %xmm0,0x58(%rsi)
     526:	48 c7 46 68 00 00 00 	movq   $0x0,0x68(%rsi)
     52d:	00 
     52e:	4c 89 5e 70          	mov    %r11,0x70(%rsi)
     532:	8b 84 17 d8 03 00 00 	mov    0x3d8(%rdi,%rdx,1),%eax
     539:	41 89 c1             	mov    %eax,%r9d
     53c:	41 c1 f9 1f          	sar    $0x1f,%r9d
     540:	c4 62 30 f2 c8       	andn   %eax,%r9d,%r9d
     545:	85 c0                	test   %eax,%eax
     547:	41 0f 49 c0          	cmovns %r8d,%eax
     54b:	c5 82 2a c0          	vcvtsi2ss %eax,%xmm15,%xmm0
     54f:	8b 84 17 f8 03 00 00 	mov    0x3f8(%rdi,%rdx,1),%eax
     556:	41 89 c2             	mov    %eax,%r10d
     559:	41 c1 fa 1f          	sar    $0x1f,%r10d
     55d:	c4 62 28 f2 d0       	andn   %eax,%r10d,%r10d
     562:	85 c0                	test   %eax,%eax
     564:	c4 c1 02 2a ca       	vcvtsi2ss %r10d,%xmm15,%xmm1
     569:	41 0f 49 c0          	cmovns %r8d,%eax
     56d:	c4 c1 02 2a d1       	vcvtsi2ss %r9d,%xmm15,%xmm2
     572:	c5 fa 11 96 80 00 00 	vmovss %xmm2,0x80(%rsi)
     579:	00 
     57a:	c5 fa 11 8e 84 00 00 	vmovss %xmm1,0x84(%rsi)
     581:	00 
     582:	c5 82 2a c8          	vcvtsi2ss %eax,%xmm15,%xmm1
     586:	c5 fa 11 46 78       	vmovss %xmm0,0x78(%rsi)
     58b:	c5 fa 11 4e 7c       	vmovss %xmm1,0x7c(%rsi)
     590:	44 8b 8c 17 d8 03 00 	mov    0x3d8(%rdi,%rdx,1),%r9d
     597:	00 
     598:	8b 84 17 f8 03 00 00 	mov    0x3f8(%rdi,%rdx,1),%eax
     59f:	48 89 43 60          	mov    %rax,0x60(%rbx)
     5a3:	44 8b 53 40          	mov    0x40(%rbx),%r10d
     5a7:	44 89 96 a0 00 00 00 	mov    %r10d,0xa0(%rsi)
     5ae:	45 89 ca             	mov    %r9d,%r10d
     5b1:	41 c1 fa 1f          	sar    $0x1f,%r10d
     5b5:	c4 42 28 f2 d1       	andn   %r9d,%r10d,%r10d
     5ba:	45 85 c9             	test   %r9d,%r9d
     5bd:	45 0f 49 c8          	cmovns %r8d,%r9d
     5c1:	c4 c1 02 2a c1       	vcvtsi2ss %r9d,%xmm15,%xmm0
     5c6:	4c 89 b9 a4 00 00 00 	mov    %r15,0xa4(%rcx)
     5cd:	85 c0                	test   %eax,%eax
     5cf:	44 0f 4f c0          	cmovg  %eax,%r8d
     5d3:	c4 c1 02 2a ca       	vcvtsi2ss %r10d,%xmm15,%xmm1
     5d8:	c4 e3 79 17 c1 00    	vextractps $0x0,%xmm0,%ecx
     5de:	4c 89 53 68          	mov    %r10,0x68(%rbx)
     5e2:	48 89 8b 10 02 00 00 	mov    %rcx,0x210(%rbx)
     5e9:	c4 e3 79 17 c9 00    	vextractps $0x0,%xmm1,%ecx
     5ef:	48 89 8b 00 02 00 00 	mov    %rcx,0x200(%rbx)
     5f6:	c4 c1 02 2a d0       	vcvtsi2ss %r8d,%xmm15,%xmm2
     5fb:	89 c1                	mov    %eax,%ecx
     5fd:	c1 f9 1f             	sar    $0x1f,%ecx
     600:	21 c1                	and    %eax,%ecx
     602:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
     609:	00 00 00 00 
     60d:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
     614:	00 00 00 00 
     618:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
     61c:	c5 82 2a d9          	vcvtsi2ss %ecx,%xmm15,%xmm3
     620:	c4 e3 79 17 d8 00    	vextractps $0x0,%xmm3,%eax
     626:	48 89 83 30 02 00 00 	mov    %rax,0x230(%rbx)
     62d:	c4 e3 79 17 d0 00    	vextractps $0x0,%xmm2,%eax
     633:	48 89 83 20 02 00 00 	mov    %rax,0x220(%rbx)
     63a:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
     641:	00 00 00 00 
     645:	48 c7 83 28 02 00 00 	movq   $0x0,0x228(%rbx)
     64c:	00 00 00 00 
     650:	c5 fa 11 8e 98 00 00 	vmovss %xmm1,0x98(%rsi)
     657:	00 
     658:	c5 fa 11 96 9c 00 00 	vmovss %xmm2,0x9c(%rsi)
     65f:	00 
     660:	c5 fa 11 86 90 00 00 	vmovss %xmm0,0x90(%rsi)
     667:	00 
     668:	c5 fa 11 9e 94 00 00 	vmovss %xmm3,0x94(%rsi)
     66f:	00 
     670:	31 c0                	xor    %eax,%eax
     672:	80 bc 17 58 04 00 00 	cmpb   $0x0,0x458(%rdi,%rdx,1)
     679:	00 
     67a:	48 c7 43 50 5b 00 00 	movq   $0x5b,0x50(%rbx)
     681:	00 
     682:	48 c7 86 b0 00 00 00 	movq   $0x0,0xb0(%rsi)
     689:	00 00 00 00 
     68d:	c7 86 bc 00 00 00 01 	movl   $0x1,0xbc(%rsi)
     694:	00 00 00 
     697:	0f 94 c0             	sete   %al
     69a:	48 8d 0c 45 59 00 00 	lea    0x59(,%rax,2),%rcx
     6a1:	00 
     6a2:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
     6a6:	e9 ca 21 00 00       	jmp    2875 <f_8001161d0+0x2875>
     6ab:	81 ff 6d 04 00 00    	cmp    $0x46d,%edi
     6b1:	49 bd 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r13
     6b8:	00 80 3f 
     6bb:	0f 8e 4c 02 00 00    	jle    90d <f_8001161d0+0x90d>
     6c1:	8d b7 92 fb ff ff    	lea    -0x46e(%rdi),%esi
     6c7:	83 fe 0c             	cmp    $0xc,%esi
     6ca:	0f 86 5a 07 00 00    	jbe    e2a <f_8001161d0+0xe2a>
     6d0:	8d b7 36 fb ff ff    	lea    -0x4ca(%rdi),%esi
     6d6:	83 fe 16             	cmp    $0x16,%esi
     6d9:	0f 87 ae 0e 00 00    	ja     158d <f_8001161d0+0x158d>
     6df:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # 6e6 <f_8001161d0+0x6e6>
     6e6:	48 63 34 b7          	movslq (%rdi,%rsi,4),%rsi
     6ea:	48 01 fe             	add    %rdi,%rsi
     6ed:	ff e6                	jmp    *%rsi
     6ef:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
     6f6:	00 
     6f7:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
     6fe:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     705:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     709:	48 89 43 10          	mov    %rax,0x10(%rbx)
     70d:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
     712:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
     719:	48 89 03             	mov    %rax,(%rbx)
     71c:	48 c7 43 18 01 00 00 	movq   $0x1,0x18(%rbx)
     723:	00 
     724:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     72b:	00 00 00 
     72e:	49 8d 85 92 18 51 fd 	lea    -0x2aee76e(%r13),%rax
     735:	e9 fc 12 00 00       	jmp    1a36 <f_8001161d0+0x1a36>
     73a:	81 ff c7 01 00 00    	cmp    $0x1c7,%edi
     740:	0f 8f b2 05 00 00    	jg     cf8 <f_8001161d0+0xcf8>
     746:	81 ff b1 01 00 00    	cmp    $0x1b1,%edi
     74c:	0f 8f c9 09 00 00    	jg     111b <f_8001161d0+0x111b>
     752:	81 ff 2e 01 00 00    	cmp    $0x12e,%edi
     758:	0f 84 0d 18 00 00    	je     1f6b <f_8001161d0+0x1f6b>
     75e:	81 ff 66 01 00 00    	cmp    $0x166,%edi
     764:	0f 85 66 12 00 00    	jne    19d0 <f_8001161d0+0x19d0>
     76a:	49 8b b4 24 c8 1e 00 	mov    0x1ec8(%r12),%rsi
     771:	00 
     772:	48 89 73 08          	mov    %rsi,0x8(%rbx)
     776:	48 c7 83 80 00 00 00 	movq   $0x3ce0,0x80(%rbx)
     77d:	e0 3c 00 00 
     781:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
     786:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
     78a:	41 0f b6 7e 08       	movzbl 0x8(%r14),%edi
     78f:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
     793:	4c 69 c7 e0 3c 00 00 	imul   $0x3ce0,%rdi,%r8
     79a:	31 d2                	xor    %edx,%edx
     79c:	39 7e 08             	cmp    %edi,0x8(%rsi)
     79f:	4c 0f 46 c2          	cmovbe %rdx,%r8
     7a3:	48 8b 76 10          	mov    0x10(%rsi),%rsi
     7a7:	49 8b b4 30 40 3c 00 	mov    0x3c40(%r8,%rsi,1),%rsi
     7ae:	00 
     7af:	48 89 b3 b0 00 00 00 	mov    %rsi,0xb0(%rbx)
     7b6:	48 8b b3 00 01 00 00 	mov    0x100(%rbx),%rsi
     7bd:	44 89 96 a0 00 00 00 	mov    %r10d,0xa0(%rsi)
     7c4:	48 89 8e 88 00 00 00 	mov    %rcx,0x88(%rsi)
     7cb:	48 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rcx
     7d2:	ff 7f 7f 
     7d5:	48 89 8e 90 00 00 00 	mov    %rcx,0x90(%rsi)
     7dc:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     7e3:	00 
     7e4:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     7e8:	c7 86 bc 00 00 00 00 	movl   $0x0,0xbc(%rsi)
     7ef:	00 00 00 
     7f2:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
     7f9:	00 
     7fa:	48 8b 04 24          	mov    (%rsp),%rax
     7fe:	48 89 46 50          	mov    %rax,0x50(%rsi)
     802:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     806:	c5 f8 11 46 58       	vmovups %xmm0,0x58(%rsi)
     80b:	48 c7 46 30 08 00 00 	movq   $0x8,0x30(%rsi)
     812:	00 
     813:	48 b8 10 00 00 00 03 	movabs $0x300000010,%rax
     81a:	00 00 00 
     81d:	48 89 06             	mov    %rax,(%rsi)
     820:	48 c7 46 08 00 00 00 	movq   $0x0,0x8(%rsi)
     827:	00 
     828:	48 c7 46 10 ff ff 00 	movq   $0xffff,0x10(%rsi)
     82f:	00 
     830:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     837:	ff ff ff 
     83a:	48 8d 45 0d          	lea    0xd(%rbp),%rax
     83e:	48 89 46 18          	mov    %rax,0x18(%rsi)
     842:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     849:	00 00 00 
     84c:	48 89 46 20          	mov    %rax,0x20(%rsi)
     850:	48 89 6e 28          	mov    %rbp,0x28(%rsi)
     854:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     85b:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
     860:	48 89 88 a4 00 00 00 	mov    %rcx,0xa4(%rax)
     867:	4c 89 6e 38          	mov    %r13,0x38(%rsi)
     86b:	4c 89 6e 40          	mov    %r13,0x40(%rsi)
     86f:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     876:	00 00 00 
     879:	49 8d 85 8b 0d 02 00 	lea    0x20d8b(%r13),%rax
     880:	48 89 43 70          	mov    %rax,0x70(%rbx)
     884:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
     88b:	ff 7f ff 
     88e:	48 89 7b 78          	mov    %rdi,0x78(%rbx)
     892:	48 89 be 98 00 00 00 	mov    %rdi,0x98(%rsi)
     899:	48 8b 4b 58          	mov    0x58(%rbx),%rcx
     89d:	48 89 4e 78          	mov    %rcx,0x78(%rsi)
     8a1:	48 89 be 80 00 00 00 	mov    %rdi,0x80(%rsi)
     8a8:	48 c7 46 68 00 00 00 	movq   $0x0,0x68(%rsi)
     8af:	00 
     8b0:	48 89 46 70          	mov    %rax,0x70(%rsi)
     8b4:	48 8b 43 08          	mov    0x8(%rbx),%rax
     8b8:	48 8b 4b 48          	mov    0x48(%rbx),%rcx
     8bc:	8b 70 08             	mov    0x8(%rax),%esi
     8bf:	48 89 73 40          	mov    %rsi,0x40(%rbx)
     8c3:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
     8c7:	41 89 f8             	mov    %edi,%r8d
     8ca:	39 fe                	cmp    %edi,%esi
     8cc:	be 00 00 00 00       	mov    $0x0,%esi
     8d1:	49 0f 47 f0          	cmova  %r8,%rsi
     8d5:	4c 8b 48 10          	mov    0x10(%rax),%r9
     8d9:	44 8b 93 80 00 00 00 	mov    0x80(%rbx),%r10d
     8e0:	49 0f af f2          	imul   %r10,%rsi
     8e4:	c4 a1 78 10 84 0e 00 	vmovups 0x2e00(%rsi,%r9,1),%xmm0
     8eb:	2e 00 00 
     8ee:	c5 f8 11 01          	vmovups %xmm0,(%rcx)
     8f2:	39 78 08             	cmp    %edi,0x8(%rax)
     8f5:	49 0f 47 d0          	cmova  %r8,%rdx
     8f9:	49 0f af d2          	imul   %r10,%rdx
     8fd:	48 03 50 10          	add    0x10(%rax),%rdx
     901:	48 8b bb b0 00 00 00 	mov    0xb0(%rbx),%rdi
     908:	e9 12 18 00 00       	jmp    211f <f_8001161d0+0x211f>
     90d:	81 ff d4 02 00 00    	cmp    $0x2d4,%edi
     913:	49 b8 00 00 00 00 01 	movabs $0x100000000,%r8
     91a:	00 00 00 
     91d:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
     922:	0f 8f 6b 04 00 00    	jg     d93 <f_8001161d0+0xd93>
     928:	81 ff b5 02 00 00    	cmp    $0x2b5,%edi
     92e:	0f 8f 7c 08 00 00    	jg     11b0 <f_8001161d0+0x11b0>
     934:	81 ff 87 02 00 00    	cmp    $0x287,%edi
     93a:	0f 84 b7 18 00 00    	je     21f7 <f_8001161d0+0x21f7>
     940:	81 ff 97 02 00 00    	cmp    $0x297,%edi
     946:	0f 85 84 10 00 00    	jne    19d0 <f_8001161d0+0x19d0>
     94c:	4d 89 cb             	mov    %r9,%r11
     94f:	49 89 cf             	mov    %rcx,%r15
     952:	4c 8b b3 00 01 00 00 	mov    0x100(%rbx),%r14
     959:	45 89 96 a0 00 00 00 	mov    %r10d,0xa0(%r14)
     960:	49 c7 06 00 00 00 40 	movq   $0x40000000,(%r14)
     967:	48 ba 00 00 00 00 00 	movabs $0x40000000000000,%rdx
     96e:	00 40 00 
     971:	49 89 56 08          	mov    %rdx,0x8(%r14)
     975:	49 c7 46 10 ff ff 00 	movq   $0xffff,0x10(%r14)
     97c:	00 
     97d:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
     984:	ff ff ff 
     987:	48 8d 56 14          	lea    0x14(%rsi),%rdx
     98b:	49 89 56 18          	mov    %rdx,0x18(%r14)
     98f:	48 8b 3c 24          	mov    (%rsp),%rdi
     993:	48 89 7b 40          	mov    %rdi,0x40(%rbx)
     997:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     99b:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     9a2:	00 
     9a3:	41 c7 86 bc 00 00 00 	movl   $0x0,0xbc(%r14)
     9aa:	00 00 00 00 
     9ae:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     9b5:	00 00 00 
     9b8:	49 89 46 20          	mov    %rax,0x20(%r14)
     9bc:	49 89 76 28          	mov    %rsi,0x28(%r14)
     9c0:	48 8d 40 ff          	lea    -0x1(%rax),%rax
     9c4:	49 89 46 30          	mov    %rax,0x30(%r14)
     9c8:	4d 89 6e 38          	mov    %r13,0x38(%r14)
     9cc:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
     9d3:	00 00 00 
     9d6:	48 8d 80 80 0d 02 00 	lea    0x20d80(%rax),%rax
     9dd:	49 89 46 70          	mov    %rax,0x70(%r14)
     9e1:	48 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rcx
     9e8:	ff 7f 7f 
     9eb:	49 89 4e 78          	mov    %rcx,0x78(%r14)
     9ef:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
     9f6:	ff 7f ff 
     9f9:	49 89 b6 80 00 00 00 	mov    %rsi,0x80(%r14)
     a00:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
     a05:	49 89 86 88 00 00 00 	mov    %rax,0x88(%r14)
     a0c:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # a14 <f_8001161d0+0xa14>
     a13:	00 
     a14:	c5 fc 11 43 60       	vmovups %ymm0,0x60(%rbx)
     a19:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     a20:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
     a25:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
     a2c:	4d 89 6e 40          	mov    %r13,0x40(%r14)
     a30:	49 c7 46 48 00 00 00 	movq   $0x0,0x48(%r14)
     a37:	00 
     a38:	49 89 8e 90 00 00 00 	mov    %rcx,0x90(%r14)
     a3f:	49 89 b6 98 00 00 00 	mov    %rsi,0x98(%r14)
     a46:	49 c7 46 68 00 00 00 	movq   $0x0,0x68(%r14)
     a4d:	00 
     a4e:	49 89 7e 50          	mov    %rdi,0x50(%r14)
     a52:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     a56:	c4 c1 78 11 46 58    	vmovups %xmm0,0x58(%r14)
     a5c:	e9 3f 1d 00 00       	jmp    27a0 <f_8001161d0+0x27a0>
     a61:	81 ff c8 00 00 00    	cmp    $0xc8,%edi
     a67:	0f 8f e0 03 00 00    	jg     e4d <f_8001161d0+0xe4d>
     a6d:	83 ff 70             	cmp    $0x70,%edi
     a70:	0f 84 43 12 00 00    	je     1cb9 <f_8001161d0+0x1cb9>
     a76:	81 ff 80 00 00 00    	cmp    $0x80,%edi
     a7c:	0f 85 4e 0f 00 00    	jne    19d0 <f_8001161d0+0x19d0>
     a82:	49 8b 94 24 c8 1e 00 	mov    0x1ec8(%r12),%rdx
     a89:	00 
     a8a:	48 89 53 08          	mov    %rdx,0x8(%rbx)
     a8e:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
     a93:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
     a97:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
     a9e:	00 
     a9f:	41 0f b6 7e 08       	movzbl 0x8(%r14),%edi
     aa4:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
     aa8:	44 8b 5a 08          	mov    0x8(%rdx),%r11d
     aac:	4c 8b 72 10          	mov    0x10(%rdx),%r14
     ab0:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
     ab7:	00 
     ab8:	4c 69 c7 e0 3c 00 00 	imul   $0x3ce0,%rdi,%r8
     abf:	31 f6                	xor    %esi,%esi
     ac1:	41 39 fb             	cmp    %edi,%r11d
     ac4:	41 bb 00 00 00 00    	mov    $0x0,%r11d
     aca:	4d 0f 47 d8          	cmova  %r8,%r11
     ace:	4f 8b 9c 33 40 3c 00 	mov    0x3c40(%r11,%r14,1),%r11
     ad5:	00 
     ad6:	4c 89 9b b0 00 00 00 	mov    %r11,0xb0(%rbx)
     add:	44 89 90 70 ff ff ff 	mov    %r10d,-0x90(%rax)
     ae4:	48 89 88 58 ff ff ff 	mov    %rcx,-0xa8(%rax)
     aeb:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     af2:	ff 7f 7f 
     af5:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
     afc:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     b03:	00 
     b04:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     b08:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     b0f:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     b16:	00 00 00 00 
     b1a:	48 8b 0c 24          	mov    (%rsp),%rcx
     b1e:	48 89 88 20 ff ff ff 	mov    %rcx,-0xe0(%rax)
     b25:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     b29:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
     b30:	ff 
     b31:	48 c7 80 00 ff ff ff 	movq   $0x5,-0x100(%rax)
     b38:	05 00 00 00 
     b3c:	48 b9 10 00 00 00 03 	movabs $0x300000010,%rcx
     b43:	00 00 00 
     b46:	48 81 c1 f0 00 00 00 	add    $0xf0,%rcx
     b4d:	48 89 88 d0 fe ff ff 	mov    %rcx,-0x130(%rax)
     b54:	48 b9 00 00 00 00 00 	movabs $0x60000000000000,%rcx
     b5b:	00 60 00 
     b5e:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
     b65:	4c 89 1b             	mov    %r11,(%rbx)
     b68:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     b6f:	ff ff 00 00 
     b73:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     b7a:	ff ff ff 
     b7d:	48 8d 4d 08          	lea    0x8(%rbp),%rcx
     b81:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
     b88:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     b8f:	00 00 00 
     b92:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
     b99:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
     ba0:	48 8b 8b c0 00 00 00 	mov    0xc0(%rbx),%rcx
     ba7:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
     bac:	4c 89 89 a4 00 00 00 	mov    %r9,0xa4(%rcx)
     bb3:	4c 89 a8 08 ff ff ff 	mov    %r13,-0xf8(%rax)
     bba:	4c 89 a8 10 ff ff ff 	mov    %r13,-0xf0(%rax)
     bc1:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     bc8:	00 00 00 
     bcb:	49 8d 8d 1d 54 09 00 	lea    0x9541d(%r13),%rcx
     bd2:	48 89 4b 78          	mov    %rcx,0x78(%rbx)
     bd6:	49 b9 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r9
     bdd:	ff 7f ff 
     be0:	4c 89 8b 80 00 00 00 	mov    %r9,0x80(%rbx)
     be7:	4c 89 88 68 ff ff ff 	mov    %r9,-0x98(%rax)
     bee:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
     bf5:	4c 89 88 50 ff ff ff 	mov    %r9,-0xb0(%rax)
     bfc:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
     c03:	00 00 00 00 
     c07:	48 89 88 40 ff ff ff 	mov    %rcx,-0xc0(%rax)
     c0e:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
     c12:	39 7a 08             	cmp    %edi,0x8(%rdx)
     c15:	41 b9 00 00 00 00    	mov    $0x0,%r9d
     c1b:	4d 0f 47 c8          	cmova  %r8,%r9
     c1f:	c4 a1 78 10 84 09 00 	vmovups 0x2e00(%rcx,%r9,1),%xmm0
     c26:	2e 00 00 
     c29:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
     c30:	ff 
     c31:	39 7a 08             	cmp    %edi,0x8(%rdx)
     c34:	49 0f 47 f0          	cmova  %r8,%rsi
     c38:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
     c3c:	48 8b 94 31 80 30 00 	mov    0x3080(%rcx,%rsi,1),%rdx
     c43:	00 
     c44:	48 8b bc 31 88 30 00 	mov    0x3088(%rcx,%rsi,1),%rdi
     c4b:	00 
     c4c:	48 89 7b 50          	mov    %rdi,0x50(%rbx)
     c50:	48 89 90 60 ff ff ff 	mov    %rdx,-0xa0(%rax)
     c57:	48 89 b8 68 ff ff ff 	mov    %rdi,-0x98(%rax)
     c5e:	48 8b 94 31 90 30 00 	mov    0x3090(%rcx,%rsi,1),%rdx
     c65:	00 
     c66:	48 89 53 48          	mov    %rdx,0x48(%rbx)
     c6a:	8b 8c 31 98 30 00 00 	mov    0x3098(%rcx,%rsi,1),%ecx
     c71:	89 88 78 ff ff ff    	mov    %ecx,-0x88(%rax)
     c77:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
     c7e:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
     c82:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
     c86:	48 89 90 70 ff ff ff 	mov    %rdx,-0x90(%rax)
     c8d:	49 8d 85 56 08 51 fd 	lea    -0x2aef7aa(%r13),%rax
     c94:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
     c9b:	48 89 df             	mov    %rbx,%rdi
     c9e:	c5 f8 77             	vzeroupper
     ca1:	e8 00 00 00 00       	call   ca6 <f_8001161d0+0xca6>
     ca6:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     cad:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
     cb4:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     cbb:	48 89 01             	mov    %rax,(%rcx)
     cbe:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     cc5:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     ccc:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
     cd0:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
     cd7:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     cdb:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     ce1:	48 89 43 40          	mov    %rax,0x40(%rbx)
     ce5:	88 51 08             	mov    %dl,0x8(%rcx)
     ce8:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     cef:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
     cf3:	e9 e5 14 00 00       	jmp    21dd <f_8001161d0+0x21dd>
     cf8:	81 ff 51 02 00 00    	cmp    $0x251,%edi
     cfe:	0f 8f 3d 05 00 00    	jg     1241 <f_8001161d0+0x1241>
     d04:	81 ff c8 01 00 00    	cmp    $0x1c8,%edi
     d0a:	0f 84 5a 15 00 00    	je     226a <f_8001161d0+0x226a>
     d10:	81 ff 0f 02 00 00    	cmp    $0x20f,%edi
     d16:	0f 85 b4 0c 00 00    	jne    19d0 <f_8001161d0+0x19d0>
     d1c:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     d23:	00 
     d24:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
     d2b:	48 c7 02 00 08 00 00 	movq   $0x800,(%rdx)
     d32:	48 c7 42 08 01 00 00 	movq   $0x1,0x8(%rdx)
     d39:	00 
     d3a:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     d41:	ff ff ff 
     d44:	48 8d 75 0b          	lea    0xb(%rbp),%rsi
     d48:	48 89 73 68          	mov    %rsi,0x68(%rbx)
     d4c:	48 c7 42 10 ff ff 00 	movq   $0xffff,0x10(%rdx)
     d53:	00 
     d54:	48 89 72 18          	mov    %rsi,0x18(%rdx)
     d58:	49 bb 00 00 00 00 01 	movabs $0x100000000,%r11
     d5f:	00 00 00 
     d62:	4c 89 5a 20          	mov    %r11,0x20(%rdx)
     d66:	48 89 6a 28          	mov    %rbp,0x28(%rdx)
     d6a:	4c 89 6b 70          	mov    %r13,0x70(%rbx)
     d6e:	49 8d 73 ff          	lea    -0x1(%r11),%rsi
     d72:	48 89 72 30          	mov    %rsi,0x30(%rdx)
     d76:	4c 89 6a 38          	mov    %r13,0x38(%rdx)
     d7a:	4c 89 e9             	mov    %r13,%rcx
     d7d:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     d84:	00 00 00 
     d87:	4d 8d 85 07 a8 04 00 	lea    0x4a807(%r13),%r8
     d8e:	e9 40 10 00 00       	jmp    1dd3 <f_8001161d0+0x1dd3>
     d93:	81 ff ac 03 00 00    	cmp    $0x3ac,%edi
     d99:	0f 8f 17 06 00 00    	jg     13b6 <f_8001161d0+0x13b6>
     d9f:	81 ff d5 02 00 00    	cmp    $0x2d5,%edi
     da5:	0f 84 06 17 00 00    	je     24b1 <f_8001161d0+0x24b1>
     dab:	81 ff f3 02 00 00    	cmp    $0x2f3,%edi
     db1:	0f 85 19 0c 00 00    	jne    19d0 <f_8001161d0+0x19d0>
     db7:	49 89 cf             	mov    %rcx,%r15
     dba:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     dc1:	00 
     dc2:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
     dc9:	48 c7 02 00 02 00 00 	movq   $0x200,(%rdx)
     dd0:	48 be 00 00 00 00 00 	movabs $0x40000000000000,%rsi
     dd7:	00 40 00 
     dda:	48 89 72 08          	mov    %rsi,0x8(%rdx)
     dde:	48 c7 42 10 ff ff 00 	movq   $0xffff,0x10(%rdx)
     de5:	00 
     de6:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     ded:	ff ff ff 
     df0:	48 8d 77 13          	lea    0x13(%rdi),%rsi
     df4:	48 89 72 18          	mov    %rsi,0x18(%rdx)
     df8:	4c 89 42 20          	mov    %r8,0x20(%rdx)
     dfc:	48 89 7a 28          	mov    %rdi,0x28(%rdx)
     e00:	49 8d 70 ff          	lea    -0x1(%r8),%rsi
     e04:	48 89 73 68          	mov    %rsi,0x68(%rbx)
     e08:	4c 89 6b 70          	mov    %r13,0x70(%rbx)
     e0c:	48 8d 72 30          	lea    0x30(%rdx),%rsi
     e10:	48 83 c2 38          	add    $0x38,%rdx
     e14:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
     e1b:	00 00 00 
     e1e:	48 81 c7 f9 7a ff ff 	add    $0xffffffffffff7af9,%rdi
     e25:	e9 be 18 00 00       	jmp    26e8 <f_8001161d0+0x26e8>
     e2a:	48 8d 3d 00 00 00 00 	lea    0x0(%rip),%rdi        # e31 <f_8001161d0+0xe31>
     e31:	48 63 34 b7          	movslq (%rdi,%rsi,4),%rsi
     e35:	48 01 fe             	add    %rdi,%rsi
     e38:	ff e6                	jmp    *%rsi
     e3a:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     e41:	00 00 00 
     e44:	4d 8d 45 e0          	lea    -0x20(%r13),%r8
     e48:	e9 6e 08 00 00       	jmp    16bb <f_8001161d0+0x16bb>
     e4d:	81 ff c9 00 00 00    	cmp    $0xc9,%edi
     e53:	0f 84 eb 0e 00 00    	je     1d44 <f_8001161d0+0x1d44>
     e59:	81 ff d9 00 00 00    	cmp    $0xd9,%edi
     e5f:	0f 85 6b 0b 00 00    	jne    19d0 <f_8001161d0+0x19d0>
     e65:	49 8b 94 24 c8 1e 00 	mov    0x1ec8(%r12),%rdx
     e6c:	00 
     e6d:	48 89 53 08          	mov    %rdx,0x8(%rbx)
     e71:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
     e76:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
     e7a:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
     e81:	00 
     e82:	41 0f b6 7e 08       	movzbl 0x8(%r14),%edi
     e87:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
     e8b:	45 0f b7 86 14 29 00 	movzwl 0x2914(%r14),%r8d
     e92:	00 
     e93:	41 83 e0 40          	and    $0x40,%r8d
     e97:	44 8b 5a 08          	mov    0x8(%rdx),%r11d
     e9b:	4c 8b 72 10          	mov    0x10(%rdx),%r14
     e9f:	48 c7 43 78 e0 3c 00 	movq   $0x3ce0,0x78(%rbx)
     ea6:	00 
     ea7:	31 f6                	xor    %esi,%esi
     ea9:	41 39 fb             	cmp    %edi,%r11d
     eac:	41 bb 00 00 00 00    	mov    $0x0,%r11d
     eb2:	4c 0f 47 df          	cmova  %rdi,%r11
     eb6:	4c 89 9b 88 00 00 00 	mov    %r11,0x88(%rbx)
     ebd:	4d 69 db e0 3c 00 00 	imul   $0x3ce0,%r11,%r11
     ec4:	4f 8b 9c 33 40 3c 00 	mov    0x3c40(%r11,%r14,1),%r11
     ecb:	00 
     ecc:	4c 89 9b b0 00 00 00 	mov    %r11,0xb0(%rbx)
     ed3:	4d 8b b4 24 b8 1e 00 	mov    0x1eb8(%r12),%r14
     eda:	00 
     edb:	44 89 90 70 ff ff ff 	mov    %r10d,-0x90(%rax)
     ee2:	48 89 88 58 ff ff ff 	mov    %rcx,-0xa8(%rax)
     ee9:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     ef0:	ff 7f 7f 
     ef3:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
     efa:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     f01:	00 
     f02:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     f06:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     f0d:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     f11:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
     f18:	ff 
     f19:	41 80 be b0 06 00 00 	cmpb   $0x0,0x6b0(%r14)
     f20:	00 
     f21:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     f28:	00 00 00 00 
     f2c:	48 8b 0c 24          	mov    (%rsp),%rcx
     f30:	48 89 88 20 ff ff ff 	mov    %rcx,-0xe0(%rax)
     f37:	48 c7 80 00 ff ff ff 	movq   $0x4,-0x100(%rax)
     f3e:	04 00 00 00 
     f42:	4c 89 1b             	mov    %r11,(%rbx)
     f45:	0f 95 c1             	setne  %cl
     f48:	41 c1 e8 06          	shr    $0x6,%r8d
     f4c:	41 20 c8             	and    %cl,%r8b
     f4f:	c7 80 d8 fe ff ff 00 	movl   $0x0,-0x128(%rax)
     f56:	00 00 00 
     f59:	41 0f b6 c8          	movzbl %r8b,%ecx
     f5d:	c1 e1 1a             	shl    $0x1a,%ecx
     f60:	81 c9 01 00 40 00    	or     $0x400001,%ecx
     f66:	89 88 dc fe ff ff    	mov    %ecx,-0x124(%rax)
     f6c:	48 b9 10 00 00 00 03 	movabs $0x300000010,%rcx
     f73:	00 00 00 
     f76:	48 89 88 d0 fe ff ff 	mov    %rcx,-0x130(%rax)
     f7d:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     f84:	ff ff 00 00 
     f88:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     f8f:	ff ff ff 
     f92:	48 8d 4d 07          	lea    0x7(%rbp),%rcx
     f96:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
     f9d:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     fa4:	00 00 00 
     fa7:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
     fae:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
     fb5:	4c 89 a8 08 ff ff ff 	mov    %r13,-0xf8(%rax)
     fbc:	4c 89 a8 10 ff ff ff 	mov    %r13,-0xf0(%rax)
     fc3:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     fca:	00 00 00 
     fcd:	49 8d 8d 00 54 09 00 	lea    0x95400(%r13),%rcx
     fd4:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
     fd8:	4c 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%r8
     fdf:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
     fe4:	4d 89 88 a4 00 00 00 	mov    %r9,0xa4(%r8)
     feb:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     ff2:	ff 7f ff 
     ff5:	4c 89 83 80 00 00 00 	mov    %r8,0x80(%rbx)
     ffc:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
    1003:	4c 89 80 50 ff ff ff 	mov    %r8,-0xb0(%rax)
    100a:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
    1011:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
    1018:	00 00 00 00 
    101c:	48 89 88 40 ff ff ff 	mov    %rcx,-0xc0(%rax)
    1023:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    1027:	4c 69 c7 e0 3c 00 00 	imul   $0x3ce0,%rdi,%r8
    102e:	39 7a 08             	cmp    %edi,0x8(%rdx)
    1031:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    1037:	4d 0f 47 c8          	cmova  %r8,%r9
    103b:	c4 a1 78 10 84 09 00 	vmovups 0x2e00(%rcx,%r9,1),%xmm0
    1042:	2e 00 00 
    1045:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
    104c:	ff 
    104d:	39 7a 08             	cmp    %edi,0x8(%rdx)
    1050:	49 0f 47 f0          	cmova  %r8,%rsi
    1054:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    1058:	48 8b 94 31 80 30 00 	mov    0x3080(%rcx,%rsi,1),%rdx
    105f:	00 
    1060:	48 8b bc 31 88 30 00 	mov    0x3088(%rcx,%rsi,1),%rdi
    1067:	00 
    1068:	48 89 7b 50          	mov    %rdi,0x50(%rbx)
    106c:	48 89 90 60 ff ff ff 	mov    %rdx,-0xa0(%rax)
    1073:	48 89 b8 68 ff ff ff 	mov    %rdi,-0x98(%rax)
    107a:	48 8b 94 31 90 30 00 	mov    0x3090(%rcx,%rsi,1),%rdx
    1081:	00 
    1082:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    1086:	8b 8c 31 98 30 00 00 	mov    0x3098(%rcx,%rsi,1),%ecx
    108d:	89 88 78 ff ff ff    	mov    %ecx,-0x88(%rax)
    1093:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
    109a:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
    109e:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    10a2:	48 89 90 70 ff ff ff 	mov    %rdx,-0x90(%rax)
    10a9:	49 8d 85 e6 09 51 fd 	lea    -0x2aef61a(%r13),%rax
    10b0:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    10b7:	48 89 df             	mov    %rbx,%rdi
    10ba:	c5 f8 77             	vzeroupper
    10bd:	e8 00 00 00 00       	call   10c2 <f_8001161d0+0x10c2>
    10c2:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    10c9:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    10d0:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    10d7:	48 89 01             	mov    %rax,(%rcx)
    10da:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
    10e1:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
    10e8:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
    10ec:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    10f0:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
    10f7:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    10fb:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
    1101:	48 89 43 40          	mov    %rax,0x40(%rbx)
    1105:	88 51 08             	mov    %dl,0x8(%rcx)
    1108:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    110f:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
    1113:	89 41 24             	mov    %eax,0x24(%rcx)
    1116:	e9 67 17 00 00       	jmp    2882 <f_8001161d0+0x2882>
    111b:	81 ff b2 01 00 00    	cmp    $0x1b2,%edi
    1121:	0f 84 84 14 00 00    	je     25ab <f_8001161d0+0x25ab>
    1127:	81 ff b8 01 00 00    	cmp    $0x1b8,%edi
    112d:	0f 85 9d 08 00 00    	jne    19d0 <f_8001161d0+0x19d0>
    1133:	49 89 cf             	mov    %rcx,%r15
    1136:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    113d:	00 
    113e:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    1145:	48 c7 02 08 00 00 00 	movq   $0x8,(%rdx)
    114c:	48 be 00 00 00 00 00 	movabs $0x40000000000000,%rsi
    1153:	00 40 00 
    1156:	48 89 72 08          	mov    %rsi,0x8(%rdx)
    115a:	48 c7 42 10 ff ff 00 	movq   $0xffff,0x10(%rdx)
    1161:	00 
    1162:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    1169:	ff ff ff 
    116c:	48 8d 77 15          	lea    0x15(%rdi),%rsi
    1170:	48 89 72 18          	mov    %rsi,0x18(%rdx)
    1174:	49 b8 00 00 00 00 01 	movabs $0x100000000,%r8
    117b:	00 00 00 
    117e:	4c 89 42 20          	mov    %r8,0x20(%rdx)
    1182:	48 89 7a 28          	mov    %rdi,0x28(%rdx)
    1186:	49 8d 70 ff          	lea    -0x1(%r8),%rsi
    118a:	48 89 73 68          	mov    %rsi,0x68(%rbx)
    118e:	4c 89 6b 70          	mov    %r13,0x70(%rbx)
    1192:	48 8d 72 30          	lea    0x30(%rdx),%rsi
    1196:	48 83 c2 38          	add    $0x38,%rdx
    119a:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    11a1:	00 00 00 
    11a4:	48 81 c7 af 2c 05 00 	add    $0x52caf,%rdi
    11ab:	e9 38 15 00 00       	jmp    26e8 <f_8001161d0+0x26e8>
    11b0:	81 ff b6 02 00 00    	cmp    $0x2b6,%edi
    11b6:	0f 84 4e 14 00 00    	je     260a <f_8001161d0+0x260a>
    11bc:	81 ff c5 02 00 00    	cmp    $0x2c5,%edi
    11c2:	0f 85 08 08 00 00    	jne    19d0 <f_8001161d0+0x19d0>
    11c8:	49 89 cf             	mov    %rcx,%r15
    11cb:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    11d2:	00 
    11d3:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    11da:	48 be 01 00 00 00 04 	movabs $0x400000001,%rsi
    11e1:	00 00 00 
    11e4:	48 89 32             	mov    %rsi,(%rdx)
    11e7:	48 be 00 00 00 00 02 	movabs $0x80200000000,%rsi
    11ee:	08 00 00 
    11f1:	48 89 72 08          	mov    %rsi,0x8(%rdx)
    11f5:	48 c7 42 10 ff ff 00 	movq   $0xffff,0x10(%rdx)
    11fc:	00 
    11fd:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    1204:	ff ff ff 
    1207:	48 8d 77 0f          	lea    0xf(%rdi),%rsi
    120b:	48 89 72 18          	mov    %rsi,0x18(%rdx)
    120f:	4c 89 42 20          	mov    %r8,0x20(%rdx)
    1213:	48 89 7a 28          	mov    %rdi,0x28(%rdx)
    1217:	49 8d 70 ff          	lea    -0x1(%r8),%rsi
    121b:	48 89 73 68          	mov    %rsi,0x68(%rbx)
    121f:	4c 89 6b 70          	mov    %r13,0x70(%rbx)
    1223:	48 8d 72 30          	lea    0x30(%rdx),%rsi
    1227:	48 83 c2 38          	add    $0x38,%rdx
    122b:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    1232:	00 00 00 
    1235:	48 81 c7 88 db 0a 00 	add    $0xadb88,%rdi
    123c:	e9 a7 14 00 00       	jmp    26e8 <f_8001161d0+0x26e8>
    1241:	81 ff 52 02 00 00    	cmp    $0x252,%edi
    1247:	0f 84 2d 14 00 00    	je     267a <f_8001161d0+0x267a>
    124d:	81 ff 61 02 00 00    	cmp    $0x261,%edi
    1253:	0f 85 77 07 00 00    	jne    19d0 <f_8001161d0+0x19d0>
    1259:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    1260:	44 89 92 a0 00 00 00 	mov    %r10d,0xa0(%rdx)
    1267:	48 be 00 00 00 00 0f 	movabs $0xf00000000,%rsi
    126e:	00 00 00 
    1271:	48 89 72 14          	mov    %rsi,0x14(%rdx)
    1275:	48 be 00 00 00 00 ff 	movabs $0xffff00000000,%rsi
    127c:	ff 00 00 
    127f:	48 81 ce 00 00 40 08 	or     $0x8400000,%rsi
    1286:	48 89 72 0c          	mov    %rsi,0xc(%rdx)
    128a:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
    1291:	bf 00 00 02 00       	mov    $0x20000,%edi
    1296:	23 be 8c 3a 00 00    	and    0x3a8c(%rsi),%edi
    129c:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    12a1:	4c 89 4b 60          	mov    %r9,0x60(%rbx)
    12a5:	4c 8b 04 24          	mov    (%rsp),%r8
    12a9:	4c 89 43 40          	mov    %r8,0x40(%rbx)
    12ad:	48 c7 42 04 00 00 00 	movq   $0x0,0x4(%rdx)
    12b4:	00 
    12b5:	48 be 00 00 00 00 01 	movabs $0x100000000,%rsi
    12bc:	00 00 00 
    12bf:	48 ff ce             	dec    %rsi
    12c2:	48 89 72 1c          	mov    %rsi,0x1c(%rdx)
    12c6:	48 c7 43 68 01 00 00 	movq   $0x1,0x68(%rbx)
    12cd:	00 
    12ce:	c7 42 34 00 00 00 00 	movl   $0x0,0x34(%rdx)
    12d5:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    12dc:	00 
    12dd:	48 c7 42 24 01 00 00 	movq   $0x1,0x24(%rdx)
    12e4:	00 
    12e5:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    12e9:	c7 82 bc 00 00 00 00 	movl   $0x0,0xbc(%rdx)
    12f0:	00 00 00 
    12f3:	48 b8 ff ff ff ff 01 	movabs $0x1ffffffff,%rax
    12fa:	00 00 00 
    12fd:	48 89 42 2c          	mov    %rax,0x2c(%rdx)
    1301:	c1 ef 08             	shr    $0x8,%edi
    1304:	81 cf 00 00 00 40    	or     $0x40000000,%edi
    130a:	89 3a                	mov    %edi,(%rdx)
    130c:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    1313:	00 00 00 
    1316:	48 8d b0 f0 85 00 00 	lea    0x85f0(%rax),%rsi
    131d:	48 89 73 70          	mov    %rsi,0x70(%rbx)
    1321:	4c 89 6a 38          	mov    %r13,0x38(%rdx)
    1325:	4c 89 6a 40          	mov    %r13,0x40(%rdx)
    1329:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    1330:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    1335:	48 89 b8 a4 00 00 00 	mov    %rdi,0xa4(%rax)
    133c:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    1343:	ff 7f ff 
    1346:	48 89 bb 80 00 00 00 	mov    %rdi,0x80(%rbx)
    134d:	48 89 ba 98 00 00 00 	mov    %rdi,0x98(%rdx)
    1354:	48 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rcx
    135b:	ff 7f 7f 
    135e:	48 89 4a 78          	mov    %rcx,0x78(%rdx)
    1362:	48 89 ba 80 00 00 00 	mov    %rdi,0x80(%rdx)
    1369:	4c 89 8a 88 00 00 00 	mov    %r9,0x88(%rdx)
    1370:	48 89 8a 90 00 00 00 	mov    %rcx,0x90(%rdx)
    1377:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    137b:	c5 f8 11 42 58       	vmovups %xmm0,0x58(%rdx)
    1380:	48 c7 42 68 00 00 00 	movq   $0x0,0x68(%rdx)
    1387:	00 
    1388:	48 89 72 70          	mov    %rsi,0x70(%rdx)
    138c:	48 c7 42 48 00 00 00 	movq   $0x0,0x48(%rdx)
    1393:	00 
    1394:	4c 89 42 50          	mov    %r8,0x50(%rdx)
    1398:	48 8b 6b 48          	mov    0x48(%rbx),%rbp
    139c:	4c 8b bb c8 00 00 00 	mov    0xc8(%rbx),%r15
    13a3:	4c 8b 9b d0 00 00 00 	mov    0xd0(%rbx),%r11
    13aa:	4c 8b b3 00 01 00 00 	mov    0x100(%rbx),%r14
    13b1:	e9 ea 13 00 00       	jmp    27a0 <f_8001161d0+0x27a0>
    13b6:	81 ff ad 03 00 00    	cmp    $0x3ad,%edi
    13bc:	0f 84 1f 17 00 00    	je     2ae1 <f_8001161d0+0x2ae1>
    13c2:	81 ff 12 04 00 00    	cmp    $0x412,%edi
    13c8:	0f 85 02 06 00 00    	jne    19d0 <f_8001161d0+0x19d0>
    13ce:	48 8b 93 a0 00 00 00 	mov    0xa0(%rbx),%rdx
    13d5:	48 8b 92 c8 1e 00 00 	mov    0x1ec8(%rdx),%rdx
    13dc:	48 89 53 70          	mov    %rdx,0x70(%rbx)
    13e0:	4c 89 03             	mov    %r8,(%rbx)
    13e3:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    13e7:	48 8b bb 00 01 00 00 	mov    0x100(%rbx),%rdi
    13ee:	48 c7 07 02 00 00 00 	movq   $0x2,(%rdi)
    13f5:	48 be 00 00 00 00 00 	movabs $0x40000000000000,%rsi
    13fc:	00 40 00 
    13ff:	48 ff c6             	inc    %rsi
    1402:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    1406:	4c 89 47 20          	mov    %r8,0x20(%rdi)
    140a:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    1411:	ff ff ff 
    1414:	48 89 6f 28          	mov    %rbp,0x28(%rdi)
    1418:	4c 89 e9             	mov    %r13,%rcx
    141b:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1422:	00 00 00 
    1425:	4c 89 6b 68          	mov    %r13,0x68(%rbx)
    1429:	49 bb ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r11
    1430:	ff 7f ff 
    1433:	4c 89 9f 80 00 00 00 	mov    %r11,0x80(%rdi)
    143a:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    143f:	48 89 b7 88 00 00 00 	mov    %rsi,0x88(%rdi)
    1446:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    144d:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    1452:	4c 89 8e a4 00 00 00 	mov    %r9,0xa4(%rsi)
    1459:	49 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r9
    1460:	ff 7f 7f 
    1463:	4c 89 8f 90 00 00 00 	mov    %r9,0x90(%rdi)
    146a:	4c 89 9f 98 00 00 00 	mov    %r11,0x98(%rdi)
    1471:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 1479 <f_8001161d0+0x1479>
    1478:	00 
    1479:	c5 fc 11 43 78       	vmovups %ymm0,0x78(%rbx)
    147e:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1485:	00 
    1486:	44 89 97 a0 00 00 00 	mov    %r10d,0xa0(%rdi)
    148d:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1494:	0f b6 70 08          	movzbl 0x8(%rax),%esi
    1498:	c7 87 bc 00 00 00 03 	movl   $0x3,0xbc(%rdi)
    149f:	00 00 00 
    14a2:	48 c7 47 10 ff ff 00 	movq   $0xffff,0x10(%rdi)
    14a9:	00 
    14aa:	48 8d 45 16          	lea    0x16(%rbp),%rax
    14ae:	48 89 47 18          	mov    %rax,0x18(%rdi)
    14b2:	48 c7 47 68 00 00 00 	movq   $0x0,0x68(%rdi)
    14b9:	00 
    14ba:	49 8d 40 ff          	lea    -0x1(%r8),%rax
    14be:	48 89 47 30          	mov    %rax,0x30(%rdi)
    14c2:	48 89 4f 38          	mov    %rcx,0x38(%rdi)
    14c6:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    14ca:	48 c7 47 48 00 00 00 	movq   $0x0,0x48(%rdi)
    14d1:	00 
    14d2:	48 8b 04 24          	mov    (%rsp),%rax
    14d6:	48 89 47 50          	mov    %rax,0x50(%rdi)
    14da:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    14de:	c5 f8 11 47 58       	vmovups %xmm0,0x58(%rdi)
    14e3:	4c 89 6f 70          	mov    %r13,0x70(%rdi)
    14e7:	4c 89 4f 78          	mov    %r9,0x78(%rdi)
    14eb:	48 8b 42 10          	mov    0x10(%rdx),%rax
    14ef:	48 69 ce e0 3c 00 00 	imul   $0x3ce0,%rsi,%rcx
    14f6:	31 ff                	xor    %edi,%edi
    14f8:	39 72 08             	cmp    %esi,0x8(%rdx)
    14fb:	ba 00 00 00 00       	mov    $0x0,%edx
    1500:	48 0f 47 d1          	cmova  %rcx,%rdx
    1504:	4c 8b 84 02 b8 30 00 	mov    0x30b8(%rdx,%rax,1),%r8
    150b:	00 
    150c:	4c 89 43 60          	mov    %r8,0x60(%rbx)
    1510:	48 8b 84 02 b0 30 00 	mov    0x30b0(%rdx,%rax,1),%rax
    1517:	00 
    1518:	48 8b 53 48          	mov    0x48(%rbx),%rdx
    151c:	48 89 02             	mov    %rax,(%rdx)
    151f:	4c 89 42 08          	mov    %r8,0x8(%rdx)
    1523:	48 8b 43 70          	mov    0x70(%rbx),%rax
    1527:	48 8b 93 d0 00 00 00 	mov    0xd0(%rbx),%rdx
    152e:	44 8b 40 08          	mov    0x8(%rax),%r8d
    1532:	4c 89 43 48          	mov    %r8,0x48(%rbx)
    1536:	4c 8b 48 10          	mov    0x10(%rax),%r9
    153a:	4c 89 4b 58          	mov    %r9,0x58(%rbx)
    153e:	41 39 f0             	cmp    %esi,%r8d
    1541:	48 0f 47 f9          	cmova  %rcx,%rdi
    1545:	4a 8b 8c 0f 30 33 00 	mov    0x3330(%rdi,%r9,1),%rcx
    154c:	00 
    154d:	4a 8b b4 0f 38 33 00 	mov    0x3338(%rdi,%r9,1),%rsi
    1554:	00 
    1555:	48 89 4b 50          	mov    %rcx,0x50(%rbx)
    1559:	48 89 0a             	mov    %rcx,(%rdx)
    155c:	48 89 72 08          	mov    %rsi,0x8(%rdx)
    1560:	42 8b 8c 0f 48 33 00 	mov    0x3348(%rdi,%r9,1),%ecx
    1567:	00 
    1568:	4a 8b 94 0f 40 33 00 	mov    0x3340(%rdi,%r9,1),%rdx
    156f:	00 
    1570:	48 8b b3 c8 00 00 00 	mov    0xc8(%rbx),%rsi
    1577:	48 89 16             	mov    %rdx,(%rsi)
    157a:	89 4e 08             	mov    %ecx,0x8(%rsi)
    157d:	8b 48 44             	mov    0x44(%rax),%ecx
    1580:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    1584:	48 83 c0 30          	add    $0x30,%rax
    1588:	e9 f3 06 00 00       	jmp    1c80 <f_8001161d0+0x1c80>
    158d:	81 ff 1a 05 00 00    	cmp    $0x51a,%edi
    1593:	0f 85 37 04 00 00    	jne    19d0 <f_8001161d0+0x19d0>
    1599:	b8 e8 0a 00 00       	mov    $0xae8,%eax
    159e:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    15a5:	48 89 03             	mov    %rax,(%rbx)
    15a8:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    15af:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    15b6:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    15ba:	48 89 43 10          	mov    %rax,0x10(%rbx)
    15be:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    15c5:	00 00 00 
    15c8:	49 8d 85 ca 19 51 fd 	lea    -0x2aee636(%r13),%rax
    15cf:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    15d6:	48 89 df             	mov    %rbx,%rdi
    15d9:	c5 f8 77             	vzeroupper
    15dc:	e8 00 00 00 00       	call   15e1 <f_8001161d0+0x15e1>
    15e1:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    15e8:	ff ff ff 
    15eb:	e9 92 12 00 00       	jmp    2882 <f_8001161d0+0x2882>
    15f0:	83 ff 61             	cmp    $0x61,%edi
    15f3:	0f 85 d7 03 00 00    	jne    19d0 <f_8001161d0+0x19d0>
    15f9:	49 89 cf             	mov    %rcx,%r15
    15fc:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    1603:	00 
    1604:	48 c7 80 d0 fe ff ff 	movq   $0x8,-0x130(%rax)
    160b:	08 00 00 00 
    160f:	48 ba 00 00 00 00 00 	movabs $0x40000000000000,%rdx
    1616:	00 40 00 
    1619:	48 89 90 d8 fe ff ff 	mov    %rdx,-0x128(%rax)
    1620:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    1627:	ff ff 00 00 
    162b:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    1632:	ff ff ff 
    1635:	48 8d 56 0f          	lea    0xf(%rsi),%rdx
    1639:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
    1640:	49 b8 00 00 00 00 01 	movabs $0x100000000,%r8
    1647:	00 00 00 
    164a:	4c 89 43 68          	mov    %r8,0x68(%rbx)
    164e:	4c 89 80 f0 fe ff ff 	mov    %r8,-0x110(%rax)
    1655:	48 89 b0 f8 fe ff ff 	mov    %rsi,-0x108(%rax)
    165c:	4c 89 6b 70          	mov    %r13,0x70(%rbx)
    1660:	48 8d b0 00 ff ff ff 	lea    -0x100(%rax),%rsi
    1667:	48 8d 90 08 ff ff ff 	lea    -0xf8(%rax),%rdx
    166e:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    1675:	00 00 00 
    1678:	48 81 c7 ab f2 0c 00 	add    $0xcf2ab,%rdi
    167f:	e9 64 10 00 00       	jmp    26e8 <f_8001161d0+0x26e8>
    1684:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    168b:	00 00 00 
    168e:	4d 8d 85 0b d1 09 00 	lea    0x9d10b(%r13),%r8
    1695:	eb 24                	jmp    16bb <f_8001161d0+0x16bb>
    1697:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    169e:	00 00 00 
    16a1:	4d 8d 85 2d 8c 01 00 	lea    0x18c2d(%r13),%r8
    16a8:	eb 11                	jmp    16bb <f_8001161d0+0x16bb>
    16aa:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    16b1:	00 00 00 
    16b4:	4d 8d 85 4b 4f 0a 00 	lea    0xa4f4b(%r13),%r8
    16bb:	4c 89 43 68          	mov    %r8,0x68(%rbx)
    16bf:	48 8b bb 00 01 00 00 	mov    0x100(%rbx),%rdi
    16c6:	c7 07 00 00 00 10    	movl   $0x10000000,(%rdi)
    16cc:	4c 8b 9b a0 00 00 00 	mov    0xa0(%rbx),%r11
    16d3:	49 8b 93 f0 31 00 00 	mov    0x31f0(%r11),%rdx
    16da:	48 89 13             	mov    %rdx,(%rbx)
    16dd:	48 be 10 00 00 00 03 	movabs $0x300000010,%rsi
    16e4:	00 00 00 
    16e7:	4c 8d 76 f0          	lea    -0x10(%rsi),%r14
    16eb:	4c 89 77 14          	mov    %r14,0x14(%rdi)
    16ef:	48 c7 43 78 01 00 00 	movq   $0x1,0x78(%rbx)
    16f6:	00 
    16f7:	48 83 c6 f6          	add    $0xfffffffffffffff6,%rsi
    16fb:	48 89 77 04          	mov    %rsi,0x4(%rdi)
    16ff:	48 8b 73 70          	mov    0x70(%rbx),%rsi
    1703:	48 89 77 2c          	mov    %rsi,0x2c(%rdi)
    1707:	48 be 00 00 00 00 ff 	movabs $0xffff00000000,%rsi
    170e:	ff 00 00 
    1711:	48 89 77 0c          	mov    %rsi,0xc(%rdi)
    1715:	49 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r15
    171c:	ff 7f ff 
    171f:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    1723:	48 be 00 00 00 00 01 	movabs $0x100000000,%rsi
    172a:	00 00 00 
    172d:	48 ff ce             	dec    %rsi
    1730:	48 89 77 1c          	mov    %rsi,0x1c(%rdi)
    1734:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    1739:	4c 89 4b 60          	mov    %r9,0x60(%rbx)
    173d:	48 b9 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rcx
    1744:	00 80 3f 
    1747:	48 89 4f 38          	mov    %rcx,0x38(%rdi)
    174b:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    174f:	4c 8b 74 24 10       	mov    0x10(%rsp),%r14
    1754:	4c 89 73 48          	mov    %r14,0x48(%rbx)
    1758:	48 8b 0c 24          	mov    (%rsp),%rcx
    175c:	48 89 4b 50          	mov    %rcx,0x50(%rbx)
    1760:	48 c7 47 24 01 00 00 	movq   $0x1,0x24(%rdi)
    1767:	00 
    1768:	c7 47 34 00 00 00 00 	movl   $0x0,0x34(%rdi)
    176f:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    1776:	4c 89 b6 a4 00 00 00 	mov    %r14,0xa4(%rsi)
    177d:	4c 89 bf 98 00 00 00 	mov    %r15,0x98(%rdi)
    1784:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1788:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    178f:	00 
    1790:	44 89 97 a0 00 00 00 	mov    %r10d,0xa0(%rdi)
    1797:	c7 87 bc 00 00 00 01 	movl   $0x1,0xbc(%rdi)
    179e:	00 00 00 
    17a1:	48 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rax
    17a8:	ff 7f 7f 
    17ab:	48 89 47 78          	mov    %rax,0x78(%rdi)
    17af:	4c 89 bf 80 00 00 00 	mov    %r15,0x80(%rdi)
    17b6:	4c 89 8f 88 00 00 00 	mov    %r9,0x88(%rdi)
    17bd:	48 89 87 90 00 00 00 	mov    %rax,0x90(%rdi)
    17c4:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    17c8:	c5 f8 11 47 58       	vmovups %xmm0,0x58(%rdi)
    17cd:	48 c7 47 68 00 00 00 	movq   $0x0,0x68(%rdi)
    17d4:	00 
    17d5:	4c 89 47 70          	mov    %r8,0x70(%rdi)
    17d9:	48 c7 47 48 00 00 00 	movq   $0x0,0x48(%rdi)
    17e0:	00 
    17e1:	48 89 4f 50          	mov    %rcx,0x50(%rdi)
    17e5:	48 85 d2             	test   %rdx,%rdx
    17e8:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    17ef:	ff ff ff 
    17f2:	0f 84 8a 10 00 00    	je     2882 <f_8001161d0+0x2882>
    17f8:	49 8b 8b c8 1e 00 00 	mov    0x1ec8(%r11),%rcx
    17ff:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1806:	44 0f b6 40 08       	movzbl 0x8(%rax),%r8d
    180b:	44 8b 49 08          	mov    0x8(%rcx),%r9d
    180f:	31 c0                	xor    %eax,%eax
    1811:	45 39 c1             	cmp    %r8d,%r9d
    1814:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    181a:	4d 0f 47 c8          	cmova  %r8,%r9
    181e:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    1822:	48 c7 43 60 e0 3c 00 	movq   $0x3ce0,0x60(%rbx)
    1829:	00 
    182a:	4c 89 4b 58          	mov    %r9,0x58(%rbx)
    182e:	4d 69 c1 e0 3c 00 00 	imul   $0x3ce0,%r9,%r8
    1835:	4d 8d 0c 08          	lea    (%r8,%rcx,1),%r9
    1839:	4c 89 4b 50          	mov    %r9,0x50(%rbx)
    183d:	c4 c1 7a 10 8c 08 08 	vmovss 0x2e08(%r8,%rcx,1),%xmm1
    1844:	2e 00 00 
    1847:	c4 c1 7a 10 94 08 0c 	vmovss 0x2e0c(%r8,%rcx,1),%xmm2
    184e:	2e 00 00 
    1851:	c4 c1 72 5c 9c 08 00 	vsubss 0x2e00(%r8,%rcx,1),%xmm1,%xmm3
    1858:	2e 00 00 
    185b:	c4 c1 6a 5c 94 08 04 	vsubss 0x2e04(%r8,%rcx,1),%xmm2,%xmm2
    1862:	2e 00 00 
    1865:	44 89 97 a0 00 00 00 	mov    %r10d,0xa0(%rdi)
    186c:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
    1873:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
    1877:	c4 e1 fa 2c fb       	vcvttss2si %xmm3,%rdi
    187c:	c5 f0 57 c9          	vxorps %xmm1,%xmm1,%xmm1
    1880:	c5 f8 2e d9          	vucomiss %xmm1,%xmm3
    1884:	0f 42 f8             	cmovb  %eax,%edi
    1887:	c5 fa 10 25 00 00 00 	vmovss 0x0(%rip),%xmm4        # 188f <f_8001161d0+0x188f>
    188e:	00 
    188f:	c5 f8 2e dc          	vucomiss %xmm4,%xmm3
    1893:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    1899:	41 0f 47 f8          	cmova  %r8d,%edi
    189d:	c4 61 fa 2c ca       	vcvttss2si %xmm2,%r9
    18a2:	c5 f8 2e d1          	vucomiss %xmm1,%xmm2
    18a6:	44 0f 42 c8          	cmovb  %eax,%r9d
    18aa:	c5 f8 2e d4          	vucomiss %xmm4,%xmm2
    18ae:	45 0f 47 c8          	cmova  %r8d,%r9d
    18b2:	c4 e1 82 2a d7       	vcvtsi2ss %rdi,%xmm15,%xmm2
    18b7:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    18bb:	4c 89 b6 a4 00 00 00 	mov    %r14,0xa4(%rsi)
    18c2:	c5 ea 59 92 08 03 00 	vmulss 0x308(%rdx),%xmm2,%xmm2
    18c9:	00 
    18ca:	c5 f9 7e d1          	vmovd  %xmm2,%ecx
    18ce:	c4 c1 82 2a d9       	vcvtsi2ss %r9,%xmm15,%xmm3
    18d3:	c5 e2 59 9a 0c 03 00 	vmulss 0x30c(%rdx),%xmm3,%xmm3
    18da:	00 
    18db:	c5 f8 29 83 20 02 00 	vmovaps %xmm0,0x220(%rbx)
    18e2:	00 
    18e3:	c5 f9 7e da          	vmovd  %xmm3,%edx
    18e7:	c5 ea 5f c1          	vmaxss %xmm1,%xmm2,%xmm0
    18eb:	c5 f9 7e c6          	vmovd  %xmm0,%esi
    18ef:	48 89 b3 30 02 00 00 	mov    %rsi,0x230(%rbx)
    18f6:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    18fd:	00 00 00 00 
    1901:	c5 e2 5f e1          	vmaxss %xmm1,%xmm3,%xmm4
    1905:	c5 f9 7e e6          	vmovd  %xmm4,%esi
    1909:	48 89 b3 40 02 00 00 	mov    %rsi,0x240(%rbx)
    1910:	c5 f8 2e d1          	vucomiss %xmm1,%xmm2
    1914:	48 0f 47 c8          	cmova  %rax,%rcx
    1918:	48 c7 83 48 02 00 00 	movq   $0x0,0x248(%rbx)
    191f:	00 00 00 00 
    1923:	48 89 8b 00 02 00 00 	mov    %rcx,0x200(%rbx)
    192a:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    1931:	00 00 00 00 
    1935:	48 8b b3 00 01 00 00 	mov    0x100(%rbx),%rsi
    193c:	c5 fa 11 86 80 00 00 	vmovss %xmm0,0x80(%rsi)
    1943:	00 
    1944:	c5 fa 11 a6 84 00 00 	vmovss %xmm4,0x84(%rsi)
    194b:	00 
    194c:	c5 fa 11 86 98 00 00 	vmovss %xmm0,0x98(%rsi)
    1953:	00 
    1954:	c5 fa 11 a6 9c 00 00 	vmovss %xmm4,0x9c(%rsi)
    195b:	00 
    195c:	c5 f8 2e d9          	vucomiss %xmm1,%xmm3
    1960:	48 0f 47 d0          	cmova  %rax,%rdx
    1964:	48 89 93 10 02 00 00 	mov    %rdx,0x210(%rbx)
    196b:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    1972:	00 00 00 00 
    1976:	89 4e 78             	mov    %ecx,0x78(%rsi)
    1979:	89 56 7c             	mov    %edx,0x7c(%rsi)
    197c:	89 8e 90 00 00 00    	mov    %ecx,0x90(%rsi)
    1982:	89 96 94 00 00 00    	mov    %edx,0x94(%rsi)
    1988:	49 8d 85 5e 18 51 fd 	lea    -0x2aee7a2(%r13),%rax
    198f:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    1996:	48 89 df             	mov    %rbx,%rdi
    1999:	c5 f8 77             	vzeroupper
    199c:	e8 00 00 00 00       	call   19a1 <f_8001161d0+0x19a1>
    19a1:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    19a8:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    19af:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    19b6:	48 89 01             	mov    %rax,(%rcx)
    19b9:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    19c0:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    19c4:	48 89 43 40          	mov    %rax,0x40(%rbx)
    19c8:	88 41 08             	mov    %al,0x8(%rcx)
    19cb:	e9 b2 0e 00 00       	jmp    2882 <f_8001161d0+0x2882>
    19d0:	48 89 93 08 01 00 00 	mov    %rdx,0x108(%rbx)
    19d7:	48 89 df             	mov    %rbx,%rdi
    19da:	48 83 c4 18          	add    $0x18,%rsp
    19de:	5b                   	pop    %rbx
    19df:	41 5c                	pop    %r12
    19e1:	41 5d                	pop    %r13
    19e3:	41 5e                	pop    %r14
    19e5:	41 5f                	pop    %r15
    19e7:	5d                   	pop    %rbp
    19e8:	c5 f8 77             	vzeroupper
    19eb:	e9 00 00 00 00       	jmp    19f0 <f_8001161d0+0x19f0>
    19f0:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    19f7:	00 
    19f8:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    19ff:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    1a06:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    1a0a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    1a0e:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1a13:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    1a1a:	48 89 03             	mov    %rax,(%rbx)
    1a1d:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
    1a24:	00 
    1a25:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1a2c:	00 00 00 
    1a2f:	49 8d 85 ae 18 51 fd 	lea    -0x2aee752(%r13),%rax
    1a36:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    1a3d:	48 89 df             	mov    %rbx,%rdi
    1a40:	c5 f8 77             	vzeroupper
    1a43:	e8 00 00 00 00       	call   1a48 <f_8001161d0+0x1a48>
    1a48:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    1a4f:	ff ff ff 
    1a52:	e9 2b 0e 00 00       	jmp    2882 <f_8001161d0+0x2882>
    1a57:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    1a5e:	00 
    1a5f:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1a66:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    1a6d:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    1a71:	48 89 43 10          	mov    %rax,0x10(%rbx)
    1a75:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1a7a:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    1a81:	48 89 03             	mov    %rax,(%rbx)
    1a84:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1a8b:	00 00 00 
    1a8e:	49 8d 85 ce 18 51 fd 	lea    -0x2aee732(%r13),%rax
    1a95:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    1a9c:	48 89 df             	mov    %rbx,%rdi
    1a9f:	c5 f8 77             	vzeroupper
    1aa2:	e8 00 00 00 00       	call   1aa7 <f_8001161d0+0x1aa7>
    1aa7:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    1aae:	ff ff ff 
    1ab1:	e9 cc 0d 00 00       	jmp    2882 <f_8001161d0+0x2882>
    1ab6:	48 8b 93 a0 00 00 00 	mov    0xa0(%rbx),%rdx
    1abd:	48 8b 92 c8 1e 00 00 	mov    0x1ec8(%rdx),%rdx
    1ac4:	48 89 53 70          	mov    %rdx,0x70(%rbx)
    1ac8:	49 bb 00 00 00 00 01 	movabs $0x100000000,%r11
    1acf:	00 00 00 
    1ad2:	4c 89 1b             	mov    %r11,(%rbx)
    1ad5:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1ad9:	48 8b b3 00 01 00 00 	mov    0x100(%rbx),%rsi
    1ae0:	48 c7 06 04 00 00 00 	movq   $0x4,(%rsi)
    1ae7:	48 bf 00 00 00 00 00 	movabs $0x40000000000000,%rdi
    1aee:	00 40 00 
    1af1:	48 ff c7             	inc    %rdi
    1af4:	48 89 7e 08          	mov    %rdi,0x8(%rsi)
    1af8:	4c 89 5e 20          	mov    %r11,0x20(%rsi)
    1afc:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    1b03:	ff ff ff 
    1b06:	48 89 6e 28          	mov    %rbp,0x28(%rsi)
    1b0a:	4c 89 e9             	mov    %r13,%rcx
    1b0d:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1b14:	00 00 00 
    1b17:	4d 8d 85 25 74 0d 00 	lea    0xd7425(%r13),%r8
    1b1e:	4c 89 43 68          	mov    %r8,0x68(%rbx)
    1b22:	49 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r14
    1b29:	ff 7f ff 
    1b2c:	4c 89 b6 80 00 00 00 	mov    %r14,0x80(%rsi)
    1b33:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    1b38:	48 89 be 88 00 00 00 	mov    %rdi,0x88(%rsi)
    1b3f:	48 8b bb c0 00 00 00 	mov    0xc0(%rbx),%rdi
    1b46:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    1b4b:	4c 89 8f a4 00 00 00 	mov    %r9,0xa4(%rdi)
    1b52:	49 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r9
    1b59:	ff 7f 7f 
    1b5c:	4c 89 8e 90 00 00 00 	mov    %r9,0x90(%rsi)
    1b63:	4c 89 b6 98 00 00 00 	mov    %r14,0x98(%rsi)
    1b6a:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 1b72 <f_8001161d0+0x1b72>
    1b71:	00 
    1b72:	c5 fc 11 43 78       	vmovups %ymm0,0x78(%rbx)
    1b77:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1b7e:	00 
    1b7f:	44 89 96 a0 00 00 00 	mov    %r10d,0xa0(%rsi)
    1b86:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1b8d:	0f b6 78 08          	movzbl 0x8(%rax),%edi
    1b91:	c7 86 bc 00 00 00 03 	movl   $0x3,0xbc(%rsi)
    1b98:	00 00 00 
    1b9b:	48 c7 46 10 ff ff 00 	movq   $0xffff,0x10(%rsi)
    1ba2:	00 
    1ba3:	48 8d 45 17          	lea    0x17(%rbp),%rax
    1ba7:	48 89 46 18          	mov    %rax,0x18(%rsi)
    1bab:	48 c7 46 68 00 00 00 	movq   $0x0,0x68(%rsi)
    1bb2:	00 
    1bb3:	49 8d 43 ff          	lea    -0x1(%r11),%rax
    1bb7:	48 89 46 30          	mov    %rax,0x30(%rsi)
    1bbb:	48 89 4e 38          	mov    %rcx,0x38(%rsi)
    1bbf:	48 89 4e 40          	mov    %rcx,0x40(%rsi)
    1bc3:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    1bca:	00 
    1bcb:	48 8b 04 24          	mov    (%rsp),%rax
    1bcf:	48 89 46 50          	mov    %rax,0x50(%rsi)
    1bd3:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1bd7:	c5 f8 11 46 58       	vmovups %xmm0,0x58(%rsi)
    1bdc:	4c 89 46 70          	mov    %r8,0x70(%rsi)
    1be0:	4c 89 4e 78          	mov    %r9,0x78(%rsi)
    1be4:	48 8b 42 10          	mov    0x10(%rdx),%rax
    1be8:	48 69 cf e0 3c 00 00 	imul   $0x3ce0,%rdi,%rcx
    1bef:	31 f6                	xor    %esi,%esi
    1bf1:	39 7a 08             	cmp    %edi,0x8(%rdx)
    1bf4:	ba 00 00 00 00       	mov    $0x0,%edx
    1bf9:	48 0f 47 d1          	cmova  %rcx,%rdx
    1bfd:	4c 8b 84 02 68 33 00 	mov    0x3368(%rdx,%rax,1),%r8
    1c04:	00 
    1c05:	4c 89 43 60          	mov    %r8,0x60(%rbx)
    1c09:	48 8b 84 02 60 33 00 	mov    0x3360(%rdx,%rax,1),%rax
    1c10:	00 
    1c11:	48 8b 53 48          	mov    0x48(%rbx),%rdx
    1c15:	48 89 02             	mov    %rax,(%rdx)
    1c18:	4c 89 42 08          	mov    %r8,0x8(%rdx)
    1c1c:	48 8b 43 70          	mov    0x70(%rbx),%rax
    1c20:	48 8b 93 d0 00 00 00 	mov    0xd0(%rbx),%rdx
    1c27:	44 8b 40 08          	mov    0x8(%rax),%r8d
    1c2b:	41 39 f8             	cmp    %edi,%r8d
    1c2e:	48 0f 47 f1          	cmova  %rcx,%rsi
    1c32:	48 8b 48 10          	mov    0x10(%rax),%rcx
    1c36:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    1c3a:	48 8b bc 0e e8 35 00 	mov    0x35e8(%rsi,%rcx,1),%rdi
    1c41:	00 
    1c42:	48 89 7b 48          	mov    %rdi,0x48(%rbx)
    1c46:	4c 8b 84 0e e0 35 00 	mov    0x35e0(%rsi,%rcx,1),%r8
    1c4d:	00 
    1c4e:	4c 89 43 50          	mov    %r8,0x50(%rbx)
    1c52:	4c 89 02             	mov    %r8,(%rdx)
    1c55:	48 89 7a 08          	mov    %rdi,0x8(%rdx)
    1c59:	8b 94 0e f8 35 00 00 	mov    0x35f8(%rsi,%rcx,1),%edx
    1c60:	48 8b 8c 0e f0 35 00 	mov    0x35f0(%rsi,%rcx,1),%rcx
    1c67:	00 
    1c68:	48 8b b3 c8 00 00 00 	mov    0xc8(%rbx),%rsi
    1c6f:	48 89 0e             	mov    %rcx,(%rsi)
    1c72:	89 56 08             	mov    %edx,0x8(%rsi)
    1c75:	8b 48 44             	mov    0x44(%rax),%ecx
    1c78:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    1c7c:	48 83 c0 3c          	add    $0x3c,%rax
    1c80:	8b 00                	mov    (%rax),%eax
    1c82:	48 89 43 48          	mov    %rax,0x48(%rbx)
    1c86:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    1c8d:	88 8a b0 00 00 00    	mov    %cl,0xb0(%rdx)
    1c93:	c7 82 b4 00 00 00 00 	movl   $0x0,0xb4(%rdx)
    1c9a:	00 00 00 
    1c9d:	48 8b 8b c0 00 00 00 	mov    0xc0(%rbx),%rcx
    1ca4:	c7 81 b1 00 00 00 00 	movl   $0x0,0xb1(%rcx)
    1cab:	00 00 00 
    1cae:	88 82 b8 00 00 00    	mov    %al,0xb8(%rdx)
    1cb4:	e9 c9 0b 00 00       	jmp    2882 <f_8001161d0+0x2882>
    1cb9:	49 89 cf             	mov    %rcx,%r15
    1cbc:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    1cc3:	00 
    1cc4:	48 c7 80 d0 fe ff ff 	movq   $0x100,-0x130(%rax)
    1ccb:	00 01 00 00 
    1ccf:	48 ba 00 00 00 00 00 	movabs $0x40000000000000,%rdx
    1cd6:	00 40 00 
    1cd9:	48 89 90 d8 fe ff ff 	mov    %rdx,-0x128(%rax)
    1ce0:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    1ce7:	ff ff 00 00 
    1ceb:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    1cf2:	ff ff ff 
    1cf5:	48 8d 56 13          	lea    0x13(%rsi),%rdx
    1cf9:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
    1d00:	49 b8 00 00 00 00 01 	movabs $0x100000000,%r8
    1d07:	00 00 00 
    1d0a:	4c 89 43 68          	mov    %r8,0x68(%rbx)
    1d0e:	4c 89 80 f0 fe ff ff 	mov    %r8,-0x110(%rax)
    1d15:	48 89 b0 f8 fe ff ff 	mov    %rsi,-0x108(%rax)
    1d1c:	4c 89 6b 70          	mov    %r13,0x70(%rbx)
    1d20:	48 8d b0 00 ff ff ff 	lea    -0x100(%rax),%rsi
    1d27:	48 8d 90 08 ff ff ff 	lea    -0xf8(%rax),%rdx
    1d2e:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    1d35:	00 00 00 
    1d38:	48 81 c7 a1 6f fe ff 	add    $0xfffffffffffe6fa1,%rdi
    1d3f:	e9 a4 09 00 00       	jmp    26e8 <f_8001161d0+0x26e8>
    1d44:	48 c7 43 68 00 10 00 	movq   $0x1000,0x68(%rbx)
    1d4b:	00 
    1d4c:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    1d53:	00 
    1d54:	48 c7 80 d0 fe ff ff 	movq   $0x1000,-0x130(%rax)
    1d5b:	00 10 00 00 
    1d5f:	48 c7 80 d8 fe ff ff 	movq   $0x1,-0x128(%rax)
    1d66:	01 00 00 00 
    1d6a:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    1d71:	ff ff 00 00 
    1d75:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    1d7c:	ff ff ff 
    1d7f:	48 8d 55 0c          	lea    0xc(%rbp),%rdx
    1d83:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
    1d8a:	49 bb 00 00 00 00 01 	movabs $0x100000000,%r11
    1d91:	00 00 00 
    1d94:	4c 89 98 f0 fe ff ff 	mov    %r11,-0x110(%rax)
    1d9b:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
    1da2:	4c 89 6b 70          	mov    %r13,0x70(%rbx)
    1da6:	49 8d 53 ff          	lea    -0x1(%r11),%rdx
    1daa:	48 89 90 00 ff ff ff 	mov    %rdx,-0x100(%rax)
    1db1:	4c 89 a8 08 ff ff ff 	mov    %r13,-0xf8(%rax)
    1db8:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    1dbf:	4c 89 e9             	mov    %r13,%rcx
    1dc2:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1dc9:	00 00 00 
    1dcc:	4d 8d 85 b2 a4 03 00 	lea    0x3a4b2(%r13),%r8
    1dd3:	44 89 92 a0 00 00 00 	mov    %r10d,0xa0(%rdx)
    1dda:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
    1de1:	48 8b be d0 2f 00 00 	mov    0x2fd0(%rsi),%rdi
    1de8:	48 89 7b 40          	mov    %rdi,0x40(%rbx)
    1dec:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    1df1:	4c 89 4b 60          	mov    %r9,0x60(%rbx)
    1df5:	4c 89 42 70          	mov    %r8,0x70(%rdx)
    1df9:	49 be ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r14
    1e00:	ff 7f 7f 
    1e03:	4c 89 72 78          	mov    %r14,0x78(%rdx)
    1e07:	49 ba ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r10
    1e0e:	ff 7f ff 
    1e11:	4c 89 53 68          	mov    %r10,0x68(%rbx)
    1e15:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1e19:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1e20:	00 
    1e21:	c7 82 bc 00 00 00 00 	movl   $0x0,0xbc(%rdx)
    1e28:	00 00 00 
    1e2b:	4c 89 92 80 00 00 00 	mov    %r10,0x80(%rdx)
    1e32:	4c 89 8a 88 00 00 00 	mov    %r9,0x88(%rdx)
    1e39:	4c 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%r8
    1e40:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    1e45:	4d 89 88 a4 00 00 00 	mov    %r9,0xa4(%r8)
    1e4c:	48 89 4a 40          	mov    %rcx,0x40(%rdx)
    1e50:	48 c7 42 48 00 00 00 	movq   $0x0,0x48(%rdx)
    1e57:	00 
    1e58:	4c 89 b2 90 00 00 00 	mov    %r14,0x90(%rdx)
    1e5f:	4c 89 92 98 00 00 00 	mov    %r10,0x98(%rdx)
    1e66:	48 c7 42 68 00 00 00 	movq   $0x0,0x68(%rdx)
    1e6d:	00 
    1e6e:	48 8b 0c 24          	mov    (%rsp),%rcx
    1e72:	48 89 4a 50          	mov    %rcx,0x50(%rdx)
    1e76:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1e7a:	c5 f8 11 42 58       	vmovups %xmm0,0x58(%rdx)
    1e7f:	48 85 ff             	test   %rdi,%rdi
    1e82:	0f 84 ed 0d 00 00    	je     2c75 <f_8001161d0+0x2c75>
    1e88:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    1e8f:	44 0f b6 41 08       	movzbl 0x8(%rcx),%r8d
    1e94:	48 c7 43 68 e0 3c 00 	movq   $0x3ce0,0x68(%rbx)
    1e9b:	00 
    1e9c:	4c 8b 4f 18          	mov    0x18(%rdi),%r9
    1ea0:	4d 69 d0 60 0f 00 00 	imul   $0xf60,%r8,%r10
    1ea7:	31 c9                	xor    %ecx,%ecx
    1ea9:	44 39 47 10          	cmp    %r8d,0x10(%rdi)
    1ead:	4c 0f 46 d1          	cmovbe %rcx,%r10
    1eb1:	43 8b bc 0a 9c 02 00 	mov    0x29c(%r10,%r9,1),%edi
    1eb8:	00 
    1eb9:	4c 09 df             	or     %r11,%rdi
    1ebc:	48 89 7a 1c          	mov    %rdi,0x1c(%rdx)
    1ec0:	c7 82 bc 00 00 00 02 	movl   $0x2,0xbc(%rdx)
    1ec7:	00 00 00 
    1eca:	48 8b 96 c8 1e 00 00 	mov    0x1ec8(%rsi),%rdx
    1ed1:	48 8b 72 10          	mov    0x10(%rdx),%rsi
    1ed5:	49 69 f8 e0 3c 00 00 	imul   $0x3ce0,%r8,%rdi
    1edc:	44 39 42 08          	cmp    %r8d,0x8(%rdx)
    1ee0:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    1ee6:	4c 0f 47 cf          	cmova  %rdi,%r9
    1eea:	4e 8b 94 0e b8 30 00 	mov    0x30b8(%rsi,%r9,1),%r10
    1ef1:	00 
    1ef2:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    1ef6:	4a 8b b4 0e b0 30 00 	mov    0x30b0(%rsi,%r9,1),%rsi
    1efd:	00 
    1efe:	48 89 73 58          	mov    %rsi,0x58(%rbx)
    1f02:	48 89 b0 48 ff ff ff 	mov    %rsi,-0xb8(%rax)
    1f09:	4c 89 90 50 ff ff ff 	mov    %r10,-0xb0(%rax)
    1f10:	44 39 42 08          	cmp    %r8d,0x8(%rdx)
    1f14:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    1f18:	48 0f 47 cf          	cmova  %rdi,%rcx
    1f1c:	48 8d 34 11          	lea    (%rcx,%rdx,1),%rsi
    1f20:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    1f24:	48 8b b4 11 30 33 00 	mov    0x3330(%rcx,%rdx,1),%rsi
    1f2b:	00 
    1f2c:	48 8b bc 11 38 33 00 	mov    0x3338(%rcx,%rdx,1),%rdi
    1f33:	00 
    1f34:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    1f38:	48 89 b0 60 ff ff ff 	mov    %rsi,-0xa0(%rax)
    1f3f:	48 89 b8 68 ff ff ff 	mov    %rdi,-0x98(%rax)
    1f46:	8b b4 11 48 33 00 00 	mov    0x3348(%rcx,%rdx,1),%esi
    1f4d:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    1f51:	48 8b 8c 11 40 33 00 	mov    0x3340(%rcx,%rdx,1),%rcx
    1f58:	00 
    1f59:	48 89 88 70 ff ff ff 	mov    %rcx,-0x90(%rax)
    1f60:	89 b0 78 ff ff ff    	mov    %esi,-0x88(%rax)
    1f66:	e9 17 09 00 00       	jmp    2882 <f_8001161d0+0x2882>
    1f6b:	49 8b b4 24 c8 1e 00 	mov    0x1ec8(%r12),%rsi
    1f72:	00 
    1f73:	48 89 73 08          	mov    %rsi,0x8(%rbx)
    1f77:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    1f7c:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
    1f80:	45 0f b6 46 08       	movzbl 0x8(%r14),%r8d
    1f85:	4c 89 43 68          	mov    %r8,0x68(%rbx)
    1f89:	8b 7e 08             	mov    0x8(%rsi),%edi
    1f8c:	4d 69 d8 e0 3c 00 00 	imul   $0x3ce0,%r8,%r11
    1f93:	31 d2                	xor    %edx,%edx
    1f95:	44 39 c7             	cmp    %r8d,%edi
    1f98:	bf 00 00 00 00       	mov    $0x0,%edi
    1f9d:	49 0f 47 fb          	cmova  %r11,%rdi
    1fa1:	4c 8b 76 10          	mov    0x10(%rsi),%r14
    1fa5:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
    1fac:	00 
    1fad:	4a 8b bc 37 40 3c 00 	mov    0x3c40(%rdi,%r14,1),%rdi
    1fb4:	00 
    1fb5:	48 89 bb b0 00 00 00 	mov    %rdi,0xb0(%rbx)
    1fbc:	44 89 90 70 ff ff ff 	mov    %r10d,-0x90(%rax)
    1fc3:	48 89 88 58 ff ff ff 	mov    %rcx,-0xa8(%rax)
    1fca:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
    1fd1:	ff 7f 7f 
    1fd4:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
    1fdb:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1fe2:	00 
    1fe3:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1fe7:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
    1fee:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
    1ff5:	00 00 00 00 
    1ff9:	48 8b 0c 24          	mov    (%rsp),%rcx
    1ffd:	48 89 88 20 ff ff ff 	mov    %rcx,-0xe0(%rax)
    2004:	48 c7 43 40 06 00 00 	movq   $0x6,0x40(%rbx)
    200b:	00 
    200c:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2010:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
    2017:	ff 
    2018:	48 c7 80 00 ff ff ff 	movq   $0x6,-0x100(%rax)
    201f:	06 00 00 00 
    2023:	48 b9 10 00 00 00 03 	movabs $0x300000010,%rcx
    202a:	00 00 00 
    202d:	48 83 c1 10          	add    $0x10,%rcx
    2031:	48 89 88 d0 fe ff ff 	mov    %rcx,-0x130(%rax)
    2038:	48 b9 00 00 00 00 01 	movabs $0x40000100000000,%rcx
    203f:	00 40 00 
    2042:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    2049:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    2050:	ff ff 00 00 
    2054:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    205b:	ff ff ff 
    205e:	48 8d 4d 09          	lea    0x9(%rbp),%rcx
    2062:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    2069:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2070:	00 00 00 
    2073:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    207a:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
    2081:	48 8b 8b c0 00 00 00 	mov    0xc0(%rbx),%rcx
    2088:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    208d:	4c 89 89 a4 00 00 00 	mov    %r9,0xa4(%rcx)
    2094:	4c 89 a8 08 ff ff ff 	mov    %r13,-0xf8(%rax)
    209b:	4c 89 a8 10 ff ff ff 	mov    %r13,-0xf0(%rax)
    20a2:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    20a9:	00 00 00 
    20ac:	49 8d 8d af c7 07 00 	lea    0x7c7af(%r13),%rcx
    20b3:	48 89 4b 78          	mov    %rcx,0x78(%rbx)
    20b7:	49 b9 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r9
    20be:	ff 7f ff 
    20c1:	4c 89 8b 80 00 00 00 	mov    %r9,0x80(%rbx)
    20c8:	4c 89 88 68 ff ff ff 	mov    %r9,-0x98(%rax)
    20cf:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
    20d6:	4c 89 88 50 ff ff ff 	mov    %r9,-0xb0(%rax)
    20dd:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
    20e4:	00 00 00 00 
    20e8:	48 89 88 40 ff ff ff 	mov    %rcx,-0xc0(%rax)
    20ef:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    20f3:	44 39 46 08          	cmp    %r8d,0x8(%rsi)
    20f7:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    20fd:	4d 0f 47 cb          	cmova  %r11,%r9
    2101:	c4 a1 78 10 84 09 00 	vmovups 0x2e00(%rcx,%r9,1),%xmm0
    2108:	2e 00 00 
    210b:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
    2112:	ff 
    2113:	44 39 46 08          	cmp    %r8d,0x8(%rsi)
    2117:	49 0f 47 d3          	cmova  %r11,%rdx
    211b:	48 03 56 10          	add    0x10(%rsi),%rdx
    211f:	48 8b 82 80 30 00 00 	mov    0x3080(%rdx),%rax
    2126:	48 89 3b             	mov    %rdi,(%rbx)
    2129:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
    2130:	00 
    2131:	48 8b 8a 88 30 00 00 	mov    0x3088(%rdx),%rcx
    2138:	48 89 4b 50          	mov    %rcx,0x50(%rbx)
    213c:	48 8b b3 d0 00 00 00 	mov    0xd0(%rbx),%rsi
    2143:	48 89 06             	mov    %rax,(%rsi)
    2146:	48 89 4e 08          	mov    %rcx,0x8(%rsi)
    214a:	48 8b 82 90 30 00 00 	mov    0x3090(%rdx),%rax
    2151:	48 89 43 48          	mov    %rax,0x48(%rbx)
    2155:	8b 8a 98 30 00 00    	mov    0x3098(%rdx),%ecx
    215b:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
    2162:	89 4a 08             	mov    %ecx,0x8(%rdx)
    2165:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
    216c:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
    2170:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    2174:	48 89 02             	mov    %rax,(%rdx)
    2177:	49 8d 85 ea 0b 51 fd 	lea    -0x2aef416(%r13),%rax
    217e:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    2185:	48 89 df             	mov    %rbx,%rdi
    2188:	c5 f8 77             	vzeroupper
    218b:	e8 00 00 00 00       	call   2190 <f_8001161d0+0x2190>
    2190:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2197:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    219e:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    21a5:	48 89 01             	mov    %rax,(%rcx)
    21a8:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
    21af:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
    21b6:	48 8b b0 04 16 00 00 	mov    0x1604(%rax),%rsi
    21bd:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
    21c1:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    21c5:	88 51 08             	mov    %dl,0x8(%rcx)
    21c8:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    21cf:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
    21d3:	8b 80 0c 16 00 00    	mov    0x160c(%rax),%eax
    21d9:	48 89 43 40          	mov    %rax,0x40(%rbx)
    21dd:	48 c7 43 48 02 00 00 	movq   $0x2,0x48(%rbx)
    21e4:	00 
    21e5:	89 41 24             	mov    %eax,0x24(%rcx)
    21e8:	c7 81 bc 00 00 00 02 	movl   $0x2,0xbc(%rcx)
    21ef:	00 00 00 
    21f2:	e9 8b 06 00 00       	jmp    2882 <f_8001161d0+0x2882>
    21f7:	49 89 cf             	mov    %rcx,%r15
    21fa:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    2201:	00 
    2202:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    2209:	48 c7 02 80 00 00 00 	movq   $0x80,(%rdx)
    2210:	48 be 00 00 00 00 00 	movabs $0x60000000000000,%rsi
    2217:	00 60 00 
    221a:	48 89 72 08          	mov    %rsi,0x8(%rdx)
    221e:	48 c7 42 10 ff ff 00 	movq   $0xffff,0x10(%rdx)
    2225:	00 
    2226:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    222d:	ff ff ff 
    2230:	48 8d 77 12          	lea    0x12(%rdi),%rsi
    2234:	48 89 72 18          	mov    %rsi,0x18(%rdx)
    2238:	4c 89 42 20          	mov    %r8,0x20(%rdx)
    223c:	48 89 7a 28          	mov    %rdi,0x28(%rdx)
    2240:	49 8d 70 ff          	lea    -0x1(%r8),%rsi
    2244:	48 89 73 68          	mov    %rsi,0x68(%rbx)
    2248:	4c 89 6b 70          	mov    %r13,0x70(%rbx)
    224c:	48 8d 72 30          	lea    0x30(%rdx),%rsi
    2250:	48 83 c2 38          	add    $0x38,%rdx
    2254:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    225b:	00 00 00 
    225e:	48 81 c7 6d 4f 0a 00 	add    $0xa4f6d,%rdi
    2265:	e9 7e 04 00 00       	jmp    26e8 <f_8001161d0+0x26e8>
    226a:	48 8b 93 98 00 00 00 	mov    0x98(%rbx),%rdx
    2271:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
    2278:	48 8b b6 c8 1e 00 00 	mov    0x1ec8(%rsi),%rsi
    227f:	48 89 73 08          	mov    %rsi,0x8(%rbx)
    2283:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2288:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
    228c:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
    2293:	00 
    2294:	0f b6 7a 08          	movzbl 0x8(%rdx),%edi
    2298:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    229c:	44 8b 46 08          	mov    0x8(%rsi),%r8d
    22a0:	4c 69 df e0 3c 00 00 	imul   $0x3ce0,%rdi,%r11
    22a7:	31 d2                	xor    %edx,%edx
    22a9:	41 39 f8             	cmp    %edi,%r8d
    22ac:	4c 0f 46 da          	cmovbe %rdx,%r11
    22b0:	48 8b 76 10          	mov    0x10(%rsi),%rsi
    22b4:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
    22bb:	00 
    22bc:	49 8b b4 33 40 3c 00 	mov    0x3c40(%r11,%rsi,1),%rsi
    22c3:	00 
    22c4:	48 89 33             	mov    %rsi,(%rbx)
    22c7:	48 8b b3 00 01 00 00 	mov    0x100(%rbx),%rsi
    22ce:	44 89 96 a0 00 00 00 	mov    %r10d,0xa0(%rsi)
    22d5:	48 89 8e 88 00 00 00 	mov    %rcx,0x88(%rsi)
    22dc:	48 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rcx
    22e3:	ff 7f 7f 
    22e6:	48 89 8e 90 00 00 00 	mov    %rcx,0x90(%rsi)
    22ed:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    22f4:	00 
    22f5:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    22f9:	c7 86 bc 00 00 00 00 	movl   $0x0,0xbc(%rsi)
    2300:	00 00 00 
    2303:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2307:	c5 f8 11 46 58       	vmovups %xmm0,0x58(%rsi)
    230c:	48 c7 06 20 00 00 00 	movq   $0x20,(%rsi)
    2313:	48 b8 00 00 00 00 00 	movabs $0x42080000000000,%rax
    231a:	08 42 00 
    231d:	48 89 46 08          	mov    %rax,0x8(%rsi)
    2321:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    2328:	00 
    2329:	48 8b 04 24          	mov    (%rsp),%rax
    232d:	48 89 46 50          	mov    %rax,0x50(%rsi)
    2331:	48 c7 46 30 07 00 00 	movq   $0x7,0x30(%rsi)
    2338:	00 
    2339:	48 c7 46 10 ff ff 00 	movq   $0xffff,0x10(%rsi)
    2340:	00 
    2341:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    2348:	ff ff ff 
    234b:	48 8d 45 0a          	lea    0xa(%rbp),%rax
    234f:	48 89 46 18          	mov    %rax,0x18(%rsi)
    2353:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    235a:	00 00 00 
    235d:	48 89 46 20          	mov    %rax,0x20(%rsi)
    2361:	48 89 6e 28          	mov    %rbp,0x28(%rsi)
    2365:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    236c:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    2371:	48 89 88 a4 00 00 00 	mov    %rcx,0xa4(%rax)
    2378:	4c 89 6e 38          	mov    %r13,0x38(%rsi)
    237c:	4c 89 6e 40          	mov    %r13,0x40(%rsi)
    2380:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    2387:	00 00 00 
    238a:	49 8d 85 c5 e4 0b 00 	lea    0xbe4c5(%r13),%rax
    2391:	48 89 43 78          	mov    %rax,0x78(%rbx)
    2395:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    239c:	ff 7f ff 
    239f:	48 89 bb 80 00 00 00 	mov    %rdi,0x80(%rbx)
    23a6:	48 89 be 98 00 00 00 	mov    %rdi,0x98(%rsi)
    23ad:	48 8b 4b 58          	mov    0x58(%rbx),%rcx
    23b1:	48 89 4e 78          	mov    %rcx,0x78(%rsi)
    23b5:	48 89 be 80 00 00 00 	mov    %rdi,0x80(%rsi)
    23bc:	48 c7 46 68 00 00 00 	movq   $0x0,0x68(%rsi)
    23c3:	00 
    23c4:	48 89 46 70          	mov    %rax,0x70(%rsi)
    23c8:	48 8b 43 08          	mov    0x8(%rbx),%rax
    23cc:	48 8b 48 10          	mov    0x10(%rax),%rcx
    23d0:	48 8b 73 68          	mov    0x68(%rbx),%rsi
    23d4:	89 f7                	mov    %esi,%edi
    23d6:	39 70 08             	cmp    %esi,0x8(%rax)
    23d9:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    23df:	4c 0f 47 c7          	cmova  %rdi,%r8
    23e3:	44 8b 4b 70          	mov    0x70(%rbx),%r9d
    23e7:	4d 0f af c1          	imul   %r9,%r8
    23eb:	c4 c1 78 10 84 08 b0 	vmovups 0x30b0(%r8,%rcx,1),%xmm0
    23f2:	30 00 00 
    23f5:	48 8b 4b 48          	mov    0x48(%rbx),%rcx
    23f9:	c5 f8 11 01          	vmovups %xmm0,(%rcx)
    23fd:	39 70 08             	cmp    %esi,0x8(%rax)
    2400:	48 0f 47 d7          	cmova  %rdi,%rdx
    2404:	48 8b 40 10          	mov    0x10(%rax),%rax
    2408:	49 0f af d1          	imul   %r9,%rdx
    240c:	48 8b 8c 02 30 33 00 	mov    0x3330(%rdx,%rax,1),%rcx
    2413:	00 
    2414:	48 8b b4 02 38 33 00 	mov    0x3338(%rdx,%rax,1),%rsi
    241b:	00 
    241c:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    2420:	48 8b bb d0 00 00 00 	mov    0xd0(%rbx),%rdi
    2427:	48 89 0f             	mov    %rcx,(%rdi)
    242a:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    242e:	48 8b 8c 02 40 33 00 	mov    0x3340(%rdx,%rax,1),%rcx
    2435:	00 
    2436:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    243a:	8b 84 02 48 33 00 00 	mov    0x3348(%rdx,%rax,1),%eax
    2441:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
    2448:	89 42 08             	mov    %eax,0x8(%rdx)
    244b:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    2452:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    2456:	48 89 43 40          	mov    %rax,0x40(%rbx)
    245a:	48 89 0a             	mov    %rcx,(%rdx)
    245d:	49 8d 85 72 0d 51 fd 	lea    -0x2aef28e(%r13),%rax
    2464:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    246b:	48 89 df             	mov    %rbx,%rdi
    246e:	c5 f8 77             	vzeroupper
    2471:	e8 00 00 00 00       	call   2476 <f_8001161d0+0x2476>
    2476:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    247d:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    2484:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    248b:	48 89 01             	mov    %rax,(%rcx)
    248e:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    2495:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    2499:	48 89 43 40          	mov    %rax,0x40(%rbx)
    249d:	88 41 08             	mov    %al,0x8(%rcx)
    24a0:	ba bc 00 00 00       	mov    $0xbc,%edx
    24a5:	48 03 93 00 01 00 00 	add    0x100(%rbx),%rdx
    24ac:	e9 cb 07 00 00       	jmp    2c7c <f_8001161d0+0x2c7c>
    24b1:	49 89 cf             	mov    %rcx,%r15
    24b4:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    24b8:	4c 8b b3 00 01 00 00 	mov    0x100(%rbx),%r14
    24bf:	49 c7 06 01 00 00 00 	movq   $0x1,(%r14)
    24c6:	48 ba 00 00 00 00 00 	movabs $0x40000000000000,%rdx
    24cd:	00 40 00 
    24d0:	49 89 56 08          	mov    %rdx,0x8(%r14)
    24d4:	49 c7 46 10 ff ff 00 	movq   $0xffff,0x10(%r14)
    24db:	00 
    24dc:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    24e3:	ff ff ff 
    24e6:	48 8d 56 15          	lea    0x15(%rsi),%rdx
    24ea:	49 89 56 18          	mov    %rdx,0x18(%r14)
    24ee:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    24f5:	00 
    24f6:	4d 89 46 20          	mov    %r8,0x20(%r14)
    24fa:	49 89 76 28          	mov    %rsi,0x28(%r14)
    24fe:	49 8d 40 ff          	lea    -0x1(%r8),%rax
    2502:	49 89 46 30          	mov    %rax,0x30(%r14)
    2506:	4d 89 6e 38          	mov    %r13,0x38(%r14)
    250a:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    2511:	00 00 00 
    2514:	48 8d 80 7c 4f 0a 00 	lea    0xa4f7c(%rax),%rax
    251b:	49 89 46 70          	mov    %rax,0x70(%r14)
    251f:	48 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rcx
    2526:	ff 7f 7f 
    2529:	49 89 4e 78          	mov    %rcx,0x78(%r14)
    252d:	48 ba ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdx
    2534:	ff 7f ff 
    2537:	49 89 96 80 00 00 00 	mov    %rdx,0x80(%r14)
    253e:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2543:	49 89 86 88 00 00 00 	mov    %rax,0x88(%r14)
    254a:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 2552 <f_8001161d0+0x2552>
    2551:	00 
    2552:	c5 fc 11 43 60       	vmovups %ymm0,0x60(%rbx)
    2557:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    255e:	4c 89 98 a4 00 00 00 	mov    %r11,0xa4(%rax)
    2565:	4d 89 6e 40          	mov    %r13,0x40(%r14)
    2569:	49 c7 46 48 00 00 00 	movq   $0x0,0x48(%r14)
    2570:	00 
    2571:	49 89 8e 90 00 00 00 	mov    %rcx,0x90(%r14)
    2578:	49 89 96 98 00 00 00 	mov    %rdx,0x98(%r14)
    257f:	49 c7 46 68 00 00 00 	movq   $0x0,0x68(%r14)
    2586:	00 
    2587:	48 8b 0c 24          	mov    (%rsp),%rcx
    258b:	49 89 4e 50          	mov    %rcx,0x50(%r14)
    258f:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2593:	c4 c1 78 11 46 58    	vmovups %xmm0,0x58(%r14)
    2599:	48 c7 43 50 03 00 00 	movq   $0x3,0x50(%rbx)
    25a0:	00 
    25a1:	b9 03 00 00 00       	mov    $0x3,%ecx
    25a6:	e9 e4 01 00 00       	jmp    278f <f_8001161d0+0x278f>
    25ab:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    25b2:	00 
    25b3:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    25ba:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    25c1:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    25c5:	48 89 43 10          	mov    %rax,0x10(%rbx)
    25c9:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    25ce:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    25d5:	48 89 03             	mov    %rax,(%rbx)
    25d8:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    25df:	00 00 00 
    25e2:	49 8d 85 2e 0c 51 fd 	lea    -0x2aef3d2(%r13),%rax
    25e9:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    25f0:	48 89 df             	mov    %rbx,%rdi
    25f3:	c5 f8 77             	vzeroupper
    25f6:	e8 00 00 00 00       	call   25fb <f_8001161d0+0x25fb>
    25fb:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    2602:	ff ff ff 
    2605:	e9 78 02 00 00       	jmp    2882 <f_8001161d0+0x2882>
    260a:	49 89 cf             	mov    %rcx,%r15
    260d:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    2614:	00 
    2615:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    261c:	48 c7 02 03 00 00 00 	movq   $0x3,(%rdx)
    2623:	48 be 00 00 00 00 00 	movabs $0x40000000000000,%rsi
    262a:	00 40 00 
    262d:	48 89 72 08          	mov    %rsi,0x8(%rdx)
    2631:	48 c7 42 10 ff ff 00 	movq   $0xffff,0x10(%rdx)
    2638:	00 
    2639:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    2640:	ff ff ff 
    2643:	48 8d 77 0f          	lea    0xf(%rdi),%rsi
    2647:	48 89 72 18          	mov    %rsi,0x18(%rdx)
    264b:	4c 89 42 20          	mov    %r8,0x20(%rdx)
    264f:	48 89 7a 28          	mov    %rdi,0x28(%rdx)
    2653:	49 8d 70 ff          	lea    -0x1(%r8),%rsi
    2657:	48 89 73 68          	mov    %rsi,0x68(%rbx)
    265b:	4c 89 6b 70          	mov    %r13,0x70(%rbx)
    265f:	48 8d 72 30          	lea    0x30(%rdx),%rsi
    2663:	48 83 c2 38          	add    $0x38,%rdx
    2667:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    266e:	00 00 00 
    2671:	48 81 c7 fb b3 05 00 	add    $0x5b3fb,%rdi
    2678:	eb 6e                	jmp    26e8 <f_8001161d0+0x26e8>
    267a:	49 89 cf             	mov    %rcx,%r15
    267d:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    2684:	ff ff ff 
    2687:	48 8d 77 0e          	lea    0xe(%rdi),%rsi
    268b:	48 89 73 78          	mov    %rsi,0x78(%rbx)
    268f:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    2696:	48 c7 02 00 04 00 00 	movq   $0x400,(%rdx)
    269d:	48 c7 42 08 00 00 00 	movq   $0x0,0x8(%rdx)
    26a4:	00 
    26a5:	48 c7 42 10 ff ff 00 	movq   $0xffff,0x10(%rdx)
    26ac:	00 
    26ad:	48 89 72 18          	mov    %rsi,0x18(%rdx)
    26b1:	49 b8 00 00 00 00 01 	movabs $0x100000000,%r8
    26b8:	00 00 00 
    26bb:	4c 89 42 20          	mov    %r8,0x20(%rdx)
    26bf:	48 89 7a 28          	mov    %rdi,0x28(%rdx)
    26c3:	49 8d 70 ff          	lea    -0x1(%r8),%rsi
    26c7:	48 89 73 68          	mov    %rsi,0x68(%rbx)
    26cb:	4c 89 6b 70          	mov    %r13,0x70(%rbx)
    26cf:	48 8d 72 30          	lea    0x30(%rdx),%rsi
    26d3:	48 83 c2 38          	add    $0x38,%rdx
    26d7:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    26de:	00 00 00 
    26e1:	48 81 c7 d9 85 00 00 	add    $0x85d9,%rdi
    26e8:	49 ff c8             	dec    %r8
    26eb:	4c 89 06             	mov    %r8,(%rsi)
    26ee:	4c 89 2a             	mov    %r13,(%rdx)
    26f1:	4c 8b b3 00 01 00 00 	mov    0x100(%rbx),%r14
    26f8:	49 89 7e 70          	mov    %rdi,0x70(%r14)
    26fc:	48 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rcx
    2703:	ff 7f 7f 
    2706:	49 89 4e 78          	mov    %rcx,0x78(%r14)
    270a:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
    2711:	ff 7f ff 
    2714:	48 89 73 68          	mov    %rsi,0x68(%rbx)
    2718:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    271c:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2723:	00 
    2724:	49 89 b6 80 00 00 00 	mov    %rsi,0x80(%r14)
    272b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2730:	49 89 86 88 00 00 00 	mov    %rax,0x88(%r14)
    2737:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    273c:	48 89 53 60          	mov    %rdx,0x60(%rbx)
    2740:	4d 89 6e 40          	mov    %r13,0x40(%r14)
    2744:	49 c7 46 48 00 00 00 	movq   $0x0,0x48(%r14)
    274b:	00 
    274c:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2753:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
    275a:	48 8b 14 24          	mov    (%rsp),%rdx
    275e:	49 89 56 50          	mov    %rdx,0x50(%r14)
    2762:	49 c7 46 58 00 00 00 	movq   $0x0,0x58(%r14)
    2769:	00 
    276a:	48 c7 43 50 02 00 00 	movq   $0x2,0x50(%rbx)
    2771:	00 
    2772:	49 89 8e 90 00 00 00 	mov    %rcx,0x90(%r14)
    2779:	49 89 b6 98 00 00 00 	mov    %rsi,0x98(%r14)
    2780:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2784:	c4 c1 78 11 46 60    	vmovups %xmm0,0x60(%r14)
    278a:	b9 02 00 00 00       	mov    $0x2,%ecx
    278f:	4d 89 cb             	mov    %r9,%r11
    2792:	45 89 96 a0 00 00 00 	mov    %r10d,0xa0(%r14)
    2799:	41 89 8e bc 00 00 00 	mov    %ecx,0xbc(%r14)
    27a0:	48 8b 93 98 00 00 00 	mov    0x98(%rbx),%rdx
    27a7:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
    27ae:	48 8b 89 c8 1e 00 00 	mov    0x1ec8(%rcx),%rcx
    27b5:	0f b6 52 08          	movzbl 0x8(%rdx),%edx
    27b9:	48 8b 71 10          	mov    0x10(%rcx),%rsi
    27bd:	48 69 fa e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdi
    27c4:	45 31 c0             	xor    %r8d,%r8d
    27c7:	39 51 08             	cmp    %edx,0x8(%rcx)
    27ca:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    27d0:	4c 0f 47 cf          	cmova  %rdi,%r9
    27d4:	4d 8b 94 31 08 2e 00 	mov    0x2e08(%r9,%rsi,1),%r10
    27db:	00 
    27dc:	4c 89 53 68          	mov    %r10,0x68(%rbx)
    27e0:	49 8b b4 31 00 2e 00 	mov    0x2e00(%r9,%rsi,1),%rsi
    27e7:	00 
    27e8:	48 89 75 00          	mov    %rsi,0x0(%rbp)
    27ec:	4c 89 55 08          	mov    %r10,0x8(%rbp)
    27f0:	8b 71 08             	mov    0x8(%rcx),%esi
    27f3:	4c 8b 49 10          	mov    0x10(%rcx),%r9
    27f7:	4c 89 4b 60          	mov    %r9,0x60(%rbx)
    27fb:	39 d6                	cmp    %edx,%esi
    27fd:	4c 0f 47 c7          	cmova  %rdi,%r8
    2801:	4b 8b 94 01 80 30 00 	mov    0x3080(%r9,%r8,1),%rdx
    2808:	00 
    2809:	4b 8b b4 01 88 30 00 	mov    0x3088(%r9,%r8,1),%rsi
    2810:	00 
    2811:	48 89 53 58          	mov    %rdx,0x58(%rbx)
    2815:	49 89 13             	mov    %rdx,(%r11)
    2818:	49 89 73 08          	mov    %rsi,0x8(%r11)
    281c:	43 8b 94 01 98 30 00 	mov    0x3098(%r9,%r8,1),%edx
    2823:	00 
    2824:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    2828:	4b 8b b4 01 90 30 00 	mov    0x3090(%r9,%r8,1),%rsi
    282f:	00 
    2830:	49 89 37             	mov    %rsi,(%r15)
    2833:	41 89 57 08          	mov    %edx,0x8(%r15)
    2837:	8b 51 20             	mov    0x20(%rcx),%edx
    283a:	8b 49 24             	mov    0x24(%rcx),%ecx
    283d:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    2841:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    2845:	41 c7 86 b4 00 00 00 	movl   $0x0,0xb4(%r14)
    284c:	00 00 00 00 
    2850:	c7 80 b1 00 00 00 00 	movl   $0x0,0xb1(%rax)
    2857:	00 00 00 
    285a:	41 88 96 b0 00 00 00 	mov    %dl,0xb0(%r14)
    2861:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    2868:	00 00 00 
    286b:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    2872:	ff ff ff 
    2875:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    287c:	88 88 b8 00 00 00    	mov    %cl,0xb8(%rax)
    2882:	48 8b bb b8 00 00 00 	mov    0xb8(%rbx),%rdi
    2889:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    2890:	8b 08                	mov    (%rax),%ecx
    2892:	48 89 4b 50          	mov    %rcx,0x50(%rbx)
    2896:	48 8d 57 1c          	lea    0x1c(%rdi),%rdx
    289a:	8b 77 1c             	mov    0x1c(%rdi),%esi
    289d:	48 89 53 40          	mov    %rdx,0x40(%rbx)
    28a1:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    28a5:	89 70 48             	mov    %esi,0x48(%rax)
    28a8:	4c 8d 47 2c          	lea    0x2c(%rdi),%r8
    28ac:	44 8b 4f 2c          	mov    0x2c(%rdi),%r9d
    28b0:	4c 89 83 b0 00 00 00 	mov    %r8,0xb0(%rbx)
    28b7:	4c 89 4b 60          	mov    %r9,0x60(%rbx)
    28bb:	8b 7f 14             	mov    0x14(%rdi),%edi
    28be:	21 cf                	and    %ecx,%edi
    28c0:	40 0f 95 c7          	setne  %dil
    28c4:	45 85 c9             	test   %r9d,%r9d
    28c7:	41 0f 9f c0          	setg   %r8b
    28cb:	41 20 f8             	and    %dil,%r8b
    28ce:	41 0f b6 f8          	movzbl %r8b,%edi
    28d2:	48 89 7b 58          	mov    %rdi,0x58(%rbx)
    28d6:	40 84 ff             	test   %dil,%dil
    28d9:	0f 84 40 01 00 00    	je     2a1f <f_8001161d0+0x2a1f>
    28df:	4c 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%r8
    28e6:	4c 8b 8b a8 00 00 00 	mov    0xa8(%rbx),%r9
    28ed:	49 8d b8 40 01 00 00 	lea    0x140(%r8),%rdi
    28f4:	48 89 bb c0 00 00 00 	mov    %rdi,0xc0(%rbx)
    28fb:	44 89 cf             	mov    %r9d,%edi
    28fe:	4d 63 c9             	movslq %r9d,%r9
    2901:	49 c1 f9 1f          	sar    $0x1f,%r9
    2905:	49 21 e9             	and    %rbp,%r9
    2908:	49 09 f9             	or     %rdi,%r9
    290b:	4c 89 8b c8 00 00 00 	mov    %r9,0xc8(%rbx)
    2912:	47 0f b6 84 08 40 01 	movzbl 0x140(%r8,%r9,1),%r8d
    2919:	00 00 
    291b:	4c 89 43 58          	mov    %r8,0x58(%rbx)
    291f:	41 f6 c0 01          	test   $0x1,%r8b
    2923:	0f 84 f6 00 00 00    	je     2a1f <f_8001161d0+0x2a1f>
    2929:	44 0f b6 40 0c       	movzbl 0xc(%rax),%r8d
    292e:	4c 89 43 58          	mov    %r8,0x58(%rbx)
    2932:	41 f6 c0 01          	test   $0x1,%r8b
    2936:	74 09                	je     2941 <f_8001161d0+0x2941>
    2938:	48 09 ce             	or     %rcx,%rsi
    293b:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    293f:	89 32                	mov    %esi,(%rdx)
    2941:	48 c7 43 40 d0 00 00 	movq   $0xd0,0x40(%rbx)
    2948:	00 
    2949:	48 89 43 08          	mov    %rax,0x8(%rbx)
    294d:	48 63 c7             	movslq %edi,%rax
    2950:	48 69 c0 d0 00 00 00 	imul   $0xd0,%rax,%rax
    2957:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    295e:	48 8d 14 01          	lea    (%rcx,%rax,1),%rdx
    2962:	48 89 93 d0 00 00 00 	mov    %rdx,0xd0(%rbx)
    2969:	48 c7 43 10 c0 00 00 	movq   $0xc0,0x10(%rbx)
    2970:	00 
    2971:	48 8d 84 01 40 0d 00 	lea    0xd40(%rcx,%rax,1),%rax
    2978:	00 
    2979:	48 89 83 a8 00 00 00 	mov    %rax,0xa8(%rbx)
    2980:	48 89 03             	mov    %rax,(%rbx)
    2983:	49 8d 85 6e 12 51 fd 	lea    -0x2aeed92(%r13),%rax
    298a:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    2991:	48 89 df             	mov    %rbx,%rdi
    2994:	c5 f8 77             	vzeroupper
    2997:	e8 00 00 00 00       	call   299c <f_8001161d0+0x299c>
    299c:	48 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%rax
    29a3:	80 88 38 0d 00 00 01 	orb    $0x1,0xd38(%rax)
    29aa:	48 8b bb a0 00 00 00 	mov    0xa0(%rbx),%rdi
    29b1:	0f b6 87 81 3a 00 00 	movzbl 0x3a81(%rdi),%eax
    29b8:	48 89 43 40          	mov    %rax,0x40(%rbx)
    29bc:	a8 40                	test   $0x40,%al
    29be:	74 5f                	je     2a1f <f_8001161d0+0x2a1f>
    29c0:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    29c7:	48 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%rcx
    29ce:	0f b6 04 01          	movzbl (%rcx,%rax,1),%eax
    29d2:	48 89 43 40          	mov    %rax,0x40(%rbx)
    29d6:	a8 02                	test   $0x2,%al
    29d8:	74 45                	je     2a1f <f_8001161d0+0x2a1f>
    29da:	48 8b 87 60 3b 00 00 	mov    0x3b60(%rdi),%rax
    29e1:	48 89 43 40          	mov    %rax,0x40(%rbx)
    29e5:	48 85 c0             	test   %rax,%rax
    29e8:	74 35                	je     2a1f <f_8001161d0+0x2a1f>
    29ea:	0f b6 87 85 3a 00 00 	movzbl 0x3a85(%rdi),%eax
    29f1:	48 89 43 40          	mov    %rax,0x40(%rbx)
    29f5:	a8 02                	test   $0x2,%al
    29f7:	74 26                	je     2a1f <f_8001161d0+0x2a1f>
    29f9:	48 8b 83 a8 00 00 00 	mov    0xa8(%rbx),%rax
    2a00:	48 8b 8b b8 00 00 00 	mov    0xb8(%rbx),%rcx
    2a07:	8b 00                	mov    (%rax),%eax
    2a09:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2a0d:	8b 49 10             	mov    0x10(%rcx),%ecx
    2a10:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    2a14:	c4 e2 70 f2 c0       	andn   %eax,%ecx,%eax
    2a19:	0f 84 70 02 00 00    	je     2c8f <f_8001161d0+0x2c8f>
    2a1f:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    2a26:	48 8b 88 20 01 00 00 	mov    0x120(%rax),%rcx
    2a2d:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    2a34:	48 89 8b a0 00 00 00 	mov    %rcx,0xa0(%rbx)
    2a3b:	48 89 93 98 00 00 00 	mov    %rdx,0x98(%rbx)
    2a42:	48 8b 88 10 01 00 00 	mov    0x110(%rax),%rcx
    2a49:	48 8b 90 18 01 00 00 	mov    0x118(%rax),%rdx
    2a50:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
    2a57:	48 89 93 a8 00 00 00 	mov    %rdx,0xa8(%rbx)
    2a5e:	48 8b 88 00 01 00 00 	mov    0x100(%rax),%rcx
    2a65:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    2a6c:	48 89 8b c0 00 00 00 	mov    %rcx,0xc0(%rbx)
    2a73:	48 89 93 b8 00 00 00 	mov    %rdx,0xb8(%rbx)
    2a7a:	48 8b 88 f0 00 00 00 	mov    0xf0(%rax),%rcx
    2a81:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
    2a88:	48 89 8b d0 00 00 00 	mov    %rcx,0xd0(%rbx)
    2a8f:	48 89 93 c8 00 00 00 	mov    %rdx,0xc8(%rbx)
    2a96:	48 8b 88 e0 00 00 00 	mov    0xe0(%rax),%rcx
    2a9d:	48 8b 90 e8 00 00 00 	mov    0xe8(%rax),%rdx
    2aa4:	48 89 8b e0 00 00 00 	mov    %rcx,0xe0(%rbx)
    2aab:	48 89 93 d8 00 00 00 	mov    %rdx,0xd8(%rbx)
    2ab2:	c5 f8 10 80 d0 00 00 	vmovups 0xd0(%rax),%xmm0
    2ab9:	00 
    2aba:	c5 f8 11 83 e8 00 00 	vmovups %xmm0,0xe8(%rbx)
    2ac1:	00 
    2ac2:	48 05 30 01 00 00    	add    $0x130,%rax
    2ac8:	48 89 83 00 01 00 00 	mov    %rax,0x100(%rbx)
    2acf:	48 83 c4 18          	add    $0x18,%rsp
    2ad3:	5b                   	pop    %rbx
    2ad4:	41 5c                	pop    %r12
    2ad6:	41 5d                	pop    %r13
    2ad8:	41 5e                	pop    %r14
    2ada:	41 5f                	pop    %r15
    2adc:	5d                   	pop    %rbp
    2add:	c5 f8 77             	vzeroupper
    2ae0:	c3                   	ret
    2ae1:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
    2ae8:	48 8b 96 c8 1e 00 00 	mov    0x1ec8(%rsi),%rdx
    2aef:	48 89 93 b0 00 00 00 	mov    %rdx,0xb0(%rbx)
    2af6:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    2afd:	ff ff ff 
    2b00:	48 8d 7d 1a          	lea    0x1a(%rbp),%rdi
    2b04:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
    2b08:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2b0c:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    2b13:	48 c7 02 00 20 00 00 	movq   $0x2000,(%rdx)
    2b1a:	48 c7 42 08 00 00 00 	movq   $0x0,0x8(%rdx)
    2b21:	00 
    2b22:	48 c7 42 10 ff ff 00 	movq   $0xffff,0x10(%rdx)
    2b29:	00 
    2b2a:	48 89 7a 18          	mov    %rdi,0x18(%rdx)
    2b2e:	48 8b bb 98 00 00 00 	mov    0x98(%rbx),%rdi
    2b35:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    2b39:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2b40:	00 
    2b41:	44 89 92 a0 00 00 00 	mov    %r10d,0xa0(%rdx)
    2b48:	4c 89 42 20          	mov    %r8,0x20(%rdx)
    2b4c:	48 89 6a 28          	mov    %rbp,0x28(%rdx)
    2b50:	4c 89 6b 68          	mov    %r13,0x68(%rbx)
    2b54:	49 8d 40 ff          	lea    -0x1(%r8),%rax
    2b58:	48 89 42 30          	mov    %rax,0x30(%rdx)
    2b5c:	4c 89 6a 38          	mov    %r13,0x38(%rdx)
    2b60:	4c 89 e9             	mov    %r13,%rcx
    2b63:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    2b6a:	00 00 00 
    2b6d:	49 8d 85 95 53 09 00 	lea    0x95395(%r13),%rax
    2b74:	48 89 42 70          	mov    %rax,0x70(%rdx)
    2b78:	49 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r8
    2b7f:	ff 7f 7f 
    2b82:	4c 89 42 78          	mov    %r8,0x78(%rdx)
    2b86:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    2b8d:	ff 7f ff 
    2b90:	48 89 ba 80 00 00 00 	mov    %rdi,0x80(%rdx)
    2b97:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2b9c:	48 89 82 88 00 00 00 	mov    %rax,0x88(%rdx)
    2ba3:	4c 89 5b 60          	mov    %r11,0x60(%rbx)
    2ba7:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2bae:	4c 89 98 a4 00 00 00 	mov    %r11,0xa4(%rax)
    2bb5:	4c 89 82 90 00 00 00 	mov    %r8,0x90(%rdx)
    2bbc:	48 89 ba 98 00 00 00 	mov    %rdi,0x98(%rdx)
    2bc3:	48 c7 43 50 b0 1e 00 	movq   $0x1eb0,0x50(%rbx)
    2bca:	00 
    2bcb:	48 81 c6 b0 1e 00 00 	add    $0x1eb0,%rsi
    2bd2:	48 89 33             	mov    %rsi,(%rbx)
    2bd5:	48 8b 04 24          	mov    (%rsp),%rax
    2bd9:	48 89 42 50          	mov    %rax,0x50(%rdx)
    2bdd:	48 c7 42 58 00 00 00 	movq   $0x0,0x58(%rdx)
    2be4:	00 
    2be5:	48 c7 43 48 03 00 00 	movq   $0x3,0x48(%rbx)
    2bec:	00 
    2bed:	c7 82 bc 00 00 00 03 	movl   $0x3,0xbc(%rdx)
    2bf4:	00 00 00 
    2bf7:	48 89 4a 40          	mov    %rcx,0x40(%rdx)
    2bfb:	48 c7 42 48 00 00 00 	movq   $0x0,0x48(%rdx)
    2c02:	00 
    2c03:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2c07:	c5 f8 11 42 60       	vmovups %xmm0,0x60(%rdx)
    2c0c:	49 8d 85 92 14 51 fd 	lea    -0x2aeeb6e(%r13),%rax
    2c13:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    2c1a:	48 89 df             	mov    %rbx,%rdi
    2c1d:	c5 f8 77             	vzeroupper
    2c20:	e8 00 00 00 00       	call   2c25 <f_8001161d0+0x2c25>
    2c25:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    2c2c:	0f b6 48 08          	movzbl 0x8(%rax),%ecx
    2c30:	48 8b 93 b0 00 00 00 	mov    0xb0(%rbx),%rdx
    2c37:	48 69 f1 e0 3c 00 00 	imul   $0x3ce0,%rcx,%rsi
    2c3e:	31 c0                	xor    %eax,%eax
    2c40:	39 4a 08             	cmp    %ecx,0x8(%rdx)
    2c43:	48 0f 47 c6          	cmova  %rsi,%rax
    2c47:	48 8b 3b             	mov    (%rbx),%rdi
    2c4a:	48 03 42 10          	add    0x10(%rdx),%rax
    2c4e:	40 f6 c7 01          	test   $0x1,%dil
    2c52:	0f 85 24 03 00 00    	jne    2f7c <f_8001161d0+0x2f7c>
    2c58:	41 b8 5c 00 00 00    	mov    $0x5c,%r8d
    2c5e:	41 b9 58 00 00 00    	mov    $0x58,%r9d
    2c64:	41 ba 54 00 00 00    	mov    $0x54,%r10d
    2c6a:	41 bb 50 00 00 00    	mov    $0x50,%r11d
    2c70:	e9 23 03 00 00       	jmp    2f98 <f_8001161d0+0x2f98>
    2c75:	48 81 c2 bc 00 00 00 	add    $0xbc,%rdx
    2c7c:	48 c7 43 40 02 00 00 	movq   $0x2,0x40(%rbx)
    2c83:	00 
    2c84:	c7 02 02 00 00 00    	movl   $0x2,(%rdx)
    2c8a:	e9 f3 fb ff ff       	jmp    2882 <f_8001161d0+0x2882>
    2c8f:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
    2c96:	8b 08                	mov    (%rax),%ecx
    2c98:	44 8b 87 90 3b 00 00 	mov    0x3b90(%rdi),%r8d
    2c9f:	44 8b 8f 94 3b 00 00 	mov    0x3b94(%rdi),%r9d
    2ca6:	41 83 f8 01          	cmp    $0x1,%r8d
    2caa:	44 89 c6             	mov    %r8d,%esi
    2cad:	83 d6 00             	adc    $0x0,%esi
    2cb0:	89 c8                	mov    %ecx,%eax
    2cb2:	31 d2                	xor    %edx,%edx
    2cb4:	f7 f6                	div    %esi
    2cb6:	89 c6                	mov    %eax,%esi
    2cb8:	45 85 c0             	test   %r8d,%r8d
    2cbb:	41 0f 44 f0          	cmove  %r8d,%esi
    2cbf:	4c 89 4b 48          	mov    %r9,0x48(%rbx)
    2cc3:	41 39 f1             	cmp    %esi,%r9d
    2cc6:	41 0f 4c f1          	cmovl  %r9d,%esi
    2cca:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    2cce:	85 f6                	test   %esi,%esi
    2cd0:	0f 84 49 fd ff ff    	je     2a1f <f_8001161d0+0x2a1f>
    2cd6:	48 89 8b 88 00 00 00 	mov    %rcx,0x88(%rbx)
    2cdd:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2ce4:	00 00 00 
    2ce7:	01 f0                	add    %esi,%eax
    2ce9:	ff c8                	dec    %eax
    2ceb:	48 89 43 48          	mov    %rax,0x48(%rbx)
    2cef:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
    2cf3:	85 f6                	test   %esi,%esi
    2cf5:	0f 8e 24 fd ff ff    	jle    2a1f <f_8001161d0+0x2a1f>
    2cfb:	89 c8                	mov    %ecx,%eax
    2cfd:	99                   	cltd
    2cfe:	f7 fe                	idiv   %esi
    2d00:	48 8d 4b 50          	lea    0x50(%rbx),%rcx
    2d04:	48 8d b7 80 3b 00 00 	lea    0x3b80(%rdi),%rsi
    2d0b:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2d0f:	c5 f8 29 01          	vmovaps %xmm0,(%rcx)
    2d13:	48 89 73 70          	mov    %rsi,0x70(%rbx)
    2d17:	48 c7 43 78 28 00 00 	movq   $0x28,0x78(%rbx)
    2d1e:	00 
    2d1f:	48 c7 83 80 00 00 00 	movq   $0x3dcccccd,0x80(%rbx)
    2d26:	cd cc cc 3d 
    2d2a:	48 89 53 60          	mov    %rdx,0x60(%rbx)
    2d2e:	48 81 c7 78 3b 00 00 	add    $0x3b78,%rdi
    2d35:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    2d39:	48 89 83 88 00 00 00 	mov    %rax,0x88(%rbx)
    2d40:	31 c9                	xor    %ecx,%ecx
    2d42:	48 ba 00 00 00 00 f8 	movabs $0xfffffff800000000,%rdx
    2d49:	ff ff ff 
    2d4c:	c4 e2 79 59 0d 00 00 	vpbroadcastq 0x0(%rip),%xmm1        # 2d55 <f_8001161d0+0x2d55>
    2d53:	00 00 
    2d55:	c5 e8 57 d2          	vxorps %xmm2,%xmm2,%xmm2
    2d59:	c5 fa 10 1d 00 00 00 	vmovss 0x0(%rip),%xmm3        # 2d61 <f_8001161d0+0x2d61>
    2d60:	00 
    2d61:	be ff ff ff ff       	mov    $0xffffffff,%esi
    2d66:	eb 2b                	jmp    2d93 <f_8001161d0+0x2d93>
    2d68:	c4 e3 f1 22 a3 88 00 	vpinsrq $0x1,0x88(%rbx),%xmm1,%xmm4
    2d6f:	00 00 01 
    2d72:	c5 d9 d4 63 50       	vpaddq 0x50(%rbx),%xmm4,%xmm4
    2d77:	c4 e3 59 02 e8 0a    	vpblendd $0xa,%xmm0,%xmm4,%xmm5
    2d7d:	c5 f9 7f 6b 50       	vmovdqa %xmm5,0x50(%rbx)
    2d82:	c5 f9 7e e0          	vmovd  %xmm4,%eax
    2d86:	3b 43 40             	cmp    0x40(%rbx),%eax
    2d89:	0f 84 90 fc ff ff    	je     2a1f <f_8001161d0+0x2a1f>
    2d8f:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
    2d93:	8b 07                	mov    (%rdi),%eax
    2d95:	48 89 83 90 00 00 00 	mov    %rax,0x90(%rbx)
    2d9c:	8d 78 01             	lea    0x1(%rax),%edi
    2d9f:	48 89 3b             	mov    %rdi,(%rbx)
    2da2:	4c 8b 43 68          	mov    0x68(%rbx),%r8
    2da6:	45 31 c9             	xor    %r9d,%r9d
    2da9:	f0 41 0f b1 38       	lock cmpxchg %edi,(%r8)
    2dae:	41 0f 95 c1          	setne  %r9b
    2db2:	4c 89 4b 08          	mov    %r9,0x8(%rbx)
    2db6:	75 d7                	jne    2d8f <f_8001161d0+0x2d8f>
    2db8:	4c 8b 93 a0 00 00 00 	mov    0xa0(%rbx),%r10
    2dbf:	8b 43 50             	mov    0x50(%rbx),%eax
    2dc2:	3b 43 48             	cmp    0x48(%rbx),%eax
    2dc5:	8b 7b 60             	mov    0x60(%rbx),%edi
    2dc8:	48 0f 45 f9          	cmovne %rcx,%rdi
    2dcc:	4d 8b 8a 70 3b 00 00 	mov    0x3b70(%r10),%r9
    2dd3:	4c 8b 83 90 00 00 00 	mov    0x90(%rbx),%r8
    2dda:	b8 00 00 00 00       	mov    $0x0,%eax
    2ddf:	45 39 82 68 3b 00 00 	cmp    %r8d,0x3b68(%r10)
    2de6:	76 10                	jbe    2df8 <f_8001161d0+0x2df8>
    2de8:	45 89 c0             	mov    %r8d,%r8d
    2deb:	49 63 c0             	movslq %r8d,%rax
    2dee:	48 c1 f8 1f          	sar    $0x1f,%rax
    2df2:	48 21 e8             	and    %rbp,%rax
    2df5:	4c 09 c0             	or     %r8,%rax
    2df8:	48 89 43 08          	mov    %rax,0x8(%rbx)
    2dfc:	48 03 bb 88 00 00 00 	add    0x88(%rbx),%rdi
    2e03:	41 89 f8             	mov    %edi,%r8d
    2e06:	4c 89 83 88 00 00 00 	mov    %r8,0x88(%rbx)
    2e0d:	48 98                	cltq
    2e0f:	4c 63 53 78          	movslq 0x78(%rbx),%r10
    2e13:	4c 0f af d0          	imul   %rax,%r10
    2e17:	4b 8d 04 0a          	lea    (%r10,%r9,1),%rax
    2e1b:	48 89 83 90 00 00 00 	mov    %rax,0x90(%rbx)
    2e22:	44 8b 5b 58          	mov    0x58(%rbx),%r11d
    2e26:	49 89 fe             	mov    %rdi,%r14
    2e29:	49 c1 e6 20          	shl    $0x20,%r14
    2e2d:	4d 09 de             	or     %r11,%r14
    2e30:	4c 8b 9b 98 00 00 00 	mov    0x98(%rbx),%r11
    2e37:	4f 89 1c 0a          	mov    %r11,(%r10,%r9,1)
    2e3b:	4c 8b 9b b8 00 00 00 	mov    0xb8(%rbx),%r11
    2e42:	4f 89 5c 0a 08       	mov    %r11,0x8(%r10,%r9,1)
    2e47:	4c 8b 9b a8 00 00 00 	mov    0xa8(%rbx),%r11
    2e4e:	4f 89 5c 0a 10       	mov    %r11,0x10(%r10,%r9,1)
    2e53:	4f 89 74 0a 18       	mov    %r14,0x18(%r10,%r9,1)
    2e58:	45 8b 8b bc 00 00 00 	mov    0xbc(%r11),%r9d
    2e5f:	41 83 f9 01          	cmp    $0x1,%r9d
    2e63:	74 5b                	je     2ec0 <f_8001161d0+0x2ec0>
    2e65:	41 83 f9 02          	cmp    $0x2,%r9d
    2e69:	75 70                	jne    2edb <f_8001161d0+0x2edb>
    2e6b:	c5 82 2a e7          	vcvtsi2ss %edi,%xmm15,%xmm4
    2e6f:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
    2e76:	41 89 f8             	mov    %edi,%r8d
    2e79:	4c 89 83 10 02 00 00 	mov    %r8,0x210(%rbx)
    2e80:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    2e87:	00 00 00 00 
    2e8b:	c5 f9 6e ef          	vmovd  %edi,%xmm5
    2e8f:	c5 da 59 e5          	vmulss %xmm5,%xmm4,%xmm4
    2e93:	c5 f9 7e e7          	vmovd  %xmm4,%edi
    2e97:	48 89 bb 00 02 00 00 	mov    %rdi,0x200(%rbx)
    2e9e:	c4 61 fa 2c c4       	vcvttss2si %xmm4,%r8
    2ea3:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    2eaa:	00 00 00 00 
    2eae:	c5 f8 2e e2          	vucomiss %xmm2,%xmm4
    2eb2:	44 0f 42 c1          	cmovb  %ecx,%r8d
    2eb6:	c5 f8 2e e3          	vucomiss %xmm3,%xmm4
    2eba:	44 0f 47 c6          	cmova  %esi,%r8d
    2ebe:	eb 2b                	jmp    2eeb <f_8001161d0+0x2eeb>
    2ec0:	41 89 f8             	mov    %edi,%r8d
    2ec3:	41 c1 e8 1f          	shr    $0x1f,%r8d
    2ec7:	41 01 f8             	add    %edi,%r8d
    2eca:	44 89 c7             	mov    %r8d,%edi
    2ecd:	d1 ef                	shr    $1,%edi
    2ecf:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
    2ed6:	41 09 f8             	or     %edi,%r8d
    2ed9:	eb 10                	jmp    2eeb <f_8001161d0+0x2eeb>
    2edb:	4c 89 43 10          	mov    %r8,0x10(%rbx)
    2edf:	41 83 f9 03          	cmp    $0x3,%r9d
    2ee3:	75 0a                	jne    2eef <f_8001161d0+0x2eef>
    2ee5:	01 ff                	add    %edi,%edi
    2ee7:	44 8d 04 bf          	lea    (%rdi,%rdi,4),%r8d
    2eeb:	4c 89 43 10          	mov    %r8,0x10(%rbx)
    2eef:	48 89 03             	mov    %rax,(%rbx)
    2ef2:	44 89 40 20          	mov    %r8d,0x20(%rax)
    2ef6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    2efd:	00 00 00 
    2f00:	48 8b 43 70          	mov    0x70(%rbx),%rax
    2f04:	8b 00                	mov    (%rax),%eax
    2f06:	48 89 03             	mov    %rax,(%rbx)
    2f09:	8d 78 01             	lea    0x1(%rax),%edi
    2f0c:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    2f10:	4c 8b 43 70          	mov    0x70(%rbx),%r8
    2f14:	45 31 c9             	xor    %r9d,%r9d
    2f17:	f0 41 0f b1 38       	lock cmpxchg %edi,(%r8)
    2f1c:	41 0f 95 c1          	setne  %r9b
    2f20:	4c 89 4b 10          	mov    %r9,0x10(%rbx)
    2f24:	75 da                	jne    2f00 <f_8001161d0+0x2f00>
    2f26:	48 8b 03             	mov    (%rbx),%rax
    2f29:	48 8b bb a0 00 00 00 	mov    0xa0(%rbx),%rdi
    2f30:	44 8b 87 84 3b 00 00 	mov    0x3b84(%rdi),%r8d
    2f37:	4c 89 43 08          	mov    %r8,0x8(%rbx)
    2f3b:	41 39 c0             	cmp    %eax,%r8d
    2f3e:	0f 8e 24 fe ff ff    	jle    2d68 <f_8001161d0+0x2d68>
    2f44:	48 8b bf 88 3b 00 00 	mov    0x3b88(%rdi),%rdi
    2f4b:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    2f4f:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    2f56:	00 
    2f57:	48 98                	cltq
    2f59:	48 21 d0             	and    %rdx,%rax
    2f5c:	4d 8d 8d 2e a2 3f fd 	lea    -0x2c05dd2(%r13),%r9
    2f63:	4d 21 c1             	and    %r8,%r9
    2f66:	49 09 c1             	or     %rax,%r9
    2f69:	4c 89 0b             	mov    %r9,(%rbx)
    2f6c:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
    2f73:	4a 89 04 0f          	mov    %rax,(%rdi,%r9,1)
    2f77:	e9 ec fd ff ff       	jmp    2d68 <f_8001161d0+0x2d68>
    2f7c:	48 89 43 68          	mov    %rax,0x68(%rbx)
    2f80:	41 b8 0c 2e 00 00    	mov    $0x2e0c,%r8d
    2f86:	41 b9 08 2e 00 00    	mov    $0x2e08,%r9d
    2f8c:	41 ba 04 2e 00 00    	mov    $0x2e04,%r10d
    2f92:	41 bb 00 2e 00 00    	mov    $0x2e00,%r11d
    2f98:	46 8b 1c 18          	mov    (%rax,%r11,1),%r11d
    2f9c:	4c 89 9b 00 02 00 00 	mov    %r11,0x200(%rbx)
    2fa3:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    2faa:	00 00 00 00 
    2fae:	46 8b 14 10          	mov    (%rax,%r10,1),%r10d
    2fb2:	4c 89 93 10 02 00 00 	mov    %r10,0x210(%rbx)
    2fb9:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    2fc0:	00 00 00 00 
    2fc4:	46 8b 0c 08          	mov    (%rax,%r9,1),%r9d
    2fc8:	4c 89 8b 20 02 00 00 	mov    %r9,0x220(%rbx)
    2fcf:	48 c7 83 28 02 00 00 	movq   $0x0,0x228(%rbx)
    2fd6:	00 00 00 00 
    2fda:	48 c7 43 58 e0 3c 00 	movq   $0x3ce0,0x58(%rbx)
    2fe1:	00 
    2fe2:	46 8b 04 00          	mov    (%rax,%r8,1),%r8d
    2fe6:	4c 89 83 30 02 00 00 	mov    %r8,0x230(%rbx)
    2fed:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    2ff4:	00 00 00 00 
    2ff8:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    2fff:	44 89 58 78          	mov    %r11d,0x78(%rax)
    3003:	44 89 50 7c          	mov    %r10d,0x7c(%rax)
    3007:	44 89 88 80 00 00 00 	mov    %r9d,0x80(%rax)
    300e:	44 89 80 84 00 00 00 	mov    %r8d,0x84(%rax)
    3015:	45 31 c0             	xor    %r8d,%r8d
    3018:	39 4a 08             	cmp    %ecx,0x8(%rdx)
    301b:	4c 0f 47 c6          	cmova  %rsi,%r8
    301f:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
    3023:	40 f6 c7 01          	test   $0x1,%dil
    3027:	75 56                	jne    307f <f_8001161d0+0x307f>
    3029:	4b 8b 7c 08 20       	mov    0x20(%r8,%r9,1),%rdi
    302e:	4f 8b 54 08 28       	mov    0x28(%r8,%r9,1),%r10
    3033:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    3037:	4c 8b 9b d0 00 00 00 	mov    0xd0(%rbx),%r11
    303e:	49 89 3b             	mov    %rdi,(%r11)
    3041:	4d 89 53 08          	mov    %r10,0x8(%r11)
    3045:	4b 8b 7c 08 30       	mov    0x30(%r8,%r9,1),%rdi
    304a:	47 8b 44 08 38       	mov    0x38(%r8,%r9,1),%r8d
    304f:	4c 89 43 48          	mov    %r8,0x48(%rbx)
    3053:	4c 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%r9
    305a:	45 89 41 08          	mov    %r8d,0x8(%r9)
    305e:	49 89 39             	mov    %rdi,(%r9)
    3061:	8b 7a 08             	mov    0x8(%rdx),%edi
    3064:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    3068:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    306c:	45 31 c0             	xor    %r8d,%r8d
    306f:	39 cf                	cmp    %ecx,%edi
    3071:	4c 0f 47 c6          	cmova  %rsi,%r8
    3075:	4a 8d 0c 02          	lea    (%rdx,%r8,1),%rcx
    3079:	48 83 c1 40          	add    $0x40,%rcx
    307d:	eb 70                	jmp    30ef <f_8001161d0+0x30ef>
    307f:	4b 8b b4 08 80 30 00 	mov    0x3080(%r8,%r9,1),%rsi
    3086:	00 
    3087:	4b 8b bc 08 88 30 00 	mov    0x3088(%r8,%r9,1),%rdi
    308e:	00 
    308f:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
    3093:	4c 8b 93 d0 00 00 00 	mov    0xd0(%rbx),%r10
    309a:	49 89 32             	mov    %rsi,(%r10)
    309d:	49 89 7a 08          	mov    %rdi,0x8(%r10)
    30a1:	4b 8b b4 08 90 30 00 	mov    0x3090(%r8,%r9,1),%rsi
    30a8:	00 
    30a9:	43 8b bc 08 98 30 00 	mov    0x3098(%r8,%r9,1),%edi
    30b0:	00 
    30b1:	4c 8b 83 c8 00 00 00 	mov    0xc8(%rbx),%r8
    30b8:	41 89 78 08          	mov    %edi,0x8(%r8)
    30bc:	49 89 30             	mov    %rsi,(%r8)
    30bf:	8b 72 08             	mov    0x8(%rdx),%esi
    30c2:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    30c6:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    30ca:	31 ff                	xor    %edi,%edi
    30cc:	39 ce                	cmp    %ecx,%esi
    30ce:	48 0f 47 f9          	cmova  %rcx,%rdi
    30d2:	48 c7 43 48 f0 2d 00 	movq   $0x2df0,0x48(%rbx)
    30d9:	00 
    30da:	48 89 7b 40          	mov    %rdi,0x40(%rbx)
    30de:	48 69 cf e0 3c 00 00 	imul   $0x3ce0,%rdi,%rcx
    30e5:	48 01 d1             	add    %rdx,%rcx
    30e8:	48 81 c1 f0 2d 00 00 	add    $0x2df0,%rcx
    30ef:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    30f3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    30f7:	48 85 d2             	test   %rdx,%rdx
    30fa:	74 0d                	je     3109 <f_8001161d0+0x3109>
    30fc:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3103:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    3107:	eb 02                	jmp    310b <f_8001161d0+0x310b>
    3109:	31 d2                	xor    %edx,%edx
    310b:	88 90 b0 00 00 00    	mov    %dl,0xb0(%rax)
    3111:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    3115:	48 85 d2             	test   %rdx,%rdx
    3118:	74 09                	je     3123 <f_8001161d0+0x3123>
    311a:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3121:	eb 02                	jmp    3125 <f_8001161d0+0x3125>
    3123:	31 d2                	xor    %edx,%edx
    3125:	88 90 b1 00 00 00    	mov    %dl,0xb1(%rax)
    312b:	48 8b 51 30          	mov    0x30(%rcx),%rdx
    312f:	48 85 d2             	test   %rdx,%rdx
    3132:	74 0d                	je     3141 <f_8001161d0+0x3141>
    3134:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    313b:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    313f:	eb 02                	jmp    3143 <f_8001161d0+0x3143>
    3141:	31 d2                	xor    %edx,%edx
    3143:	88 90 b2 00 00 00    	mov    %dl,0xb2(%rax)
    3149:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    314d:	48 85 d2             	test   %rdx,%rdx
    3150:	74 09                	je     315b <f_8001161d0+0x315b>
    3152:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3159:	eb 02                	jmp    315d <f_8001161d0+0x315d>
    315b:	31 d2                	xor    %edx,%edx
    315d:	88 90 b3 00 00 00    	mov    %dl,0xb3(%rax)
    3163:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    3167:	48 85 d2             	test   %rdx,%rdx
    316a:	74 0d                	je     3179 <f_8001161d0+0x3179>
    316c:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3173:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    3177:	eb 02                	jmp    317b <f_8001161d0+0x317b>
    3179:	31 d2                	xor    %edx,%edx
    317b:	88 90 b4 00 00 00    	mov    %dl,0xb4(%rax)
    3181:	48 8b 51 48          	mov    0x48(%rcx),%rdx
    3185:	48 85 d2             	test   %rdx,%rdx
    3188:	74 09                	je     3193 <f_8001161d0+0x3193>
    318a:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3191:	eb 02                	jmp    3195 <f_8001161d0+0x3195>
    3193:	31 d2                	xor    %edx,%edx
    3195:	88 90 b5 00 00 00    	mov    %dl,0xb5(%rax)
    319b:	48 8b 51 50          	mov    0x50(%rcx),%rdx
    319f:	48 85 d2             	test   %rdx,%rdx
    31a2:	74 09                	je     31ad <f_8001161d0+0x31ad>
    31a4:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    31ab:	eb 02                	jmp    31af <f_8001161d0+0x31af>
    31ad:	31 d2                	xor    %edx,%edx
    31af:	88 90 b6 00 00 00    	mov    %dl,0xb6(%rax)
    31b5:	48 8b 51 58          	mov    0x58(%rcx),%rdx
    31b9:	48 85 d2             	test   %rdx,%rdx
    31bc:	74 0d                	je     31cb <f_8001161d0+0x31cb>
    31be:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    31c5:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    31c9:	eb 02                	jmp    31cd <f_8001161d0+0x31cd>
    31cb:	31 d2                	xor    %edx,%edx
    31cd:	88 90 b7 00 00 00    	mov    %dl,0xb7(%rax)
    31d3:	48 8b 41 60          	mov    0x60(%rcx),%rax
    31d7:	48 85 c0             	test   %rax,%rax
    31da:	74 10                	je     31ec <f_8001161d0+0x31ec>
    31dc:	0f b6 88 c0 00 00 00 	movzbl 0xc0(%rax),%ecx
    31e3:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    31e7:	e9 89 f6 ff ff       	jmp    2875 <f_8001161d0+0x2875>
    31ec:	31 c9                	xor    %ecx,%ecx
    31ee:	e9 82 f6 ff ff       	jmp    2875 <f_8001161d0+0x2875>
