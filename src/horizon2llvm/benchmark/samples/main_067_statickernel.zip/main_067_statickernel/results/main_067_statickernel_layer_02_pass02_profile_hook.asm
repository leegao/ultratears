
/home/leegao/meh/ultratears-main/src/horizon2llvm/benchmark/samples/main_067_statickernel/results/main_067_statickernel_layer_02_pass02_profile_hook.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <f_8001161d0>:
       0:	55                   	push   %rbp
       1:	41 57                	push   %r15
       3:	41 56                	push   %r14
       5:	41 55                	push   %r13
       7:	41 54                	push   %r12
       9:	53                   	push   %rbx
       a:	48 83 ec 18          	sub    $0x18,%rsp
       e:	48 89 fb             	mov    %rdi,%rbx
      11:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
      18:	00 00 00 
      1b:	48 8b 8f e8 00 00 00 	mov    0xe8(%rdi),%rcx
      22:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
      29:	4c 8d a8 d0 fe ff ff 	lea    -0x130(%rax),%r13
      30:	4c 89 af 00 01 00 00 	mov    %r13,0x100(%rdi)
      37:	48 8d 50 a0          	lea    -0x60(%rax),%rdx
      3b:	48 89 48 a0          	mov    %rcx,-0x60(%rax)
      3f:	48 8b 8f f0 00 00 00 	mov    0xf0(%rdi),%rcx
      46:	48 89 48 a8          	mov    %rcx,-0x58(%rax)
      4a:	48 8b 8f e0 00 00 00 	mov    0xe0(%rdi),%rcx
      51:	48 89 48 b0          	mov    %rcx,-0x50(%rax)
      55:	48 8b 8f d8 00 00 00 	mov    0xd8(%rdi),%rcx
      5c:	48 89 48 b8          	mov    %rcx,-0x48(%rax)
      60:	48 8b 8f d0 00 00 00 	mov    0xd0(%rdi),%rcx
      67:	48 89 48 c0          	mov    %rcx,-0x40(%rax)
      6b:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
      72:	48 89 48 c8          	mov    %rcx,-0x38(%rax)
      76:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
      7d:	48 89 48 d0          	mov    %rcx,-0x30(%rax)
      81:	48 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%rcx
      88:	48 89 48 d8          	mov    %rcx,-0x28(%rax)
      8c:	48 8b 8f b0 00 00 00 	mov    0xb0(%rdi),%rcx
      93:	48 89 48 e0          	mov    %rcx,-0x20(%rax)
      97:	48 8b 8f a8 00 00 00 	mov    0xa8(%rdi),%rcx
      9e:	48 89 48 e8          	mov    %rcx,-0x18(%rax)
      a2:	48 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%rcx
      a9:	48 89 48 f0          	mov    %rcx,-0x10(%rax)
      ad:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
      b4:	48 89 48 f8          	mov    %rcx,-0x8(%rax)
      b8:	48 89 97 e8 00 00 00 	mov    %rdx,0xe8(%rdi)
      bf:	4c 8b 5f 10          	mov    0x10(%rdi),%r11
      c3:	4c 89 9f a8 00 00 00 	mov    %r11,0xa8(%rdi)
      ca:	4c 8b 27             	mov    (%rdi),%r12
      cd:	4c 8b 7f 08          	mov    0x8(%rdi),%r15
      d1:	4c 89 bf 98 00 00 00 	mov    %r15,0x98(%rdi)
      d8:	4c 89 a7 a0 00 00 00 	mov    %r12,0xa0(%rdi)
      df:	49 8d 8f 14 29 00 00 	lea    0x2914(%r15),%rcx
      e6:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
      ea:	41 83 fb 20          	cmp    $0x20,%r11d
      ee:	73 1f                	jae    10f <f_8001161d0+0x10f>
      f0:	b9 1f 7d c3 f6       	mov    $0xf6c37d1f,%ecx
      f5:	44 0f a3 d9          	bt     %r11d,%ecx
      f9:	73 14                	jae    10f <f_8001161d0+0x10f>
      fb:	44 89 d9             	mov    %r11d,%ecx
      fe:	83 e1 1f             	and    $0x1f,%ecx
     101:	48 8b 8c cd be 6b 16 	mov    0x166bbe(%rbp,%rcx,8),%rcx
     108:	00 
     109:	48 c1 e1 08          	shl    $0x8,%rcx
     10d:	eb 0f                	jmp    11e <f_8001161d0+0x11e>
     10f:	31 d2                	xor    %edx,%edx
     111:	41 83 fb 12          	cmp    $0x12,%r11d
     115:	b9 00 03 00 00       	mov    $0x300,%ecx
     11a:	48 0f 45 ca          	cmovne %rdx,%rcx
     11e:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     125:	ff ff ff 
     128:	49 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r14
     12f:	ff 7f ff 
     132:	41 0f be 97 17 29 00 	movsbl 0x2917(%r15),%edx
     139:	00 
     13a:	48 63 d2             	movslq %edx,%rdx
     13d:	4c 89 ab c0 00 00 00 	mov    %r13,0xc0(%rbx)
     144:	48 69 f2 48 07 00 00 	imul   $0x748,%rdx,%rsi
     14b:	45 31 c0             	xor    %r8d,%r8d
     14e:	41 39 94 24 90 33 00 	cmp    %edx,0x3390(%r12)
     155:	00 
     156:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     15d:	ff 7f 7f 
     160:	4c 0f 47 c6          	cmova  %rsi,%r8
     164:	49 b9 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r9
     16b:	00 80 3f 
     16e:	48 be 00 00 00 00 01 	movabs $0x100000000,%rsi
     175:	00 00 00 
     178:	4d 03 84 24 98 33 00 	add    0x3398(%r12),%r8
     17f:	00 
     180:	48 c7 43 70 ff ff ff 	movq   $0xffffffffffffffff,0x70(%rbx)
     187:	ff 
     188:	c5 fd 6f 05 00 00 00 	vmovdqa 0x0(%rip),%ymm0        # 190 <f_8001161d0+0x190>
     18f:	00 
     190:	c5 fe 7f 80 d0 fe ff 	vmovdqu %ymm0,-0x130(%rax)
     197:	ff 
     198:	ba ff ff ff ff       	mov    $0xffffffff,%edx
     19d:	48 89 53 78          	mov    %rdx,0x78(%rbx)
     1a1:	48 89 b0 f0 fe ff ff 	mov    %rsi,-0x110(%rax)
     1a8:	48 89 b8 f8 fe ff ff 	mov    %rdi,-0x108(%rax)
     1af:	4a 8d 8c 01 e8 01 00 	lea    0x1e8(%rcx,%r8,1),%rcx
     1b6:	00 
     1b7:	48 89 8b b8 00 00 00 	mov    %rcx,0xb8(%rbx)
     1be:	48 89 90 00 ff ff ff 	mov    %rdx,-0x100(%rax)
     1c5:	4c 89 88 08 ff ff ff 	mov    %r9,-0xf8(%rax)
     1cc:	4c 89 53 58          	mov    %r10,0x58(%rbx)
     1d0:	31 d2                	xor    %edx,%edx
     1d2:	44 89 de             	mov    %r11d,%esi
     1d5:	83 c6 df             	add    $0xffffffdf,%esi
     1d8:	0f 94 c2             	sete   %dl
     1db:	31 c9                	xor    %ecx,%ecx
     1dd:	41 83 fb 21          	cmp    $0x21,%r11d
     1e1:	0f 93 c1             	setae  %cl
     1e4:	41 b8 20 00 00 00    	mov    $0x20,%r8d
     1ea:	45 29 d8             	sub    %r11d,%r8d
     1ed:	45 21 d8             	and    %r11d,%r8d
     1f0:	81 e6 00 00 00 80    	and    $0x80000000,%esi
     1f6:	c1 e2 1e             	shl    $0x1e,%edx
     1f9:	c1 e1 1d             	shl    $0x1d,%ecx
     1fc:	09 f1                	or     %esi,%ecx
     1fe:	09 d1                	or     %edx,%ecx
     200:	41 c1 e8 03          	shr    $0x3,%r8d
     204:	41 81 e0 00 00 00 10 	and    $0x10000000,%r8d
     20b:	41 09 c8             	or     %ecx,%r8d
     20e:	4c 89 83 10 01 00 00 	mov    %r8,0x110(%rbx)
     215:	4c 89 88 10 ff ff ff 	mov    %r9,-0xf0(%rax)
     21c:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     223:	00 00 00 00 
     227:	4c 8b 85 7e 86 d5 00 	mov    0xd5867e(%rbp),%r8
     22e:	4c 89 43 50          	mov    %r8,0x50(%rbx)
     232:	48 8b b5 ae 5d d4 00 	mov    0xd45dae(%rbp),%rsi
     239:	48 89 73 48          	mov    %rsi,0x48(%rbx)
     23d:	49 8d 50 10          	lea    0x10(%r8),%rdx
     241:	48 89 90 20 ff ff ff 	mov    %rdx,-0xe0(%rax)
     248:	48 89 b0 40 ff ff ff 	mov    %rsi,-0xc0(%rax)
     24f:	48 8b bd b6 7e d5 00 	mov    0xd57eb6(%rbp),%rdi
     256:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
     25a:	48 83 c7 10          	add    $0x10,%rdi
     25e:	48 89 bb 80 00 00 00 	mov    %rdi,0x80(%rbx)
     265:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
     26c:	4c 89 b0 50 ff ff ff 	mov    %r14,-0xb0(%rax)
     273:	49 8d b1 00 00 80 c0 	lea    -0x3f800000(%r9),%rsi
     27a:	48 89 b0 74 ff ff ff 	mov    %rsi,-0x8c(%rax)
     281:	4c 8b 8d c6 7d d5 00 	mov    0xd57dc6(%rbp),%r9
     288:	4c 89 b0 68 ff ff ff 	mov    %r14,-0x98(%rax)
     28f:	45 8b 31             	mov    (%r9),%r14d
     292:	4c 89 73 40          	mov    %r14,0x40(%rbx)
     296:	48 89 b8 58 ff ff ff 	mov    %rdi,-0xa8(%rax)
     29d:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
     2a4:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     2ab:	00 
     2ac:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     2b0:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     2b7:	44 89 b0 70 ff ff ff 	mov    %r14d,-0x90(%rax)
     2be:	81 e1 00 00 00 60    	and    $0x60000000,%ecx
     2c4:	81 f9 00 00 00 20    	cmp    $0x20000000,%ecx
     2ca:	0f 84 70 2b 00 00    	je     2e40 <f_8001161d0+0x2e40>
     2d0:	48 89 3c 24          	mov    %rdi,(%rsp)
     2d4:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
     2d9:	49 89 ea             	mov    %rbp,%r10
     2dc:	48 8d b0 48 ff ff ff 	lea    -0xb8(%rax),%rsi
     2e3:	48 8d a8 60 ff ff ff 	lea    -0xa0(%rax),%rbp
     2ea:	4c 8d 48 80          	lea    -0x80(%rax),%r9
     2ee:	48 8d b8 70 ff ff ff 	lea    -0x90(%rax),%rdi
     2f5:	49 8d 8a 76 6b 16 00 	lea    0x166b76(%r10),%rcx
     2fc:	48 89 8b 88 00 00 00 	mov    %rcx,0x88(%rbx)
     303:	45 89 db             	mov    %r11d,%r11d
     306:	4c 89 9b 90 00 00 00 	mov    %r11,0x90(%rbx)
     30d:	4c 89 ab 80 00 00 00 	mov    %r13,0x80(%rbx)
     314:	43 0f b7 8c 5a 76 6b 	movzwl 0x166b76(%r10,%r11,2),%ecx
     31b:	16 00 
     31d:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     321:	4d 8d ac 8a 52 05 51 	lea    -0x2aefaae(%r10,%rcx,4),%r13
     328:	fd 
     329:	4c 89 2b             	mov    %r13,(%rbx)
     32c:	48 89 73 48          	mov    %rsi,0x48(%rbx)
     330:	49 89 ea             	mov    %rbp,%r10
     333:	48 89 ab d0 00 00 00 	mov    %rbp,0xd0(%rbx)
     33a:	48 89 bb c8 00 00 00 	mov    %rdi,0xc8(%rbx)
     341:	4c 89 8b d8 00 00 00 	mov    %r9,0xd8(%rbx)
     348:	81 f9 86 02 00 00    	cmp    $0x286,%ecx
     34e:	7f 5f                	jg     3af <f_8001161d0+0x3af>
     350:	81 f9 2d 01 00 00    	cmp    $0x12d,%ecx
     356:	0f 8f e1 00 00 00    	jg     43d <f_8001161d0+0x43d>
     35c:	83 f9 6f             	cmp    $0x6f,%ecx
     35f:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
     364:	0f 8f bf 03 00 00    	jg     729 <f_8001161d0+0x729>
     36a:	83 f9 04             	cmp    $0x4,%ecx
     36d:	0f 87 5a 10 00 00    	ja     13cd <f_8001161d0+0x13cd>
     373:	89 c9                	mov    %ecx,%ecx
     375:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 37c <f_8001161d0+0x37c>
     37c:	48 63 0c 8e          	movslq (%rsi,%rcx,4),%rcx
     380:	48 01 f1             	add    %rsi,%rcx
     383:	ff e1                	jmp    *%rcx
     385:	45 0f b7 9c 24 e4 0c 	movzwl 0xce4(%r12),%r11d
     38c:	00 00 
     38e:	8b 8b a8 00 00 00    	mov    0xa8(%rbx),%ecx
     394:	be ff ff ff ff       	mov    $0xffffffff,%esi
     399:	01 f1                	add    %esi,%ecx
     39b:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
     39f:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
     3a6:	0f b6 79 08          	movzbl 0x8(%rcx),%edi
     3aa:	e9 ec 15 00 00       	jmp    199b <f_8001161d0+0x199b>
     3af:	81 f9 6d 04 00 00    	cmp    $0x46d,%ecx
     3b5:	0f 8e 25 02 00 00    	jle    5e0 <f_8001161d0+0x5e0>
     3bb:	44 8d 81 92 fb ff ff 	lea    -0x46e(%rcx),%r8d
     3c2:	41 83 f8 0c          	cmp    $0xc,%r8d
     3c6:	0f 86 89 07 00 00    	jbe    b55 <f_8001161d0+0xb55>
     3cc:	44 8d 81 36 fb ff ff 	lea    -0x4ca(%rcx),%r8d
     3d3:	41 83 f8 16          	cmp    $0x16,%r8d
     3d7:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
     3dc:	0f 87 92 0f 00 00    	ja     1374 <f_8001161d0+0x1374>
     3e2:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 3e9 <f_8001161d0+0x3e9>
     3e9:	4a 63 34 81          	movslq (%rcx,%r8,4),%rsi
     3ed:	48 01 ce             	add    %rcx,%rsi
     3f0:	ff e6                	jmp    *%rsi
     3f2:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
     3f9:	00 
     3fa:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
     401:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     408:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     40c:	48 89 43 10          	mov    %rax,0x10(%rbx)
     410:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
     415:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
     41c:	48 89 03             	mov    %rax,(%rbx)
     41f:	48 c7 43 18 01 00 00 	movq   $0x1,0x18(%rbx)
     426:	00 
     427:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
     42e:	00 00 00 
     431:	48 8d 85 92 18 51 fd 	lea    -0x2aee76e(%rbp),%rax
     438:	e9 2c 1a 00 00       	jmp    1e69 <f_8001161d0+0x1e69>
     43d:	81 f9 c7 01 00 00    	cmp    $0x1c7,%ecx
     443:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
     448:	0f 8f b5 05 00 00    	jg     a03 <f_8001161d0+0xa03>
     44e:	81 f9 b1 01 00 00    	cmp    $0x1b1,%ecx
     454:	0f 8f 2d 0a 00 00    	jg     e87 <f_8001161d0+0xe87>
     45a:	81 f9 2e 01 00 00    	cmp    $0x12e,%ecx
     460:	0f 84 be 1f 00 00    	je     2424 <f_8001161d0+0x2424>
     466:	81 f9 66 01 00 00    	cmp    $0x166,%ecx
     46c:	0f 85 91 19 00 00    	jne    1e03 <f_8001161d0+0x1e03>
     472:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
     479:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
     480:	48 8b b6 c8 1e 00 00 	mov    0x1ec8(%rsi),%rsi
     487:	48 89 73 08          	mov    %rsi,0x8(%rbx)
     48b:	48 c7 83 80 00 00 00 	movq   $0x3ce0,0x80(%rbx)
     492:	e0 3c 00 00 
     496:	4c 8b 14 24          	mov    (%rsp),%r10
     49a:	4c 89 53 60          	mov    %r10,0x60(%rbx)
     49e:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
     4a2:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
     4a6:	4c 69 c1 e0 3c 00 00 	imul   $0x3ce0,%rcx,%r8
     4ad:	45 31 c9             	xor    %r9d,%r9d
     4b0:	39 4e 08             	cmp    %ecx,0x8(%rsi)
     4b3:	4d 0f 47 c8          	cmova  %r8,%r9
     4b7:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
     4bb:	49 8b 8c 09 40 3c 00 	mov    0x3c40(%r9,%rcx,1),%rcx
     4c2:	00 
     4c3:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
     4ca:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     4d1:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
     4d8:	4c 89 91 88 00 00 00 	mov    %r10,0x88(%rcx)
     4df:	48 be ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rsi
     4e6:	ff 7f 7f 
     4e9:	48 89 b1 90 00 00 00 	mov    %rsi,0x90(%rcx)
     4f0:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     4f7:	00 
     4f8:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     4fc:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
     503:	00 00 00 
     506:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
     50d:	00 
     50e:	48 89 51 50          	mov    %rdx,0x50(%rcx)
     512:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
     516:	c5 fa 7f 41 58       	vmovdqu %xmm0,0x58(%rcx)
     51b:	48 c7 41 30 08 00 00 	movq   $0x8,0x30(%rcx)
     522:	00 
     523:	48 b8 10 00 00 00 03 	movabs $0x300000010,%rax
     52a:	00 00 00 
     52d:	48 89 01             	mov    %rax,(%rcx)
     530:	48 c7 41 08 00 00 00 	movq   $0x0,0x8(%rcx)
     537:	00 
     538:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     53f:	00 
     540:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     547:	ff ff ff 
     54a:	48 8d 42 0d          	lea    0xd(%rdx),%rax
     54e:	48 89 41 18          	mov    %rax,0x18(%rcx)
     552:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     559:	00 00 00 
     55c:	48 89 41 20          	mov    %rax,0x20(%rcx)
     560:	48 89 51 28          	mov    %rdx,0x28(%rcx)
     564:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     56b:	48 89 b8 a4 00 00 00 	mov    %rdi,0xa4(%rax)
     572:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
     579:	00 80 3f 
     57c:	48 89 41 38          	mov    %rax,0x38(%rcx)
     580:	48 89 41 40          	mov    %rax,0x40(%rcx)
     584:	49 be ca 5d c0 02 08 	movabs $0x802c05dca,%r14
     58b:	00 00 00 
     58e:	49 8d 86 8b 0d 02 00 	lea    0x20d8b(%r14),%rax
     595:	48 89 43 70          	mov    %rax,0x70(%rbx)
     599:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
     5a0:	ff 7f ff 
     5a3:	48 89 73 78          	mov    %rsi,0x78(%rbx)
     5a7:	48 89 b1 98 00 00 00 	mov    %rsi,0x98(%rcx)
     5ae:	48 8b 53 58          	mov    0x58(%rbx),%rdx
     5b2:	48 89 51 78          	mov    %rdx,0x78(%rcx)
     5b6:	48 89 b1 80 00 00 00 	mov    %rsi,0x80(%rcx)
     5bd:	48 8d 93 80 00 00 00 	lea    0x80(%rbx),%rdx
     5c4:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
     5cb:	00 
     5cc:	48 89 41 70          	mov    %rax,0x70(%rcx)
     5d0:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
     5d4:	8b 71 08             	mov    0x8(%rcx),%esi
     5d7:	48 89 73 40          	mov    %rsi,0x40(%rbx)
     5db:	e9 bc 1f 00 00       	jmp    259c <f_8001161d0+0x259c>
     5e0:	81 f9 d4 02 00 00    	cmp    $0x2d4,%ecx
     5e6:	0f 8f ba 04 00 00    	jg     aa6 <f_8001161d0+0xaa6>
     5ec:	81 f9 b5 02 00 00    	cmp    $0x2b5,%ecx
     5f2:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
     5f7:	0f 8f 28 09 00 00    	jg     f25 <f_8001161d0+0xf25>
     5fd:	81 f9 87 02 00 00    	cmp    $0x287,%ecx
     603:	0f 84 fd 20 00 00    	je     2706 <f_8001161d0+0x2706>
     609:	81 f9 97 02 00 00    	cmp    $0x297,%ecx
     60f:	0f 85 ee 17 00 00    	jne    1e03 <f_8001161d0+0x1e03>
     615:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     61c:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
     623:	48 c7 01 00 00 00 40 	movq   $0x40000000,(%rcx)
     62a:	49 b8 00 00 00 00 00 	movabs $0x40000000000000,%r8
     631:	00 40 00 
     634:	4c 89 41 08          	mov    %r8,0x8(%rcx)
     638:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     63f:	00 
     640:	49 89 f9             	mov    %rdi,%r9
     643:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     64a:	ff ff ff 
     64d:	4c 8d 47 14          	lea    0x14(%rdi),%r8
     651:	4c 89 41 18          	mov    %r8,0x18(%rcx)
     655:	48 89 53 40          	mov    %rdx,0x40(%rbx)
     659:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     65d:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     664:	00 
     665:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
     66c:	00 00 00 
     66f:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     676:	00 00 00 
     679:	48 89 41 20          	mov    %rax,0x20(%rcx)
     67d:	48 89 79 28          	mov    %rdi,0x28(%rcx)
     681:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
     686:	48 89 41 30          	mov    %rax,0x30(%rcx)
     68a:	49 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r8
     691:	00 80 3f 
     694:	4c 89 41 38          	mov    %r8,0x38(%rcx)
     698:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
     69f:	00 00 00 
     6a2:	48 8d 80 80 0d 02 00 	lea    0x20d80(%rax),%rax
     6a9:	48 89 41 70          	mov    %rax,0x70(%rcx)
     6ad:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
     6b4:	ff 7f 7f 
     6b7:	4c 89 59 78          	mov    %r11,0x78(%rcx)
     6bb:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
     6c2:	ff 7f ff 
     6c5:	48 89 b9 80 00 00 00 	mov    %rdi,0x80(%rcx)
     6cc:	48 8b 04 24          	mov    (%rsp),%rax
     6d0:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
     6d7:	c5 fd 6f 05 00 00 00 	vmovdqa 0x0(%rip),%ymm0        # 6df <f_8001161d0+0x6df>
     6de:	00 
     6df:	c5 fe 7f 43 60       	vmovdqu %ymm0,0x60(%rbx)
     6e4:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     6eb:	4c 89 88 a4 00 00 00 	mov    %r9,0xa4(%rax)
     6f2:	4c 89 41 40          	mov    %r8,0x40(%rcx)
     6f6:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
     6fd:	00 
     6fe:	4c 89 99 90 00 00 00 	mov    %r11,0x90(%rcx)
     705:	48 89 b9 98 00 00 00 	mov    %rdi,0x98(%rcx)
     70c:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
     713:	00 
     714:	48 89 51 50          	mov    %rdx,0x50(%rcx)
     718:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
     71c:	c5 fa 7f 41 58       	vmovdqu %xmm0,0x58(%rcx)
     721:	4d 89 d7             	mov    %r10,%r15
     724:	e9 fa 25 00 00       	jmp    2d23 <f_8001161d0+0x2d23>
     729:	81 f9 c8 00 00 00    	cmp    $0xc8,%ecx
     72f:	0f 8f 43 04 00 00    	jg     b78 <f_8001161d0+0xb78>
     735:	83 f9 70             	cmp    $0x70,%ecx
     738:	0f 84 e5 19 00 00    	je     2123 <f_8001161d0+0x2123>
     73e:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
     744:	0f 85 b9 16 00 00    	jne    1e03 <f_8001161d0+0x1e03>
     74a:	4d 8b 9c 24 c8 1e 00 	mov    0x1ec8(%r12),%r11
     751:	00 
     752:	4c 89 5b 08          	mov    %r11,0x8(%rbx)
     756:	4c 8b 14 24          	mov    (%rsp),%r10
     75a:	4c 89 53 60          	mov    %r10,0x60(%rbx)
     75e:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
     765:	00 
     766:	41 0f b6 77 08       	movzbl 0x8(%r15),%esi
     76b:	48 89 73 68          	mov    %rsi,0x68(%rbx)
     76f:	45 8b 4b 08          	mov    0x8(%r11),%r9d
     773:	4d 8b 7b 10          	mov    0x10(%r11),%r15
     777:	4c 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%r8
     77e:	31 c9                	xor    %ecx,%ecx
     780:	41 39 f1             	cmp    %esi,%r9d
     783:	41 b9 00 00 00 00    	mov    $0x0,%r9d
     789:	4d 0f 47 c8          	cmova  %r8,%r9
     78d:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
     794:	00 
     795:	4f 8b 8c 39 40 3c 00 	mov    0x3c40(%r9,%r15,1),%r9
     79c:	00 
     79d:	4c 89 8b b0 00 00 00 	mov    %r9,0xb0(%rbx)
     7a4:	44 89 b0 70 ff ff ff 	mov    %r14d,-0x90(%rax)
     7ab:	4c 89 90 58 ff ff ff 	mov    %r10,-0xa8(%rax)
     7b2:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     7b9:	ff 7f 7f 
     7bc:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
     7c3:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     7ca:	00 
     7cb:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     7cf:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     7d6:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     7dd:	00 00 00 00 
     7e1:	48 89 90 20 ff ff ff 	mov    %rdx,-0xe0(%rax)
     7e8:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
     7ec:	c5 fa 7f 80 28 ff ff 	vmovdqu %xmm0,-0xd8(%rax)
     7f3:	ff 
     7f4:	48 c7 80 00 ff ff ff 	movq   $0x5,-0x100(%rax)
     7fb:	05 00 00 00 
     7ff:	48 ba 10 00 00 00 03 	movabs $0x300000010,%rdx
     806:	00 00 00 
     809:	48 81 c2 f0 00 00 00 	add    $0xf0,%rdx
     810:	48 89 90 d0 fe ff ff 	mov    %rdx,-0x130(%rax)
     817:	48 ba 00 00 00 00 00 	movabs $0x60000000000000,%rdx
     81e:	00 60 00 
     821:	48 89 90 d8 fe ff ff 	mov    %rdx,-0x128(%rax)
     828:	4c 89 0b             	mov    %r9,(%rbx)
     82b:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     832:	ff ff 00 00 
     836:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     83d:	ff ff ff 
     840:	49 89 f9             	mov    %rdi,%r9
     843:	48 89 d7             	mov    %rdx,%rdi
     846:	48 83 c2 08          	add    $0x8,%rdx
     84a:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
     851:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
     858:	00 00 00 
     85b:	48 89 90 f0 fe ff ff 	mov    %rdx,-0x110(%rax)
     862:	48 89 b8 f8 fe ff ff 	mov    %rdi,-0x108(%rax)
     869:	48 8b 93 c0 00 00 00 	mov    0xc0(%rbx),%rdx
     870:	4c 89 8a a4 00 00 00 	mov    %r9,0xa4(%rdx)
     877:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
     87e:	00 80 3f 
     881:	48 89 90 08 ff ff ff 	mov    %rdx,-0xf8(%rax)
     888:	48 89 90 10 ff ff ff 	mov    %rdx,-0xf0(%rax)
     88f:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
     896:	00 00 00 
     899:	48 8d 95 1d 54 09 00 	lea    0x9541d(%rbp),%rdx
     8a0:	48 89 53 78          	mov    %rdx,0x78(%rbx)
     8a4:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
     8ab:	ff 7f ff 
     8ae:	48 89 bb 80 00 00 00 	mov    %rdi,0x80(%rbx)
     8b5:	48 89 b8 68 ff ff ff 	mov    %rdi,-0x98(%rax)
     8bc:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
     8c3:	48 89 b8 50 ff ff ff 	mov    %rdi,-0xb0(%rax)
     8ca:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
     8d1:	00 00 00 00 
     8d5:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
     8dc:	41 39 73 08          	cmp    %esi,0x8(%r11)
     8e0:	ba 00 00 00 00       	mov    $0x0,%edx
     8e5:	49 0f 47 d0          	cmova  %r8,%rdx
     8e9:	49 8b 7b 10          	mov    0x10(%r11),%rdi
     8ed:	c5 fa 6f 84 17 00 2e 	vmovdqu 0x2e00(%rdi,%rdx,1),%xmm0
     8f4:	00 00 
     8f6:	c5 fa 7f 80 48 ff ff 	vmovdqu %xmm0,-0xb8(%rax)
     8fd:	ff 
     8fe:	41 8b 7b 08          	mov    0x8(%r11),%edi
     902:	45 31 c9             	xor    %r9d,%r9d
     905:	31 d2                	xor    %edx,%edx
     907:	41 89 fa             	mov    %edi,%r10d
     90a:	41 29 f2             	sub    %esi,%r10d
     90d:	49 0f 47 c8          	cmova  %r8,%rcx
     911:	41 0f 94 c1          	sete   %r9b
     915:	0f 93 c2             	setae  %dl
     918:	41 c1 e1 1e          	shl    $0x1e,%r9d
     91c:	c1 e2 1d             	shl    $0x1d,%edx
     91f:	44 09 ca             	or     %r9d,%edx
     922:	c4 e2 28 f2 f7       	andn   %edi,%r10d,%esi
     927:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
     92e:	44 09 d2             	or     %r10d,%edx
     931:	49 8b 7b 10          	mov    0x10(%r11),%rdi
     935:	c1 ee 03             	shr    $0x3,%esi
     938:	81 e6 00 00 00 10    	and    $0x10000000,%esi
     93e:	09 d6                	or     %edx,%esi
     940:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
     947:	48 8b 94 0f 80 30 00 	mov    0x3080(%rdi,%rcx,1),%rdx
     94e:	00 
     94f:	48 8b b4 0f 88 30 00 	mov    0x3088(%rdi,%rcx,1),%rsi
     956:	00 
     957:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     95b:	48 89 90 60 ff ff ff 	mov    %rdx,-0xa0(%rax)
     962:	48 89 b0 68 ff ff ff 	mov    %rsi,-0x98(%rax)
     969:	48 8b 94 0f 90 30 00 	mov    0x3090(%rdi,%rcx,1),%rdx
     970:	00 
     971:	48 89 53 48          	mov    %rdx,0x48(%rbx)
     975:	8b 8c 0f 98 30 00 00 	mov    0x3098(%rdi,%rcx,1),%ecx
     97c:	89 88 78 ff ff ff    	mov    %ecx,-0x88(%rax)
     982:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
     989:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
     98d:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
     991:	48 89 90 70 ff ff ff 	mov    %rdx,-0x90(%rax)
     998:	48 8d 85 56 08 51 fd 	lea    -0x2aef7aa(%rbp),%rax
     99f:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
     9a6:	48 89 df             	mov    %rbx,%rdi
     9a9:	c5 f8 77             	vzeroupper
     9ac:	e8 00 00 00 00       	call   9b1 <f_8001161d0+0x9b1>
     9b1:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     9b8:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
     9bf:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     9c6:	48 89 01             	mov    %rax,(%rcx)
     9c9:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     9d0:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     9d7:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
     9db:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
     9e2:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     9e6:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     9ec:	48 89 43 40          	mov    %rax,0x40(%rbx)
     9f0:	88 51 08             	mov    %dl,0x8(%rcx)
     9f3:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     9fa:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
     9fe:	e9 e9 1c 00 00       	jmp    26ec <f_8001161d0+0x26ec>
     a03:	81 f9 51 02 00 00    	cmp    $0x251,%ecx
     a09:	0f 8f ba 05 00 00    	jg     fc9 <f_8001161d0+0xfc9>
     a0f:	81 f9 c8 01 00 00    	cmp    $0x1c8,%ecx
     a15:	0f 84 71 1d 00 00    	je     278c <f_8001161d0+0x278c>
     a1b:	81 f9 0f 02 00 00    	cmp    $0x20f,%ecx
     a21:	0f 85 dc 13 00 00    	jne    1e03 <f_8001161d0+0x1e03>
     a27:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     a2e:	00 
     a2f:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     a36:	48 c7 01 00 08 00 00 	movq   $0x800,(%rcx)
     a3d:	48 c7 41 08 01 00 00 	movq   $0x1,0x8(%rcx)
     a44:	00 
     a45:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     a4c:	ff ff ff 
     a4f:	48 8d 77 0b          	lea    0xb(%rdi),%rsi
     a53:	48 89 73 68          	mov    %rsi,0x68(%rbx)
     a57:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     a5e:	00 
     a5f:	48 89 71 18          	mov    %rsi,0x18(%rcx)
     a63:	49 bc 00 00 00 00 01 	movabs $0x100000000,%r12
     a6a:	00 00 00 
     a6d:	4c 89 61 20          	mov    %r12,0x20(%rcx)
     a71:	48 89 79 28          	mov    %rdi,0x28(%rcx)
     a75:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
     a7c:	00 80 3f 
     a7f:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
     a83:	be ff ff ff ff       	mov    $0xffffffff,%esi
     a88:	48 89 71 30          	mov    %rsi,0x30(%rcx)
     a8c:	4c 89 79 38          	mov    %r15,0x38(%rcx)
     a90:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
     a97:	00 00 00 
     a9a:	4c 8d 9d 07 a8 04 00 	lea    0x4a807(%rbp),%r11
     aa1:	e9 ac 17 00 00       	jmp    2252 <f_8001161d0+0x2252>
     aa6:	81 f9 ac 03 00 00    	cmp    $0x3ac,%ecx
     aac:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
     ab1:	0f 8f 90 06 00 00    	jg     1147 <f_8001161d0+0x1147>
     ab7:	81 f9 d5 02 00 00    	cmp    $0x2d5,%ecx
     abd:	0f 84 5a 1f 00 00    	je     2a1d <f_8001161d0+0x2a1d>
     ac3:	81 f9 f3 02 00 00    	cmp    $0x2f3,%ecx
     ac9:	0f 85 34 13 00 00    	jne    1e03 <f_8001161d0+0x1e03>
     acf:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     ad6:	00 
     ad7:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
     ade:	49 c7 03 00 02 00 00 	movq   $0x200,(%r11)
     ae5:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
     aec:	00 40 00 
     aef:	49 89 4b 08          	mov    %rcx,0x8(%r11)
     af3:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
     afa:	00 
     afb:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     b02:	ff ff ff 
     b05:	48 8d 4f 13          	lea    0x13(%rdi),%rcx
     b09:	49 89 4b 18          	mov    %rcx,0x18(%r11)
     b0d:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     b14:	00 00 00 
     b17:	49 89 4b 20          	mov    %rcx,0x20(%r11)
     b1b:	49 89 7b 28          	mov    %rdi,0x28(%r11)
     b1f:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
     b25:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
     b29:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
     b30:	00 80 3f 
     b33:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
     b37:	49 8d 4b 30          	lea    0x30(%r11),%rcx
     b3b:	49 83 c3 38          	add    $0x38,%r11
     b3f:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
     b46:	00 00 00 
     b49:	4c 8d 87 f9 7a ff ff 	lea    -0x8507(%rdi),%r8
     b50:	e9 20 21 00 00       	jmp    2c75 <f_8001161d0+0x2c75>
     b55:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # b5c <f_8001161d0+0xb5c>
     b5c:	4a 63 34 81          	movslq (%rcx,%r8,4),%rsi
     b60:	48 01 ce             	add    %rcx,%rsi
     b63:	ff e6                	jmp    *%rsi
     b65:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
     b6c:	00 00 00 
     b6f:	4c 8d 5d e0          	lea    -0x20(%rbp),%r11
     b73:	e9 2d 09 00 00       	jmp    14a5 <f_8001161d0+0x14a5>
     b78:	81 f9 c9 00 00 00    	cmp    $0xc9,%ecx
     b7e:	0f 84 37 16 00 00    	je     21bb <f_8001161d0+0x21bb>
     b84:	81 f9 d9 00 00 00    	cmp    $0xd9,%ecx
     b8a:	0f 85 73 12 00 00    	jne    1e03 <f_8001161d0+0x1e03>
     b90:	49 8b 8c 24 c8 1e 00 	mov    0x1ec8(%r12),%rcx
     b97:	00 
     b98:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     b9c:	4c 8b 14 24          	mov    (%rsp),%r10
     ba0:	4c 89 53 60          	mov    %r10,0x60(%rbx)
     ba4:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
     bab:	00 
     bac:	45 0f b6 5f 08       	movzbl 0x8(%r15),%r11d
     bb1:	4c 89 5b 70          	mov    %r11,0x70(%rbx)
     bb5:	41 0f b7 af 14 29 00 	movzwl 0x2914(%r15),%ebp
     bbc:	00 
     bbd:	83 e5 40             	and    $0x40,%ebp
     bc0:	8b 71 08             	mov    0x8(%rcx),%esi
     bc3:	4c 8b 49 10          	mov    0x10(%rcx),%r9
     bc7:	45 31 c0             	xor    %r8d,%r8d
     bca:	44 39 de             	cmp    %r11d,%esi
     bcd:	be 00 00 00 00       	mov    $0x0,%esi
     bd2:	49 0f 47 f3          	cmova  %r11,%rsi
     bd6:	48 c7 43 78 e0 3c 00 	movq   $0x3ce0,0x78(%rbx)
     bdd:	00 
     bde:	48 89 b3 88 00 00 00 	mov    %rsi,0x88(%rbx)
     be5:	48 69 f6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rsi
     bec:	4a 8b b4 0e 40 3c 00 	mov    0x3c40(%rsi,%r9,1),%rsi
     bf3:	00 
     bf4:	48 89 b3 b0 00 00 00 	mov    %rsi,0xb0(%rbx)
     bfb:	4c 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%r9
     c02:	4d 8b 89 b8 1e 00 00 	mov    0x1eb8(%r9),%r9
     c09:	44 89 b0 70 ff ff ff 	mov    %r14d,-0x90(%rax)
     c10:	4c 89 90 58 ff ff ff 	mov    %r10,-0xa8(%rax)
     c17:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     c1e:	ff 7f 7f 
     c21:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
     c28:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     c2f:	00 
     c30:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     c34:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     c3b:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
     c3f:	c5 fa 7f 80 28 ff ff 	vmovdqu %xmm0,-0xd8(%rax)
     c46:	ff 
     c47:	41 80 b9 b0 06 00 00 	cmpb   $0x0,0x6b0(%r9)
     c4e:	00 
     c4f:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     c56:	00 00 00 00 
     c5a:	48 89 90 20 ff ff ff 	mov    %rdx,-0xe0(%rax)
     c61:	48 c7 80 00 ff ff ff 	movq   $0x4,-0x100(%rax)
     c68:	04 00 00 00 
     c6c:	48 89 33             	mov    %rsi,(%rbx)
     c6f:	0f 95 c2             	setne  %dl
     c72:	c1 ed 06             	shr    $0x6,%ebp
     c75:	40 20 d5             	and    %dl,%bpl
     c78:	c7 80 d8 fe ff ff 00 	movl   $0x0,-0x128(%rax)
     c7f:	00 00 00 
     c82:	40 0f b6 d5          	movzbl %bpl,%edx
     c86:	c1 e2 1a             	shl    $0x1a,%edx
     c89:	81 ca 01 00 40 00    	or     $0x400001,%edx
     c8f:	89 90 dc fe ff ff    	mov    %edx,-0x124(%rax)
     c95:	48 ba 10 00 00 00 03 	movabs $0x300000010,%rdx
     c9c:	00 00 00 
     c9f:	48 89 90 d0 fe ff ff 	mov    %rdx,-0x130(%rax)
     ca6:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     cad:	ff ff 00 00 
     cb1:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
     cb8:	ff ff ff 
     cbb:	48 8d 56 07          	lea    0x7(%rsi),%rdx
     cbf:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
     cc6:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
     ccd:	00 00 00 
     cd0:	48 89 90 f0 fe ff ff 	mov    %rdx,-0x110(%rax)
     cd7:	48 89 b0 f8 fe ff ff 	mov    %rsi,-0x108(%rax)
     cde:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
     ce5:	00 80 3f 
     ce8:	48 89 90 08 ff ff ff 	mov    %rdx,-0xf8(%rax)
     cef:	48 89 90 10 ff ff ff 	mov    %rdx,-0xf0(%rax)
     cf6:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
     cfd:	00 00 00 
     d00:	48 8d 95 00 54 09 00 	lea    0x95400(%rbp),%rdx
     d07:	48 89 53 68          	mov    %rdx,0x68(%rbx)
     d0b:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
     d12:	48 89 be a4 00 00 00 	mov    %rdi,0xa4(%rsi)
     d19:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
     d20:	ff 7f ff 
     d23:	48 89 b3 80 00 00 00 	mov    %rsi,0x80(%rbx)
     d2a:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
     d31:	48 89 b0 50 ff ff ff 	mov    %rsi,-0xb0(%rax)
     d38:	48 89 b0 68 ff ff ff 	mov    %rsi,-0x98(%rax)
     d3f:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
     d46:	00 00 00 00 
     d4a:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
     d51:	49 69 d3 e0 3c 00 00 	imul   $0x3ce0,%r11,%rdx
     d58:	44 39 59 08          	cmp    %r11d,0x8(%rcx)
     d5c:	49 0f 46 d0          	cmovbe %r8,%rdx
     d60:	48 8b 71 10          	mov    0x10(%rcx),%rsi
     d64:	c5 fa 6f 84 16 00 2e 	vmovdqu 0x2e00(%rsi,%rdx,1),%xmm0
     d6b:	00 00 
     d6d:	c5 fa 7f 80 48 ff ff 	vmovdqu %xmm0,-0xb8(%rax)
     d74:	ff 
     d75:	8b 71 08             	mov    0x8(%rcx),%esi
     d78:	31 ff                	xor    %edi,%edi
     d7a:	31 c0                	xor    %eax,%eax
     d7c:	41 89 f1             	mov    %esi,%r9d
     d7f:	45 29 d9             	sub    %r11d,%r9d
     d82:	8b 53 70             	mov    0x70(%rbx),%edx
     d85:	49 0f 46 d0          	cmovbe %r8,%rdx
     d89:	40 0f 94 c7          	sete   %dil
     d8d:	0f 93 c0             	setae  %al
     d90:	c1 e7 1e             	shl    $0x1e,%edi
     d93:	c1 e0 1d             	shl    $0x1d,%eax
     d96:	09 f8                	or     %edi,%eax
     d98:	48 8b 49 10          	mov    0x10(%rcx),%rcx
     d9c:	c4 e2 30 f2 f6       	andn   %esi,%r9d,%esi
     da1:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
     da8:	44 09 c8             	or     %r9d,%eax
     dab:	8b 7b 78             	mov    0x78(%rbx),%edi
     dae:	c1 ee 03             	shr    $0x3,%esi
     db1:	81 e6 00 00 00 10    	and    $0x10000000,%esi
     db7:	09 c6                	or     %eax,%esi
     db9:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
     dc0:	48 0f af fa          	imul   %rdx,%rdi
     dc4:	48 8b 84 0f 80 30 00 	mov    0x3080(%rdi,%rcx,1),%rax
     dcb:	00 
     dcc:	48 8b 94 0f 88 30 00 	mov    0x3088(%rdi,%rcx,1),%rdx
     dd3:	00 
     dd4:	48 89 53 50          	mov    %rdx,0x50(%rbx)
     dd8:	48 8b b3 d0 00 00 00 	mov    0xd0(%rbx),%rsi
     ddf:	48 89 06             	mov    %rax,(%rsi)
     de2:	48 89 56 08          	mov    %rdx,0x8(%rsi)
     de6:	48 8b 84 0f 90 30 00 	mov    0x3090(%rdi,%rcx,1),%rax
     ded:	00 
     dee:	48 89 43 48          	mov    %rax,0x48(%rbx)
     df2:	8b 8c 0f 98 30 00 00 	mov    0x3098(%rdi,%rcx,1),%ecx
     df9:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
     e00:	89 4a 08             	mov    %ecx,0x8(%rdx)
     e03:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
     e0a:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
     e0e:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
     e12:	48 89 02             	mov    %rax,(%rdx)
     e15:	48 8d 85 e6 09 51 fd 	lea    -0x2aef61a(%rbp),%rax
     e1c:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
     e23:	48 89 df             	mov    %rbx,%rdi
     e26:	c5 f8 77             	vzeroupper
     e29:	e8 00 00 00 00       	call   e2e <f_8001161d0+0xe2e>
     e2e:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     e35:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
     e3c:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     e43:	48 89 01             	mov    %rax,(%rcx)
     e46:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     e4d:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     e54:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
     e58:	48 89 53 48          	mov    %rdx,0x48(%rbx)
     e5c:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
     e63:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     e67:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     e6d:	48 89 43 40          	mov    %rax,0x40(%rbx)
     e71:	88 51 08             	mov    %dl,0x8(%rcx)
     e74:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     e7b:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
     e7f:	89 41 24             	mov    %eax,0x24(%rcx)
     e82:	e9 b9 1f 00 00       	jmp    2e40 <f_8001161d0+0x2e40>
     e87:	81 f9 b2 01 00 00    	cmp    $0x1b2,%ecx
     e8d:	0f 84 93 1c 00 00    	je     2b26 <f_8001161d0+0x2b26>
     e93:	81 f9 b8 01 00 00    	cmp    $0x1b8,%ecx
     e99:	0f 85 64 0f 00 00    	jne    1e03 <f_8001161d0+0x1e03>
     e9f:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     ea6:	00 
     ea7:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
     eae:	49 c7 03 08 00 00 00 	movq   $0x8,(%r11)
     eb5:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
     ebc:	00 40 00 
     ebf:	49 89 4b 08          	mov    %rcx,0x8(%r11)
     ec3:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
     eca:	00 
     ecb:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     ed2:	ff ff ff 
     ed5:	48 8d 4f 15          	lea    0x15(%rdi),%rcx
     ed9:	49 89 4b 18          	mov    %rcx,0x18(%r11)
     edd:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     ee4:	00 00 00 
     ee7:	49 89 4b 20          	mov    %rcx,0x20(%r11)
     eeb:	49 89 7b 28          	mov    %rdi,0x28(%r11)
     eef:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
     ef5:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
     ef9:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
     f00:	00 80 3f 
     f03:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
     f07:	49 8d 4b 30          	lea    0x30(%r11),%rcx
     f0b:	49 83 c3 38          	add    $0x38,%r11
     f0f:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
     f16:	00 00 00 
     f19:	4c 8d 87 af 2c 05 00 	lea    0x52caf(%rdi),%r8
     f20:	e9 50 1d 00 00       	jmp    2c75 <f_8001161d0+0x2c75>
     f25:	81 f9 b6 02 00 00    	cmp    $0x2b6,%ecx
     f2b:	0f 84 4a 1c 00 00    	je     2b7b <f_8001161d0+0x2b7b>
     f31:	81 f9 c5 02 00 00    	cmp    $0x2c5,%ecx
     f37:	0f 85 c6 0e 00 00    	jne    1e03 <f_8001161d0+0x1e03>
     f3d:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     f44:	00 
     f45:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
     f4c:	48 b9 01 00 00 00 04 	movabs $0x400000001,%rcx
     f53:	00 00 00 
     f56:	49 89 0b             	mov    %rcx,(%r11)
     f59:	48 b9 00 00 00 00 02 	movabs $0x80200000000,%rcx
     f60:	08 00 00 
     f63:	49 89 4b 08          	mov    %rcx,0x8(%r11)
     f67:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
     f6e:	00 
     f6f:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     f76:	ff ff ff 
     f79:	48 8d 4f 0f          	lea    0xf(%rdi),%rcx
     f7d:	49 89 4b 18          	mov    %rcx,0x18(%r11)
     f81:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     f88:	00 00 00 
     f8b:	49 89 4b 20          	mov    %rcx,0x20(%r11)
     f8f:	49 89 7b 28          	mov    %rdi,0x28(%r11)
     f93:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
     f99:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
     f9d:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
     fa4:	00 80 3f 
     fa7:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
     fab:	49 8d 4b 30          	lea    0x30(%r11),%rcx
     faf:	49 83 c3 38          	add    $0x38,%r11
     fb3:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
     fba:	00 00 00 
     fbd:	4c 8d 87 88 db 0a 00 	lea    0xadb88(%rdi),%r8
     fc4:	e9 ac 1c 00 00       	jmp    2c75 <f_8001161d0+0x2c75>
     fc9:	81 f9 52 02 00 00    	cmp    $0x252,%ecx
     fcf:	0f 84 29 1c 00 00    	je     2bfe <f_8001161d0+0x2bfe>
     fd5:	81 f9 61 02 00 00    	cmp    $0x261,%ecx
     fdb:	0f 85 22 0e 00 00    	jne    1e03 <f_8001161d0+0x1e03>
     fe1:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     fe8:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
     fef:	48 be 00 00 00 00 0f 	movabs $0xf00000000,%rsi
     ff6:	00 00 00 
     ff9:	48 89 71 14          	mov    %rsi,0x14(%rcx)
     ffd:	48 be 00 00 00 00 ff 	movabs $0xffff00000000,%rsi
    1004:	ff 00 00 
    1007:	48 81 ce 00 00 40 08 	or     $0x8400000,%rsi
    100e:	48 89 71 0c          	mov    %rsi,0xc(%rcx)
    1012:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
    1019:	8b b6 8c 3a 00 00    	mov    0x3a8c(%rsi),%esi
    101f:	4c 8b 14 24          	mov    (%rsp),%r10
    1023:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    1027:	48 89 53 40          	mov    %rdx,0x40(%rbx)
    102b:	48 c7 41 04 00 00 00 	movq   $0x0,0x4(%rcx)
    1032:	00 
    1033:	4c 8b 43 78          	mov    0x78(%rbx),%r8
    1037:	4c 89 41 1c          	mov    %r8,0x1c(%rcx)
    103b:	41 89 f1             	mov    %esi,%r9d
    103e:	41 c1 e1 0d          	shl    $0xd,%r9d
    1042:	41 81 e1 00 00 00 40 	and    $0x40000000,%r9d
    1049:	49 81 f1 00 00 00 40 	xor    $0x40000000,%r9
    1050:	4c 89 8b 10 01 00 00 	mov    %r9,0x110(%rbx)
    1057:	48 c7 43 68 01 00 00 	movq   $0x1,0x68(%rbx)
    105e:	00 
    105f:	c7 41 34 00 00 00 00 	movl   $0x0,0x34(%rcx)
    1066:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    106d:	00 
    106e:	48 c7 41 24 01 00 00 	movq   $0x1,0x24(%rcx)
    1075:	00 
    1076:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    107a:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    1081:	00 00 00 
    1084:	44 89 41 2c          	mov    %r8d,0x2c(%rcx)
    1088:	c7 41 30 01 00 00 00 	movl   $0x1,0x30(%rcx)
    108f:	c1 ee 08             	shr    $0x8,%esi
    1092:	81 e6 00 02 00 00    	and    $0x200,%esi
    1098:	81 ce 00 00 00 40    	or     $0x40000000,%esi
    109e:	89 31                	mov    %esi,(%rcx)
    10a0:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    10a7:	00 00 00 
    10aa:	48 05 f0 85 00 00    	add    $0x85f0,%rax
    10b0:	48 89 43 70          	mov    %rax,0x70(%rbx)
    10b4:	48 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rsi
    10bb:	00 80 3f 
    10be:	48 89 71 38          	mov    %rsi,0x38(%rcx)
    10c2:	48 89 71 40          	mov    %rsi,0x40(%rcx)
    10c6:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    10cd:	48 89 be a4 00 00 00 	mov    %rdi,0xa4(%rsi)
    10d4:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
    10db:	ff 7f ff 
    10de:	48 89 b3 80 00 00 00 	mov    %rsi,0x80(%rbx)
    10e5:	48 89 b1 98 00 00 00 	mov    %rsi,0x98(%rcx)
    10ec:	48 bf ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rdi
    10f3:	ff 7f 7f 
    10f6:	48 89 79 78          	mov    %rdi,0x78(%rcx)
    10fa:	48 89 b1 80 00 00 00 	mov    %rsi,0x80(%rcx)
    1101:	4c 89 91 88 00 00 00 	mov    %r10,0x88(%rcx)
    1108:	48 89 b9 90 00 00 00 	mov    %rdi,0x90(%rcx)
    110f:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    1113:	c5 fa 7f 41 58       	vmovdqu %xmm0,0x58(%rcx)
    1118:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    111f:	00 
    1120:	48 89 41 70          	mov    %rax,0x70(%rcx)
    1124:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    112b:	48 c7 40 48 00 00 00 	movq   $0x0,0x48(%rax)
    1132:	00 
    1133:	48 89 50 50          	mov    %rdx,0x50(%rax)
    1137:	48 8b 73 48          	mov    0x48(%rbx),%rsi
    113b:	4c 8b bb d0 00 00 00 	mov    0xd0(%rbx),%r15
    1142:	e9 dc 1b 00 00       	jmp    2d23 <f_8001161d0+0x2d23>
    1147:	81 f9 ad 03 00 00    	cmp    $0x3ad,%ecx
    114d:	0f 84 ad 1f 00 00    	je     3100 <f_8001161d0+0x3100>
    1153:	81 f9 12 04 00 00    	cmp    $0x412,%ecx
    1159:	0f 85 a4 0c 00 00    	jne    1e03 <f_8001161d0+0x1e03>
    115f:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
    1166:	48 8b 89 c8 1e 00 00 	mov    0x1ec8(%rcx),%rcx
    116d:	48 89 4b 70          	mov    %rcx,0x70(%rbx)
    1171:	49 b9 00 00 00 00 01 	movabs $0x100000000,%r9
    1178:	00 00 00 
    117b:	4c 89 0b             	mov    %r9,(%rbx)
    117e:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1182:	4c 8b 83 00 01 00 00 	mov    0x100(%rbx),%r8
    1189:	49 c7 00 02 00 00 00 	movq   $0x2,(%r8)
    1190:	48 be 00 00 00 00 00 	movabs $0x40000000000000,%rsi
    1197:	00 40 00 
    119a:	48 ff c6             	inc    %rsi
    119d:	49 89 70 08          	mov    %rsi,0x8(%r8)
    11a1:	4d 89 48 20          	mov    %r9,0x20(%r8)
    11a5:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    11ac:	ff ff ff 
    11af:	49 89 fb             	mov    %rdi,%r11
    11b2:	48 89 f7             	mov    %rsi,%rdi
    11b5:	49 89 70 28          	mov    %rsi,0x28(%r8)
    11b9:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    11c0:	00 00 00 
    11c3:	48 89 6b 68          	mov    %rbp,0x68(%rbx)
    11c7:	49 b9 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r9
    11ce:	ff 7f ff 
    11d1:	4d 89 88 80 00 00 00 	mov    %r9,0x80(%r8)
    11d8:	48 8b 34 24          	mov    (%rsp),%rsi
    11dc:	49 89 b0 88 00 00 00 	mov    %rsi,0x88(%r8)
    11e3:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    11ea:	4c 89 9e a4 00 00 00 	mov    %r11,0xa4(%rsi)
    11f1:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
    11f8:	ff 7f 7f 
    11fb:	4d 89 90 90 00 00 00 	mov    %r10,0x90(%r8)
    1202:	4d 89 88 98 00 00 00 	mov    %r9,0x98(%r8)
    1209:	c5 fd 6f 05 00 00 00 	vmovdqa 0x0(%rip),%ymm0        # 1211 <f_8001161d0+0x1211>
    1210:	00 
    1211:	c5 fe 7f 43 78       	vmovdqu %ymm0,0x78(%rbx)
    1216:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    121d:	00 
    121e:	45 89 b0 a0 00 00 00 	mov    %r14d,0xa0(%r8)
    1225:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    122c:	0f b6 70 08          	movzbl 0x8(%rax),%esi
    1230:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    1234:	41 c7 80 bc 00 00 00 	movl   $0x3,0xbc(%r8)
    123b:	03 00 00 00 
    123f:	49 c7 40 10 ff ff 00 	movq   $0xffff,0x10(%r8)
    1246:	00 
    1247:	48 8d 47 16          	lea    0x16(%rdi),%rax
    124b:	49 89 40 18          	mov    %rax,0x18(%r8)
    124f:	49 c7 40 68 00 00 00 	movq   $0x0,0x68(%r8)
    1256:	00 
    1257:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    125c:	49 89 40 30          	mov    %rax,0x30(%r8)
    1260:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    1267:	00 80 3f 
    126a:	49 89 40 38          	mov    %rax,0x38(%r8)
    126e:	49 89 40 40          	mov    %rax,0x40(%r8)
    1272:	49 c7 40 48 00 00 00 	movq   $0x0,0x48(%r8)
    1279:	00 
    127a:	49 89 50 50          	mov    %rdx,0x50(%r8)
    127e:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    1282:	c4 c1 7a 7f 40 58    	vmovdqu %xmm0,0x58(%r8)
    1288:	49 89 68 70          	mov    %rbp,0x70(%r8)
    128c:	4d 89 50 78          	mov    %r10,0x78(%r8)
    1290:	48 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rax
    1297:	31 ff                	xor    %edi,%edi
    1299:	39 71 08             	cmp    %esi,0x8(%rcx)
    129c:	48 0f 46 c7          	cmovbe %rdi,%rax
    12a0:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    12a4:	48 8b 94 08 b8 30 00 	mov    0x30b8(%rax,%rcx,1),%rdx
    12ab:	00 
    12ac:	48 89 53 60          	mov    %rdx,0x60(%rbx)
    12b0:	48 8b 84 08 b0 30 00 	mov    0x30b0(%rax,%rcx,1),%rax
    12b7:	00 
    12b8:	48 8b 4b 48          	mov    0x48(%rbx),%rcx
    12bc:	48 89 01             	mov    %rax,(%rcx)
    12bf:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    12c3:	48 8b 43 70          	mov    0x70(%rbx),%rax
    12c7:	44 8b 40 08          	mov    0x8(%rax),%r8d
    12cb:	4c 89 43 48          	mov    %r8,0x48(%rbx)
    12cf:	48 8b 48 10          	mov    0x10(%rax),%rcx
    12d3:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    12d7:	8b 53 40             	mov    0x40(%rbx),%edx
    12da:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
    12e1:	45 31 d2             	xor    %r10d,%r10d
    12e4:	45 31 c9             	xor    %r9d,%r9d
    12e7:	45 89 c3             	mov    %r8d,%r11d
    12ea:	41 29 f3             	sub    %esi,%r11d
    12ed:	48 0f 46 d7          	cmovbe %rdi,%rdx
    12f1:	41 0f 94 c2          	sete   %r10b
    12f5:	41 0f 93 c1          	setae  %r9b
    12f9:	41 c1 e2 1e          	shl    $0x1e,%r10d
    12fd:	41 c1 e1 1d          	shl    $0x1d,%r9d
    1301:	45 09 d1             	or     %r10d,%r9d
    1304:	c4 c2 20 f2 f0       	andn   %r8d,%r11d,%esi
    1309:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    1310:	45 09 d9             	or     %r11d,%r9d
    1313:	c1 ee 03             	shr    $0x3,%esi
    1316:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    131c:	44 09 ce             	or     %r9d,%esi
    131f:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    1326:	48 8b b4 0a 30 33 00 	mov    0x3330(%rdx,%rcx,1),%rsi
    132d:	00 
    132e:	48 8b bc 0a 38 33 00 	mov    0x3338(%rdx,%rcx,1),%rdi
    1335:	00 
    1336:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    133a:	4c 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%r8
    1341:	49 89 30             	mov    %rsi,(%r8)
    1344:	49 89 78 08          	mov    %rdi,0x8(%r8)
    1348:	8b b4 0a 48 33 00 00 	mov    0x3348(%rdx,%rcx,1),%esi
    134f:	48 8b 8c 0a 40 33 00 	mov    0x3340(%rdx,%rcx,1),%rcx
    1356:	00 
    1357:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
    135e:	48 89 0a             	mov    %rcx,(%rdx)
    1361:	89 72 08             	mov    %esi,0x8(%rdx)
    1364:	8b 48 44             	mov    0x44(%rax),%ecx
    1367:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    136b:	48 83 c0 30          	add    $0x30,%rax
    136f:	e9 76 0d 00 00       	jmp    20ea <f_8001161d0+0x20ea>
    1374:	81 f9 1a 05 00 00    	cmp    $0x51a,%ecx
    137a:	0f 85 83 0a 00 00    	jne    1e03 <f_8001161d0+0x1e03>
    1380:	b8 e8 0a 00 00       	mov    $0xae8,%eax
    1385:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    138c:	48 89 03             	mov    %rax,(%rbx)
    138f:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1396:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    139d:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    13a1:	48 89 43 10          	mov    %rax,0x10(%rbx)
    13a5:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    13ac:	00 00 00 
    13af:	48 8d 85 ca 19 51 fd 	lea    -0x2aee636(%rbp),%rax
    13b6:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    13bd:	48 89 df             	mov    %rbx,%rdi
    13c0:	c5 f8 77             	vzeroupper
    13c3:	e8 00 00 00 00       	call   13c8 <f_8001161d0+0x13c8>
    13c8:	e9 73 1a 00 00       	jmp    2e40 <f_8001161d0+0x2e40>
    13cd:	83 f9 61             	cmp    $0x61,%ecx
    13d0:	0f 85 2d 0a 00 00    	jne    1e03 <f_8001161d0+0x1e03>
    13d6:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    13dd:	00 
    13de:	48 c7 80 d0 fe ff ff 	movq   $0x8,-0x130(%rax)
    13e5:	08 00 00 00 
    13e9:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    13f0:	00 40 00 
    13f3:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    13fa:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    1401:	ff ff 00 00 
    1405:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    140c:	ff ff ff 
    140f:	48 8d 4f 0f          	lea    0xf(%rdi),%rcx
    1413:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    141a:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    1421:	00 00 00 
    1424:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
    1428:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    142f:	48 89 b8 f8 fe ff ff 	mov    %rdi,-0x108(%rax)
    1436:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    143d:	00 80 3f 
    1440:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    1444:	48 8d 88 00 ff ff ff 	lea    -0x100(%rax),%rcx
    144b:	4c 8d 98 08 ff ff ff 	lea    -0xf8(%rax),%r11
    1452:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    1459:	00 00 00 
    145c:	4c 8d 87 ab f2 0c 00 	lea    0xcf2ab(%rdi),%r8
    1463:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    1469:	e9 07 18 00 00       	jmp    2c75 <f_8001161d0+0x2c75>
    146e:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    1475:	00 00 00 
    1478:	4c 8d 9d 0b d1 09 00 	lea    0x9d10b(%rbp),%r11
    147f:	eb 24                	jmp    14a5 <f_8001161d0+0x14a5>
    1481:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    1488:	00 00 00 
    148b:	4c 8d 9d 2d 8c 01 00 	lea    0x18c2d(%rbp),%r11
    1492:	eb 11                	jmp    14a5 <f_8001161d0+0x14a5>
    1494:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    149b:	00 00 00 
    149e:	4c 8d 9d 4b 4f 0a 00 	lea    0xa4f4b(%rbp),%r11
    14a5:	4c 89 5b 68          	mov    %r11,0x68(%rbx)
    14a9:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    14b0:	c7 01 00 00 00 10    	movl   $0x10000000,(%rcx)
    14b6:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
    14bd:	4c 8b be f0 31 00 00 	mov    0x31f0(%rsi),%r15
    14c4:	4c 89 3b             	mov    %r15,(%rbx)
    14c7:	49 b8 10 00 00 00 03 	movabs $0x300000010,%r8
    14ce:	00 00 00 
    14d1:	4d 8d 48 f0          	lea    -0x10(%r8),%r9
    14d5:	4c 89 49 14          	mov    %r9,0x14(%rcx)
    14d9:	48 c7 43 78 01 00 00 	movq   $0x1,0x78(%rbx)
    14e0:	00 
    14e1:	49 83 c0 f6          	add    $0xfffffffffffffff6,%r8
    14e5:	4c 89 41 04          	mov    %r8,0x4(%rcx)
    14e9:	4c 8b 43 70          	mov    0x70(%rbx),%r8
    14ed:	4c 89 41 2c          	mov    %r8,0x2c(%rcx)
    14f1:	49 b8 00 00 00 00 ff 	movabs $0xffff00000000,%r8
    14f8:	ff 00 00 
    14fb:	4c 89 41 0c          	mov    %r8,0xc(%rcx)
    14ff:	49 b9 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r9
    1506:	ff 7f ff 
    1509:	4c 89 4b 70          	mov    %r9,0x70(%rbx)
    150d:	bf ff ff ff ff       	mov    $0xffffffff,%edi
    1512:	48 89 79 1c          	mov    %rdi,0x1c(%rcx)
    1516:	4c 8b 14 24          	mov    (%rsp),%r10
    151a:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    151e:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
    1525:	00 80 3f 
    1528:	48 89 79 38          	mov    %rdi,0x38(%rcx)
    152c:	48 89 79 40          	mov    %rdi,0x40(%rcx)
    1530:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
    1535:	4c 89 6b 48          	mov    %r13,0x48(%rbx)
    1539:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    153d:	48 c7 41 24 01 00 00 	movq   $0x1,0x24(%rcx)
    1544:	00 
    1545:	c7 41 34 00 00 00 00 	movl   $0x0,0x34(%rcx)
    154c:	4c 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%r8
    1553:	4d 89 a8 a4 00 00 00 	mov    %r13,0xa4(%r8)
    155a:	4c 89 89 98 00 00 00 	mov    %r9,0x98(%rcx)
    1561:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1565:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    156c:	00 
    156d:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    1574:	c7 81 bc 00 00 00 01 	movl   $0x1,0xbc(%rcx)
    157b:	00 00 00 
    157e:	48 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rax
    1585:	ff 7f 7f 
    1588:	48 89 41 78          	mov    %rax,0x78(%rcx)
    158c:	4c 89 89 80 00 00 00 	mov    %r9,0x80(%rcx)
    1593:	4c 89 91 88 00 00 00 	mov    %r10,0x88(%rcx)
    159a:	48 89 81 90 00 00 00 	mov    %rax,0x90(%rcx)
    15a1:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    15a5:	c5 fa 7f 41 58       	vmovdqu %xmm0,0x58(%rcx)
    15aa:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    15b1:	00 
    15b2:	4c 89 59 70          	mov    %r11,0x70(%rcx)
    15b6:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    15bd:	00 
    15be:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    15c2:	4d 85 ff             	test   %r15,%r15
    15c5:	0f 84 75 18 00 00    	je     2e40 <f_8001161d0+0x2e40>
    15cb:	48 8b 86 c8 1e 00 00 	mov    0x1ec8(%rsi),%rax
    15d2:	48 8b 93 98 00 00 00 	mov    0x98(%rbx),%rdx
    15d9:	0f b6 72 08          	movzbl 0x8(%rdx),%esi
    15dd:	8b 78 08             	mov    0x8(%rax),%edi
    15e0:	48 8b 40 10          	mov    0x10(%rax),%rax
    15e4:	31 d2                	xor    %edx,%edx
    15e6:	45 31 c9             	xor    %r9d,%r9d
    15e9:	45 31 d2             	xor    %r10d,%r10d
    15ec:	41 89 fb             	mov    %edi,%r11d
    15ef:	41 29 f3             	sub    %esi,%r11d
    15f2:	41 0f 94 c1          	sete   %r9b
    15f6:	48 0f 47 d6          	cmova  %rsi,%rdx
    15fa:	41 0f 93 c2          	setae  %r10b
    15fe:	c4 e2 20 f2 f7       	andn   %edi,%r11d,%esi
    1603:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    160a:	41 c1 e1 1e          	shl    $0x1e,%r9d
    160e:	41 c1 e2 1d          	shl    $0x1d,%r10d
    1612:	45 09 ca             	or     %r9d,%r10d
    1615:	45 09 da             	or     %r11d,%r10d
    1618:	c1 ee 03             	shr    $0x3,%esi
    161b:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    1621:	44 09 d6             	or     %r10d,%esi
    1624:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    162b:	48 c7 43 60 e0 3c 00 	movq   $0x3ce0,0x60(%rbx)
    1632:	00 
    1633:	48 89 53 58          	mov    %rdx,0x58(%rbx)
    1637:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
    163e:	48 8d 34 02          	lea    (%rdx,%rax,1),%rsi
    1642:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    1646:	8b b4 02 00 2e 00 00 	mov    0x2e00(%rdx,%rax,1),%esi
    164d:	4c 8d a3 00 02 00 00 	lea    0x200(%rbx),%r12
    1654:	48 89 b3 00 02 00 00 	mov    %rsi,0x200(%rbx)
    165b:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    1662:	00 00 00 00 
    1666:	8b b4 02 08 2e 00 00 	mov    0x2e08(%rdx,%rax,1),%esi
    166d:	48 8d bb 10 02 00 00 	lea    0x210(%rbx),%rdi
    1674:	48 89 3c 24          	mov    %rdi,(%rsp)
    1678:	48 89 b3 10 02 00 00 	mov    %rsi,0x210(%rbx)
    167f:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    1686:	00 00 00 00 
    168a:	8b b4 02 04 2e 00 00 	mov    0x2e04(%rdx,%rax,1),%esi
    1691:	4c 8d bb 20 02 00 00 	lea    0x220(%rbx),%r15
    1698:	48 89 b3 20 02 00 00 	mov    %rsi,0x220(%rbx)
    169f:	48 c7 83 28 02 00 00 	movq   $0x0,0x228(%rbx)
    16a6:	00 00 00 00 
    16aa:	8b 84 02 0c 2e 00 00 	mov    0x2e0c(%rdx,%rax,1),%eax
    16b1:	48 89 83 30 02 00 00 	mov    %rax,0x230(%rbx)
    16b8:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    16bf:	00 00 00 00 
    16c3:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    16ca:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    16d1:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    16d5:	48 89 43 40          	mov    %rax,0x40(%rbx)
    16d9:	4d 89 a8 a4 00 00 00 	mov    %r13,0xa4(%r8)
    16e0:	48 89 df             	mov    %rbx,%rdi
    16e3:	be 01 00 00 00       	mov    $0x1,%esi
    16e8:	31 d2                	xor    %edx,%edx
    16ea:	b9 01 00 00 00       	mov    $0x1,%ecx
    16ef:	45 31 c0             	xor    %r8d,%r8d
    16f2:	c5 f8 77             	vzeroupper
    16f5:	e8 00 00 00 00       	call   16fa <f_8001161d0+0x16fa>
    16fa:	48 89 df             	mov    %rbx,%rdi
    16fd:	be 01 00 00 00       	mov    $0x1,%esi
    1702:	ba 01 00 00 00       	mov    $0x1,%edx
    1707:	b9 03 00 00 00       	mov    $0x3,%ecx
    170c:	41 b8 02 00 00 00    	mov    $0x2,%r8d
    1712:	e8 00 00 00 00       	call   1717 <f_8001161d0+0x1717>
    1717:	48 8b 03             	mov    (%rbx),%rax
    171a:	8b 88 08 03 00 00    	mov    0x308(%rax),%ecx
    1720:	48 89 8b 20 02 00 00 	mov    %rcx,0x220(%rbx)
    1727:	48 c7 83 28 02 00 00 	movq   $0x0,0x228(%rbx)
    172e:	00 00 00 00 
    1732:	8b 80 0c 03 00 00    	mov    0x30c(%rax),%eax
    1738:	48 89 83 30 02 00 00 	mov    %rax,0x230(%rbx)
    173f:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    1746:	00 00 00 00 
    174a:	48 89 df             	mov    %rbx,%rdi
    174d:	31 f6                	xor    %esi,%esi
    174f:	ba 01 00 00 00       	mov    $0x1,%edx
    1754:	b9 01 00 00 00       	mov    $0x1,%ecx
    1759:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    175f:	41 b9 03 00 00 00    	mov    $0x3,%r9d
    1765:	6a 00                	push   $0x0
    1767:	6a 00                	push   $0x0
    1769:	6a 01                	push   $0x1
    176b:	6a 00                	push   $0x0
    176d:	e8 00 00 00 00       	call   1772 <f_8001161d0+0x1772>
    1772:	48 83 c4 20          	add    $0x20,%rsp
    1776:	48 89 df             	mov    %rbx,%rdi
    1779:	31 f6                	xor    %esi,%esi
    177b:	ba 01 00 00 00       	mov    $0x1,%edx
    1780:	b9 01 00 00 00       	mov    $0x1,%ecx
    1785:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    178b:	41 b9 03 00 00 00    	mov    $0x3,%r9d
    1791:	6a 01                	push   $0x1
    1793:	6a 01                	push   $0x1
    1795:	6a 01                	push   $0x1
    1797:	6a 00                	push   $0x0
    1799:	e8 00 00 00 00       	call   179e <f_8001161d0+0x179e>
    179e:	48 83 c4 20          	add    $0x20,%rsp
    17a2:	48 89 df             	mov    %rbx,%rdi
    17a5:	31 f6                	xor    %esi,%esi
    17a7:	31 d2                	xor    %edx,%edx
    17a9:	b9 01 00 00 00       	mov    $0x1,%ecx
    17ae:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    17b4:	45 31 c9             	xor    %r9d,%r9d
    17b7:	6a 00                	push   $0x0
    17b9:	6a 00                	push   $0x0
    17bb:	6a 01                	push   $0x1
    17bd:	6a 00                	push   $0x0
    17bf:	e8 00 00 00 00       	call   17c4 <f_8001161d0+0x17c4>
    17c4:	48 83 c4 20          	add    $0x20,%rsp
    17c8:	48 89 df             	mov    %rbx,%rdi
    17cb:	be 02 00 00 00       	mov    $0x2,%esi
    17d0:	31 d2                	xor    %edx,%edx
    17d2:	b9 02 00 00 00       	mov    $0x2,%ecx
    17d7:	45 31 c0             	xor    %r8d,%r8d
    17da:	e8 00 00 00 00       	call   17df <f_8001161d0+0x17df>
    17df:	48 89 df             	mov    %rbx,%rdi
    17e2:	31 f6                	xor    %esi,%esi
    17e4:	31 d2                	xor    %edx,%edx
    17e6:	b9 01 00 00 00       	mov    $0x1,%ecx
    17eb:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    17f1:	45 31 c9             	xor    %r9d,%r9d
    17f4:	6a 01                	push   $0x1
    17f6:	6a 01                	push   $0x1
    17f8:	6a 01                	push   $0x1
    17fa:	6a 00                	push   $0x0
    17fc:	e8 00 00 00 00       	call   1801 <f_8001161d0+0x1801>
    1801:	48 83 c4 20          	add    $0x20,%rsp
    1805:	48 89 df             	mov    %rbx,%rdi
    1808:	be 02 00 00 00       	mov    $0x2,%esi
    180d:	ba 01 00 00 00       	mov    $0x1,%edx
    1812:	b9 03 00 00 00       	mov    $0x3,%ecx
    1817:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    181d:	e8 00 00 00 00       	call   1822 <f_8001161d0+0x1822>
    1822:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    1826:	c5 f9 7f 83 20 02 00 	vmovdqa %xmm0,0x220(%rbx)
    182d:	00 
    182e:	48 89 df             	mov    %rbx,%rdi
    1831:	31 f6                	xor    %esi,%esi
    1833:	31 d2                	xor    %edx,%edx
    1835:	b9 01 00 00 00       	mov    $0x1,%ecx
    183a:	e8 00 00 00 00       	call   183f <f_8001161d0+0x183f>
    183f:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    1846:	48 89 df             	mov    %rbx,%rdi
    1849:	be 0d 00 00 00       	mov    $0xd,%esi
    184e:	ba 03 00 00 00       	mov    $0x3,%edx
    1853:	31 c9                	xor    %ecx,%ecx
    1855:	41 b8 02 00 00 00    	mov    $0x2,%r8d
    185b:	e8 00 00 00 00       	call   1860 <f_8001161d0+0x1860>
    1860:	48 89 df             	mov    %rbx,%rdi
    1863:	be 0d 00 00 00       	mov    $0xd,%esi
    1868:	ba 04 00 00 00       	mov    $0x4,%edx
    186d:	b9 01 00 00 00       	mov    $0x1,%ecx
    1872:	41 b8 02 00 00 00    	mov    $0x2,%r8d
    1878:	e8 00 00 00 00       	call   187d <f_8001161d0+0x187d>
    187d:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    1884:	85 c0                	test   %eax,%eax
    1886:	0f 98 c1             	sets   %cl
    1889:	a9 00 00 00 10       	test   $0x10000000,%eax
    188e:	0f 94 c2             	sete   %dl
    1891:	30 ca                	xor    %cl,%dl
    1893:	4c 89 e1             	mov    %r12,%rcx
    1896:	49 0f 45 cf          	cmovne %r15,%rcx
    189a:	a9 00 00 00 40       	test   $0x40000000,%eax
    189f:	49 0f 45 cc          	cmovne %r12,%rcx
    18a3:	8b 01                	mov    (%rcx),%eax
    18a5:	48 89 83 00 02 00 00 	mov    %rax,0x200(%rbx)
    18ac:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    18b3:	00 00 00 00 
    18b7:	48 89 df             	mov    %rbx,%rdi
    18ba:	be 01 00 00 00       	mov    $0x1,%esi
    18bf:	31 d2                	xor    %edx,%edx
    18c1:	b9 01 00 00 00       	mov    $0x1,%ecx
    18c6:	e8 00 00 00 00       	call   18cb <f_8001161d0+0x18cb>
    18cb:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    18d2:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    18d9:	8b 93 30 02 00 00    	mov    0x230(%rbx),%edx
    18df:	85 c0                	test   %eax,%eax
    18e1:	40 0f 98 c6          	sets   %sil
    18e5:	a9 00 00 00 10       	test   $0x10000000,%eax
    18ea:	40 0f 94 c7          	sete   %dil
    18ee:	40 30 f7             	xor    %sil,%dil
    18f1:	8b b3 40 02 00 00    	mov    0x240(%rbx),%esi
    18f7:	89 91 80 00 00 00    	mov    %edx,0x80(%rcx)
    18fd:	89 b1 84 00 00 00    	mov    %esi,0x84(%rcx)
    1903:	48 8b 3c 24          	mov    (%rsp),%rdi
    1907:	4c 0f 44 ff          	cmove  %rdi,%r15
    190b:	89 91 98 00 00 00    	mov    %edx,0x98(%rcx)
    1911:	a9 00 00 00 40       	test   $0x40000000,%eax
    1916:	4c 0f 45 ff          	cmovne %rdi,%r15
    191a:	89 b1 9c 00 00 00    	mov    %esi,0x9c(%rcx)
    1920:	49 8b 07             	mov    (%r15),%rax
    1923:	89 c2                	mov    %eax,%edx
    1925:	48 89 93 10 02 00 00 	mov    %rdx,0x210(%rbx)
    192c:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    1933:	00 00 00 00 
    1937:	8b 93 00 02 00 00    	mov    0x200(%rbx),%edx
    193d:	89 51 78             	mov    %edx,0x78(%rcx)
    1940:	89 41 7c             	mov    %eax,0x7c(%rcx)
    1943:	89 91 90 00 00 00    	mov    %edx,0x90(%rcx)
    1949:	89 81 94 00 00 00    	mov    %eax,0x94(%rcx)
    194f:	48 8d 85 5e 18 51 fd 	lea    -0x2aee7a2(%rbp),%rax
    1956:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    195d:	48 89 df             	mov    %rbx,%rdi
    1960:	e8 00 00 00 00       	call   1965 <f_8001161d0+0x1965>
    1965:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    196c:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    1973:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    197a:	48 89 01             	mov    %rax,(%rcx)
    197d:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    1984:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    1988:	48 89 43 40          	mov    %rax,0x40(%rbx)
    198c:	88 41 08             	mov    %al,0x8(%rcx)
    198f:	e9 ac 14 00 00       	jmp    2e40 <f_8001161d0+0x2e40>
    1994:	48 8b 7b 78          	mov    0x78(%rbx),%rdi
    1998:	4c 89 c2             	mov    %r8,%rdx
    199b:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
    19a2:	00 00 00 00 
    19a6:	48 89 90 20 ff ff ff 	mov    %rdx,-0xe0(%rax)
    19ad:	4c 8b bb a0 00 00 00 	mov    0xa0(%rbx),%r15
    19b4:	44 8b a3 a8 00 00 00 	mov    0xa8(%rbx),%r12d
    19bb:	45 8d 44 24 08       	lea    0x8(%r12),%r8d
    19c0:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    19c7:	c4 c2 43 f7 97 fc 0d 	shrx   %edi,0xdfc(%r15),%edx
    19ce:	00 00 
    19d0:	89 54 24 14          	mov    %edx,0x14(%rsp)
    19d4:	44 89 41 30          	mov    %r8d,0x30(%rcx)
    19d8:	48 8b 6b 68          	mov    0x68(%rbx),%rbp
    19dc:	89 69 34             	mov    %ebp,0x34(%rcx)
    19df:	45 31 ed             	xor    %r13d,%r13d
    19e2:	41 f7 c3 00 02 00 00 	test   $0x200,%r11d
    19e9:	41 0f 94 c5          	sete   %r13b
    19ed:	45 8b 87 20 0d 00 00 	mov    0xd20(%r15),%r8d
    19f4:	45 31 d2             	xor    %r10d,%r10d
    19f7:	41 39 f8             	cmp    %edi,%r8d
    19fa:	49 0f 46 fa          	cmovbe %r10,%rdi
    19fe:	44 89 de             	mov    %r11d,%esi
    1a01:	c1 e6 10             	shl    $0x10,%esi
    1a04:	81 e6 00 00 00 40    	and    $0x40000000,%esi
    1a0a:	48 89 f2             	mov    %rsi,%rdx
    1a0d:	48 81 f2 00 00 00 40 	xor    $0x40000000,%rdx
    1a14:	41 89 f8             	mov    %edi,%r8d
    1a17:	4d 69 c0 b0 0b 00 00 	imul   $0xbb0,%r8,%r8
    1a1e:	45 31 c9             	xor    %r9d,%r9d
    1a21:	85 f6                	test   %esi,%esi
    1a23:	41 0f 94 c1          	sete   %r9b
    1a27:	41 c1 e3 06          	shl    $0x6,%r11d
    1a2b:	41 81 e3 00 00 04 00 	and    $0x40000,%r11d
    1a32:	41 c1 e1 04          	shl    $0x4,%r9d
    1a36:	44 85 6c 24 14       	test   %r13d,0x14(%rsp)
    1a3b:	be 01 00 00 00       	mov    $0x1,%esi
    1a40:	c4 e2 51 f7 f6       	shlx   %ebp,%esi,%esi
    1a45:	48 c7 43 48 01 00 00 	movq   $0x1,0x48(%rbx)
    1a4c:	00 
    1a4d:	48 89 73 08          	mov    %rsi,0x8(%rbx)
    1a51:	4d 8b bf 28 0d 00 00 	mov    0xd28(%r15),%r15
    1a58:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    1a5c:	48 89 7b 78          	mov    %rdi,0x78(%rbx)
    1a60:	48 89 93 10 01 00 00 	mov    %rdx,0x110(%rbx)
    1a67:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1a6e:	00 
    1a6f:	4b 8d 14 07          	lea    (%r15,%r8,1),%rdx
    1a73:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    1a77:	ba 0f 00 00 00       	mov    $0xf,%edx
    1a7c:	0f 45 d6             	cmovne %esi,%edx
    1a7f:	43 8d b4 19 00 00 20 	lea    0x200000(%r9,%r11,1),%esi
    1a86:	00 
    1a87:	48 c7 03 08 00 00 00 	movq   $0x8,(%rbx)
    1a8e:	89 11                	mov    %edx,(%rcx)
    1a90:	c7 41 04 08 00 00 00 	movl   $0x8,0x4(%rcx)
    1a97:	41 83 c4 04          	add    $0x4,%r12d
    1a9b:	44 89 61 08          	mov    %r12d,0x8(%rcx)
    1a9f:	89 71 0c             	mov    %esi,0xc(%rcx)
    1aa2:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    1aa9:	00 
    1aaa:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    1ab1:	ff ff ff 
    1ab4:	48 8d 56 02          	lea    0x2(%rsi),%rdx
    1ab8:	48 89 51 18          	mov    %rdx,0x18(%rcx)
    1abc:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    1ac1:	4c 89 8b 90 00 00 00 	mov    %r9,0x90(%rbx)
    1ac8:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
    1acf:	00 00 00 
    1ad2:	48 89 51 20          	mov    %rdx,0x20(%rcx)
    1ad6:	48 89 71 28          	mov    %rsi,0x28(%rcx)
    1ada:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
    1ae1:	00 80 3f 
    1ae4:	48 89 51 38          	mov    %rdx,0x38(%rcx)
    1ae8:	48 89 51 40          	mov    %rdx,0x40(%rcx)
    1aec:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    1af3:	00 00 00 
    1af6:	48 8d 95 b1 e5 0b 00 	lea    0xbe5b1(%rbp),%rdx
    1afd:	48 89 93 80 00 00 00 	mov    %rdx,0x80(%rbx)
    1b04:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    1b0b:	ff 7f ff 
    1b0e:	48 89 bb 88 00 00 00 	mov    %rdi,0x88(%rbx)
    1b15:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    1b1c:	4c 89 8e a4 00 00 00 	mov    %r9,0xa4(%rsi)
    1b23:	48 8b 73 58          	mov    0x58(%rbx),%rsi
    1b27:	48 89 71 78          	mov    %rsi,0x78(%rcx)
    1b2b:	48 89 b9 80 00 00 00 	mov    %rdi,0x80(%rcx)
    1b32:	48 89 b9 98 00 00 00 	mov    %rdi,0x98(%rcx)
    1b39:	48 8b 3c 24          	mov    (%rsp),%rdi
    1b3d:	48 89 b9 88 00 00 00 	mov    %rdi,0x88(%rcx)
    1b44:	48 89 b1 90 00 00 00 	mov    %rsi,0x90(%rcx)
    1b4b:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1b4f:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    1b56:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    1b5d:	00 00 00 
    1b60:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    1b64:	c5 fa 7f 41 58       	vmovdqu %xmm0,0x58(%rcx)
    1b69:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    1b70:	00 
    1b71:	48 89 51 70          	mov    %rdx,0x70(%rcx)
    1b75:	43 8b 8c 07 d8 03 00 	mov    0x3d8(%r15,%r8,1),%ecx
    1b7c:	00 
    1b7d:	43 8b 84 07 f8 03 00 	mov    0x3f8(%r15,%r8,1),%eax
    1b84:	00 
    1b85:	48 89 43 60          	mov    %rax,0x60(%rbx)
    1b89:	89 c8                	mov    %ecx,%eax
    1b8b:	c1 f8 1f             	sar    $0x1f,%eax
    1b8e:	c4 e2 78 f2 c1       	andn   %ecx,%eax,%eax
    1b93:	48 89 43 68          	mov    %rax,0x68(%rbx)
    1b97:	85 c9                	test   %ecx,%ecx
    1b99:	41 0f 49 ca          	cmovns %r10d,%ecx
    1b9d:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    1ba1:	48 83 ec 08          	sub    $0x8,%rsp
    1ba5:	48 89 df             	mov    %rbx,%rdi
    1ba8:	31 f6                	xor    %esi,%esi
    1baa:	ba 01 00 00 00       	mov    $0x1,%edx
    1baf:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1bb5:	45 31 c9             	xor    %r9d,%r9d
    1bb8:	6a 00                	push   $0x0
    1bba:	c5 f8 77             	vzeroupper
    1bbd:	e8 00 00 00 00       	call   1bc2 <f_8001161d0+0x1bc2>
    1bc2:	48 83 c4 10          	add    $0x10,%rsp
    1bc6:	8b 43 60             	mov    0x60(%rbx),%eax
    1bc9:	89 c1                	mov    %eax,%ecx
    1bcb:	c1 f9 1f             	sar    $0x1f,%ecx
    1bce:	c4 e2 70 f2 c8       	andn   %eax,%ecx,%ecx
    1bd3:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    1bd7:	48 83 ec 08          	sub    $0x8,%rsp
    1bdb:	48 89 df             	mov    %rbx,%rdi
    1bde:	31 f6                	xor    %esi,%esi
    1be0:	ba 02 00 00 00       	mov    $0x2,%edx
    1be5:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1beb:	45 31 c9             	xor    %r9d,%r9d
    1bee:	6a 00                	push   $0x0
    1bf0:	e8 00 00 00 00       	call   1bf5 <f_8001161d0+0x1bf5>
    1bf5:	48 83 c4 10          	add    $0x10,%rsp
    1bf9:	8b 43 60             	mov    0x60(%rbx),%eax
    1bfc:	8b 4b 68             	mov    0x68(%rbx),%ecx
    1bff:	89 c2                	mov    %eax,%edx
    1c01:	c1 fa 1f             	sar    $0x1f,%edx
    1c04:	21 c2                	and    %eax,%edx
    1c06:	48 89 53 58          	mov    %rdx,0x58(%rbx)
    1c0a:	48 83 ec 08          	sub    $0x8,%rsp
    1c0e:	48 89 df             	mov    %rbx,%rdi
    1c11:	31 f6                	xor    %esi,%esi
    1c13:	31 d2                	xor    %edx,%edx
    1c15:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1c1b:	45 31 c9             	xor    %r9d,%r9d
    1c1e:	6a 00                	push   $0x0
    1c20:	e8 00 00 00 00       	call   1c25 <f_8001161d0+0x1c25>
    1c25:	48 83 c4 10          	add    $0x10,%rsp
    1c29:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    1c30:	8b 8b 00 02 00 00    	mov    0x200(%rbx),%ecx
    1c36:	8b 93 20 02 00 00    	mov    0x220(%rbx),%edx
    1c3c:	89 88 80 00 00 00    	mov    %ecx,0x80(%rax)
    1c42:	89 90 84 00 00 00    	mov    %edx,0x84(%rax)
    1c48:	8b 4b 58             	mov    0x58(%rbx),%ecx
    1c4b:	48 83 ec 08          	sub    $0x8,%rsp
    1c4f:	48 89 df             	mov    %rbx,%rdi
    1c52:	31 f6                	xor    %esi,%esi
    1c54:	ba 03 00 00 00       	mov    $0x3,%edx
    1c59:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1c5f:	45 31 c9             	xor    %r9d,%r9d
    1c62:	6a 00                	push   $0x0
    1c64:	e8 00 00 00 00       	call   1c69 <f_8001161d0+0x1c69>
    1c69:	48 83 c4 10          	add    $0x10,%rsp
    1c6d:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    1c74:	8b 8b 10 02 00 00    	mov    0x210(%rbx),%ecx
    1c7a:	8b 93 30 02 00 00    	mov    0x230(%rbx),%edx
    1c80:	89 48 78             	mov    %ecx,0x78(%rax)
    1c83:	89 50 7c             	mov    %edx,0x7c(%rax)
    1c86:	48 8b 4b 50          	mov    0x50(%rbx),%rcx
    1c8a:	8b 91 d8 03 00 00    	mov    0x3d8(%rcx),%edx
    1c90:	8b 89 f8 03 00 00    	mov    0x3f8(%rcx),%ecx
    1c96:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
    1c9a:	8b 4b 40             	mov    0x40(%rbx),%ecx
    1c9d:	89 88 a0 00 00 00    	mov    %ecx,0xa0(%rax)
    1ca3:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
    1caa:	48 8b 8b c0 00 00 00 	mov    0xc0(%rbx),%rcx
    1cb1:	48 89 81 a4 00 00 00 	mov    %rax,0xa4(%rcx)
    1cb8:	89 d0                	mov    %edx,%eax
    1cba:	c1 f8 1f             	sar    $0x1f,%eax
    1cbd:	c4 e2 78 f2 c2       	andn   %edx,%eax,%eax
    1cc2:	85 d2                	test   %edx,%edx
    1cc4:	48 89 43 68          	mov    %rax,0x68(%rbx)
    1cc8:	b9 00 00 00 00       	mov    $0x0,%ecx
    1ccd:	0f 48 ca             	cmovs  %edx,%ecx
    1cd0:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    1cd4:	48 83 ec 08          	sub    $0x8,%rsp
    1cd8:	48 89 df             	mov    %rbx,%rdi
    1cdb:	31 f6                	xor    %esi,%esi
    1cdd:	ba 01 00 00 00       	mov    $0x1,%edx
    1ce2:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1ce8:	45 31 c9             	xor    %r9d,%r9d
    1ceb:	6a 00                	push   $0x0
    1ced:	e8 00 00 00 00       	call   1cf2 <f_8001161d0+0x1cf2>
    1cf2:	48 83 c4 10          	add    $0x10,%rsp
    1cf6:	8b 43 60             	mov    0x60(%rbx),%eax
    1cf9:	8b 4b 68             	mov    0x68(%rbx),%ecx
    1cfc:	89 c2                	mov    %eax,%edx
    1cfe:	c1 fa 1f             	sar    $0x1f,%edx
    1d01:	c4 e2 68 f2 c0       	andn   %eax,%edx,%eax
    1d06:	48 89 43 58          	mov    %rax,0x58(%rbx)
    1d0a:	48 83 ec 08          	sub    $0x8,%rsp
    1d0e:	48 89 df             	mov    %rbx,%rdi
    1d11:	31 f6                	xor    %esi,%esi
    1d13:	31 d2                	xor    %edx,%edx
    1d15:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1d1b:	45 31 c9             	xor    %r9d,%r9d
    1d1e:	6a 00                	push   $0x0
    1d20:	e8 00 00 00 00       	call   1d25 <f_8001161d0+0x1d25>
    1d25:	48 83 c4 10          	add    $0x10,%rsp
    1d29:	8b 4b 58             	mov    0x58(%rbx),%ecx
    1d2c:	48 83 ec 08          	sub    $0x8,%rsp
    1d30:	48 89 df             	mov    %rbx,%rdi
    1d33:	31 f6                	xor    %esi,%esi
    1d35:	ba 02 00 00 00       	mov    $0x2,%edx
    1d3a:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1d40:	45 31 c9             	xor    %r9d,%r9d
    1d43:	6a 00                	push   $0x0
    1d45:	e8 00 00 00 00       	call   1d4a <f_8001161d0+0x1d4a>
    1d4a:	48 83 c4 10          	add    $0x10,%rsp
    1d4e:	8b 43 60             	mov    0x60(%rbx),%eax
    1d51:	89 c1                	mov    %eax,%ecx
    1d53:	c1 f9 1f             	sar    $0x1f,%ecx
    1d56:	21 c1                	and    %eax,%ecx
    1d58:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    1d5c:	48 83 ec 08          	sub    $0x8,%rsp
    1d60:	48 89 df             	mov    %rbx,%rdi
    1d63:	31 f6                	xor    %esi,%esi
    1d65:	ba 03 00 00 00       	mov    $0x3,%edx
    1d6a:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1d70:	45 31 c9             	xor    %r9d,%r9d
    1d73:	6a 00                	push   $0x0
    1d75:	e8 00 00 00 00       	call   1d7a <f_8001161d0+0x1d7a>
    1d7a:	48 83 c4 10          	add    $0x10,%rsp
    1d7e:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    1d85:	8b 8b 00 02 00 00    	mov    0x200(%rbx),%ecx
    1d8b:	8b 93 20 02 00 00    	mov    0x220(%rbx),%edx
    1d91:	89 88 98 00 00 00    	mov    %ecx,0x98(%rax)
    1d97:	89 90 9c 00 00 00    	mov    %edx,0x9c(%rax)
    1d9d:	8b 8b 10 02 00 00    	mov    0x210(%rbx),%ecx
    1da3:	8b 93 30 02 00 00    	mov    0x230(%rbx),%edx
    1da9:	89 88 90 00 00 00    	mov    %ecx,0x90(%rax)
    1daf:	89 90 94 00 00 00    	mov    %edx,0x94(%rax)
    1db5:	48 8b 4b 50          	mov    0x50(%rbx),%rcx
    1db9:	31 d2                	xor    %edx,%edx
    1dbb:	80 b9 58 04 00 00 00 	cmpb   $0x0,0x458(%rcx)
    1dc2:	48 c7 43 50 5b 00 00 	movq   $0x5b,0x50(%rbx)
    1dc9:	00 
    1dca:	48 c7 80 b0 00 00 00 	movq   $0x0,0xb0(%rax)
    1dd1:	00 00 00 00 
    1dd5:	8b 4b 48             	mov    0x48(%rbx),%ecx
    1dd8:	89 88 bc 00 00 00    	mov    %ecx,0xbc(%rax)
    1dde:	0f 94 c2             	sete   %dl
    1de1:	48 8d 0c 55 59 00 00 	lea    0x59(,%rdx,2),%rcx
    1de8:	00 
    1de9:	c1 e2 1e             	shl    $0x1e,%edx
    1dec:	48 81 ca 00 00 00 20 	or     $0x20000000,%rdx
    1df3:	48 89 93 10 01 00 00 	mov    %rdx,0x110(%rbx)
    1dfa:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    1dfe:	e9 37 10 00 00       	jmp    2e3a <f_8001161d0+0x2e3a>
    1e03:	4c 89 ab 08 01 00 00 	mov    %r13,0x108(%rbx)
    1e0a:	48 89 df             	mov    %rbx,%rdi
    1e0d:	48 83 c4 18          	add    $0x18,%rsp
    1e11:	5b                   	pop    %rbx
    1e12:	41 5c                	pop    %r12
    1e14:	41 5d                	pop    %r13
    1e16:	41 5e                	pop    %r14
    1e18:	41 5f                	pop    %r15
    1e1a:	5d                   	pop    %rbp
    1e1b:	c5 f8 77             	vzeroupper
    1e1e:	e9 00 00 00 00       	jmp    1e23 <f_8001161d0+0x1e23>
    1e23:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    1e2a:	00 
    1e2b:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1e32:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    1e39:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    1e3d:	48 89 43 10          	mov    %rax,0x10(%rbx)
    1e41:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1e46:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    1e4d:	48 89 03             	mov    %rax,(%rbx)
    1e50:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
    1e57:	00 
    1e58:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    1e5f:	00 00 00 
    1e62:	48 8d 85 ae 18 51 fd 	lea    -0x2aee752(%rbp),%rax
    1e69:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    1e70:	48 89 df             	mov    %rbx,%rdi
    1e73:	c5 f8 77             	vzeroupper
    1e76:	e8 00 00 00 00       	call   1e7b <f_8001161d0+0x1e7b>
    1e7b:	e9 c0 0f 00 00       	jmp    2e40 <f_8001161d0+0x2e40>
    1e80:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    1e87:	00 
    1e88:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1e8f:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    1e96:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    1e9a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    1e9e:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1ea3:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    1eaa:	48 89 03             	mov    %rax,(%rbx)
    1ead:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    1eb4:	00 00 00 
    1eb7:	48 8d 85 ce 18 51 fd 	lea    -0x2aee732(%rbp),%rax
    1ebe:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    1ec5:	48 89 df             	mov    %rbx,%rdi
    1ec8:	c5 f8 77             	vzeroupper
    1ecb:	e8 00 00 00 00       	call   1ed0 <f_8001161d0+0x1ed0>
    1ed0:	e9 6b 0f 00 00       	jmp    2e40 <f_8001161d0+0x2e40>
    1ed5:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
    1edc:	48 8b 89 c8 1e 00 00 	mov    0x1ec8(%rcx),%rcx
    1ee3:	48 89 4b 70          	mov    %rcx,0x70(%rbx)
    1ee7:	49 b9 00 00 00 00 01 	movabs $0x100000000,%r9
    1eee:	00 00 00 
    1ef1:	4c 89 0b             	mov    %r9,(%rbx)
    1ef4:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1ef8:	4c 8b 83 00 01 00 00 	mov    0x100(%rbx),%r8
    1eff:	49 c7 00 04 00 00 00 	movq   $0x4,(%r8)
    1f06:	48 be 00 00 00 00 00 	movabs $0x40000000000000,%rsi
    1f0d:	00 40 00 
    1f10:	48 ff c6             	inc    %rsi
    1f13:	49 89 70 08          	mov    %rsi,0x8(%r8)
    1f17:	4d 89 48 20          	mov    %r9,0x20(%r8)
    1f1b:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    1f22:	ff ff ff 
    1f25:	49 89 ff             	mov    %rdi,%r15
    1f28:	48 89 f7             	mov    %rsi,%rdi
    1f2b:	49 89 70 28          	mov    %rsi,0x28(%r8)
    1f2f:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    1f36:	00 00 00 
    1f39:	4c 8d 8d 25 74 0d 00 	lea    0xd7425(%rbp),%r9
    1f40:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    1f44:	49 bb ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r11
    1f4b:	ff 7f ff 
    1f4e:	4d 89 98 80 00 00 00 	mov    %r11,0x80(%r8)
    1f55:	48 8b 34 24          	mov    (%rsp),%rsi
    1f59:	49 89 b0 88 00 00 00 	mov    %rsi,0x88(%r8)
    1f60:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    1f67:	4c 89 be a4 00 00 00 	mov    %r15,0xa4(%rsi)
    1f6e:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
    1f75:	ff 7f 7f 
    1f78:	4d 89 90 90 00 00 00 	mov    %r10,0x90(%r8)
    1f7f:	4d 89 98 98 00 00 00 	mov    %r11,0x98(%r8)
    1f86:	c5 fd 6f 05 00 00 00 	vmovdqa 0x0(%rip),%ymm0        # 1f8e <f_8001161d0+0x1f8e>
    1f8d:	00 
    1f8e:	c5 fe 7f 43 78       	vmovdqu %ymm0,0x78(%rbx)
    1f93:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1f9a:	00 
    1f9b:	45 89 b0 a0 00 00 00 	mov    %r14d,0xa0(%r8)
    1fa2:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1fa9:	0f b6 70 08          	movzbl 0x8(%rax),%esi
    1fad:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    1fb1:	41 c7 80 bc 00 00 00 	movl   $0x3,0xbc(%r8)
    1fb8:	03 00 00 00 
    1fbc:	49 c7 40 10 ff ff 00 	movq   $0xffff,0x10(%r8)
    1fc3:	00 
    1fc4:	48 8d 47 17          	lea    0x17(%rdi),%rax
    1fc8:	49 89 40 18          	mov    %rax,0x18(%r8)
    1fcc:	49 c7 40 68 00 00 00 	movq   $0x0,0x68(%r8)
    1fd3:	00 
    1fd4:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    1fd9:	49 89 40 30          	mov    %rax,0x30(%r8)
    1fdd:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    1fe4:	00 80 3f 
    1fe7:	49 89 40 38          	mov    %rax,0x38(%r8)
    1feb:	49 89 40 40          	mov    %rax,0x40(%r8)
    1fef:	49 c7 40 48 00 00 00 	movq   $0x0,0x48(%r8)
    1ff6:	00 
    1ff7:	49 89 50 50          	mov    %rdx,0x50(%r8)
    1ffb:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    1fff:	c4 c1 7a 7f 40 58    	vmovdqu %xmm0,0x58(%r8)
    2005:	4d 89 48 70          	mov    %r9,0x70(%r8)
    2009:	4d 89 50 78          	mov    %r10,0x78(%r8)
    200d:	48 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rax
    2014:	45 31 c0             	xor    %r8d,%r8d
    2017:	39 71 08             	cmp    %esi,0x8(%rcx)
    201a:	49 0f 46 c0          	cmovbe %r8,%rax
    201e:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    2022:	48 8b 94 08 68 33 00 	mov    0x3368(%rax,%rcx,1),%rdx
    2029:	00 
    202a:	48 89 53 60          	mov    %rdx,0x60(%rbx)
    202e:	48 8b 84 08 60 33 00 	mov    0x3360(%rax,%rcx,1),%rax
    2035:	00 
    2036:	48 8b 4b 48          	mov    0x48(%rbx),%rcx
    203a:	48 89 01             	mov    %rax,(%rcx)
    203d:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    2041:	48 8b 43 70          	mov    0x70(%rbx),%rax
    2045:	44 8b 48 08          	mov    0x8(%rax),%r9d
    2049:	48 8b 48 10          	mov    0x10(%rax),%rcx
    204d:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    2051:	8b 53 40             	mov    0x40(%rbx),%edx
    2054:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
    205b:	45 31 d2             	xor    %r10d,%r10d
    205e:	31 ff                	xor    %edi,%edi
    2060:	45 89 cb             	mov    %r9d,%r11d
    2063:	41 29 f3             	sub    %esi,%r11d
    2066:	49 0f 46 d0          	cmovbe %r8,%rdx
    206a:	41 0f 94 c2          	sete   %r10b
    206e:	40 0f 93 c7          	setae  %dil
    2072:	41 c1 e2 1e          	shl    $0x1e,%r10d
    2076:	c1 e7 1d             	shl    $0x1d,%edi
    2079:	44 09 d7             	or     %r10d,%edi
    207c:	c4 c2 20 f2 f1       	andn   %r9d,%r11d,%esi
    2081:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    2088:	44 09 df             	or     %r11d,%edi
    208b:	c1 ee 03             	shr    $0x3,%esi
    208e:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    2094:	09 fe                	or     %edi,%esi
    2096:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    209d:	48 8b b4 0a e8 35 00 	mov    0x35e8(%rdx,%rcx,1),%rsi
    20a4:	00 
    20a5:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    20a9:	48 8b bc 0a e0 35 00 	mov    0x35e0(%rdx,%rcx,1),%rdi
    20b0:	00 
    20b1:	48 89 7b 50          	mov    %rdi,0x50(%rbx)
    20b5:	4c 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%r8
    20bc:	49 89 38             	mov    %rdi,(%r8)
    20bf:	49 89 70 08          	mov    %rsi,0x8(%r8)
    20c3:	8b b4 0a f8 35 00 00 	mov    0x35f8(%rdx,%rcx,1),%esi
    20ca:	48 8b 8c 0a f0 35 00 	mov    0x35f0(%rdx,%rcx,1),%rcx
    20d1:	00 
    20d2:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
    20d9:	48 89 0a             	mov    %rcx,(%rdx)
    20dc:	89 72 08             	mov    %esi,0x8(%rdx)
    20df:	8b 48 44             	mov    0x44(%rax),%ecx
    20e2:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    20e6:	48 83 c0 3c          	add    $0x3c,%rax
    20ea:	8b 00                	mov    (%rax),%eax
    20ec:	48 89 43 48          	mov    %rax,0x48(%rbx)
    20f0:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    20f7:	88 8a b0 00 00 00    	mov    %cl,0xb0(%rdx)
    20fd:	c7 82 b4 00 00 00 00 	movl   $0x0,0xb4(%rdx)
    2104:	00 00 00 
    2107:	48 8b 8b c0 00 00 00 	mov    0xc0(%rbx),%rcx
    210e:	c7 81 b1 00 00 00 00 	movl   $0x0,0xb1(%rcx)
    2115:	00 00 00 
    2118:	88 82 b8 00 00 00    	mov    %al,0xb8(%rdx)
    211e:	e9 1d 0d 00 00       	jmp    2e40 <f_8001161d0+0x2e40>
    2123:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    212a:	00 
    212b:	48 c7 80 d0 fe ff ff 	movq   $0x100,-0x130(%rax)
    2132:	00 01 00 00 
    2136:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    213d:	00 40 00 
    2140:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    2147:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    214e:	ff ff 00 00 
    2152:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    2159:	ff ff ff 
    215c:	48 8d 4f 13          	lea    0x13(%rdi),%rcx
    2160:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    2167:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    216e:	00 00 00 
    2171:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
    2175:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    217c:	48 89 b8 f8 fe ff ff 	mov    %rdi,-0x108(%rax)
    2183:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    218a:	00 80 3f 
    218d:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    2191:	48 8d 88 00 ff ff ff 	lea    -0x100(%rax),%rcx
    2198:	4c 8d 98 08 ff ff ff 	lea    -0xf8(%rax),%r11
    219f:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    21a6:	00 00 00 
    21a9:	4c 8d 87 a1 6f fe ff 	lea    -0x1905f(%rdi),%r8
    21b0:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    21b6:	e9 ba 0a 00 00       	jmp    2c75 <f_8001161d0+0x2c75>
    21bb:	48 c7 43 68 00 10 00 	movq   $0x1000,0x68(%rbx)
    21c2:	00 
    21c3:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    21ca:	00 
    21cb:	48 c7 80 d0 fe ff ff 	movq   $0x1000,-0x130(%rax)
    21d2:	00 10 00 00 
    21d6:	48 c7 80 d8 fe ff ff 	movq   $0x1,-0x128(%rax)
    21dd:	01 00 00 00 
    21e1:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    21e8:	ff ff 00 00 
    21ec:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    21f3:	ff ff ff 
    21f6:	48 8d 4e 0c          	lea    0xc(%rsi),%rcx
    21fa:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    2201:	49 bc 00 00 00 00 01 	movabs $0x100000000,%r12
    2208:	00 00 00 
    220b:	4c 89 a0 f0 fe ff ff 	mov    %r12,-0x110(%rax)
    2212:	48 89 b0 f8 fe ff ff 	mov    %rsi,-0x108(%rax)
    2219:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    2220:	00 80 3f 
    2223:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    2227:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
    222c:	48 89 88 00 ff ff ff 	mov    %rcx,-0x100(%rax)
    2233:	4c 89 b8 08 ff ff ff 	mov    %r15,-0xf8(%rax)
    223a:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    2241:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    2248:	00 00 00 
    224b:	4c 8d 9d b2 a4 03 00 	lea    0x3a4b2(%rbp),%r11
    2252:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    2259:	4c 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%r8
    2260:	4d 8b 88 d0 2f 00 00 	mov    0x2fd0(%r8),%r9
    2267:	4c 89 4b 40          	mov    %r9,0x40(%rbx)
    226b:	4c 8b 14 24          	mov    (%rsp),%r10
    226f:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    2273:	4c 89 59 70          	mov    %r11,0x70(%rcx)
    2277:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
    227e:	ff 7f 7f 
    2281:	4c 89 59 78          	mov    %r11,0x78(%rcx)
    2285:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    228c:	ff 7f ff 
    228f:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    2293:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2297:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    229e:	00 
    229f:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    22a6:	00 00 00 
    22a9:	48 89 b9 80 00 00 00 	mov    %rdi,0x80(%rcx)
    22b0:	4c 89 91 88 00 00 00 	mov    %r10,0x88(%rcx)
    22b7:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    22be:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    22c3:	4c 89 96 a4 00 00 00 	mov    %r10,0xa4(%rsi)
    22ca:	4c 89 79 40          	mov    %r15,0x40(%rcx)
    22ce:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    22d5:	00 
    22d6:	4c 89 99 90 00 00 00 	mov    %r11,0x90(%rcx)
    22dd:	48 89 b9 98 00 00 00 	mov    %rdi,0x98(%rcx)
    22e4:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    22eb:	00 
    22ec:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    22f0:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    22f4:	c5 fa 7f 41 58       	vmovdqu %xmm0,0x58(%rcx)
    22f9:	4d 85 c9             	test   %r9,%r9
    22fc:	0f 84 e6 0f 00 00    	je     32e8 <f_8001161d0+0x32e8>
    2302:	48 8b 93 98 00 00 00 	mov    0x98(%rbx),%rdx
    2309:	0f b6 72 08          	movzbl 0x8(%rdx),%esi
    230d:	48 c7 43 68 e0 3c 00 	movq   $0x3ce0,0x68(%rbx)
    2314:	00 
    2315:	48 69 fe 60 0f 00 00 	imul   $0xf60,%rsi,%rdi
    231c:	31 d2                	xor    %edx,%edx
    231e:	41 39 71 10          	cmp    %esi,0x10(%r9)
    2322:	4d 8b 49 18          	mov    0x18(%r9),%r9
    2326:	48 0f 46 fa          	cmovbe %rdx,%rdi
    232a:	42 8b bc 0f 9c 02 00 	mov    0x29c(%rdi,%r9,1),%edi
    2331:	00 
    2332:	4c 09 e7             	or     %r12,%rdi
    2335:	48 89 79 1c          	mov    %rdi,0x1c(%rcx)
    2339:	c7 81 bc 00 00 00 02 	movl   $0x2,0xbc(%rcx)
    2340:	00 00 00 
    2343:	49 8b 88 c8 1e 00 00 	mov    0x1ec8(%r8),%rcx
    234a:	48 69 fe e0 3c 00 00 	imul   $0x3ce0,%rsi,%rdi
    2351:	39 71 08             	cmp    %esi,0x8(%rcx)
    2354:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    235a:	4c 0f 47 c7          	cmova  %rdi,%r8
    235e:	4c 8b 49 10          	mov    0x10(%rcx),%r9
    2362:	4f 8b 94 01 b8 30 00 	mov    0x30b8(%r9,%r8,1),%r10
    2369:	00 
    236a:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    236e:	4f 8b 84 01 b0 30 00 	mov    0x30b0(%r9,%r8,1),%r8
    2375:	00 
    2376:	4c 89 43 58          	mov    %r8,0x58(%rbx)
    237a:	4c 89 80 48 ff ff ff 	mov    %r8,-0xb8(%rax)
    2381:	4c 89 90 50 ff ff ff 	mov    %r10,-0xb0(%rax)
    2388:	44 8b 41 08          	mov    0x8(%rcx),%r8d
    238c:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    2390:	45 31 c9             	xor    %r9d,%r9d
    2393:	45 31 d2             	xor    %r10d,%r10d
    2396:	45 89 c3             	mov    %r8d,%r11d
    2399:	41 29 f3             	sub    %esi,%r11d
    239c:	48 0f 47 d7          	cmova  %rdi,%rdx
    23a0:	41 0f 94 c1          	sete   %r9b
    23a4:	41 0f 93 c2          	setae  %r10b
    23a8:	c4 c2 20 f2 f0       	andn   %r8d,%r11d,%esi
    23ad:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    23b4:	41 c1 e1 1e          	shl    $0x1e,%r9d
    23b8:	41 c1 e2 1d          	shl    $0x1d,%r10d
    23bc:	45 09 ca             	or     %r9d,%r10d
    23bf:	45 09 da             	or     %r11d,%r10d
    23c2:	c1 ee 03             	shr    $0x3,%esi
    23c5:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    23cb:	44 09 d6             	or     %r10d,%esi
    23ce:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    23d5:	48 8d 34 0a          	lea    (%rdx,%rcx,1),%rsi
    23d9:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    23dd:	48 8b b4 0a 30 33 00 	mov    0x3330(%rdx,%rcx,1),%rsi
    23e4:	00 
    23e5:	48 8b bc 0a 38 33 00 	mov    0x3338(%rdx,%rcx,1),%rdi
    23ec:	00 
    23ed:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    23f1:	48 89 b0 60 ff ff ff 	mov    %rsi,-0xa0(%rax)
    23f8:	48 89 b8 68 ff ff ff 	mov    %rdi,-0x98(%rax)
    23ff:	8b b4 0a 48 33 00 00 	mov    0x3348(%rdx,%rcx,1),%esi
    2406:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    240a:	48 8b 8c 0a 40 33 00 	mov    0x3340(%rdx,%rcx,1),%rcx
    2411:	00 
    2412:	48 89 88 70 ff ff ff 	mov    %rcx,-0x90(%rax)
    2419:	89 b0 78 ff ff ff    	mov    %esi,-0x88(%rax)
    241f:	e9 1c 0a 00 00       	jmp    2e40 <f_8001161d0+0x2e40>
    2424:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    242b:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
    2432:	48 8b b6 c8 1e 00 00 	mov    0x1ec8(%rsi),%rsi
    2439:	48 89 73 08          	mov    %rsi,0x8(%rbx)
    243d:	4c 8b 14 24          	mov    (%rsp),%r10
    2441:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    2445:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
    2449:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
    244d:	44 8b 46 08          	mov    0x8(%rsi),%r8d
    2451:	4c 69 c9 e0 3c 00 00 	imul   $0x3ce0,%rcx,%r9
    2458:	45 31 db             	xor    %r11d,%r11d
    245b:	41 39 c8             	cmp    %ecx,%r8d
    245e:	4d 0f 47 d9          	cmova  %r9,%r11
    2462:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    2466:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
    246d:	00 
    246e:	49 8b 8c 0b 40 3c 00 	mov    0x3c40(%r11,%rcx,1),%rcx
    2475:	00 
    2476:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
    247d:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    2484:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    248b:	4c 89 91 88 00 00 00 	mov    %r10,0x88(%rcx)
    2492:	48 be ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rsi
    2499:	ff 7f 7f 
    249c:	48 89 b1 90 00 00 00 	mov    %rsi,0x90(%rcx)
    24a3:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    24aa:	00 
    24ab:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    24af:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    24b6:	00 00 00 
    24b9:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    24c0:	00 
    24c1:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    24c5:	48 c7 43 40 06 00 00 	movq   $0x6,0x40(%rbx)
    24cc:	00 
    24cd:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    24d1:	c5 fa 7f 41 58       	vmovdqu %xmm0,0x58(%rcx)
    24d6:	48 c7 41 30 06 00 00 	movq   $0x6,0x30(%rcx)
    24dd:	00 
    24de:	48 b8 10 00 00 00 03 	movabs $0x300000010,%rax
    24e5:	00 00 00 
    24e8:	48 83 c0 10          	add    $0x10,%rax
    24ec:	48 89 01             	mov    %rax,(%rcx)
    24ef:	48 b8 00 00 00 00 01 	movabs $0x40000100000000,%rax
    24f6:	00 40 00 
    24f9:	48 89 41 08          	mov    %rax,0x8(%rcx)
    24fd:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    2504:	00 
    2505:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    250c:	ff ff ff 
    250f:	48 8d 42 09          	lea    0x9(%rdx),%rax
    2513:	48 89 41 18          	mov    %rax,0x18(%rcx)
    2517:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    251e:	00 00 00 
    2521:	48 89 41 20          	mov    %rax,0x20(%rcx)
    2525:	48 89 51 28          	mov    %rdx,0x28(%rcx)
    2529:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2530:	48 89 b8 a4 00 00 00 	mov    %rdi,0xa4(%rax)
    2537:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    253e:	00 80 3f 
    2541:	48 89 41 38          	mov    %rax,0x38(%rcx)
    2545:	48 89 41 40          	mov    %rax,0x40(%rcx)
    2549:	49 be ca 5d c0 02 08 	movabs $0x802c05dca,%r14
    2550:	00 00 00 
    2553:	49 8d 86 af c7 07 00 	lea    0x7c7af(%r14),%rax
    255a:	48 89 43 78          	mov    %rax,0x78(%rbx)
    255e:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
    2565:	ff 7f ff 
    2568:	48 89 b3 80 00 00 00 	mov    %rsi,0x80(%rbx)
    256f:	48 89 b1 98 00 00 00 	mov    %rsi,0x98(%rcx)
    2576:	48 8b 53 58          	mov    0x58(%rbx),%rdx
    257a:	48 89 51 78          	mov    %rdx,0x78(%rcx)
    257e:	48 89 b1 80 00 00 00 	mov    %rsi,0x80(%rcx)
    2585:	48 8d 53 70          	lea    0x70(%rbx),%rdx
    2589:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    2590:	00 
    2591:	48 89 41 70          	mov    %rax,0x70(%rcx)
    2595:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
    2599:	8b 71 08             	mov    0x8(%rcx),%esi
    259c:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
    25a0:	41 89 f8             	mov    %edi,%r8d
    25a3:	31 c0                	xor    %eax,%eax
    25a5:	39 fe                	cmp    %edi,%esi
    25a7:	be 00 00 00 00       	mov    $0x0,%esi
    25ac:	49 0f 47 f0          	cmova  %r8,%rsi
    25b0:	4c 8b 4b 48          	mov    0x48(%rbx),%r9
    25b4:	4c 8b 51 10          	mov    0x10(%rcx),%r10
    25b8:	8b 12                	mov    (%rdx),%edx
    25ba:	48 0f af f2          	imul   %rdx,%rsi
    25be:	c4 a1 7a 6f 84 16 00 	vmovdqu 0x2e00(%rsi,%r10,1),%xmm0
    25c5:	2e 00 00 
    25c8:	c4 c1 7a 7f 01       	vmovdqu %xmm0,(%r9)
    25cd:	8b 71 08             	mov    0x8(%rcx),%esi
    25d0:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    25d4:	45 31 c9             	xor    %r9d,%r9d
    25d7:	41 89 f2             	mov    %esi,%r10d
    25da:	41 31 fa             	xor    %edi,%r10d
    25dd:	41 0f 94 c1          	sete   %r9b
    25e1:	45 31 db             	xor    %r11d,%r11d
    25e4:	89 f5                	mov    %esi,%ebp
    25e6:	29 fd                	sub    %edi,%ebp
    25e8:	41 0f 93 c3          	setae  %r11b
    25ec:	49 0f 47 c0          	cmova  %r8,%rax
    25f0:	31 ee                	xor    %ebp,%esi
    25f2:	44 21 d6             	and    %r10d,%esi
    25f5:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    25fb:	41 c1 e1 1e          	shl    $0x1e,%r9d
    25ff:	41 c1 e3 1d          	shl    $0x1d,%r11d
    2603:	45 09 cb             	or     %r9d,%r11d
    2606:	41 09 eb             	or     %ebp,%r11d
    2609:	c1 ee 03             	shr    $0x3,%esi
    260c:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    2612:	44 09 de             	or     %r11d,%esi
    2615:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    261c:	48 0f af c2          	imul   %rdx,%rax
    2620:	48 8b 94 08 80 30 00 	mov    0x3080(%rax,%rcx,1),%rdx
    2627:	00 
    2628:	48 8b b3 b0 00 00 00 	mov    0xb0(%rbx),%rsi
    262f:	48 8b bb d0 00 00 00 	mov    0xd0(%rbx),%rdi
    2636:	48 89 33             	mov    %rsi,(%rbx)
    2639:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
    2640:	00 
    2641:	48 8b b4 08 88 30 00 	mov    0x3088(%rax,%rcx,1),%rsi
    2648:	00 
    2649:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    264d:	48 89 17             	mov    %rdx,(%rdi)
    2650:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    2654:	48 8b 94 08 90 30 00 	mov    0x3090(%rax,%rcx,1),%rdx
    265b:	00 
    265c:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    2660:	8b 84 08 98 30 00 00 	mov    0x3098(%rax,%rcx,1),%eax
    2667:	48 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%rcx
    266e:	89 41 08             	mov    %eax,0x8(%rcx)
    2671:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    2678:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    267c:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2680:	48 89 11             	mov    %rdx,(%rcx)
    2683:	49 8d 86 ea 0b 51 fd 	lea    -0x2aef416(%r14),%rax
    268a:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    2691:	48 89 df             	mov    %rbx,%rdi
    2694:	c5 f8 77             	vzeroupper
    2697:	e8 00 00 00 00       	call   269c <f_8001161d0+0x269c>
    269c:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    26a3:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    26aa:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    26b1:	48 89 01             	mov    %rax,(%rcx)
    26b4:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
    26bb:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
    26c2:	48 8b b0 04 16 00 00 	mov    0x1604(%rax),%rsi
    26c9:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
    26cd:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    26d1:	88 51 08             	mov    %dl,0x8(%rcx)
    26d4:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    26db:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
    26df:	8b 80 0c 16 00 00    	mov    0x160c(%rax),%eax
    26e5:	48 89 43 40          	mov    %rax,0x40(%rbx)
    26e9:	4c 89 f5             	mov    %r14,%rbp
    26ec:	48 c7 43 48 02 00 00 	movq   $0x2,0x48(%rbx)
    26f3:	00 
    26f4:	89 41 24             	mov    %eax,0x24(%rcx)
    26f7:	c7 81 bc 00 00 00 02 	movl   $0x2,0xbc(%rcx)
    26fe:	00 00 00 
    2701:	e9 3a 07 00 00       	jmp    2e40 <f_8001161d0+0x2e40>
    2706:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    270d:	00 
    270e:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
    2715:	49 c7 03 80 00 00 00 	movq   $0x80,(%r11)
    271c:	48 b9 00 00 00 00 00 	movabs $0x60000000000000,%rcx
    2723:	00 60 00 
    2726:	49 89 4b 08          	mov    %rcx,0x8(%r11)
    272a:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
    2731:	00 
    2732:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    2739:	ff ff ff 
    273c:	48 8d 4f 12          	lea    0x12(%rdi),%rcx
    2740:	49 89 4b 18          	mov    %rcx,0x18(%r11)
    2744:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    274b:	00 00 00 
    274e:	49 89 4b 20          	mov    %rcx,0x20(%r11)
    2752:	49 89 7b 28          	mov    %rdi,0x28(%r11)
    2756:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    275c:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    2760:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    2767:	00 80 3f 
    276a:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    276e:	49 8d 4b 30          	lea    0x30(%r11),%rcx
    2772:	49 83 c3 38          	add    $0x38,%r11
    2776:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    277d:	00 00 00 
    2780:	4c 8d 87 6d 4f 0a 00 	lea    0xa4f6d(%rdi),%r8
    2787:	e9 e9 04 00 00       	jmp    2c75 <f_8001161d0+0x2c75>
    278c:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    2793:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
    279a:	48 8b b6 c8 1e 00 00 	mov    0x1ec8(%rsi),%rsi
    27a1:	48 89 73 08          	mov    %rsi,0x8(%rbx)
    27a5:	4c 8b 14 24          	mov    (%rsp),%r10
    27a9:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    27ad:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
    27b4:	00 
    27b5:	44 0f b6 41 08       	movzbl 0x8(%rcx),%r8d
    27ba:	4c 89 43 68          	mov    %r8,0x68(%rbx)
    27be:	44 8b 4e 08          	mov    0x8(%rsi),%r9d
    27c2:	4d 69 d8 e0 3c 00 00 	imul   $0x3ce0,%r8,%r11
    27c9:	31 c9                	xor    %ecx,%ecx
    27cb:	45 39 c1             	cmp    %r8d,%r9d
    27ce:	48 8b 76 10          	mov    0x10(%rsi),%rsi
    27d2:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
    27d9:	00 
    27da:	4c 0f 46 d9          	cmovbe %rcx,%r11
    27de:	49 8b b4 33 40 3c 00 	mov    0x3c40(%r11,%rsi,1),%rsi
    27e5:	00 
    27e6:	48 89 33             	mov    %rsi,(%rbx)
    27e9:	4c 8b 83 00 01 00 00 	mov    0x100(%rbx),%r8
    27f0:	45 89 b0 a0 00 00 00 	mov    %r14d,0xa0(%r8)
    27f7:	4d 89 90 88 00 00 00 	mov    %r10,0x88(%r8)
    27fe:	48 be ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rsi
    2805:	ff 7f 7f 
    2808:	49 89 b0 90 00 00 00 	mov    %rsi,0x90(%r8)
    280f:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2816:	00 
    2817:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    281b:	41 c7 80 bc 00 00 00 	movl   $0x0,0xbc(%r8)
    2822:	00 00 00 00 
    2826:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    282a:	c4 c1 7a 7f 40 58    	vmovdqu %xmm0,0x58(%r8)
    2830:	49 c7 00 20 00 00 00 	movq   $0x20,(%r8)
    2837:	48 b8 00 00 00 00 00 	movabs $0x42080000000000,%rax
    283e:	08 42 00 
    2841:	49 89 40 08          	mov    %rax,0x8(%r8)
    2845:	49 c7 40 48 00 00 00 	movq   $0x0,0x48(%r8)
    284c:	00 
    284d:	49 89 50 50          	mov    %rdx,0x50(%r8)
    2851:	49 c7 40 30 07 00 00 	movq   $0x7,0x30(%r8)
    2858:	00 
    2859:	49 c7 40 10 ff ff 00 	movq   $0xffff,0x10(%r8)
    2860:	00 
    2861:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    2868:	ff ff ff 
    286b:	48 8d 42 0a          	lea    0xa(%rdx),%rax
    286f:	49 89 40 18          	mov    %rax,0x18(%r8)
    2873:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    287a:	00 00 00 
    287d:	49 89 40 20          	mov    %rax,0x20(%r8)
    2881:	49 89 50 28          	mov    %rdx,0x28(%r8)
    2885:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    288c:	48 89 b8 a4 00 00 00 	mov    %rdi,0xa4(%rax)
    2893:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    289a:	00 80 3f 
    289d:	49 89 40 38          	mov    %rax,0x38(%r8)
    28a1:	49 89 40 40          	mov    %rax,0x40(%r8)
    28a5:	49 be ca 5d c0 02 08 	movabs $0x802c05dca,%r14
    28ac:	00 00 00 
    28af:	49 8d 86 c5 e4 0b 00 	lea    0xbe4c5(%r14),%rax
    28b6:	48 89 43 78          	mov    %rax,0x78(%rbx)
    28ba:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
    28c1:	ff 7f ff 
    28c4:	48 89 b3 80 00 00 00 	mov    %rsi,0x80(%rbx)
    28cb:	49 89 b0 98 00 00 00 	mov    %rsi,0x98(%r8)
    28d2:	48 8b 53 58          	mov    0x58(%rbx),%rdx
    28d6:	49 89 50 78          	mov    %rdx,0x78(%r8)
    28da:	49 89 b0 80 00 00 00 	mov    %rsi,0x80(%r8)
    28e1:	49 c7 40 68 00 00 00 	movq   $0x0,0x68(%r8)
    28e8:	00 
    28e9:	49 89 40 70          	mov    %rax,0x70(%r8)
    28ed:	48 8b 43 08          	mov    0x8(%rbx),%rax
    28f1:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
    28f5:	41 89 f8             	mov    %edi,%r8d
    28f8:	39 78 08             	cmp    %edi,0x8(%rax)
    28fb:	be 00 00 00 00       	mov    $0x0,%esi
    2900:	49 0f 47 f0          	cmova  %r8,%rsi
    2904:	4c 8b 4b 48          	mov    0x48(%rbx),%r9
    2908:	4c 8b 50 10          	mov    0x10(%rax),%r10
    290c:	8b 53 70             	mov    0x70(%rbx),%edx
    290f:	48 0f af f2          	imul   %rdx,%rsi
    2913:	c4 a1 7a 6f 84 16 b0 	vmovdqu 0x30b0(%rsi,%r10,1),%xmm0
    291a:	30 00 00 
    291d:	c4 c1 7a 7f 01       	vmovdqu %xmm0,(%r9)
    2922:	8b 70 08             	mov    0x8(%rax),%esi
    2925:	45 31 c9             	xor    %r9d,%r9d
    2928:	41 89 f2             	mov    %esi,%r10d
    292b:	41 31 fa             	xor    %edi,%r10d
    292e:	41 0f 94 c1          	sete   %r9b
    2932:	45 31 db             	xor    %r11d,%r11d
    2935:	89 f5                	mov    %esi,%ebp
    2937:	29 fd                	sub    %edi,%ebp
    2939:	49 0f 47 c8          	cmova  %r8,%rcx
    293d:	41 0f 93 c3          	setae  %r11b
    2941:	31 ee                	xor    %ebp,%esi
    2943:	44 21 d6             	and    %r10d,%esi
    2946:	41 c1 e1 1e          	shl    $0x1e,%r9d
    294a:	41 c1 e3 1d          	shl    $0x1d,%r11d
    294e:	45 09 cb             	or     %r9d,%r11d
    2951:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    2957:	41 09 eb             	or     %ebp,%r11d
    295a:	4c 89 f5             	mov    %r14,%rbp
    295d:	48 8b 40 10          	mov    0x10(%rax),%rax
    2961:	c1 ee 03             	shr    $0x3,%esi
    2964:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    296a:	44 09 de             	or     %r11d,%esi
    296d:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    2974:	48 0f af ca          	imul   %rdx,%rcx
    2978:	48 8b 94 01 30 33 00 	mov    0x3330(%rcx,%rax,1),%rdx
    297f:	00 
    2980:	48 8b b4 01 38 33 00 	mov    0x3338(%rcx,%rax,1),%rsi
    2987:	00 
    2988:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    298c:	48 8b bb d0 00 00 00 	mov    0xd0(%rbx),%rdi
    2993:	48 89 17             	mov    %rdx,(%rdi)
    2996:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    299a:	48 8b 94 01 40 33 00 	mov    0x3340(%rcx,%rax,1),%rdx
    29a1:	00 
    29a2:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    29a6:	8b 84 01 48 33 00 00 	mov    0x3348(%rcx,%rax,1),%eax
    29ad:	48 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%rcx
    29b4:	89 41 08             	mov    %eax,0x8(%rcx)
    29b7:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    29be:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    29c2:	48 89 43 40          	mov    %rax,0x40(%rbx)
    29c6:	48 89 11             	mov    %rdx,(%rcx)
    29c9:	49 8d 86 72 0d 51 fd 	lea    -0x2aef28e(%r14),%rax
    29d0:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    29d7:	48 89 df             	mov    %rbx,%rdi
    29da:	c5 f8 77             	vzeroupper
    29dd:	e8 00 00 00 00       	call   29e2 <f_8001161d0+0x29e2>
    29e2:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    29e9:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    29f0:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    29f7:	48 89 01             	mov    %rax,(%rcx)
    29fa:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    2a01:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    2a05:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2a09:	88 41 08             	mov    %al,0x8(%rcx)
    2a0c:	b9 bc 00 00 00       	mov    $0xbc,%ecx
    2a11:	48 03 8b 00 01 00 00 	add    0x100(%rbx),%rcx
    2a18:	e9 d2 08 00 00       	jmp    32ef <f_8001161d0+0x32ef>
    2a1d:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2a21:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    2a28:	48 c7 01 01 00 00 00 	movq   $0x1,(%rcx)
    2a2f:	49 b8 00 00 00 00 00 	movabs $0x40000000000000,%r8
    2a36:	00 40 00 
    2a39:	4c 89 41 08          	mov    %r8,0x8(%rcx)
    2a3d:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    2a44:	00 
    2a45:	49 89 f9             	mov    %rdi,%r9
    2a48:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    2a4f:	ff ff ff 
    2a52:	4c 8d 47 15          	lea    0x15(%rdi),%r8
    2a56:	4c 89 41 18          	mov    %r8,0x18(%rcx)
    2a5a:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2a61:	00 
    2a62:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2a69:	00 00 00 
    2a6c:	48 89 41 20          	mov    %rax,0x20(%rcx)
    2a70:	48 89 79 28          	mov    %rdi,0x28(%rcx)
    2a74:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    2a79:	48 89 41 30          	mov    %rax,0x30(%rcx)
    2a7d:	49 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r8
    2a84:	00 80 3f 
    2a87:	4c 89 41 38          	mov    %r8,0x38(%rcx)
    2a8b:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    2a92:	00 00 00 
    2a95:	48 8d 80 7c 4f 0a 00 	lea    0xa4f7c(%rax),%rax
    2a9c:	48 89 41 70          	mov    %rax,0x70(%rcx)
    2aa0:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
    2aa7:	ff 7f 7f 
    2aaa:	4c 89 59 78          	mov    %r11,0x78(%rcx)
    2aae:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    2ab5:	ff 7f ff 
    2ab8:	48 89 b9 80 00 00 00 	mov    %rdi,0x80(%rcx)
    2abf:	48 8b 04 24          	mov    (%rsp),%rax
    2ac3:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    2aca:	c5 fd 6f 05 00 00 00 	vmovdqa 0x0(%rip),%ymm0        # 2ad2 <f_8001161d0+0x2ad2>
    2ad1:	00 
    2ad2:	c5 fe 7f 43 60       	vmovdqu %ymm0,0x60(%rbx)
    2ad7:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2ade:	4c 89 88 a4 00 00 00 	mov    %r9,0xa4(%rax)
    2ae5:	4c 89 41 40          	mov    %r8,0x40(%rcx)
    2ae9:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    2af0:	00 
    2af1:	4c 89 99 90 00 00 00 	mov    %r11,0x90(%rcx)
    2af8:	48 89 b9 98 00 00 00 	mov    %rdi,0x98(%rcx)
    2aff:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    2b06:	00 
    2b07:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    2b0b:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    2b0f:	c5 fa 7f 41 58       	vmovdqu %xmm0,0x58(%rcx)
    2b14:	48 c7 43 50 03 00 00 	movq   $0x3,0x50(%rbx)
    2b1b:	00 
    2b1c:	b8 03 00 00 00       	mov    $0x3,%eax
    2b21:	e9 ed 01 00 00       	jmp    2d13 <f_8001161d0+0x2d13>
    2b26:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    2b2d:	00 
    2b2e:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    2b35:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    2b3c:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    2b40:	48 89 43 10          	mov    %rax,0x10(%rbx)
    2b44:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    2b49:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    2b50:	48 89 03             	mov    %rax,(%rbx)
    2b53:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    2b5a:	00 00 00 
    2b5d:	48 8d 85 2e 0c 51 fd 	lea    -0x2aef3d2(%rbp),%rax
    2b64:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    2b6b:	48 89 df             	mov    %rbx,%rdi
    2b6e:	c5 f8 77             	vzeroupper
    2b71:	e8 00 00 00 00       	call   2b76 <f_8001161d0+0x2b76>
    2b76:	e9 c5 02 00 00       	jmp    2e40 <f_8001161d0+0x2e40>
    2b7b:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    2b82:	00 
    2b83:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
    2b8a:	49 c7 03 03 00 00 00 	movq   $0x3,(%r11)
    2b91:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    2b98:	00 40 00 
    2b9b:	49 89 4b 08          	mov    %rcx,0x8(%r11)
    2b9f:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
    2ba6:	00 
    2ba7:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    2bae:	ff ff ff 
    2bb1:	48 8d 4f 0f          	lea    0xf(%rdi),%rcx
    2bb5:	49 89 4b 18          	mov    %rcx,0x18(%r11)
    2bb9:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2bc0:	00 00 00 
    2bc3:	49 89 4b 20          	mov    %rcx,0x20(%r11)
    2bc7:	49 89 7b 28          	mov    %rdi,0x28(%r11)
    2bcb:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    2bd1:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    2bd5:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    2bdc:	00 80 3f 
    2bdf:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    2be3:	49 8d 4b 30          	lea    0x30(%r11),%rcx
    2be7:	49 83 c3 38          	add    $0x38,%r11
    2beb:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    2bf2:	00 00 00 
    2bf5:	4c 8d 87 fb b3 05 00 	lea    0x5b3fb(%rdi),%r8
    2bfc:	eb 77                	jmp    2c75 <f_8001161d0+0x2c75>
    2bfe:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    2c05:	ff ff ff 
    2c08:	48 8d 4f 0e          	lea    0xe(%rdi),%rcx
    2c0c:	48 89 4b 78          	mov    %rcx,0x78(%rbx)
    2c10:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
    2c17:	49 c7 03 00 04 00 00 	movq   $0x400,(%r11)
    2c1e:	49 c7 43 08 00 00 00 	movq   $0x0,0x8(%r11)
    2c25:	00 
    2c26:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
    2c2d:	00 
    2c2e:	49 89 4b 18          	mov    %rcx,0x18(%r11)
    2c32:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2c39:	00 00 00 
    2c3c:	49 89 4b 20          	mov    %rcx,0x20(%r11)
    2c40:	49 89 7b 28          	mov    %rdi,0x28(%r11)
    2c44:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    2c4a:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    2c4e:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    2c55:	00 80 3f 
    2c58:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    2c5c:	49 8d 4b 30          	lea    0x30(%r11),%rcx
    2c60:	49 83 c3 38          	add    $0x38,%r11
    2c64:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    2c6b:	00 00 00 
    2c6e:	4c 8d 87 d9 85 00 00 	lea    0x85d9(%rdi),%r8
    2c75:	4c 89 09             	mov    %r9,(%rcx)
    2c78:	4d 89 3b             	mov    %r15,(%r11)
    2c7b:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    2c82:	4c 89 41 70          	mov    %r8,0x70(%rcx)
    2c86:	49 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r9
    2c8d:	ff 7f 7f 
    2c90:	4c 89 49 78          	mov    %r9,0x78(%rcx)
    2c94:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    2c9b:	ff 7f ff 
    2c9e:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    2ca2:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2ca6:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2cad:	00 
    2cae:	48 89 b9 80 00 00 00 	mov    %rdi,0x80(%rcx)
    2cb5:	48 8b 04 24          	mov    (%rsp),%rax
    2cb9:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    2cc0:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    2cc5:	4c 89 43 60          	mov    %r8,0x60(%rbx)
    2cc9:	4c 89 79 40          	mov    %r15,0x40(%rcx)
    2ccd:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    2cd4:	00 
    2cd5:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2cdc:	4c 89 80 a4 00 00 00 	mov    %r8,0xa4(%rax)
    2ce3:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    2ce7:	48 c7 41 58 00 00 00 	movq   $0x0,0x58(%rcx)
    2cee:	00 
    2cef:	48 c7 43 50 02 00 00 	movq   $0x2,0x50(%rbx)
    2cf6:	00 
    2cf7:	4c 89 89 90 00 00 00 	mov    %r9,0x90(%rcx)
    2cfe:	48 89 b9 98 00 00 00 	mov    %rdi,0x98(%rcx)
    2d05:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    2d09:	c5 fa 7f 41 60       	vmovdqu %xmm0,0x60(%rcx)
    2d0e:	b8 02 00 00 00       	mov    $0x2,%eax
    2d13:	4d 89 d7             	mov    %r10,%r15
    2d16:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    2d1d:	89 81 bc 00 00 00    	mov    %eax,0xbc(%rcx)
    2d23:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    2d2a:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
    2d31:	48 8b 80 c8 1e 00 00 	mov    0x1ec8(%rax),%rax
    2d38:	0f b6 79 08          	movzbl 0x8(%rcx),%edi
    2d3c:	4c 69 c7 e0 3c 00 00 	imul   $0x3ce0,%rdi,%r8
    2d43:	31 c9                	xor    %ecx,%ecx
    2d45:	39 78 08             	cmp    %edi,0x8(%rax)
    2d48:	ba 00 00 00 00       	mov    $0x0,%edx
    2d4d:	49 0f 47 d0          	cmova  %r8,%rdx
    2d51:	4c 8b 48 10          	mov    0x10(%rax),%r9
    2d55:	4e 8b 94 0a 08 2e 00 	mov    0x2e08(%rdx,%r9,1),%r10
    2d5c:	00 
    2d5d:	4c 89 53 68          	mov    %r10,0x68(%rbx)
    2d61:	4a 8b 94 0a 00 2e 00 	mov    0x2e00(%rdx,%r9,1),%rdx
    2d68:	00 
    2d69:	48 89 16             	mov    %rdx,(%rsi)
    2d6c:	4c 89 56 08          	mov    %r10,0x8(%rsi)
    2d70:	44 8b 48 08          	mov    0x8(%rax),%r9d
    2d74:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2d78:	48 89 53 60          	mov    %rdx,0x60(%rbx)
    2d7c:	45 31 d2             	xor    %r10d,%r10d
    2d7f:	45 31 db             	xor    %r11d,%r11d
    2d82:	44 89 cd             	mov    %r9d,%ebp
    2d85:	29 fd                	sub    %edi,%ebp
    2d87:	49 0f 47 c8          	cmova  %r8,%rcx
    2d8b:	41 0f 94 c2          	sete   %r10b
    2d8f:	41 0f 93 c3          	setae  %r11b
    2d93:	c4 c2 50 f2 f9       	andn   %r9d,%ebp,%edi
    2d98:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    2d9e:	41 c1 e2 1e          	shl    $0x1e,%r10d
    2da2:	41 c1 e3 1d          	shl    $0x1d,%r11d
    2da6:	45 09 d3             	or     %r10d,%r11d
    2da9:	41 09 eb             	or     %ebp,%r11d
    2dac:	c1 ef 03             	shr    $0x3,%edi
    2daf:	81 e7 00 00 00 10    	and    $0x10000000,%edi
    2db5:	44 09 df             	or     %r11d,%edi
    2db8:	48 89 bb 10 01 00 00 	mov    %rdi,0x110(%rbx)
    2dbf:	48 8b bc 0a 80 30 00 	mov    0x3080(%rdx,%rcx,1),%rdi
    2dc6:	00 
    2dc7:	4c 8b 84 0a 88 30 00 	mov    0x3088(%rdx,%rcx,1),%r8
    2dce:	00 
    2dcf:	48 89 7b 58          	mov    %rdi,0x58(%rbx)
    2dd3:	49 89 3f             	mov    %rdi,(%r15)
    2dd6:	4d 89 47 08          	mov    %r8,0x8(%r15)
    2dda:	8b b4 0a 98 30 00 00 	mov    0x3098(%rdx,%rcx,1),%esi
    2de1:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    2de5:	48 8b 8c 0a 90 30 00 	mov    0x3090(%rdx,%rcx,1),%rcx
    2dec:	00 
    2ded:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
    2df4:	48 89 0a             	mov    %rcx,(%rdx)
    2df7:	89 72 08             	mov    %esi,0x8(%rdx)
    2dfa:	8b 50 20             	mov    0x20(%rax),%edx
    2dfd:	8b 48 24             	mov    0x24(%rax),%ecx
    2e00:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    2e04:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    2e08:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    2e0f:	c7 80 b4 00 00 00 00 	movl   $0x0,0xb4(%rax)
    2e16:	00 00 00 
    2e19:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    2e20:	c7 86 b1 00 00 00 00 	movl   $0x0,0xb1(%rsi)
    2e27:	00 00 00 
    2e2a:	88 90 b0 00 00 00    	mov    %dl,0xb0(%rax)
    2e30:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    2e37:	00 00 00 
    2e3a:	88 88 b8 00 00 00    	mov    %cl,0xb8(%rax)
    2e40:	4c 8b 83 b8 00 00 00 	mov    0xb8(%rbx),%r8
    2e47:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    2e4e:	8b 08                	mov    (%rax),%ecx
    2e50:	48 89 4b 50          	mov    %rcx,0x50(%rbx)
    2e54:	49 8d 50 1c          	lea    0x1c(%r8),%rdx
    2e58:	41 8b 70 1c          	mov    0x1c(%r8),%esi
    2e5c:	48 89 53 40          	mov    %rdx,0x40(%rbx)
    2e60:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    2e64:	89 70 48             	mov    %esi,0x48(%rax)
    2e67:	4d 8d 48 2c          	lea    0x2c(%r8),%r9
    2e6b:	41 8b 78 2c          	mov    0x2c(%r8),%edi
    2e6f:	45 31 d2             	xor    %r10d,%r10d
    2e72:	48 85 ff             	test   %rdi,%rdi
    2e75:	41 0f 94 c2          	sete   %r10b
    2e79:	4c 89 8b b0 00 00 00 	mov    %r9,0xb0(%rbx)
    2e80:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
    2e84:	45 8b 40 14          	mov    0x14(%r8),%r8d
    2e88:	45 31 c9             	xor    %r9d,%r9d
    2e8b:	41 85 c8             	test   %ecx,%r8d
    2e8e:	41 0f 95 c1          	setne  %r9b
    2e92:	4c 89 4b 58          	mov    %r9,0x58(%rbx)
    2e96:	41 89 f9             	mov    %edi,%r9d
    2e99:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    2ea0:	45 89 d3             	mov    %r10d,%r11d
    2ea3:	41 c1 e3 1e          	shl    $0x1e,%r11d
    2ea7:	4d 01 d9             	add    %r11,%r9
    2eaa:	49 81 c1 00 00 00 20 	add    $0x20000000,%r9
    2eb1:	4c 89 8b 10 01 00 00 	mov    %r9,0x110(%rbx)
    2eb8:	c1 ef 1f             	shr    $0x1f,%edi
    2ebb:	41 08 fa             	or     %dil,%r10b
    2ebe:	74 0d                	je     2ecd <f_8001161d0+0x2ecd>
    2ec0:	48 c7 43 58 00 00 00 	movq   $0x0,0x58(%rbx)
    2ec7:	00 
    2ec8:	e9 71 01 00 00       	jmp    303e <f_8001161d0+0x303e>
    2ecd:	41 85 c8             	test   %ecx,%r8d
    2ed0:	0f 84 68 01 00 00    	je     303e <f_8001161d0+0x303e>
    2ed6:	4c 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%r8
    2edd:	4c 8b 8b a8 00 00 00 	mov    0xa8(%rbx),%r9
    2ee4:	49 8d b8 40 01 00 00 	lea    0x140(%r8),%rdi
    2eeb:	48 89 bb c0 00 00 00 	mov    %rdi,0xc0(%rbx)
    2ef2:	44 89 cf             	mov    %r9d,%edi
    2ef5:	4d 63 c9             	movslq %r9d,%r9
    2ef8:	49 c1 f9 1f          	sar    $0x1f,%r9
    2efc:	49 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%r10
    2f03:	ff ff ff 
    2f06:	4d 21 d1             	and    %r10,%r9
    2f09:	49 09 f9             	or     %rdi,%r9
    2f0c:	4c 89 8b c8 00 00 00 	mov    %r9,0xc8(%rbx)
    2f13:	47 0f b6 84 08 40 01 	movzbl 0x140(%r8,%r9,1),%r8d
    2f1a:	00 00 
    2f1c:	4c 89 43 58          	mov    %r8,0x58(%rbx)
    2f20:	41 f6 c0 01          	test   $0x1,%r8b
    2f24:	0f 84 14 01 00 00    	je     303e <f_8001161d0+0x303e>
    2f2a:	49 89 ef             	mov    %rbp,%r15
    2f2d:	44 0f b6 40 0c       	movzbl 0xc(%rax),%r8d
    2f32:	4c 89 43 58          	mov    %r8,0x58(%rbx)
    2f36:	41 f6 c0 01          	test   $0x1,%r8b
    2f3a:	74 09                	je     2f45 <f_8001161d0+0x2f45>
    2f3c:	48 09 ce             	or     %rcx,%rsi
    2f3f:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    2f43:	89 32                	mov    %esi,(%rdx)
    2f45:	48 c7 43 40 d0 00 00 	movq   $0xd0,0x40(%rbx)
    2f4c:	00 
    2f4d:	48 89 43 08          	mov    %rax,0x8(%rbx)
    2f51:	48 63 c7             	movslq %edi,%rax
    2f54:	48 69 c0 d0 00 00 00 	imul   $0xd0,%rax,%rax
    2f5b:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    2f62:	48 8d 14 01          	lea    (%rcx,%rax,1),%rdx
    2f66:	48 89 93 d0 00 00 00 	mov    %rdx,0xd0(%rbx)
    2f6d:	48 c7 43 10 c0 00 00 	movq   $0xc0,0x10(%rbx)
    2f74:	00 
    2f75:	48 8d 84 01 40 0d 00 	lea    0xd40(%rcx,%rax,1),%rax
    2f7c:	00 
    2f7d:	48 89 83 a8 00 00 00 	mov    %rax,0xa8(%rbx)
    2f84:	48 89 03             	mov    %rax,(%rbx)
    2f87:	49 8d 87 6e 12 51 fd 	lea    -0x2aeed92(%r15),%rax
    2f8e:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    2f95:	48 89 df             	mov    %rbx,%rdi
    2f98:	c5 f8 77             	vzeroupper
    2f9b:	e8 00 00 00 00       	call   2fa0 <f_8001161d0+0x2fa0>
    2fa0:	48 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%rax
    2fa7:	80 88 38 0d 00 00 01 	orb    $0x1,0xd38(%rax)
    2fae:	48 8b bb a0 00 00 00 	mov    0xa0(%rbx),%rdi
    2fb5:	0f b6 87 81 3a 00 00 	movzbl 0x3a81(%rdi),%eax
    2fbc:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2fc0:	a8 40                	test   $0x40,%al
    2fc2:	74 7a                	je     303e <f_8001161d0+0x303e>
    2fc4:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2fcb:	48 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%rcx
    2fd2:	0f b6 04 01          	movzbl (%rcx,%rax,1),%eax
    2fd6:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2fda:	a8 02                	test   $0x2,%al
    2fdc:	74 60                	je     303e <f_8001161d0+0x303e>
    2fde:	48 8b 87 60 3b 00 00 	mov    0x3b60(%rdi),%rax
    2fe5:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2fe9:	48 85 c0             	test   %rax,%rax
    2fec:	74 50                	je     303e <f_8001161d0+0x303e>
    2fee:	0f b6 87 85 3a 00 00 	movzbl 0x3a85(%rdi),%eax
    2ff5:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2ff9:	a8 02                	test   $0x2,%al
    2ffb:	74 41                	je     303e <f_8001161d0+0x303e>
    2ffd:	48 8b 83 a8 00 00 00 	mov    0xa8(%rbx),%rax
    3004:	48 8b 8b b8 00 00 00 	mov    0xb8(%rbx),%rcx
    300b:	8b 00                	mov    (%rax),%eax
    300d:	48 89 43 40          	mov    %rax,0x40(%rbx)
    3011:	8b 49 10             	mov    0x10(%rcx),%ecx
    3014:	31 d2                	xor    %edx,%edx
    3016:	c4 e2 70 f2 c0       	andn   %eax,%ecx,%eax
    301b:	0f 94 c2             	sete   %dl
    301e:	89 c6                	mov    %eax,%esi
    3020:	81 e6 00 00 00 80    	and    $0x80000000,%esi
    3026:	c1 e2 1e             	shl    $0x1e,%edx
    3029:	09 f2                	or     %esi,%edx
    302b:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    302f:	48 89 93 10 01 00 00 	mov    %rdx,0x110(%rbx)
    3036:	85 c0                	test   %eax,%eax
    3038:	0f 84 c3 05 00 00    	je     3601 <f_8001161d0+0x3601>
    303e:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    3045:	48 8b 88 20 01 00 00 	mov    0x120(%rax),%rcx
    304c:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    3053:	48 89 8b a0 00 00 00 	mov    %rcx,0xa0(%rbx)
    305a:	48 89 93 98 00 00 00 	mov    %rdx,0x98(%rbx)
    3061:	48 8b 88 10 01 00 00 	mov    0x110(%rax),%rcx
    3068:	48 8b 90 18 01 00 00 	mov    0x118(%rax),%rdx
    306f:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
    3076:	48 89 93 a8 00 00 00 	mov    %rdx,0xa8(%rbx)
    307d:	48 8b 88 00 01 00 00 	mov    0x100(%rax),%rcx
    3084:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    308b:	48 89 8b c0 00 00 00 	mov    %rcx,0xc0(%rbx)
    3092:	48 89 93 b8 00 00 00 	mov    %rdx,0xb8(%rbx)
    3099:	48 8b 88 f0 00 00 00 	mov    0xf0(%rax),%rcx
    30a0:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
    30a7:	48 89 8b d0 00 00 00 	mov    %rcx,0xd0(%rbx)
    30ae:	48 89 93 c8 00 00 00 	mov    %rdx,0xc8(%rbx)
    30b5:	48 8b 88 e0 00 00 00 	mov    0xe0(%rax),%rcx
    30bc:	48 8b 90 e8 00 00 00 	mov    0xe8(%rax),%rdx
    30c3:	48 89 8b e0 00 00 00 	mov    %rcx,0xe0(%rbx)
    30ca:	48 89 93 d8 00 00 00 	mov    %rdx,0xd8(%rbx)
    30d1:	c5 f8 10 80 d0 00 00 	vmovups 0xd0(%rax),%xmm0
    30d8:	00 
    30d9:	c5 f8 11 83 e8 00 00 	vmovups %xmm0,0xe8(%rbx)
    30e0:	00 
    30e1:	48 05 30 01 00 00    	add    $0x130,%rax
    30e7:	48 89 83 00 01 00 00 	mov    %rax,0x100(%rbx)
    30ee:	48 83 c4 18          	add    $0x18,%rsp
    30f2:	5b                   	pop    %rbx
    30f3:	41 5c                	pop    %r12
    30f5:	41 5d                	pop    %r13
    30f7:	41 5e                	pop    %r14
    30f9:	41 5f                	pop    %r15
    30fb:	5d                   	pop    %rbp
    30fc:	c5 f8 77             	vzeroupper
    30ff:	c3                   	ret
    3100:	4c 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%r8
    3107:	49 8b 88 c8 1e 00 00 	mov    0x1ec8(%r8),%rcx
    310e:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
    3115:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
    311c:	ff ff ff 
    311f:	49 89 f9             	mov    %rdi,%r9
    3122:	48 89 cf             	mov    %rcx,%rdi
    3125:	48 8d 71 1a          	lea    0x1a(%rcx),%rsi
    3129:	48 89 73 70          	mov    %rsi,0x70(%rbx)
    312d:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    3131:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    3138:	48 c7 01 00 20 00 00 	movq   $0x2000,(%rcx)
    313f:	48 c7 41 08 00 00 00 	movq   $0x0,0x8(%rcx)
    3146:	00 
    3147:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    314e:	00 
    314f:	48 89 71 18          	mov    %rsi,0x18(%rcx)
    3153:	48 8b b3 98 00 00 00 	mov    0x98(%rbx),%rsi
    315a:	48 89 73 08          	mov    %rsi,0x8(%rbx)
    315e:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    3165:	00 
    3166:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    316d:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    3174:	00 00 00 
    3177:	48 89 41 20          	mov    %rax,0x20(%rcx)
    317b:	48 89 79 28          	mov    %rdi,0x28(%rcx)
    317f:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
    3186:	00 80 3f 
    3189:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    318d:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    3192:	48 89 41 30          	mov    %rax,0x30(%rcx)
    3196:	48 89 79 38          	mov    %rdi,0x38(%rcx)
    319a:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    31a1:	00 00 00 
    31a4:	48 8d 85 95 53 09 00 	lea    0x95395(%rbp),%rax
    31ab:	48 89 41 70          	mov    %rax,0x70(%rcx)
    31af:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
    31b6:	ff 7f 7f 
    31b9:	4c 89 59 78          	mov    %r11,0x78(%rcx)
    31bd:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
    31c4:	ff 7f ff 
    31c7:	48 89 b1 80 00 00 00 	mov    %rsi,0x80(%rcx)
    31ce:	48 8b 04 24          	mov    (%rsp),%rax
    31d2:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    31d9:	4c 89 4b 60          	mov    %r9,0x60(%rbx)
    31dd:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    31e4:	4c 89 88 a4 00 00 00 	mov    %r9,0xa4(%rax)
    31eb:	4c 89 99 90 00 00 00 	mov    %r11,0x90(%rcx)
    31f2:	48 89 b1 98 00 00 00 	mov    %rsi,0x98(%rcx)
    31f9:	48 c7 43 50 b0 1e 00 	movq   $0x1eb0,0x50(%rbx)
    3200:	00 
    3201:	49 81 c0 b0 1e 00 00 	add    $0x1eb0,%r8
    3208:	4c 89 03             	mov    %r8,(%rbx)
    320b:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    320f:	48 c7 41 58 00 00 00 	movq   $0x0,0x58(%rcx)
    3216:	00 
    3217:	48 c7 43 48 03 00 00 	movq   $0x3,0x48(%rbx)
    321e:	00 
    321f:	c7 81 bc 00 00 00 03 	movl   $0x3,0xbc(%rcx)
    3226:	00 00 00 
    3229:	48 89 79 40          	mov    %rdi,0x40(%rcx)
    322d:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    3234:	00 
    3235:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    3239:	c5 fa 7f 41 60       	vmovdqu %xmm0,0x60(%rcx)
    323e:	48 8d 85 92 14 51 fd 	lea    -0x2aeeb6e(%rbp),%rax
    3245:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    324c:	48 89 df             	mov    %rbx,%rdi
    324f:	c5 f8 77             	vzeroupper
    3252:	e8 00 00 00 00       	call   3257 <f_8001161d0+0x3257>
    3257:	48 8b 33             	mov    (%rbx),%rsi
    325a:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    3261:	0f b6 48 08          	movzbl 0x8(%rax),%ecx
    3265:	48 8b 93 b0 00 00 00 	mov    0xb0(%rbx),%rdx
    326c:	8b 42 08             	mov    0x8(%rdx),%eax
    326f:	31 ff                	xor    %edi,%edi
    3271:	45 31 c0             	xor    %r8d,%r8d
    3274:	41 89 c1             	mov    %eax,%r9d
    3277:	41 29 c9             	sub    %ecx,%r9d
    327a:	40 0f 94 c7          	sete   %dil
    327e:	41 0f 93 c0          	setae  %r8b
    3282:	c4 62 30 f2 d0       	andn   %eax,%r9d,%r10d
    3287:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    328e:	c1 e7 1e             	shl    $0x1e,%edi
    3291:	41 c1 e0 1d          	shl    $0x1d,%r8d
    3295:	41 09 f8             	or     %edi,%r8d
    3298:	41 c1 ea 03          	shr    $0x3,%r10d
    329c:	41 81 e2 00 00 00 10 	and    $0x10000000,%r10d
    32a3:	45 09 ca             	or     %r9d,%r10d
    32a6:	45 09 c2             	or     %r8d,%r10d
    32a9:	48 69 f9 e0 3c 00 00 	imul   $0x3ce0,%rcx,%rdi
    32b0:	31 c0                	xor    %eax,%eax
    32b2:	41 81 f8 00 00 00 20 	cmp    $0x20000000,%r8d
    32b9:	48 0f 44 c7          	cmove  %rdi,%rax
    32bd:	4c 89 93 10 01 00 00 	mov    %r10,0x110(%rbx)
    32c4:	48 03 42 10          	add    0x10(%rdx),%rax
    32c8:	40 f6 c6 01          	test   $0x1,%sil
    32cc:	75 34                	jne    3302 <f_8001161d0+0x3302>
    32ce:	41 b8 5c 00 00 00    	mov    $0x5c,%r8d
    32d4:	41 b9 58 00 00 00    	mov    $0x58,%r9d
    32da:	41 ba 54 00 00 00    	mov    $0x54,%r10d
    32e0:	41 bb 50 00 00 00    	mov    $0x50,%r11d
    32e6:	eb 36                	jmp    331e <f_8001161d0+0x331e>
    32e8:	48 81 c1 bc 00 00 00 	add    $0xbc,%rcx
    32ef:	48 c7 43 40 02 00 00 	movq   $0x2,0x40(%rbx)
    32f6:	00 
    32f7:	c7 01 02 00 00 00    	movl   $0x2,(%rcx)
    32fd:	e9 3e fb ff ff       	jmp    2e40 <f_8001161d0+0x2e40>
    3302:	48 89 43 68          	mov    %rax,0x68(%rbx)
    3306:	41 b8 0c 2e 00 00    	mov    $0x2e0c,%r8d
    330c:	41 b9 08 2e 00 00    	mov    $0x2e08,%r9d
    3312:	41 ba 04 2e 00 00    	mov    $0x2e04,%r10d
    3318:	41 bb 00 2e 00 00    	mov    $0x2e00,%r11d
    331e:	46 8b 1c 18          	mov    (%rax,%r11,1),%r11d
    3322:	4c 89 9b 00 02 00 00 	mov    %r11,0x200(%rbx)
    3329:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    3330:	00 00 00 00 
    3334:	46 8b 14 10          	mov    (%rax,%r10,1),%r10d
    3338:	4c 89 93 10 02 00 00 	mov    %r10,0x210(%rbx)
    333f:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    3346:	00 00 00 00 
    334a:	46 8b 0c 08          	mov    (%rax,%r9,1),%r9d
    334e:	4c 89 8b 20 02 00 00 	mov    %r9,0x220(%rbx)
    3355:	48 c7 83 28 02 00 00 	movq   $0x0,0x228(%rbx)
    335c:	00 00 00 00 
    3360:	48 c7 43 58 e0 3c 00 	movq   $0x3ce0,0x58(%rbx)
    3367:	00 
    3368:	46 8b 04 00          	mov    (%rax,%r8,1),%r8d
    336c:	4c 89 83 30 02 00 00 	mov    %r8,0x230(%rbx)
    3373:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    337a:	00 00 00 00 
    337e:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    3385:	44 89 58 78          	mov    %r11d,0x78(%rax)
    3389:	44 89 50 7c          	mov    %r10d,0x7c(%rax)
    338d:	44 89 88 80 00 00 00 	mov    %r9d,0x80(%rax)
    3394:	44 89 80 84 00 00 00 	mov    %r8d,0x84(%rax)
    339b:	45 31 c0             	xor    %r8d,%r8d
    339e:	39 4a 08             	cmp    %ecx,0x8(%rdx)
    33a1:	4c 0f 47 c7          	cmova  %rdi,%r8
    33a5:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
    33a9:	40 f6 c6 01          	test   $0x1,%sil
    33ad:	0f 85 9a 00 00 00    	jne    344d <f_8001161d0+0x344d>
    33b3:	4b 8b 74 08 20       	mov    0x20(%r8,%r9,1),%rsi
    33b8:	4f 8b 54 08 28       	mov    0x28(%r8,%r9,1),%r10
    33bd:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    33c1:	4c 8b 9b d0 00 00 00 	mov    0xd0(%rbx),%r11
    33c8:	49 89 33             	mov    %rsi,(%r11)
    33cb:	4d 89 53 08          	mov    %r10,0x8(%r11)
    33cf:	4b 8b 74 08 30       	mov    0x30(%r8,%r9,1),%rsi
    33d4:	47 8b 44 08 38       	mov    0x38(%r8,%r9,1),%r8d
    33d9:	4c 89 43 48          	mov    %r8,0x48(%rbx)
    33dd:	4c 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%r9
    33e4:	45 89 41 08          	mov    %r8d,0x8(%r9)
    33e8:	49 89 31             	mov    %rsi,(%r9)
    33eb:	44 8b 4a 08          	mov    0x8(%rdx),%r9d
    33ef:	48 8b 72 10          	mov    0x10(%rdx),%rsi
    33f3:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    33f7:	45 31 c0             	xor    %r8d,%r8d
    33fa:	45 31 d2             	xor    %r10d,%r10d
    33fd:	45 31 db             	xor    %r11d,%r11d
    3400:	44 89 cd             	mov    %r9d,%ebp
    3403:	29 cd                	sub    %ecx,%ebp
    3405:	4c 0f 47 c7          	cmova  %rdi,%r8
    3409:	41 0f 94 c2          	sete   %r10b
    340d:	41 0f 93 c3          	setae  %r11b
    3411:	c4 c2 50 f2 d1       	andn   %r9d,%ebp,%edx
    3416:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    341c:	41 c1 e2 1e          	shl    $0x1e,%r10d
    3420:	41 c1 e3 1d          	shl    $0x1d,%r11d
    3424:	45 09 d3             	or     %r10d,%r11d
    3427:	41 09 eb             	or     %ebp,%r11d
    342a:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    3431:	00 00 00 
    3434:	c1 ea 03             	shr    $0x3,%edx
    3437:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    343d:	44 09 da             	or     %r11d,%edx
    3440:	4a 8d 0c 06          	lea    (%rsi,%r8,1),%rcx
    3444:	48 83 c1 40          	add    $0x40,%rcx
    3448:	e9 a9 00 00 00       	jmp    34f6 <f_8001161d0+0x34f6>
    344d:	4b 8b b4 08 80 30 00 	mov    0x3080(%r8,%r9,1),%rsi
    3454:	00 
    3455:	4b 8b bc 08 88 30 00 	mov    0x3088(%r8,%r9,1),%rdi
    345c:	00 
    345d:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
    3461:	4c 8b 93 d0 00 00 00 	mov    0xd0(%rbx),%r10
    3468:	49 89 32             	mov    %rsi,(%r10)
    346b:	49 89 7a 08          	mov    %rdi,0x8(%r10)
    346f:	4b 8b b4 08 90 30 00 	mov    0x3090(%r8,%r9,1),%rsi
    3476:	00 
    3477:	43 8b bc 08 98 30 00 	mov    0x3098(%r8,%r9,1),%edi
    347e:	00 
    347f:	4c 8b 83 c8 00 00 00 	mov    0xc8(%rbx),%r8
    3486:	41 89 78 08          	mov    %edi,0x8(%r8)
    348a:	49 89 30             	mov    %rsi,(%r8)
    348d:	44 8b 42 08          	mov    0x8(%rdx),%r8d
    3491:	48 8b 72 10          	mov    0x10(%rdx),%rsi
    3495:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    3499:	31 ff                	xor    %edi,%edi
    349b:	45 31 c9             	xor    %r9d,%r9d
    349e:	45 31 d2             	xor    %r10d,%r10d
    34a1:	45 89 c3             	mov    %r8d,%r11d
    34a4:	41 29 cb             	sub    %ecx,%r11d
    34a7:	41 0f 94 c1          	sete   %r9b
    34ab:	41 0f 93 c2          	setae  %r10b
    34af:	48 0f 47 f9          	cmova  %rcx,%rdi
    34b3:	c4 c2 20 f2 d0       	andn   %r8d,%r11d,%edx
    34b8:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    34bf:	41 c1 e1 1e          	shl    $0x1e,%r9d
    34c3:	41 c1 e2 1d          	shl    $0x1d,%r10d
    34c7:	45 09 ca             	or     %r9d,%r10d
    34ca:	45 09 da             	or     %r11d,%r10d
    34cd:	c1 ea 03             	shr    $0x3,%edx
    34d0:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    34d6:	44 09 d2             	or     %r10d,%edx
    34d9:	48 c7 43 48 f0 2d 00 	movq   $0x2df0,0x48(%rbx)
    34e0:	00 
    34e1:	48 89 7b 40          	mov    %rdi,0x40(%rbx)
    34e5:	48 69 cf e0 3c 00 00 	imul   $0x3ce0,%rdi,%rcx
    34ec:	48 01 f1             	add    %rsi,%rcx
    34ef:	48 81 c1 f0 2d 00 00 	add    $0x2df0,%rcx
    34f6:	48 89 93 10 01 00 00 	mov    %rdx,0x110(%rbx)
    34fd:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    3501:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    3505:	48 85 d2             	test   %rdx,%rdx
    3508:	74 0d                	je     3517 <f_8001161d0+0x3517>
    350a:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3511:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    3515:	eb 02                	jmp    3519 <f_8001161d0+0x3519>
    3517:	31 d2                	xor    %edx,%edx
    3519:	88 90 b0 00 00 00    	mov    %dl,0xb0(%rax)
    351f:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    3523:	48 85 d2             	test   %rdx,%rdx
    3526:	74 09                	je     3531 <f_8001161d0+0x3531>
    3528:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    352f:	eb 02                	jmp    3533 <f_8001161d0+0x3533>
    3531:	31 d2                	xor    %edx,%edx
    3533:	88 90 b1 00 00 00    	mov    %dl,0xb1(%rax)
    3539:	48 8b 51 30          	mov    0x30(%rcx),%rdx
    353d:	48 85 d2             	test   %rdx,%rdx
    3540:	74 0d                	je     354f <f_8001161d0+0x354f>
    3542:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3549:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    354d:	eb 02                	jmp    3551 <f_8001161d0+0x3551>
    354f:	31 d2                	xor    %edx,%edx
    3551:	88 90 b2 00 00 00    	mov    %dl,0xb2(%rax)
    3557:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    355b:	48 85 d2             	test   %rdx,%rdx
    355e:	74 09                	je     3569 <f_8001161d0+0x3569>
    3560:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3567:	eb 02                	jmp    356b <f_8001161d0+0x356b>
    3569:	31 d2                	xor    %edx,%edx
    356b:	88 90 b3 00 00 00    	mov    %dl,0xb3(%rax)
    3571:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    3575:	48 85 d2             	test   %rdx,%rdx
    3578:	74 0d                	je     3587 <f_8001161d0+0x3587>
    357a:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3581:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    3585:	eb 02                	jmp    3589 <f_8001161d0+0x3589>
    3587:	31 d2                	xor    %edx,%edx
    3589:	88 90 b4 00 00 00    	mov    %dl,0xb4(%rax)
    358f:	48 8b 51 48          	mov    0x48(%rcx),%rdx
    3593:	48 85 d2             	test   %rdx,%rdx
    3596:	74 09                	je     35a1 <f_8001161d0+0x35a1>
    3598:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    359f:	eb 02                	jmp    35a3 <f_8001161d0+0x35a3>
    35a1:	31 d2                	xor    %edx,%edx
    35a3:	88 90 b5 00 00 00    	mov    %dl,0xb5(%rax)
    35a9:	48 8b 51 50          	mov    0x50(%rcx),%rdx
    35ad:	48 85 d2             	test   %rdx,%rdx
    35b0:	74 09                	je     35bb <f_8001161d0+0x35bb>
    35b2:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    35b9:	eb 02                	jmp    35bd <f_8001161d0+0x35bd>
    35bb:	31 d2                	xor    %edx,%edx
    35bd:	88 90 b6 00 00 00    	mov    %dl,0xb6(%rax)
    35c3:	48 8b 51 58          	mov    0x58(%rcx),%rdx
    35c7:	48 85 d2             	test   %rdx,%rdx
    35ca:	74 0d                	je     35d9 <f_8001161d0+0x35d9>
    35cc:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    35d3:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    35d7:	eb 02                	jmp    35db <f_8001161d0+0x35db>
    35d9:	31 d2                	xor    %edx,%edx
    35db:	88 90 b7 00 00 00    	mov    %dl,0xb7(%rax)
    35e1:	48 8b 49 60          	mov    0x60(%rcx),%rcx
    35e5:	48 85 c9             	test   %rcx,%rcx
    35e8:	74 10                	je     35fa <f_8001161d0+0x35fa>
    35ea:	0f b6 89 c0 00 00 00 	movzbl 0xc0(%rcx),%ecx
    35f1:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    35f5:	e9 40 f8 ff ff       	jmp    2e3a <f_8001161d0+0x2e3a>
    35fa:	31 c9                	xor    %ecx,%ecx
    35fc:	e9 39 f8 ff ff       	jmp    2e3a <f_8001161d0+0x2e3a>
    3601:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
    3608:	8b 08                	mov    (%rax),%ecx
    360a:	44 8b 8f 90 3b 00 00 	mov    0x3b90(%rdi),%r9d
    3611:	44 8b 87 94 3b 00 00 	mov    0x3b94(%rdi),%r8d
    3618:	41 83 f9 01          	cmp    $0x1,%r9d
    361c:	44 89 ce             	mov    %r9d,%esi
    361f:	83 d6 00             	adc    $0x0,%esi
    3622:	89 c8                	mov    %ecx,%eax
    3624:	31 d2                	xor    %edx,%edx
    3626:	f7 f6                	div    %esi
    3628:	89 c6                	mov    %eax,%esi
    362a:	45 85 c9             	test   %r9d,%r9d
    362d:	41 0f 44 f1          	cmove  %r9d,%esi
    3631:	4c 89 43 48          	mov    %r8,0x48(%rbx)
    3635:	31 d2                	xor    %edx,%edx
    3637:	41 89 f1             	mov    %esi,%r9d
    363a:	45 31 c1             	xor    %r8d,%r9d
    363d:	0f 94 c2             	sete   %dl
    3640:	45 31 d2             	xor    %r10d,%r10d
    3643:	89 f0                	mov    %esi,%eax
    3645:	44 29 c0             	sub    %r8d,%eax
    3648:	41 0f 93 c2          	setae  %r10b
    364c:	41 89 f3             	mov    %esi,%r11d
    364f:	41 31 c3             	xor    %eax,%r11d
    3652:	45 21 cb             	and    %r9d,%r11d
    3655:	41 89 c1             	mov    %eax,%r9d
    3658:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    365f:	c1 e2 1e             	shl    $0x1e,%edx
    3662:	41 c1 e2 1d          	shl    $0x1d,%r10d
    3666:	41 09 d2             	or     %edx,%r10d
    3669:	45 09 ca             	or     %r9d,%r10d
    366c:	44 31 d8             	xor    %r11d,%eax
    366f:	41 c1 eb 03          	shr    $0x3,%r11d
    3673:	41 81 e3 00 00 00 10 	and    $0x10000000,%r11d
    367a:	45 09 d3             	or     %r10d,%r11d
    367d:	4c 89 9b 10 01 00 00 	mov    %r11,0x110(%rbx)
    3684:	a9 00 00 00 80       	test   $0x80000000,%eax
    3689:	49 0f 44 f0          	cmove  %r8,%rsi
    368d:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    3691:	48 85 f6             	test   %rsi,%rsi
    3694:	0f 84 a4 f9 ff ff    	je     303e <f_8001161d0+0x303e>
    369a:	48 89 8b 88 00 00 00 	mov    %rcx,0x88(%rbx)
    36a1:	31 d2                	xor    %edx,%edx
    36a3:	89 f0                	mov    %esi,%eax
    36a5:	ff c8                	dec    %eax
    36a7:	0f 94 c2             	sete   %dl
    36aa:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    36b0:	49 81 c1 01 00 00 80 	add    $0xffffffff80000001,%r9
    36b7:	45 31 c0             	xor    %r8d,%r8d
    36ba:	4d 89 cb             	mov    %r9,%r11
    36bd:	4c 39 ce             	cmp    %r9,%rsi
    36c0:	41 0f 94 c0          	sete   %r8b
    36c4:	41 89 c1             	mov    %eax,%r9d
    36c7:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    36ce:	c1 e2 1e             	shl    $0x1e,%edx
    36d1:	44 09 ca             	or     %r9d,%edx
    36d4:	45 89 c1             	mov    %r8d,%r9d
    36d7:	41 c1 e1 1c          	shl    $0x1c,%r9d
    36db:	41 09 d1             	or     %edx,%r9d
    36de:	49 81 c9 00 00 00 20 	or     $0x20000000,%r9
    36e5:	4c 89 8b 10 01 00 00 	mov    %r9,0x110(%rbx)
    36ec:	48 89 43 48          	mov    %rax,0x48(%rbx)
    36f0:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
    36f4:	c1 e8 1f             	shr    $0x1f,%eax
    36f7:	41 30 c0             	xor    %al,%r8b
    36fa:	0f 85 3e f9 ff ff    	jne    303e <f_8001161d0+0x303e>
    3700:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    3706:	49 31 f0             	xor    %rsi,%r8
    3709:	41 be 00 00 00 80    	mov    $0x80000000,%r14d
    370f:	49 89 c9             	mov    %rcx,%r9
    3712:	4d 31 f1             	xor    %r14,%r9
    3715:	4c 89 c8             	mov    %r9,%rax
    3718:	4c 09 c0             	or     %r8,%rax
    371b:	b8 01 00 00 00       	mov    $0x1,%eax
    3720:	41 89 f2             	mov    %esi,%r10d
    3723:	44 0f 44 d0          	cmove  %eax,%r10d
    3727:	89 c8                	mov    %ecx,%eax
    3729:	99                   	cltd
    372a:	41 f7 fa             	idiv   %r10d
    372d:	48 8d 53 50          	lea    0x50(%rbx),%rdx
    3731:	4d 09 c1             	or     %r8,%r9
    3734:	41 89 c0             	mov    %eax,%r8d
    3737:	44 0f 44 c1          	cmove  %ecx,%r8d
    373b:	49 0f 44 c3          	cmove  %r11,%rax
    373f:	4c 8d 8f 80 3b 00 00 	lea    0x3b80(%rdi),%r9
    3746:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
    374a:	c5 f9 7f 0a          	vmovdqa %xmm1,(%rdx)
    374e:	4c 89 4b 70          	mov    %r9,0x70(%rbx)
    3752:	48 c7 43 78 28 00 00 	movq   $0x28,0x78(%rbx)
    3759:	00 
    375a:	48 c7 83 80 00 00 00 	movq   $0x3dcccccd,0x80(%rbx)
    3761:	cd cc cc 3d 
    3765:	41 0f af f0          	imul   %r8d,%esi
    3769:	29 f1                	sub    %esi,%ecx
    376b:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
    376f:	48 81 c7 78 3b 00 00 	add    $0x3b78,%rdi
    3776:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    377a:	48 89 83 88 00 00 00 	mov    %rax,0x88(%rbx)
    3781:	45 31 ed             	xor    %r13d,%r13d
    3784:	c4 e2 79 59 15 00 00 	vpbroadcastq 0x0(%rip),%xmm2        # 378d <f_8001161d0+0x378d>
    378b:	00 00 
    378d:	48 bd 00 00 00 00 f8 	movabs $0xfffffff800000000,%rbp
    3794:	ff ff ff 
    3797:	eb 72                	jmp    380b <f_8001161d0+0x380b>
    3799:	c4 e3 e9 22 83 88 00 	vpinsrq $0x1,0x88(%rbx),%xmm2,%xmm0
    37a0:	00 00 01 
    37a3:	c5 f9 d4 43 50       	vpaddq 0x50(%rbx),%xmm0,%xmm0
    37a8:	c5 f9 7e c0          	vmovd  %xmm0,%eax
    37ac:	8b 4b 40             	mov    0x40(%rbx),%ecx
    37af:	31 d2                	xor    %edx,%edx
    37b1:	89 c6                	mov    %eax,%esi
    37b3:	31 ce                	xor    %ecx,%esi
    37b5:	0f 94 c2             	sete   %dl
    37b8:	31 ff                	xor    %edi,%edi
    37ba:	41 89 c0             	mov    %eax,%r8d
    37bd:	41 29 c8             	sub    %ecx,%r8d
    37c0:	40 0f 93 c7          	setae  %dil
    37c4:	45 89 c1             	mov    %r8d,%r9d
    37c7:	41 31 c1             	xor    %eax,%r9d
    37ca:	41 21 f1             	and    %esi,%r9d
    37cd:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
    37d4:	c1 e2 1e             	shl    $0x1e,%edx
    37d7:	c1 e7 1d             	shl    $0x1d,%edi
    37da:	09 d7                	or     %edx,%edi
    37dc:	44 09 c7             	or     %r8d,%edi
    37df:	41 c1 e9 03          	shr    $0x3,%r9d
    37e3:	41 81 e1 00 00 00 10 	and    $0x10000000,%r9d
    37ea:	41 09 f9             	or     %edi,%r9d
    37ed:	31 c8                	xor    %ecx,%eax
    37ef:	c4 e3 79 02 c1 0a    	vpblendd $0xa,%xmm1,%xmm0,%xmm0
    37f5:	c5 f9 7f 43 50       	vmovdqa %xmm0,0x50(%rbx)
    37fa:	4c 89 8b 10 01 00 00 	mov    %r9,0x110(%rbx)
    3801:	0f 84 37 f8 ff ff    	je     303e <f_8001161d0+0x303e>
    3807:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
    380b:	8b 07                	mov    (%rdi),%eax
    380d:	48 89 83 30 01 00 00 	mov    %rax,0x130(%rbx)
    3814:	48 89 83 90 00 00 00 	mov    %rax,0x90(%rbx)
    381b:	8d 48 01             	lea    0x1(%rax),%ecx
    381e:	48 89 0b             	mov    %rcx,(%rbx)
    3821:	48 8b 53 68          	mov    0x68(%rbx),%rdx
    3825:	48 c7 83 28 01 00 00 	movq   $0xffffffffffffffff,0x128(%rbx)
    382c:	ff ff ff ff 
    3830:	48 39 d7             	cmp    %rdx,%rdi
    3833:	40 0f 94 c6          	sete   %sil
    3837:	f0 0f b1 0a          	lock cmpxchg %ecx,(%rdx)
    383b:	0f 94 c0             	sete   %al
    383e:	40 20 f0             	and    %sil,%al
    3841:	89 c1                	mov    %eax,%ecx
    3843:	80 f1 01             	xor    $0x1,%cl
    3846:	0f b6 c9             	movzbl %cl,%ecx
    3849:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    384d:	84 c0                	test   %al,%al
    384f:	74 b6                	je     3807 <f_8001161d0+0x3807>
    3851:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
    3858:	8b b9 68 3b 00 00    	mov    0x3b68(%rcx),%edi
    385e:	8b 43 50             	mov    0x50(%rbx),%eax
    3861:	3b 43 48             	cmp    0x48(%rbx),%eax
    3864:	8b 43 60             	mov    0x60(%rbx),%eax
    3867:	49 0f 45 c5          	cmovne %r13,%rax
    386b:	48 8b b1 70 3b 00 00 	mov    0x3b70(%rcx),%rsi
    3872:	48 89 33             	mov    %rsi,(%rbx)
    3875:	48 8b 8b 90 00 00 00 	mov    0x90(%rbx),%rcx
    387c:	ba 00 00 00 00       	mov    $0x0,%edx
    3881:	39 cf                	cmp    %ecx,%edi
    3883:	76 19                	jbe    389e <f_8001161d0+0x389e>
    3885:	89 c9                	mov    %ecx,%ecx
    3887:	48 63 d1             	movslq %ecx,%rdx
    388a:	48 c1 fa 1f          	sar    $0x1f,%rdx
    388e:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    3895:	ff ff ff 
    3898:	48 21 fa             	and    %rdi,%rdx
    389b:	48 09 ca             	or     %rcx,%rdx
    389e:	48 89 53 08          	mov    %rdx,0x8(%rbx)
    38a2:	48 03 83 88 00 00 00 	add    0x88(%rbx),%rax
    38a9:	89 c1                	mov    %eax,%ecx
    38ab:	48 89 8b 88 00 00 00 	mov    %rcx,0x88(%rbx)
    38b2:	48 63 d2             	movslq %edx,%rdx
    38b5:	48 63 7b 78          	movslq 0x78(%rbx),%rdi
    38b9:	48 0f af fa          	imul   %rdx,%rdi
    38bd:	48 8d 14 37          	lea    (%rdi,%rsi,1),%rdx
    38c1:	48 89 93 90 00 00 00 	mov    %rdx,0x90(%rbx)
    38c8:	44 8b 43 58          	mov    0x58(%rbx),%r8d
    38cc:	49 89 c1             	mov    %rax,%r9
    38cf:	49 c1 e1 20          	shl    $0x20,%r9
    38d3:	4d 09 c1             	or     %r8,%r9
    38d6:	4c 8b 83 98 00 00 00 	mov    0x98(%rbx),%r8
    38dd:	4c 89 04 37          	mov    %r8,(%rdi,%rsi,1)
    38e1:	4c 8b 83 b8 00 00 00 	mov    0xb8(%rbx),%r8
    38e8:	4c 89 44 37 08       	mov    %r8,0x8(%rdi,%rsi,1)
    38ed:	4c 8b 83 a8 00 00 00 	mov    0xa8(%rbx),%r8
    38f4:	4c 89 44 37 10       	mov    %r8,0x10(%rdi,%rsi,1)
    38f9:	4c 89 4c 37 18       	mov    %r9,0x18(%rdi,%rsi,1)
    38fe:	41 8b b0 bc 00 00 00 	mov    0xbc(%r8),%esi
    3905:	45 31 c0             	xor    %r8d,%r8d
    3908:	89 f7                	mov    %esi,%edi
    390a:	83 c7 fe             	add    $0xfffffffe,%edi
    390d:	41 0f 94 c0          	sete   %r8b
    3911:	45 31 c9             	xor    %r9d,%r9d
    3914:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    391a:	41 29 f2             	sub    %esi,%r10d
    391d:	41 0f 92 c1          	setb   %r9b
    3921:	41 21 f2             	and    %esi,%r10d
    3924:	41 89 fb             	mov    %edi,%r11d
    3927:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    392e:	41 c1 e0 1e          	shl    $0x1e,%r8d
    3932:	41 c1 e1 1d          	shl    $0x1d,%r9d
    3936:	45 09 d9             	or     %r11d,%r9d
    3939:	45 09 c1             	or     %r8d,%r9d
    393c:	41 c1 ea 03          	shr    $0x3,%r10d
    3940:	41 81 e2 00 00 00 10 	and    $0x10000000,%r10d
    3947:	45 09 ca             	or     %r9d,%r10d
    394a:	48 89 73 10          	mov    %rsi,0x10(%rbx)
    394e:	4c 89 93 10 01 00 00 	mov    %r10,0x110(%rbx)
    3955:	85 ff                	test   %edi,%edi
    3957:	0f 84 b1 00 00 00    	je     3a0e <f_8001161d0+0x3a0e>
    395d:	31 ff                	xor    %edi,%edi
    395f:	48 85 f6             	test   %rsi,%rsi
    3962:	40 0f 95 c7          	setne  %dil
    3966:	45 31 c0             	xor    %r8d,%r8d
    3969:	41 89 f1             	mov    %esi,%r9d
    396c:	41 ff c9             	dec    %r9d
    396f:	41 0f 94 c0          	sete   %r8b
    3973:	45 31 d2             	xor    %r10d,%r10d
    3976:	4c 39 f6             	cmp    %r14,%rsi
    3979:	41 0f 94 c2          	sete   %r10b
    397d:	45 89 cb             	mov    %r9d,%r11d
    3980:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    3987:	41 c1 e0 1e          	shl    $0x1e,%r8d
    398b:	c1 e7 1d             	shl    $0x1d,%edi
    398e:	41 c1 e2 1c          	shl    $0x1c,%r10d
    3992:	41 09 fa             	or     %edi,%r10d
    3995:	45 09 da             	or     %r11d,%r10d
    3998:	45 09 c2             	or     %r8d,%r10d
    399b:	4c 89 93 10 01 00 00 	mov    %r10,0x110(%rbx)
    39a2:	45 85 c9             	test   %r9d,%r9d
    39a5:	0f 84 f9 00 00 00    	je     3aa4 <f_8001161d0+0x3aa4>
    39ab:	45 31 c0             	xor    %r8d,%r8d
    39ae:	89 f7                	mov    %esi,%edi
    39b0:	83 c7 fd             	add    $0xfffffffd,%edi
    39b3:	41 0f 94 c0          	sete   %r8b
    39b7:	45 31 c9             	xor    %r9d,%r9d
    39ba:	83 fe 03             	cmp    $0x3,%esi
    39bd:	41 0f 93 c1          	setae  %r9b
    39c1:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    39c7:	41 29 f2             	sub    %esi,%r10d
    39ca:	41 21 f2             	and    %esi,%r10d
    39cd:	89 fe                	mov    %edi,%esi
    39cf:	81 e6 00 00 00 80    	and    $0x80000000,%esi
    39d5:	41 c1 e0 1e          	shl    $0x1e,%r8d
    39d9:	41 c1 e1 1d          	shl    $0x1d,%r9d
    39dd:	41 09 f1             	or     %esi,%r9d
    39e0:	45 09 c1             	or     %r8d,%r9d
    39e3:	41 c1 ea 03          	shr    $0x3,%r10d
    39e7:	41 81 e2 00 00 00 10 	and    $0x10000000,%r10d
    39ee:	45 09 ca             	or     %r9d,%r10d
    39f1:	4c 89 93 10 01 00 00 	mov    %r10,0x110(%rbx)
    39f8:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
    39fc:	85 ff                	test   %edi,%edi
    39fe:	0f 85 dc 00 00 00    	jne    3ae0 <f_8001161d0+0x3ae0>
    3a04:	01 c0                	add    %eax,%eax
    3a06:	8d 0c 80             	lea    (%rax,%rax,4),%ecx
    3a09:	e9 ce 00 00 00       	jmp    3adc <f_8001161d0+0x3adc>
    3a0e:	48 83 ec 08          	sub    $0x8,%rsp
    3a12:	48 89 df             	mov    %rbx,%rdi
    3a15:	31 f6                	xor    %esi,%esi
    3a17:	31 d2                	xor    %edx,%edx
    3a19:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    3a1f:	45 31 c9             	xor    %r9d,%r9d
    3a22:	6a 00                	push   $0x0
    3a24:	e8 00 00 00 00       	call   3a29 <f_8001161d0+0x3a29>
    3a29:	48 83 c4 10          	add    $0x10,%rsp
    3a2d:	8b 83 80 00 00 00    	mov    0x80(%rbx),%eax
    3a33:	48 89 83 10 02 00 00 	mov    %rax,0x210(%rbx)
    3a3a:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    3a41:	00 00 00 00 
    3a45:	48 89 df             	mov    %rbx,%rdi
    3a48:	be 02 00 00 00       	mov    $0x2,%esi
    3a4d:	31 d2                	xor    %edx,%edx
    3a4f:	31 c9                	xor    %ecx,%ecx
    3a51:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    3a57:	e8 00 00 00 00       	call   3a5c <f_8001161d0+0x3a5c>
    3a5c:	48 83 ec 08          	sub    $0x8,%rsp
    3a60:	48 89 df             	mov    %rbx,%rdi
    3a63:	31 f6                	xor    %esi,%esi
    3a65:	31 d2                	xor    %edx,%edx
    3a67:	b9 03 00 00 00       	mov    $0x3,%ecx
    3a6c:	45 31 c0             	xor    %r8d,%r8d
    3a6f:	41 b9 20 00 00 00    	mov    $0x20,%r9d
    3a75:	6a 01                	push   $0x1
    3a77:	e8 00 00 00 00       	call   3a7c <f_8001161d0+0x3a7c>
    3a7c:	c4 e2 79 59 15 00 00 	vpbroadcastq 0x0(%rip),%xmm2        # 3a85 <f_8001161d0+0x3a85>
    3a83:	00 00 
    3a85:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
    3a89:	48 83 c4 10          	add    $0x10,%rsp
    3a8d:	89 c1                	mov    %eax,%ecx
    3a8f:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
    3a93:	48 63 43 08          	movslq 0x8(%rbx),%rax
    3a97:	48 63 53 78          	movslq 0x78(%rbx),%rdx
    3a9b:	48 0f af d0          	imul   %rax,%rdx
    3a9f:	48 03 13             	add    (%rbx),%rdx
    3aa2:	eb 3c                	jmp    3ae0 <f_8001161d0+0x3ae0>
    3aa4:	31 f6                	xor    %esi,%esi
    3aa6:	48 85 c9             	test   %rcx,%rcx
    3aa9:	40 0f 94 c6          	sete   %sil
    3aad:	89 c1                	mov    %eax,%ecx
    3aaf:	81 e1 00 00 00 80    	and    $0x80000000,%ecx
    3ab5:	c1 e6 1e             	shl    $0x1e,%esi
    3ab8:	48 01 f1             	add    %rsi,%rcx
    3abb:	48 81 c1 00 00 00 20 	add    $0x20000000,%rcx
    3ac2:	48 89 8b 10 01 00 00 	mov    %rcx,0x110(%rbx)
    3ac9:	89 c1                	mov    %eax,%ecx
    3acb:	c1 e9 1f             	shr    $0x1f,%ecx
    3ace:	01 c1                	add    %eax,%ecx
    3ad0:	89 c8                	mov    %ecx,%eax
    3ad2:	d1 e8                	shr    $1,%eax
    3ad4:	81 e1 00 00 00 80    	and    $0x80000000,%ecx
    3ada:	09 c1                	or     %eax,%ecx
    3adc:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
    3ae0:	48 89 13             	mov    %rdx,(%rbx)
    3ae3:	89 4a 20             	mov    %ecx,0x20(%rdx)
    3ae6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    3aed:	00 00 00 
    3af0:	48 8b 4b 70          	mov    0x70(%rbx),%rcx
    3af4:	8b 01                	mov    (%rcx),%eax
    3af6:	48 89 83 30 01 00 00 	mov    %rax,0x130(%rbx)
    3afd:	48 89 03             	mov    %rax,(%rbx)
    3b00:	8d 50 01             	lea    0x1(%rax),%edx
    3b03:	48 89 53 08          	mov    %rdx,0x8(%rbx)
    3b07:	48 8b 73 70          	mov    0x70(%rbx),%rsi
    3b0b:	48 c7 83 28 01 00 00 	movq   $0xffffffffffffffff,0x128(%rbx)
    3b12:	ff ff ff ff 
    3b16:	48 39 f1             	cmp    %rsi,%rcx
    3b19:	0f 94 c1             	sete   %cl
    3b1c:	f0 0f b1 16          	lock cmpxchg %edx,(%rsi)
    3b20:	0f 94 c0             	sete   %al
    3b23:	20 c8                	and    %cl,%al
    3b25:	89 c1                	mov    %eax,%ecx
    3b27:	80 f1 01             	xor    $0x1,%cl
    3b2a:	0f b6 c9             	movzbl %cl,%ecx
    3b2d:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
    3b31:	84 c0                	test   %al,%al
    3b33:	74 bb                	je     3af0 <f_8001161d0+0x3af0>
    3b35:	48 8b 03             	mov    (%rbx),%rax
    3b38:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
    3b3f:	8b 91 84 3b 00 00    	mov    0x3b84(%rcx),%edx
    3b45:	89 d6                	mov    %edx,%esi
    3b47:	31 c6                	xor    %eax,%esi
    3b49:	89 d7                	mov    %edx,%edi
    3b4b:	31 c7                	xor    %eax,%edi
    3b4d:	48 89 53 08          	mov    %rdx,0x8(%rbx)
    3b51:	0f 84 42 fc ff ff    	je     3799 <f_8001161d0+0x3799>
    3b57:	89 d7                	mov    %edx,%edi
    3b59:	29 c7                	sub    %eax,%edi
    3b5b:	c4 e2 48 f2 ff       	andn   %edi,%esi,%edi
    3b60:	21 d6                	and    %edx,%esi
    3b62:	09 fe                	or     %edi,%esi
    3b64:	0f 88 2f fc ff ff    	js     3799 <f_8001161d0+0x3799>
    3b6a:	48 8b 89 88 3b 00 00 	mov    0x3b88(%rcx),%rcx
    3b71:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    3b75:	48 8d 14 c5 00 00 00 	lea    0x0(,%rax,8),%rdx
    3b7c:	00 
    3b7d:	48 98                	cltq
    3b7f:	48 21 e8             	and    %rbp,%rax
    3b82:	49 8d b7 2e a2 3f fd 	lea    -0x2c05dd2(%r15),%rsi
    3b89:	48 21 d6             	and    %rdx,%rsi
    3b8c:	48 09 c6             	or     %rax,%rsi
    3b8f:	48 89 33             	mov    %rsi,(%rbx)
    3b92:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
    3b99:	48 89 04 31          	mov    %rax,(%rcx,%rsi,1)
    3b9d:	e9 f7 fb ff ff       	jmp    3799 <f_8001161d0+0x3799>
