
/home/leegao/meh/ultratears-main/src/horizon2llvm/benchmark/samples/main_067_statickernel/results/main_067_statickernel_layer_12_pass12_idiom_deconstruct.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <f_8001161d0>:
       0:	55                   	push   %rbp
       1:	41 57                	push   %r15
       3:	41 56                	push   %r14
       5:	41 55                	push   %r13
       7:	41 54                	push   %r12
       9:	53                   	push   %rbx
       a:	48 83 ec 28          	sub    $0x28,%rsp
       e:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
      15:	00 00 00 
      18:	48 8b 8f e8 00 00 00 	mov    0xe8(%rdi),%rcx
      1f:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
      26:	4c 8d a0 d0 fe ff ff 	lea    -0x130(%rax),%r12
      2d:	4c 89 a7 00 01 00 00 	mov    %r12,0x100(%rdi)
      34:	48 8d 50 a0          	lea    -0x60(%rax),%rdx
      38:	48 89 48 a0          	mov    %rcx,-0x60(%rax)
      3c:	48 8b 8f f0 00 00 00 	mov    0xf0(%rdi),%rcx
      43:	48 89 48 a8          	mov    %rcx,-0x58(%rax)
      47:	48 8b 8f e0 00 00 00 	mov    0xe0(%rdi),%rcx
      4e:	48 89 48 b0          	mov    %rcx,-0x50(%rax)
      52:	48 8b 8f d8 00 00 00 	mov    0xd8(%rdi),%rcx
      59:	48 89 48 b8          	mov    %rcx,-0x48(%rax)
      5d:	48 8b 8f d0 00 00 00 	mov    0xd0(%rdi),%rcx
      64:	48 89 48 c0          	mov    %rcx,-0x40(%rax)
      68:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
      6f:	48 89 48 c8          	mov    %rcx,-0x38(%rax)
      73:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
      7a:	48 89 48 d0          	mov    %rcx,-0x30(%rax)
      7e:	48 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%rcx
      85:	48 89 48 d8          	mov    %rcx,-0x28(%rax)
      89:	48 8b 8f b0 00 00 00 	mov    0xb0(%rdi),%rcx
      90:	48 89 48 e0          	mov    %rcx,-0x20(%rax)
      94:	48 8b 8f a8 00 00 00 	mov    0xa8(%rdi),%rcx
      9b:	48 89 48 e8          	mov    %rcx,-0x18(%rax)
      9f:	48 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%rcx
      a6:	48 89 48 f0          	mov    %rcx,-0x10(%rax)
      aa:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
      b1:	48 89 48 f8          	mov    %rcx,-0x8(%rax)
      b5:	48 89 97 e8 00 00 00 	mov    %rdx,0xe8(%rdi)
      bc:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
      c0:	48 89 9f a8 00 00 00 	mov    %rbx,0xa8(%rdi)
      c7:	4c 8b 3f             	mov    (%rdi),%r15
      ca:	4c 8b 77 08          	mov    0x8(%rdi),%r14
      ce:	4c 89 b7 98 00 00 00 	mov    %r14,0x98(%rdi)
      d5:	4c 89 bf a0 00 00 00 	mov    %r15,0xa0(%rdi)
      dc:	49 8d 8e 14 29 00 00 	lea    0x2914(%r14),%rcx
      e3:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
      e7:	83 fb 20             	cmp    $0x20,%ebx
      ea:	73 1d                	jae    109 <f_8001161d0+0x109>
      ec:	b9 1f 7d c3 f6       	mov    $0xf6c37d1f,%ecx
      f1:	0f a3 d9             	bt     %ebx,%ecx
      f4:	73 13                	jae    109 <f_8001161d0+0x109>
      f6:	89 d9                	mov    %ebx,%ecx
      f8:	83 e1 1f             	and    $0x1f,%ecx
      fb:	49 8b 8c cd be 6b 16 	mov    0x166bbe(%r13,%rcx,8),%rcx
     102:	00 
     103:	48 c1 e1 08          	shl    $0x8,%rcx
     107:	eb 0e                	jmp    117 <f_8001161d0+0x117>
     109:	31 d2                	xor    %edx,%edx
     10b:	83 fb 12             	cmp    $0x12,%ebx
     10e:	b9 00 03 00 00       	mov    $0x300,%ecx
     113:	48 0f 45 ca          	cmovne %rdx,%rcx
     117:	49 bb 00 00 00 00 ff 	movabs $0xffffffff00000000,%r11
     11e:	ff ff ff 
     121:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     128:	ff 7f ff 
     12b:	41 0f be 96 17 29 00 	movsbl 0x2917(%r14),%edx
     132:	00 
     133:	48 63 d2             	movslq %edx,%rdx
     136:	4c 89 a7 c0 00 00 00 	mov    %r12,0xc0(%rdi)
     13d:	48 69 f2 48 07 00 00 	imul   $0x748,%rdx,%rsi
     144:	45 31 c9             	xor    %r9d,%r9d
     147:	41 39 97 90 33 00 00 	cmp    %edx,0x3390(%r15)
     14e:	48 bd ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rbp
     155:	ff 7f 7f 
     158:	4c 0f 47 ce          	cmova  %rsi,%r9
     15c:	49 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r10
     163:	00 80 3f 
     166:	48 be 00 00 00 00 01 	movabs $0x100000000,%rsi
     16d:	00 00 00 
     170:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
     175:	4d 03 8f 98 33 00 00 	add    0x3398(%r15),%r9
     17c:	48 c7 47 70 ff ff ff 	movq   $0xffffffffffffffff,0x70(%rdi)
     183:	ff 
     184:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 18c <f_8001161d0+0x18c>
     18b:	00 
     18c:	c5 fc 11 80 d0 fe ff 	vmovups %ymm0,-0x130(%rax)
     193:	ff 
     194:	ba ff ff ff ff       	mov    $0xffffffff,%edx
     199:	48 89 57 78          	mov    %rdx,0x78(%rdi)
     19d:	48 89 b0 f0 fe ff ff 	mov    %rsi,-0x110(%rax)
     1a4:	4c 89 98 f8 fe ff ff 	mov    %r11,-0x108(%rax)
     1ab:	4a 8d 8c 09 e8 01 00 	lea    0x1e8(%rcx,%r9,1),%rcx
     1b2:	00 
     1b3:	48 89 8f b8 00 00 00 	mov    %rcx,0xb8(%rdi)
     1ba:	48 89 90 00 ff ff ff 	mov    %rdx,-0x100(%rax)
     1c1:	4c 89 90 08 ff ff ff 	mov    %r10,-0xf8(%rax)
     1c8:	48 89 6f 58          	mov    %rbp,0x58(%rdi)
     1cc:	31 d2                	xor    %edx,%edx
     1ce:	89 de                	mov    %ebx,%esi
     1d0:	83 c6 df             	add    $0xffffffdf,%esi
     1d3:	0f 94 c2             	sete   %dl
     1d6:	31 c9                	xor    %ecx,%ecx
     1d8:	83 fb 21             	cmp    $0x21,%ebx
     1db:	0f 93 c1             	setae  %cl
     1de:	41 b9 20 00 00 00    	mov    $0x20,%r9d
     1e4:	41 29 d9             	sub    %ebx,%r9d
     1e7:	41 21 d9             	and    %ebx,%r9d
     1ea:	81 e6 00 00 00 80    	and    $0x80000000,%esi
     1f0:	c1 e2 1e             	shl    $0x1e,%edx
     1f3:	c1 e1 1d             	shl    $0x1d,%ecx
     1f6:	09 f1                	or     %esi,%ecx
     1f8:	09 d1                	or     %edx,%ecx
     1fa:	41 c1 e9 03          	shr    $0x3,%r9d
     1fe:	41 81 e1 00 00 00 10 	and    $0x10000000,%r9d
     205:	41 09 c9             	or     %ecx,%r9d
     208:	4c 89 8f 10 01 00 00 	mov    %r9,0x110(%rdi)
     20f:	4c 89 90 10 ff ff ff 	mov    %r10,-0xf0(%rax)
     216:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     21d:	00 00 00 00 
     221:	4d 8b 8d 7e 86 d5 00 	mov    0xd5867e(%r13),%r9
     228:	4c 89 4f 50          	mov    %r9,0x50(%rdi)
     22c:	49 8b 95 ae 5d d4 00 	mov    0xd45dae(%r13),%rdx
     233:	48 89 57 48          	mov    %rdx,0x48(%rdi)
     237:	49 8d 71 10          	lea    0x10(%r9),%rsi
     23b:	48 89 b0 20 ff ff ff 	mov    %rsi,-0xe0(%rax)
     242:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
     249:	4d 8b bd b6 7e d5 00 	mov    0xd57eb6(%r13),%r15
     250:	4c 89 7f 60          	mov    %r15,0x60(%rdi)
     254:	49 83 c7 10          	add    $0x10,%r15
     258:	4c 89 bf 80 00 00 00 	mov    %r15,0x80(%rdi)
     25f:	48 89 a8 48 ff ff ff 	mov    %rbp,-0xb8(%rax)
     266:	4c 89 80 50 ff ff ff 	mov    %r8,-0xb0(%rax)
     26d:	49 8d 92 00 00 80 c0 	lea    -0x3f800000(%r10),%rdx
     274:	48 89 90 74 ff ff ff 	mov    %rdx,-0x8c(%rax)
     27b:	4d 8b 95 c6 7d d5 00 	mov    0xd57dc6(%r13),%r10
     282:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
     289:	45 8b 1a             	mov    (%r10),%r11d
     28c:	4c 89 5f 40          	mov    %r11,0x40(%rdi)
     290:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
     295:	4c 89 b8 58 ff ff ff 	mov    %r15,-0xa8(%rax)
     29c:	48 89 a8 60 ff ff ff 	mov    %rbp,-0xa0(%rax)
     2a3:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     2aa:	00 
     2ab:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     2af:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     2b6:	44 89 98 70 ff ff ff 	mov    %r11d,-0x90(%rax)
     2bd:	81 e1 00 00 00 60    	and    $0x60000000,%ecx
     2c3:	81 f9 00 00 00 20    	cmp    $0x20000000,%ecx
     2c9:	0f 84 f9 29 00 00    	je     2cc8 <f_8001161d0+0x2cc8>
     2cf:	48 89 f5             	mov    %rsi,%rbp
     2d2:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
     2d7:	48 8d b0 48 ff ff ff 	lea    -0xb8(%rax),%rsi
     2de:	4c 8d 90 60 ff ff ff 	lea    -0xa0(%rax),%r10
     2e5:	48 8d 50 80          	lea    -0x80(%rax),%rdx
     2e9:	4c 8d 80 70 ff ff ff 	lea    -0x90(%rax),%r8
     2f0:	49 8d 8d 76 6b 16 00 	lea    0x166b76(%r13),%rcx
     2f7:	48 89 8f 88 00 00 00 	mov    %rcx,0x88(%rdi)
     2fe:	89 db                	mov    %ebx,%ebx
     300:	48 89 9f 90 00 00 00 	mov    %rbx,0x90(%rdi)
     307:	4c 89 a7 80 00 00 00 	mov    %r12,0x80(%rdi)
     30e:	41 0f b7 8c 5d 76 6b 	movzwl 0x166b76(%r13,%rbx,2),%ecx
     315:	16 00 
     317:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
     31b:	4d 8d a4 8d 52 05 51 	lea    -0x2aefaae(%r13,%rcx,4),%r12
     322:	fd 
     323:	4d 89 d5             	mov    %r10,%r13
     326:	4c 89 27             	mov    %r12,(%rdi)
     329:	48 89 74 24 20       	mov    %rsi,0x20(%rsp)
     32e:	48 89 77 48          	mov    %rsi,0x48(%rdi)
     332:	4c 89 97 d0 00 00 00 	mov    %r10,0xd0(%rdi)
     339:	4c 89 87 c8 00 00 00 	mov    %r8,0xc8(%rdi)
     340:	48 89 97 d8 00 00 00 	mov    %rdx,0xd8(%rdi)
     347:	81 f9 86 02 00 00    	cmp    $0x286,%ecx
     34d:	7f 6d                	jg     3bc <f_8001161d0+0x3bc>
     34f:	81 f9 2d 01 00 00    	cmp    $0x12d,%ecx
     355:	0f 8f fa 00 00 00    	jg     455 <f_8001161d0+0x455>
     35b:	83 f9 6f             	cmp    $0x6f,%ecx
     35e:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     365:	ff 7f ff 
     368:	49 89 ef             	mov    %rbp,%r15
     36b:	4d 89 da             	mov    %r11,%r10
     36e:	0f 8f 67 04 00 00    	jg     7db <f_8001161d0+0x7db>
     374:	83 f9 04             	cmp    $0x4,%ecx
     377:	0f 87 ee 10 00 00    	ja     146b <f_8001161d0+0x146b>
     37d:	89 c9                	mov    %ecx,%ecx
     37f:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 386 <f_8001161d0+0x386>
     386:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
     38a:	48 01 d1             	add    %rdx,%rcx
     38d:	ff e1                	jmp    *%rcx
     38f:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
     394:	0f b7 99 e4 0c 00 00 	movzwl 0xce4(%rcx),%ebx
     39b:	8b 8f a8 00 00 00    	mov    0xa8(%rdi),%ecx
     3a1:	ba ff ff ff ff       	mov    $0xffffffff,%edx
     3a6:	01 d1                	add    %edx,%ecx
     3a8:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
     3ac:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
     3b3:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
     3b7:	e9 a9 15 00 00       	jmp    1965 <f_8001161d0+0x1965>
     3bc:	81 f9 6d 04 00 00    	cmp    $0x46d,%ecx
     3c2:	0f 8e be 02 00 00    	jle    686 <f_8001161d0+0x686>
     3c8:	44 8d 89 92 fb ff ff 	lea    -0x46e(%rcx),%r9d
     3cf:	41 83 f9 0c          	cmp    $0xc,%r9d
     3d3:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     3da:	ff 7f ff 
     3dd:	48 89 ee             	mov    %rbp,%rsi
     3e0:	4d 89 da             	mov    %r11,%r10
     3e3:	0f 86 1a 08 00 00    	jbe    c03 <f_8001161d0+0xc03>
     3e9:	44 8d 89 36 fb ff ff 	lea    -0x4ca(%rcx),%r9d
     3f0:	41 83 f9 16          	cmp    $0x16,%r9d
     3f4:	0f 87 15 10 00 00    	ja     140f <f_8001161d0+0x140f>
     3fa:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 401 <f_8001161d0+0x401>
     401:	4a 63 14 89          	movslq (%rcx,%r9,4),%rdx
     405:	48 01 ca             	add    %rcx,%rdx
     408:	ff e2                	jmp    *%rdx
     40a:	48 c7 47 40 b0 1e 00 	movq   $0x1eb0,0x40(%rdi)
     411:	00 
     412:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
     419:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
     420:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
     424:	48 89 47 10          	mov    %rax,0x10(%rdi)
     428:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
     42d:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
     434:	48 89 07             	mov    %rax,(%rdi)
     437:	48 c7 47 18 01 00 00 	movq   $0x1,0x18(%rdi)
     43e:	00 
     43f:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     446:	00 00 00 
     449:	49 8d 85 92 18 51 fd 	lea    -0x2aee76e(%r13),%rax
     450:	e9 b5 18 00 00       	jmp    1d0a <f_8001161d0+0x1d0a>
     455:	81 f9 c7 01 00 00    	cmp    $0x1c7,%ecx
     45b:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     462:	ff 7f ff 
     465:	49 89 ef             	mov    %rbp,%r15
     468:	4d 89 da             	mov    %r11,%r10
     46b:	0f 8f 42 06 00 00    	jg     ab3 <f_8001161d0+0xab3>
     471:	81 f9 b1 01 00 00    	cmp    $0x1b1,%ecx
     477:	0f 8f bb 0a 00 00    	jg     f38 <f_8001161d0+0xf38>
     47d:	81 f9 2e 01 00 00    	cmp    $0x12e,%ecx
     483:	0f 84 31 1e 00 00    	je     22ba <f_8001161d0+0x22ba>
     489:	81 f9 66 01 00 00    	cmp    $0x166,%ecx
     48f:	0f 85 12 18 00 00    	jne    1ca7 <f_8001161d0+0x1ca7>
     495:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
     49c:	48 8b 97 a0 00 00 00 	mov    0xa0(%rdi),%rdx
     4a3:	48 8b 92 c8 1e 00 00 	mov    0x1ec8(%rdx),%rdx
     4aa:	48 89 57 08          	mov    %rdx,0x8(%rdi)
     4ae:	48 c7 87 80 00 00 00 	movq   $0x3ce0,0x80(%rdi)
     4b5:	e0 3c 00 00 
     4b9:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
     4be:	48 89 77 60          	mov    %rsi,0x60(%rdi)
     4c2:	44 0f b6 49 08       	movzbl 0x8(%rcx),%r9d
     4c7:	4c 89 4f 68          	mov    %r9,0x68(%rdi)
     4cb:	49 69 d9 e0 3c 00 00 	imul   $0x3ce0,%r9,%rbx
     4d2:	31 c9                	xor    %ecx,%ecx
     4d4:	44 39 4a 08          	cmp    %r9d,0x8(%rdx)
     4d8:	48 0f 46 d9          	cmovbe %rcx,%rbx
     4dc:	48 8b 52 10          	mov    0x10(%rdx),%rdx
     4e0:	48 8b 94 13 40 3c 00 	mov    0x3c40(%rbx,%rdx,1),%rdx
     4e7:	00 
     4e8:	48 89 97 b0 00 00 00 	mov    %rdx,0xb0(%rdi)
     4ef:	4c 8b 8f 00 01 00 00 	mov    0x100(%rdi),%r9
     4f6:	45 89 91 a0 00 00 00 	mov    %r10d,0xa0(%r9)
     4fd:	49 89 b1 88 00 00 00 	mov    %rsi,0x88(%r9)
     504:	48 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rdx
     50b:	ff 7f 7f 
     50e:	49 89 91 90 00 00 00 	mov    %rdx,0x90(%r9)
     515:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     51c:	00 
     51d:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     521:	41 c7 81 bc 00 00 00 	movl   $0x0,0xbc(%r9)
     528:	00 00 00 00 
     52c:	49 c7 41 48 00 00 00 	movq   $0x0,0x48(%r9)
     533:	00 
     534:	4d 89 79 50          	mov    %r15,0x50(%r9)
     538:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     53c:	c4 c1 78 11 41 58    	vmovups %xmm0,0x58(%r9)
     542:	49 c7 41 30 08 00 00 	movq   $0x8,0x30(%r9)
     549:	00 
     54a:	48 b8 10 00 00 00 03 	movabs $0x300000010,%rax
     551:	00 00 00 
     554:	49 89 01             	mov    %rax,(%r9)
     557:	49 c7 41 08 00 00 00 	movq   $0x0,0x8(%r9)
     55e:	00 
     55f:	49 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%r9)
     566:	00 
     567:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     56e:	ff ff ff 
     571:	48 8d 42 0d          	lea    0xd(%rdx),%rax
     575:	49 89 41 18          	mov    %rax,0x18(%r9)
     579:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     580:	00 00 00 
     583:	49 89 41 20          	mov    %rax,0x20(%r9)
     587:	49 89 51 28          	mov    %rdx,0x28(%r9)
     58b:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
     592:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
     597:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
     59e:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
     5a5:	00 80 3f 
     5a8:	49 89 41 38          	mov    %rax,0x38(%r9)
     5ac:	49 89 41 40          	mov    %rax,0x40(%r9)
     5b0:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     5b7:	00 00 00 
     5ba:	49 8d 85 8b 0d 02 00 	lea    0x20d8b(%r13),%rax
     5c1:	48 89 47 70          	mov    %rax,0x70(%rdi)
     5c5:	4c 89 47 78          	mov    %r8,0x78(%rdi)
     5c9:	4d 89 81 98 00 00 00 	mov    %r8,0x98(%r9)
     5d0:	48 8b 57 58          	mov    0x58(%rdi),%rdx
     5d4:	49 89 51 78          	mov    %rdx,0x78(%r9)
     5d8:	4d 89 81 80 00 00 00 	mov    %r8,0x80(%r9)
     5df:	49 c7 41 68 00 00 00 	movq   $0x0,0x68(%r9)
     5e6:	00 
     5e7:	49 89 41 70          	mov    %rax,0x70(%r9)
     5eb:	48 8b 47 08          	mov    0x8(%rdi),%rax
     5ef:	48 8b 57 48          	mov    0x48(%rdi),%rdx
     5f3:	4c 8b 40 10          	mov    0x10(%rax),%r8
     5f7:	4c 8b 57 68          	mov    0x68(%rdi),%r10
     5fb:	44 39 50 08          	cmp    %r10d,0x8(%rax)
     5ff:	4c 89 d6             	mov    %r10,%rsi
     602:	48 0f 46 f1          	cmovbe %rcx,%rsi
     606:	48 89 77 40          	mov    %rsi,0x40(%rdi)
     60a:	41 89 f1             	mov    %esi,%r9d
     60d:	8b b7 80 00 00 00    	mov    0x80(%rdi),%esi
     613:	4c 0f af ce          	imul   %rsi,%r9
     617:	c4 81 78 10 84 01 00 	vmovups 0x2e00(%r9,%r8,1),%xmm0
     61e:	2e 00 00 
     621:	c5 f8 11 02          	vmovups %xmm0,(%rdx)
     625:	44 8b 40 08          	mov    0x8(%rax),%r8d
     629:	45 31 db             	xor    %r11d,%r11d
     62c:	44 89 c3             	mov    %r8d,%ebx
     62f:	44 31 d3             	xor    %r10d,%ebx
     632:	41 0f 94 c3          	sete   %r11b
     636:	45 31 c9             	xor    %r9d,%r9d
     639:	44 89 c5             	mov    %r8d,%ebp
     63c:	44 29 d5             	sub    %r10d,%ebp
     63f:	44 89 d2             	mov    %r10d,%edx
     642:	48 0f 46 d1          	cmovbe %rcx,%rdx
     646:	41 0f 93 c1          	setae  %r9b
     64a:	41 31 e8             	xor    %ebp,%r8d
     64d:	41 21 d8             	and    %ebx,%r8d
     650:	41 c1 e3 1e          	shl    $0x1e,%r11d
     654:	41 c1 e1 1d          	shl    $0x1d,%r9d
     658:	45 09 d9             	or     %r11d,%r9d
     65b:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
     661:	41 09 e9             	or     %ebp,%r9d
     664:	41 c1 e8 03          	shr    $0x3,%r8d
     668:	41 81 e0 00 00 00 10 	and    $0x10000000,%r8d
     66f:	45 09 c8             	or     %r9d,%r8d
     672:	48 0f af d6          	imul   %rsi,%rdx
     676:	48 03 50 10          	add    0x10(%rax),%rdx
     67a:	4c 89 87 10 01 00 00 	mov    %r8,0x110(%rdi)
     681:	e9 28 1e 00 00       	jmp    24ae <f_8001161d0+0x24ae>
     686:	81 f9 d4 02 00 00    	cmp    $0x2d4,%ecx
     68c:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     693:	ff 7f ff 
     696:	49 89 ef             	mov    %rbp,%r15
     699:	4d 89 da             	mov    %r11,%r10
     69c:	0f 8f b7 04 00 00    	jg     b59 <f_8001161d0+0xb59>
     6a2:	81 f9 b5 02 00 00    	cmp    $0x2b5,%ecx
     6a8:	0f 8f 28 09 00 00    	jg     fd6 <f_8001161d0+0xfd6>
     6ae:	81 f9 87 02 00 00    	cmp    $0x287,%ecx
     6b4:	0f 84 d6 1e 00 00    	je     2590 <f_8001161d0+0x2590>
     6ba:	81 f9 97 02 00 00    	cmp    $0x297,%ecx
     6c0:	0f 85 e1 15 00 00    	jne    1ca7 <f_8001161d0+0x1ca7>
     6c6:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
     6cd:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
     6d4:	48 c7 01 00 00 00 40 	movq   $0x40000000,(%rcx)
     6db:	48 ba 00 00 00 00 00 	movabs $0x40000000000000,%rdx
     6e2:	00 40 00 
     6e5:	48 89 51 08          	mov    %rdx,0x8(%rcx)
     6e9:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     6f0:	00 
     6f1:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     6f8:	ff ff ff 
     6fb:	4d 89 c1             	mov    %r8,%r9
     6fe:	49 89 d0             	mov    %rdx,%r8
     701:	48 83 c2 14          	add    $0x14,%rdx
     705:	48 89 51 18          	mov    %rdx,0x18(%rcx)
     709:	4c 89 7f 40          	mov    %r15,0x40(%rdi)
     70d:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     711:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     718:	00 
     719:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
     720:	00 00 00 
     723:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     72a:	00 00 00 
     72d:	48 89 41 20          	mov    %rax,0x20(%rcx)
     731:	4c 89 41 28          	mov    %r8,0x28(%rcx)
     735:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
     73a:	48 89 41 30          	mov    %rax,0x30(%rcx)
     73e:	49 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r8
     745:	00 80 3f 
     748:	4c 89 41 38          	mov    %r8,0x38(%rcx)
     74c:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
     753:	00 00 00 
     756:	48 8d 80 80 0d 02 00 	lea    0x20d80(%rax),%rax
     75d:	48 89 41 70          	mov    %rax,0x70(%rcx)
     761:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     768:	ff 7f 7f 
     76b:	4c 89 51 78          	mov    %r10,0x78(%rcx)
     76f:	4c 89 89 80 00 00 00 	mov    %r9,0x80(%rcx)
     776:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
     77b:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
     782:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 78a <f_8001161d0+0x78a>
     789:	00 
     78a:	c5 fc 11 47 60       	vmovups %ymm0,0x60(%rdi)
     78f:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
     796:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
     79b:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
     7a2:	4c 89 41 40          	mov    %r8,0x40(%rcx)
     7a6:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
     7ad:	00 
     7ae:	4c 89 91 90 00 00 00 	mov    %r10,0x90(%rcx)
     7b5:	4c 89 89 98 00 00 00 	mov    %r9,0x98(%rcx)
     7bc:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
     7c3:	00 
     7c4:	4c 89 79 50          	mov    %r15,0x50(%rcx)
     7c8:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     7cc:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
     7d1:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
     7d6:	e9 cf 23 00 00       	jmp    2baa <f_8001161d0+0x2baa>
     7db:	81 f9 c8 00 00 00    	cmp    $0xc8,%ecx
     7e1:	0f 8f 3f 04 00 00    	jg     c26 <f_8001161d0+0xc26>
     7e7:	83 f9 70             	cmp    $0x70,%ecx
     7ea:	0f 84 d1 17 00 00    	je     1fc1 <f_8001161d0+0x1fc1>
     7f0:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
     7f6:	0f 85 ab 14 00 00    	jne    1ca7 <f_8001161d0+0x1ca7>
     7fc:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
     801:	48 8b 99 c8 1e 00 00 	mov    0x1ec8(%rcx),%rbx
     808:	48 89 5f 08          	mov    %rbx,0x8(%rdi)
     80c:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
     811:	48 89 77 60          	mov    %rsi,0x60(%rdi)
     815:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
     81c:	00 
     81d:	45 0f b6 76 08       	movzbl 0x8(%r14),%r14d
     822:	4c 89 77 68          	mov    %r14,0x68(%rdi)
     826:	8b 53 08             	mov    0x8(%rbx),%edx
     829:	4d 89 fb             	mov    %r15,%r11
     82c:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
     830:	4d 69 ce e0 3c 00 00 	imul   $0x3ce0,%r14,%r9
     837:	31 c9                	xor    %ecx,%ecx
     839:	44 39 f2             	cmp    %r14d,%edx
     83c:	ba 00 00 00 00       	mov    $0x0,%edx
     841:	49 0f 47 d1          	cmova  %r9,%rdx
     845:	48 c7 47 70 e0 3c 00 	movq   $0x3ce0,0x70(%rdi)
     84c:	00 
     84d:	4a 8b 94 3a 40 3c 00 	mov    0x3c40(%rdx,%r15,1),%rdx
     854:	00 
     855:	48 89 97 b0 00 00 00 	mov    %rdx,0xb0(%rdi)
     85c:	44 89 90 70 ff ff ff 	mov    %r10d,-0x90(%rax)
     863:	48 89 b0 58 ff ff ff 	mov    %rsi,-0xa8(%rax)
     86a:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     871:	ff 7f 7f 
     874:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
     87b:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     882:	00 
     883:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     887:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     88e:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     895:	00 00 00 00 
     899:	4c 89 98 20 ff ff ff 	mov    %r11,-0xe0(%rax)
     8a0:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     8a4:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
     8ab:	ff 
     8ac:	48 c7 80 00 ff ff ff 	movq   $0x5,-0x100(%rax)
     8b3:	05 00 00 00 
     8b7:	48 be 10 00 00 00 03 	movabs $0x300000010,%rsi
     8be:	00 00 00 
     8c1:	48 81 c6 f0 00 00 00 	add    $0xf0,%rsi
     8c8:	48 89 b0 d0 fe ff ff 	mov    %rsi,-0x130(%rax)
     8cf:	48 be 00 00 00 00 00 	movabs $0x60000000000000,%rsi
     8d6:	00 60 00 
     8d9:	48 89 b0 d8 fe ff ff 	mov    %rsi,-0x128(%rax)
     8e0:	48 89 17             	mov    %rdx,(%rdi)
     8e3:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     8ea:	ff ff 00 00 
     8ee:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     8f5:	ff ff ff 
     8f8:	48 8d 55 08          	lea    0x8(%rbp),%rdx
     8fc:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
     903:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
     90a:	00 00 00 
     90d:	48 89 90 f0 fe ff ff 	mov    %rdx,-0x110(%rax)
     914:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
     91b:	48 8b 97 c0 00 00 00 	mov    0xc0(%rdi),%rdx
     922:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
     927:	48 89 b2 a4 00 00 00 	mov    %rsi,0xa4(%rdx)
     92e:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
     935:	00 80 3f 
     938:	48 89 90 08 ff ff ff 	mov    %rdx,-0xf8(%rax)
     93f:	48 89 90 10 ff ff ff 	mov    %rdx,-0xf0(%rax)
     946:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     94d:	00 00 00 
     950:	49 8d 95 1d 54 09 00 	lea    0x9541d(%r13),%rdx
     957:	48 89 57 78          	mov    %rdx,0x78(%rdi)
     95b:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
     962:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
     969:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
     970:	4c 89 80 50 ff ff ff 	mov    %r8,-0xb0(%rax)
     977:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
     97e:	00 00 00 00 
     982:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
     989:	44 39 73 08          	cmp    %r14d,0x8(%rbx)
     98d:	ba 00 00 00 00       	mov    $0x0,%edx
     992:	49 0f 47 d1          	cmova  %r9,%rdx
     996:	48 8b 73 10          	mov    0x10(%rbx),%rsi
     99a:	c5 f8 10 84 16 00 2e 	vmovups 0x2e00(%rsi,%rdx,1),%xmm0
     9a1:	00 00 
     9a3:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
     9aa:	ff 
     9ab:	8b 73 08             	mov    0x8(%rbx),%esi
     9ae:	45 31 c0             	xor    %r8d,%r8d
     9b1:	31 d2                	xor    %edx,%edx
     9b3:	41 89 f2             	mov    %esi,%r10d
     9b6:	45 29 f2             	sub    %r14d,%r10d
     9b9:	49 0f 47 c9          	cmova  %r9,%rcx
     9bd:	41 0f 94 c0          	sete   %r8b
     9c1:	0f 93 c2             	setae  %dl
     9c4:	41 c1 e0 1e          	shl    $0x1e,%r8d
     9c8:	c1 e2 1d             	shl    $0x1d,%edx
     9cb:	44 09 c2             	or     %r8d,%edx
     9ce:	c4 e2 28 f2 f6       	andn   %esi,%r10d,%esi
     9d3:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
     9da:	44 09 d2             	or     %r10d,%edx
     9dd:	4c 8b 43 10          	mov    0x10(%rbx),%r8
     9e1:	c1 ee 03             	shr    $0x3,%esi
     9e4:	81 e6 00 00 00 10    	and    $0x10000000,%esi
     9ea:	09 d6                	or     %edx,%esi
     9ec:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
     9f3:	49 8b 94 08 80 30 00 	mov    0x3080(%r8,%rcx,1),%rdx
     9fa:	00 
     9fb:	49 8b b4 08 88 30 00 	mov    0x3088(%r8,%rcx,1),%rsi
     a02:	00 
     a03:	48 89 77 50          	mov    %rsi,0x50(%rdi)
     a07:	48 89 90 60 ff ff ff 	mov    %rdx,-0xa0(%rax)
     a0e:	48 89 b0 68 ff ff ff 	mov    %rsi,-0x98(%rax)
     a15:	49 8b 94 08 90 30 00 	mov    0x3090(%r8,%rcx,1),%rdx
     a1c:	00 
     a1d:	48 89 57 48          	mov    %rdx,0x48(%rdi)
     a21:	41 8b 8c 08 98 30 00 	mov    0x3098(%r8,%rcx,1),%ecx
     a28:	00 
     a29:	89 88 78 ff ff ff    	mov    %ecx,-0x88(%rax)
     a2f:	48 8b 8f e8 00 00 00 	mov    0xe8(%rdi),%rcx
     a36:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
     a3a:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
     a3e:	48 89 90 70 ff ff ff 	mov    %rdx,-0x90(%rax)
     a45:	49 8d 85 56 08 51 fd 	lea    -0x2aef7aa(%r13),%rax
     a4c:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
     a53:	48 89 fb             	mov    %rdi,%rbx
     a56:	c5 f8 77             	vzeroupper
     a59:	e8 00 00 00 00       	call   a5e <f_8001161d0+0xa5e>
     a5e:	48 89 df             	mov    %rbx,%rdi
     a61:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     a68:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
     a6f:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     a76:	48 89 01             	mov    %rax,(%rcx)
     a79:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     a80:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     a87:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
     a8b:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
     a92:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     a96:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     a9c:	48 89 43 40          	mov    %rax,0x40(%rbx)
     aa0:	88 51 08             	mov    %dl,0x8(%rcx)
     aa3:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     aaa:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
     aae:	e9 c3 1a 00 00       	jmp    2576 <f_8001161d0+0x2576>
     ab3:	81 f9 51 02 00 00    	cmp    $0x251,%ecx
     ab9:	0f 8f bb 05 00 00    	jg     107a <f_8001161d0+0x107a>
     abf:	81 f9 c8 01 00 00    	cmp    $0x1c8,%ecx
     ac5:	0f 84 4b 1b 00 00    	je     2616 <f_8001161d0+0x2616>
     acb:	81 f9 0f 02 00 00    	cmp    $0x20f,%ecx
     ad1:	0f 85 d0 11 00 00    	jne    1ca7 <f_8001161d0+0x1ca7>
     ad7:	4d 89 fc             	mov    %r15,%r12
     ada:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
     ae1:	00 
     ae2:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
     ae9:	48 c7 01 00 08 00 00 	movq   $0x800,(%rcx)
     af0:	48 c7 41 08 01 00 00 	movq   $0x1,0x8(%rcx)
     af7:	00 
     af8:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     aff:	ff ff ff 
     b02:	48 8d 55 0b          	lea    0xb(%rbp),%rdx
     b06:	48 89 57 68          	mov    %rdx,0x68(%rdi)
     b0a:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     b11:	00 
     b12:	48 89 51 18          	mov    %rdx,0x18(%rcx)
     b16:	49 bf 00 00 00 00 01 	movabs $0x100000000,%r15
     b1d:	00 00 00 
     b20:	4c 89 79 20          	mov    %r15,0x20(%rcx)
     b24:	48 89 69 28          	mov    %rbp,0x28(%rcx)
     b28:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
     b2f:	00 80 3f 
     b32:	4c 89 77 70          	mov    %r14,0x70(%rdi)
     b36:	ba ff ff ff ff       	mov    $0xffffffff,%edx
     b3b:	48 89 51 30          	mov    %rdx,0x30(%rcx)
     b3f:	4c 89 71 38          	mov    %r14,0x38(%rcx)
     b43:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     b4a:	00 00 00 
     b4d:	49 8d 9d 07 a8 04 00 	lea    0x4a807(%r13),%rbx
     b54:	e9 9a 15 00 00       	jmp    20f3 <f_8001161d0+0x20f3>
     b59:	81 f9 ac 03 00 00    	cmp    $0x3ac,%ecx
     b5f:	0f 8f 88 06 00 00    	jg     11ed <f_8001161d0+0x11ed>
     b65:	81 f9 d5 02 00 00    	cmp    $0x2d5,%ecx
     b6b:	0f 84 2e 1d 00 00    	je     289f <f_8001161d0+0x289f>
     b71:	81 f9 f3 02 00 00    	cmp    $0x2f3,%ecx
     b77:	0f 85 2a 11 00 00    	jne    1ca7 <f_8001161d0+0x1ca7>
     b7d:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
     b84:	00 
     b85:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
     b8c:	48 c7 03 00 02 00 00 	movq   $0x200,(%rbx)
     b93:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
     b9a:	00 40 00 
     b9d:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     ba1:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
     ba8:	00 
     ba9:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     bb0:	ff ff ff 
     bb3:	48 8d 4a 13          	lea    0x13(%rdx),%rcx
     bb7:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
     bbb:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     bc2:	00 00 00 
     bc5:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
     bc9:	48 89 53 28          	mov    %rdx,0x28(%rbx)
     bcd:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
     bd3:	4c 89 47 68          	mov    %r8,0x68(%rdi)
     bd7:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
     bde:	00 80 3f 
     be1:	4c 89 77 70          	mov    %r14,0x70(%rdi)
     be5:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
     be9:	48 83 c3 38          	add    $0x38,%rbx
     bed:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
     bf4:	00 00 00 
     bf7:	4c 8d 8a f9 7a ff ff 	lea    -0x8507(%rdx),%r9
     bfe:	e9 f6 1e 00 00       	jmp    2af9 <f_8001161d0+0x2af9>
     c03:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # c0a <f_8001161d0+0xc0a>
     c0a:	4a 63 14 89          	movslq (%rcx,%r9,4),%rdx
     c0e:	48 01 ca             	add    %rcx,%rdx
     c11:	ff e2                	jmp    *%rdx
     c13:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     c1a:	00 00 00 
     c1d:	4d 8d 75 e0          	lea    -0x20(%r13),%r14
     c21:	e9 1d 09 00 00       	jmp    1543 <f_8001161d0+0x1543>
     c26:	81 f9 c9 00 00 00    	cmp    $0xc9,%ecx
     c2c:	0f 84 27 14 00 00    	je     2059 <f_8001161d0+0x2059>
     c32:	81 f9 d9 00 00 00    	cmp    $0xd9,%ecx
     c38:	0f 85 69 10 00 00    	jne    1ca7 <f_8001161d0+0x1ca7>
     c3e:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
     c43:	48 8b 99 c8 1e 00 00 	mov    0x1ec8(%rcx),%rbx
     c4a:	48 89 5f 08          	mov    %rbx,0x8(%rdi)
     c4e:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
     c53:	48 89 77 60          	mov    %rsi,0x60(%rdi)
     c57:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
     c5e:	00 
     c5f:	45 0f b6 4e 08       	movzbl 0x8(%r14),%r9d
     c64:	4c 89 4f 70          	mov    %r9,0x70(%rdi)
     c68:	41 0f b7 ae 14 29 00 	movzwl 0x2914(%r14),%ebp
     c6f:	00 
     c70:	83 e5 40             	and    $0x40,%ebp
     c73:	8b 53 08             	mov    0x8(%rbx),%edx
     c76:	4c 8b 73 10          	mov    0x10(%rbx),%r14
     c7a:	31 c9                	xor    %ecx,%ecx
     c7c:	44 39 ca             	cmp    %r9d,%edx
     c7f:	ba 00 00 00 00       	mov    $0x0,%edx
     c84:	49 0f 47 d1          	cmova  %r9,%rdx
     c88:	48 c7 47 78 e0 3c 00 	movq   $0x3ce0,0x78(%rdi)
     c8f:	00 
     c90:	48 89 97 88 00 00 00 	mov    %rdx,0x88(%rdi)
     c97:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
     c9e:	4a 8b 94 32 40 3c 00 	mov    0x3c40(%rdx,%r14,1),%rdx
     ca5:	00 
     ca6:	48 89 97 b0 00 00 00 	mov    %rdx,0xb0(%rdi)
     cad:	4c 8b b7 a0 00 00 00 	mov    0xa0(%rdi),%r14
     cb4:	4d 8b b6 b8 1e 00 00 	mov    0x1eb8(%r14),%r14
     cbb:	44 89 90 70 ff ff ff 	mov    %r10d,-0x90(%rax)
     cc2:	48 89 b0 58 ff ff ff 	mov    %rsi,-0xa8(%rax)
     cc9:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
     cd0:	ff 7f 7f 
     cd3:	4c 89 98 60 ff ff ff 	mov    %r11,-0xa0(%rax)
     cda:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     ce1:	00 
     ce2:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     ce6:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     ced:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     cf1:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
     cf8:	ff 
     cf9:	41 80 be b0 06 00 00 	cmpb   $0x0,0x6b0(%r14)
     d00:	00 
     d01:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     d08:	00 00 00 00 
     d0c:	4c 89 b8 20 ff ff ff 	mov    %r15,-0xe0(%rax)
     d13:	48 c7 80 00 ff ff ff 	movq   $0x4,-0x100(%rax)
     d1a:	04 00 00 00 
     d1e:	48 89 17             	mov    %rdx,(%rdi)
     d21:	0f 95 c2             	setne  %dl
     d24:	c1 ed 06             	shr    $0x6,%ebp
     d27:	40 20 d5             	and    %dl,%bpl
     d2a:	c7 80 d8 fe ff ff 00 	movl   $0x0,-0x128(%rax)
     d31:	00 00 00 
     d34:	40 0f b6 d5          	movzbl %bpl,%edx
     d38:	c1 e2 1a             	shl    $0x1a,%edx
     d3b:	81 ca 01 00 40 00    	or     $0x400001,%edx
     d41:	89 90 dc fe ff ff    	mov    %edx,-0x124(%rax)
     d47:	48 ba 10 00 00 00 03 	movabs $0x300000010,%rdx
     d4e:	00 00 00 
     d51:	48 89 90 d0 fe ff ff 	mov    %rdx,-0x130(%rax)
     d58:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     d5f:	ff ff 00 00 
     d63:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     d6a:	ff ff ff 
     d6d:	48 8d 55 07          	lea    0x7(%rbp),%rdx
     d71:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
     d78:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
     d7f:	00 00 00 
     d82:	48 89 90 f0 fe ff ff 	mov    %rdx,-0x110(%rax)
     d89:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
     d90:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
     d97:	00 80 3f 
     d9a:	48 89 90 08 ff ff ff 	mov    %rdx,-0xf8(%rax)
     da1:	48 89 90 10 ff ff ff 	mov    %rdx,-0xf0(%rax)
     da8:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     daf:	00 00 00 
     db2:	49 8d 95 00 54 09 00 	lea    0x95400(%r13),%rdx
     db9:	48 89 57 68          	mov    %rdx,0x68(%rdi)
     dbd:	48 8b b7 c0 00 00 00 	mov    0xc0(%rdi),%rsi
     dc4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
     dc9:	4c 89 96 a4 00 00 00 	mov    %r10,0xa4(%rsi)
     dd0:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
     dd7:	4c 89 98 48 ff ff ff 	mov    %r11,-0xb8(%rax)
     dde:	4c 89 80 50 ff ff ff 	mov    %r8,-0xb0(%rax)
     de5:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
     dec:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
     df3:	00 00 00 00 
     df7:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
     dfe:	49 69 f1 e0 3c 00 00 	imul   $0x3ce0,%r9,%rsi
     e05:	44 39 4b 08          	cmp    %r9d,0x8(%rbx)
     e09:	ba 00 00 00 00       	mov    $0x0,%edx
     e0e:	48 0f 47 d6          	cmova  %rsi,%rdx
     e12:	4c 8b 43 10          	mov    0x10(%rbx),%r8
     e16:	c4 c1 78 10 84 10 00 	vmovups 0x2e00(%r8,%rdx,1),%xmm0
     e1d:	2e 00 00 
     e20:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
     e27:	ff 
     e28:	44 8b 43 08          	mov    0x8(%rbx),%r8d
     e2c:	45 31 d2             	xor    %r10d,%r10d
     e2f:	31 d2                	xor    %edx,%edx
     e31:	45 89 c3             	mov    %r8d,%r11d
     e34:	45 29 cb             	sub    %r9d,%r11d
     e37:	48 0f 47 ce          	cmova  %rsi,%rcx
     e3b:	41 0f 94 c2          	sete   %r10b
     e3f:	0f 93 c2             	setae  %dl
     e42:	41 c1 e2 1e          	shl    $0x1e,%r10d
     e46:	c1 e2 1d             	shl    $0x1d,%edx
     e49:	44 09 d2             	or     %r10d,%edx
     e4c:	c4 c2 20 f2 f0       	andn   %r8d,%r11d,%esi
     e51:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
     e58:	44 09 da             	or     %r11d,%edx
     e5b:	4c 8b 43 10          	mov    0x10(%rbx),%r8
     e5f:	c1 ee 03             	shr    $0x3,%esi
     e62:	81 e6 00 00 00 10    	and    $0x10000000,%esi
     e68:	09 d6                	or     %edx,%esi
     e6a:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
     e71:	49 8b 94 08 80 30 00 	mov    0x3080(%r8,%rcx,1),%rdx
     e78:	00 
     e79:	49 8b b4 08 88 30 00 	mov    0x3088(%r8,%rcx,1),%rsi
     e80:	00 
     e81:	48 89 77 50          	mov    %rsi,0x50(%rdi)
     e85:	48 89 90 60 ff ff ff 	mov    %rdx,-0xa0(%rax)
     e8c:	48 89 b0 68 ff ff ff 	mov    %rsi,-0x98(%rax)
     e93:	49 8b 94 08 90 30 00 	mov    0x3090(%r8,%rcx,1),%rdx
     e9a:	00 
     e9b:	48 89 57 48          	mov    %rdx,0x48(%rdi)
     e9f:	41 8b 8c 08 98 30 00 	mov    0x3098(%r8,%rcx,1),%ecx
     ea6:	00 
     ea7:	89 88 78 ff ff ff    	mov    %ecx,-0x88(%rax)
     ead:	48 8b 8f e8 00 00 00 	mov    0xe8(%rdi),%rcx
     eb4:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
     eb8:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
     ebc:	48 89 90 70 ff ff ff 	mov    %rdx,-0x90(%rax)
     ec3:	49 8d 85 e6 09 51 fd 	lea    -0x2aef61a(%r13),%rax
     eca:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
     ed1:	48 89 fb             	mov    %rdi,%rbx
     ed4:	c5 f8 77             	vzeroupper
     ed7:	e8 00 00 00 00       	call   edc <f_8001161d0+0xedc>
     edc:	48 89 df             	mov    %rbx,%rdi
     edf:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     ee6:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
     eed:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     ef4:	48 89 01             	mov    %rax,(%rcx)
     ef7:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     efe:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     f05:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
     f09:	48 89 53 48          	mov    %rdx,0x48(%rbx)
     f0d:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
     f14:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     f18:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     f1e:	48 89 43 40          	mov    %rax,0x40(%rbx)
     f22:	88 51 08             	mov    %dl,0x8(%rcx)
     f25:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     f2c:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
     f30:	89 41 24             	mov    %eax,0x24(%rcx)
     f33:	e9 90 1d 00 00       	jmp    2cc8 <f_8001161d0+0x2cc8>
     f38:	81 f9 b2 01 00 00    	cmp    $0x1b2,%ecx
     f3e:	0f 84 63 1a 00 00    	je     29a7 <f_8001161d0+0x29a7>
     f44:	81 f9 b8 01 00 00    	cmp    $0x1b8,%ecx
     f4a:	0f 85 57 0d 00 00    	jne    1ca7 <f_8001161d0+0x1ca7>
     f50:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
     f57:	00 
     f58:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
     f5f:	48 c7 03 08 00 00 00 	movq   $0x8,(%rbx)
     f66:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
     f6d:	00 40 00 
     f70:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     f74:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
     f7b:	00 
     f7c:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     f83:	ff ff ff 
     f86:	48 8d 4a 15          	lea    0x15(%rdx),%rcx
     f8a:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
     f8e:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     f95:	00 00 00 
     f98:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
     f9c:	48 89 53 28          	mov    %rdx,0x28(%rbx)
     fa0:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
     fa6:	4c 89 47 68          	mov    %r8,0x68(%rdi)
     faa:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
     fb1:	00 80 3f 
     fb4:	4c 89 77 70          	mov    %r14,0x70(%rdi)
     fb8:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
     fbc:	48 83 c3 38          	add    $0x38,%rbx
     fc0:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
     fc7:	00 00 00 
     fca:	4c 8d 8a af 2c 05 00 	lea    0x52caf(%rdx),%r9
     fd1:	e9 23 1b 00 00       	jmp    2af9 <f_8001161d0+0x2af9>
     fd6:	81 f9 b6 02 00 00    	cmp    $0x2b6,%ecx
     fdc:	0f 84 1d 1a 00 00    	je     29ff <f_8001161d0+0x29ff>
     fe2:	81 f9 c5 02 00 00    	cmp    $0x2c5,%ecx
     fe8:	0f 85 b9 0c 00 00    	jne    1ca7 <f_8001161d0+0x1ca7>
     fee:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
     ff5:	00 
     ff6:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
     ffd:	48 b9 01 00 00 00 04 	movabs $0x400000001,%rcx
    1004:	00 00 00 
    1007:	48 89 0b             	mov    %rcx,(%rbx)
    100a:	48 b9 00 00 00 00 02 	movabs $0x80200000000,%rcx
    1011:	08 00 00 
    1014:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    1018:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
    101f:	00 
    1020:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    1027:	ff ff ff 
    102a:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    102e:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    1032:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    1039:	00 00 00 
    103c:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
    1040:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    1044:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    104a:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    104e:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    1055:	00 80 3f 
    1058:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    105c:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
    1060:	48 83 c3 38          	add    $0x38,%rbx
    1064:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
    106b:	00 00 00 
    106e:	4c 8d 8a 88 db 0a 00 	lea    0xadb88(%rdx),%r9
    1075:	e9 7f 1a 00 00       	jmp    2af9 <f_8001161d0+0x2af9>
    107a:	81 f9 52 02 00 00    	cmp    $0x252,%ecx
    1080:	0f 84 fc 19 00 00    	je     2a82 <f_8001161d0+0x2a82>
    1086:	81 f9 61 02 00 00    	cmp    $0x261,%ecx
    108c:	0f 85 15 0c 00 00    	jne    1ca7 <f_8001161d0+0x1ca7>
    1092:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    1099:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
    10a0:	48 ba 00 00 00 00 0f 	movabs $0xf00000000,%rdx
    10a7:	00 00 00 
    10aa:	48 89 51 14          	mov    %rdx,0x14(%rcx)
    10ae:	48 ba 00 00 00 00 ff 	movabs $0xffff00000000,%rdx
    10b5:	ff 00 00 
    10b8:	48 81 ca 00 00 40 08 	or     $0x8400000,%rdx
    10bf:	48 89 51 0c          	mov    %rdx,0xc(%rcx)
    10c3:	48 8b 97 a0 00 00 00 	mov    0xa0(%rdi),%rdx
    10ca:	8b 92 8c 3a 00 00    	mov    0x3a8c(%rdx),%edx
    10d0:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    10d5:	48 89 77 60          	mov    %rsi,0x60(%rdi)
    10d9:	4c 89 7f 40          	mov    %r15,0x40(%rdi)
    10dd:	48 c7 41 04 00 00 00 	movq   $0x0,0x4(%rcx)
    10e4:	00 
    10e5:	4c 8b 4f 78          	mov    0x78(%rdi),%r9
    10e9:	4c 89 49 1c          	mov    %r9,0x1c(%rcx)
    10ed:	41 89 d2             	mov    %edx,%r10d
    10f0:	41 c1 e2 0d          	shl    $0xd,%r10d
    10f4:	41 81 e2 00 00 00 40 	and    $0x40000000,%r10d
    10fb:	49 81 f2 00 00 00 40 	xor    $0x40000000,%r10
    1102:	4c 89 97 10 01 00 00 	mov    %r10,0x110(%rdi)
    1109:	48 c7 47 68 01 00 00 	movq   $0x1,0x68(%rdi)
    1110:	00 
    1111:	c7 41 34 00 00 00 00 	movl   $0x0,0x34(%rcx)
    1118:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    111f:	00 
    1120:	48 c7 41 24 01 00 00 	movq   $0x1,0x24(%rcx)
    1127:	00 
    1128:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    112c:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    1133:	00 00 00 
    1136:	44 89 49 2c          	mov    %r9d,0x2c(%rcx)
    113a:	c7 41 30 01 00 00 00 	movl   $0x1,0x30(%rcx)
    1141:	c1 ea 08             	shr    $0x8,%edx
    1144:	81 e2 00 02 00 00    	and    $0x200,%edx
    114a:	81 ca 00 00 00 40    	or     $0x40000000,%edx
    1150:	89 11                	mov    %edx,(%rcx)
    1152:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    1159:	00 00 00 
    115c:	48 05 f0 85 00 00    	add    $0x85f0,%rax
    1162:	48 89 47 70          	mov    %rax,0x70(%rdi)
    1166:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
    116d:	00 80 3f 
    1170:	48 89 51 38          	mov    %rdx,0x38(%rcx)
    1174:	48 89 51 40          	mov    %rdx,0x40(%rcx)
    1178:	48 8b 97 c0 00 00 00 	mov    0xc0(%rdi),%rdx
    117f:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    1184:	4c 89 8a a4 00 00 00 	mov    %r9,0xa4(%rdx)
    118b:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
    1192:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    1199:	48 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rdx
    11a0:	ff 7f 7f 
    11a3:	48 89 51 78          	mov    %rdx,0x78(%rcx)
    11a7:	4c 89 81 80 00 00 00 	mov    %r8,0x80(%rcx)
    11ae:	48 89 b1 88 00 00 00 	mov    %rsi,0x88(%rcx)
    11b5:	48 89 91 90 00 00 00 	mov    %rdx,0x90(%rcx)
    11bc:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    11c0:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    11c5:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    11cc:	00 
    11cd:	48 89 41 70          	mov    %rax,0x70(%rcx)
    11d1:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    11d8:	00 
    11d9:	4c 89 79 50          	mov    %r15,0x50(%rcx)
    11dd:	4c 8b 5f 48          	mov    0x48(%rdi),%r11
    11e1:	4c 8b af d0 00 00 00 	mov    0xd0(%rdi),%r13
    11e8:	e9 bd 19 00 00       	jmp    2baa <f_8001161d0+0x2baa>
    11ed:	81 f9 ad 03 00 00    	cmp    $0x3ad,%ecx
    11f3:	0f 84 91 1d 00 00    	je     2f8a <f_8001161d0+0x2f8a>
    11f9:	81 f9 12 04 00 00    	cmp    $0x412,%ecx
    11ff:	0f 85 a2 0a 00 00    	jne    1ca7 <f_8001161d0+0x1ca7>
    1205:	48 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%rcx
    120c:	48 8b 89 c8 1e 00 00 	mov    0x1ec8(%rcx),%rcx
    1213:	48 89 4f 70          	mov    %rcx,0x70(%rdi)
    1217:	48 bb 00 00 00 00 01 	movabs $0x100000000,%rbx
    121e:	00 00 00 
    1221:	48 89 1f             	mov    %rbx,(%rdi)
    1224:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1228:	4c 8b 8f 00 01 00 00 	mov    0x100(%rdi),%r9
    122f:	49 c7 01 02 00 00 00 	movq   $0x2,(%r9)
    1236:	48 ba 00 00 00 00 00 	movabs $0x40000000000000,%rdx
    123d:	00 40 00 
    1240:	48 ff c2             	inc    %rdx
    1243:	49 89 51 08          	mov    %rdx,0x8(%r9)
    1247:	49 89 59 20          	mov    %rbx,0x20(%r9)
    124b:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    1252:	ff ff ff 
    1255:	49 89 69 28          	mov    %rbp,0x28(%r9)
    1259:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1260:	00 00 00 
    1263:	4c 89 6f 68          	mov    %r13,0x68(%rdi)
    1267:	4d 89 81 80 00 00 00 	mov    %r8,0x80(%r9)
    126e:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    1273:	49 89 91 88 00 00 00 	mov    %rdx,0x88(%r9)
    127a:	48 8b 97 c0 00 00 00 	mov    0xc0(%rdi),%rdx
    1281:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    1286:	4c 89 9a a4 00 00 00 	mov    %r11,0xa4(%rdx)
    128d:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
    1294:	ff 7f 7f 
    1297:	4d 89 99 90 00 00 00 	mov    %r11,0x90(%r9)
    129e:	4d 89 81 98 00 00 00 	mov    %r8,0x98(%r9)
    12a5:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 12ad <f_8001161d0+0x12ad>
    12ac:	00 
    12ad:	c5 fc 11 47 78       	vmovups %ymm0,0x78(%rdi)
    12b2:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    12b9:	00 
    12ba:	45 89 91 a0 00 00 00 	mov    %r10d,0xa0(%r9)
    12c1:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    12c8:	0f b6 50 08          	movzbl 0x8(%rax),%edx
    12cc:	48 89 57 40          	mov    %rdx,0x40(%rdi)
    12d0:	41 c7 81 bc 00 00 00 	movl   $0x3,0xbc(%r9)
    12d7:	03 00 00 00 
    12db:	49 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%r9)
    12e2:	00 
    12e3:	48 8d 45 16          	lea    0x16(%rbp),%rax
    12e7:	49 89 41 18          	mov    %rax,0x18(%r9)
    12eb:	49 c7 41 68 00 00 00 	movq   $0x0,0x68(%r9)
    12f2:	00 
    12f3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    12f8:	49 89 41 30          	mov    %rax,0x30(%r9)
    12fc:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    1303:	00 80 3f 
    1306:	49 89 41 38          	mov    %rax,0x38(%r9)
    130a:	49 89 41 40          	mov    %rax,0x40(%r9)
    130e:	49 c7 41 48 00 00 00 	movq   $0x0,0x48(%r9)
    1315:	00 
    1316:	4d 89 79 50          	mov    %r15,0x50(%r9)
    131a:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    131e:	c4 c1 78 11 41 58    	vmovups %xmm0,0x58(%r9)
    1324:	4d 89 69 70          	mov    %r13,0x70(%r9)
    1328:	4d 89 59 78          	mov    %r11,0x78(%r9)
    132c:	48 69 c2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rax
    1333:	45 31 c0             	xor    %r8d,%r8d
    1336:	39 51 08             	cmp    %edx,0x8(%rcx)
    1339:	49 0f 46 c0          	cmovbe %r8,%rax
    133d:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    1341:	48 8b b4 08 b8 30 00 	mov    0x30b8(%rax,%rcx,1),%rsi
    1348:	00 
    1349:	48 89 77 60          	mov    %rsi,0x60(%rdi)
    134d:	48 8b 84 08 b0 30 00 	mov    0x30b0(%rax,%rcx,1),%rax
    1354:	00 
    1355:	48 8b 4f 48          	mov    0x48(%rdi),%rcx
    1359:	48 89 01             	mov    %rax,(%rcx)
    135c:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    1360:	48 8b 47 70          	mov    0x70(%rdi),%rax
    1364:	44 8b 48 08          	mov    0x8(%rax),%r9d
    1368:	4c 89 4f 48          	mov    %r9,0x48(%rdi)
    136c:	48 8b 48 10          	mov    0x10(%rax),%rcx
    1370:	48 89 4f 58          	mov    %rcx,0x58(%rdi)
    1374:	8b 77 40             	mov    0x40(%rdi),%esi
    1377:	48 69 f6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rsi
    137e:	45 31 db             	xor    %r11d,%r11d
    1381:	45 31 d2             	xor    %r10d,%r10d
    1384:	44 89 cb             	mov    %r9d,%ebx
    1387:	29 d3                	sub    %edx,%ebx
    1389:	49 0f 46 f0          	cmovbe %r8,%rsi
    138d:	41 0f 94 c3          	sete   %r11b
    1391:	41 0f 93 c2          	setae  %r10b
    1395:	41 c1 e3 1e          	shl    $0x1e,%r11d
    1399:	41 c1 e2 1d          	shl    $0x1d,%r10d
    139d:	45 09 da             	or     %r11d,%r10d
    13a0:	c4 c2 60 f2 d1       	andn   %r9d,%ebx,%edx
    13a5:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    13ab:	41 09 da             	or     %ebx,%r10d
    13ae:	c1 ea 03             	shr    $0x3,%edx
    13b1:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    13b7:	44 09 d2             	or     %r10d,%edx
    13ba:	48 89 97 10 01 00 00 	mov    %rdx,0x110(%rdi)
    13c1:	48 8b 94 0e 30 33 00 	mov    0x3330(%rsi,%rcx,1),%rdx
    13c8:	00 
    13c9:	4c 8b 84 0e 38 33 00 	mov    0x3338(%rsi,%rcx,1),%r8
    13d0:	00 
    13d1:	48 89 57 50          	mov    %rdx,0x50(%rdi)
    13d5:	4c 8b 8f d0 00 00 00 	mov    0xd0(%rdi),%r9
    13dc:	49 89 11             	mov    %rdx,(%r9)
    13df:	4d 89 41 08          	mov    %r8,0x8(%r9)
    13e3:	8b 94 0e 48 33 00 00 	mov    0x3348(%rsi,%rcx,1),%edx
    13ea:	48 8b 8c 0e 40 33 00 	mov    0x3340(%rsi,%rcx,1),%rcx
    13f1:	00 
    13f2:	48 8b b7 c8 00 00 00 	mov    0xc8(%rdi),%rsi
    13f9:	48 89 0e             	mov    %rcx,(%rsi)
    13fc:	89 56 08             	mov    %edx,0x8(%rsi)
    13ff:	8b 48 44             	mov    0x44(%rax),%ecx
    1402:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    1406:	48 83 c0 30          	add    $0x30,%rax
    140a:	e9 79 0b 00 00       	jmp    1f88 <f_8001161d0+0x1f88>
    140f:	81 f9 1a 05 00 00    	cmp    $0x51a,%ecx
    1415:	0f 85 8c 08 00 00    	jne    1ca7 <f_8001161d0+0x1ca7>
    141b:	b8 e8 0a 00 00       	mov    $0xae8,%eax
    1420:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
    1427:	48 89 07             	mov    %rax,(%rdi)
    142a:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    1431:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    1438:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    143c:	48 89 47 10          	mov    %rax,0x10(%rdi)
    1440:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1447:	00 00 00 
    144a:	49 8d 85 ca 19 51 fd 	lea    -0x2aee636(%r13),%rax
    1451:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    1458:	48 89 fb             	mov    %rdi,%rbx
    145b:	c5 f8 77             	vzeroupper
    145e:	e8 00 00 00 00       	call   1463 <f_8001161d0+0x1463>
    1463:	48 89 df             	mov    %rbx,%rdi
    1466:	e9 5d 18 00 00       	jmp    2cc8 <f_8001161d0+0x2cc8>
    146b:	83 f9 61             	cmp    $0x61,%ecx
    146e:	0f 85 33 08 00 00    	jne    1ca7 <f_8001161d0+0x1ca7>
    1474:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    147b:	00 
    147c:	48 c7 80 d0 fe ff ff 	movq   $0x8,-0x130(%rax)
    1483:	08 00 00 00 
    1487:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    148e:	00 40 00 
    1491:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    1498:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    149f:	ff ff 00 00 
    14a3:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    14aa:	ff ff ff 
    14ad:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    14b1:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    14b8:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    14bf:	00 00 00 
    14c2:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
    14c6:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    14cd:	48 89 90 f8 fe ff ff 	mov    %rdx,-0x108(%rax)
    14d4:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    14db:	00 80 3f 
    14de:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    14e2:	48 8d 88 00 ff ff ff 	lea    -0x100(%rax),%rcx
    14e9:	48 8d 98 08 ff ff ff 	lea    -0xf8(%rax),%rbx
    14f0:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
    14f7:	00 00 00 
    14fa:	4c 8d 8a ab f2 0c 00 	lea    0xcf2ab(%rdx),%r9
    1501:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    1507:	e9 ed 15 00 00       	jmp    2af9 <f_8001161d0+0x2af9>
    150c:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1513:	00 00 00 
    1516:	4d 8d b5 0b d1 09 00 	lea    0x9d10b(%r13),%r14
    151d:	eb 24                	jmp    1543 <f_8001161d0+0x1543>
    151f:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1526:	00 00 00 
    1529:	4d 8d b5 2d 8c 01 00 	lea    0x18c2d(%r13),%r14
    1530:	eb 11                	jmp    1543 <f_8001161d0+0x1543>
    1532:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1539:	00 00 00 
    153c:	4d 8d b5 4b 4f 0a 00 	lea    0xa4f4b(%r13),%r14
    1543:	4c 89 77 68          	mov    %r14,0x68(%rdi)
    1547:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    154e:	c7 03 00 00 00 10    	movl   $0x10000000,(%rbx)
    1554:	4c 8b bf a0 00 00 00 	mov    0xa0(%rdi),%r15
    155b:	49 8b 8f f0 31 00 00 	mov    0x31f0(%r15),%rcx
    1562:	48 89 0f             	mov    %rcx,(%rdi)
    1565:	48 ba 10 00 00 00 03 	movabs $0x300000010,%rdx
    156c:	00 00 00 
    156f:	4c 8d 4a f0          	lea    -0x10(%rdx),%r9
    1573:	4c 89 4b 14          	mov    %r9,0x14(%rbx)
    1577:	48 c7 47 78 01 00 00 	movq   $0x1,0x78(%rdi)
    157e:	00 
    157f:	48 83 c2 f6          	add    $0xfffffffffffffff6,%rdx
    1583:	48 89 53 04          	mov    %rdx,0x4(%rbx)
    1587:	48 8b 57 70          	mov    0x70(%rdi),%rdx
    158b:	48 89 53 2c          	mov    %rdx,0x2c(%rbx)
    158f:	48 ba 00 00 00 00 ff 	movabs $0xffff00000000,%rdx
    1596:	ff 00 00 
    1599:	48 89 53 0c          	mov    %rdx,0xc(%rbx)
    159d:	4c 89 47 70          	mov    %r8,0x70(%rdi)
    15a1:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    15a6:	48 89 53 1c          	mov    %rdx,0x1c(%rbx)
    15aa:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
    15af:	4c 89 5f 60          	mov    %r11,0x60(%rdi)
    15b3:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
    15ba:	00 80 3f 
    15bd:	48 89 53 38          	mov    %rdx,0x38(%rbx)
    15c1:	48 89 53 40          	mov    %rdx,0x40(%rbx)
    15c5:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    15ca:	4c 89 67 48          	mov    %r12,0x48(%rdi)
    15ce:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    15d2:	48 c7 43 24 01 00 00 	movq   $0x1,0x24(%rbx)
    15d9:	00 
    15da:	c7 43 34 00 00 00 00 	movl   $0x0,0x34(%rbx)
    15e1:	4c 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%r9
    15e8:	4d 89 a1 a4 00 00 00 	mov    %r12,0xa4(%r9)
    15ef:	4c 89 83 98 00 00 00 	mov    %r8,0x98(%rbx)
    15f6:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    15fa:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1601:	00 
    1602:	44 89 93 a0 00 00 00 	mov    %r10d,0xa0(%rbx)
    1609:	c7 83 bc 00 00 00 01 	movl   $0x1,0xbc(%rbx)
    1610:	00 00 00 
    1613:	48 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rax
    161a:	ff 7f 7f 
    161d:	48 89 43 78          	mov    %rax,0x78(%rbx)
    1621:	4c 89 83 80 00 00 00 	mov    %r8,0x80(%rbx)
    1628:	4c 89 9b 88 00 00 00 	mov    %r11,0x88(%rbx)
    162f:	48 89 83 90 00 00 00 	mov    %rax,0x90(%rbx)
    1636:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    163a:	c5 f8 11 43 58       	vmovups %xmm0,0x58(%rbx)
    163f:	48 c7 43 68 00 00 00 	movq   $0x0,0x68(%rbx)
    1646:	00 
    1647:	4c 89 73 70          	mov    %r14,0x70(%rbx)
    164b:	48 c7 43 48 00 00 00 	movq   $0x0,0x48(%rbx)
    1652:	00 
    1653:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    1657:	48 85 c9             	test   %rcx,%rcx
    165a:	0f 84 68 16 00 00    	je     2cc8 <f_8001161d0+0x2cc8>
    1660:	49 8b 87 c8 1e 00 00 	mov    0x1ec8(%r15),%rax
    1667:	48 8b 97 98 00 00 00 	mov    0x98(%rdi),%rdx
    166e:	0f b6 52 08          	movzbl 0x8(%rdx),%edx
    1672:	44 8b 40 08          	mov    0x8(%rax),%r8d
    1676:	48 8b 70 10          	mov    0x10(%rax),%rsi
    167a:	31 c0                	xor    %eax,%eax
    167c:	45 31 db             	xor    %r11d,%r11d
    167f:	31 ed                	xor    %ebp,%ebp
    1681:	45 89 c6             	mov    %r8d,%r14d
    1684:	41 29 d6             	sub    %edx,%r14d
    1687:	41 bf 00 00 00 00    	mov    $0x0,%r15d
    168d:	4c 0f 47 fa          	cmova  %rdx,%r15
    1691:	41 0f 94 c3          	sete   %r11b
    1695:	40 0f 93 c5          	setae  %bpl
    1699:	c4 c2 08 f2 d0       	andn   %r8d,%r14d,%edx
    169e:	41 81 e6 00 00 00 80 	and    $0x80000000,%r14d
    16a5:	41 c1 e3 1e          	shl    $0x1e,%r11d
    16a9:	c1 e5 1d             	shl    $0x1d,%ebp
    16ac:	44 09 dd             	or     %r11d,%ebp
    16af:	44 09 f5             	or     %r14d,%ebp
    16b2:	c1 ea 03             	shr    $0x3,%edx
    16b5:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    16bb:	09 ea                	or     %ebp,%edx
    16bd:	48 89 97 10 01 00 00 	mov    %rdx,0x110(%rdi)
    16c4:	48 c7 47 60 e0 3c 00 	movq   $0x3ce0,0x60(%rdi)
    16cb:	00 
    16cc:	4c 89 7f 58          	mov    %r15,0x58(%rdi)
    16d0:	49 69 d7 e0 3c 00 00 	imul   $0x3ce0,%r15,%rdx
    16d7:	4c 8d 04 32          	lea    (%rdx,%rsi,1),%r8
    16db:	4c 89 47 50          	mov    %r8,0x50(%rdi)
    16df:	4c 8d b7 10 02 00 00 	lea    0x210(%rdi),%r14
    16e6:	c5 fa 10 8c 32 08 2e 	vmovss 0x2e08(%rdx,%rsi,1),%xmm1
    16ed:	00 00 
    16ef:	c5 fa 10 94 32 0c 2e 	vmovss 0x2e0c(%rdx,%rsi,1),%xmm2
    16f6:	00 00 
    16f8:	c5 f2 5c 9c 32 00 2e 	vsubss 0x2e00(%rdx,%rsi,1),%xmm1,%xmm3
    16ff:	00 00 
    1701:	c5 ea 5c 8c 32 04 2e 	vsubss 0x2e04(%rdx,%rsi,1),%xmm2,%xmm1
    1708:	00 00 
    170a:	4c 8d bf 20 02 00 00 	lea    0x220(%rdi),%r15
    1711:	44 89 93 a0 00 00 00 	mov    %r10d,0xa0(%rbx)
    1718:	48 8b 97 e8 00 00 00 	mov    0xe8(%rdi),%rdx
    171f:	48 83 c2 f7          	add    $0xfffffffffffffff7,%rdx
    1723:	c4 e1 fa 2c f3       	vcvttss2si %xmm3,%rsi
    1728:	c5 e8 57 d2          	vxorps %xmm2,%xmm2,%xmm2
    172c:	c5 f8 2e da          	vucomiss %xmm2,%xmm3
    1730:	0f 42 f0             	cmovb  %eax,%esi
    1733:	c5 fa 10 25 00 00 00 	vmovss 0x0(%rip),%xmm4        # 173b <f_8001161d0+0x173b>
    173a:	00 
    173b:	c5 f8 2e dc          	vucomiss %xmm4,%xmm3
    173f:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    1745:	41 0f 47 f0          	cmova  %r8d,%esi
    1749:	48 89 57 40          	mov    %rdx,0x40(%rdi)
    174d:	c4 e1 82 2a de       	vcvtsi2ss %rsi,%xmm15,%xmm3
    1752:	4d 89 a1 a4 00 00 00 	mov    %r12,0xa4(%r9)
    1759:	8b 91 0c 03 00 00    	mov    0x30c(%rcx),%edx
    175f:	c5 e2 59 99 08 03 00 	vmulss 0x308(%rcx),%xmm3,%xmm3
    1766:	00 
    1767:	48 89 97 30 02 00 00 	mov    %rdx,0x230(%rdi)
    176e:	48 c7 87 38 02 00 00 	movq   $0x0,0x238(%rdi)
    1775:	00 00 00 00 
    1779:	c4 e1 fa 2c c9       	vcvttss2si %xmm1,%rcx
    177e:	c5 f8 2e ca          	vucomiss %xmm2,%xmm1
    1782:	0f 42 c8             	cmovb  %eax,%ecx
    1785:	c5 f8 2e cc          	vucomiss %xmm4,%xmm1
    1789:	41 0f 47 c8          	cmova  %r8d,%ecx
    178d:	c5 f9 7e d8          	vmovd  %xmm3,%eax
    1791:	48 89 87 00 02 00 00 	mov    %rax,0x200(%rdi)
    1798:	c4 e1 82 2a c9       	vcvtsi2ss %rcx,%xmm15,%xmm1
    179d:	48 c7 87 08 02 00 00 	movq   $0x0,0x208(%rdi)
    17a4:	00 00 00 00 
    17a8:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    17ac:	c5 f2 59 ca          	vmulss %xmm2,%xmm1,%xmm1
    17b0:	c5 f9 7e c8          	vmovd  %xmm1,%eax
    17b4:	c5 f8 11 87 18 02 00 	vmovups %xmm0,0x218(%rdi)
    17bb:	00 
    17bc:	48 89 87 10 02 00 00 	mov    %rax,0x210(%rdi)
    17c3:	48 c7 87 28 02 00 00 	movq   $0x0,0x228(%rdi)
    17ca:	00 00 00 00 
    17ce:	48 89 fb             	mov    %rdi,%rbx
    17d1:	31 f6                	xor    %esi,%esi
    17d3:	31 d2                	xor    %edx,%edx
    17d5:	b9 01 00 00 00       	mov    $0x1,%ecx
    17da:	c5 f8 77             	vzeroupper
    17dd:	e8 00 00 00 00       	call   17e2 <f_8001161d0+0x17e2>
    17e2:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    17e9:	48 8b 8b 00 02 00 00 	mov    0x200(%rbx),%rcx
    17f0:	48 8b 93 20 02 00 00 	mov    0x220(%rbx),%rdx
    17f7:	c5 f9 6e c1          	vmovd  %ecx,%xmm0
    17fb:	c4 e3 79 22 83 10 02 	vpinsrd $0x1,0x210(%rbx),%xmm0,%xmm0
    1802:	00 00 01 
    1805:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    1809:	c4 e2 79 58 c9       	vpbroadcastd %xmm1,%xmm1
    180e:	c5 f0 5f d0          	vmaxps %xmm0,%xmm1,%xmm2
    1812:	c5 f8 c2 c0 03       	vcmpunordps %xmm0,%xmm0,%xmm0
    1817:	c4 e3 69 4a c1 00    	vblendvps %xmm0,%xmm1,%xmm2,%xmm0
    181d:	c4 e3 79 17 c6 00    	vextractps $0x0,%xmm0,%esi
    1823:	c4 e3 79 17 c7 01    	vextractps $0x1,%xmm0,%edi
    1829:	48 89 bb 40 02 00 00 	mov    %rdi,0x240(%rbx)
    1830:	48 89 b3 30 02 00 00 	mov    %rsi,0x230(%rbx)
    1837:	48 c7 83 48 02 00 00 	movq   $0x0,0x248(%rbx)
    183e:	00 00 00 00 
    1842:	a9 00 00 00 40       	test   $0x40000000,%eax
    1847:	40 0f 94 c6          	sete   %sil
    184b:	85 c0                	test   %eax,%eax
    184d:	40 0f 98 c7          	sets   %dil
    1851:	a9 00 00 00 10       	test   $0x10000000,%eax
    1856:	0f 94 c0             	sete   %al
    1859:	40 30 f8             	xor    %dil,%al
    185c:	40 84 c6             	test   %al,%sil
    185f:	48 0f 45 ca          	cmovne %rdx,%rcx
    1863:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    186a:	00 00 00 00 
    186e:	89 c8                	mov    %ecx,%eax
    1870:	48 89 83 00 02 00 00 	mov    %rax,0x200(%rbx)
    1877:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    187e:	00 00 00 00 
    1882:	48 89 df             	mov    %rbx,%rdi
    1885:	be 01 00 00 00       	mov    $0x1,%esi
    188a:	31 d2                	xor    %edx,%edx
    188c:	b9 01 00 00 00       	mov    $0x1,%ecx
    1891:	e8 00 00 00 00       	call   1896 <f_8001161d0+0x1896>
    1896:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    189d:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    18a4:	8b 93 30 02 00 00    	mov    0x230(%rbx),%edx
    18aa:	85 c0                	test   %eax,%eax
    18ac:	40 0f 98 c6          	sets   %sil
    18b0:	a9 00 00 00 10       	test   $0x10000000,%eax
    18b5:	40 0f 94 c7          	sete   %dil
    18b9:	40 30 f7             	xor    %sil,%dil
    18bc:	8b b3 40 02 00 00    	mov    0x240(%rbx),%esi
    18c2:	89 91 80 00 00 00    	mov    %edx,0x80(%rcx)
    18c8:	89 b1 84 00 00 00    	mov    %esi,0x84(%rcx)
    18ce:	4d 0f 44 fe          	cmove  %r14,%r15
    18d2:	89 91 98 00 00 00    	mov    %edx,0x98(%rcx)
    18d8:	a9 00 00 00 40       	test   $0x40000000,%eax
    18dd:	4d 0f 45 fe          	cmovne %r14,%r15
    18e1:	89 b1 9c 00 00 00    	mov    %esi,0x9c(%rcx)
    18e7:	49 8b 07             	mov    (%r15),%rax
    18ea:	89 c2                	mov    %eax,%edx
    18ec:	48 89 93 10 02 00 00 	mov    %rdx,0x210(%rbx)
    18f3:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    18fa:	00 00 00 00 
    18fe:	8b 93 00 02 00 00    	mov    0x200(%rbx),%edx
    1904:	89 51 78             	mov    %edx,0x78(%rcx)
    1907:	89 41 7c             	mov    %eax,0x7c(%rcx)
    190a:	89 91 90 00 00 00    	mov    %edx,0x90(%rcx)
    1910:	89 81 94 00 00 00    	mov    %eax,0x94(%rcx)
    1916:	49 8d 85 5e 18 51 fd 	lea    -0x2aee7a2(%r13),%rax
    191d:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    1924:	48 89 df             	mov    %rbx,%rdi
    1927:	e8 00 00 00 00       	call   192c <f_8001161d0+0x192c>
    192c:	48 89 df             	mov    %rbx,%rdi
    192f:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    1936:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    193d:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    1944:	48 89 01             	mov    %rax,(%rcx)
    1947:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    194e:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    1952:	48 89 43 40          	mov    %rax,0x40(%rbx)
    1956:	88 41 08             	mov    %al,0x8(%rcx)
    1959:	e9 6a 13 00 00       	jmp    2cc8 <f_8001161d0+0x2cc8>
    195e:	48 8b 4f 78          	mov    0x78(%rdi),%rcx
    1962:	4d 89 cf             	mov    %r9,%r15
    1965:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
    196c:	00 00 00 00 
    1970:	4c 89 b8 20 ff ff ff 	mov    %r15,-0xe0(%rax)
    1977:	4c 8b bf a0 00 00 00 	mov    0xa0(%rdi),%r15
    197e:	8b b7 a8 00 00 00    	mov    0xa8(%rdi),%esi
    1984:	44 8d 4e 08          	lea    0x8(%rsi),%r9d
    1988:	4c 8b 87 00 01 00 00 	mov    0x100(%rdi),%r8
    198f:	c4 c2 73 f7 af fc 0d 	shrx   %ecx,0xdfc(%r15),%ebp
    1996:	00 00 
    1998:	45 89 48 30          	mov    %r9d,0x30(%r8)
    199c:	4c 8b 67 68          	mov    0x68(%rdi),%r12
    19a0:	45 89 60 34          	mov    %r12d,0x34(%r8)
    19a4:	45 31 ed             	xor    %r13d,%r13d
    19a7:	f7 c3 00 02 00 00    	test   $0x200,%ebx
    19ad:	41 0f 94 c5          	sete   %r13b
    19b1:	45 8b 8f 20 0d 00 00 	mov    0xd20(%r15),%r9d
    19b8:	45 31 f6             	xor    %r14d,%r14d
    19bb:	41 39 c9             	cmp    %ecx,%r9d
    19be:	49 0f 46 ce          	cmovbe %r14,%rcx
    19c2:	41 89 c9             	mov    %ecx,%r9d
    19c5:	4d 69 c9 b0 0b 00 00 	imul   $0xbb0,%r9,%r9
    19cc:	31 d2                	xor    %edx,%edx
    19ce:	f7 c3 00 40 00 00    	test   $0x4000,%ebx
    19d4:	0f 94 c2             	sete   %dl
    19d7:	c1 e3 06             	shl    $0x6,%ebx
    19da:	81 e3 00 00 04 00    	and    $0x40000,%ebx
    19e0:	c1 e2 04             	shl    $0x4,%edx
    19e3:	41 85 ed             	test   %ebp,%r13d
    19e6:	bd 01 00 00 00       	mov    $0x1,%ebp
    19eb:	c4 62 19 f7 e5       	shlx   %r12d,%ebp,%r12d
    19f0:	48 c7 47 48 01 00 00 	movq   $0x1,0x48(%rdi)
    19f7:	00 
    19f8:	4c 89 67 08          	mov    %r12,0x8(%rdi)
    19fc:	4d 8b bf 28 0d 00 00 	mov    0xd28(%r15),%r15
    1a03:	4c 89 7f 70          	mov    %r15,0x70(%rdi)
    1a07:	48 89 4f 78          	mov    %rcx,0x78(%rdi)
    1a0b:	8d 8c 1a 00 00 20 00 	lea    0x200000(%rdx,%rbx,1),%ecx
    1a12:	ba 0f 00 00 00       	mov    $0xf,%edx
    1a17:	41 0f 45 d4          	cmovne %r12d,%edx
    1a1b:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1a22:	00 
    1a23:	48 c7 07 08 00 00 00 	movq   $0x8,(%rdi)
    1a2a:	41 89 10             	mov    %edx,(%r8)
    1a2d:	41 c7 40 04 08 00 00 	movl   $0x8,0x4(%r8)
    1a34:	00 
    1a35:	83 c6 04             	add    $0x4,%esi
    1a38:	41 89 70 08          	mov    %esi,0x8(%r8)
    1a3c:	41 89 48 0c          	mov    %ecx,0xc(%r8)
    1a40:	49 c7 40 10 ff ff 00 	movq   $0xffff,0x10(%r8)
    1a47:	00 
    1a48:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    1a4f:	ff ff ff 
    1a52:	48 8d 4d 02          	lea    0x2(%rbp),%rcx
    1a56:	49 89 48 18          	mov    %rcx,0x18(%r8)
    1a5a:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    1a5f:	4c 89 a7 90 00 00 00 	mov    %r12,0x90(%rdi)
    1a66:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    1a6d:	00 00 00 
    1a70:	49 89 48 20          	mov    %rcx,0x20(%r8)
    1a74:	49 89 68 28          	mov    %rbp,0x28(%r8)
    1a78:	48 b9 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rcx
    1a7f:	00 80 3f 
    1a82:	49 89 48 38          	mov    %rcx,0x38(%r8)
    1a86:	49 89 48 40          	mov    %rcx,0x40(%r8)
    1a8a:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1a91:	00 00 00 
    1a94:	49 8d 95 b1 e5 0b 00 	lea    0xbe5b1(%r13),%rdx
    1a9b:	48 89 97 80 00 00 00 	mov    %rdx,0x80(%rdi)
    1aa2:	48 bb ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rbx
    1aa9:	ff 7f ff 
    1aac:	48 89 9f 88 00 00 00 	mov    %rbx,0x88(%rdi)
    1ab3:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
    1aba:	4c 89 a1 a4 00 00 00 	mov    %r12,0xa4(%rcx)
    1ac1:	48 8b 77 58          	mov    0x58(%rdi),%rsi
    1ac5:	49 89 70 78          	mov    %rsi,0x78(%r8)
    1ac9:	49 89 98 80 00 00 00 	mov    %rbx,0x80(%r8)
    1ad0:	49 89 98 98 00 00 00 	mov    %rbx,0x98(%r8)
    1ad7:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
    1adc:	4d 89 98 88 00 00 00 	mov    %r11,0x88(%r8)
    1ae3:	49 89 b0 90 00 00 00 	mov    %rsi,0x90(%r8)
    1aea:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1aee:	45 89 90 a0 00 00 00 	mov    %r10d,0xa0(%r8)
    1af5:	41 c7 80 bc 00 00 00 	movl   $0x0,0xbc(%r8)
    1afc:	00 00 00 00 
    1b00:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1b04:	c4 c1 78 11 40 58    	vmovups %xmm0,0x58(%r8)
    1b0a:	49 c7 40 68 00 00 00 	movq   $0x0,0x68(%r8)
    1b11:	00 
    1b12:	49 89 50 70          	mov    %rdx,0x70(%r8)
    1b16:	43 8b 84 0f d8 03 00 	mov    0x3d8(%r15,%r9,1),%eax
    1b1d:	00 
    1b1e:	89 c2                	mov    %eax,%edx
    1b20:	c1 fa 1f             	sar    $0x1f,%edx
    1b23:	c4 e2 68 f2 d0       	andn   %eax,%edx,%edx
    1b28:	85 c0                	test   %eax,%eax
    1b2a:	41 0f 49 c6          	cmovns %r14d,%eax
    1b2e:	c5 82 2a c0          	vcvtsi2ss %eax,%xmm15,%xmm0
    1b32:	43 8b 84 0f f8 03 00 	mov    0x3f8(%r15,%r9,1),%eax
    1b39:	00 
    1b3a:	89 c6                	mov    %eax,%esi
    1b3c:	c1 fe 1f             	sar    $0x1f,%esi
    1b3f:	c4 e2 48 f2 f0       	andn   %eax,%esi,%esi
    1b44:	85 c0                	test   %eax,%eax
    1b46:	c5 82 2a ce          	vcvtsi2ss %esi,%xmm15,%xmm1
    1b4a:	41 0f 49 c6          	cmovns %r14d,%eax
    1b4e:	c5 82 2a d2          	vcvtsi2ss %edx,%xmm15,%xmm2
    1b52:	c4 c1 7a 11 90 80 00 	vmovss %xmm2,0x80(%r8)
    1b59:	00 00 
    1b5b:	c4 c1 7a 11 88 84 00 	vmovss %xmm1,0x84(%r8)
    1b62:	00 00 
    1b64:	c5 82 2a c8          	vcvtsi2ss %eax,%xmm15,%xmm1
    1b68:	c4 c1 7a 11 40 78    	vmovss %xmm0,0x78(%r8)
    1b6e:	c4 c1 7a 11 48 7c    	vmovss %xmm1,0x7c(%r8)
    1b74:	43 8b 94 0f d8 03 00 	mov    0x3d8(%r15,%r9,1),%edx
    1b7b:	00 
    1b7c:	43 8b 84 0f f8 03 00 	mov    0x3f8(%r15,%r9,1),%eax
    1b83:	00 
    1b84:	48 89 47 60          	mov    %rax,0x60(%rdi)
    1b88:	8b 77 40             	mov    0x40(%rdi),%esi
    1b8b:	41 89 b0 a0 00 00 00 	mov    %esi,0xa0(%r8)
    1b92:	89 d6                	mov    %edx,%esi
    1b94:	c1 fe 1f             	sar    $0x1f,%esi
    1b97:	c4 e2 48 f2 f2       	andn   %edx,%esi,%esi
    1b9c:	85 d2                	test   %edx,%edx
    1b9e:	41 0f 49 d6          	cmovns %r14d,%edx
    1ba2:	c5 82 2a c2          	vcvtsi2ss %edx,%xmm15,%xmm0
    1ba6:	4c 89 a1 a4 00 00 00 	mov    %r12,0xa4(%rcx)
    1bad:	85 c0                	test   %eax,%eax
    1baf:	44 0f 4f f0          	cmovg  %eax,%r14d
    1bb3:	c5 82 2a ce          	vcvtsi2ss %esi,%xmm15,%xmm1
    1bb7:	c4 e3 79 17 c1 00    	vextractps $0x0,%xmm0,%ecx
    1bbd:	48 89 77 68          	mov    %rsi,0x68(%rdi)
    1bc1:	48 89 8f 10 02 00 00 	mov    %rcx,0x210(%rdi)
    1bc8:	c4 e3 79 17 c9 00    	vextractps $0x0,%xmm1,%ecx
    1bce:	48 89 8f 00 02 00 00 	mov    %rcx,0x200(%rdi)
    1bd5:	c4 c1 02 2a d6       	vcvtsi2ss %r14d,%xmm15,%xmm2
    1bda:	89 c1                	mov    %eax,%ecx
    1bdc:	c1 f9 1f             	sar    $0x1f,%ecx
    1bdf:	21 c1                	and    %eax,%ecx
    1be1:	48 c7 87 18 02 00 00 	movq   $0x0,0x218(%rdi)
    1be8:	00 00 00 00 
    1bec:	48 c7 87 08 02 00 00 	movq   $0x0,0x208(%rdi)
    1bf3:	00 00 00 00 
    1bf7:	48 89 4f 58          	mov    %rcx,0x58(%rdi)
    1bfb:	c5 82 2a d9          	vcvtsi2ss %ecx,%xmm15,%xmm3
    1bff:	c4 e3 79 17 d8 00    	vextractps $0x0,%xmm3,%eax
    1c05:	48 89 87 30 02 00 00 	mov    %rax,0x230(%rdi)
    1c0c:	c4 e3 79 17 d0 00    	vextractps $0x0,%xmm2,%eax
    1c12:	48 89 87 20 02 00 00 	mov    %rax,0x220(%rdi)
    1c19:	48 c7 87 38 02 00 00 	movq   $0x0,0x238(%rdi)
    1c20:	00 00 00 00 
    1c24:	48 c7 87 28 02 00 00 	movq   $0x0,0x228(%rdi)
    1c2b:	00 00 00 00 
    1c2f:	c4 c1 7a 11 88 98 00 	vmovss %xmm1,0x98(%r8)
    1c36:	00 00 
    1c38:	c4 c1 7a 11 90 9c 00 	vmovss %xmm2,0x9c(%r8)
    1c3f:	00 00 
    1c41:	c4 c1 7a 11 80 90 00 	vmovss %xmm0,0x90(%r8)
    1c48:	00 00 
    1c4a:	c4 c1 7a 11 98 94 00 	vmovss %xmm3,0x94(%r8)
    1c51:	00 00 
    1c53:	31 c0                	xor    %eax,%eax
    1c55:	43 80 bc 0f 58 04 00 	cmpb   $0x0,0x458(%r15,%r9,1)
    1c5c:	00 00 
    1c5e:	48 c7 47 50 5b 00 00 	movq   $0x5b,0x50(%rdi)
    1c65:	00 
    1c66:	49 c7 80 b0 00 00 00 	movq   $0x0,0xb0(%r8)
    1c6d:	00 00 00 00 
    1c71:	41 c7 80 bc 00 00 00 	movl   $0x1,0xbc(%r8)
    1c78:	01 00 00 00 
    1c7c:	0f 94 c0             	sete   %al
    1c7f:	48 8d 0c 45 59 00 00 	lea    0x59(,%rax,2),%rcx
    1c86:	00 
    1c87:	c1 e0 1e             	shl    $0x1e,%eax
    1c8a:	48 0d 00 00 00 20    	or     $0x20000000,%rax
    1c90:	48 89 87 10 01 00 00 	mov    %rax,0x110(%rdi)
    1c97:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    1c9b:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    1ca2:	e9 1b 10 00 00       	jmp    2cc2 <f_8001161d0+0x2cc2>
    1ca7:	4c 89 a7 08 01 00 00 	mov    %r12,0x108(%rdi)
    1cae:	48 83 c4 28          	add    $0x28,%rsp
    1cb2:	5b                   	pop    %rbx
    1cb3:	41 5c                	pop    %r12
    1cb5:	41 5d                	pop    %r13
    1cb7:	41 5e                	pop    %r14
    1cb9:	41 5f                	pop    %r15
    1cbb:	5d                   	pop    %rbp
    1cbc:	c5 f8 77             	vzeroupper
    1cbf:	e9 00 00 00 00       	jmp    1cc4 <f_8001161d0+0x1cc4>
    1cc4:	48 c7 47 40 b0 1e 00 	movq   $0x1eb0,0x40(%rdi)
    1ccb:	00 
    1ccc:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    1cd3:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    1cda:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    1cde:	48 89 47 10          	mov    %rax,0x10(%rdi)
    1ce2:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1ce7:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
    1cee:	48 89 07             	mov    %rax,(%rdi)
    1cf1:	48 c7 47 18 00 00 00 	movq   $0x0,0x18(%rdi)
    1cf8:	00 
    1cf9:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1d00:	00 00 00 
    1d03:	49 8d 85 ae 18 51 fd 	lea    -0x2aee752(%r13),%rax
    1d0a:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    1d11:	48 89 fb             	mov    %rdi,%rbx
    1d14:	c5 f8 77             	vzeroupper
    1d17:	e8 00 00 00 00       	call   1d1c <f_8001161d0+0x1d1c>
    1d1c:	48 89 df             	mov    %rbx,%rdi
    1d1f:	e9 a4 0f 00 00       	jmp    2cc8 <f_8001161d0+0x2cc8>
    1d24:	48 c7 47 40 b0 1e 00 	movq   $0x1eb0,0x40(%rdi)
    1d2b:	00 
    1d2c:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    1d33:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    1d3a:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    1d3e:	48 89 47 10          	mov    %rax,0x10(%rdi)
    1d42:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1d47:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
    1d4e:	48 89 07             	mov    %rax,(%rdi)
    1d51:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1d58:	00 00 00 
    1d5b:	49 8d 85 ce 18 51 fd 	lea    -0x2aee732(%r13),%rax
    1d62:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    1d69:	48 89 fb             	mov    %rdi,%rbx
    1d6c:	c5 f8 77             	vzeroupper
    1d6f:	e8 00 00 00 00       	call   1d74 <f_8001161d0+0x1d74>
    1d74:	48 89 df             	mov    %rbx,%rdi
    1d77:	e9 4c 0f 00 00       	jmp    2cc8 <f_8001161d0+0x2cc8>
    1d7c:	48 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%rcx
    1d83:	48 8b 89 c8 1e 00 00 	mov    0x1ec8(%rcx),%rcx
    1d8a:	48 89 4f 70          	mov    %rcx,0x70(%rdi)
    1d8e:	49 b9 00 00 00 00 01 	movabs $0x100000000,%r9
    1d95:	00 00 00 
    1d98:	4c 89 0f             	mov    %r9,(%rdi)
    1d9b:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1d9f:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    1da6:	48 c7 03 04 00 00 00 	movq   $0x4,(%rbx)
    1dad:	48 ba 00 00 00 00 00 	movabs $0x40000000000000,%rdx
    1db4:	00 40 00 
    1db7:	48 ff c2             	inc    %rdx
    1dba:	48 89 53 08          	mov    %rdx,0x8(%rbx)
    1dbe:	4c 89 4b 20          	mov    %r9,0x20(%rbx)
    1dc2:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    1dc9:	ff ff ff 
    1dcc:	48 89 6b 28          	mov    %rbp,0x28(%rbx)
    1dd0:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1dd7:	00 00 00 
    1dda:	49 8d 95 25 74 0d 00 	lea    0xd7425(%r13),%rdx
    1de1:	48 89 57 68          	mov    %rdx,0x68(%rdi)
    1de5:	4c 89 83 80 00 00 00 	mov    %r8,0x80(%rbx)
    1dec:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    1df1:	4c 89 8b 88 00 00 00 	mov    %r9,0x88(%rbx)
    1df8:	4c 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%r9
    1dff:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    1e04:	4d 89 99 a4 00 00 00 	mov    %r11,0xa4(%r9)
    1e0b:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
    1e12:	ff 7f 7f 
    1e15:	4c 89 9b 90 00 00 00 	mov    %r11,0x90(%rbx)
    1e1c:	4c 89 83 98 00 00 00 	mov    %r8,0x98(%rbx)
    1e23:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 1e2b <f_8001161d0+0x1e2b>
    1e2a:	00 
    1e2b:	c5 fc 11 47 78       	vmovups %ymm0,0x78(%rdi)
    1e30:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1e37:	00 
    1e38:	44 89 93 a0 00 00 00 	mov    %r10d,0xa0(%rbx)
    1e3f:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    1e46:	44 0f b6 48 08       	movzbl 0x8(%rax),%r9d
    1e4b:	4c 89 4f 40          	mov    %r9,0x40(%rdi)
    1e4f:	c7 83 bc 00 00 00 03 	movl   $0x3,0xbc(%rbx)
    1e56:	00 00 00 
    1e59:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
    1e60:	00 
    1e61:	48 8d 45 17          	lea    0x17(%rbp),%rax
    1e65:	48 89 43 18          	mov    %rax,0x18(%rbx)
    1e69:	48 c7 43 68 00 00 00 	movq   $0x0,0x68(%rbx)
    1e70:	00 
    1e71:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    1e76:	48 89 43 30          	mov    %rax,0x30(%rbx)
    1e7a:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    1e81:	00 80 3f 
    1e84:	48 89 43 38          	mov    %rax,0x38(%rbx)
    1e88:	48 89 43 40          	mov    %rax,0x40(%rbx)
    1e8c:	48 c7 43 48 00 00 00 	movq   $0x0,0x48(%rbx)
    1e93:	00 
    1e94:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    1e98:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1e9c:	c5 f8 11 43 58       	vmovups %xmm0,0x58(%rbx)
    1ea1:	48 89 53 70          	mov    %rdx,0x70(%rbx)
    1ea5:	4c 89 5b 78          	mov    %r11,0x78(%rbx)
    1ea9:	49 69 c1 e0 3c 00 00 	imul   $0x3ce0,%r9,%rax
    1eb0:	45 31 c0             	xor    %r8d,%r8d
    1eb3:	44 39 49 08          	cmp    %r9d,0x8(%rcx)
    1eb7:	49 0f 46 c0          	cmovbe %r8,%rax
    1ebb:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    1ebf:	48 8b 94 08 68 33 00 	mov    0x3368(%rax,%rcx,1),%rdx
    1ec6:	00 
    1ec7:	48 89 57 60          	mov    %rdx,0x60(%rdi)
    1ecb:	48 8b 84 08 60 33 00 	mov    0x3360(%rax,%rcx,1),%rax
    1ed2:	00 
    1ed3:	48 8b 4f 48          	mov    0x48(%rdi),%rcx
    1ed7:	48 89 01             	mov    %rax,(%rcx)
    1eda:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    1ede:	48 8b 47 70          	mov    0x70(%rdi),%rax
    1ee2:	44 8b 50 08          	mov    0x8(%rax),%r10d
    1ee6:	48 8b 48 10          	mov    0x10(%rax),%rcx
    1eea:	48 89 4f 58          	mov    %rcx,0x58(%rdi)
    1eee:	8b 57 40             	mov    0x40(%rdi),%edx
    1ef1:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
    1ef8:	45 31 db             	xor    %r11d,%r11d
    1efb:	31 f6                	xor    %esi,%esi
    1efd:	44 89 d3             	mov    %r10d,%ebx
    1f00:	44 29 cb             	sub    %r9d,%ebx
    1f03:	49 0f 46 d0          	cmovbe %r8,%rdx
    1f07:	41 0f 94 c3          	sete   %r11b
    1f0b:	40 0f 93 c6          	setae  %sil
    1f0f:	41 c1 e3 1e          	shl    $0x1e,%r11d
    1f13:	c1 e6 1d             	shl    $0x1d,%esi
    1f16:	44 09 de             	or     %r11d,%esi
    1f19:	c4 42 60 f2 c2       	andn   %r10d,%ebx,%r8d
    1f1e:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    1f24:	09 de                	or     %ebx,%esi
    1f26:	41 c1 e8 03          	shr    $0x3,%r8d
    1f2a:	41 81 e0 00 00 00 10 	and    $0x10000000,%r8d
    1f31:	41 09 f0             	or     %esi,%r8d
    1f34:	4c 89 87 10 01 00 00 	mov    %r8,0x110(%rdi)
    1f3b:	48 8b b4 0a e8 35 00 	mov    0x35e8(%rdx,%rcx,1),%rsi
    1f42:	00 
    1f43:	48 89 77 48          	mov    %rsi,0x48(%rdi)
    1f47:	4c 8b 84 0a e0 35 00 	mov    0x35e0(%rdx,%rcx,1),%r8
    1f4e:	00 
    1f4f:	4c 89 47 50          	mov    %r8,0x50(%rdi)
    1f53:	4c 8b 8f d0 00 00 00 	mov    0xd0(%rdi),%r9
    1f5a:	4d 89 01             	mov    %r8,(%r9)
    1f5d:	49 89 71 08          	mov    %rsi,0x8(%r9)
    1f61:	8b b4 0a f8 35 00 00 	mov    0x35f8(%rdx,%rcx,1),%esi
    1f68:	48 8b 8c 0a f0 35 00 	mov    0x35f0(%rdx,%rcx,1),%rcx
    1f6f:	00 
    1f70:	48 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%rdx
    1f77:	48 89 0a             	mov    %rcx,(%rdx)
    1f7a:	89 72 08             	mov    %esi,0x8(%rdx)
    1f7d:	8b 48 44             	mov    0x44(%rax),%ecx
    1f80:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    1f84:	48 83 c0 3c          	add    $0x3c,%rax
    1f88:	8b 00                	mov    (%rax),%eax
    1f8a:	48 89 47 48          	mov    %rax,0x48(%rdi)
    1f8e:	48 8b 97 00 01 00 00 	mov    0x100(%rdi),%rdx
    1f95:	88 8a b0 00 00 00    	mov    %cl,0xb0(%rdx)
    1f9b:	c7 82 b4 00 00 00 00 	movl   $0x0,0xb4(%rdx)
    1fa2:	00 00 00 
    1fa5:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
    1fac:	c7 81 b1 00 00 00 00 	movl   $0x0,0xb1(%rcx)
    1fb3:	00 00 00 
    1fb6:	88 82 b8 00 00 00    	mov    %al,0xb8(%rdx)
    1fbc:	e9 07 0d 00 00       	jmp    2cc8 <f_8001161d0+0x2cc8>
    1fc1:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    1fc8:	00 
    1fc9:	48 c7 80 d0 fe ff ff 	movq   $0x100,-0x130(%rax)
    1fd0:	00 01 00 00 
    1fd4:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    1fdb:	00 40 00 
    1fde:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    1fe5:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    1fec:	ff ff 00 00 
    1ff0:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    1ff7:	ff ff ff 
    1ffa:	48 8d 4a 13          	lea    0x13(%rdx),%rcx
    1ffe:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    2005:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    200c:	00 00 00 
    200f:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
    2013:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    201a:	48 89 90 f8 fe ff ff 	mov    %rdx,-0x108(%rax)
    2021:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    2028:	00 80 3f 
    202b:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    202f:	48 8d 88 00 ff ff ff 	lea    -0x100(%rax),%rcx
    2036:	48 8d 98 08 ff ff ff 	lea    -0xf8(%rax),%rbx
    203d:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
    2044:	00 00 00 
    2047:	4c 8d 8a a1 6f fe ff 	lea    -0x1905f(%rdx),%r9
    204e:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    2054:	e9 a0 0a 00 00       	jmp    2af9 <f_8001161d0+0x2af9>
    2059:	4d 89 fc             	mov    %r15,%r12
    205c:	48 c7 47 68 00 10 00 	movq   $0x1000,0x68(%rdi)
    2063:	00 
    2064:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    206b:	00 
    206c:	48 c7 80 d0 fe ff ff 	movq   $0x1000,-0x130(%rax)
    2073:	00 10 00 00 
    2077:	48 c7 80 d8 fe ff ff 	movq   $0x1,-0x128(%rax)
    207e:	01 00 00 00 
    2082:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    2089:	ff ff 00 00 
    208d:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    2094:	ff ff ff 
    2097:	48 8d 4d 0c          	lea    0xc(%rbp),%rcx
    209b:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    20a2:	49 bf 00 00 00 00 01 	movabs $0x100000000,%r15
    20a9:	00 00 00 
    20ac:	4c 89 b8 f0 fe ff ff 	mov    %r15,-0x110(%rax)
    20b3:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
    20ba:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    20c1:	00 80 3f 
    20c4:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    20c8:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
    20cd:	48 89 88 00 ff ff ff 	mov    %rcx,-0x100(%rax)
    20d4:	4c 89 b0 08 ff ff ff 	mov    %r14,-0xf8(%rax)
    20db:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    20e2:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    20e9:	00 00 00 
    20ec:	49 8d 9d b2 a4 03 00 	lea    0x3a4b2(%r13),%rbx
    20f3:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
    20fa:	4c 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%r9
    2101:	4d 8b 91 d0 2f 00 00 	mov    0x2fd0(%r9),%r10
    2108:	4c 89 57 40          	mov    %r10,0x40(%rdi)
    210c:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    2111:	48 89 77 60          	mov    %rsi,0x60(%rdi)
    2115:	48 89 59 70          	mov    %rbx,0x70(%rcx)
    2119:	48 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rbx
    2120:	ff 7f 7f 
    2123:	48 89 59 78          	mov    %rbx,0x78(%rcx)
    2127:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    212b:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    212f:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2136:	00 
    2137:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    213e:	00 00 00 
    2141:	4c 89 81 80 00 00 00 	mov    %r8,0x80(%rcx)
    2148:	48 89 b1 88 00 00 00 	mov    %rsi,0x88(%rcx)
    214f:	48 8b 97 c0 00 00 00 	mov    0xc0(%rdi),%rdx
    2156:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    215b:	4c 89 9a a4 00 00 00 	mov    %r11,0xa4(%rdx)
    2162:	4c 89 71 40          	mov    %r14,0x40(%rcx)
    2166:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    216d:	00 
    216e:	48 89 99 90 00 00 00 	mov    %rbx,0x90(%rcx)
    2175:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    217c:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    2183:	00 
    2184:	4c 89 61 50          	mov    %r12,0x50(%rcx)
    2188:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    218c:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    2191:	4d 85 d2             	test   %r10,%r10
    2194:	0f 84 d2 0f 00 00    	je     316c <f_8001161d0+0x316c>
    219a:	48 8b 97 98 00 00 00 	mov    0x98(%rdi),%rdx
    21a1:	0f b6 72 08          	movzbl 0x8(%rdx),%esi
    21a5:	48 c7 47 68 e0 3c 00 	movq   $0x3ce0,0x68(%rdi)
    21ac:	00 
    21ad:	4c 69 c6 60 0f 00 00 	imul   $0xf60,%rsi,%r8
    21b4:	31 d2                	xor    %edx,%edx
    21b6:	41 39 72 10          	cmp    %esi,0x10(%r10)
    21ba:	4d 8b 52 18          	mov    0x18(%r10),%r10
    21be:	4c 0f 46 c2          	cmovbe %rdx,%r8
    21c2:	47 8b 84 10 9c 02 00 	mov    0x29c(%r8,%r10,1),%r8d
    21c9:	00 
    21ca:	4d 09 f8             	or     %r15,%r8
    21cd:	4c 89 41 1c          	mov    %r8,0x1c(%rcx)
    21d1:	c7 81 bc 00 00 00 02 	movl   $0x2,0xbc(%rcx)
    21d8:	00 00 00 
    21db:	49 8b 89 c8 1e 00 00 	mov    0x1ec8(%r9),%rcx
    21e2:	4c 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%r8
    21e9:	39 71 08             	cmp    %esi,0x8(%rcx)
    21ec:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    21f2:	4d 0f 47 c8          	cmova  %r8,%r9
    21f6:	4c 8b 51 10          	mov    0x10(%rcx),%r10
    21fa:	4f 8b 9c 0a b8 30 00 	mov    0x30b8(%r10,%r9,1),%r11
    2201:	00 
    2202:	4c 89 5f 60          	mov    %r11,0x60(%rdi)
    2206:	4f 8b 8c 0a b0 30 00 	mov    0x30b0(%r10,%r9,1),%r9
    220d:	00 
    220e:	4c 89 4f 58          	mov    %r9,0x58(%rdi)
    2212:	4c 89 88 48 ff ff ff 	mov    %r9,-0xb8(%rax)
    2219:	4c 89 98 50 ff ff ff 	mov    %r11,-0xb0(%rax)
    2220:	44 8b 49 08          	mov    0x8(%rcx),%r9d
    2224:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    2228:	45 31 d2             	xor    %r10d,%r10d
    222b:	45 31 db             	xor    %r11d,%r11d
    222e:	44 89 cb             	mov    %r9d,%ebx
    2231:	29 f3                	sub    %esi,%ebx
    2233:	49 0f 47 d0          	cmova  %r8,%rdx
    2237:	41 0f 94 c2          	sete   %r10b
    223b:	41 0f 93 c3          	setae  %r11b
    223f:	c4 c2 60 f2 f1       	andn   %r9d,%ebx,%esi
    2244:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    224a:	41 c1 e2 1e          	shl    $0x1e,%r10d
    224e:	41 c1 e3 1d          	shl    $0x1d,%r11d
    2252:	45 09 d3             	or     %r10d,%r11d
    2255:	41 09 db             	or     %ebx,%r11d
    2258:	c1 ee 03             	shr    $0x3,%esi
    225b:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    2261:	44 09 de             	or     %r11d,%esi
    2264:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    226b:	48 8d 34 0a          	lea    (%rdx,%rcx,1),%rsi
    226f:	48 89 77 40          	mov    %rsi,0x40(%rdi)
    2273:	48 8b b4 0a 30 33 00 	mov    0x3330(%rdx,%rcx,1),%rsi
    227a:	00 
    227b:	4c 8b 84 0a 38 33 00 	mov    0x3338(%rdx,%rcx,1),%r8
    2282:	00 
    2283:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    2287:	48 89 b0 60 ff ff ff 	mov    %rsi,-0xa0(%rax)
    228e:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
    2295:	8b b4 0a 48 33 00 00 	mov    0x3348(%rdx,%rcx,1),%esi
    229c:	48 89 77 48          	mov    %rsi,0x48(%rdi)
    22a0:	48 8b 8c 0a 40 33 00 	mov    0x3340(%rdx,%rcx,1),%rcx
    22a7:	00 
    22a8:	48 89 88 70 ff ff ff 	mov    %rcx,-0x90(%rax)
    22af:	89 b0 78 ff ff ff    	mov    %esi,-0x88(%rax)
    22b5:	e9 0e 0a 00 00       	jmp    2cc8 <f_8001161d0+0x2cc8>
    22ba:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    22bf:	48 8b 89 c8 1e 00 00 	mov    0x1ec8(%rcx),%rcx
    22c6:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    22ca:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    22cf:	48 89 77 60          	mov    %rsi,0x60(%rdi)
    22d3:	41 0f b6 5e 08       	movzbl 0x8(%r14),%ebx
    22d8:	48 89 5f 68          	mov    %rbx,0x68(%rdi)
    22dc:	8b 51 08             	mov    0x8(%rcx),%edx
    22df:	4d 89 fb             	mov    %r15,%r11
    22e2:	4c 8b 79 10          	mov    0x10(%rcx),%r15
    22e6:	4c 69 f3 e0 3c 00 00 	imul   $0x3ce0,%rbx,%r14
    22ed:	45 31 c9             	xor    %r9d,%r9d
    22f0:	39 da                	cmp    %ebx,%edx
    22f2:	ba 00 00 00 00       	mov    $0x0,%edx
    22f7:	49 0f 47 d6          	cmova  %r14,%rdx
    22fb:	48 c7 47 70 e0 3c 00 	movq   $0x3ce0,0x70(%rdi)
    2302:	00 
    2303:	4a 8b 94 3a 40 3c 00 	mov    0x3c40(%rdx,%r15,1),%rdx
    230a:	00 
    230b:	48 89 97 b0 00 00 00 	mov    %rdx,0xb0(%rdi)
    2312:	44 89 90 70 ff ff ff 	mov    %r10d,-0x90(%rax)
    2319:	48 89 b0 58 ff ff ff 	mov    %rsi,-0xa8(%rax)
    2320:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
    2327:	ff 7f 7f 
    232a:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
    2331:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2338:	00 
    2339:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    233d:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
    2344:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
    234b:	00 00 00 00 
    234f:	4c 89 98 20 ff ff ff 	mov    %r11,-0xe0(%rax)
    2356:	48 c7 47 40 06 00 00 	movq   $0x6,0x40(%rdi)
    235d:	00 
    235e:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2362:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
    2369:	ff 
    236a:	48 c7 80 00 ff ff ff 	movq   $0x6,-0x100(%rax)
    2371:	06 00 00 00 
    2375:	48 ba 10 00 00 00 03 	movabs $0x300000010,%rdx
    237c:	00 00 00 
    237f:	48 83 c2 10          	add    $0x10,%rdx
    2383:	48 89 90 d0 fe ff ff 	mov    %rdx,-0x130(%rax)
    238a:	48 ba 00 00 00 00 01 	movabs $0x40000100000000,%rdx
    2391:	00 40 00 
    2394:	48 89 90 d8 fe ff ff 	mov    %rdx,-0x128(%rax)
    239b:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    23a2:	ff ff 00 00 
    23a6:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    23ad:	ff ff ff 
    23b0:	48 8d 55 09          	lea    0x9(%rbp),%rdx
    23b4:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
    23bb:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
    23c2:	00 00 00 
    23c5:	48 89 90 f0 fe ff ff 	mov    %rdx,-0x110(%rax)
    23cc:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
    23d3:	48 8b 97 c0 00 00 00 	mov    0xc0(%rdi),%rdx
    23da:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    23df:	48 89 b2 a4 00 00 00 	mov    %rsi,0xa4(%rdx)
    23e6:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
    23ed:	00 80 3f 
    23f0:	48 89 90 08 ff ff ff 	mov    %rdx,-0xf8(%rax)
    23f7:	48 89 90 10 ff ff ff 	mov    %rdx,-0xf0(%rax)
    23fe:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    2405:	00 00 00 
    2408:	49 8d 95 af c7 07 00 	lea    0x7c7af(%r13),%rdx
    240f:	48 89 57 78          	mov    %rdx,0x78(%rdi)
    2413:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
    241a:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
    2421:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
    2428:	4c 89 80 50 ff ff ff 	mov    %r8,-0xb0(%rax)
    242f:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
    2436:	00 00 00 00 
    243a:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
    2441:	39 59 08             	cmp    %ebx,0x8(%rcx)
    2444:	4d 0f 46 f1          	cmovbe %r9,%r14
    2448:	48 8b 51 10          	mov    0x10(%rcx),%rdx
    244c:	c4 a1 78 10 84 32 00 	vmovups 0x2e00(%rdx,%r14,1),%xmm0
    2453:	2e 00 00 
    2456:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
    245d:	ff 
    245e:	8b 51 08             	mov    0x8(%rcx),%edx
    2461:	31 f6                	xor    %esi,%esi
    2463:	31 c0                	xor    %eax,%eax
    2465:	41 89 d0             	mov    %edx,%r8d
    2468:	41 29 d8             	sub    %ebx,%r8d
    246b:	44 8b 57 68          	mov    0x68(%rdi),%r10d
    246f:	4d 0f 46 d1          	cmovbe %r9,%r10
    2473:	40 0f 94 c6          	sete   %sil
    2477:	0f 93 c0             	setae  %al
    247a:	c1 e6 1e             	shl    $0x1e,%esi
    247d:	c1 e0 1d             	shl    $0x1d,%eax
    2480:	09 f0                	or     %esi,%eax
    2482:	c4 e2 38 f2 f2       	andn   %edx,%r8d,%esi
    2487:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
    248e:	44 09 c0             	or     %r8d,%eax
    2491:	c1 ee 03             	shr    $0x3,%esi
    2494:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    249a:	09 c6                	or     %eax,%esi
    249c:	8b 57 70             	mov    0x70(%rdi),%edx
    249f:	49 0f af d2          	imul   %r10,%rdx
    24a3:	48 03 51 10          	add    0x10(%rcx),%rdx
    24a7:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    24ae:	48 8b 82 80 30 00 00 	mov    0x3080(%rdx),%rax
    24b5:	48 8b 8f b0 00 00 00 	mov    0xb0(%rdi),%rcx
    24bc:	48 8b b7 d0 00 00 00 	mov    0xd0(%rdi),%rsi
    24c3:	48 89 0f             	mov    %rcx,(%rdi)
    24c6:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    24cd:	00 
    24ce:	48 8b 8a 88 30 00 00 	mov    0x3088(%rdx),%rcx
    24d5:	48 89 4f 50          	mov    %rcx,0x50(%rdi)
    24d9:	48 89 06             	mov    %rax,(%rsi)
    24dc:	48 89 4e 08          	mov    %rcx,0x8(%rsi)
    24e0:	48 8b 82 90 30 00 00 	mov    0x3090(%rdx),%rax
    24e7:	48 89 47 48          	mov    %rax,0x48(%rdi)
    24eb:	8b 8a 98 30 00 00    	mov    0x3098(%rdx),%ecx
    24f1:	48 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%rdx
    24f8:	89 4a 08             	mov    %ecx,0x8(%rdx)
    24fb:	48 8b 8f e8 00 00 00 	mov    0xe8(%rdi),%rcx
    2502:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
    2506:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    250a:	48 89 02             	mov    %rax,(%rdx)
    250d:	49 8d 85 ea 0b 51 fd 	lea    -0x2aef416(%r13),%rax
    2514:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    251b:	48 89 fb             	mov    %rdi,%rbx
    251e:	c5 f8 77             	vzeroupper
    2521:	e8 00 00 00 00       	call   2526 <f_8001161d0+0x2526>
    2526:	48 89 df             	mov    %rbx,%rdi
    2529:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2530:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    2537:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    253e:	48 89 01             	mov    %rax,(%rcx)
    2541:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
    2548:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
    254f:	48 8b b0 04 16 00 00 	mov    0x1604(%rax),%rsi
    2556:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
    255a:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    255e:	88 51 08             	mov    %dl,0x8(%rcx)
    2561:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    2568:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
    256c:	8b 80 0c 16 00 00    	mov    0x160c(%rax),%eax
    2572:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2576:	48 c7 47 48 02 00 00 	movq   $0x2,0x48(%rdi)
    257d:	00 
    257e:	89 41 24             	mov    %eax,0x24(%rcx)
    2581:	c7 81 bc 00 00 00 02 	movl   $0x2,0xbc(%rcx)
    2588:	00 00 00 
    258b:	e9 38 07 00 00       	jmp    2cc8 <f_8001161d0+0x2cc8>
    2590:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    2597:	00 
    2598:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    259f:	48 c7 03 80 00 00 00 	movq   $0x80,(%rbx)
    25a6:	48 b9 00 00 00 00 00 	movabs $0x60000000000000,%rcx
    25ad:	00 60 00 
    25b0:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    25b4:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
    25bb:	00 
    25bc:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    25c3:	ff ff ff 
    25c6:	48 8d 4a 12          	lea    0x12(%rdx),%rcx
    25ca:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    25ce:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    25d5:	00 00 00 
    25d8:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
    25dc:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    25e0:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    25e6:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    25ea:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    25f1:	00 80 3f 
    25f4:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    25f8:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
    25fc:	48 83 c3 38          	add    $0x38,%rbx
    2600:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
    2607:	00 00 00 
    260a:	4c 8d 8a 6d 4f 0a 00 	lea    0xa4f6d(%rdx),%r9
    2611:	e9 e3 04 00 00       	jmp    2af9 <f_8001161d0+0x2af9>
    2616:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
    261d:	48 8b 97 a0 00 00 00 	mov    0xa0(%rdi),%rdx
    2624:	48 8b 92 c8 1e 00 00 	mov    0x1ec8(%rdx),%rdx
    262b:	48 89 57 08          	mov    %rdx,0x8(%rdi)
    262f:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    2634:	48 89 77 60          	mov    %rsi,0x60(%rdi)
    2638:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    263f:	00 
    2640:	44 0f b6 49 08       	movzbl 0x8(%rcx),%r9d
    2645:	4c 89 4f 68          	mov    %r9,0x68(%rdi)
    2649:	8b 5a 08             	mov    0x8(%rdx),%ebx
    264c:	4d 69 f1 e0 3c 00 00 	imul   $0x3ce0,%r9,%r14
    2653:	31 c9                	xor    %ecx,%ecx
    2655:	44 39 cb             	cmp    %r9d,%ebx
    2658:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    265c:	48 c7 47 70 e0 3c 00 	movq   $0x3ce0,0x70(%rdi)
    2663:	00 
    2664:	4c 0f 46 f1          	cmovbe %rcx,%r14
    2668:	49 8b 94 16 40 3c 00 	mov    0x3c40(%r14,%rdx,1),%rdx
    266f:	00 
    2670:	48 89 17             	mov    %rdx,(%rdi)
    2673:	4c 8b 8f 00 01 00 00 	mov    0x100(%rdi),%r9
    267a:	45 89 91 a0 00 00 00 	mov    %r10d,0xa0(%r9)
    2681:	49 89 b1 88 00 00 00 	mov    %rsi,0x88(%r9)
    2688:	48 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rdx
    268f:	ff 7f 7f 
    2692:	49 89 91 90 00 00 00 	mov    %rdx,0x90(%r9)
    2699:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    26a0:	00 
    26a1:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    26a5:	41 c7 81 bc 00 00 00 	movl   $0x0,0xbc(%r9)
    26ac:	00 00 00 00 
    26b0:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    26b4:	c4 c1 78 11 41 58    	vmovups %xmm0,0x58(%r9)
    26ba:	49 c7 01 20 00 00 00 	movq   $0x20,(%r9)
    26c1:	48 b8 00 00 00 00 00 	movabs $0x42080000000000,%rax
    26c8:	08 42 00 
    26cb:	49 89 41 08          	mov    %rax,0x8(%r9)
    26cf:	49 c7 41 48 00 00 00 	movq   $0x0,0x48(%r9)
    26d6:	00 
    26d7:	4d 89 79 50          	mov    %r15,0x50(%r9)
    26db:	49 c7 41 30 07 00 00 	movq   $0x7,0x30(%r9)
    26e2:	00 
    26e3:	49 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%r9)
    26ea:	00 
    26eb:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    26f2:	ff ff ff 
    26f5:	48 8d 42 0a          	lea    0xa(%rdx),%rax
    26f9:	49 89 41 18          	mov    %rax,0x18(%r9)
    26fd:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2704:	00 00 00 
    2707:	49 89 41 20          	mov    %rax,0x20(%r9)
    270b:	49 89 51 28          	mov    %rdx,0x28(%r9)
    270f:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    2716:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    271b:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
    2722:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    2729:	00 80 3f 
    272c:	49 89 41 38          	mov    %rax,0x38(%r9)
    2730:	49 89 41 40          	mov    %rax,0x40(%r9)
    2734:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    273b:	00 00 00 
    273e:	49 8d 85 c5 e4 0b 00 	lea    0xbe4c5(%r13),%rax
    2745:	48 89 47 78          	mov    %rax,0x78(%rdi)
    2749:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
    2750:	4d 89 81 98 00 00 00 	mov    %r8,0x98(%r9)
    2757:	48 8b 57 58          	mov    0x58(%rdi),%rdx
    275b:	49 89 51 78          	mov    %rdx,0x78(%r9)
    275f:	4d 89 81 80 00 00 00 	mov    %r8,0x80(%r9)
    2766:	49 c7 41 68 00 00 00 	movq   $0x0,0x68(%r9)
    276d:	00 
    276e:	49 89 41 70          	mov    %rax,0x70(%r9)
    2772:	48 8b 47 08          	mov    0x8(%rdi),%rax
    2776:	4c 8b 47 68          	mov    0x68(%rdi),%r8
    277a:	45 89 c1             	mov    %r8d,%r9d
    277d:	44 39 40 08          	cmp    %r8d,0x8(%rax)
    2781:	be 00 00 00 00       	mov    $0x0,%esi
    2786:	49 0f 47 f1          	cmova  %r9,%rsi
    278a:	4c 8b 57 48          	mov    0x48(%rdi),%r10
    278e:	4c 8b 58 10          	mov    0x10(%rax),%r11
    2792:	8b 57 70             	mov    0x70(%rdi),%edx
    2795:	48 0f af f2          	imul   %rdx,%rsi
    2799:	c4 a1 78 10 84 1e b0 	vmovups 0x30b0(%rsi,%r11,1),%xmm0
    27a0:	30 00 00 
    27a3:	c4 c1 78 11 02       	vmovups %xmm0,(%r10)
    27a8:	8b 70 08             	mov    0x8(%rax),%esi
    27ab:	45 31 d2             	xor    %r10d,%r10d
    27ae:	41 89 f3             	mov    %esi,%r11d
    27b1:	45 31 c3             	xor    %r8d,%r11d
    27b4:	41 0f 94 c2          	sete   %r10b
    27b8:	31 db                	xor    %ebx,%ebx
    27ba:	89 f5                	mov    %esi,%ebp
    27bc:	44 29 c5             	sub    %r8d,%ebp
    27bf:	49 0f 47 c9          	cmova  %r9,%rcx
    27c3:	0f 93 c3             	setae  %bl
    27c6:	31 ee                	xor    %ebp,%esi
    27c8:	44 21 de             	and    %r11d,%esi
    27cb:	41 c1 e2 1e          	shl    $0x1e,%r10d
    27cf:	c1 e3 1d             	shl    $0x1d,%ebx
    27d2:	44 09 d3             	or     %r10d,%ebx
    27d5:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    27db:	09 eb                	or     %ebp,%ebx
    27dd:	48 8b 40 10          	mov    0x10(%rax),%rax
    27e1:	c1 ee 03             	shr    $0x3,%esi
    27e4:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    27ea:	09 de                	or     %ebx,%esi
    27ec:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    27f3:	48 0f af ca          	imul   %rdx,%rcx
    27f7:	48 8b 94 01 30 33 00 	mov    0x3330(%rcx,%rax,1),%rdx
    27fe:	00 
    27ff:	48 8b b4 01 38 33 00 	mov    0x3338(%rcx,%rax,1),%rsi
    2806:	00 
    2807:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    280b:	4c 8b 87 d0 00 00 00 	mov    0xd0(%rdi),%r8
    2812:	49 89 10             	mov    %rdx,(%r8)
    2815:	49 89 70 08          	mov    %rsi,0x8(%r8)
    2819:	48 8b 94 01 40 33 00 	mov    0x3340(%rcx,%rax,1),%rdx
    2820:	00 
    2821:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    2825:	8b 84 01 48 33 00 00 	mov    0x3348(%rcx,%rax,1),%eax
    282c:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
    2833:	89 41 08             	mov    %eax,0x8(%rcx)
    2836:	48 8b 87 e8 00 00 00 	mov    0xe8(%rdi),%rax
    283d:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    2841:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2845:	48 89 11             	mov    %rdx,(%rcx)
    2848:	49 8d 85 72 0d 51 fd 	lea    -0x2aef28e(%r13),%rax
    284f:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    2856:	48 89 fb             	mov    %rdi,%rbx
    2859:	c5 f8 77             	vzeroupper
    285c:	e8 00 00 00 00       	call   2861 <f_8001161d0+0x2861>
    2861:	48 89 df             	mov    %rbx,%rdi
    2864:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    286b:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    2872:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    2879:	48 89 01             	mov    %rax,(%rcx)
    287c:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    2883:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    2887:	48 89 43 40          	mov    %rax,0x40(%rbx)
    288b:	88 41 08             	mov    %al,0x8(%rcx)
    288e:	b9 bc 00 00 00       	mov    $0xbc,%ecx
    2893:	48 03 8b 00 01 00 00 	add    0x100(%rbx),%rcx
    289a:	e9 d4 08 00 00       	jmp    3173 <f_8001161d0+0x3173>
    289f:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    28a3:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    28aa:	48 c7 01 01 00 00 00 	movq   $0x1,(%rcx)
    28b1:	48 ba 00 00 00 00 00 	movabs $0x40000000000000,%rdx
    28b8:	00 40 00 
    28bb:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    28bf:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    28c6:	00 
    28c7:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    28ce:	ff ff ff 
    28d1:	4d 89 c1             	mov    %r8,%r9
    28d4:	49 89 d0             	mov    %rdx,%r8
    28d7:	48 83 c2 15          	add    $0x15,%rdx
    28db:	48 89 51 18          	mov    %rdx,0x18(%rcx)
    28df:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    28e6:	00 
    28e7:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    28ee:	00 00 00 
    28f1:	48 89 41 20          	mov    %rax,0x20(%rcx)
    28f5:	4c 89 41 28          	mov    %r8,0x28(%rcx)
    28f9:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    28fe:	48 89 41 30          	mov    %rax,0x30(%rcx)
    2902:	49 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r8
    2909:	00 80 3f 
    290c:	4c 89 41 38          	mov    %r8,0x38(%rcx)
    2910:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    2917:	00 00 00 
    291a:	48 8d 80 7c 4f 0a 00 	lea    0xa4f7c(%rax),%rax
    2921:	48 89 41 70          	mov    %rax,0x70(%rcx)
    2925:	48 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rbx
    292c:	ff 7f 7f 
    292f:	48 89 59 78          	mov    %rbx,0x78(%rcx)
    2933:	4c 89 89 80 00 00 00 	mov    %r9,0x80(%rcx)
    293a:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    293f:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    2946:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 294e <f_8001161d0+0x294e>
    294d:	00 
    294e:	c5 fc 11 47 60       	vmovups %ymm0,0x60(%rdi)
    2953:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    295a:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    295f:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
    2966:	4c 89 41 40          	mov    %r8,0x40(%rcx)
    296a:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    2971:	00 
    2972:	48 89 99 90 00 00 00 	mov    %rbx,0x90(%rcx)
    2979:	4c 89 89 98 00 00 00 	mov    %r9,0x98(%rcx)
    2980:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    2987:	00 
    2988:	4c 89 79 50          	mov    %r15,0x50(%rcx)
    298c:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2990:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    2995:	48 c7 47 50 03 00 00 	movq   $0x3,0x50(%rdi)
    299c:	00 
    299d:	b8 03 00 00 00       	mov    $0x3,%eax
    29a2:	e9 f1 01 00 00       	jmp    2b98 <f_8001161d0+0x2b98>
    29a7:	48 c7 47 40 b0 1e 00 	movq   $0x1eb0,0x40(%rdi)
    29ae:	00 
    29af:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    29b6:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    29bd:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    29c1:	48 89 47 10          	mov    %rax,0x10(%rdi)
    29c5:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    29ca:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
    29d1:	48 89 07             	mov    %rax,(%rdi)
    29d4:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    29db:	00 00 00 
    29de:	49 8d 85 2e 0c 51 fd 	lea    -0x2aef3d2(%r13),%rax
    29e5:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    29ec:	48 89 fb             	mov    %rdi,%rbx
    29ef:	c5 f8 77             	vzeroupper
    29f2:	e8 00 00 00 00       	call   29f7 <f_8001161d0+0x29f7>
    29f7:	48 89 df             	mov    %rbx,%rdi
    29fa:	e9 c9 02 00 00       	jmp    2cc8 <f_8001161d0+0x2cc8>
    29ff:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    2a06:	00 
    2a07:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    2a0e:	48 c7 03 03 00 00 00 	movq   $0x3,(%rbx)
    2a15:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    2a1c:	00 40 00 
    2a1f:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    2a23:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
    2a2a:	00 
    2a2b:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    2a32:	ff ff ff 
    2a35:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    2a39:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    2a3d:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2a44:	00 00 00 
    2a47:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
    2a4b:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    2a4f:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    2a55:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    2a59:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    2a60:	00 80 3f 
    2a63:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    2a67:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
    2a6b:	48 83 c3 38          	add    $0x38,%rbx
    2a6f:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
    2a76:	00 00 00 
    2a79:	4c 8d 8a fb b3 05 00 	lea    0x5b3fb(%rdx),%r9
    2a80:	eb 77                	jmp    2af9 <f_8001161d0+0x2af9>
    2a82:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    2a89:	ff ff ff 
    2a8c:	48 8d 4a 0e          	lea    0xe(%rdx),%rcx
    2a90:	48 89 4f 78          	mov    %rcx,0x78(%rdi)
    2a94:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    2a9b:	48 c7 03 00 04 00 00 	movq   $0x400,(%rbx)
    2aa2:	48 c7 43 08 00 00 00 	movq   $0x0,0x8(%rbx)
    2aa9:	00 
    2aaa:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
    2ab1:	00 
    2ab2:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    2ab6:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2abd:	00 00 00 
    2ac0:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
    2ac4:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    2ac8:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    2ace:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    2ad2:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    2ad9:	00 80 3f 
    2adc:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    2ae0:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
    2ae4:	48 83 c3 38          	add    $0x38,%rbx
    2ae8:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
    2aef:	00 00 00 
    2af2:	4c 8d 8a d9 85 00 00 	lea    0x85d9(%rdx),%r9
    2af9:	4c 89 01             	mov    %r8,(%rcx)
    2afc:	4c 89 33             	mov    %r14,(%rbx)
    2aff:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    2b06:	4c 89 49 70          	mov    %r9,0x70(%rcx)
    2b0a:	49 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r9
    2b11:	ff 7f 7f 
    2b14:	4c 89 49 78          	mov    %r9,0x78(%rcx)
    2b18:	48 ba ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdx
    2b1f:	ff 7f ff 
    2b22:	48 89 57 68          	mov    %rdx,0x68(%rdi)
    2b26:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2b2a:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2b31:	00 
    2b32:	48 89 91 80 00 00 00 	mov    %rdx,0x80(%rcx)
    2b39:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    2b3e:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    2b45:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    2b4a:	4c 89 47 60          	mov    %r8,0x60(%rdi)
    2b4e:	4c 89 71 40          	mov    %r14,0x40(%rcx)
    2b52:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    2b59:	00 
    2b5a:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    2b61:	4c 89 80 a4 00 00 00 	mov    %r8,0xa4(%rax)
    2b68:	4c 89 79 50          	mov    %r15,0x50(%rcx)
    2b6c:	48 c7 41 58 00 00 00 	movq   $0x0,0x58(%rcx)
    2b73:	00 
    2b74:	48 c7 47 50 02 00 00 	movq   $0x2,0x50(%rdi)
    2b7b:	00 
    2b7c:	4c 89 89 90 00 00 00 	mov    %r9,0x90(%rcx)
    2b83:	48 89 91 98 00 00 00 	mov    %rdx,0x98(%rcx)
    2b8a:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2b8e:	c5 f8 11 41 60       	vmovups %xmm0,0x60(%rcx)
    2b93:	b8 02 00 00 00       	mov    $0x2,%eax
    2b98:	4c 8b 5c 24 20       	mov    0x20(%rsp),%r11
    2b9d:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
    2ba4:	89 81 bc 00 00 00    	mov    %eax,0xbc(%rcx)
    2baa:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
    2bb1:	48 8b 87 a0 00 00 00 	mov    0xa0(%rdi),%rax
    2bb8:	48 8b 80 c8 1e 00 00 	mov    0x1ec8(%rax),%rax
    2bbf:	0f b6 71 08          	movzbl 0x8(%rcx),%esi
    2bc3:	4c 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%r8
    2bca:	31 c9                	xor    %ecx,%ecx
    2bcc:	39 70 08             	cmp    %esi,0x8(%rax)
    2bcf:	ba 00 00 00 00       	mov    $0x0,%edx
    2bd4:	49 0f 47 d0          	cmova  %r8,%rdx
    2bd8:	4c 8b 48 10          	mov    0x10(%rax),%r9
    2bdc:	4e 8b 94 0a 08 2e 00 	mov    0x2e08(%rdx,%r9,1),%r10
    2be3:	00 
    2be4:	4c 89 57 68          	mov    %r10,0x68(%rdi)
    2be8:	4a 8b 94 0a 00 2e 00 	mov    0x2e00(%rdx,%r9,1),%rdx
    2bef:	00 
    2bf0:	49 89 13             	mov    %rdx,(%r11)
    2bf3:	4d 89 53 08          	mov    %r10,0x8(%r11)
    2bf7:	44 8b 48 08          	mov    0x8(%rax),%r9d
    2bfb:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2bff:	48 89 57 60          	mov    %rdx,0x60(%rdi)
    2c03:	45 31 d2             	xor    %r10d,%r10d
    2c06:	45 31 db             	xor    %r11d,%r11d
    2c09:	44 89 cb             	mov    %r9d,%ebx
    2c0c:	29 f3                	sub    %esi,%ebx
    2c0e:	49 0f 47 c8          	cmova  %r8,%rcx
    2c12:	41 0f 94 c2          	sete   %r10b
    2c16:	41 0f 93 c3          	setae  %r11b
    2c1a:	c4 c2 60 f2 f1       	andn   %r9d,%ebx,%esi
    2c1f:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    2c25:	41 c1 e2 1e          	shl    $0x1e,%r10d
    2c29:	41 c1 e3 1d          	shl    $0x1d,%r11d
    2c2d:	45 09 d3             	or     %r10d,%r11d
    2c30:	41 09 db             	or     %ebx,%r11d
    2c33:	c1 ee 03             	shr    $0x3,%esi
    2c36:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    2c3c:	44 09 de             	or     %r11d,%esi
    2c3f:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    2c46:	48 8b b4 0a 80 30 00 	mov    0x3080(%rdx,%rcx,1),%rsi
    2c4d:	00 
    2c4e:	4c 8b 84 0a 88 30 00 	mov    0x3088(%rdx,%rcx,1),%r8
    2c55:	00 
    2c56:	48 89 77 58          	mov    %rsi,0x58(%rdi)
    2c5a:	49 89 75 00          	mov    %rsi,0x0(%r13)
    2c5e:	4d 89 45 08          	mov    %r8,0x8(%r13)
    2c62:	8b b4 0a 98 30 00 00 	mov    0x3098(%rdx,%rcx,1),%esi
    2c69:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    2c6d:	48 8b 8c 0a 90 30 00 	mov    0x3090(%rdx,%rcx,1),%rcx
    2c74:	00 
    2c75:	48 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%rdx
    2c7c:	48 89 0a             	mov    %rcx,(%rdx)
    2c7f:	89 72 08             	mov    %esi,0x8(%rdx)
    2c82:	8b 50 20             	mov    0x20(%rax),%edx
    2c85:	8b 48 24             	mov    0x24(%rax),%ecx
    2c88:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    2c8c:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    2c90:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    2c97:	c7 80 b4 00 00 00 00 	movl   $0x0,0xb4(%rax)
    2c9e:	00 00 00 
    2ca1:	48 8b b7 c0 00 00 00 	mov    0xc0(%rdi),%rsi
    2ca8:	c7 86 b1 00 00 00 00 	movl   $0x0,0xb1(%rsi)
    2caf:	00 00 00 
    2cb2:	88 90 b0 00 00 00    	mov    %dl,0xb0(%rax)
    2cb8:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    2cbf:	00 00 00 
    2cc2:	88 88 b8 00 00 00    	mov    %cl,0xb8(%rax)
    2cc8:	4c 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%r9
    2ccf:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    2cd6:	8b 08                	mov    (%rax),%ecx
    2cd8:	48 89 4f 50          	mov    %rcx,0x50(%rdi)
    2cdc:	49 8d 51 1c          	lea    0x1c(%r9),%rdx
    2ce0:	41 8b 71 1c          	mov    0x1c(%r9),%esi
    2ce4:	48 89 57 40          	mov    %rdx,0x40(%rdi)
    2ce8:	48 89 77 48          	mov    %rsi,0x48(%rdi)
    2cec:	89 70 48             	mov    %esi,0x48(%rax)
    2cef:	4d 8d 51 2c          	lea    0x2c(%r9),%r10
    2cf3:	45 8b 41 2c          	mov    0x2c(%r9),%r8d
    2cf7:	45 31 db             	xor    %r11d,%r11d
    2cfa:	4d 85 c0             	test   %r8,%r8
    2cfd:	41 0f 94 c3          	sete   %r11b
    2d01:	4c 89 97 b0 00 00 00 	mov    %r10,0xb0(%rdi)
    2d08:	4c 89 47 60          	mov    %r8,0x60(%rdi)
    2d0c:	45 8b 49 14          	mov    0x14(%r9),%r9d
    2d10:	45 31 d2             	xor    %r10d,%r10d
    2d13:	41 85 c9             	test   %ecx,%r9d
    2d16:	41 0f 95 c2          	setne  %r10b
    2d1a:	4c 89 57 58          	mov    %r10,0x58(%rdi)
    2d1e:	45 89 c2             	mov    %r8d,%r10d
    2d21:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    2d28:	44 89 db             	mov    %r11d,%ebx
    2d2b:	c1 e3 1e             	shl    $0x1e,%ebx
    2d2e:	49 01 da             	add    %rbx,%r10
    2d31:	49 81 c2 00 00 00 20 	add    $0x20000000,%r10
    2d38:	4c 89 97 10 01 00 00 	mov    %r10,0x110(%rdi)
    2d3f:	41 c1 e8 1f          	shr    $0x1f,%r8d
    2d43:	45 08 c3             	or     %r8b,%r11b
    2d46:	74 0d                	je     2d55 <f_8001161d0+0x2d55>
    2d48:	48 c7 47 58 00 00 00 	movq   $0x0,0x58(%rdi)
    2d4f:	00 
    2d50:	e9 73 01 00 00       	jmp    2ec8 <f_8001161d0+0x2ec8>
    2d55:	41 85 c9             	test   %ecx,%r9d
    2d58:	0f 84 6a 01 00 00    	je     2ec8 <f_8001161d0+0x2ec8>
    2d5e:	4c 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%r9
    2d65:	4c 8b 97 a8 00 00 00 	mov    0xa8(%rdi),%r10
    2d6c:	4d 8d 81 40 01 00 00 	lea    0x140(%r9),%r8
    2d73:	4c 89 87 c0 00 00 00 	mov    %r8,0xc0(%rdi)
    2d7a:	45 89 d0             	mov    %r10d,%r8d
    2d7d:	4d 63 d2             	movslq %r10d,%r10
    2d80:	49 c1 fa 1f          	sar    $0x1f,%r10
    2d84:	49 bb 00 00 00 00 ff 	movabs $0xffffffff00000000,%r11
    2d8b:	ff ff ff 
    2d8e:	4d 21 da             	and    %r11,%r10
    2d91:	4d 09 c2             	or     %r8,%r10
    2d94:	4c 89 97 c8 00 00 00 	mov    %r10,0xc8(%rdi)
    2d9b:	47 0f b6 8c 11 40 01 	movzbl 0x140(%r9,%r10,1),%r9d
    2da2:	00 00 
    2da4:	4c 89 4f 58          	mov    %r9,0x58(%rdi)
    2da8:	41 f6 c1 01          	test   $0x1,%r9b
    2dac:	0f 84 16 01 00 00    	je     2ec8 <f_8001161d0+0x2ec8>
    2db2:	44 0f b6 48 0c       	movzbl 0xc(%rax),%r9d
    2db7:	4c 89 4f 58          	mov    %r9,0x58(%rdi)
    2dbb:	41 f6 c1 01          	test   $0x1,%r9b
    2dbf:	74 09                	je     2dca <f_8001161d0+0x2dca>
    2dc1:	48 09 ce             	or     %rcx,%rsi
    2dc4:	48 89 77 48          	mov    %rsi,0x48(%rdi)
    2dc8:	89 32                	mov    %esi,(%rdx)
    2dca:	48 c7 47 40 d0 00 00 	movq   $0xd0,0x40(%rdi)
    2dd1:	00 
    2dd2:	48 89 47 08          	mov    %rax,0x8(%rdi)
    2dd6:	49 63 c0             	movslq %r8d,%rax
    2dd9:	48 69 c0 d0 00 00 00 	imul   $0xd0,%rax,%rax
    2de0:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
    2de7:	48 8d 14 01          	lea    (%rcx,%rax,1),%rdx
    2deb:	48 89 97 d0 00 00 00 	mov    %rdx,0xd0(%rdi)
    2df2:	48 c7 47 10 c0 00 00 	movq   $0xc0,0x10(%rdi)
    2df9:	00 
    2dfa:	48 8d 84 01 40 0d 00 	lea    0xd40(%rcx,%rax,1),%rax
    2e01:	00 
    2e02:	48 89 87 a8 00 00 00 	mov    %rax,0xa8(%rdi)
    2e09:	48 89 07             	mov    %rax,(%rdi)
    2e0c:	49 8d 85 6e 12 51 fd 	lea    -0x2aeed92(%r13),%rax
    2e13:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    2e1a:	48 89 fb             	mov    %rdi,%rbx
    2e1d:	c5 f8 77             	vzeroupper
    2e20:	e8 00 00 00 00       	call   2e25 <f_8001161d0+0x2e25>
    2e25:	48 89 df             	mov    %rbx,%rdi
    2e28:	48 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%rax
    2e2f:	80 88 38 0d 00 00 01 	orb    $0x1,0xd38(%rax)
    2e36:	4c 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%r8
    2e3d:	41 0f b6 80 81 3a 00 	movzbl 0x3a81(%r8),%eax
    2e44:	00 
    2e45:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2e49:	a8 40                	test   $0x40,%al
    2e4b:	74 7b                	je     2ec8 <f_8001161d0+0x2ec8>
    2e4d:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    2e54:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
    2e5b:	0f b6 04 01          	movzbl (%rcx,%rax,1),%eax
    2e5f:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2e63:	a8 02                	test   $0x2,%al
    2e65:	74 61                	je     2ec8 <f_8001161d0+0x2ec8>
    2e67:	49 8b 80 60 3b 00 00 	mov    0x3b60(%r8),%rax
    2e6e:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2e72:	48 85 c0             	test   %rax,%rax
    2e75:	74 51                	je     2ec8 <f_8001161d0+0x2ec8>
    2e77:	41 0f b6 80 85 3a 00 	movzbl 0x3a85(%r8),%eax
    2e7e:	00 
    2e7f:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2e83:	a8 02                	test   $0x2,%al
    2e85:	74 41                	je     2ec8 <f_8001161d0+0x2ec8>
    2e87:	48 8b 87 a8 00 00 00 	mov    0xa8(%rdi),%rax
    2e8e:	48 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%rcx
    2e95:	8b 00                	mov    (%rax),%eax
    2e97:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2e9b:	8b 49 10             	mov    0x10(%rcx),%ecx
    2e9e:	31 d2                	xor    %edx,%edx
    2ea0:	c4 e2 70 f2 c0       	andn   %eax,%ecx,%eax
    2ea5:	0f 94 c2             	sete   %dl
    2ea8:	89 c6                	mov    %eax,%esi
    2eaa:	81 e6 00 00 00 80    	and    $0x80000000,%esi
    2eb0:	c1 e2 1e             	shl    $0x1e,%edx
    2eb3:	09 f2                	or     %esi,%edx
    2eb5:	48 89 4f 48          	mov    %rcx,0x48(%rdi)
    2eb9:	48 89 97 10 01 00 00 	mov    %rdx,0x110(%rdi)
    2ec0:	85 c0                	test   %eax,%eax
    2ec2:	0f 84 aa 05 00 00    	je     3472 <f_8001161d0+0x3472>
    2ec8:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    2ecf:	48 8b 88 20 01 00 00 	mov    0x120(%rax),%rcx
    2ed6:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    2edd:	48 89 8f a0 00 00 00 	mov    %rcx,0xa0(%rdi)
    2ee4:	48 89 97 98 00 00 00 	mov    %rdx,0x98(%rdi)
    2eeb:	48 8b 88 10 01 00 00 	mov    0x110(%rax),%rcx
    2ef2:	48 8b 90 18 01 00 00 	mov    0x118(%rax),%rdx
    2ef9:	48 89 8f b0 00 00 00 	mov    %rcx,0xb0(%rdi)
    2f00:	48 89 97 a8 00 00 00 	mov    %rdx,0xa8(%rdi)
    2f07:	48 8b 88 00 01 00 00 	mov    0x100(%rax),%rcx
    2f0e:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    2f15:	48 89 8f c0 00 00 00 	mov    %rcx,0xc0(%rdi)
    2f1c:	48 89 97 b8 00 00 00 	mov    %rdx,0xb8(%rdi)
    2f23:	48 8b 88 f0 00 00 00 	mov    0xf0(%rax),%rcx
    2f2a:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
    2f31:	48 89 8f d0 00 00 00 	mov    %rcx,0xd0(%rdi)
    2f38:	48 89 97 c8 00 00 00 	mov    %rdx,0xc8(%rdi)
    2f3f:	48 8b 88 e0 00 00 00 	mov    0xe0(%rax),%rcx
    2f46:	48 8b 90 e8 00 00 00 	mov    0xe8(%rax),%rdx
    2f4d:	48 89 8f e0 00 00 00 	mov    %rcx,0xe0(%rdi)
    2f54:	48 89 97 d8 00 00 00 	mov    %rdx,0xd8(%rdi)
    2f5b:	c5 f8 10 80 d0 00 00 	vmovups 0xd0(%rax),%xmm0
    2f62:	00 
    2f63:	c5 f8 11 87 e8 00 00 	vmovups %xmm0,0xe8(%rdi)
    2f6a:	00 
    2f6b:	48 05 30 01 00 00    	add    $0x130,%rax
    2f71:	48 89 87 00 01 00 00 	mov    %rax,0x100(%rdi)
    2f78:	48 83 c4 28          	add    $0x28,%rsp
    2f7c:	5b                   	pop    %rbx
    2f7d:	41 5c                	pop    %r12
    2f7f:	41 5d                	pop    %r13
    2f81:	41 5e                	pop    %r14
    2f83:	41 5f                	pop    %r15
    2f85:	5d                   	pop    %rbp
    2f86:	c5 f8 77             	vzeroupper
    2f89:	c3                   	ret
    2f8a:	4c 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%r9
    2f91:	49 8b 89 c8 1e 00 00 	mov    0x1ec8(%r9),%rcx
    2f98:	48 89 8f b0 00 00 00 	mov    %rcx,0xb0(%rdi)
    2f9f:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    2fa6:	ff ff ff 
    2fa9:	48 8d 55 1a          	lea    0x1a(%rbp),%rdx
    2fad:	48 89 57 70          	mov    %rdx,0x70(%rdi)
    2fb1:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2fb5:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    2fbc:	48 c7 01 00 20 00 00 	movq   $0x2000,(%rcx)
    2fc3:	48 c7 41 08 00 00 00 	movq   $0x0,0x8(%rcx)
    2fca:	00 
    2fcb:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    2fd2:	00 
    2fd3:	48 89 51 18          	mov    %rdx,0x18(%rcx)
    2fd7:	48 8b 97 98 00 00 00 	mov    0x98(%rdi),%rdx
    2fde:	48 89 57 08          	mov    %rdx,0x8(%rdi)
    2fe2:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2fe9:	00 
    2fea:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
    2ff1:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2ff8:	00 00 00 
    2ffb:	48 89 41 20          	mov    %rax,0x20(%rcx)
    2fff:	48 89 69 28          	mov    %rbp,0x28(%rcx)
    3003:	49 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r10
    300a:	00 80 3f 
    300d:	4c 89 57 68          	mov    %r10,0x68(%rdi)
    3011:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    3016:	48 89 41 30          	mov    %rax,0x30(%rcx)
    301a:	4c 89 51 38          	mov    %r10,0x38(%rcx)
    301e:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    3025:	00 00 00 
    3028:	49 8d 85 95 53 09 00 	lea    0x95395(%r13),%rax
    302f:	48 89 41 70          	mov    %rax,0x70(%rcx)
    3033:	48 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rbx
    303a:	ff 7f 7f 
    303d:	48 89 59 78          	mov    %rbx,0x78(%rcx)
    3041:	4c 89 81 80 00 00 00 	mov    %r8,0x80(%rcx)
    3048:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    304d:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    3054:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    3059:	48 89 57 60          	mov    %rdx,0x60(%rdi)
    305d:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    3064:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
    306b:	48 89 99 90 00 00 00 	mov    %rbx,0x90(%rcx)
    3072:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    3079:	48 c7 47 50 b0 1e 00 	movq   $0x1eb0,0x50(%rdi)
    3080:	00 
    3081:	49 81 c1 b0 1e 00 00 	add    $0x1eb0,%r9
    3088:	4c 89 0f             	mov    %r9,(%rdi)
    308b:	4c 89 79 50          	mov    %r15,0x50(%rcx)
    308f:	48 c7 41 58 00 00 00 	movq   $0x0,0x58(%rcx)
    3096:	00 
    3097:	48 c7 47 48 03 00 00 	movq   $0x3,0x48(%rdi)
    309e:	00 
    309f:	c7 81 bc 00 00 00 03 	movl   $0x3,0xbc(%rcx)
    30a6:	00 00 00 
    30a9:	4c 89 51 40          	mov    %r10,0x40(%rcx)
    30ad:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    30b4:	00 
    30b5:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    30b9:	c5 f8 11 41 60       	vmovups %xmm0,0x60(%rcx)
    30be:	49 8d 85 92 14 51 fd 	lea    -0x2aeeb6e(%r13),%rax
    30c5:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    30cc:	48 89 fb             	mov    %rdi,%rbx
    30cf:	c5 f8 77             	vzeroupper
    30d2:	e8 00 00 00 00       	call   30d7 <f_8001161d0+0x30d7>
    30d7:	48 89 df             	mov    %rbx,%rdi
    30da:	48 8b 33             	mov    (%rbx),%rsi
    30dd:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    30e4:	0f b6 48 08          	movzbl 0x8(%rax),%ecx
    30e8:	48 8b 93 b0 00 00 00 	mov    0xb0(%rbx),%rdx
    30ef:	8b 42 08             	mov    0x8(%rdx),%eax
    30f2:	45 31 c0             	xor    %r8d,%r8d
    30f5:	45 31 c9             	xor    %r9d,%r9d
    30f8:	41 89 c2             	mov    %eax,%r10d
    30fb:	41 29 ca             	sub    %ecx,%r10d
    30fe:	41 0f 94 c0          	sete   %r8b
    3102:	41 0f 93 c1          	setae  %r9b
    3106:	c4 62 28 f2 d8       	andn   %eax,%r10d,%r11d
    310b:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    3112:	41 c1 e0 1e          	shl    $0x1e,%r8d
    3116:	41 c1 e1 1d          	shl    $0x1d,%r9d
    311a:	45 09 c1             	or     %r8d,%r9d
    311d:	41 c1 eb 03          	shr    $0x3,%r11d
    3121:	41 81 e3 00 00 00 10 	and    $0x10000000,%r11d
    3128:	45 09 d3             	or     %r10d,%r11d
    312b:	45 09 cb             	or     %r9d,%r11d
    312e:	4c 69 c1 e0 3c 00 00 	imul   $0x3ce0,%rcx,%r8
    3135:	31 c0                	xor    %eax,%eax
    3137:	41 81 f9 00 00 00 20 	cmp    $0x20000000,%r9d
    313e:	49 0f 44 c0          	cmove  %r8,%rax
    3142:	4c 89 9b 10 01 00 00 	mov    %r11,0x110(%rbx)
    3149:	48 03 42 10          	add    0x10(%rdx),%rax
    314d:	40 f6 c6 01          	test   $0x1,%sil
    3151:	75 33                	jne    3186 <f_8001161d0+0x3186>
    3153:	41 b9 5c 00 00 00    	mov    $0x5c,%r9d
    3159:	41 ba 58 00 00 00    	mov    $0x58,%r10d
    315f:	41 bb 54 00 00 00    	mov    $0x54,%r11d
    3165:	bb 50 00 00 00       	mov    $0x50,%ebx
    316a:	eb 35                	jmp    31a1 <f_8001161d0+0x31a1>
    316c:	48 81 c1 bc 00 00 00 	add    $0xbc,%rcx
    3173:	48 c7 47 40 02 00 00 	movq   $0x2,0x40(%rdi)
    317a:	00 
    317b:	c7 01 02 00 00 00    	movl   $0x2,(%rcx)
    3181:	e9 42 fb ff ff       	jmp    2cc8 <f_8001161d0+0x2cc8>
    3186:	48 89 47 68          	mov    %rax,0x68(%rdi)
    318a:	41 b9 0c 2e 00 00    	mov    $0x2e0c,%r9d
    3190:	41 ba 08 2e 00 00    	mov    $0x2e08,%r10d
    3196:	41 bb 04 2e 00 00    	mov    $0x2e04,%r11d
    319c:	bb 00 2e 00 00       	mov    $0x2e00,%ebx
    31a1:	8b 1c 18             	mov    (%rax,%rbx,1),%ebx
    31a4:	48 89 9f 00 02 00 00 	mov    %rbx,0x200(%rdi)
    31ab:	48 c7 87 08 02 00 00 	movq   $0x0,0x208(%rdi)
    31b2:	00 00 00 00 
    31b6:	46 8b 1c 18          	mov    (%rax,%r11,1),%r11d
    31ba:	4c 89 9f 10 02 00 00 	mov    %r11,0x210(%rdi)
    31c1:	48 c7 87 18 02 00 00 	movq   $0x0,0x218(%rdi)
    31c8:	00 00 00 00 
    31cc:	46 8b 14 10          	mov    (%rax,%r10,1),%r10d
    31d0:	4c 89 97 20 02 00 00 	mov    %r10,0x220(%rdi)
    31d7:	48 c7 87 28 02 00 00 	movq   $0x0,0x228(%rdi)
    31de:	00 00 00 00 
    31e2:	48 c7 47 58 e0 3c 00 	movq   $0x3ce0,0x58(%rdi)
    31e9:	00 
    31ea:	46 8b 0c 08          	mov    (%rax,%r9,1),%r9d
    31ee:	4c 89 8f 30 02 00 00 	mov    %r9,0x230(%rdi)
    31f5:	48 c7 87 38 02 00 00 	movq   $0x0,0x238(%rdi)
    31fc:	00 00 00 00 
    3200:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    3207:	89 58 78             	mov    %ebx,0x78(%rax)
    320a:	44 89 58 7c          	mov    %r11d,0x7c(%rax)
    320e:	44 89 90 80 00 00 00 	mov    %r10d,0x80(%rax)
    3215:	44 89 88 84 00 00 00 	mov    %r9d,0x84(%rax)
    321c:	45 31 c9             	xor    %r9d,%r9d
    321f:	39 4a 08             	cmp    %ecx,0x8(%rdx)
    3222:	4d 0f 47 c8          	cmova  %r8,%r9
    3226:	4c 8b 52 10          	mov    0x10(%rdx),%r10
    322a:	40 f6 c6 01          	test   $0x1,%sil
    322e:	0f 85 8b 00 00 00    	jne    32bf <f_8001161d0+0x32bf>
    3234:	4b 8b 74 11 20       	mov    0x20(%r9,%r10,1),%rsi
    3239:	4f 8b 5c 11 28       	mov    0x28(%r9,%r10,1),%r11
    323e:	4c 89 5f 60          	mov    %r11,0x60(%rdi)
    3242:	48 8b 9f d0 00 00 00 	mov    0xd0(%rdi),%rbx
    3249:	48 89 33             	mov    %rsi,(%rbx)
    324c:	4c 89 5b 08          	mov    %r11,0x8(%rbx)
    3250:	4b 8b 74 11 30       	mov    0x30(%r9,%r10,1),%rsi
    3255:	47 8b 4c 11 38       	mov    0x38(%r9,%r10,1),%r9d
    325a:	4c 89 4f 48          	mov    %r9,0x48(%rdi)
    325e:	4c 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%r10
    3265:	45 89 4a 08          	mov    %r9d,0x8(%r10)
    3269:	49 89 32             	mov    %rsi,(%r10)
    326c:	44 8b 52 08          	mov    0x8(%rdx),%r10d
    3270:	48 8b 72 10          	mov    0x10(%rdx),%rsi
    3274:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    3278:	45 31 c9             	xor    %r9d,%r9d
    327b:	45 31 db             	xor    %r11d,%r11d
    327e:	31 db                	xor    %ebx,%ebx
    3280:	44 89 d5             	mov    %r10d,%ebp
    3283:	29 cd                	sub    %ecx,%ebp
    3285:	4d 0f 47 c8          	cmova  %r8,%r9
    3289:	41 0f 94 c3          	sete   %r11b
    328d:	0f 93 c3             	setae  %bl
    3290:	c4 c2 50 f2 d2       	andn   %r10d,%ebp,%edx
    3295:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    329b:	41 c1 e3 1e          	shl    $0x1e,%r11d
    329f:	c1 e3 1d             	shl    $0x1d,%ebx
    32a2:	44 09 db             	or     %r11d,%ebx
    32a5:	09 eb                	or     %ebp,%ebx
    32a7:	c1 ea 03             	shr    $0x3,%edx
    32aa:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    32b0:	09 da                	or     %ebx,%edx
    32b2:	4a 8d 0c 0e          	lea    (%rsi,%r9,1),%rcx
    32b6:	48 83 c1 40          	add    $0x40,%rcx
    32ba:	e9 a8 00 00 00       	jmp    3367 <f_8001161d0+0x3367>
    32bf:	4b 8b b4 11 80 30 00 	mov    0x3080(%r9,%r10,1),%rsi
    32c6:	00 
    32c7:	4f 8b 84 11 88 30 00 	mov    0x3088(%r9,%r10,1),%r8
    32ce:	00 
    32cf:	4c 89 47 60          	mov    %r8,0x60(%rdi)
    32d3:	4c 8b 9f d0 00 00 00 	mov    0xd0(%rdi),%r11
    32da:	49 89 33             	mov    %rsi,(%r11)
    32dd:	4d 89 43 08          	mov    %r8,0x8(%r11)
    32e1:	4b 8b b4 11 90 30 00 	mov    0x3090(%r9,%r10,1),%rsi
    32e8:	00 
    32e9:	47 8b 84 11 98 30 00 	mov    0x3098(%r9,%r10,1),%r8d
    32f0:	00 
    32f1:	4c 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%r9
    32f8:	45 89 41 08          	mov    %r8d,0x8(%r9)
    32fc:	49 89 31             	mov    %rsi,(%r9)
    32ff:	44 8b 4a 08          	mov    0x8(%rdx),%r9d
    3303:	48 8b 72 10          	mov    0x10(%rdx),%rsi
    3307:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    330b:	45 31 c0             	xor    %r8d,%r8d
    330e:	45 31 d2             	xor    %r10d,%r10d
    3311:	45 31 db             	xor    %r11d,%r11d
    3314:	44 89 cb             	mov    %r9d,%ebx
    3317:	29 cb                	sub    %ecx,%ebx
    3319:	41 0f 94 c2          	sete   %r10b
    331d:	41 0f 93 c3          	setae  %r11b
    3321:	4c 0f 47 c1          	cmova  %rcx,%r8
    3325:	c4 c2 60 f2 d1       	andn   %r9d,%ebx,%edx
    332a:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    3330:	41 c1 e2 1e          	shl    $0x1e,%r10d
    3334:	41 c1 e3 1d          	shl    $0x1d,%r11d
    3338:	45 09 d3             	or     %r10d,%r11d
    333b:	41 09 db             	or     %ebx,%r11d
    333e:	c1 ea 03             	shr    $0x3,%edx
    3341:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    3347:	44 09 da             	or     %r11d,%edx
    334a:	48 c7 47 48 f0 2d 00 	movq   $0x2df0,0x48(%rdi)
    3351:	00 
    3352:	4c 89 47 40          	mov    %r8,0x40(%rdi)
    3356:	49 69 c8 e0 3c 00 00 	imul   $0x3ce0,%r8,%rcx
    335d:	48 01 f1             	add    %rsi,%rcx
    3360:	48 81 c1 f0 2d 00 00 	add    $0x2df0,%rcx
    3367:	48 89 97 10 01 00 00 	mov    %rdx,0x110(%rdi)
    336e:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    3372:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    3376:	48 85 d2             	test   %rdx,%rdx
    3379:	74 0d                	je     3388 <f_8001161d0+0x3388>
    337b:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3382:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    3386:	eb 02                	jmp    338a <f_8001161d0+0x338a>
    3388:	31 d2                	xor    %edx,%edx
    338a:	88 90 b0 00 00 00    	mov    %dl,0xb0(%rax)
    3390:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    3394:	48 85 d2             	test   %rdx,%rdx
    3397:	74 09                	je     33a2 <f_8001161d0+0x33a2>
    3399:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    33a0:	eb 02                	jmp    33a4 <f_8001161d0+0x33a4>
    33a2:	31 d2                	xor    %edx,%edx
    33a4:	88 90 b1 00 00 00    	mov    %dl,0xb1(%rax)
    33aa:	48 8b 51 30          	mov    0x30(%rcx),%rdx
    33ae:	48 85 d2             	test   %rdx,%rdx
    33b1:	74 0d                	je     33c0 <f_8001161d0+0x33c0>
    33b3:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    33ba:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    33be:	eb 02                	jmp    33c2 <f_8001161d0+0x33c2>
    33c0:	31 d2                	xor    %edx,%edx
    33c2:	88 90 b2 00 00 00    	mov    %dl,0xb2(%rax)
    33c8:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    33cc:	48 85 d2             	test   %rdx,%rdx
    33cf:	74 09                	je     33da <f_8001161d0+0x33da>
    33d1:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    33d8:	eb 02                	jmp    33dc <f_8001161d0+0x33dc>
    33da:	31 d2                	xor    %edx,%edx
    33dc:	88 90 b3 00 00 00    	mov    %dl,0xb3(%rax)
    33e2:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    33e6:	48 85 d2             	test   %rdx,%rdx
    33e9:	74 0d                	je     33f8 <f_8001161d0+0x33f8>
    33eb:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    33f2:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    33f6:	eb 02                	jmp    33fa <f_8001161d0+0x33fa>
    33f8:	31 d2                	xor    %edx,%edx
    33fa:	88 90 b4 00 00 00    	mov    %dl,0xb4(%rax)
    3400:	48 8b 51 48          	mov    0x48(%rcx),%rdx
    3404:	48 85 d2             	test   %rdx,%rdx
    3407:	74 09                	je     3412 <f_8001161d0+0x3412>
    3409:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3410:	eb 02                	jmp    3414 <f_8001161d0+0x3414>
    3412:	31 d2                	xor    %edx,%edx
    3414:	88 90 b5 00 00 00    	mov    %dl,0xb5(%rax)
    341a:	48 8b 51 50          	mov    0x50(%rcx),%rdx
    341e:	48 85 d2             	test   %rdx,%rdx
    3421:	74 09                	je     342c <f_8001161d0+0x342c>
    3423:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    342a:	eb 02                	jmp    342e <f_8001161d0+0x342e>
    342c:	31 d2                	xor    %edx,%edx
    342e:	88 90 b6 00 00 00    	mov    %dl,0xb6(%rax)
    3434:	48 8b 51 58          	mov    0x58(%rcx),%rdx
    3438:	48 85 d2             	test   %rdx,%rdx
    343b:	74 0d                	je     344a <f_8001161d0+0x344a>
    343d:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3444:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    3448:	eb 02                	jmp    344c <f_8001161d0+0x344c>
    344a:	31 d2                	xor    %edx,%edx
    344c:	88 90 b7 00 00 00    	mov    %dl,0xb7(%rax)
    3452:	48 8b 49 60          	mov    0x60(%rcx),%rcx
    3456:	48 85 c9             	test   %rcx,%rcx
    3459:	74 10                	je     346b <f_8001161d0+0x346b>
    345b:	0f b6 89 c0 00 00 00 	movzbl 0xc0(%rcx),%ecx
    3462:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    3466:	e9 57 f8 ff ff       	jmp    2cc2 <f_8001161d0+0x2cc2>
    346b:	31 c9                	xor    %ecx,%ecx
    346d:	e9 50 f8 ff ff       	jmp    2cc2 <f_8001161d0+0x2cc2>
    3472:	48 8b 87 b0 00 00 00 	mov    0xb0(%rdi),%rax
    3479:	8b 08                	mov    (%rax),%ecx
    347b:	45 8b 90 90 3b 00 00 	mov    0x3b90(%r8),%r10d
    3482:	45 8b 88 94 3b 00 00 	mov    0x3b94(%r8),%r9d
    3489:	41 83 fa 01          	cmp    $0x1,%r10d
    348d:	44 89 d6             	mov    %r10d,%esi
    3490:	83 d6 00             	adc    $0x0,%esi
    3493:	89 c8                	mov    %ecx,%eax
    3495:	31 d2                	xor    %edx,%edx
    3497:	f7 f6                	div    %esi
    3499:	89 c6                	mov    %eax,%esi
    349b:	45 85 d2             	test   %r10d,%r10d
    349e:	41 0f 44 f2          	cmove  %r10d,%esi
    34a2:	4c 89 4f 48          	mov    %r9,0x48(%rdi)
    34a6:	31 d2                	xor    %edx,%edx
    34a8:	41 89 f2             	mov    %esi,%r10d
    34ab:	45 31 ca             	xor    %r9d,%r10d
    34ae:	0f 94 c2             	sete   %dl
    34b1:	45 31 db             	xor    %r11d,%r11d
    34b4:	89 f0                	mov    %esi,%eax
    34b6:	44 29 c8             	sub    %r9d,%eax
    34b9:	41 0f 93 c3          	setae  %r11b
    34bd:	89 f3                	mov    %esi,%ebx
    34bf:	31 c3                	xor    %eax,%ebx
    34c1:	44 21 d3             	and    %r10d,%ebx
    34c4:	41 89 c2             	mov    %eax,%r10d
    34c7:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    34ce:	c1 e2 1e             	shl    $0x1e,%edx
    34d1:	41 c1 e3 1d          	shl    $0x1d,%r11d
    34d5:	41 09 d3             	or     %edx,%r11d
    34d8:	45 09 d3             	or     %r10d,%r11d
    34db:	31 d8                	xor    %ebx,%eax
    34dd:	c1 eb 03             	shr    $0x3,%ebx
    34e0:	81 e3 00 00 00 10    	and    $0x10000000,%ebx
    34e6:	44 09 db             	or     %r11d,%ebx
    34e9:	48 89 9f 10 01 00 00 	mov    %rbx,0x110(%rdi)
    34f0:	a9 00 00 00 80       	test   $0x80000000,%eax
    34f5:	49 0f 44 f1          	cmove  %r9,%rsi
    34f9:	48 89 77 40          	mov    %rsi,0x40(%rdi)
    34fd:	48 85 f6             	test   %rsi,%rsi
    3500:	0f 84 c2 f9 ff ff    	je     2ec8 <f_8001161d0+0x2ec8>
    3506:	48 89 8f 88 00 00 00 	mov    %rcx,0x88(%rdi)
    350d:	31 d2                	xor    %edx,%edx
    350f:	89 f0                	mov    %esi,%eax
    3511:	ff c8                	dec    %eax
    3513:	0f 94 c2             	sete   %dl
    3516:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
    351c:	49 81 c2 01 00 00 80 	add    $0xffffffff80000001,%r10
    3523:	45 31 c9             	xor    %r9d,%r9d
    3526:	4c 89 d3             	mov    %r10,%rbx
    3529:	4c 39 d6             	cmp    %r10,%rsi
    352c:	41 0f 94 c1          	sete   %r9b
    3530:	41 89 c2             	mov    %eax,%r10d
    3533:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    353a:	c1 e2 1e             	shl    $0x1e,%edx
    353d:	44 09 d2             	or     %r10d,%edx
    3540:	45 89 ca             	mov    %r9d,%r10d
    3543:	41 c1 e2 1c          	shl    $0x1c,%r10d
    3547:	41 09 d2             	or     %edx,%r10d
    354a:	49 81 ca 00 00 00 20 	or     $0x20000000,%r10
    3551:	4c 89 97 10 01 00 00 	mov    %r10,0x110(%rdi)
    3558:	48 89 47 48          	mov    %rax,0x48(%rdi)
    355c:	48 89 4f 60          	mov    %rcx,0x60(%rdi)
    3560:	c1 e8 1f             	shr    $0x1f,%eax
    3563:	41 30 c1             	xor    %al,%r9b
    3566:	0f 85 5c f9 ff ff    	jne    2ec8 <f_8001161d0+0x2ec8>
    356c:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    3572:	49 31 f1             	xor    %rsi,%r9
    3575:	41 ba 00 00 00 80    	mov    $0x80000000,%r10d
    357b:	49 31 ca             	xor    %rcx,%r10
    357e:	4c 89 d0             	mov    %r10,%rax
    3581:	4c 09 c8             	or     %r9,%rax
    3584:	b8 01 00 00 00       	mov    $0x1,%eax
    3589:	41 89 f3             	mov    %esi,%r11d
    358c:	44 0f 44 d8          	cmove  %eax,%r11d
    3590:	89 c8                	mov    %ecx,%eax
    3592:	99                   	cltd
    3593:	41 f7 fb             	idiv   %r11d
    3596:	4d 09 ca             	or     %r9,%r10
    3599:	89 c2                	mov    %eax,%edx
    359b:	0f 44 d1             	cmove  %ecx,%edx
    359e:	48 0f 44 c3          	cmove  %rbx,%rax
    35a2:	4c 8d 4f 50          	lea    0x50(%rdi),%r9
    35a6:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    35aa:	c4 c1 78 29 01       	vmovaps %xmm0,(%r9)
    35af:	4d 8d 88 80 3b 00 00 	lea    0x3b80(%r8),%r9
    35b6:	4c 89 4f 70          	mov    %r9,0x70(%rdi)
    35ba:	48 c7 47 78 28 00 00 	movq   $0x28,0x78(%rdi)
    35c1:	00 
    35c2:	48 c7 87 80 00 00 00 	movq   $0x3dcccccd,0x80(%rdi)
    35c9:	cd cc cc 3d 
    35cd:	0f af f2             	imul   %edx,%esi
    35d0:	29 f1                	sub    %esi,%ecx
    35d2:	48 89 4f 60          	mov    %rcx,0x60(%rdi)
    35d6:	49 81 c0 78 3b 00 00 	add    $0x3b78,%r8
    35dd:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    35e1:	48 89 87 88 00 00 00 	mov    %rax,0x88(%rdi)
    35e8:	31 c9                	xor    %ecx,%ecx
    35ea:	c5 f0 57 c9          	vxorps %xmm1,%xmm1,%xmm1
    35ee:	c5 fa 10 15 00 00 00 	vmovss 0x0(%rip),%xmm2        # 35f6 <f_8001161d0+0x35f6>
    35f5:	00 
    35f6:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    35fb:	c4 e2 79 59 1d 00 00 	vpbroadcastq 0x0(%rip),%xmm3        # 3604 <f_8001161d0+0x3604>
    3602:	00 00 
    3604:	48 be 00 00 00 00 f8 	movabs $0xfffffff800000000,%rsi
    360b:	ff ff ff 
    360e:	eb 7a                	jmp    368a <f_8001161d0+0x368a>
    3610:	c4 e3 e1 22 a7 88 00 	vpinsrq $0x1,0x88(%rdi),%xmm3,%xmm4
    3617:	00 00 01 
    361a:	c5 d9 d4 67 50       	vpaddq 0x50(%rdi),%xmm4,%xmm4
    361f:	c5 f9 7e e0          	vmovd  %xmm4,%eax
    3623:	44 8b 47 40          	mov    0x40(%rdi),%r8d
    3627:	45 31 c9             	xor    %r9d,%r9d
    362a:	41 89 c2             	mov    %eax,%r10d
    362d:	45 31 c2             	xor    %r8d,%r10d
    3630:	41 0f 94 c1          	sete   %r9b
    3634:	45 31 db             	xor    %r11d,%r11d
    3637:	89 c3                	mov    %eax,%ebx
    3639:	44 29 c3             	sub    %r8d,%ebx
    363c:	41 0f 93 c3          	setae  %r11b
    3640:	41 89 de             	mov    %ebx,%r14d
    3643:	41 31 c6             	xor    %eax,%r14d
    3646:	45 21 d6             	and    %r10d,%r14d
    3649:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    364f:	41 c1 e1 1e          	shl    $0x1e,%r9d
    3653:	41 c1 e3 1d          	shl    $0x1d,%r11d
    3657:	45 09 cb             	or     %r9d,%r11d
    365a:	41 09 db             	or     %ebx,%r11d
    365d:	41 c1 ee 03          	shr    $0x3,%r14d
    3661:	41 81 e6 00 00 00 10 	and    $0x10000000,%r14d
    3668:	45 09 de             	or     %r11d,%r14d
    366b:	44 31 c0             	xor    %r8d,%eax
    366e:	c4 e3 59 02 e0 0a    	vpblendd $0xa,%xmm0,%xmm4,%xmm4
    3674:	c5 f9 7f 67 50       	vmovdqa %xmm4,0x50(%rdi)
    3679:	4c 89 b7 10 01 00 00 	mov    %r14,0x110(%rdi)
    3680:	0f 84 42 f8 ff ff    	je     2ec8 <f_8001161d0+0x2ec8>
    3686:	4c 8b 47 68          	mov    0x68(%rdi),%r8
    368a:	41 8b 00             	mov    (%r8),%eax
    368d:	48 89 87 90 00 00 00 	mov    %rax,0x90(%rdi)
    3694:	44 8d 40 01          	lea    0x1(%rax),%r8d
    3698:	4c 89 07             	mov    %r8,(%rdi)
    369b:	4c 8b 4f 68          	mov    0x68(%rdi),%r9
    369f:	45 31 d2             	xor    %r10d,%r10d
    36a2:	f0 45 0f b1 01       	lock cmpxchg %r8d,(%r9)
    36a7:	41 0f 95 c2          	setne  %r10b
    36ab:	4c 89 57 08          	mov    %r10,0x8(%rdi)
    36af:	75 d5                	jne    3686 <f_8001161d0+0x3686>
    36b1:	4c 8b 9f a0 00 00 00 	mov    0xa0(%rdi),%r11
    36b8:	8b 47 50             	mov    0x50(%rdi),%eax
    36bb:	3b 47 48             	cmp    0x48(%rdi),%eax
    36be:	44 8b 47 60          	mov    0x60(%rdi),%r8d
    36c2:	4c 0f 45 c1          	cmovne %rcx,%r8
    36c6:	4d 8b 93 70 3b 00 00 	mov    0x3b70(%r11),%r10
    36cd:	4c 8b 8f 90 00 00 00 	mov    0x90(%rdi),%r9
    36d4:	b8 00 00 00 00       	mov    $0x0,%eax
    36d9:	45 39 8b 68 3b 00 00 	cmp    %r9d,0x3b68(%r11)
    36e0:	76 1a                	jbe    36fc <f_8001161d0+0x36fc>
    36e2:	45 89 c9             	mov    %r9d,%r9d
    36e5:	49 63 c1             	movslq %r9d,%rax
    36e8:	48 c1 f8 1f          	sar    $0x1f,%rax
    36ec:	49 bb 00 00 00 00 ff 	movabs $0xffffffff00000000,%r11
    36f3:	ff ff ff 
    36f6:	4c 21 d8             	and    %r11,%rax
    36f9:	4c 09 c8             	or     %r9,%rax
    36fc:	48 89 47 08          	mov    %rax,0x8(%rdi)
    3700:	4c 03 87 88 00 00 00 	add    0x88(%rdi),%r8
    3707:	45 89 c1             	mov    %r8d,%r9d
    370a:	4c 89 8f 88 00 00 00 	mov    %r9,0x88(%rdi)
    3711:	48 98                	cltq
    3713:	4c 63 5f 78          	movslq 0x78(%rdi),%r11
    3717:	4c 0f af d8          	imul   %rax,%r11
    371b:	4b 8d 04 13          	lea    (%r11,%r10,1),%rax
    371f:	48 89 87 90 00 00 00 	mov    %rax,0x90(%rdi)
    3726:	8b 5f 58             	mov    0x58(%rdi),%ebx
    3729:	4d 89 c6             	mov    %r8,%r14
    372c:	49 c1 e6 20          	shl    $0x20,%r14
    3730:	49 09 de             	or     %rbx,%r14
    3733:	48 8b 9f 98 00 00 00 	mov    0x98(%rdi),%rbx
    373a:	4b 89 1c 13          	mov    %rbx,(%r11,%r10,1)
    373e:	48 8b 9f b8 00 00 00 	mov    0xb8(%rdi),%rbx
    3745:	4b 89 5c 13 08       	mov    %rbx,0x8(%r11,%r10,1)
    374a:	48 8b 9f a8 00 00 00 	mov    0xa8(%rdi),%rbx
    3751:	4b 89 5c 13 10       	mov    %rbx,0x10(%r11,%r10,1)
    3756:	4f 89 74 13 18       	mov    %r14,0x18(%r11,%r10,1)
    375b:	44 8b 93 bc 00 00 00 	mov    0xbc(%rbx),%r10d
    3762:	31 db                	xor    %ebx,%ebx
    3764:	45 89 d3             	mov    %r10d,%r11d
    3767:	41 83 c3 fe          	add    $0xfffffffe,%r11d
    376b:	0f 94 c3             	sete   %bl
    376e:	31 ed                	xor    %ebp,%ebp
    3770:	41 be 01 00 00 00    	mov    $0x1,%r14d
    3776:	45 29 d6             	sub    %r10d,%r14d
    3779:	40 0f 92 c5          	setb   %bpl
    377d:	45 21 d6             	and    %r10d,%r14d
    3780:	45 89 df             	mov    %r11d,%r15d
    3783:	41 81 e7 00 00 00 80 	and    $0x80000000,%r15d
    378a:	c1 e3 1e             	shl    $0x1e,%ebx
    378d:	c1 e5 1d             	shl    $0x1d,%ebp
    3790:	44 09 fd             	or     %r15d,%ebp
    3793:	09 dd                	or     %ebx,%ebp
    3795:	41 c1 ee 03          	shr    $0x3,%r14d
    3799:	41 81 e6 00 00 00 10 	and    $0x10000000,%r14d
    37a0:	41 09 ee             	or     %ebp,%r14d
    37a3:	4c 89 b7 10 01 00 00 	mov    %r14,0x110(%rdi)
    37aa:	45 85 db             	test   %r11d,%r11d
    37ad:	0f 84 aa 00 00 00    	je     385d <f_8001161d0+0x385d>
    37b3:	45 31 db             	xor    %r11d,%r11d
    37b6:	44 89 d3             	mov    %r10d,%ebx
    37b9:	f7 db                	neg    %ebx
    37bb:	41 0f 90 c3          	seto   %r11b
    37bf:	31 db                	xor    %ebx,%ebx
    37c1:	31 ed                	xor    %ebp,%ebp
    37c3:	45 89 d6             	mov    %r10d,%r14d
    37c6:	41 83 ee 01          	sub    $0x1,%r14d
    37ca:	0f 94 c3             	sete   %bl
    37cd:	40 0f 93 c5          	setae  %bpl
    37d1:	41 81 e6 00 00 00 80 	and    $0x80000000,%r14d
    37d8:	c1 e3 1e             	shl    $0x1e,%ebx
    37db:	c1 e5 1d             	shl    $0x1d,%ebp
    37de:	41 c1 e3 1c          	shl    $0x1c,%r11d
    37e2:	41 09 eb             	or     %ebp,%r11d
    37e5:	45 09 f3             	or     %r14d,%r11d
    37e8:	41 09 db             	or     %ebx,%r11d
    37eb:	4c 89 9f 10 01 00 00 	mov    %r11,0x110(%rdi)
    37f2:	41 83 fa 01          	cmp    $0x1,%r10d
    37f6:	0f 84 b9 00 00 00    	je     38b5 <f_8001161d0+0x38b5>
    37fc:	31 db                	xor    %ebx,%ebx
    37fe:	45 89 d3             	mov    %r10d,%r11d
    3801:	41 83 c3 fd          	add    $0xfffffffd,%r11d
    3805:	0f 94 c3             	sete   %bl
    3808:	31 ed                	xor    %ebp,%ebp
    380a:	41 be 02 00 00 00    	mov    $0x2,%r14d
    3810:	45 29 d6             	sub    %r10d,%r14d
    3813:	40 0f 92 c5          	setb   %bpl
    3817:	45 21 d6             	and    %r10d,%r14d
    381a:	45 89 da             	mov    %r11d,%r10d
    381d:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    3824:	c1 e3 1e             	shl    $0x1e,%ebx
    3827:	c1 e5 1d             	shl    $0x1d,%ebp
    382a:	44 09 d5             	or     %r10d,%ebp
    382d:	09 dd                	or     %ebx,%ebp
    382f:	41 c1 ee 03          	shr    $0x3,%r14d
    3833:	41 81 e6 00 00 00 10 	and    $0x10000000,%r14d
    383a:	41 09 ee             	or     %ebp,%r14d
    383d:	4c 89 b7 10 01 00 00 	mov    %r14,0x110(%rdi)
    3844:	4c 89 4f 10          	mov    %r9,0x10(%rdi)
    3848:	45 85 db             	test   %r11d,%r11d
    384b:	0f 85 ab 00 00 00    	jne    38fc <f_8001161d0+0x38fc>
    3851:	45 01 c0             	add    %r8d,%r8d
    3854:	47 8d 0c 80          	lea    (%r8,%r8,4),%r9d
    3858:	e9 9b 00 00 00       	jmp    38f8 <f_8001161d0+0x38f8>
    385d:	c4 c1 02 2a e0       	vcvtsi2ss %r8d,%xmm15,%xmm4
    3862:	4c 8b 87 80 00 00 00 	mov    0x80(%rdi),%r8
    3869:	45 89 c1             	mov    %r8d,%r9d
    386c:	4c 89 8f 10 02 00 00 	mov    %r9,0x210(%rdi)
    3873:	48 c7 87 18 02 00 00 	movq   $0x0,0x218(%rdi)
    387a:	00 00 00 00 
    387e:	c4 c1 79 6e e8       	vmovd  %r8d,%xmm5
    3883:	c5 da 59 e5          	vmulss %xmm5,%xmm4,%xmm4
    3887:	c4 c1 79 7e e0       	vmovd  %xmm4,%r8d
    388c:	4c 89 87 00 02 00 00 	mov    %r8,0x200(%rdi)
    3893:	c4 61 fa 2c cc       	vcvttss2si %xmm4,%r9
    3898:	48 c7 87 08 02 00 00 	movq   $0x0,0x208(%rdi)
    389f:	00 00 00 00 
    38a3:	c5 f8 2e e1          	vucomiss %xmm1,%xmm4
    38a7:	44 0f 42 c9          	cmovb  %ecx,%r9d
    38ab:	c5 f8 2e e2          	vucomiss %xmm2,%xmm4
    38af:	44 0f 47 ca          	cmova  %edx,%r9d
    38b3:	eb 43                	jmp    38f8 <f_8001161d0+0x38f8>
    38b5:	45 31 d2             	xor    %r10d,%r10d
    38b8:	4d 85 c9             	test   %r9,%r9
    38bb:	41 0f 94 c2          	sete   %r10b
    38bf:	45 89 c1             	mov    %r8d,%r9d
    38c2:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    38c9:	41 c1 e2 1e          	shl    $0x1e,%r10d
    38cd:	4d 01 d1             	add    %r10,%r9
    38d0:	49 81 c1 00 00 00 20 	add    $0x20000000,%r9
    38d7:	4c 89 8f 10 01 00 00 	mov    %r9,0x110(%rdi)
    38de:	45 89 c1             	mov    %r8d,%r9d
    38e1:	41 c1 e9 1f          	shr    $0x1f,%r9d
    38e5:	45 01 c1             	add    %r8d,%r9d
    38e8:	45 89 c8             	mov    %r9d,%r8d
    38eb:	41 d1 e8             	shr    $1,%r8d
    38ee:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    38f5:	45 09 c1             	or     %r8d,%r9d
    38f8:	4c 89 4f 10          	mov    %r9,0x10(%rdi)
    38fc:	48 89 07             	mov    %rax,(%rdi)
    38ff:	44 89 48 20          	mov    %r9d,0x20(%rax)
    3903:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    390a:	84 00 00 00 00 00 
    3910:	48 8b 47 70          	mov    0x70(%rdi),%rax
    3914:	8b 00                	mov    (%rax),%eax
    3916:	48 89 07             	mov    %rax,(%rdi)
    3919:	44 8d 40 01          	lea    0x1(%rax),%r8d
    391d:	4c 89 47 08          	mov    %r8,0x8(%rdi)
    3921:	4c 8b 4f 70          	mov    0x70(%rdi),%r9
    3925:	45 31 d2             	xor    %r10d,%r10d
    3928:	f0 45 0f b1 01       	lock cmpxchg %r8d,(%r9)
    392d:	41 0f 95 c2          	setne  %r10b
    3931:	4c 89 57 10          	mov    %r10,0x10(%rdi)
    3935:	75 d9                	jne    3910 <f_8001161d0+0x3910>
    3937:	48 8b 07             	mov    (%rdi),%rax
    393a:	4c 8b 87 a0 00 00 00 	mov    0xa0(%rdi),%r8
    3941:	45 8b 88 84 3b 00 00 	mov    0x3b84(%r8),%r9d
    3948:	45 89 ca             	mov    %r9d,%r10d
    394b:	41 31 c2             	xor    %eax,%r10d
    394e:	45 89 cb             	mov    %r9d,%r11d
    3951:	41 31 c3             	xor    %eax,%r11d
    3954:	4c 89 4f 08          	mov    %r9,0x8(%rdi)
    3958:	0f 84 b2 fc ff ff    	je     3610 <f_8001161d0+0x3610>
    395e:	45 89 cb             	mov    %r9d,%r11d
    3961:	41 29 c3             	sub    %eax,%r11d
    3964:	c4 42 28 f2 db       	andn   %r11d,%r10d,%r11d
    3969:	45 21 ca             	and    %r9d,%r10d
    396c:	45 09 da             	or     %r11d,%r10d
    396f:	0f 88 9b fc ff ff    	js     3610 <f_8001161d0+0x3610>
    3975:	4d 8b 80 88 3b 00 00 	mov    0x3b88(%r8),%r8
    397c:	4c 89 47 08          	mov    %r8,0x8(%rdi)
    3980:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    3987:	00 
    3988:	48 98                	cltq
    398a:	48 21 f0             	and    %rsi,%rax
    398d:	4d 8d 95 2e a2 3f fd 	lea    -0x2c05dd2(%r13),%r10
    3994:	4d 21 ca             	and    %r9,%r10
    3997:	49 09 c2             	or     %rax,%r10
    399a:	4c 89 17             	mov    %r10,(%rdi)
    399d:	48 8b 87 90 00 00 00 	mov    0x90(%rdi),%rax
    39a4:	4b 89 04 10          	mov    %rax,(%r8,%r10,1)
    39a8:	e9 63 fc ff ff       	jmp    3610 <f_8001161d0+0x3610>
