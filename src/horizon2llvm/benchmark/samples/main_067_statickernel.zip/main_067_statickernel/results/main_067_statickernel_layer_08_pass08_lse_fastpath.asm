
/home/leegao/meh/ultratears-main/src/horizon2llvm/benchmark/samples/main_067_statickernel/results/main_067_statickernel_layer_08_pass08_lse_fastpath.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <f_8001161d0>:
       0:	55                   	push   %rbp
       1:	41 57                	push   %r15
       3:	41 56                	push   %r14
       5:	41 55                	push   %r13
       7:	41 54                	push   %r12
       9:	53                   	push   %rbx
       a:	48 83 ec 18          	sub    $0x18,%rsp
       e:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
      15:	00 00 00 
      18:	48 8b 8f e8 00 00 00 	mov    0xe8(%rdi),%rcx
      1f:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
      26:	48 8d b0 d0 fe ff ff 	lea    -0x130(%rax),%rsi
      2d:	48 89 b7 00 01 00 00 	mov    %rsi,0x100(%rdi)
      34:	48 8d 50 a0          	lea    -0x60(%rax),%rdx
      38:	48 89 48 a0          	mov    %rcx,-0x60(%rax)
      3c:	48 8b 8f f0 00 00 00 	mov    0xf0(%rdi),%rcx
      43:	48 89 48 a8          	mov    %rcx,-0x58(%rax)
      47:	48 8b 8f e0 00 00 00 	mov    0xe0(%rdi),%rcx
      4e:	48 89 48 b0          	mov    %rcx,-0x50(%rax)
      52:	48 8b 8f d8 00 00 00 	mov    0xd8(%rdi),%rcx
      59:	48 89 48 b8          	mov    %rcx,-0x48(%rax)
      5d:	48 8b 8f d0 00 00 00 	mov    0xd0(%rdi),%rcx
      64:	48 89 48 c0          	mov    %rcx,-0x40(%rax)
      68:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
      6f:	48 89 48 c8          	mov    %rcx,-0x38(%rax)
      73:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
      7a:	48 89 48 d0          	mov    %rcx,-0x30(%rax)
      7e:	48 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%rcx
      85:	48 89 48 d8          	mov    %rcx,-0x28(%rax)
      89:	48 8b 8f b0 00 00 00 	mov    0xb0(%rdi),%rcx
      90:	48 89 48 e0          	mov    %rcx,-0x20(%rax)
      94:	48 8b 8f a8 00 00 00 	mov    0xa8(%rdi),%rcx
      9b:	48 89 48 e8          	mov    %rcx,-0x18(%rax)
      9f:	48 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%rcx
      a6:	48 89 48 f0          	mov    %rcx,-0x10(%rax)
      aa:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
      b1:	48 89 48 f8          	mov    %rcx,-0x8(%rax)
      b5:	48 89 97 e8 00 00 00 	mov    %rdx,0xe8(%rdi)
      bc:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
      c0:	48 89 9f a8 00 00 00 	mov    %rbx,0xa8(%rdi)
      c7:	4c 8b 3f             	mov    (%rdi),%r15
      ca:	4c 8b 77 08          	mov    0x8(%rdi),%r14
      ce:	4c 89 b7 98 00 00 00 	mov    %r14,0x98(%rdi)
      d5:	4c 89 bf a0 00 00 00 	mov    %r15,0xa0(%rdi)
      dc:	49 8d 8e 14 29 00 00 	lea    0x2914(%r14),%rcx
      e3:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
      e7:	83 fb 20             	cmp    $0x20,%ebx
      ea:	73 1d                	jae    109 <f_8001161d0+0x109>
      ec:	b9 1f 7d c3 f6       	mov    $0xf6c37d1f,%ecx
      f1:	0f a3 d9             	bt     %ebx,%ecx
      f4:	73 13                	jae    109 <f_8001161d0+0x109>
      f6:	89 d9                	mov    %ebx,%ecx
      f8:	83 e1 1f             	and    $0x1f,%ecx
      fb:	49 8b 8c cd be 6b 16 	mov    0x166bbe(%r13,%rcx,8),%rcx
     102:	00 
     103:	48 c1 e1 08          	shl    $0x8,%rcx
     107:	eb 0e                	jmp    117 <f_8001161d0+0x117>
     109:	31 d2                	xor    %edx,%edx
     10b:	83 fb 12             	cmp    $0x12,%ebx
     10e:	b9 00 03 00 00       	mov    $0x300,%ecx
     113:	48 0f 45 ca          	cmovne %rdx,%rcx
     117:	49 bb 00 00 00 00 ff 	movabs $0xffffffff00000000,%r11
     11e:	ff ff ff 
     121:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     128:	ff 7f ff 
     12b:	41 0f be 96 17 29 00 	movsbl 0x2917(%r14),%edx
     132:	00 
     133:	48 63 d2             	movslq %edx,%rdx
     136:	48 89 b7 c0 00 00 00 	mov    %rsi,0xc0(%rdi)
     13d:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
     142:	48 69 f2 48 07 00 00 	imul   $0x748,%rdx,%rsi
     149:	45 31 c9             	xor    %r9d,%r9d
     14c:	41 39 97 90 33 00 00 	cmp    %edx,0x3390(%r15)
     153:	48 bd ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rbp
     15a:	ff 7f 7f 
     15d:	4c 0f 47 ce          	cmova  %rsi,%r9
     161:	49 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r10
     168:	00 80 3f 
     16b:	48 be 00 00 00 00 01 	movabs $0x100000000,%rsi
     172:	00 00 00 
     175:	4d 03 8f 98 33 00 00 	add    0x3398(%r15),%r9
     17c:	48 c7 47 70 ff ff ff 	movq   $0xffffffffffffffff,0x70(%rdi)
     183:	ff 
     184:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 18c <f_8001161d0+0x18c>
     18b:	00 
     18c:	c5 fc 11 80 d0 fe ff 	vmovups %ymm0,-0x130(%rax)
     193:	ff 
     194:	ba ff ff ff ff       	mov    $0xffffffff,%edx
     199:	48 89 57 78          	mov    %rdx,0x78(%rdi)
     19d:	48 89 b0 f0 fe ff ff 	mov    %rsi,-0x110(%rax)
     1a4:	4c 89 98 f8 fe ff ff 	mov    %r11,-0x108(%rax)
     1ab:	4a 8d 8c 09 e8 01 00 	lea    0x1e8(%rcx,%r9,1),%rcx
     1b2:	00 
     1b3:	48 89 8f b8 00 00 00 	mov    %rcx,0xb8(%rdi)
     1ba:	48 89 90 00 ff ff ff 	mov    %rdx,-0x100(%rax)
     1c1:	4c 89 90 08 ff ff ff 	mov    %r10,-0xf8(%rax)
     1c8:	48 89 6f 58          	mov    %rbp,0x58(%rdi)
     1cc:	31 d2                	xor    %edx,%edx
     1ce:	89 de                	mov    %ebx,%esi
     1d0:	83 c6 df             	add    $0xffffffdf,%esi
     1d3:	0f 94 c2             	sete   %dl
     1d6:	31 c9                	xor    %ecx,%ecx
     1d8:	83 fb 21             	cmp    $0x21,%ebx
     1db:	0f 93 c1             	setae  %cl
     1de:	41 b9 20 00 00 00    	mov    $0x20,%r9d
     1e4:	41 29 d9             	sub    %ebx,%r9d
     1e7:	41 21 d9             	and    %ebx,%r9d
     1ea:	81 e6 00 00 00 80    	and    $0x80000000,%esi
     1f0:	c1 e2 1e             	shl    $0x1e,%edx
     1f3:	c1 e1 1d             	shl    $0x1d,%ecx
     1f6:	09 f1                	or     %esi,%ecx
     1f8:	09 d1                	or     %edx,%ecx
     1fa:	41 c1 e9 03          	shr    $0x3,%r9d
     1fe:	41 81 e1 00 00 00 10 	and    $0x10000000,%r9d
     205:	41 09 c9             	or     %ecx,%r9d
     208:	4c 89 8f 10 01 00 00 	mov    %r9,0x110(%rdi)
     20f:	4c 89 90 10 ff ff ff 	mov    %r10,-0xf0(%rax)
     216:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     21d:	00 00 00 00 
     221:	4d 8b 8d 7e 86 d5 00 	mov    0xd5867e(%r13),%r9
     228:	4c 89 4f 50          	mov    %r9,0x50(%rdi)
     22c:	49 8b 95 ae 5d d4 00 	mov    0xd45dae(%r13),%rdx
     233:	48 89 57 48          	mov    %rdx,0x48(%rdi)
     237:	49 8d 71 10          	lea    0x10(%r9),%rsi
     23b:	48 89 b0 20 ff ff ff 	mov    %rsi,-0xe0(%rax)
     242:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
     249:	4d 8b a5 b6 7e d5 00 	mov    0xd57eb6(%r13),%r12
     250:	4c 89 67 60          	mov    %r12,0x60(%rdi)
     254:	49 83 c4 10          	add    $0x10,%r12
     258:	4c 89 a7 80 00 00 00 	mov    %r12,0x80(%rdi)
     25f:	48 89 a8 48 ff ff ff 	mov    %rbp,-0xb8(%rax)
     266:	4c 89 80 50 ff ff ff 	mov    %r8,-0xb0(%rax)
     26d:	49 8d 92 00 00 80 c0 	lea    -0x3f800000(%r10),%rdx
     274:	48 89 90 74 ff ff ff 	mov    %rdx,-0x8c(%rax)
     27b:	4d 8b 95 c6 7d d5 00 	mov    0xd57dc6(%r13),%r10
     282:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
     289:	45 8b 1a             	mov    (%r10),%r11d
     28c:	4c 89 5f 40          	mov    %r11,0x40(%rdi)
     290:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
     295:	4c 89 a0 58 ff ff ff 	mov    %r12,-0xa8(%rax)
     29c:	48 89 a8 60 ff ff ff 	mov    %rbp,-0xa0(%rax)
     2a3:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     2aa:	00 
     2ab:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     2af:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     2b6:	44 89 98 70 ff ff ff 	mov    %r11d,-0x90(%rax)
     2bd:	81 e1 00 00 00 60    	and    $0x60000000,%ecx
     2c3:	81 f9 00 00 00 20    	cmp    $0x20000000,%ecx
     2c9:	0f 84 5a 29 00 00    	je     2c29 <f_8001161d0+0x2c29>
     2cf:	48 89 f5             	mov    %rsi,%rbp
     2d2:	48 89 14 24          	mov    %rdx,(%rsp)
     2d6:	48 8d b0 48 ff ff ff 	lea    -0xb8(%rax),%rsi
     2dd:	4c 8d 90 60 ff ff ff 	lea    -0xa0(%rax),%r10
     2e4:	48 8d 50 80          	lea    -0x80(%rax),%rdx
     2e8:	4c 8d 80 70 ff ff ff 	lea    -0x90(%rax),%r8
     2ef:	49 8d 8d 76 6b 16 00 	lea    0x166b76(%r13),%rcx
     2f6:	48 89 8f 88 00 00 00 	mov    %rcx,0x88(%rdi)
     2fd:	89 db                	mov    %ebx,%ebx
     2ff:	48 89 9f 90 00 00 00 	mov    %rbx,0x90(%rdi)
     306:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
     30b:	48 89 8f 80 00 00 00 	mov    %rcx,0x80(%rdi)
     312:	41 0f b7 8c 5d 76 6b 	movzwl 0x166b76(%r13,%rbx,2),%ecx
     319:	16 00 
     31b:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
     31f:	4d 8d a4 8d 52 05 51 	lea    -0x2aefaae(%r13,%rcx,4),%r12
     326:	fd 
     327:	4d 89 d5             	mov    %r10,%r13
     32a:	4c 89 27             	mov    %r12,(%rdi)
     32d:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
     332:	48 89 77 48          	mov    %rsi,0x48(%rdi)
     336:	4c 89 97 d0 00 00 00 	mov    %r10,0xd0(%rdi)
     33d:	4c 89 87 c8 00 00 00 	mov    %r8,0xc8(%rdi)
     344:	48 89 97 d8 00 00 00 	mov    %rdx,0xd8(%rdi)
     34b:	81 f9 86 02 00 00    	cmp    $0x286,%ecx
     351:	7f 66                	jg     3b9 <f_8001161d0+0x3b9>
     353:	81 f9 2d 01 00 00    	cmp    $0x12d,%ecx
     359:	0f 8f f3 00 00 00    	jg     452 <f_8001161d0+0x452>
     35f:	83 f9 6f             	cmp    $0x6f,%ecx
     362:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     369:	ff 7f ff 
     36c:	4d 89 da             	mov    %r11,%r10
     36f:	0f 8f d3 03 00 00    	jg     748 <f_8001161d0+0x748>
     375:	83 f9 04             	cmp    $0x4,%ecx
     378:	0f 87 51 10 00 00    	ja     13cf <f_8001161d0+0x13cf>
     37e:	89 c9                	mov    %ecx,%ecx
     380:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 387 <f_8001161d0+0x387>
     387:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
     38b:	48 01 d1             	add    %rdx,%rcx
     38e:	ff e1                	jmp    *%rcx
     390:	41 0f b7 9f e4 0c 00 	movzwl 0xce4(%r15),%ebx
     397:	00 
     398:	8b 8f a8 00 00 00    	mov    0xa8(%rdi),%ecx
     39e:	ba ff ff ff ff       	mov    $0xffffffff,%edx
     3a3:	01 d1                	add    %edx,%ecx
     3a5:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
     3a9:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
     3b0:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
     3b4:	e9 0f 15 00 00       	jmp    18c8 <f_8001161d0+0x18c8>
     3b9:	81 f9 6d 04 00 00    	cmp    $0x46d,%ecx
     3bf:	0f 8e 32 02 00 00    	jle    5f7 <f_8001161d0+0x5f7>
     3c5:	44 8d 89 92 fb ff ff 	lea    -0x46e(%rcx),%r9d
     3cc:	41 83 f9 0c          	cmp    $0xc,%r9d
     3d0:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     3d7:	ff 7f ff 
     3da:	48 89 ee             	mov    %rbp,%rsi
     3dd:	4d 89 da             	mov    %r11,%r10
     3e0:	0f 86 81 07 00 00    	jbe    b67 <f_8001161d0+0xb67>
     3e6:	44 8d 89 36 fb ff ff 	lea    -0x4ca(%rcx),%r9d
     3ed:	41 83 f9 16          	cmp    $0x16,%r9d
     3f1:	0f 87 7c 0f 00 00    	ja     1373 <f_8001161d0+0x1373>
     3f7:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 3fe <f_8001161d0+0x3fe>
     3fe:	4a 63 14 89          	movslq (%rcx,%r9,4),%rdx
     402:	48 01 ca             	add    %rcx,%rdx
     405:	ff e2                	jmp    *%rdx
     407:	48 c7 47 40 b0 1e 00 	movq   $0x1eb0,0x40(%rdi)
     40e:	00 
     40f:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
     416:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
     41d:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
     421:	48 89 47 10          	mov    %rax,0x10(%rdi)
     425:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
     42a:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
     431:	48 89 07             	mov    %rax,(%rdi)
     434:	48 c7 47 18 01 00 00 	movq   $0x1,0x18(%rdi)
     43b:	00 
     43c:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     443:	00 00 00 
     446:	49 8d 85 92 18 51 fd 	lea    -0x2aee76e(%r13),%rax
     44d:	e9 1a 18 00 00       	jmp    1c6c <f_8001161d0+0x1c6c>
     452:	81 f9 c7 01 00 00    	cmp    $0x1c7,%ecx
     458:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     45f:	ff 7f ff 
     462:	4d 89 da             	mov    %r11,%r10
     465:	0f 8f ac 05 00 00    	jg     a17 <f_8001161d0+0xa17>
     46b:	81 f9 b1 01 00 00    	cmp    $0x1b1,%ecx
     471:	0f 8f 1d 0a 00 00    	jg     e94 <f_8001161d0+0xe94>
     477:	81 f9 2e 01 00 00    	cmp    $0x12e,%ecx
     47d:	0f 84 97 1d 00 00    	je     221a <f_8001161d0+0x221a>
     483:	81 f9 66 01 00 00    	cmp    $0x166,%ecx
     489:	0f 85 7a 17 00 00    	jne    1c09 <f_8001161d0+0x1c09>
     48f:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
     496:	48 8b 97 a0 00 00 00 	mov    0xa0(%rdi),%rdx
     49d:	48 8b 92 c8 1e 00 00 	mov    0x1ec8(%rdx),%rdx
     4a4:	48 89 57 08          	mov    %rdx,0x8(%rdi)
     4a8:	48 c7 87 80 00 00 00 	movq   $0x3ce0,0x80(%rdi)
     4af:	e0 3c 00 00 
     4b3:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
     4b8:	48 89 77 60          	mov    %rsi,0x60(%rdi)
     4bc:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
     4c0:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
     4c4:	4c 69 c9 e0 3c 00 00 	imul   $0x3ce0,%rcx,%r9
     4cb:	31 db                	xor    %ebx,%ebx
     4cd:	39 4a 08             	cmp    %ecx,0x8(%rdx)
     4d0:	49 0f 47 d9          	cmova  %r9,%rbx
     4d4:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
     4d8:	48 8b 8c 0b 40 3c 00 	mov    0x3c40(%rbx,%rcx,1),%rcx
     4df:	00 
     4e0:	48 89 8f b0 00 00 00 	mov    %rcx,0xb0(%rdi)
     4e7:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
     4ee:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
     4f5:	48 89 b1 88 00 00 00 	mov    %rsi,0x88(%rcx)
     4fc:	48 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rdx
     503:	ff 7f 7f 
     506:	48 89 91 90 00 00 00 	mov    %rdx,0x90(%rcx)
     50d:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     514:	00 
     515:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     519:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
     520:	00 00 00 
     523:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
     52a:	00 
     52b:	48 89 69 50          	mov    %rbp,0x50(%rcx)
     52f:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     533:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
     538:	48 c7 41 30 08 00 00 	movq   $0x8,0x30(%rcx)
     53f:	00 
     540:	48 b8 10 00 00 00 03 	movabs $0x300000010,%rax
     547:	00 00 00 
     54a:	48 89 01             	mov    %rax,(%rcx)
     54d:	48 c7 41 08 00 00 00 	movq   $0x0,0x8(%rcx)
     554:	00 
     555:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     55c:	00 
     55d:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     564:	ff ff ff 
     567:	48 8d 42 0d          	lea    0xd(%rdx),%rax
     56b:	48 89 41 18          	mov    %rax,0x18(%rcx)
     56f:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     576:	00 00 00 
     579:	48 89 41 20          	mov    %rax,0x20(%rcx)
     57d:	48 89 51 28          	mov    %rdx,0x28(%rcx)
     581:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
     588:	48 8b 14 24          	mov    (%rsp),%rdx
     58c:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
     593:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
     59a:	00 80 3f 
     59d:	48 89 41 38          	mov    %rax,0x38(%rcx)
     5a1:	48 89 41 40          	mov    %rax,0x40(%rcx)
     5a5:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     5ac:	00 00 00 
     5af:	49 8d 85 8b 0d 02 00 	lea    0x20d8b(%r13),%rax
     5b6:	48 89 47 70          	mov    %rax,0x70(%rdi)
     5ba:	4c 89 47 78          	mov    %r8,0x78(%rdi)
     5be:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
     5c5:	48 8b 57 58          	mov    0x58(%rdi),%rdx
     5c9:	48 89 51 78          	mov    %rdx,0x78(%rcx)
     5cd:	4c 89 81 80 00 00 00 	mov    %r8,0x80(%rcx)
     5d4:	48 8d 97 80 00 00 00 	lea    0x80(%rdi),%rdx
     5db:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
     5e2:	00 
     5e3:	48 89 41 70          	mov    %rax,0x70(%rcx)
     5e7:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
     5eb:	8b 71 08             	mov    0x8(%rcx),%esi
     5ee:	48 89 77 40          	mov    %rsi,0x40(%rdi)
     5f2:	e9 96 1d 00 00       	jmp    238d <f_8001161d0+0x238d>
     5f7:	81 f9 d4 02 00 00    	cmp    $0x2d4,%ecx
     5fd:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     604:	ff 7f ff 
     607:	4d 89 da             	mov    %r11,%r10
     60a:	0f 8f ad 04 00 00    	jg     abd <f_8001161d0+0xabd>
     610:	81 f9 b5 02 00 00    	cmp    $0x2b5,%ecx
     616:	0f 8f 16 09 00 00    	jg     f32 <f_8001161d0+0xf32>
     61c:	81 f9 87 02 00 00    	cmp    $0x287,%ecx
     622:	0f 84 cc 1e 00 00    	je     24f4 <f_8001161d0+0x24f4>
     628:	81 f9 97 02 00 00    	cmp    $0x297,%ecx
     62e:	0f 85 d5 15 00 00    	jne    1c09 <f_8001161d0+0x1c09>
     634:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
     63b:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
     642:	48 c7 01 00 00 00 40 	movq   $0x40000000,(%rcx)
     649:	48 ba 00 00 00 00 00 	movabs $0x40000000000000,%rdx
     650:	00 40 00 
     653:	48 89 51 08          	mov    %rdx,0x8(%rcx)
     657:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     65e:	00 
     65f:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     666:	ff ff ff 
     669:	4d 89 c1             	mov    %r8,%r9
     66c:	49 89 d0             	mov    %rdx,%r8
     66f:	48 83 c2 14          	add    $0x14,%rdx
     673:	48 89 51 18          	mov    %rdx,0x18(%rcx)
     677:	48 89 6f 40          	mov    %rbp,0x40(%rdi)
     67b:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     67f:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     686:	00 
     687:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
     68e:	00 00 00 
     691:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     698:	00 00 00 
     69b:	48 89 41 20          	mov    %rax,0x20(%rcx)
     69f:	4c 89 41 28          	mov    %r8,0x28(%rcx)
     6a3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
     6a8:	48 89 41 30          	mov    %rax,0x30(%rcx)
     6ac:	49 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r8
     6b3:	00 80 3f 
     6b6:	4c 89 41 38          	mov    %r8,0x38(%rcx)
     6ba:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
     6c1:	00 00 00 
     6c4:	48 8d 80 80 0d 02 00 	lea    0x20d80(%rax),%rax
     6cb:	48 89 41 70          	mov    %rax,0x70(%rcx)
     6cf:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     6d6:	ff 7f 7f 
     6d9:	4c 89 51 78          	mov    %r10,0x78(%rcx)
     6dd:	4c 89 89 80 00 00 00 	mov    %r9,0x80(%rcx)
     6e4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
     6e9:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
     6f0:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 6f8 <f_8001161d0+0x6f8>
     6f7:	00 
     6f8:	c5 fc 11 47 60       	vmovups %ymm0,0x60(%rdi)
     6fd:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
     704:	48 8b 14 24          	mov    (%rsp),%rdx
     708:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
     70f:	4c 89 41 40          	mov    %r8,0x40(%rcx)
     713:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
     71a:	00 
     71b:	4c 89 91 90 00 00 00 	mov    %r10,0x90(%rcx)
     722:	4c 89 89 98 00 00 00 	mov    %r9,0x98(%rcx)
     729:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
     730:	00 
     731:	48 89 69 50          	mov    %rbp,0x50(%rcx)
     735:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     739:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
     73e:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
     743:	e9 c3 23 00 00       	jmp    2b0b <f_8001161d0+0x2b0b>
     748:	81 f9 c8 00 00 00    	cmp    $0xc8,%ecx
     74e:	0f 8f 36 04 00 00    	jg     b8a <f_8001161d0+0xb8a>
     754:	83 f9 70             	cmp    $0x70,%ecx
     757:	0f 84 c5 17 00 00    	je     1f22 <f_8001161d0+0x1f22>
     75d:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
     763:	0f 85 a0 14 00 00    	jne    1c09 <f_8001161d0+0x1c09>
     769:	49 8b 9f c8 1e 00 00 	mov    0x1ec8(%r15),%rbx
     770:	48 89 5f 08          	mov    %rbx,0x8(%rdi)
     774:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
     779:	48 89 77 60          	mov    %rsi,0x60(%rdi)
     77d:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
     784:	00 
     785:	45 0f b6 76 08       	movzbl 0x8(%r14),%r14d
     78a:	4c 89 77 68          	mov    %r14,0x68(%rdi)
     78e:	8b 53 08             	mov    0x8(%rbx),%edx
     791:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
     795:	4d 69 ce e0 3c 00 00 	imul   $0x3ce0,%r14,%r9
     79c:	31 c9                	xor    %ecx,%ecx
     79e:	44 39 f2             	cmp    %r14d,%edx
     7a1:	ba 00 00 00 00       	mov    $0x0,%edx
     7a6:	49 0f 47 d1          	cmova  %r9,%rdx
     7aa:	48 c7 47 70 e0 3c 00 	movq   $0x3ce0,0x70(%rdi)
     7b1:	00 
     7b2:	4a 8b 94 3a 40 3c 00 	mov    0x3c40(%rdx,%r15,1),%rdx
     7b9:	00 
     7ba:	48 89 97 b0 00 00 00 	mov    %rdx,0xb0(%rdi)
     7c1:	44 89 90 70 ff ff ff 	mov    %r10d,-0x90(%rax)
     7c8:	48 89 b0 58 ff ff ff 	mov    %rsi,-0xa8(%rax)
     7cf:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     7d6:	ff 7f 7f 
     7d9:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
     7e0:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     7e7:	00 
     7e8:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     7ec:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     7f3:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     7fa:	00 00 00 00 
     7fe:	48 89 a8 20 ff ff ff 	mov    %rbp,-0xe0(%rax)
     805:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     809:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
     810:	ff 
     811:	48 c7 80 00 ff ff ff 	movq   $0x5,-0x100(%rax)
     818:	05 00 00 00 
     81c:	48 be 10 00 00 00 03 	movabs $0x300000010,%rsi
     823:	00 00 00 
     826:	48 81 c6 f0 00 00 00 	add    $0xf0,%rsi
     82d:	48 89 b0 d0 fe ff ff 	mov    %rsi,-0x130(%rax)
     834:	48 be 00 00 00 00 00 	movabs $0x60000000000000,%rsi
     83b:	00 60 00 
     83e:	48 89 b0 d8 fe ff ff 	mov    %rsi,-0x128(%rax)
     845:	48 89 17             	mov    %rdx,(%rdi)
     848:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     84f:	ff ff 00 00 
     853:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     85a:	ff ff ff 
     85d:	48 8d 55 08          	lea    0x8(%rbp),%rdx
     861:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
     868:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
     86f:	00 00 00 
     872:	48 89 90 f0 fe ff ff 	mov    %rdx,-0x110(%rax)
     879:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
     880:	48 8b 97 c0 00 00 00 	mov    0xc0(%rdi),%rdx
     887:	48 8b 34 24          	mov    (%rsp),%rsi
     88b:	48 89 b2 a4 00 00 00 	mov    %rsi,0xa4(%rdx)
     892:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
     899:	00 80 3f 
     89c:	48 89 90 08 ff ff ff 	mov    %rdx,-0xf8(%rax)
     8a3:	48 89 90 10 ff ff ff 	mov    %rdx,-0xf0(%rax)
     8aa:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     8b1:	00 00 00 
     8b4:	49 8d 95 1d 54 09 00 	lea    0x9541d(%r13),%rdx
     8bb:	48 89 57 78          	mov    %rdx,0x78(%rdi)
     8bf:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
     8c6:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
     8cd:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
     8d4:	4c 89 80 50 ff ff ff 	mov    %r8,-0xb0(%rax)
     8db:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
     8e2:	00 00 00 00 
     8e6:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
     8ed:	44 39 73 08          	cmp    %r14d,0x8(%rbx)
     8f1:	ba 00 00 00 00       	mov    $0x0,%edx
     8f6:	49 0f 47 d1          	cmova  %r9,%rdx
     8fa:	48 8b 73 10          	mov    0x10(%rbx),%rsi
     8fe:	c5 f8 10 84 16 00 2e 	vmovups 0x2e00(%rsi,%rdx,1),%xmm0
     905:	00 00 
     907:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
     90e:	ff 
     90f:	8b 73 08             	mov    0x8(%rbx),%esi
     912:	45 31 c0             	xor    %r8d,%r8d
     915:	31 d2                	xor    %edx,%edx
     917:	41 89 f2             	mov    %esi,%r10d
     91a:	45 29 f2             	sub    %r14d,%r10d
     91d:	49 0f 47 c9          	cmova  %r9,%rcx
     921:	41 0f 94 c0          	sete   %r8b
     925:	0f 93 c2             	setae  %dl
     928:	41 c1 e0 1e          	shl    $0x1e,%r8d
     92c:	c1 e2 1d             	shl    $0x1d,%edx
     92f:	44 09 c2             	or     %r8d,%edx
     932:	c4 e2 28 f2 f6       	andn   %esi,%r10d,%esi
     937:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
     93e:	44 09 d2             	or     %r10d,%edx
     941:	4c 8b 43 10          	mov    0x10(%rbx),%r8
     945:	c1 ee 03             	shr    $0x3,%esi
     948:	81 e6 00 00 00 10    	and    $0x10000000,%esi
     94e:	09 d6                	or     %edx,%esi
     950:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
     957:	49 8b 94 08 80 30 00 	mov    0x3080(%r8,%rcx,1),%rdx
     95e:	00 
     95f:	49 8b b4 08 88 30 00 	mov    0x3088(%r8,%rcx,1),%rsi
     966:	00 
     967:	48 89 77 50          	mov    %rsi,0x50(%rdi)
     96b:	48 89 90 60 ff ff ff 	mov    %rdx,-0xa0(%rax)
     972:	48 89 b0 68 ff ff ff 	mov    %rsi,-0x98(%rax)
     979:	49 8b 94 08 90 30 00 	mov    0x3090(%r8,%rcx,1),%rdx
     980:	00 
     981:	48 89 57 48          	mov    %rdx,0x48(%rdi)
     985:	41 8b 8c 08 98 30 00 	mov    0x3098(%r8,%rcx,1),%ecx
     98c:	00 
     98d:	89 88 78 ff ff ff    	mov    %ecx,-0x88(%rax)
     993:	48 8b 8f e8 00 00 00 	mov    0xe8(%rdi),%rcx
     99a:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
     99e:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
     9a2:	48 89 90 70 ff ff ff 	mov    %rdx,-0x90(%rax)
     9a9:	49 8d 85 56 08 51 fd 	lea    -0x2aef7aa(%r13),%rax
     9b0:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
     9b7:	48 89 fb             	mov    %rdi,%rbx
     9ba:	c5 f8 77             	vzeroupper
     9bd:	e8 00 00 00 00       	call   9c2 <f_8001161d0+0x9c2>
     9c2:	48 89 df             	mov    %rbx,%rdi
     9c5:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     9cc:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
     9d3:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     9da:	48 89 01             	mov    %rax,(%rcx)
     9dd:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     9e4:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     9eb:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
     9ef:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
     9f6:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     9fa:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     a00:	48 89 43 40          	mov    %rax,0x40(%rbx)
     a04:	88 51 08             	mov    %dl,0x8(%rcx)
     a07:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     a0e:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
     a12:	e9 c3 1a 00 00       	jmp    24da <f_8001161d0+0x24da>
     a17:	81 f9 51 02 00 00    	cmp    $0x251,%ecx
     a1d:	0f 8f b3 05 00 00    	jg     fd6 <f_8001161d0+0xfd6>
     a23:	81 f9 c8 01 00 00    	cmp    $0x1c8,%ecx
     a29:	0f 84 4b 1b 00 00    	je     257a <f_8001161d0+0x257a>
     a2f:	81 f9 0f 02 00 00    	cmp    $0x20f,%ecx
     a35:	0f 85 ce 11 00 00    	jne    1c09 <f_8001161d0+0x1c09>
     a3b:	49 89 ec             	mov    %rbp,%r12
     a3e:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
     a45:	00 
     a46:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
     a4d:	48 c7 01 00 08 00 00 	movq   $0x800,(%rcx)
     a54:	48 c7 41 08 01 00 00 	movq   $0x1,0x8(%rcx)
     a5b:	00 
     a5c:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     a63:	ff ff ff 
     a66:	48 8d 55 0b          	lea    0xb(%rbp),%rdx
     a6a:	48 89 57 68          	mov    %rdx,0x68(%rdi)
     a6e:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     a75:	00 
     a76:	48 89 51 18          	mov    %rdx,0x18(%rcx)
     a7a:	49 bf 00 00 00 00 01 	movabs $0x100000000,%r15
     a81:	00 00 00 
     a84:	4c 89 79 20          	mov    %r15,0x20(%rcx)
     a88:	48 89 69 28          	mov    %rbp,0x28(%rcx)
     a8c:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
     a93:	00 80 3f 
     a96:	4c 89 77 70          	mov    %r14,0x70(%rdi)
     a9a:	ba ff ff ff ff       	mov    $0xffffffff,%edx
     a9f:	48 89 51 30          	mov    %rdx,0x30(%rcx)
     aa3:	4c 89 71 38          	mov    %r14,0x38(%rcx)
     aa7:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     aae:	00 00 00 
     ab1:	49 8d 9d 07 a8 04 00 	lea    0x4a807(%r13),%rbx
     ab8:	e9 97 15 00 00       	jmp    2054 <f_8001161d0+0x2054>
     abd:	81 f9 ac 03 00 00    	cmp    $0x3ac,%ecx
     ac3:	0f 8f 86 06 00 00    	jg     114f <f_8001161d0+0x114f>
     ac9:	81 f9 d5 02 00 00    	cmp    $0x2d5,%ecx
     acf:	0f 84 2d 1d 00 00    	je     2802 <f_8001161d0+0x2802>
     ad5:	81 f9 f3 02 00 00    	cmp    $0x2f3,%ecx
     adb:	0f 85 28 11 00 00    	jne    1c09 <f_8001161d0+0x1c09>
     ae1:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
     ae8:	00 
     ae9:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
     af0:	48 c7 03 00 02 00 00 	movq   $0x200,(%rbx)
     af7:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
     afe:	00 40 00 
     b01:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     b05:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
     b0c:	00 
     b0d:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     b14:	ff ff ff 
     b17:	48 8d 4a 13          	lea    0x13(%rdx),%rcx
     b1b:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
     b1f:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     b26:	00 00 00 
     b29:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
     b2d:	48 89 53 28          	mov    %rdx,0x28(%rbx)
     b31:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
     b37:	4c 89 47 68          	mov    %r8,0x68(%rdi)
     b3b:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
     b42:	00 80 3f 
     b45:	4c 89 77 70          	mov    %r14,0x70(%rdi)
     b49:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
     b4d:	48 83 c3 38          	add    $0x38,%rbx
     b51:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
     b58:	00 00 00 
     b5b:	4c 8d 8a f9 7a ff ff 	lea    -0x8507(%rdx),%r9
     b62:	e9 f4 1e 00 00       	jmp    2a5b <f_8001161d0+0x2a5b>
     b67:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # b6e <f_8001161d0+0xb6e>
     b6e:	4a 63 14 89          	movslq (%rcx,%r9,4),%rdx
     b72:	48 01 ca             	add    %rcx,%rdx
     b75:	ff e2                	jmp    *%rdx
     b77:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     b7e:	00 00 00 
     b81:	4d 8d 75 e0          	lea    -0x20(%r13),%r14
     b85:	e9 1d 09 00 00       	jmp    14a7 <f_8001161d0+0x14a7>
     b8a:	81 f9 c9 00 00 00    	cmp    $0xc9,%ecx
     b90:	0f 84 24 14 00 00    	je     1fba <f_8001161d0+0x1fba>
     b96:	81 f9 d9 00 00 00    	cmp    $0xd9,%ecx
     b9c:	0f 85 67 10 00 00    	jne    1c09 <f_8001161d0+0x1c09>
     ba2:	49 8b 9f c8 1e 00 00 	mov    0x1ec8(%r15),%rbx
     ba9:	48 89 5f 08          	mov    %rbx,0x8(%rdi)
     bad:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
     bb2:	48 89 77 60          	mov    %rsi,0x60(%rdi)
     bb6:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
     bbd:	00 
     bbe:	45 0f b6 7e 08       	movzbl 0x8(%r14),%r15d
     bc3:	4c 89 7f 70          	mov    %r15,0x70(%rdi)
     bc7:	45 0f b7 8e 14 29 00 	movzwl 0x2914(%r14),%r9d
     bce:	00 
     bcf:	41 83 e1 40          	and    $0x40,%r9d
     bd3:	8b 53 08             	mov    0x8(%rbx),%edx
     bd6:	4c 8b 73 10          	mov    0x10(%rbx),%r14
     bda:	31 c9                	xor    %ecx,%ecx
     bdc:	44 39 fa             	cmp    %r15d,%edx
     bdf:	ba 00 00 00 00       	mov    $0x0,%edx
     be4:	49 0f 47 d7          	cmova  %r15,%rdx
     be8:	48 c7 47 78 e0 3c 00 	movq   $0x3ce0,0x78(%rdi)
     bef:	00 
     bf0:	48 89 97 88 00 00 00 	mov    %rdx,0x88(%rdi)
     bf7:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
     bfe:	4a 8b 94 32 40 3c 00 	mov    0x3c40(%rdx,%r14,1),%rdx
     c05:	00 
     c06:	48 89 97 b0 00 00 00 	mov    %rdx,0xb0(%rdi)
     c0d:	4c 8b b7 a0 00 00 00 	mov    0xa0(%rdi),%r14
     c14:	4d 8b b6 b8 1e 00 00 	mov    0x1eb8(%r14),%r14
     c1b:	44 89 90 70 ff ff ff 	mov    %r10d,-0x90(%rax)
     c22:	48 89 b0 58 ff ff ff 	mov    %rsi,-0xa8(%rax)
     c29:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     c30:	ff 7f 7f 
     c33:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
     c3a:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     c41:	00 
     c42:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     c46:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     c4d:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     c51:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
     c58:	ff 
     c59:	41 80 be b0 06 00 00 	cmpb   $0x0,0x6b0(%r14)
     c60:	00 
     c61:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     c68:	00 00 00 00 
     c6c:	48 89 a8 20 ff ff ff 	mov    %rbp,-0xe0(%rax)
     c73:	48 c7 80 00 ff ff ff 	movq   $0x4,-0x100(%rax)
     c7a:	04 00 00 00 
     c7e:	48 89 17             	mov    %rdx,(%rdi)
     c81:	0f 95 c2             	setne  %dl
     c84:	41 c1 e9 06          	shr    $0x6,%r9d
     c88:	41 20 d1             	and    %dl,%r9b
     c8b:	c7 80 d8 fe ff ff 00 	movl   $0x0,-0x128(%rax)
     c92:	00 00 00 
     c95:	41 0f b6 d1          	movzbl %r9b,%edx
     c99:	c1 e2 1a             	shl    $0x1a,%edx
     c9c:	81 ca 01 00 40 00    	or     $0x400001,%edx
     ca2:	89 90 dc fe ff ff    	mov    %edx,-0x124(%rax)
     ca8:	48 ba 10 00 00 00 03 	movabs $0x300000010,%rdx
     caf:	00 00 00 
     cb2:	48 89 90 d0 fe ff ff 	mov    %rdx,-0x130(%rax)
     cb9:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     cc0:	ff ff 00 00 
     cc4:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     ccb:	ff ff ff 
     cce:	48 8d 55 07          	lea    0x7(%rbp),%rdx
     cd2:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
     cd9:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
     ce0:	00 00 00 
     ce3:	48 89 90 f0 fe ff ff 	mov    %rdx,-0x110(%rax)
     cea:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
     cf1:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
     cf8:	00 80 3f 
     cfb:	48 89 90 08 ff ff ff 	mov    %rdx,-0xf8(%rax)
     d02:	48 89 90 10 ff ff ff 	mov    %rdx,-0xf0(%rax)
     d09:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     d10:	00 00 00 
     d13:	49 8d 95 00 54 09 00 	lea    0x95400(%r13),%rdx
     d1a:	48 89 57 68          	mov    %rdx,0x68(%rdi)
     d1e:	48 8b b7 c0 00 00 00 	mov    0xc0(%rdi),%rsi
     d25:	4c 8b 0c 24          	mov    (%rsp),%r9
     d29:	4c 89 8e a4 00 00 00 	mov    %r9,0xa4(%rsi)
     d30:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
     d37:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
     d3e:	4c 89 80 50 ff ff ff 	mov    %r8,-0xb0(%rax)
     d45:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
     d4c:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
     d53:	00 00 00 00 
     d57:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
     d5e:	49 69 d7 e0 3c 00 00 	imul   $0x3ce0,%r15,%rdx
     d65:	44 39 7b 08          	cmp    %r15d,0x8(%rbx)
     d69:	48 0f 46 d1          	cmovbe %rcx,%rdx
     d6d:	48 8b 73 10          	mov    0x10(%rbx),%rsi
     d71:	c5 f8 10 84 16 00 2e 	vmovups 0x2e00(%rsi,%rdx,1),%xmm0
     d78:	00 00 
     d7a:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
     d81:	ff 
     d82:	8b 53 08             	mov    0x8(%rbx),%edx
     d85:	31 f6                	xor    %esi,%esi
     d87:	31 c0                	xor    %eax,%eax
     d89:	41 89 d0             	mov    %edx,%r8d
     d8c:	45 29 f8             	sub    %r15d,%r8d
     d8f:	49 0f 47 cf          	cmova  %r15,%rcx
     d93:	40 0f 94 c6          	sete   %sil
     d97:	0f 93 c0             	setae  %al
     d9a:	c1 e6 1e             	shl    $0x1e,%esi
     d9d:	c1 e0 1d             	shl    $0x1d,%eax
     da0:	09 f0                	or     %esi,%eax
     da2:	48 8b 73 10          	mov    0x10(%rbx),%rsi
     da6:	c4 e2 38 f2 d2       	andn   %edx,%r8d,%edx
     dab:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
     db2:	44 09 c0             	or     %r8d,%eax
     db5:	c1 ea 03             	shr    $0x3,%edx
     db8:	81 e2 00 00 00 10    	and    $0x10000000,%edx
     dbe:	09 c2                	or     %eax,%edx
     dc0:	48 89 97 10 01 00 00 	mov    %rdx,0x110(%rdi)
     dc7:	8b 47 78             	mov    0x78(%rdi),%eax
     dca:	48 0f af c1          	imul   %rcx,%rax
     dce:	48 8b 8c 30 80 30 00 	mov    0x3080(%rax,%rsi,1),%rcx
     dd5:	00 
     dd6:	48 8b 94 30 88 30 00 	mov    0x3088(%rax,%rsi,1),%rdx
     ddd:	00 
     dde:	48 89 57 50          	mov    %rdx,0x50(%rdi)
     de2:	4c 8b 87 d0 00 00 00 	mov    0xd0(%rdi),%r8
     de9:	49 89 08             	mov    %rcx,(%r8)
     dec:	49 89 50 08          	mov    %rdx,0x8(%r8)
     df0:	48 8b 8c 30 90 30 00 	mov    0x3090(%rax,%rsi,1),%rcx
     df7:	00 
     df8:	48 89 4f 48          	mov    %rcx,0x48(%rdi)
     dfc:	8b 84 30 98 30 00 00 	mov    0x3098(%rax,%rsi,1),%eax
     e03:	48 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%rdx
     e0a:	89 42 08             	mov    %eax,0x8(%rdx)
     e0d:	48 8b 87 e8 00 00 00 	mov    0xe8(%rdi),%rax
     e14:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
     e18:	48 89 47 40          	mov    %rax,0x40(%rdi)
     e1c:	48 89 0a             	mov    %rcx,(%rdx)
     e1f:	49 8d 85 e6 09 51 fd 	lea    -0x2aef61a(%r13),%rax
     e26:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
     e2d:	48 89 fb             	mov    %rdi,%rbx
     e30:	c5 f8 77             	vzeroupper
     e33:	e8 00 00 00 00       	call   e38 <f_8001161d0+0xe38>
     e38:	48 89 df             	mov    %rbx,%rdi
     e3b:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     e42:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
     e49:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     e50:	48 89 01             	mov    %rax,(%rcx)
     e53:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     e5a:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     e61:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
     e65:	48 89 53 48          	mov    %rdx,0x48(%rbx)
     e69:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
     e70:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     e74:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     e7a:	48 89 43 40          	mov    %rax,0x40(%rbx)
     e7e:	88 51 08             	mov    %dl,0x8(%rcx)
     e81:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     e88:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
     e8c:	89 41 24             	mov    %eax,0x24(%rcx)
     e8f:	e9 95 1d 00 00       	jmp    2c29 <f_8001161d0+0x2c29>
     e94:	81 f9 b2 01 00 00    	cmp    $0x1b2,%ecx
     e9a:	0f 84 69 1a 00 00    	je     2909 <f_8001161d0+0x2909>
     ea0:	81 f9 b8 01 00 00    	cmp    $0x1b8,%ecx
     ea6:	0f 85 5d 0d 00 00    	jne    1c09 <f_8001161d0+0x1c09>
     eac:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
     eb3:	00 
     eb4:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
     ebb:	48 c7 03 08 00 00 00 	movq   $0x8,(%rbx)
     ec2:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
     ec9:	00 40 00 
     ecc:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     ed0:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
     ed7:	00 
     ed8:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     edf:	ff ff ff 
     ee2:	48 8d 4a 15          	lea    0x15(%rdx),%rcx
     ee6:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
     eea:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     ef1:	00 00 00 
     ef4:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
     ef8:	48 89 53 28          	mov    %rdx,0x28(%rbx)
     efc:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
     f02:	4c 89 47 68          	mov    %r8,0x68(%rdi)
     f06:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
     f0d:	00 80 3f 
     f10:	4c 89 77 70          	mov    %r14,0x70(%rdi)
     f14:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
     f18:	48 83 c3 38          	add    $0x38,%rbx
     f1c:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
     f23:	00 00 00 
     f26:	4c 8d 8a af 2c 05 00 	lea    0x52caf(%rdx),%r9
     f2d:	e9 29 1b 00 00       	jmp    2a5b <f_8001161d0+0x2a5b>
     f32:	81 f9 b6 02 00 00    	cmp    $0x2b6,%ecx
     f38:	0f 84 23 1a 00 00    	je     2961 <f_8001161d0+0x2961>
     f3e:	81 f9 c5 02 00 00    	cmp    $0x2c5,%ecx
     f44:	0f 85 bf 0c 00 00    	jne    1c09 <f_8001161d0+0x1c09>
     f4a:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
     f51:	00 
     f52:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
     f59:	48 b9 01 00 00 00 04 	movabs $0x400000001,%rcx
     f60:	00 00 00 
     f63:	48 89 0b             	mov    %rcx,(%rbx)
     f66:	48 b9 00 00 00 00 02 	movabs $0x80200000000,%rcx
     f6d:	08 00 00 
     f70:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     f74:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
     f7b:	00 
     f7c:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     f83:	ff ff ff 
     f86:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
     f8a:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
     f8e:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     f95:	00 00 00 
     f98:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
     f9c:	48 89 53 28          	mov    %rdx,0x28(%rbx)
     fa0:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
     fa6:	4c 89 47 68          	mov    %r8,0x68(%rdi)
     faa:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
     fb1:	00 80 3f 
     fb4:	4c 89 77 70          	mov    %r14,0x70(%rdi)
     fb8:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
     fbc:	48 83 c3 38          	add    $0x38,%rbx
     fc0:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
     fc7:	00 00 00 
     fca:	4c 8d 8a 88 db 0a 00 	lea    0xadb88(%rdx),%r9
     fd1:	e9 85 1a 00 00       	jmp    2a5b <f_8001161d0+0x2a5b>
     fd6:	81 f9 52 02 00 00    	cmp    $0x252,%ecx
     fdc:	0f 84 02 1a 00 00    	je     29e4 <f_8001161d0+0x29e4>
     fe2:	81 f9 61 02 00 00    	cmp    $0x261,%ecx
     fe8:	0f 85 1b 0c 00 00    	jne    1c09 <f_8001161d0+0x1c09>
     fee:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
     ff5:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
     ffc:	48 ba 00 00 00 00 0f 	movabs $0xf00000000,%rdx
    1003:	00 00 00 
    1006:	48 89 51 14          	mov    %rdx,0x14(%rcx)
    100a:	48 ba 00 00 00 00 ff 	movabs $0xffff00000000,%rdx
    1011:	ff 00 00 
    1014:	48 81 ca 00 00 40 08 	or     $0x8400000,%rdx
    101b:	48 89 51 0c          	mov    %rdx,0xc(%rcx)
    101f:	48 8b 97 a0 00 00 00 	mov    0xa0(%rdi),%rdx
    1026:	8b 92 8c 3a 00 00    	mov    0x3a8c(%rdx),%edx
    102c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    1031:	48 89 77 60          	mov    %rsi,0x60(%rdi)
    1035:	48 89 6f 40          	mov    %rbp,0x40(%rdi)
    1039:	48 c7 41 04 00 00 00 	movq   $0x0,0x4(%rcx)
    1040:	00 
    1041:	4c 8b 4f 78          	mov    0x78(%rdi),%r9
    1045:	4c 89 49 1c          	mov    %r9,0x1c(%rcx)
    1049:	41 89 d2             	mov    %edx,%r10d
    104c:	41 c1 e2 0d          	shl    $0xd,%r10d
    1050:	41 81 e2 00 00 00 40 	and    $0x40000000,%r10d
    1057:	49 81 f2 00 00 00 40 	xor    $0x40000000,%r10
    105e:	4c 89 97 10 01 00 00 	mov    %r10,0x110(%rdi)
    1065:	48 c7 47 68 01 00 00 	movq   $0x1,0x68(%rdi)
    106c:	00 
    106d:	c7 41 34 00 00 00 00 	movl   $0x0,0x34(%rcx)
    1074:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    107b:	00 
    107c:	48 c7 41 24 01 00 00 	movq   $0x1,0x24(%rcx)
    1083:	00 
    1084:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1088:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    108f:	00 00 00 
    1092:	44 89 49 2c          	mov    %r9d,0x2c(%rcx)
    1096:	c7 41 30 01 00 00 00 	movl   $0x1,0x30(%rcx)
    109d:	c1 ea 08             	shr    $0x8,%edx
    10a0:	81 e2 00 02 00 00    	and    $0x200,%edx
    10a6:	81 ca 00 00 00 40    	or     $0x40000000,%edx
    10ac:	89 11                	mov    %edx,(%rcx)
    10ae:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    10b5:	00 00 00 
    10b8:	48 05 f0 85 00 00    	add    $0x85f0,%rax
    10be:	48 89 47 70          	mov    %rax,0x70(%rdi)
    10c2:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
    10c9:	00 80 3f 
    10cc:	48 89 51 38          	mov    %rdx,0x38(%rcx)
    10d0:	48 89 51 40          	mov    %rdx,0x40(%rcx)
    10d4:	48 8b 97 c0 00 00 00 	mov    0xc0(%rdi),%rdx
    10db:	4c 8b 0c 24          	mov    (%rsp),%r9
    10df:	4c 89 8a a4 00 00 00 	mov    %r9,0xa4(%rdx)
    10e6:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
    10ed:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    10f4:	48 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rdx
    10fb:	ff 7f 7f 
    10fe:	48 89 51 78          	mov    %rdx,0x78(%rcx)
    1102:	4c 89 81 80 00 00 00 	mov    %r8,0x80(%rcx)
    1109:	48 89 b1 88 00 00 00 	mov    %rsi,0x88(%rcx)
    1110:	48 89 91 90 00 00 00 	mov    %rdx,0x90(%rcx)
    1117:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    111b:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    1120:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    1127:	00 
    1128:	48 89 41 70          	mov    %rax,0x70(%rcx)
    112c:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    1133:	48 c7 40 48 00 00 00 	movq   $0x0,0x48(%rax)
    113a:	00 
    113b:	48 89 68 50          	mov    %rbp,0x50(%rax)
    113f:	4c 8b 5f 48          	mov    0x48(%rdi),%r11
    1143:	4c 8b af d0 00 00 00 	mov    0xd0(%rdi),%r13
    114a:	e9 bc 19 00 00       	jmp    2b0b <f_8001161d0+0x2b0b>
    114f:	81 f9 ad 03 00 00    	cmp    $0x3ad,%ecx
    1155:	0f 84 90 1d 00 00    	je     2eeb <f_8001161d0+0x2eeb>
    115b:	81 f9 12 04 00 00    	cmp    $0x412,%ecx
    1161:	0f 85 a2 0a 00 00    	jne    1c09 <f_8001161d0+0x1c09>
    1167:	48 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%rcx
    116e:	48 8b 89 c8 1e 00 00 	mov    0x1ec8(%rcx),%rcx
    1175:	48 89 4f 70          	mov    %rcx,0x70(%rdi)
    1179:	48 bb 00 00 00 00 01 	movabs $0x100000000,%rbx
    1180:	00 00 00 
    1183:	48 89 1f             	mov    %rbx,(%rdi)
    1186:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    118a:	4c 8b 8f 00 01 00 00 	mov    0x100(%rdi),%r9
    1191:	49 c7 01 02 00 00 00 	movq   $0x2,(%r9)
    1198:	48 ba 00 00 00 00 00 	movabs $0x40000000000000,%rdx
    119f:	00 40 00 
    11a2:	48 ff c2             	inc    %rdx
    11a5:	49 89 51 08          	mov    %rdx,0x8(%r9)
    11a9:	49 89 59 20          	mov    %rbx,0x20(%r9)
    11ad:	48 89 ee             	mov    %rbp,%rsi
    11b0:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    11b7:	ff ff ff 
    11ba:	49 89 69 28          	mov    %rbp,0x28(%r9)
    11be:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    11c5:	00 00 00 
    11c8:	4c 89 6f 68          	mov    %r13,0x68(%rdi)
    11cc:	4d 89 81 80 00 00 00 	mov    %r8,0x80(%r9)
    11d3:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    11d8:	49 89 91 88 00 00 00 	mov    %rdx,0x88(%r9)
    11df:	48 8b 97 c0 00 00 00 	mov    0xc0(%rdi),%rdx
    11e6:	4c 8b 1c 24          	mov    (%rsp),%r11
    11ea:	4c 89 9a a4 00 00 00 	mov    %r11,0xa4(%rdx)
    11f1:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
    11f8:	ff 7f 7f 
    11fb:	4d 89 99 90 00 00 00 	mov    %r11,0x90(%r9)
    1202:	4d 89 81 98 00 00 00 	mov    %r8,0x98(%r9)
    1209:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 1211 <f_8001161d0+0x1211>
    1210:	00 
    1211:	c5 fc 11 47 78       	vmovups %ymm0,0x78(%rdi)
    1216:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    121d:	00 
    121e:	45 89 91 a0 00 00 00 	mov    %r10d,0xa0(%r9)
    1225:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    122c:	0f b6 50 08          	movzbl 0x8(%rax),%edx
    1230:	48 89 57 40          	mov    %rdx,0x40(%rdi)
    1234:	41 c7 81 bc 00 00 00 	movl   $0x3,0xbc(%r9)
    123b:	03 00 00 00 
    123f:	49 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%r9)
    1246:	00 
    1247:	48 8d 45 16          	lea    0x16(%rbp),%rax
    124b:	49 89 41 18          	mov    %rax,0x18(%r9)
    124f:	49 c7 41 68 00 00 00 	movq   $0x0,0x68(%r9)
    1256:	00 
    1257:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    125c:	49 89 41 30          	mov    %rax,0x30(%r9)
    1260:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    1267:	00 80 3f 
    126a:	49 89 41 38          	mov    %rax,0x38(%r9)
    126e:	49 89 41 40          	mov    %rax,0x40(%r9)
    1272:	49 c7 41 48 00 00 00 	movq   $0x0,0x48(%r9)
    1279:	00 
    127a:	49 89 71 50          	mov    %rsi,0x50(%r9)
    127e:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1282:	c4 c1 78 11 41 58    	vmovups %xmm0,0x58(%r9)
    1288:	4d 89 69 70          	mov    %r13,0x70(%r9)
    128c:	4d 89 59 78          	mov    %r11,0x78(%r9)
    1290:	48 69 c2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rax
    1297:	45 31 c0             	xor    %r8d,%r8d
    129a:	39 51 08             	cmp    %edx,0x8(%rcx)
    129d:	49 0f 46 c0          	cmovbe %r8,%rax
    12a1:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    12a5:	48 8b b4 08 b8 30 00 	mov    0x30b8(%rax,%rcx,1),%rsi
    12ac:	00 
    12ad:	48 89 77 60          	mov    %rsi,0x60(%rdi)
    12b1:	48 8b 84 08 b0 30 00 	mov    0x30b0(%rax,%rcx,1),%rax
    12b8:	00 
    12b9:	48 8b 4f 48          	mov    0x48(%rdi),%rcx
    12bd:	48 89 01             	mov    %rax,(%rcx)
    12c0:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    12c4:	48 8b 47 70          	mov    0x70(%rdi),%rax
    12c8:	44 8b 48 08          	mov    0x8(%rax),%r9d
    12cc:	4c 89 4f 48          	mov    %r9,0x48(%rdi)
    12d0:	48 8b 48 10          	mov    0x10(%rax),%rcx
    12d4:	48 89 4f 58          	mov    %rcx,0x58(%rdi)
    12d8:	8b 77 40             	mov    0x40(%rdi),%esi
    12db:	48 69 f6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rsi
    12e2:	45 31 db             	xor    %r11d,%r11d
    12e5:	45 31 d2             	xor    %r10d,%r10d
    12e8:	44 89 cb             	mov    %r9d,%ebx
    12eb:	29 d3                	sub    %edx,%ebx
    12ed:	49 0f 46 f0          	cmovbe %r8,%rsi
    12f1:	41 0f 94 c3          	sete   %r11b
    12f5:	41 0f 93 c2          	setae  %r10b
    12f9:	41 c1 e3 1e          	shl    $0x1e,%r11d
    12fd:	41 c1 e2 1d          	shl    $0x1d,%r10d
    1301:	45 09 da             	or     %r11d,%r10d
    1304:	c4 c2 60 f2 d1       	andn   %r9d,%ebx,%edx
    1309:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    130f:	41 09 da             	or     %ebx,%r10d
    1312:	c1 ea 03             	shr    $0x3,%edx
    1315:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    131b:	44 09 d2             	or     %r10d,%edx
    131e:	48 89 97 10 01 00 00 	mov    %rdx,0x110(%rdi)
    1325:	48 8b 94 0e 30 33 00 	mov    0x3330(%rsi,%rcx,1),%rdx
    132c:	00 
    132d:	4c 8b 84 0e 38 33 00 	mov    0x3338(%rsi,%rcx,1),%r8
    1334:	00 
    1335:	48 89 57 50          	mov    %rdx,0x50(%rdi)
    1339:	4c 8b 8f d0 00 00 00 	mov    0xd0(%rdi),%r9
    1340:	49 89 11             	mov    %rdx,(%r9)
    1343:	4d 89 41 08          	mov    %r8,0x8(%r9)
    1347:	8b 94 0e 48 33 00 00 	mov    0x3348(%rsi,%rcx,1),%edx
    134e:	48 8b 8c 0e 40 33 00 	mov    0x3340(%rsi,%rcx,1),%rcx
    1355:	00 
    1356:	48 8b b7 c8 00 00 00 	mov    0xc8(%rdi),%rsi
    135d:	48 89 0e             	mov    %rcx,(%rsi)
    1360:	89 56 08             	mov    %edx,0x8(%rsi)
    1363:	8b 48 44             	mov    0x44(%rax),%ecx
    1366:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    136a:	48 83 c0 30          	add    $0x30,%rax
    136e:	e9 76 0b 00 00       	jmp    1ee9 <f_8001161d0+0x1ee9>
    1373:	81 f9 1a 05 00 00    	cmp    $0x51a,%ecx
    1379:	0f 85 8a 08 00 00    	jne    1c09 <f_8001161d0+0x1c09>
    137f:	b8 e8 0a 00 00       	mov    $0xae8,%eax
    1384:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
    138b:	48 89 07             	mov    %rax,(%rdi)
    138e:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    1395:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    139c:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    13a0:	48 89 47 10          	mov    %rax,0x10(%rdi)
    13a4:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    13ab:	00 00 00 
    13ae:	49 8d 85 ca 19 51 fd 	lea    -0x2aee636(%r13),%rax
    13b5:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    13bc:	48 89 fb             	mov    %rdi,%rbx
    13bf:	c5 f8 77             	vzeroupper
    13c2:	e8 00 00 00 00       	call   13c7 <f_8001161d0+0x13c7>
    13c7:	48 89 df             	mov    %rbx,%rdi
    13ca:	e9 5a 18 00 00       	jmp    2c29 <f_8001161d0+0x2c29>
    13cf:	83 f9 61             	cmp    $0x61,%ecx
    13d2:	0f 85 31 08 00 00    	jne    1c09 <f_8001161d0+0x1c09>
    13d8:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    13df:	00 
    13e0:	48 c7 80 d0 fe ff ff 	movq   $0x8,-0x130(%rax)
    13e7:	08 00 00 00 
    13eb:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    13f2:	00 40 00 
    13f5:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    13fc:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    1403:	ff ff 00 00 
    1407:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    140e:	ff ff ff 
    1411:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    1415:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    141c:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    1423:	00 00 00 
    1426:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
    142a:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    1431:	48 89 90 f8 fe ff ff 	mov    %rdx,-0x108(%rax)
    1438:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    143f:	00 80 3f 
    1442:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    1446:	48 8d 88 00 ff ff ff 	lea    -0x100(%rax),%rcx
    144d:	48 8d 98 08 ff ff ff 	lea    -0xf8(%rax),%rbx
    1454:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
    145b:	00 00 00 
    145e:	4c 8d 8a ab f2 0c 00 	lea    0xcf2ab(%rdx),%r9
    1465:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    146b:	e9 eb 15 00 00       	jmp    2a5b <f_8001161d0+0x2a5b>
    1470:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1477:	00 00 00 
    147a:	4d 8d b5 0b d1 09 00 	lea    0x9d10b(%r13),%r14
    1481:	eb 24                	jmp    14a7 <f_8001161d0+0x14a7>
    1483:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    148a:	00 00 00 
    148d:	4d 8d b5 2d 8c 01 00 	lea    0x18c2d(%r13),%r14
    1494:	eb 11                	jmp    14a7 <f_8001161d0+0x14a7>
    1496:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    149d:	00 00 00 
    14a0:	4d 8d b5 4b 4f 0a 00 	lea    0xa4f4b(%r13),%r14
    14a7:	4c 89 77 68          	mov    %r14,0x68(%rdi)
    14ab:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    14b2:	c7 03 00 00 00 10    	movl   $0x10000000,(%rbx)
    14b8:	4c 8b bf a0 00 00 00 	mov    0xa0(%rdi),%r15
    14bf:	49 8b 8f f0 31 00 00 	mov    0x31f0(%r15),%rcx
    14c6:	48 89 0f             	mov    %rcx,(%rdi)
    14c9:	48 ba 10 00 00 00 03 	movabs $0x300000010,%rdx
    14d0:	00 00 00 
    14d3:	4c 8d 4a f0          	lea    -0x10(%rdx),%r9
    14d7:	4c 89 4b 14          	mov    %r9,0x14(%rbx)
    14db:	48 c7 47 78 01 00 00 	movq   $0x1,0x78(%rdi)
    14e2:	00 
    14e3:	48 83 c2 f6          	add    $0xfffffffffffffff6,%rdx
    14e7:	48 89 53 04          	mov    %rdx,0x4(%rbx)
    14eb:	48 8b 57 70          	mov    0x70(%rdi),%rdx
    14ef:	48 89 53 2c          	mov    %rdx,0x2c(%rbx)
    14f3:	48 ba 00 00 00 00 ff 	movabs $0xffff00000000,%rdx
    14fa:	ff 00 00 
    14fd:	48 89 53 0c          	mov    %rdx,0xc(%rbx)
    1501:	4c 89 47 70          	mov    %r8,0x70(%rdi)
    1505:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    150a:	48 89 53 1c          	mov    %rdx,0x1c(%rbx)
    150e:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    1513:	4c 89 5f 60          	mov    %r11,0x60(%rdi)
    1517:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
    151e:	00 80 3f 
    1521:	48 89 53 38          	mov    %rdx,0x38(%rbx)
    1525:	48 89 53 40          	mov    %rdx,0x40(%rbx)
    1529:	4c 8b 24 24          	mov    (%rsp),%r12
    152d:	4c 89 67 48          	mov    %r12,0x48(%rdi)
    1531:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    1535:	48 c7 43 24 01 00 00 	movq   $0x1,0x24(%rbx)
    153c:	00 
    153d:	c7 43 34 00 00 00 00 	movl   $0x0,0x34(%rbx)
    1544:	4c 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%r9
    154b:	4d 89 a1 a4 00 00 00 	mov    %r12,0xa4(%r9)
    1552:	4c 89 83 98 00 00 00 	mov    %r8,0x98(%rbx)
    1559:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    155d:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1564:	00 
    1565:	44 89 93 a0 00 00 00 	mov    %r10d,0xa0(%rbx)
    156c:	c7 83 bc 00 00 00 01 	movl   $0x1,0xbc(%rbx)
    1573:	00 00 00 
    1576:	48 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rax
    157d:	ff 7f 7f 
    1580:	48 89 43 78          	mov    %rax,0x78(%rbx)
    1584:	4c 89 83 80 00 00 00 	mov    %r8,0x80(%rbx)
    158b:	4c 89 9b 88 00 00 00 	mov    %r11,0x88(%rbx)
    1592:	48 89 83 90 00 00 00 	mov    %rax,0x90(%rbx)
    1599:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    159d:	c5 f8 11 43 58       	vmovups %xmm0,0x58(%rbx)
    15a2:	48 c7 43 68 00 00 00 	movq   $0x0,0x68(%rbx)
    15a9:	00 
    15aa:	4c 89 73 70          	mov    %r14,0x70(%rbx)
    15ae:	48 c7 43 48 00 00 00 	movq   $0x0,0x48(%rbx)
    15b5:	00 
    15b6:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    15ba:	48 85 c9             	test   %rcx,%rcx
    15bd:	0f 84 66 16 00 00    	je     2c29 <f_8001161d0+0x2c29>
    15c3:	49 8b 87 c8 1e 00 00 	mov    0x1ec8(%r15),%rax
    15ca:	48 8b 97 98 00 00 00 	mov    0x98(%rdi),%rdx
    15d1:	0f b6 52 08          	movzbl 0x8(%rdx),%edx
    15d5:	44 8b 40 08          	mov    0x8(%rax),%r8d
    15d9:	48 8b 70 10          	mov    0x10(%rax),%rsi
    15dd:	31 c0                	xor    %eax,%eax
    15df:	45 31 db             	xor    %r11d,%r11d
    15e2:	31 ed                	xor    %ebp,%ebp
    15e4:	45 89 c6             	mov    %r8d,%r14d
    15e7:	41 29 d6             	sub    %edx,%r14d
    15ea:	41 bf 00 00 00 00    	mov    $0x0,%r15d
    15f0:	4c 0f 47 fa          	cmova  %rdx,%r15
    15f4:	41 0f 94 c3          	sete   %r11b
    15f8:	40 0f 93 c5          	setae  %bpl
    15fc:	c4 c2 08 f2 d0       	andn   %r8d,%r14d,%edx
    1601:	41 81 e6 00 00 00 80 	and    $0x80000000,%r14d
    1608:	41 c1 e3 1e          	shl    $0x1e,%r11d
    160c:	c1 e5 1d             	shl    $0x1d,%ebp
    160f:	44 09 dd             	or     %r11d,%ebp
    1612:	44 09 f5             	or     %r14d,%ebp
    1615:	c1 ea 03             	shr    $0x3,%edx
    1618:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    161e:	09 ea                	or     %ebp,%edx
    1620:	48 89 97 10 01 00 00 	mov    %rdx,0x110(%rdi)
    1627:	48 c7 47 60 e0 3c 00 	movq   $0x3ce0,0x60(%rdi)
    162e:	00 
    162f:	4c 89 7f 58          	mov    %r15,0x58(%rdi)
    1633:	49 69 d7 e0 3c 00 00 	imul   $0x3ce0,%r15,%rdx
    163a:	4c 8d 04 32          	lea    (%rdx,%rsi,1),%r8
    163e:	4c 89 47 50          	mov    %r8,0x50(%rdi)
    1642:	4c 8d b7 10 02 00 00 	lea    0x210(%rdi),%r14
    1649:	c5 fa 10 8c 32 08 2e 	vmovss 0x2e08(%rdx,%rsi,1),%xmm1
    1650:	00 00 
    1652:	c5 fa 10 94 32 0c 2e 	vmovss 0x2e0c(%rdx,%rsi,1),%xmm2
    1659:	00 00 
    165b:	c5 f2 5c 9c 32 00 2e 	vsubss 0x2e00(%rdx,%rsi,1),%xmm1,%xmm3
    1662:	00 00 
    1664:	c5 ea 5c 8c 32 04 2e 	vsubss 0x2e04(%rdx,%rsi,1),%xmm2,%xmm1
    166b:	00 00 
    166d:	4c 8d bf 20 02 00 00 	lea    0x220(%rdi),%r15
    1674:	44 89 93 a0 00 00 00 	mov    %r10d,0xa0(%rbx)
    167b:	48 8b 97 e8 00 00 00 	mov    0xe8(%rdi),%rdx
    1682:	48 83 c2 f7          	add    $0xfffffffffffffff7,%rdx
    1686:	c4 e1 fa 2c f3       	vcvttss2si %xmm3,%rsi
    168b:	c5 e8 57 d2          	vxorps %xmm2,%xmm2,%xmm2
    168f:	c5 f8 2e da          	vucomiss %xmm2,%xmm3
    1693:	0f 42 f0             	cmovb  %eax,%esi
    1696:	c5 fa 10 25 00 00 00 	vmovss 0x0(%rip),%xmm4        # 169e <f_8001161d0+0x169e>
    169d:	00 
    169e:	c5 f8 2e dc          	vucomiss %xmm4,%xmm3
    16a2:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    16a8:	41 0f 47 f0          	cmova  %r8d,%esi
    16ac:	48 89 57 40          	mov    %rdx,0x40(%rdi)
    16b0:	c4 e1 82 2a de       	vcvtsi2ss %rsi,%xmm15,%xmm3
    16b5:	4d 89 a1 a4 00 00 00 	mov    %r12,0xa4(%r9)
    16bc:	8b 91 0c 03 00 00    	mov    0x30c(%rcx),%edx
    16c2:	c5 e2 59 99 08 03 00 	vmulss 0x308(%rcx),%xmm3,%xmm3
    16c9:	00 
    16ca:	48 89 97 30 02 00 00 	mov    %rdx,0x230(%rdi)
    16d1:	48 c7 87 38 02 00 00 	movq   $0x0,0x238(%rdi)
    16d8:	00 00 00 00 
    16dc:	c4 e1 fa 2c c9       	vcvttss2si %xmm1,%rcx
    16e1:	c5 f8 2e ca          	vucomiss %xmm2,%xmm1
    16e5:	0f 42 c8             	cmovb  %eax,%ecx
    16e8:	c5 f8 2e cc          	vucomiss %xmm4,%xmm1
    16ec:	41 0f 47 c8          	cmova  %r8d,%ecx
    16f0:	c5 f9 7e d8          	vmovd  %xmm3,%eax
    16f4:	48 89 87 00 02 00 00 	mov    %rax,0x200(%rdi)
    16fb:	c4 e1 82 2a c9       	vcvtsi2ss %rcx,%xmm15,%xmm1
    1700:	48 c7 87 08 02 00 00 	movq   $0x0,0x208(%rdi)
    1707:	00 00 00 00 
    170b:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    170f:	c5 f2 59 ca          	vmulss %xmm2,%xmm1,%xmm1
    1713:	c5 f9 7e c8          	vmovd  %xmm1,%eax
    1717:	c5 f8 11 87 18 02 00 	vmovups %xmm0,0x218(%rdi)
    171e:	00 
    171f:	48 89 87 10 02 00 00 	mov    %rax,0x210(%rdi)
    1726:	48 c7 87 28 02 00 00 	movq   $0x0,0x228(%rdi)
    172d:	00 00 00 00 
    1731:	48 89 fb             	mov    %rdi,%rbx
    1734:	31 f6                	xor    %esi,%esi
    1736:	31 d2                	xor    %edx,%edx
    1738:	b9 01 00 00 00       	mov    $0x1,%ecx
    173d:	c5 f8 77             	vzeroupper
    1740:	e8 00 00 00 00       	call   1745 <f_8001161d0+0x1745>
    1745:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    174c:	48 8b 8b 00 02 00 00 	mov    0x200(%rbx),%rcx
    1753:	48 8b 93 20 02 00 00 	mov    0x220(%rbx),%rdx
    175a:	c5 f9 6e c1          	vmovd  %ecx,%xmm0
    175e:	c4 e3 79 22 83 10 02 	vpinsrd $0x1,0x210(%rbx),%xmm0,%xmm0
    1765:	00 00 01 
    1768:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    176c:	c4 e2 79 58 c9       	vpbroadcastd %xmm1,%xmm1
    1771:	c5 f0 5f d0          	vmaxps %xmm0,%xmm1,%xmm2
    1775:	c5 f8 c2 c0 03       	vcmpunordps %xmm0,%xmm0,%xmm0
    177a:	c4 e3 69 4a c1 00    	vblendvps %xmm0,%xmm1,%xmm2,%xmm0
    1780:	c4 e3 79 17 c6 00    	vextractps $0x0,%xmm0,%esi
    1786:	c4 e3 79 17 c7 01    	vextractps $0x1,%xmm0,%edi
    178c:	48 89 bb 40 02 00 00 	mov    %rdi,0x240(%rbx)
    1793:	48 89 b3 30 02 00 00 	mov    %rsi,0x230(%rbx)
    179a:	48 c7 83 48 02 00 00 	movq   $0x0,0x248(%rbx)
    17a1:	00 00 00 00 
    17a5:	a9 00 00 00 40       	test   $0x40000000,%eax
    17aa:	40 0f 94 c6          	sete   %sil
    17ae:	85 c0                	test   %eax,%eax
    17b0:	40 0f 98 c7          	sets   %dil
    17b4:	a9 00 00 00 10       	test   $0x10000000,%eax
    17b9:	0f 94 c0             	sete   %al
    17bc:	40 30 f8             	xor    %dil,%al
    17bf:	40 84 c6             	test   %al,%sil
    17c2:	48 0f 45 ca          	cmovne %rdx,%rcx
    17c6:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    17cd:	00 00 00 00 
    17d1:	89 c8                	mov    %ecx,%eax
    17d3:	48 89 83 00 02 00 00 	mov    %rax,0x200(%rbx)
    17da:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    17e1:	00 00 00 00 
    17e5:	48 89 df             	mov    %rbx,%rdi
    17e8:	be 01 00 00 00       	mov    $0x1,%esi
    17ed:	31 d2                	xor    %edx,%edx
    17ef:	b9 01 00 00 00       	mov    $0x1,%ecx
    17f4:	e8 00 00 00 00       	call   17f9 <f_8001161d0+0x17f9>
    17f9:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    1800:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    1807:	8b 93 30 02 00 00    	mov    0x230(%rbx),%edx
    180d:	85 c0                	test   %eax,%eax
    180f:	40 0f 98 c6          	sets   %sil
    1813:	a9 00 00 00 10       	test   $0x10000000,%eax
    1818:	40 0f 94 c7          	sete   %dil
    181c:	40 30 f7             	xor    %sil,%dil
    181f:	8b b3 40 02 00 00    	mov    0x240(%rbx),%esi
    1825:	89 91 80 00 00 00    	mov    %edx,0x80(%rcx)
    182b:	89 b1 84 00 00 00    	mov    %esi,0x84(%rcx)
    1831:	4d 0f 44 fe          	cmove  %r14,%r15
    1835:	89 91 98 00 00 00    	mov    %edx,0x98(%rcx)
    183b:	a9 00 00 00 40       	test   $0x40000000,%eax
    1840:	4d 0f 45 fe          	cmovne %r14,%r15
    1844:	89 b1 9c 00 00 00    	mov    %esi,0x9c(%rcx)
    184a:	49 8b 07             	mov    (%r15),%rax
    184d:	89 c2                	mov    %eax,%edx
    184f:	48 89 93 10 02 00 00 	mov    %rdx,0x210(%rbx)
    1856:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    185d:	00 00 00 00 
    1861:	8b 93 00 02 00 00    	mov    0x200(%rbx),%edx
    1867:	89 51 78             	mov    %edx,0x78(%rcx)
    186a:	89 41 7c             	mov    %eax,0x7c(%rcx)
    186d:	89 91 90 00 00 00    	mov    %edx,0x90(%rcx)
    1873:	89 81 94 00 00 00    	mov    %eax,0x94(%rcx)
    1879:	49 8d 85 5e 18 51 fd 	lea    -0x2aee7a2(%r13),%rax
    1880:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    1887:	48 89 df             	mov    %rbx,%rdi
    188a:	e8 00 00 00 00       	call   188f <f_8001161d0+0x188f>
    188f:	48 89 df             	mov    %rbx,%rdi
    1892:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    1899:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    18a0:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    18a7:	48 89 01             	mov    %rax,(%rcx)
    18aa:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    18b1:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    18b5:	48 89 43 40          	mov    %rax,0x40(%rbx)
    18b9:	88 41 08             	mov    %al,0x8(%rcx)
    18bc:	e9 68 13 00 00       	jmp    2c29 <f_8001161d0+0x2c29>
    18c1:	48 8b 4f 78          	mov    0x78(%rdi),%rcx
    18c5:	4c 89 cd             	mov    %r9,%rbp
    18c8:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
    18cf:	00 00 00 00 
    18d3:	48 89 a8 20 ff ff ff 	mov    %rbp,-0xe0(%rax)
    18da:	4c 8b bf a0 00 00 00 	mov    0xa0(%rdi),%r15
    18e1:	8b b7 a8 00 00 00    	mov    0xa8(%rdi),%esi
    18e7:	44 8d 4e 08          	lea    0x8(%rsi),%r9d
    18eb:	4c 8b 87 00 01 00 00 	mov    0x100(%rdi),%r8
    18f2:	c4 c2 73 f7 af fc 0d 	shrx   %ecx,0xdfc(%r15),%ebp
    18f9:	00 00 
    18fb:	45 89 48 30          	mov    %r9d,0x30(%r8)
    18ff:	4c 8b 67 68          	mov    0x68(%rdi),%r12
    1903:	45 89 60 34          	mov    %r12d,0x34(%r8)
    1907:	45 31 ed             	xor    %r13d,%r13d
    190a:	f7 c3 00 02 00 00    	test   $0x200,%ebx
    1910:	41 0f 94 c5          	sete   %r13b
    1914:	45 8b 8f 20 0d 00 00 	mov    0xd20(%r15),%r9d
    191b:	45 31 f6             	xor    %r14d,%r14d
    191e:	41 39 c9             	cmp    %ecx,%r9d
    1921:	49 0f 46 ce          	cmovbe %r14,%rcx
    1925:	41 89 c9             	mov    %ecx,%r9d
    1928:	4d 69 c9 b0 0b 00 00 	imul   $0xbb0,%r9,%r9
    192f:	31 d2                	xor    %edx,%edx
    1931:	f7 c3 00 40 00 00    	test   $0x4000,%ebx
    1937:	0f 94 c2             	sete   %dl
    193a:	c1 e3 06             	shl    $0x6,%ebx
    193d:	81 e3 00 00 04 00    	and    $0x40000,%ebx
    1943:	c1 e2 04             	shl    $0x4,%edx
    1946:	41 85 ed             	test   %ebp,%r13d
    1949:	bd 01 00 00 00       	mov    $0x1,%ebp
    194e:	c4 62 19 f7 e5       	shlx   %r12d,%ebp,%r12d
    1953:	48 c7 47 48 01 00 00 	movq   $0x1,0x48(%rdi)
    195a:	00 
    195b:	4c 89 67 08          	mov    %r12,0x8(%rdi)
    195f:	4d 8b bf 28 0d 00 00 	mov    0xd28(%r15),%r15
    1966:	4c 89 7f 70          	mov    %r15,0x70(%rdi)
    196a:	48 89 4f 78          	mov    %rcx,0x78(%rdi)
    196e:	8d 8c 1a 00 00 20 00 	lea    0x200000(%rdx,%rbx,1),%ecx
    1975:	ba 0f 00 00 00       	mov    $0xf,%edx
    197a:	41 0f 45 d4          	cmovne %r12d,%edx
    197e:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1985:	00 
    1986:	48 c7 07 08 00 00 00 	movq   $0x8,(%rdi)
    198d:	41 89 10             	mov    %edx,(%r8)
    1990:	41 c7 40 04 08 00 00 	movl   $0x8,0x4(%r8)
    1997:	00 
    1998:	83 c6 04             	add    $0x4,%esi
    199b:	41 89 70 08          	mov    %esi,0x8(%r8)
    199f:	41 89 48 0c          	mov    %ecx,0xc(%r8)
    19a3:	49 c7 40 10 ff ff 00 	movq   $0xffff,0x10(%r8)
    19aa:	00 
    19ab:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    19b2:	ff ff ff 
    19b5:	48 8d 4d 02          	lea    0x2(%rbp),%rcx
    19b9:	49 89 48 18          	mov    %rcx,0x18(%r8)
    19bd:	4c 8b 24 24          	mov    (%rsp),%r12
    19c1:	4c 89 a7 90 00 00 00 	mov    %r12,0x90(%rdi)
    19c8:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    19cf:	00 00 00 
    19d2:	49 89 48 20          	mov    %rcx,0x20(%r8)
    19d6:	49 89 68 28          	mov    %rbp,0x28(%r8)
    19da:	48 b9 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rcx
    19e1:	00 80 3f 
    19e4:	49 89 48 38          	mov    %rcx,0x38(%r8)
    19e8:	49 89 48 40          	mov    %rcx,0x40(%r8)
    19ec:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    19f3:	00 00 00 
    19f6:	49 8d 95 b1 e5 0b 00 	lea    0xbe5b1(%r13),%rdx
    19fd:	48 89 97 80 00 00 00 	mov    %rdx,0x80(%rdi)
    1a04:	48 bb ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rbx
    1a0b:	ff 7f ff 
    1a0e:	48 89 9f 88 00 00 00 	mov    %rbx,0x88(%rdi)
    1a15:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
    1a1c:	4c 89 a1 a4 00 00 00 	mov    %r12,0xa4(%rcx)
    1a23:	48 8b 77 58          	mov    0x58(%rdi),%rsi
    1a27:	49 89 70 78          	mov    %rsi,0x78(%r8)
    1a2b:	49 89 98 80 00 00 00 	mov    %rbx,0x80(%r8)
    1a32:	49 89 98 98 00 00 00 	mov    %rbx,0x98(%r8)
    1a39:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    1a3e:	4d 89 98 88 00 00 00 	mov    %r11,0x88(%r8)
    1a45:	49 89 b0 90 00 00 00 	mov    %rsi,0x90(%r8)
    1a4c:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1a50:	45 89 90 a0 00 00 00 	mov    %r10d,0xa0(%r8)
    1a57:	41 c7 80 bc 00 00 00 	movl   $0x0,0xbc(%r8)
    1a5e:	00 00 00 00 
    1a62:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1a66:	c4 c1 78 11 40 58    	vmovups %xmm0,0x58(%r8)
    1a6c:	49 c7 40 68 00 00 00 	movq   $0x0,0x68(%r8)
    1a73:	00 
    1a74:	49 89 50 70          	mov    %rdx,0x70(%r8)
    1a78:	43 8b 84 0f d8 03 00 	mov    0x3d8(%r15,%r9,1),%eax
    1a7f:	00 
    1a80:	89 c2                	mov    %eax,%edx
    1a82:	c1 fa 1f             	sar    $0x1f,%edx
    1a85:	c4 e2 68 f2 d0       	andn   %eax,%edx,%edx
    1a8a:	85 c0                	test   %eax,%eax
    1a8c:	41 0f 49 c6          	cmovns %r14d,%eax
    1a90:	c5 82 2a c0          	vcvtsi2ss %eax,%xmm15,%xmm0
    1a94:	43 8b 84 0f f8 03 00 	mov    0x3f8(%r15,%r9,1),%eax
    1a9b:	00 
    1a9c:	89 c6                	mov    %eax,%esi
    1a9e:	c1 fe 1f             	sar    $0x1f,%esi
    1aa1:	c4 e2 48 f2 f0       	andn   %eax,%esi,%esi
    1aa6:	85 c0                	test   %eax,%eax
    1aa8:	c5 82 2a ce          	vcvtsi2ss %esi,%xmm15,%xmm1
    1aac:	41 0f 49 c6          	cmovns %r14d,%eax
    1ab0:	c5 82 2a d2          	vcvtsi2ss %edx,%xmm15,%xmm2
    1ab4:	c4 c1 7a 11 90 80 00 	vmovss %xmm2,0x80(%r8)
    1abb:	00 00 
    1abd:	c4 c1 7a 11 88 84 00 	vmovss %xmm1,0x84(%r8)
    1ac4:	00 00 
    1ac6:	c5 82 2a c8          	vcvtsi2ss %eax,%xmm15,%xmm1
    1aca:	c4 c1 7a 11 40 78    	vmovss %xmm0,0x78(%r8)
    1ad0:	c4 c1 7a 11 48 7c    	vmovss %xmm1,0x7c(%r8)
    1ad6:	43 8b 94 0f d8 03 00 	mov    0x3d8(%r15,%r9,1),%edx
    1add:	00 
    1ade:	43 8b 84 0f f8 03 00 	mov    0x3f8(%r15,%r9,1),%eax
    1ae5:	00 
    1ae6:	48 89 47 60          	mov    %rax,0x60(%rdi)
    1aea:	8b 77 40             	mov    0x40(%rdi),%esi
    1aed:	41 89 b0 a0 00 00 00 	mov    %esi,0xa0(%r8)
    1af4:	89 d6                	mov    %edx,%esi
    1af6:	c1 fe 1f             	sar    $0x1f,%esi
    1af9:	c4 e2 48 f2 f2       	andn   %edx,%esi,%esi
    1afe:	85 d2                	test   %edx,%edx
    1b00:	41 0f 49 d6          	cmovns %r14d,%edx
    1b04:	c5 82 2a c2          	vcvtsi2ss %edx,%xmm15,%xmm0
    1b08:	4c 89 a1 a4 00 00 00 	mov    %r12,0xa4(%rcx)
    1b0f:	85 c0                	test   %eax,%eax
    1b11:	44 0f 4f f0          	cmovg  %eax,%r14d
    1b15:	c5 82 2a ce          	vcvtsi2ss %esi,%xmm15,%xmm1
    1b19:	c4 e3 79 17 c1 00    	vextractps $0x0,%xmm0,%ecx
    1b1f:	48 89 77 68          	mov    %rsi,0x68(%rdi)
    1b23:	48 89 8f 10 02 00 00 	mov    %rcx,0x210(%rdi)
    1b2a:	c4 e3 79 17 c9 00    	vextractps $0x0,%xmm1,%ecx
    1b30:	48 89 8f 00 02 00 00 	mov    %rcx,0x200(%rdi)
    1b37:	c4 c1 02 2a d6       	vcvtsi2ss %r14d,%xmm15,%xmm2
    1b3c:	89 c1                	mov    %eax,%ecx
    1b3e:	c1 f9 1f             	sar    $0x1f,%ecx
    1b41:	21 c1                	and    %eax,%ecx
    1b43:	48 c7 87 18 02 00 00 	movq   $0x0,0x218(%rdi)
    1b4a:	00 00 00 00 
    1b4e:	48 c7 87 08 02 00 00 	movq   $0x0,0x208(%rdi)
    1b55:	00 00 00 00 
    1b59:	48 89 4f 58          	mov    %rcx,0x58(%rdi)
    1b5d:	c5 82 2a d9          	vcvtsi2ss %ecx,%xmm15,%xmm3
    1b61:	c4 e3 79 17 d8 00    	vextractps $0x0,%xmm3,%eax
    1b67:	48 89 87 30 02 00 00 	mov    %rax,0x230(%rdi)
    1b6e:	c4 e3 79 17 d0 00    	vextractps $0x0,%xmm2,%eax
    1b74:	48 89 87 20 02 00 00 	mov    %rax,0x220(%rdi)
    1b7b:	48 c7 87 38 02 00 00 	movq   $0x0,0x238(%rdi)
    1b82:	00 00 00 00 
    1b86:	48 c7 87 28 02 00 00 	movq   $0x0,0x228(%rdi)
    1b8d:	00 00 00 00 
    1b91:	c4 c1 7a 11 88 98 00 	vmovss %xmm1,0x98(%r8)
    1b98:	00 00 
    1b9a:	c4 c1 7a 11 90 9c 00 	vmovss %xmm2,0x9c(%r8)
    1ba1:	00 00 
    1ba3:	c4 c1 7a 11 80 90 00 	vmovss %xmm0,0x90(%r8)
    1baa:	00 00 
    1bac:	c4 c1 7a 11 98 94 00 	vmovss %xmm3,0x94(%r8)
    1bb3:	00 00 
    1bb5:	31 c0                	xor    %eax,%eax
    1bb7:	43 80 bc 0f 58 04 00 	cmpb   $0x0,0x458(%r15,%r9,1)
    1bbe:	00 00 
    1bc0:	48 c7 47 50 5b 00 00 	movq   $0x5b,0x50(%rdi)
    1bc7:	00 
    1bc8:	49 c7 80 b0 00 00 00 	movq   $0x0,0xb0(%r8)
    1bcf:	00 00 00 00 
    1bd3:	41 c7 80 bc 00 00 00 	movl   $0x1,0xbc(%r8)
    1bda:	01 00 00 00 
    1bde:	0f 94 c0             	sete   %al
    1be1:	48 8d 0c 45 59 00 00 	lea    0x59(,%rax,2),%rcx
    1be8:	00 
    1be9:	c1 e0 1e             	shl    $0x1e,%eax
    1bec:	48 0d 00 00 00 20    	or     $0x20000000,%rax
    1bf2:	48 89 87 10 01 00 00 	mov    %rax,0x110(%rdi)
    1bf9:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    1bfd:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    1c04:	e9 1a 10 00 00       	jmp    2c23 <f_8001161d0+0x2c23>
    1c09:	4c 89 a7 08 01 00 00 	mov    %r12,0x108(%rdi)
    1c10:	48 83 c4 18          	add    $0x18,%rsp
    1c14:	5b                   	pop    %rbx
    1c15:	41 5c                	pop    %r12
    1c17:	41 5d                	pop    %r13
    1c19:	41 5e                	pop    %r14
    1c1b:	41 5f                	pop    %r15
    1c1d:	5d                   	pop    %rbp
    1c1e:	c5 f8 77             	vzeroupper
    1c21:	e9 00 00 00 00       	jmp    1c26 <f_8001161d0+0x1c26>
    1c26:	48 c7 47 40 b0 1e 00 	movq   $0x1eb0,0x40(%rdi)
    1c2d:	00 
    1c2e:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    1c35:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    1c3c:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    1c40:	48 89 47 10          	mov    %rax,0x10(%rdi)
    1c44:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1c49:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
    1c50:	48 89 07             	mov    %rax,(%rdi)
    1c53:	48 c7 47 18 00 00 00 	movq   $0x0,0x18(%rdi)
    1c5a:	00 
    1c5b:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1c62:	00 00 00 
    1c65:	49 8d 85 ae 18 51 fd 	lea    -0x2aee752(%r13),%rax
    1c6c:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    1c73:	48 89 fb             	mov    %rdi,%rbx
    1c76:	c5 f8 77             	vzeroupper
    1c79:	e8 00 00 00 00       	call   1c7e <f_8001161d0+0x1c7e>
    1c7e:	48 89 df             	mov    %rbx,%rdi
    1c81:	e9 a3 0f 00 00       	jmp    2c29 <f_8001161d0+0x2c29>
    1c86:	48 c7 47 40 b0 1e 00 	movq   $0x1eb0,0x40(%rdi)
    1c8d:	00 
    1c8e:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    1c95:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    1c9c:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    1ca0:	48 89 47 10          	mov    %rax,0x10(%rdi)
    1ca4:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1ca9:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
    1cb0:	48 89 07             	mov    %rax,(%rdi)
    1cb3:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1cba:	00 00 00 
    1cbd:	49 8d 85 ce 18 51 fd 	lea    -0x2aee732(%r13),%rax
    1cc4:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    1ccb:	48 89 fb             	mov    %rdi,%rbx
    1cce:	c5 f8 77             	vzeroupper
    1cd1:	e8 00 00 00 00       	call   1cd6 <f_8001161d0+0x1cd6>
    1cd6:	48 89 df             	mov    %rbx,%rdi
    1cd9:	e9 4b 0f 00 00       	jmp    2c29 <f_8001161d0+0x2c29>
    1cde:	48 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%rcx
    1ce5:	48 8b 89 c8 1e 00 00 	mov    0x1ec8(%rcx),%rcx
    1cec:	48 89 4f 70          	mov    %rcx,0x70(%rdi)
    1cf0:	49 b9 00 00 00 00 01 	movabs $0x100000000,%r9
    1cf7:	00 00 00 
    1cfa:	4c 89 0f             	mov    %r9,(%rdi)
    1cfd:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1d01:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    1d08:	48 c7 03 04 00 00 00 	movq   $0x4,(%rbx)
    1d0f:	48 ba 00 00 00 00 00 	movabs $0x40000000000000,%rdx
    1d16:	00 40 00 
    1d19:	48 ff c2             	inc    %rdx
    1d1c:	48 89 53 08          	mov    %rdx,0x8(%rbx)
    1d20:	4c 89 4b 20          	mov    %r9,0x20(%rbx)
    1d24:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    1d2b:	ff ff ff 
    1d2e:	48 89 6b 28          	mov    %rbp,0x28(%rbx)
    1d32:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1d39:	00 00 00 
    1d3c:	49 8d 95 25 74 0d 00 	lea    0xd7425(%r13),%rdx
    1d43:	48 89 57 68          	mov    %rdx,0x68(%rdi)
    1d47:	4c 89 83 80 00 00 00 	mov    %r8,0x80(%rbx)
    1d4e:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    1d53:	4c 89 8b 88 00 00 00 	mov    %r9,0x88(%rbx)
    1d5a:	4c 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%r9
    1d61:	4c 8b 1c 24          	mov    (%rsp),%r11
    1d65:	4d 89 99 a4 00 00 00 	mov    %r11,0xa4(%r9)
    1d6c:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
    1d73:	ff 7f 7f 
    1d76:	4c 89 9b 90 00 00 00 	mov    %r11,0x90(%rbx)
    1d7d:	4c 89 83 98 00 00 00 	mov    %r8,0x98(%rbx)
    1d84:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 1d8c <f_8001161d0+0x1d8c>
    1d8b:	00 
    1d8c:	c5 fc 11 47 78       	vmovups %ymm0,0x78(%rdi)
    1d91:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1d98:	00 
    1d99:	44 89 93 a0 00 00 00 	mov    %r10d,0xa0(%rbx)
    1da0:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    1da7:	44 0f b6 48 08       	movzbl 0x8(%rax),%r9d
    1dac:	4c 89 4f 40          	mov    %r9,0x40(%rdi)
    1db0:	c7 83 bc 00 00 00 03 	movl   $0x3,0xbc(%rbx)
    1db7:	00 00 00 
    1dba:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
    1dc1:	00 
    1dc2:	48 8d 45 17          	lea    0x17(%rbp),%rax
    1dc6:	48 89 43 18          	mov    %rax,0x18(%rbx)
    1dca:	48 c7 43 68 00 00 00 	movq   $0x0,0x68(%rbx)
    1dd1:	00 
    1dd2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    1dd7:	48 89 43 30          	mov    %rax,0x30(%rbx)
    1ddb:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    1de2:	00 80 3f 
    1de5:	48 89 43 38          	mov    %rax,0x38(%rbx)
    1de9:	48 89 43 40          	mov    %rax,0x40(%rbx)
    1ded:	48 c7 43 48 00 00 00 	movq   $0x0,0x48(%rbx)
    1df4:	00 
    1df5:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    1df9:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1dfd:	c5 f8 11 43 58       	vmovups %xmm0,0x58(%rbx)
    1e02:	48 89 53 70          	mov    %rdx,0x70(%rbx)
    1e06:	4c 89 5b 78          	mov    %r11,0x78(%rbx)
    1e0a:	49 69 c1 e0 3c 00 00 	imul   $0x3ce0,%r9,%rax
    1e11:	45 31 c0             	xor    %r8d,%r8d
    1e14:	44 39 49 08          	cmp    %r9d,0x8(%rcx)
    1e18:	49 0f 46 c0          	cmovbe %r8,%rax
    1e1c:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    1e20:	48 8b 94 08 68 33 00 	mov    0x3368(%rax,%rcx,1),%rdx
    1e27:	00 
    1e28:	48 89 57 60          	mov    %rdx,0x60(%rdi)
    1e2c:	48 8b 84 08 60 33 00 	mov    0x3360(%rax,%rcx,1),%rax
    1e33:	00 
    1e34:	48 8b 4f 48          	mov    0x48(%rdi),%rcx
    1e38:	48 89 01             	mov    %rax,(%rcx)
    1e3b:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    1e3f:	48 8b 47 70          	mov    0x70(%rdi),%rax
    1e43:	44 8b 50 08          	mov    0x8(%rax),%r10d
    1e47:	48 8b 48 10          	mov    0x10(%rax),%rcx
    1e4b:	48 89 4f 58          	mov    %rcx,0x58(%rdi)
    1e4f:	8b 57 40             	mov    0x40(%rdi),%edx
    1e52:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
    1e59:	45 31 db             	xor    %r11d,%r11d
    1e5c:	31 f6                	xor    %esi,%esi
    1e5e:	44 89 d3             	mov    %r10d,%ebx
    1e61:	44 29 cb             	sub    %r9d,%ebx
    1e64:	49 0f 46 d0          	cmovbe %r8,%rdx
    1e68:	41 0f 94 c3          	sete   %r11b
    1e6c:	40 0f 93 c6          	setae  %sil
    1e70:	41 c1 e3 1e          	shl    $0x1e,%r11d
    1e74:	c1 e6 1d             	shl    $0x1d,%esi
    1e77:	44 09 de             	or     %r11d,%esi
    1e7a:	c4 42 60 f2 c2       	andn   %r10d,%ebx,%r8d
    1e7f:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    1e85:	09 de                	or     %ebx,%esi
    1e87:	41 c1 e8 03          	shr    $0x3,%r8d
    1e8b:	41 81 e0 00 00 00 10 	and    $0x10000000,%r8d
    1e92:	41 09 f0             	or     %esi,%r8d
    1e95:	4c 89 87 10 01 00 00 	mov    %r8,0x110(%rdi)
    1e9c:	48 8b b4 0a e8 35 00 	mov    0x35e8(%rdx,%rcx,1),%rsi
    1ea3:	00 
    1ea4:	48 89 77 48          	mov    %rsi,0x48(%rdi)
    1ea8:	4c 8b 84 0a e0 35 00 	mov    0x35e0(%rdx,%rcx,1),%r8
    1eaf:	00 
    1eb0:	4c 89 47 50          	mov    %r8,0x50(%rdi)
    1eb4:	4c 8b 8f d0 00 00 00 	mov    0xd0(%rdi),%r9
    1ebb:	4d 89 01             	mov    %r8,(%r9)
    1ebe:	49 89 71 08          	mov    %rsi,0x8(%r9)
    1ec2:	8b b4 0a f8 35 00 00 	mov    0x35f8(%rdx,%rcx,1),%esi
    1ec9:	48 8b 8c 0a f0 35 00 	mov    0x35f0(%rdx,%rcx,1),%rcx
    1ed0:	00 
    1ed1:	48 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%rdx
    1ed8:	48 89 0a             	mov    %rcx,(%rdx)
    1edb:	89 72 08             	mov    %esi,0x8(%rdx)
    1ede:	8b 48 44             	mov    0x44(%rax),%ecx
    1ee1:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    1ee5:	48 83 c0 3c          	add    $0x3c,%rax
    1ee9:	8b 00                	mov    (%rax),%eax
    1eeb:	48 89 47 48          	mov    %rax,0x48(%rdi)
    1eef:	48 8b 97 00 01 00 00 	mov    0x100(%rdi),%rdx
    1ef6:	88 8a b0 00 00 00    	mov    %cl,0xb0(%rdx)
    1efc:	c7 82 b4 00 00 00 00 	movl   $0x0,0xb4(%rdx)
    1f03:	00 00 00 
    1f06:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
    1f0d:	c7 81 b1 00 00 00 00 	movl   $0x0,0xb1(%rcx)
    1f14:	00 00 00 
    1f17:	88 82 b8 00 00 00    	mov    %al,0xb8(%rdx)
    1f1d:	e9 07 0d 00 00       	jmp    2c29 <f_8001161d0+0x2c29>
    1f22:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    1f29:	00 
    1f2a:	48 c7 80 d0 fe ff ff 	movq   $0x100,-0x130(%rax)
    1f31:	00 01 00 00 
    1f35:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    1f3c:	00 40 00 
    1f3f:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    1f46:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    1f4d:	ff ff 00 00 
    1f51:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    1f58:	ff ff ff 
    1f5b:	48 8d 4a 13          	lea    0x13(%rdx),%rcx
    1f5f:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    1f66:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    1f6d:	00 00 00 
    1f70:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
    1f74:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    1f7b:	48 89 90 f8 fe ff ff 	mov    %rdx,-0x108(%rax)
    1f82:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    1f89:	00 80 3f 
    1f8c:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    1f90:	48 8d 88 00 ff ff ff 	lea    -0x100(%rax),%rcx
    1f97:	48 8d 98 08 ff ff ff 	lea    -0xf8(%rax),%rbx
    1f9e:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
    1fa5:	00 00 00 
    1fa8:	4c 8d 8a a1 6f fe ff 	lea    -0x1905f(%rdx),%r9
    1faf:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    1fb5:	e9 a1 0a 00 00       	jmp    2a5b <f_8001161d0+0x2a5b>
    1fba:	49 89 ec             	mov    %rbp,%r12
    1fbd:	48 c7 47 68 00 10 00 	movq   $0x1000,0x68(%rdi)
    1fc4:	00 
    1fc5:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    1fcc:	00 
    1fcd:	48 c7 80 d0 fe ff ff 	movq   $0x1000,-0x130(%rax)
    1fd4:	00 10 00 00 
    1fd8:	48 c7 80 d8 fe ff ff 	movq   $0x1,-0x128(%rax)
    1fdf:	01 00 00 00 
    1fe3:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    1fea:	ff ff 00 00 
    1fee:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    1ff5:	ff ff ff 
    1ff8:	48 8d 4d 0c          	lea    0xc(%rbp),%rcx
    1ffc:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    2003:	49 bf 00 00 00 00 01 	movabs $0x100000000,%r15
    200a:	00 00 00 
    200d:	4c 89 b8 f0 fe ff ff 	mov    %r15,-0x110(%rax)
    2014:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
    201b:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    2022:	00 80 3f 
    2025:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    2029:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
    202e:	48 89 88 00 ff ff ff 	mov    %rcx,-0x100(%rax)
    2035:	4c 89 b0 08 ff ff ff 	mov    %r14,-0xf8(%rax)
    203c:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    2043:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    204a:	00 00 00 
    204d:	49 8d 9d b2 a4 03 00 	lea    0x3a4b2(%r13),%rbx
    2054:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
    205b:	4c 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%r9
    2062:	4d 8b 91 d0 2f 00 00 	mov    0x2fd0(%r9),%r10
    2069:	4c 89 57 40          	mov    %r10,0x40(%rdi)
    206d:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    2072:	48 89 77 60          	mov    %rsi,0x60(%rdi)
    2076:	48 89 59 70          	mov    %rbx,0x70(%rcx)
    207a:	48 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rbx
    2081:	ff 7f 7f 
    2084:	48 89 59 78          	mov    %rbx,0x78(%rcx)
    2088:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    208c:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2090:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2097:	00 
    2098:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    209f:	00 00 00 
    20a2:	4c 89 81 80 00 00 00 	mov    %r8,0x80(%rcx)
    20a9:	48 89 b1 88 00 00 00 	mov    %rsi,0x88(%rcx)
    20b0:	48 8b 97 c0 00 00 00 	mov    0xc0(%rdi),%rdx
    20b7:	4c 8b 1c 24          	mov    (%rsp),%r11
    20bb:	4c 89 9a a4 00 00 00 	mov    %r11,0xa4(%rdx)
    20c2:	4c 89 71 40          	mov    %r14,0x40(%rcx)
    20c6:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    20cd:	00 
    20ce:	48 89 99 90 00 00 00 	mov    %rbx,0x90(%rcx)
    20d5:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    20dc:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    20e3:	00 
    20e4:	4c 89 61 50          	mov    %r12,0x50(%rcx)
    20e8:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    20ec:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    20f1:	4d 85 d2             	test   %r10,%r10
    20f4:	0f 84 d5 0f 00 00    	je     30cf <f_8001161d0+0x30cf>
    20fa:	48 8b 97 98 00 00 00 	mov    0x98(%rdi),%rdx
    2101:	0f b6 72 08          	movzbl 0x8(%rdx),%esi
    2105:	48 c7 47 68 e0 3c 00 	movq   $0x3ce0,0x68(%rdi)
    210c:	00 
    210d:	4c 69 c6 60 0f 00 00 	imul   $0xf60,%rsi,%r8
    2114:	31 d2                	xor    %edx,%edx
    2116:	41 39 72 10          	cmp    %esi,0x10(%r10)
    211a:	4d 8b 52 18          	mov    0x18(%r10),%r10
    211e:	4c 0f 46 c2          	cmovbe %rdx,%r8
    2122:	47 8b 84 10 9c 02 00 	mov    0x29c(%r8,%r10,1),%r8d
    2129:	00 
    212a:	4d 09 f8             	or     %r15,%r8
    212d:	4c 89 41 1c          	mov    %r8,0x1c(%rcx)
    2131:	c7 81 bc 00 00 00 02 	movl   $0x2,0xbc(%rcx)
    2138:	00 00 00 
    213b:	49 8b 89 c8 1e 00 00 	mov    0x1ec8(%r9),%rcx
    2142:	4c 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%r8
    2149:	39 71 08             	cmp    %esi,0x8(%rcx)
    214c:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    2152:	4d 0f 47 c8          	cmova  %r8,%r9
    2156:	4c 8b 51 10          	mov    0x10(%rcx),%r10
    215a:	4f 8b 9c 0a b8 30 00 	mov    0x30b8(%r10,%r9,1),%r11
    2161:	00 
    2162:	4c 89 5f 60          	mov    %r11,0x60(%rdi)
    2166:	4f 8b 8c 0a b0 30 00 	mov    0x30b0(%r10,%r9,1),%r9
    216d:	00 
    216e:	4c 89 4f 58          	mov    %r9,0x58(%rdi)
    2172:	4c 89 88 48 ff ff ff 	mov    %r9,-0xb8(%rax)
    2179:	4c 89 98 50 ff ff ff 	mov    %r11,-0xb0(%rax)
    2180:	44 8b 49 08          	mov    0x8(%rcx),%r9d
    2184:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    2188:	45 31 d2             	xor    %r10d,%r10d
    218b:	45 31 db             	xor    %r11d,%r11d
    218e:	44 89 cb             	mov    %r9d,%ebx
    2191:	29 f3                	sub    %esi,%ebx
    2193:	49 0f 47 d0          	cmova  %r8,%rdx
    2197:	41 0f 94 c2          	sete   %r10b
    219b:	41 0f 93 c3          	setae  %r11b
    219f:	c4 c2 60 f2 f1       	andn   %r9d,%ebx,%esi
    21a4:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    21aa:	41 c1 e2 1e          	shl    $0x1e,%r10d
    21ae:	41 c1 e3 1d          	shl    $0x1d,%r11d
    21b2:	45 09 d3             	or     %r10d,%r11d
    21b5:	41 09 db             	or     %ebx,%r11d
    21b8:	c1 ee 03             	shr    $0x3,%esi
    21bb:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    21c1:	44 09 de             	or     %r11d,%esi
    21c4:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    21cb:	48 8d 34 0a          	lea    (%rdx,%rcx,1),%rsi
    21cf:	48 89 77 40          	mov    %rsi,0x40(%rdi)
    21d3:	48 8b b4 0a 30 33 00 	mov    0x3330(%rdx,%rcx,1),%rsi
    21da:	00 
    21db:	4c 8b 84 0a 38 33 00 	mov    0x3338(%rdx,%rcx,1),%r8
    21e2:	00 
    21e3:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    21e7:	48 89 b0 60 ff ff ff 	mov    %rsi,-0xa0(%rax)
    21ee:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
    21f5:	8b b4 0a 48 33 00 00 	mov    0x3348(%rdx,%rcx,1),%esi
    21fc:	48 89 77 48          	mov    %rsi,0x48(%rdi)
    2200:	48 8b 8c 0a 40 33 00 	mov    0x3340(%rdx,%rcx,1),%rcx
    2207:	00 
    2208:	48 89 88 70 ff ff ff 	mov    %rcx,-0x90(%rax)
    220f:	89 b0 78 ff ff ff    	mov    %esi,-0x88(%rax)
    2215:	e9 0f 0a 00 00       	jmp    2c29 <f_8001161d0+0x2c29>
    221a:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
    2221:	48 8b 97 a0 00 00 00 	mov    0xa0(%rdi),%rdx
    2228:	48 8b 92 c8 1e 00 00 	mov    0x1ec8(%rdx),%rdx
    222f:	48 89 57 08          	mov    %rdx,0x8(%rdi)
    2233:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    2238:	48 89 77 60          	mov    %rsi,0x60(%rdi)
    223c:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
    2240:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
    2244:	44 8b 4a 08          	mov    0x8(%rdx),%r9d
    2248:	48 69 d9 e0 3c 00 00 	imul   $0x3ce0,%rcx,%rbx
    224f:	45 31 f6             	xor    %r14d,%r14d
    2252:	41 39 c9             	cmp    %ecx,%r9d
    2255:	4c 0f 47 f3          	cmova  %rbx,%r14
    2259:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    225d:	48 c7 47 70 e0 3c 00 	movq   $0x3ce0,0x70(%rdi)
    2264:	00 
    2265:	49 8b 8c 0e 40 3c 00 	mov    0x3c40(%r14,%rcx,1),%rcx
    226c:	00 
    226d:	48 89 8f b0 00 00 00 	mov    %rcx,0xb0(%rdi)
    2274:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    227b:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
    2282:	48 89 b1 88 00 00 00 	mov    %rsi,0x88(%rcx)
    2289:	48 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rdx
    2290:	ff 7f 7f 
    2293:	48 89 91 90 00 00 00 	mov    %rdx,0x90(%rcx)
    229a:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    22a1:	00 
    22a2:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    22a6:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    22ad:	00 00 00 
    22b0:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    22b7:	00 
    22b8:	48 89 69 50          	mov    %rbp,0x50(%rcx)
    22bc:	48 c7 47 40 06 00 00 	movq   $0x6,0x40(%rdi)
    22c3:	00 
    22c4:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    22c8:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    22cd:	48 c7 41 30 06 00 00 	movq   $0x6,0x30(%rcx)
    22d4:	00 
    22d5:	48 b8 10 00 00 00 03 	movabs $0x300000010,%rax
    22dc:	00 00 00 
    22df:	48 83 c0 10          	add    $0x10,%rax
    22e3:	48 89 01             	mov    %rax,(%rcx)
    22e6:	48 b8 00 00 00 00 01 	movabs $0x40000100000000,%rax
    22ed:	00 40 00 
    22f0:	48 89 41 08          	mov    %rax,0x8(%rcx)
    22f4:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    22fb:	00 
    22fc:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    2303:	ff ff ff 
    2306:	48 8d 42 09          	lea    0x9(%rdx),%rax
    230a:	48 89 41 18          	mov    %rax,0x18(%rcx)
    230e:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2315:	00 00 00 
    2318:	48 89 41 20          	mov    %rax,0x20(%rcx)
    231c:	48 89 51 28          	mov    %rdx,0x28(%rcx)
    2320:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    2327:	48 8b 14 24          	mov    (%rsp),%rdx
    232b:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
    2332:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    2339:	00 80 3f 
    233c:	48 89 41 38          	mov    %rax,0x38(%rcx)
    2340:	48 89 41 40          	mov    %rax,0x40(%rcx)
    2344:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    234b:	00 00 00 
    234e:	49 8d 85 af c7 07 00 	lea    0x7c7af(%r13),%rax
    2355:	48 89 47 78          	mov    %rax,0x78(%rdi)
    2359:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
    2360:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    2367:	48 8b 57 58          	mov    0x58(%rdi),%rdx
    236b:	48 89 51 78          	mov    %rdx,0x78(%rcx)
    236f:	4c 89 81 80 00 00 00 	mov    %r8,0x80(%rcx)
    2376:	48 8d 57 70          	lea    0x70(%rdi),%rdx
    237a:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    2381:	00 
    2382:	48 89 41 70          	mov    %rax,0x70(%rcx)
    2386:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    238a:	8b 71 08             	mov    0x8(%rcx),%esi
    238d:	4c 8b 47 68          	mov    0x68(%rdi),%r8
    2391:	45 89 c1             	mov    %r8d,%r9d
    2394:	31 c0                	xor    %eax,%eax
    2396:	44 39 c6             	cmp    %r8d,%esi
    2399:	be 00 00 00 00       	mov    $0x0,%esi
    239e:	49 0f 47 f1          	cmova  %r9,%rsi
    23a2:	4c 8b 57 48          	mov    0x48(%rdi),%r10
    23a6:	4c 8b 59 10          	mov    0x10(%rcx),%r11
    23aa:	8b 12                	mov    (%rdx),%edx
    23ac:	48 0f af f2          	imul   %rdx,%rsi
    23b0:	c4 a1 78 10 84 1e 00 	vmovups 0x2e00(%rsi,%r11,1),%xmm0
    23b7:	2e 00 00 
    23ba:	c4 c1 78 11 02       	vmovups %xmm0,(%r10)
    23bf:	8b 71 08             	mov    0x8(%rcx),%esi
    23c2:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    23c6:	45 31 d2             	xor    %r10d,%r10d
    23c9:	41 89 f3             	mov    %esi,%r11d
    23cc:	45 31 c3             	xor    %r8d,%r11d
    23cf:	41 0f 94 c2          	sete   %r10b
    23d3:	31 db                	xor    %ebx,%ebx
    23d5:	89 f5                	mov    %esi,%ebp
    23d7:	44 29 c5             	sub    %r8d,%ebp
    23da:	0f 93 c3             	setae  %bl
    23dd:	49 0f 47 c1          	cmova  %r9,%rax
    23e1:	31 ee                	xor    %ebp,%esi
    23e3:	44 21 de             	and    %r11d,%esi
    23e6:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    23ec:	41 c1 e2 1e          	shl    $0x1e,%r10d
    23f0:	c1 e3 1d             	shl    $0x1d,%ebx
    23f3:	44 09 d3             	or     %r10d,%ebx
    23f6:	09 eb                	or     %ebp,%ebx
    23f8:	c1 ee 03             	shr    $0x3,%esi
    23fb:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    2401:	09 de                	or     %ebx,%esi
    2403:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    240a:	48 0f af c2          	imul   %rdx,%rax
    240e:	48 8b 94 08 80 30 00 	mov    0x3080(%rax,%rcx,1),%rdx
    2415:	00 
    2416:	48 8b b7 b0 00 00 00 	mov    0xb0(%rdi),%rsi
    241d:	4c 8b 87 d0 00 00 00 	mov    0xd0(%rdi),%r8
    2424:	48 89 37             	mov    %rsi,(%rdi)
    2427:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    242e:	00 
    242f:	48 8b b4 08 88 30 00 	mov    0x3088(%rax,%rcx,1),%rsi
    2436:	00 
    2437:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    243b:	49 89 10             	mov    %rdx,(%r8)
    243e:	49 89 70 08          	mov    %rsi,0x8(%r8)
    2442:	48 8b 94 08 90 30 00 	mov    0x3090(%rax,%rcx,1),%rdx
    2449:	00 
    244a:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    244e:	8b 84 08 98 30 00 00 	mov    0x3098(%rax,%rcx,1),%eax
    2455:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
    245c:	89 41 08             	mov    %eax,0x8(%rcx)
    245f:	48 8b 87 e8 00 00 00 	mov    0xe8(%rdi),%rax
    2466:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    246a:	48 89 47 40          	mov    %rax,0x40(%rdi)
    246e:	48 89 11             	mov    %rdx,(%rcx)
    2471:	49 8d 85 ea 0b 51 fd 	lea    -0x2aef416(%r13),%rax
    2478:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    247f:	48 89 fb             	mov    %rdi,%rbx
    2482:	c5 f8 77             	vzeroupper
    2485:	e8 00 00 00 00       	call   248a <f_8001161d0+0x248a>
    248a:	48 89 df             	mov    %rbx,%rdi
    248d:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2494:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    249b:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    24a2:	48 89 01             	mov    %rax,(%rcx)
    24a5:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
    24ac:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
    24b3:	48 8b b0 04 16 00 00 	mov    0x1604(%rax),%rsi
    24ba:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
    24be:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    24c2:	88 51 08             	mov    %dl,0x8(%rcx)
    24c5:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    24cc:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
    24d0:	8b 80 0c 16 00 00    	mov    0x160c(%rax),%eax
    24d6:	48 89 43 40          	mov    %rax,0x40(%rbx)
    24da:	48 c7 47 48 02 00 00 	movq   $0x2,0x48(%rdi)
    24e1:	00 
    24e2:	89 41 24             	mov    %eax,0x24(%rcx)
    24e5:	c7 81 bc 00 00 00 02 	movl   $0x2,0xbc(%rcx)
    24ec:	00 00 00 
    24ef:	e9 35 07 00 00       	jmp    2c29 <f_8001161d0+0x2c29>
    24f4:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    24fb:	00 
    24fc:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    2503:	48 c7 03 80 00 00 00 	movq   $0x80,(%rbx)
    250a:	48 b9 00 00 00 00 00 	movabs $0x60000000000000,%rcx
    2511:	00 60 00 
    2514:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    2518:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
    251f:	00 
    2520:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    2527:	ff ff ff 
    252a:	48 8d 4a 12          	lea    0x12(%rdx),%rcx
    252e:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    2532:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2539:	00 00 00 
    253c:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
    2540:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    2544:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    254a:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    254e:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    2555:	00 80 3f 
    2558:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    255c:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
    2560:	48 83 c3 38          	add    $0x38,%rbx
    2564:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
    256b:	00 00 00 
    256e:	4c 8d 8a 6d 4f 0a 00 	lea    0xa4f6d(%rdx),%r9
    2575:	e9 e1 04 00 00       	jmp    2a5b <f_8001161d0+0x2a5b>
    257a:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
    2581:	48 8b 97 a0 00 00 00 	mov    0xa0(%rdi),%rdx
    2588:	48 8b 92 c8 1e 00 00 	mov    0x1ec8(%rdx),%rdx
    258f:	48 89 57 08          	mov    %rdx,0x8(%rdi)
    2593:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    2598:	48 89 77 60          	mov    %rsi,0x60(%rdi)
    259c:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    25a3:	00 
    25a4:	44 0f b6 49 08       	movzbl 0x8(%rcx),%r9d
    25a9:	4c 89 4f 68          	mov    %r9,0x68(%rdi)
    25ad:	8b 5a 08             	mov    0x8(%rdx),%ebx
    25b0:	4d 69 f1 e0 3c 00 00 	imul   $0x3ce0,%r9,%r14
    25b7:	31 c9                	xor    %ecx,%ecx
    25b9:	44 39 cb             	cmp    %r9d,%ebx
    25bc:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    25c0:	48 c7 47 70 e0 3c 00 	movq   $0x3ce0,0x70(%rdi)
    25c7:	00 
    25c8:	4c 0f 46 f1          	cmovbe %rcx,%r14
    25cc:	49 8b 94 16 40 3c 00 	mov    0x3c40(%r14,%rdx,1),%rdx
    25d3:	00 
    25d4:	48 89 17             	mov    %rdx,(%rdi)
    25d7:	4c 8b 8f 00 01 00 00 	mov    0x100(%rdi),%r9
    25de:	45 89 91 a0 00 00 00 	mov    %r10d,0xa0(%r9)
    25e5:	49 89 b1 88 00 00 00 	mov    %rsi,0x88(%r9)
    25ec:	48 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rdx
    25f3:	ff 7f 7f 
    25f6:	49 89 91 90 00 00 00 	mov    %rdx,0x90(%r9)
    25fd:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2604:	00 
    2605:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2609:	41 c7 81 bc 00 00 00 	movl   $0x0,0xbc(%r9)
    2610:	00 00 00 00 
    2614:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2618:	c4 c1 78 11 41 58    	vmovups %xmm0,0x58(%r9)
    261e:	49 c7 01 20 00 00 00 	movq   $0x20,(%r9)
    2625:	48 b8 00 00 00 00 00 	movabs $0x42080000000000,%rax
    262c:	08 42 00 
    262f:	49 89 41 08          	mov    %rax,0x8(%r9)
    2633:	49 c7 41 48 00 00 00 	movq   $0x0,0x48(%r9)
    263a:	00 
    263b:	49 89 69 50          	mov    %rbp,0x50(%r9)
    263f:	49 c7 41 30 07 00 00 	movq   $0x7,0x30(%r9)
    2646:	00 
    2647:	49 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%r9)
    264e:	00 
    264f:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    2656:	ff ff ff 
    2659:	48 8d 42 0a          	lea    0xa(%rdx),%rax
    265d:	49 89 41 18          	mov    %rax,0x18(%r9)
    2661:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2668:	00 00 00 
    266b:	49 89 41 20          	mov    %rax,0x20(%r9)
    266f:	49 89 51 28          	mov    %rdx,0x28(%r9)
    2673:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    267a:	48 8b 14 24          	mov    (%rsp),%rdx
    267e:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
    2685:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    268c:	00 80 3f 
    268f:	49 89 41 38          	mov    %rax,0x38(%r9)
    2693:	49 89 41 40          	mov    %rax,0x40(%r9)
    2697:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    269e:	00 00 00 
    26a1:	49 8d 85 c5 e4 0b 00 	lea    0xbe4c5(%r13),%rax
    26a8:	48 89 47 78          	mov    %rax,0x78(%rdi)
    26ac:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
    26b3:	4d 89 81 98 00 00 00 	mov    %r8,0x98(%r9)
    26ba:	48 8b 57 58          	mov    0x58(%rdi),%rdx
    26be:	49 89 51 78          	mov    %rdx,0x78(%r9)
    26c2:	4d 89 81 80 00 00 00 	mov    %r8,0x80(%r9)
    26c9:	49 c7 41 68 00 00 00 	movq   $0x0,0x68(%r9)
    26d0:	00 
    26d1:	49 89 41 70          	mov    %rax,0x70(%r9)
    26d5:	48 8b 47 08          	mov    0x8(%rdi),%rax
    26d9:	4c 8b 47 68          	mov    0x68(%rdi),%r8
    26dd:	45 89 c1             	mov    %r8d,%r9d
    26e0:	44 39 40 08          	cmp    %r8d,0x8(%rax)
    26e4:	be 00 00 00 00       	mov    $0x0,%esi
    26e9:	49 0f 47 f1          	cmova  %r9,%rsi
    26ed:	4c 8b 57 48          	mov    0x48(%rdi),%r10
    26f1:	4c 8b 58 10          	mov    0x10(%rax),%r11
    26f5:	8b 57 70             	mov    0x70(%rdi),%edx
    26f8:	48 0f af f2          	imul   %rdx,%rsi
    26fc:	c4 a1 78 10 84 1e b0 	vmovups 0x30b0(%rsi,%r11,1),%xmm0
    2703:	30 00 00 
    2706:	c4 c1 78 11 02       	vmovups %xmm0,(%r10)
    270b:	8b 70 08             	mov    0x8(%rax),%esi
    270e:	45 31 d2             	xor    %r10d,%r10d
    2711:	41 89 f3             	mov    %esi,%r11d
    2714:	45 31 c3             	xor    %r8d,%r11d
    2717:	41 0f 94 c2          	sete   %r10b
    271b:	31 db                	xor    %ebx,%ebx
    271d:	89 f5                	mov    %esi,%ebp
    271f:	44 29 c5             	sub    %r8d,%ebp
    2722:	49 0f 47 c9          	cmova  %r9,%rcx
    2726:	0f 93 c3             	setae  %bl
    2729:	31 ee                	xor    %ebp,%esi
    272b:	44 21 de             	and    %r11d,%esi
    272e:	41 c1 e2 1e          	shl    $0x1e,%r10d
    2732:	c1 e3 1d             	shl    $0x1d,%ebx
    2735:	44 09 d3             	or     %r10d,%ebx
    2738:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    273e:	09 eb                	or     %ebp,%ebx
    2740:	48 8b 40 10          	mov    0x10(%rax),%rax
    2744:	c1 ee 03             	shr    $0x3,%esi
    2747:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    274d:	09 de                	or     %ebx,%esi
    274f:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    2756:	48 0f af ca          	imul   %rdx,%rcx
    275a:	48 8b 94 01 30 33 00 	mov    0x3330(%rcx,%rax,1),%rdx
    2761:	00 
    2762:	48 8b b4 01 38 33 00 	mov    0x3338(%rcx,%rax,1),%rsi
    2769:	00 
    276a:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    276e:	4c 8b 87 d0 00 00 00 	mov    0xd0(%rdi),%r8
    2775:	49 89 10             	mov    %rdx,(%r8)
    2778:	49 89 70 08          	mov    %rsi,0x8(%r8)
    277c:	48 8b 94 01 40 33 00 	mov    0x3340(%rcx,%rax,1),%rdx
    2783:	00 
    2784:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    2788:	8b 84 01 48 33 00 00 	mov    0x3348(%rcx,%rax,1),%eax
    278f:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
    2796:	89 41 08             	mov    %eax,0x8(%rcx)
    2799:	48 8b 87 e8 00 00 00 	mov    0xe8(%rdi),%rax
    27a0:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    27a4:	48 89 47 40          	mov    %rax,0x40(%rdi)
    27a8:	48 89 11             	mov    %rdx,(%rcx)
    27ab:	49 8d 85 72 0d 51 fd 	lea    -0x2aef28e(%r13),%rax
    27b2:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    27b9:	48 89 fb             	mov    %rdi,%rbx
    27bc:	c5 f8 77             	vzeroupper
    27bf:	e8 00 00 00 00       	call   27c4 <f_8001161d0+0x27c4>
    27c4:	48 89 df             	mov    %rbx,%rdi
    27c7:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    27ce:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    27d5:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    27dc:	48 89 01             	mov    %rax,(%rcx)
    27df:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    27e6:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    27ea:	48 89 43 40          	mov    %rax,0x40(%rbx)
    27ee:	88 41 08             	mov    %al,0x8(%rcx)
    27f1:	b9 bc 00 00 00       	mov    $0xbc,%ecx
    27f6:	48 03 8b 00 01 00 00 	add    0x100(%rbx),%rcx
    27fd:	e9 d4 08 00 00       	jmp    30d6 <f_8001161d0+0x30d6>
    2802:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2806:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    280d:	48 c7 01 01 00 00 00 	movq   $0x1,(%rcx)
    2814:	48 ba 00 00 00 00 00 	movabs $0x40000000000000,%rdx
    281b:	00 40 00 
    281e:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    2822:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    2829:	00 
    282a:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    2831:	ff ff ff 
    2834:	4d 89 c1             	mov    %r8,%r9
    2837:	49 89 d0             	mov    %rdx,%r8
    283a:	48 83 c2 15          	add    $0x15,%rdx
    283e:	48 89 51 18          	mov    %rdx,0x18(%rcx)
    2842:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2849:	00 
    284a:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2851:	00 00 00 
    2854:	48 89 41 20          	mov    %rax,0x20(%rcx)
    2858:	4c 89 41 28          	mov    %r8,0x28(%rcx)
    285c:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    2861:	48 89 41 30          	mov    %rax,0x30(%rcx)
    2865:	49 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r8
    286c:	00 80 3f 
    286f:	4c 89 41 38          	mov    %r8,0x38(%rcx)
    2873:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    287a:	00 00 00 
    287d:	48 8d 80 7c 4f 0a 00 	lea    0xa4f7c(%rax),%rax
    2884:	48 89 41 70          	mov    %rax,0x70(%rcx)
    2888:	48 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rbx
    288f:	ff 7f 7f 
    2892:	48 89 59 78          	mov    %rbx,0x78(%rcx)
    2896:	4c 89 89 80 00 00 00 	mov    %r9,0x80(%rcx)
    289d:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    28a2:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    28a9:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 28b1 <f_8001161d0+0x28b1>
    28b0:	00 
    28b1:	c5 fc 11 47 60       	vmovups %ymm0,0x60(%rdi)
    28b6:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    28bd:	48 8b 14 24          	mov    (%rsp),%rdx
    28c1:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
    28c8:	4c 89 41 40          	mov    %r8,0x40(%rcx)
    28cc:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    28d3:	00 
    28d4:	48 89 99 90 00 00 00 	mov    %rbx,0x90(%rcx)
    28db:	4c 89 89 98 00 00 00 	mov    %r9,0x98(%rcx)
    28e2:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    28e9:	00 
    28ea:	48 89 69 50          	mov    %rbp,0x50(%rcx)
    28ee:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    28f2:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    28f7:	48 c7 47 50 03 00 00 	movq   $0x3,0x50(%rdi)
    28fe:	00 
    28ff:	b8 03 00 00 00       	mov    $0x3,%eax
    2904:	e9 f0 01 00 00       	jmp    2af9 <f_8001161d0+0x2af9>
    2909:	48 c7 47 40 b0 1e 00 	movq   $0x1eb0,0x40(%rdi)
    2910:	00 
    2911:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    2918:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    291f:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    2923:	48 89 47 10          	mov    %rax,0x10(%rdi)
    2927:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    292c:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
    2933:	48 89 07             	mov    %rax,(%rdi)
    2936:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    293d:	00 00 00 
    2940:	49 8d 85 2e 0c 51 fd 	lea    -0x2aef3d2(%r13),%rax
    2947:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    294e:	48 89 fb             	mov    %rdi,%rbx
    2951:	c5 f8 77             	vzeroupper
    2954:	e8 00 00 00 00       	call   2959 <f_8001161d0+0x2959>
    2959:	48 89 df             	mov    %rbx,%rdi
    295c:	e9 c8 02 00 00       	jmp    2c29 <f_8001161d0+0x2c29>
    2961:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    2968:	00 
    2969:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    2970:	48 c7 03 03 00 00 00 	movq   $0x3,(%rbx)
    2977:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    297e:	00 40 00 
    2981:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    2985:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
    298c:	00 
    298d:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    2994:	ff ff ff 
    2997:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    299b:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    299f:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    29a6:	00 00 00 
    29a9:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
    29ad:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    29b1:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    29b7:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    29bb:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    29c2:	00 80 3f 
    29c5:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    29c9:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
    29cd:	48 83 c3 38          	add    $0x38,%rbx
    29d1:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
    29d8:	00 00 00 
    29db:	4c 8d 8a fb b3 05 00 	lea    0x5b3fb(%rdx),%r9
    29e2:	eb 77                	jmp    2a5b <f_8001161d0+0x2a5b>
    29e4:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    29eb:	ff ff ff 
    29ee:	48 8d 4a 0e          	lea    0xe(%rdx),%rcx
    29f2:	48 89 4f 78          	mov    %rcx,0x78(%rdi)
    29f6:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    29fd:	48 c7 03 00 04 00 00 	movq   $0x400,(%rbx)
    2a04:	48 c7 43 08 00 00 00 	movq   $0x0,0x8(%rbx)
    2a0b:	00 
    2a0c:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
    2a13:	00 
    2a14:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    2a18:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2a1f:	00 00 00 
    2a22:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
    2a26:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    2a2a:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    2a30:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    2a34:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    2a3b:	00 80 3f 
    2a3e:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    2a42:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
    2a46:	48 83 c3 38          	add    $0x38,%rbx
    2a4a:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
    2a51:	00 00 00 
    2a54:	4c 8d 8a d9 85 00 00 	lea    0x85d9(%rdx),%r9
    2a5b:	4c 89 01             	mov    %r8,(%rcx)
    2a5e:	4c 89 33             	mov    %r14,(%rbx)
    2a61:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    2a68:	4c 89 49 70          	mov    %r9,0x70(%rcx)
    2a6c:	49 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r9
    2a73:	ff 7f 7f 
    2a76:	4c 89 49 78          	mov    %r9,0x78(%rcx)
    2a7a:	48 ba ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdx
    2a81:	ff 7f ff 
    2a84:	48 89 57 68          	mov    %rdx,0x68(%rdi)
    2a88:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2a8c:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2a93:	00 
    2a94:	48 89 91 80 00 00 00 	mov    %rdx,0x80(%rcx)
    2a9b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2aa0:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    2aa7:	4c 8b 04 24          	mov    (%rsp),%r8
    2aab:	4c 89 47 60          	mov    %r8,0x60(%rdi)
    2aaf:	4c 89 71 40          	mov    %r14,0x40(%rcx)
    2ab3:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    2aba:	00 
    2abb:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    2ac2:	4c 89 80 a4 00 00 00 	mov    %r8,0xa4(%rax)
    2ac9:	48 89 69 50          	mov    %rbp,0x50(%rcx)
    2acd:	48 c7 41 58 00 00 00 	movq   $0x0,0x58(%rcx)
    2ad4:	00 
    2ad5:	48 c7 47 50 02 00 00 	movq   $0x2,0x50(%rdi)
    2adc:	00 
    2add:	4c 89 89 90 00 00 00 	mov    %r9,0x90(%rcx)
    2ae4:	48 89 91 98 00 00 00 	mov    %rdx,0x98(%rcx)
    2aeb:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2aef:	c5 f8 11 41 60       	vmovups %xmm0,0x60(%rcx)
    2af4:	b8 02 00 00 00       	mov    $0x2,%eax
    2af9:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
    2afe:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
    2b05:	89 81 bc 00 00 00    	mov    %eax,0xbc(%rcx)
    2b0b:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
    2b12:	48 8b 87 a0 00 00 00 	mov    0xa0(%rdi),%rax
    2b19:	48 8b 80 c8 1e 00 00 	mov    0x1ec8(%rax),%rax
    2b20:	0f b6 71 08          	movzbl 0x8(%rcx),%esi
    2b24:	4c 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%r8
    2b2b:	31 c9                	xor    %ecx,%ecx
    2b2d:	39 70 08             	cmp    %esi,0x8(%rax)
    2b30:	ba 00 00 00 00       	mov    $0x0,%edx
    2b35:	49 0f 47 d0          	cmova  %r8,%rdx
    2b39:	4c 8b 48 10          	mov    0x10(%rax),%r9
    2b3d:	4e 8b 94 0a 08 2e 00 	mov    0x2e08(%rdx,%r9,1),%r10
    2b44:	00 
    2b45:	4c 89 57 68          	mov    %r10,0x68(%rdi)
    2b49:	4a 8b 94 0a 00 2e 00 	mov    0x2e00(%rdx,%r9,1),%rdx
    2b50:	00 
    2b51:	49 89 13             	mov    %rdx,(%r11)
    2b54:	4d 89 53 08          	mov    %r10,0x8(%r11)
    2b58:	44 8b 48 08          	mov    0x8(%rax),%r9d
    2b5c:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2b60:	48 89 57 60          	mov    %rdx,0x60(%rdi)
    2b64:	45 31 d2             	xor    %r10d,%r10d
    2b67:	45 31 db             	xor    %r11d,%r11d
    2b6a:	44 89 cb             	mov    %r9d,%ebx
    2b6d:	29 f3                	sub    %esi,%ebx
    2b6f:	49 0f 47 c8          	cmova  %r8,%rcx
    2b73:	41 0f 94 c2          	sete   %r10b
    2b77:	41 0f 93 c3          	setae  %r11b
    2b7b:	c4 c2 60 f2 f1       	andn   %r9d,%ebx,%esi
    2b80:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    2b86:	41 c1 e2 1e          	shl    $0x1e,%r10d
    2b8a:	41 c1 e3 1d          	shl    $0x1d,%r11d
    2b8e:	45 09 d3             	or     %r10d,%r11d
    2b91:	41 09 db             	or     %ebx,%r11d
    2b94:	c1 ee 03             	shr    $0x3,%esi
    2b97:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    2b9d:	44 09 de             	or     %r11d,%esi
    2ba0:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    2ba7:	48 8b b4 0a 80 30 00 	mov    0x3080(%rdx,%rcx,1),%rsi
    2bae:	00 
    2baf:	4c 8b 84 0a 88 30 00 	mov    0x3088(%rdx,%rcx,1),%r8
    2bb6:	00 
    2bb7:	48 89 77 58          	mov    %rsi,0x58(%rdi)
    2bbb:	49 89 75 00          	mov    %rsi,0x0(%r13)
    2bbf:	4d 89 45 08          	mov    %r8,0x8(%r13)
    2bc3:	8b b4 0a 98 30 00 00 	mov    0x3098(%rdx,%rcx,1),%esi
    2bca:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    2bce:	48 8b 8c 0a 90 30 00 	mov    0x3090(%rdx,%rcx,1),%rcx
    2bd5:	00 
    2bd6:	48 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%rdx
    2bdd:	48 89 0a             	mov    %rcx,(%rdx)
    2be0:	89 72 08             	mov    %esi,0x8(%rdx)
    2be3:	8b 50 20             	mov    0x20(%rax),%edx
    2be6:	8b 48 24             	mov    0x24(%rax),%ecx
    2be9:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    2bed:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    2bf1:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    2bf8:	c7 80 b4 00 00 00 00 	movl   $0x0,0xb4(%rax)
    2bff:	00 00 00 
    2c02:	48 8b b7 c0 00 00 00 	mov    0xc0(%rdi),%rsi
    2c09:	c7 86 b1 00 00 00 00 	movl   $0x0,0xb1(%rsi)
    2c10:	00 00 00 
    2c13:	88 90 b0 00 00 00    	mov    %dl,0xb0(%rax)
    2c19:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    2c20:	00 00 00 
    2c23:	88 88 b8 00 00 00    	mov    %cl,0xb8(%rax)
    2c29:	4c 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%r9
    2c30:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    2c37:	8b 08                	mov    (%rax),%ecx
    2c39:	48 89 4f 50          	mov    %rcx,0x50(%rdi)
    2c3d:	49 8d 51 1c          	lea    0x1c(%r9),%rdx
    2c41:	41 8b 71 1c          	mov    0x1c(%r9),%esi
    2c45:	48 89 57 40          	mov    %rdx,0x40(%rdi)
    2c49:	48 89 77 48          	mov    %rsi,0x48(%rdi)
    2c4d:	89 70 48             	mov    %esi,0x48(%rax)
    2c50:	4d 8d 51 2c          	lea    0x2c(%r9),%r10
    2c54:	45 8b 41 2c          	mov    0x2c(%r9),%r8d
    2c58:	45 31 db             	xor    %r11d,%r11d
    2c5b:	4d 85 c0             	test   %r8,%r8
    2c5e:	41 0f 94 c3          	sete   %r11b
    2c62:	4c 89 97 b0 00 00 00 	mov    %r10,0xb0(%rdi)
    2c69:	4c 89 47 60          	mov    %r8,0x60(%rdi)
    2c6d:	45 8b 49 14          	mov    0x14(%r9),%r9d
    2c71:	45 31 d2             	xor    %r10d,%r10d
    2c74:	41 85 c9             	test   %ecx,%r9d
    2c77:	41 0f 95 c2          	setne  %r10b
    2c7b:	4c 89 57 58          	mov    %r10,0x58(%rdi)
    2c7f:	45 89 c2             	mov    %r8d,%r10d
    2c82:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    2c89:	44 89 db             	mov    %r11d,%ebx
    2c8c:	c1 e3 1e             	shl    $0x1e,%ebx
    2c8f:	49 01 da             	add    %rbx,%r10
    2c92:	49 81 c2 00 00 00 20 	add    $0x20000000,%r10
    2c99:	4c 89 97 10 01 00 00 	mov    %r10,0x110(%rdi)
    2ca0:	41 c1 e8 1f          	shr    $0x1f,%r8d
    2ca4:	45 08 c3             	or     %r8b,%r11b
    2ca7:	74 0d                	je     2cb6 <f_8001161d0+0x2cb6>
    2ca9:	48 c7 47 58 00 00 00 	movq   $0x0,0x58(%rdi)
    2cb0:	00 
    2cb1:	e9 73 01 00 00       	jmp    2e29 <f_8001161d0+0x2e29>
    2cb6:	41 85 c9             	test   %ecx,%r9d
    2cb9:	0f 84 6a 01 00 00    	je     2e29 <f_8001161d0+0x2e29>
    2cbf:	4c 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%r9
    2cc6:	4c 8b 97 a8 00 00 00 	mov    0xa8(%rdi),%r10
    2ccd:	4d 8d 81 40 01 00 00 	lea    0x140(%r9),%r8
    2cd4:	4c 89 87 c0 00 00 00 	mov    %r8,0xc0(%rdi)
    2cdb:	45 89 d0             	mov    %r10d,%r8d
    2cde:	4d 63 d2             	movslq %r10d,%r10
    2ce1:	49 c1 fa 1f          	sar    $0x1f,%r10
    2ce5:	49 bb 00 00 00 00 ff 	movabs $0xffffffff00000000,%r11
    2cec:	ff ff ff 
    2cef:	4d 21 da             	and    %r11,%r10
    2cf2:	4d 09 c2             	or     %r8,%r10
    2cf5:	4c 89 97 c8 00 00 00 	mov    %r10,0xc8(%rdi)
    2cfc:	47 0f b6 8c 11 40 01 	movzbl 0x140(%r9,%r10,1),%r9d
    2d03:	00 00 
    2d05:	4c 89 4f 58          	mov    %r9,0x58(%rdi)
    2d09:	41 f6 c1 01          	test   $0x1,%r9b
    2d0d:	0f 84 16 01 00 00    	je     2e29 <f_8001161d0+0x2e29>
    2d13:	44 0f b6 48 0c       	movzbl 0xc(%rax),%r9d
    2d18:	4c 89 4f 58          	mov    %r9,0x58(%rdi)
    2d1c:	41 f6 c1 01          	test   $0x1,%r9b
    2d20:	74 09                	je     2d2b <f_8001161d0+0x2d2b>
    2d22:	48 09 ce             	or     %rcx,%rsi
    2d25:	48 89 77 48          	mov    %rsi,0x48(%rdi)
    2d29:	89 32                	mov    %esi,(%rdx)
    2d2b:	48 c7 47 40 d0 00 00 	movq   $0xd0,0x40(%rdi)
    2d32:	00 
    2d33:	48 89 47 08          	mov    %rax,0x8(%rdi)
    2d37:	49 63 c0             	movslq %r8d,%rax
    2d3a:	48 69 c0 d0 00 00 00 	imul   $0xd0,%rax,%rax
    2d41:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
    2d48:	48 8d 14 01          	lea    (%rcx,%rax,1),%rdx
    2d4c:	48 89 97 d0 00 00 00 	mov    %rdx,0xd0(%rdi)
    2d53:	48 c7 47 10 c0 00 00 	movq   $0xc0,0x10(%rdi)
    2d5a:	00 
    2d5b:	48 8d 84 01 40 0d 00 	lea    0xd40(%rcx,%rax,1),%rax
    2d62:	00 
    2d63:	48 89 87 a8 00 00 00 	mov    %rax,0xa8(%rdi)
    2d6a:	48 89 07             	mov    %rax,(%rdi)
    2d6d:	49 8d 85 6e 12 51 fd 	lea    -0x2aeed92(%r13),%rax
    2d74:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    2d7b:	48 89 fb             	mov    %rdi,%rbx
    2d7e:	c5 f8 77             	vzeroupper
    2d81:	e8 00 00 00 00       	call   2d86 <f_8001161d0+0x2d86>
    2d86:	48 89 df             	mov    %rbx,%rdi
    2d89:	48 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%rax
    2d90:	80 88 38 0d 00 00 01 	orb    $0x1,0xd38(%rax)
    2d97:	4c 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%r8
    2d9e:	41 0f b6 80 81 3a 00 	movzbl 0x3a81(%r8),%eax
    2da5:	00 
    2da6:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2daa:	a8 40                	test   $0x40,%al
    2dac:	74 7b                	je     2e29 <f_8001161d0+0x2e29>
    2dae:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    2db5:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
    2dbc:	0f b6 04 01          	movzbl (%rcx,%rax,1),%eax
    2dc0:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2dc4:	a8 02                	test   $0x2,%al
    2dc6:	74 61                	je     2e29 <f_8001161d0+0x2e29>
    2dc8:	49 8b 80 60 3b 00 00 	mov    0x3b60(%r8),%rax
    2dcf:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2dd3:	48 85 c0             	test   %rax,%rax
    2dd6:	74 51                	je     2e29 <f_8001161d0+0x2e29>
    2dd8:	41 0f b6 80 85 3a 00 	movzbl 0x3a85(%r8),%eax
    2ddf:	00 
    2de0:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2de4:	a8 02                	test   $0x2,%al
    2de6:	74 41                	je     2e29 <f_8001161d0+0x2e29>
    2de8:	48 8b 87 a8 00 00 00 	mov    0xa8(%rdi),%rax
    2def:	48 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%rcx
    2df6:	8b 00                	mov    (%rax),%eax
    2df8:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2dfc:	8b 49 10             	mov    0x10(%rcx),%ecx
    2dff:	31 d2                	xor    %edx,%edx
    2e01:	c4 e2 70 f2 c0       	andn   %eax,%ecx,%eax
    2e06:	0f 94 c2             	sete   %dl
    2e09:	89 c6                	mov    %eax,%esi
    2e0b:	81 e6 00 00 00 80    	and    $0x80000000,%esi
    2e11:	c1 e2 1e             	shl    $0x1e,%edx
    2e14:	09 f2                	or     %esi,%edx
    2e16:	48 89 4f 48          	mov    %rcx,0x48(%rdi)
    2e1a:	48 89 97 10 01 00 00 	mov    %rdx,0x110(%rdi)
    2e21:	85 c0                	test   %eax,%eax
    2e23:	0f 84 ac 05 00 00    	je     33d5 <f_8001161d0+0x33d5>
    2e29:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    2e30:	48 8b 88 20 01 00 00 	mov    0x120(%rax),%rcx
    2e37:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    2e3e:	48 89 8f a0 00 00 00 	mov    %rcx,0xa0(%rdi)
    2e45:	48 89 97 98 00 00 00 	mov    %rdx,0x98(%rdi)
    2e4c:	48 8b 88 10 01 00 00 	mov    0x110(%rax),%rcx
    2e53:	48 8b 90 18 01 00 00 	mov    0x118(%rax),%rdx
    2e5a:	48 89 8f b0 00 00 00 	mov    %rcx,0xb0(%rdi)
    2e61:	48 89 97 a8 00 00 00 	mov    %rdx,0xa8(%rdi)
    2e68:	48 8b 88 00 01 00 00 	mov    0x100(%rax),%rcx
    2e6f:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    2e76:	48 89 8f c0 00 00 00 	mov    %rcx,0xc0(%rdi)
    2e7d:	48 89 97 b8 00 00 00 	mov    %rdx,0xb8(%rdi)
    2e84:	48 8b 88 f0 00 00 00 	mov    0xf0(%rax),%rcx
    2e8b:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
    2e92:	48 89 8f d0 00 00 00 	mov    %rcx,0xd0(%rdi)
    2e99:	48 89 97 c8 00 00 00 	mov    %rdx,0xc8(%rdi)
    2ea0:	48 8b 88 e0 00 00 00 	mov    0xe0(%rax),%rcx
    2ea7:	48 8b 90 e8 00 00 00 	mov    0xe8(%rax),%rdx
    2eae:	48 89 8f e0 00 00 00 	mov    %rcx,0xe0(%rdi)
    2eb5:	48 89 97 d8 00 00 00 	mov    %rdx,0xd8(%rdi)
    2ebc:	c5 f8 10 80 d0 00 00 	vmovups 0xd0(%rax),%xmm0
    2ec3:	00 
    2ec4:	c5 f8 11 87 e8 00 00 	vmovups %xmm0,0xe8(%rdi)
    2ecb:	00 
    2ecc:	48 05 30 01 00 00    	add    $0x130,%rax
    2ed2:	48 89 87 00 01 00 00 	mov    %rax,0x100(%rdi)
    2ed9:	48 83 c4 18          	add    $0x18,%rsp
    2edd:	5b                   	pop    %rbx
    2ede:	41 5c                	pop    %r12
    2ee0:	41 5d                	pop    %r13
    2ee2:	41 5e                	pop    %r14
    2ee4:	41 5f                	pop    %r15
    2ee6:	5d                   	pop    %rbp
    2ee7:	c5 f8 77             	vzeroupper
    2eea:	c3                   	ret
    2eeb:	4c 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%r9
    2ef2:	49 8b 89 c8 1e 00 00 	mov    0x1ec8(%r9),%rcx
    2ef9:	48 89 8f b0 00 00 00 	mov    %rcx,0xb0(%rdi)
    2f00:	48 89 ee             	mov    %rbp,%rsi
    2f03:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    2f0a:	ff ff ff 
    2f0d:	48 8d 55 1a          	lea    0x1a(%rbp),%rdx
    2f11:	48 89 57 70          	mov    %rdx,0x70(%rdi)
    2f15:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2f19:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    2f20:	48 c7 01 00 20 00 00 	movq   $0x2000,(%rcx)
    2f27:	48 c7 41 08 00 00 00 	movq   $0x0,0x8(%rcx)
    2f2e:	00 
    2f2f:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    2f36:	00 
    2f37:	48 89 51 18          	mov    %rdx,0x18(%rcx)
    2f3b:	48 8b 97 98 00 00 00 	mov    0x98(%rdi),%rdx
    2f42:	48 89 57 08          	mov    %rdx,0x8(%rdi)
    2f46:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2f4d:	00 
    2f4e:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
    2f55:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2f5c:	00 00 00 
    2f5f:	48 89 41 20          	mov    %rax,0x20(%rcx)
    2f63:	48 89 69 28          	mov    %rbp,0x28(%rcx)
    2f67:	49 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r10
    2f6e:	00 80 3f 
    2f71:	4c 89 57 68          	mov    %r10,0x68(%rdi)
    2f75:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    2f7a:	48 89 41 30          	mov    %rax,0x30(%rcx)
    2f7e:	4c 89 51 38          	mov    %r10,0x38(%rcx)
    2f82:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    2f89:	00 00 00 
    2f8c:	49 8d 85 95 53 09 00 	lea    0x95395(%r13),%rax
    2f93:	48 89 41 70          	mov    %rax,0x70(%rcx)
    2f97:	48 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rbx
    2f9e:	ff 7f 7f 
    2fa1:	48 89 59 78          	mov    %rbx,0x78(%rcx)
    2fa5:	4c 89 81 80 00 00 00 	mov    %r8,0x80(%rcx)
    2fac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2fb1:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    2fb8:	48 8b 14 24          	mov    (%rsp),%rdx
    2fbc:	48 89 57 60          	mov    %rdx,0x60(%rdi)
    2fc0:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    2fc7:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
    2fce:	48 89 99 90 00 00 00 	mov    %rbx,0x90(%rcx)
    2fd5:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    2fdc:	48 c7 47 50 b0 1e 00 	movq   $0x1eb0,0x50(%rdi)
    2fe3:	00 
    2fe4:	49 81 c1 b0 1e 00 00 	add    $0x1eb0,%r9
    2feb:	4c 89 0f             	mov    %r9,(%rdi)
    2fee:	48 89 71 50          	mov    %rsi,0x50(%rcx)
    2ff2:	48 c7 41 58 00 00 00 	movq   $0x0,0x58(%rcx)
    2ff9:	00 
    2ffa:	48 c7 47 48 03 00 00 	movq   $0x3,0x48(%rdi)
    3001:	00 
    3002:	c7 81 bc 00 00 00 03 	movl   $0x3,0xbc(%rcx)
    3009:	00 00 00 
    300c:	4c 89 51 40          	mov    %r10,0x40(%rcx)
    3010:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    3017:	00 
    3018:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    301c:	c5 f8 11 41 60       	vmovups %xmm0,0x60(%rcx)
    3021:	49 8d 85 92 14 51 fd 	lea    -0x2aeeb6e(%r13),%rax
    3028:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    302f:	48 89 fb             	mov    %rdi,%rbx
    3032:	c5 f8 77             	vzeroupper
    3035:	e8 00 00 00 00       	call   303a <f_8001161d0+0x303a>
    303a:	48 89 df             	mov    %rbx,%rdi
    303d:	48 8b 33             	mov    (%rbx),%rsi
    3040:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    3047:	0f b6 48 08          	movzbl 0x8(%rax),%ecx
    304b:	48 8b 93 b0 00 00 00 	mov    0xb0(%rbx),%rdx
    3052:	8b 42 08             	mov    0x8(%rdx),%eax
    3055:	45 31 c0             	xor    %r8d,%r8d
    3058:	45 31 c9             	xor    %r9d,%r9d
    305b:	41 89 c2             	mov    %eax,%r10d
    305e:	41 29 ca             	sub    %ecx,%r10d
    3061:	41 0f 94 c0          	sete   %r8b
    3065:	41 0f 93 c1          	setae  %r9b
    3069:	c4 62 28 f2 d8       	andn   %eax,%r10d,%r11d
    306e:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    3075:	41 c1 e0 1e          	shl    $0x1e,%r8d
    3079:	41 c1 e1 1d          	shl    $0x1d,%r9d
    307d:	45 09 c1             	or     %r8d,%r9d
    3080:	41 c1 eb 03          	shr    $0x3,%r11d
    3084:	41 81 e3 00 00 00 10 	and    $0x10000000,%r11d
    308b:	45 09 d3             	or     %r10d,%r11d
    308e:	45 09 cb             	or     %r9d,%r11d
    3091:	4c 69 c1 e0 3c 00 00 	imul   $0x3ce0,%rcx,%r8
    3098:	31 c0                	xor    %eax,%eax
    309a:	41 81 f9 00 00 00 20 	cmp    $0x20000000,%r9d
    30a1:	49 0f 44 c0          	cmove  %r8,%rax
    30a5:	4c 89 9b 10 01 00 00 	mov    %r11,0x110(%rbx)
    30ac:	48 03 42 10          	add    0x10(%rdx),%rax
    30b0:	40 f6 c6 01          	test   $0x1,%sil
    30b4:	75 33                	jne    30e9 <f_8001161d0+0x30e9>
    30b6:	41 b9 5c 00 00 00    	mov    $0x5c,%r9d
    30bc:	41 ba 58 00 00 00    	mov    $0x58,%r10d
    30c2:	41 bb 54 00 00 00    	mov    $0x54,%r11d
    30c8:	bb 50 00 00 00       	mov    $0x50,%ebx
    30cd:	eb 35                	jmp    3104 <f_8001161d0+0x3104>
    30cf:	48 81 c1 bc 00 00 00 	add    $0xbc,%rcx
    30d6:	48 c7 47 40 02 00 00 	movq   $0x2,0x40(%rdi)
    30dd:	00 
    30de:	c7 01 02 00 00 00    	movl   $0x2,(%rcx)
    30e4:	e9 40 fb ff ff       	jmp    2c29 <f_8001161d0+0x2c29>
    30e9:	48 89 47 68          	mov    %rax,0x68(%rdi)
    30ed:	41 b9 0c 2e 00 00    	mov    $0x2e0c,%r9d
    30f3:	41 ba 08 2e 00 00    	mov    $0x2e08,%r10d
    30f9:	41 bb 04 2e 00 00    	mov    $0x2e04,%r11d
    30ff:	bb 00 2e 00 00       	mov    $0x2e00,%ebx
    3104:	8b 1c 18             	mov    (%rax,%rbx,1),%ebx
    3107:	48 89 9f 00 02 00 00 	mov    %rbx,0x200(%rdi)
    310e:	48 c7 87 08 02 00 00 	movq   $0x0,0x208(%rdi)
    3115:	00 00 00 00 
    3119:	46 8b 1c 18          	mov    (%rax,%r11,1),%r11d
    311d:	4c 89 9f 10 02 00 00 	mov    %r11,0x210(%rdi)
    3124:	48 c7 87 18 02 00 00 	movq   $0x0,0x218(%rdi)
    312b:	00 00 00 00 
    312f:	46 8b 14 10          	mov    (%rax,%r10,1),%r10d
    3133:	4c 89 97 20 02 00 00 	mov    %r10,0x220(%rdi)
    313a:	48 c7 87 28 02 00 00 	movq   $0x0,0x228(%rdi)
    3141:	00 00 00 00 
    3145:	48 c7 47 58 e0 3c 00 	movq   $0x3ce0,0x58(%rdi)
    314c:	00 
    314d:	46 8b 0c 08          	mov    (%rax,%r9,1),%r9d
    3151:	4c 89 8f 30 02 00 00 	mov    %r9,0x230(%rdi)
    3158:	48 c7 87 38 02 00 00 	movq   $0x0,0x238(%rdi)
    315f:	00 00 00 00 
    3163:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    316a:	89 58 78             	mov    %ebx,0x78(%rax)
    316d:	44 89 58 7c          	mov    %r11d,0x7c(%rax)
    3171:	44 89 90 80 00 00 00 	mov    %r10d,0x80(%rax)
    3178:	44 89 88 84 00 00 00 	mov    %r9d,0x84(%rax)
    317f:	45 31 c9             	xor    %r9d,%r9d
    3182:	39 4a 08             	cmp    %ecx,0x8(%rdx)
    3185:	4d 0f 47 c8          	cmova  %r8,%r9
    3189:	4c 8b 52 10          	mov    0x10(%rdx),%r10
    318d:	40 f6 c6 01          	test   $0x1,%sil
    3191:	0f 85 8b 00 00 00    	jne    3222 <f_8001161d0+0x3222>
    3197:	4b 8b 74 11 20       	mov    0x20(%r9,%r10,1),%rsi
    319c:	4f 8b 5c 11 28       	mov    0x28(%r9,%r10,1),%r11
    31a1:	4c 89 5f 60          	mov    %r11,0x60(%rdi)
    31a5:	48 8b 9f d0 00 00 00 	mov    0xd0(%rdi),%rbx
    31ac:	48 89 33             	mov    %rsi,(%rbx)
    31af:	4c 89 5b 08          	mov    %r11,0x8(%rbx)
    31b3:	4b 8b 74 11 30       	mov    0x30(%r9,%r10,1),%rsi
    31b8:	47 8b 4c 11 38       	mov    0x38(%r9,%r10,1),%r9d
    31bd:	4c 89 4f 48          	mov    %r9,0x48(%rdi)
    31c1:	4c 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%r10
    31c8:	45 89 4a 08          	mov    %r9d,0x8(%r10)
    31cc:	49 89 32             	mov    %rsi,(%r10)
    31cf:	44 8b 52 08          	mov    0x8(%rdx),%r10d
    31d3:	48 8b 72 10          	mov    0x10(%rdx),%rsi
    31d7:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    31db:	45 31 c9             	xor    %r9d,%r9d
    31de:	45 31 db             	xor    %r11d,%r11d
    31e1:	31 db                	xor    %ebx,%ebx
    31e3:	44 89 d5             	mov    %r10d,%ebp
    31e6:	29 cd                	sub    %ecx,%ebp
    31e8:	4d 0f 47 c8          	cmova  %r8,%r9
    31ec:	41 0f 94 c3          	sete   %r11b
    31f0:	0f 93 c3             	setae  %bl
    31f3:	c4 c2 50 f2 d2       	andn   %r10d,%ebp,%edx
    31f8:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    31fe:	41 c1 e3 1e          	shl    $0x1e,%r11d
    3202:	c1 e3 1d             	shl    $0x1d,%ebx
    3205:	44 09 db             	or     %r11d,%ebx
    3208:	09 eb                	or     %ebp,%ebx
    320a:	c1 ea 03             	shr    $0x3,%edx
    320d:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    3213:	09 da                	or     %ebx,%edx
    3215:	4a 8d 0c 0e          	lea    (%rsi,%r9,1),%rcx
    3219:	48 83 c1 40          	add    $0x40,%rcx
    321d:	e9 a8 00 00 00       	jmp    32ca <f_8001161d0+0x32ca>
    3222:	4b 8b b4 11 80 30 00 	mov    0x3080(%r9,%r10,1),%rsi
    3229:	00 
    322a:	4f 8b 84 11 88 30 00 	mov    0x3088(%r9,%r10,1),%r8
    3231:	00 
    3232:	4c 89 47 60          	mov    %r8,0x60(%rdi)
    3236:	4c 8b 9f d0 00 00 00 	mov    0xd0(%rdi),%r11
    323d:	49 89 33             	mov    %rsi,(%r11)
    3240:	4d 89 43 08          	mov    %r8,0x8(%r11)
    3244:	4b 8b b4 11 90 30 00 	mov    0x3090(%r9,%r10,1),%rsi
    324b:	00 
    324c:	47 8b 84 11 98 30 00 	mov    0x3098(%r9,%r10,1),%r8d
    3253:	00 
    3254:	4c 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%r9
    325b:	45 89 41 08          	mov    %r8d,0x8(%r9)
    325f:	49 89 31             	mov    %rsi,(%r9)
    3262:	44 8b 4a 08          	mov    0x8(%rdx),%r9d
    3266:	48 8b 72 10          	mov    0x10(%rdx),%rsi
    326a:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    326e:	45 31 c0             	xor    %r8d,%r8d
    3271:	45 31 d2             	xor    %r10d,%r10d
    3274:	45 31 db             	xor    %r11d,%r11d
    3277:	44 89 cb             	mov    %r9d,%ebx
    327a:	29 cb                	sub    %ecx,%ebx
    327c:	41 0f 94 c2          	sete   %r10b
    3280:	41 0f 93 c3          	setae  %r11b
    3284:	4c 0f 47 c1          	cmova  %rcx,%r8
    3288:	c4 c2 60 f2 d1       	andn   %r9d,%ebx,%edx
    328d:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    3293:	41 c1 e2 1e          	shl    $0x1e,%r10d
    3297:	41 c1 e3 1d          	shl    $0x1d,%r11d
    329b:	45 09 d3             	or     %r10d,%r11d
    329e:	41 09 db             	or     %ebx,%r11d
    32a1:	c1 ea 03             	shr    $0x3,%edx
    32a4:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    32aa:	44 09 da             	or     %r11d,%edx
    32ad:	48 c7 47 48 f0 2d 00 	movq   $0x2df0,0x48(%rdi)
    32b4:	00 
    32b5:	4c 89 47 40          	mov    %r8,0x40(%rdi)
    32b9:	49 69 c8 e0 3c 00 00 	imul   $0x3ce0,%r8,%rcx
    32c0:	48 01 f1             	add    %rsi,%rcx
    32c3:	48 81 c1 f0 2d 00 00 	add    $0x2df0,%rcx
    32ca:	48 89 97 10 01 00 00 	mov    %rdx,0x110(%rdi)
    32d1:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    32d5:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    32d9:	48 85 d2             	test   %rdx,%rdx
    32dc:	74 0d                	je     32eb <f_8001161d0+0x32eb>
    32de:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    32e5:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    32e9:	eb 02                	jmp    32ed <f_8001161d0+0x32ed>
    32eb:	31 d2                	xor    %edx,%edx
    32ed:	88 90 b0 00 00 00    	mov    %dl,0xb0(%rax)
    32f3:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    32f7:	48 85 d2             	test   %rdx,%rdx
    32fa:	74 09                	je     3305 <f_8001161d0+0x3305>
    32fc:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3303:	eb 02                	jmp    3307 <f_8001161d0+0x3307>
    3305:	31 d2                	xor    %edx,%edx
    3307:	88 90 b1 00 00 00    	mov    %dl,0xb1(%rax)
    330d:	48 8b 51 30          	mov    0x30(%rcx),%rdx
    3311:	48 85 d2             	test   %rdx,%rdx
    3314:	74 0d                	je     3323 <f_8001161d0+0x3323>
    3316:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    331d:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    3321:	eb 02                	jmp    3325 <f_8001161d0+0x3325>
    3323:	31 d2                	xor    %edx,%edx
    3325:	88 90 b2 00 00 00    	mov    %dl,0xb2(%rax)
    332b:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    332f:	48 85 d2             	test   %rdx,%rdx
    3332:	74 09                	je     333d <f_8001161d0+0x333d>
    3334:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    333b:	eb 02                	jmp    333f <f_8001161d0+0x333f>
    333d:	31 d2                	xor    %edx,%edx
    333f:	88 90 b3 00 00 00    	mov    %dl,0xb3(%rax)
    3345:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    3349:	48 85 d2             	test   %rdx,%rdx
    334c:	74 0d                	je     335b <f_8001161d0+0x335b>
    334e:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3355:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    3359:	eb 02                	jmp    335d <f_8001161d0+0x335d>
    335b:	31 d2                	xor    %edx,%edx
    335d:	88 90 b4 00 00 00    	mov    %dl,0xb4(%rax)
    3363:	48 8b 51 48          	mov    0x48(%rcx),%rdx
    3367:	48 85 d2             	test   %rdx,%rdx
    336a:	74 09                	je     3375 <f_8001161d0+0x3375>
    336c:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3373:	eb 02                	jmp    3377 <f_8001161d0+0x3377>
    3375:	31 d2                	xor    %edx,%edx
    3377:	88 90 b5 00 00 00    	mov    %dl,0xb5(%rax)
    337d:	48 8b 51 50          	mov    0x50(%rcx),%rdx
    3381:	48 85 d2             	test   %rdx,%rdx
    3384:	74 09                	je     338f <f_8001161d0+0x338f>
    3386:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    338d:	eb 02                	jmp    3391 <f_8001161d0+0x3391>
    338f:	31 d2                	xor    %edx,%edx
    3391:	88 90 b6 00 00 00    	mov    %dl,0xb6(%rax)
    3397:	48 8b 51 58          	mov    0x58(%rcx),%rdx
    339b:	48 85 d2             	test   %rdx,%rdx
    339e:	74 0d                	je     33ad <f_8001161d0+0x33ad>
    33a0:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    33a7:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    33ab:	eb 02                	jmp    33af <f_8001161d0+0x33af>
    33ad:	31 d2                	xor    %edx,%edx
    33af:	88 90 b7 00 00 00    	mov    %dl,0xb7(%rax)
    33b5:	48 8b 49 60          	mov    0x60(%rcx),%rcx
    33b9:	48 85 c9             	test   %rcx,%rcx
    33bc:	74 10                	je     33ce <f_8001161d0+0x33ce>
    33be:	0f b6 89 c0 00 00 00 	movzbl 0xc0(%rcx),%ecx
    33c5:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    33c9:	e9 55 f8 ff ff       	jmp    2c23 <f_8001161d0+0x2c23>
    33ce:	31 c9                	xor    %ecx,%ecx
    33d0:	e9 4e f8 ff ff       	jmp    2c23 <f_8001161d0+0x2c23>
    33d5:	48 8b 87 b0 00 00 00 	mov    0xb0(%rdi),%rax
    33dc:	8b 08                	mov    (%rax),%ecx
    33de:	45 8b 90 90 3b 00 00 	mov    0x3b90(%r8),%r10d
    33e5:	45 8b 88 94 3b 00 00 	mov    0x3b94(%r8),%r9d
    33ec:	41 83 fa 01          	cmp    $0x1,%r10d
    33f0:	44 89 d6             	mov    %r10d,%esi
    33f3:	83 d6 00             	adc    $0x0,%esi
    33f6:	89 c8                	mov    %ecx,%eax
    33f8:	31 d2                	xor    %edx,%edx
    33fa:	f7 f6                	div    %esi
    33fc:	89 c6                	mov    %eax,%esi
    33fe:	45 85 d2             	test   %r10d,%r10d
    3401:	41 0f 44 f2          	cmove  %r10d,%esi
    3405:	4c 89 4f 48          	mov    %r9,0x48(%rdi)
    3409:	31 d2                	xor    %edx,%edx
    340b:	41 89 f2             	mov    %esi,%r10d
    340e:	45 31 ca             	xor    %r9d,%r10d
    3411:	0f 94 c2             	sete   %dl
    3414:	45 31 db             	xor    %r11d,%r11d
    3417:	89 f0                	mov    %esi,%eax
    3419:	44 29 c8             	sub    %r9d,%eax
    341c:	41 0f 93 c3          	setae  %r11b
    3420:	89 f3                	mov    %esi,%ebx
    3422:	31 c3                	xor    %eax,%ebx
    3424:	44 21 d3             	and    %r10d,%ebx
    3427:	41 89 c2             	mov    %eax,%r10d
    342a:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    3431:	c1 e2 1e             	shl    $0x1e,%edx
    3434:	41 c1 e3 1d          	shl    $0x1d,%r11d
    3438:	41 09 d3             	or     %edx,%r11d
    343b:	45 09 d3             	or     %r10d,%r11d
    343e:	31 d8                	xor    %ebx,%eax
    3440:	c1 eb 03             	shr    $0x3,%ebx
    3443:	81 e3 00 00 00 10    	and    $0x10000000,%ebx
    3449:	44 09 db             	or     %r11d,%ebx
    344c:	48 89 9f 10 01 00 00 	mov    %rbx,0x110(%rdi)
    3453:	a9 00 00 00 80       	test   $0x80000000,%eax
    3458:	49 0f 44 f1          	cmove  %r9,%rsi
    345c:	48 89 77 40          	mov    %rsi,0x40(%rdi)
    3460:	48 85 f6             	test   %rsi,%rsi
    3463:	0f 84 c0 f9 ff ff    	je     2e29 <f_8001161d0+0x2e29>
    3469:	48 89 8f 88 00 00 00 	mov    %rcx,0x88(%rdi)
    3470:	31 d2                	xor    %edx,%edx
    3472:	89 f0                	mov    %esi,%eax
    3474:	ff c8                	dec    %eax
    3476:	0f 94 c2             	sete   %dl
    3479:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
    347f:	49 81 c2 01 00 00 80 	add    $0xffffffff80000001,%r10
    3486:	45 31 c9             	xor    %r9d,%r9d
    3489:	4c 89 d3             	mov    %r10,%rbx
    348c:	4c 39 d6             	cmp    %r10,%rsi
    348f:	41 0f 94 c1          	sete   %r9b
    3493:	41 89 c2             	mov    %eax,%r10d
    3496:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    349d:	c1 e2 1e             	shl    $0x1e,%edx
    34a0:	44 09 d2             	or     %r10d,%edx
    34a3:	45 89 ca             	mov    %r9d,%r10d
    34a6:	41 c1 e2 1c          	shl    $0x1c,%r10d
    34aa:	41 09 d2             	or     %edx,%r10d
    34ad:	49 81 ca 00 00 00 20 	or     $0x20000000,%r10
    34b4:	4c 89 97 10 01 00 00 	mov    %r10,0x110(%rdi)
    34bb:	48 89 47 48          	mov    %rax,0x48(%rdi)
    34bf:	48 89 4f 60          	mov    %rcx,0x60(%rdi)
    34c3:	c1 e8 1f             	shr    $0x1f,%eax
    34c6:	41 30 c1             	xor    %al,%r9b
    34c9:	0f 85 5a f9 ff ff    	jne    2e29 <f_8001161d0+0x2e29>
    34cf:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    34d5:	49 31 f1             	xor    %rsi,%r9
    34d8:	41 ba 00 00 00 80    	mov    $0x80000000,%r10d
    34de:	49 31 ca             	xor    %rcx,%r10
    34e1:	4c 89 d0             	mov    %r10,%rax
    34e4:	4c 09 c8             	or     %r9,%rax
    34e7:	b8 01 00 00 00       	mov    $0x1,%eax
    34ec:	41 89 f3             	mov    %esi,%r11d
    34ef:	44 0f 44 d8          	cmove  %eax,%r11d
    34f3:	89 c8                	mov    %ecx,%eax
    34f5:	99                   	cltd
    34f6:	41 f7 fb             	idiv   %r11d
    34f9:	4d 09 ca             	or     %r9,%r10
    34fc:	89 c2                	mov    %eax,%edx
    34fe:	0f 44 d1             	cmove  %ecx,%edx
    3501:	48 0f 44 c3          	cmove  %rbx,%rax
    3505:	4c 8d 4f 50          	lea    0x50(%rdi),%r9
    3509:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    350d:	c4 c1 78 29 01       	vmovaps %xmm0,(%r9)
    3512:	4d 8d 88 80 3b 00 00 	lea    0x3b80(%r8),%r9
    3519:	4c 89 4f 70          	mov    %r9,0x70(%rdi)
    351d:	48 c7 47 78 28 00 00 	movq   $0x28,0x78(%rdi)
    3524:	00 
    3525:	48 c7 87 80 00 00 00 	movq   $0x3dcccccd,0x80(%rdi)
    352c:	cd cc cc 3d 
    3530:	0f af f2             	imul   %edx,%esi
    3533:	29 f1                	sub    %esi,%ecx
    3535:	48 89 4f 60          	mov    %rcx,0x60(%rdi)
    3539:	49 81 c0 78 3b 00 00 	add    $0x3b78,%r8
    3540:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    3544:	48 89 87 88 00 00 00 	mov    %rax,0x88(%rdi)
    354b:	31 c9                	xor    %ecx,%ecx
    354d:	c5 f0 57 c9          	vxorps %xmm1,%xmm1,%xmm1
    3551:	c5 fa 10 15 00 00 00 	vmovss 0x0(%rip),%xmm2        # 3559 <f_8001161d0+0x3559>
    3558:	00 
    3559:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    355e:	c4 e2 79 59 1d 00 00 	vpbroadcastq 0x0(%rip),%xmm3        # 3567 <f_8001161d0+0x3567>
    3565:	00 00 
    3567:	48 be 00 00 00 00 f8 	movabs $0xfffffff800000000,%rsi
    356e:	ff ff ff 
    3571:	eb 7a                	jmp    35ed <f_8001161d0+0x35ed>
    3573:	c4 e3 e1 22 a7 88 00 	vpinsrq $0x1,0x88(%rdi),%xmm3,%xmm4
    357a:	00 00 01 
    357d:	c5 d9 d4 67 50       	vpaddq 0x50(%rdi),%xmm4,%xmm4
    3582:	c5 f9 7e e0          	vmovd  %xmm4,%eax
    3586:	44 8b 47 40          	mov    0x40(%rdi),%r8d
    358a:	45 31 c9             	xor    %r9d,%r9d
    358d:	41 89 c2             	mov    %eax,%r10d
    3590:	45 31 c2             	xor    %r8d,%r10d
    3593:	41 0f 94 c1          	sete   %r9b
    3597:	45 31 db             	xor    %r11d,%r11d
    359a:	89 c3                	mov    %eax,%ebx
    359c:	44 29 c3             	sub    %r8d,%ebx
    359f:	41 0f 93 c3          	setae  %r11b
    35a3:	41 89 de             	mov    %ebx,%r14d
    35a6:	41 31 c6             	xor    %eax,%r14d
    35a9:	45 21 d6             	and    %r10d,%r14d
    35ac:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    35b2:	41 c1 e1 1e          	shl    $0x1e,%r9d
    35b6:	41 c1 e3 1d          	shl    $0x1d,%r11d
    35ba:	45 09 cb             	or     %r9d,%r11d
    35bd:	41 09 db             	or     %ebx,%r11d
    35c0:	41 c1 ee 03          	shr    $0x3,%r14d
    35c4:	41 81 e6 00 00 00 10 	and    $0x10000000,%r14d
    35cb:	45 09 de             	or     %r11d,%r14d
    35ce:	44 31 c0             	xor    %r8d,%eax
    35d1:	c4 e3 59 02 e0 0a    	vpblendd $0xa,%xmm0,%xmm4,%xmm4
    35d7:	c5 f9 7f 67 50       	vmovdqa %xmm4,0x50(%rdi)
    35dc:	4c 89 b7 10 01 00 00 	mov    %r14,0x110(%rdi)
    35e3:	0f 84 40 f8 ff ff    	je     2e29 <f_8001161d0+0x2e29>
    35e9:	4c 8b 47 68          	mov    0x68(%rdi),%r8
    35ed:	41 8b 00             	mov    (%r8),%eax
    35f0:	48 89 87 90 00 00 00 	mov    %rax,0x90(%rdi)
    35f7:	44 8d 40 01          	lea    0x1(%rax),%r8d
    35fb:	4c 89 07             	mov    %r8,(%rdi)
    35fe:	4c 8b 4f 68          	mov    0x68(%rdi),%r9
    3602:	45 31 d2             	xor    %r10d,%r10d
    3605:	f0 45 0f b1 01       	lock cmpxchg %r8d,(%r9)
    360a:	41 0f 95 c2          	setne  %r10b
    360e:	4c 89 57 08          	mov    %r10,0x8(%rdi)
    3612:	75 d5                	jne    35e9 <f_8001161d0+0x35e9>
    3614:	4c 8b 9f a0 00 00 00 	mov    0xa0(%rdi),%r11
    361b:	8b 47 50             	mov    0x50(%rdi),%eax
    361e:	3b 47 48             	cmp    0x48(%rdi),%eax
    3621:	44 8b 47 60          	mov    0x60(%rdi),%r8d
    3625:	4c 0f 45 c1          	cmovne %rcx,%r8
    3629:	4d 8b 93 70 3b 00 00 	mov    0x3b70(%r11),%r10
    3630:	4c 8b 8f 90 00 00 00 	mov    0x90(%rdi),%r9
    3637:	b8 00 00 00 00       	mov    $0x0,%eax
    363c:	45 39 8b 68 3b 00 00 	cmp    %r9d,0x3b68(%r11)
    3643:	76 1a                	jbe    365f <f_8001161d0+0x365f>
    3645:	45 89 c9             	mov    %r9d,%r9d
    3648:	49 63 c1             	movslq %r9d,%rax
    364b:	48 c1 f8 1f          	sar    $0x1f,%rax
    364f:	49 bb 00 00 00 00 ff 	movabs $0xffffffff00000000,%r11
    3656:	ff ff ff 
    3659:	4c 21 d8             	and    %r11,%rax
    365c:	4c 09 c8             	or     %r9,%rax
    365f:	48 89 47 08          	mov    %rax,0x8(%rdi)
    3663:	4c 03 87 88 00 00 00 	add    0x88(%rdi),%r8
    366a:	45 89 c1             	mov    %r8d,%r9d
    366d:	4c 89 8f 88 00 00 00 	mov    %r9,0x88(%rdi)
    3674:	48 98                	cltq
    3676:	4c 63 5f 78          	movslq 0x78(%rdi),%r11
    367a:	4c 0f af d8          	imul   %rax,%r11
    367e:	4b 8d 04 13          	lea    (%r11,%r10,1),%rax
    3682:	48 89 87 90 00 00 00 	mov    %rax,0x90(%rdi)
    3689:	8b 5f 58             	mov    0x58(%rdi),%ebx
    368c:	4d 89 c6             	mov    %r8,%r14
    368f:	49 c1 e6 20          	shl    $0x20,%r14
    3693:	49 09 de             	or     %rbx,%r14
    3696:	48 8b 9f 98 00 00 00 	mov    0x98(%rdi),%rbx
    369d:	4b 89 1c 13          	mov    %rbx,(%r11,%r10,1)
    36a1:	48 8b 9f b8 00 00 00 	mov    0xb8(%rdi),%rbx
    36a8:	4b 89 5c 13 08       	mov    %rbx,0x8(%r11,%r10,1)
    36ad:	48 8b 9f a8 00 00 00 	mov    0xa8(%rdi),%rbx
    36b4:	4b 89 5c 13 10       	mov    %rbx,0x10(%r11,%r10,1)
    36b9:	4f 89 74 13 18       	mov    %r14,0x18(%r11,%r10,1)
    36be:	44 8b 93 bc 00 00 00 	mov    0xbc(%rbx),%r10d
    36c5:	31 db                	xor    %ebx,%ebx
    36c7:	45 89 d3             	mov    %r10d,%r11d
    36ca:	41 83 c3 fe          	add    $0xfffffffe,%r11d
    36ce:	0f 94 c3             	sete   %bl
    36d1:	31 ed                	xor    %ebp,%ebp
    36d3:	41 be 01 00 00 00    	mov    $0x1,%r14d
    36d9:	45 29 d6             	sub    %r10d,%r14d
    36dc:	40 0f 92 c5          	setb   %bpl
    36e0:	45 21 d6             	and    %r10d,%r14d
    36e3:	45 89 df             	mov    %r11d,%r15d
    36e6:	41 81 e7 00 00 00 80 	and    $0x80000000,%r15d
    36ed:	c1 e3 1e             	shl    $0x1e,%ebx
    36f0:	c1 e5 1d             	shl    $0x1d,%ebp
    36f3:	44 09 fd             	or     %r15d,%ebp
    36f6:	09 dd                	or     %ebx,%ebp
    36f8:	41 c1 ee 03          	shr    $0x3,%r14d
    36fc:	41 81 e6 00 00 00 10 	and    $0x10000000,%r14d
    3703:	41 09 ee             	or     %ebp,%r14d
    3706:	4c 89 b7 10 01 00 00 	mov    %r14,0x110(%rdi)
    370d:	45 85 db             	test   %r11d,%r11d
    3710:	0f 84 aa 00 00 00    	je     37c0 <f_8001161d0+0x37c0>
    3716:	45 31 db             	xor    %r11d,%r11d
    3719:	44 89 d3             	mov    %r10d,%ebx
    371c:	f7 db                	neg    %ebx
    371e:	41 0f 90 c3          	seto   %r11b
    3722:	31 db                	xor    %ebx,%ebx
    3724:	31 ed                	xor    %ebp,%ebp
    3726:	45 89 d6             	mov    %r10d,%r14d
    3729:	41 83 ee 01          	sub    $0x1,%r14d
    372d:	0f 94 c3             	sete   %bl
    3730:	40 0f 93 c5          	setae  %bpl
    3734:	41 81 e6 00 00 00 80 	and    $0x80000000,%r14d
    373b:	c1 e3 1e             	shl    $0x1e,%ebx
    373e:	c1 e5 1d             	shl    $0x1d,%ebp
    3741:	41 c1 e3 1c          	shl    $0x1c,%r11d
    3745:	41 09 eb             	or     %ebp,%r11d
    3748:	45 09 f3             	or     %r14d,%r11d
    374b:	41 09 db             	or     %ebx,%r11d
    374e:	4c 89 9f 10 01 00 00 	mov    %r11,0x110(%rdi)
    3755:	41 83 fa 01          	cmp    $0x1,%r10d
    3759:	0f 84 b9 00 00 00    	je     3818 <f_8001161d0+0x3818>
    375f:	31 db                	xor    %ebx,%ebx
    3761:	45 89 d3             	mov    %r10d,%r11d
    3764:	41 83 c3 fd          	add    $0xfffffffd,%r11d
    3768:	0f 94 c3             	sete   %bl
    376b:	31 ed                	xor    %ebp,%ebp
    376d:	41 be 02 00 00 00    	mov    $0x2,%r14d
    3773:	45 29 d6             	sub    %r10d,%r14d
    3776:	40 0f 92 c5          	setb   %bpl
    377a:	45 21 d6             	and    %r10d,%r14d
    377d:	45 89 da             	mov    %r11d,%r10d
    3780:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    3787:	c1 e3 1e             	shl    $0x1e,%ebx
    378a:	c1 e5 1d             	shl    $0x1d,%ebp
    378d:	44 09 d5             	or     %r10d,%ebp
    3790:	09 dd                	or     %ebx,%ebp
    3792:	41 c1 ee 03          	shr    $0x3,%r14d
    3796:	41 81 e6 00 00 00 10 	and    $0x10000000,%r14d
    379d:	41 09 ee             	or     %ebp,%r14d
    37a0:	4c 89 b7 10 01 00 00 	mov    %r14,0x110(%rdi)
    37a7:	4c 89 4f 10          	mov    %r9,0x10(%rdi)
    37ab:	45 85 db             	test   %r11d,%r11d
    37ae:	0f 85 ab 00 00 00    	jne    385f <f_8001161d0+0x385f>
    37b4:	45 01 c0             	add    %r8d,%r8d
    37b7:	47 8d 0c 80          	lea    (%r8,%r8,4),%r9d
    37bb:	e9 9b 00 00 00       	jmp    385b <f_8001161d0+0x385b>
    37c0:	c4 c1 02 2a e0       	vcvtsi2ss %r8d,%xmm15,%xmm4
    37c5:	4c 8b 87 80 00 00 00 	mov    0x80(%rdi),%r8
    37cc:	45 89 c1             	mov    %r8d,%r9d
    37cf:	4c 89 8f 10 02 00 00 	mov    %r9,0x210(%rdi)
    37d6:	48 c7 87 18 02 00 00 	movq   $0x0,0x218(%rdi)
    37dd:	00 00 00 00 
    37e1:	c4 c1 79 6e e8       	vmovd  %r8d,%xmm5
    37e6:	c5 da 59 e5          	vmulss %xmm5,%xmm4,%xmm4
    37ea:	c4 c1 79 7e e0       	vmovd  %xmm4,%r8d
    37ef:	4c 89 87 00 02 00 00 	mov    %r8,0x200(%rdi)
    37f6:	c4 61 fa 2c cc       	vcvttss2si %xmm4,%r9
    37fb:	48 c7 87 08 02 00 00 	movq   $0x0,0x208(%rdi)
    3802:	00 00 00 00 
    3806:	c5 f8 2e e1          	vucomiss %xmm1,%xmm4
    380a:	44 0f 42 c9          	cmovb  %ecx,%r9d
    380e:	c5 f8 2e e2          	vucomiss %xmm2,%xmm4
    3812:	44 0f 47 ca          	cmova  %edx,%r9d
    3816:	eb 43                	jmp    385b <f_8001161d0+0x385b>
    3818:	45 31 d2             	xor    %r10d,%r10d
    381b:	4d 85 c9             	test   %r9,%r9
    381e:	41 0f 94 c2          	sete   %r10b
    3822:	45 89 c1             	mov    %r8d,%r9d
    3825:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    382c:	41 c1 e2 1e          	shl    $0x1e,%r10d
    3830:	4d 01 d1             	add    %r10,%r9
    3833:	49 81 c1 00 00 00 20 	add    $0x20000000,%r9
    383a:	4c 89 8f 10 01 00 00 	mov    %r9,0x110(%rdi)
    3841:	45 89 c1             	mov    %r8d,%r9d
    3844:	41 c1 e9 1f          	shr    $0x1f,%r9d
    3848:	45 01 c1             	add    %r8d,%r9d
    384b:	45 89 c8             	mov    %r9d,%r8d
    384e:	41 d1 e8             	shr    $1,%r8d
    3851:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    3858:	45 09 c1             	or     %r8d,%r9d
    385b:	4c 89 4f 10          	mov    %r9,0x10(%rdi)
    385f:	48 89 07             	mov    %rax,(%rdi)
    3862:	44 89 48 20          	mov    %r9d,0x20(%rax)
    3866:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
    386d:	00 00 00 
    3870:	48 8b 47 70          	mov    0x70(%rdi),%rax
    3874:	8b 00                	mov    (%rax),%eax
    3876:	48 89 07             	mov    %rax,(%rdi)
    3879:	44 8d 40 01          	lea    0x1(%rax),%r8d
    387d:	4c 89 47 08          	mov    %r8,0x8(%rdi)
    3881:	4c 8b 4f 70          	mov    0x70(%rdi),%r9
    3885:	45 31 d2             	xor    %r10d,%r10d
    3888:	f0 45 0f b1 01       	lock cmpxchg %r8d,(%r9)
    388d:	41 0f 95 c2          	setne  %r10b
    3891:	4c 89 57 10          	mov    %r10,0x10(%rdi)
    3895:	75 d9                	jne    3870 <f_8001161d0+0x3870>
    3897:	48 8b 07             	mov    (%rdi),%rax
    389a:	4c 8b 87 a0 00 00 00 	mov    0xa0(%rdi),%r8
    38a1:	45 8b 88 84 3b 00 00 	mov    0x3b84(%r8),%r9d
    38a8:	45 89 ca             	mov    %r9d,%r10d
    38ab:	41 31 c2             	xor    %eax,%r10d
    38ae:	45 89 cb             	mov    %r9d,%r11d
    38b1:	41 31 c3             	xor    %eax,%r11d
    38b4:	4c 89 4f 08          	mov    %r9,0x8(%rdi)
    38b8:	0f 84 b5 fc ff ff    	je     3573 <f_8001161d0+0x3573>
    38be:	45 89 cb             	mov    %r9d,%r11d
    38c1:	41 29 c3             	sub    %eax,%r11d
    38c4:	c4 42 28 f2 db       	andn   %r11d,%r10d,%r11d
    38c9:	45 21 ca             	and    %r9d,%r10d
    38cc:	45 09 da             	or     %r11d,%r10d
    38cf:	0f 88 9e fc ff ff    	js     3573 <f_8001161d0+0x3573>
    38d5:	4d 8b 80 88 3b 00 00 	mov    0x3b88(%r8),%r8
    38dc:	4c 89 47 08          	mov    %r8,0x8(%rdi)
    38e0:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    38e7:	00 
    38e8:	48 98                	cltq
    38ea:	48 21 f0             	and    %rsi,%rax
    38ed:	4d 8d 95 2e a2 3f fd 	lea    -0x2c05dd2(%r13),%r10
    38f4:	4d 21 ca             	and    %r9,%r10
    38f7:	49 09 c2             	or     %rax,%r10
    38fa:	4c 89 17             	mov    %r10,(%rdi)
    38fd:	48 8b 87 90 00 00 00 	mov    0x90(%rdi),%rax
    3904:	4b 89 04 10          	mov    %rax,(%r8,%r10,1)
    3908:	e9 66 fc ff ff       	jmp    3573 <f_8001161d0+0x3573>
