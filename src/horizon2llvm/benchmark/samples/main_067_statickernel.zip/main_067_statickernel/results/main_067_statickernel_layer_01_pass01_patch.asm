
/home/leegao/meh/ultratears-main/src/horizon2llvm/benchmark/samples/main_067_statickernel/results/main_067_statickernel_layer_01_pass01_patch.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <f_8001161d0>:
       0:	55                   	push   %rbp
       1:	41 57                	push   %r15
       3:	41 56                	push   %r14
       5:	41 55                	push   %r13
       7:	41 54                	push   %r12
       9:	53                   	push   %rbx
       a:	48 83 ec 18          	sub    $0x18,%rsp
       e:	48 89 fb             	mov    %rdi,%rbx
      11:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
      18:	00 00 00 
      1b:	83 3d 00 00 00 00 00 	cmpl   $0x0,0x0(%rip)        # 22 <f_8001161d0+0x22>
      22:	74 16                	je     3a <f_8001161d0+0x3a>
      24:	48 8b 13             	mov    (%rbx),%rdx
      27:	48 8b b3 f0 00 00 00 	mov    0xf0(%rbx),%rsi
      2e:	48 8d bd 06 04 51 fd 	lea    -0x2aefbfa(%rbp),%rdi
      35:	e8 00 00 00 00       	call   3a <f_8001161d0+0x3a>
      3a:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
      41:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
      48:	4c 8d b8 d0 fe ff ff 	lea    -0x130(%rax),%r15
      4f:	4c 89 bb 00 01 00 00 	mov    %r15,0x100(%rbx)
      56:	48 8d 50 a0          	lea    -0x60(%rax),%rdx
      5a:	48 89 48 a0          	mov    %rcx,-0x60(%rax)
      5e:	48 8b 8b f0 00 00 00 	mov    0xf0(%rbx),%rcx
      65:	48 89 48 a8          	mov    %rcx,-0x58(%rax)
      69:	48 8b 8b e0 00 00 00 	mov    0xe0(%rbx),%rcx
      70:	48 89 48 b0          	mov    %rcx,-0x50(%rax)
      74:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
      7b:	48 89 48 b8          	mov    %rcx,-0x48(%rax)
      7f:	48 8b 8b d0 00 00 00 	mov    0xd0(%rbx),%rcx
      86:	48 89 48 c0          	mov    %rcx,-0x40(%rax)
      8a:	48 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%rcx
      91:	48 89 48 c8          	mov    %rcx,-0x38(%rax)
      95:	48 8b 8b c0 00 00 00 	mov    0xc0(%rbx),%rcx
      9c:	48 89 48 d0          	mov    %rcx,-0x30(%rax)
      a0:	48 8b 8b b8 00 00 00 	mov    0xb8(%rbx),%rcx
      a7:	48 89 48 d8          	mov    %rcx,-0x28(%rax)
      ab:	48 8b 8b b0 00 00 00 	mov    0xb0(%rbx),%rcx
      b2:	48 89 48 e0          	mov    %rcx,-0x20(%rax)
      b6:	48 8b 8b a8 00 00 00 	mov    0xa8(%rbx),%rcx
      bd:	48 89 48 e8          	mov    %rcx,-0x18(%rax)
      c1:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
      c8:	48 89 48 f0          	mov    %rcx,-0x10(%rax)
      cc:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
      d3:	48 89 48 f8          	mov    %rcx,-0x8(%rax)
      d7:	48 89 93 e8 00 00 00 	mov    %rdx,0xe8(%rbx)
      de:	4c 8b 5b 10          	mov    0x10(%rbx),%r11
      e2:	4c 89 9b a8 00 00 00 	mov    %r11,0xa8(%rbx)
      e9:	4c 8b 23             	mov    (%rbx),%r12
      ec:	4c 8b 6b 08          	mov    0x8(%rbx),%r13
      f0:	4c 89 ab 98 00 00 00 	mov    %r13,0x98(%rbx)
      f7:	4c 89 a3 a0 00 00 00 	mov    %r12,0xa0(%rbx)
      fe:	49 8d 8d 14 29 00 00 	lea    0x2914(%r13),%rcx
     105:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
     109:	41 83 fb 1f          	cmp    $0x1f,%r11d
     10d:	77 1f                	ja     12e <f_8001161d0+0x12e>
     10f:	b9 1f 7d c3 f6       	mov    $0xf6c37d1f,%ecx
     114:	44 0f a3 d9          	bt     %r11d,%ecx
     118:	73 14                	jae    12e <f_8001161d0+0x12e>
     11a:	44 89 d9             	mov    %r11d,%ecx
     11d:	83 e1 1f             	and    $0x1f,%ecx
     120:	48 8b 8c cd be 6b 16 	mov    0x166bbe(%rbp,%rcx,8),%rcx
     127:	00 
     128:	48 c1 e1 08          	shl    $0x8,%rcx
     12c:	eb 0f                	jmp    13d <f_8001161d0+0x13d>
     12e:	31 d2                	xor    %edx,%edx
     130:	41 83 fb 12          	cmp    $0x12,%r11d
     134:	b9 00 03 00 00       	mov    $0x300,%ecx
     139:	48 0f 45 ca          	cmovne %rdx,%rcx
     13d:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     144:	ff ff ff 
     147:	49 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r14
     14e:	ff 7f ff 
     151:	41 0f be 95 17 29 00 	movsbl 0x2917(%r13),%edx
     158:	00 
     159:	48 63 d2             	movslq %edx,%rdx
     15c:	4c 89 bb c0 00 00 00 	mov    %r15,0xc0(%rbx)
     163:	48 69 f2 48 07 00 00 	imul   $0x748,%rdx,%rsi
     16a:	45 31 c0             	xor    %r8d,%r8d
     16d:	41 39 94 24 90 33 00 	cmp    %edx,0x3390(%r12)
     174:	00 
     175:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     17c:	ff 7f 7f 
     17f:	4c 0f 47 c6          	cmova  %rsi,%r8
     183:	49 b9 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r9
     18a:	00 80 3f 
     18d:	48 be 00 00 00 00 01 	movabs $0x100000000,%rsi
     194:	00 00 00 
     197:	4d 03 84 24 98 33 00 	add    0x3398(%r12),%r8
     19e:	00 
     19f:	48 c7 43 70 ff ff ff 	movq   $0xffffffffffffffff,0x70(%rbx)
     1a6:	ff 
     1a7:	c5 fd 6f 05 00 00 00 	vmovdqa 0x0(%rip),%ymm0        # 1af <f_8001161d0+0x1af>
     1ae:	00 
     1af:	c5 fe 7f 80 d0 fe ff 	vmovdqu %ymm0,-0x130(%rax)
     1b6:	ff 
     1b7:	ba ff ff ff ff       	mov    $0xffffffff,%edx
     1bc:	48 89 53 78          	mov    %rdx,0x78(%rbx)
     1c0:	48 89 b0 f0 fe ff ff 	mov    %rsi,-0x110(%rax)
     1c7:	48 89 b8 f8 fe ff ff 	mov    %rdi,-0x108(%rax)
     1ce:	4a 8d 8c 01 e8 01 00 	lea    0x1e8(%rcx,%r8,1),%rcx
     1d5:	00 
     1d6:	48 89 8b b8 00 00 00 	mov    %rcx,0xb8(%rbx)
     1dd:	48 89 90 00 ff ff ff 	mov    %rdx,-0x100(%rax)
     1e4:	4c 89 88 08 ff ff ff 	mov    %r9,-0xf8(%rax)
     1eb:	4c 89 53 58          	mov    %r10,0x58(%rbx)
     1ef:	31 d2                	xor    %edx,%edx
     1f1:	44 89 de             	mov    %r11d,%esi
     1f4:	83 c6 df             	add    $0xffffffdf,%esi
     1f7:	0f 94 c2             	sete   %dl
     1fa:	31 c9                	xor    %ecx,%ecx
     1fc:	41 83 fb 21          	cmp    $0x21,%r11d
     200:	0f 93 c1             	setae  %cl
     203:	41 b8 20 00 00 00    	mov    $0x20,%r8d
     209:	45 29 d8             	sub    %r11d,%r8d
     20c:	45 21 d8             	and    %r11d,%r8d
     20f:	81 e6 00 00 00 80    	and    $0x80000000,%esi
     215:	c1 e2 1e             	shl    $0x1e,%edx
     218:	c1 e1 1d             	shl    $0x1d,%ecx
     21b:	09 f1                	or     %esi,%ecx
     21d:	09 d1                	or     %edx,%ecx
     21f:	41 c1 e8 03          	shr    $0x3,%r8d
     223:	41 81 e0 00 00 00 10 	and    $0x10000000,%r8d
     22a:	41 09 c8             	or     %ecx,%r8d
     22d:	4c 89 83 10 01 00 00 	mov    %r8,0x110(%rbx)
     234:	4c 89 88 10 ff ff ff 	mov    %r9,-0xf0(%rax)
     23b:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     242:	00 00 00 00 
     246:	4c 8b 85 7e 86 d5 00 	mov    0xd5867e(%rbp),%r8
     24d:	4c 89 43 50          	mov    %r8,0x50(%rbx)
     251:	48 8b b5 ae 5d d4 00 	mov    0xd45dae(%rbp),%rsi
     258:	48 89 73 48          	mov    %rsi,0x48(%rbx)
     25c:	49 8d 50 10          	lea    0x10(%r8),%rdx
     260:	48 89 90 20 ff ff ff 	mov    %rdx,-0xe0(%rax)
     267:	48 89 b0 40 ff ff ff 	mov    %rsi,-0xc0(%rax)
     26e:	48 8b bd b6 7e d5 00 	mov    0xd57eb6(%rbp),%rdi
     275:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
     279:	48 83 c7 10          	add    $0x10,%rdi
     27d:	48 89 bb 80 00 00 00 	mov    %rdi,0x80(%rbx)
     284:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
     28b:	4c 89 b0 50 ff ff ff 	mov    %r14,-0xb0(%rax)
     292:	49 8d b1 00 00 80 c0 	lea    -0x3f800000(%r9),%rsi
     299:	48 89 b0 74 ff ff ff 	mov    %rsi,-0x8c(%rax)
     2a0:	4c 8b 8d c6 7d d5 00 	mov    0xd57dc6(%rbp),%r9
     2a7:	4c 89 b0 68 ff ff ff 	mov    %r14,-0x98(%rax)
     2ae:	45 8b 31             	mov    (%r9),%r14d
     2b1:	4c 89 73 40          	mov    %r14,0x40(%rbx)
     2b5:	48 89 b8 58 ff ff ff 	mov    %rdi,-0xa8(%rax)
     2bc:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
     2c3:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     2ca:	00 
     2cb:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     2cf:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     2d6:	44 89 b0 70 ff ff ff 	mov    %r14d,-0x90(%rax)
     2dd:	81 e1 00 00 00 60    	and    $0x60000000,%ecx
     2e3:	81 f9 00 00 00 20    	cmp    $0x20000000,%ecx
     2e9:	0f 84 78 2b 00 00    	je     2e67 <f_8001161d0+0x2e67>
     2ef:	48 89 3c 24          	mov    %rdi,(%rsp)
     2f3:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
     2f8:	49 89 ea             	mov    %rbp,%r10
     2fb:	48 8d b0 48 ff ff ff 	lea    -0xb8(%rax),%rsi
     302:	48 8d a8 60 ff ff ff 	lea    -0xa0(%rax),%rbp
     309:	4c 8d 48 80          	lea    -0x80(%rax),%r9
     30d:	48 8d b8 70 ff ff ff 	lea    -0x90(%rax),%rdi
     314:	49 8d 8a 76 6b 16 00 	lea    0x166b76(%r10),%rcx
     31b:	48 89 8b 88 00 00 00 	mov    %rcx,0x88(%rbx)
     322:	45 89 db             	mov    %r11d,%r11d
     325:	4c 89 9b 90 00 00 00 	mov    %r11,0x90(%rbx)
     32c:	4c 89 bb 80 00 00 00 	mov    %r15,0x80(%rbx)
     333:	43 0f b7 8c 5a 76 6b 	movzwl 0x166b76(%r10,%r11,2),%ecx
     33a:	16 00 
     33c:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     340:	4d 8d bc 8a 52 05 51 	lea    -0x2aefaae(%r10,%rcx,4),%r15
     347:	fd 
     348:	4c 89 3b             	mov    %r15,(%rbx)
     34b:	48 89 73 48          	mov    %rsi,0x48(%rbx)
     34f:	49 89 ea             	mov    %rbp,%r10
     352:	48 89 ab d0 00 00 00 	mov    %rbp,0xd0(%rbx)
     359:	48 89 bb c8 00 00 00 	mov    %rdi,0xc8(%rbx)
     360:	4c 89 8b d8 00 00 00 	mov    %r9,0xd8(%rbx)
     367:	81 f9 86 02 00 00    	cmp    $0x286,%ecx
     36d:	7f 5f                	jg     3ce <f_8001161d0+0x3ce>
     36f:	81 f9 2d 01 00 00    	cmp    $0x12d,%ecx
     375:	0f 8f e1 00 00 00    	jg     45c <f_8001161d0+0x45c>
     37b:	83 f9 6f             	cmp    $0x6f,%ecx
     37e:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
     383:	0f 8f bc 03 00 00    	jg     745 <f_8001161d0+0x745>
     389:	83 f9 04             	cmp    $0x4,%ecx
     38c:	0f 87 57 10 00 00    	ja     13e9 <f_8001161d0+0x13e9>
     392:	89 c9                	mov    %ecx,%ecx
     394:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 39b <f_8001161d0+0x39b>
     39b:	48 63 0c 8e          	movslq (%rsi,%rcx,4),%rcx
     39f:	48 01 f1             	add    %rsi,%rcx
     3a2:	ff e1                	jmp    *%rcx
     3a4:	45 0f b7 9c 24 e4 0c 	movzwl 0xce4(%r12),%r11d
     3ab:	00 00 
     3ad:	8b 8b a8 00 00 00    	mov    0xa8(%rbx),%ecx
     3b3:	be ff ff ff ff       	mov    $0xffffffff,%esi
     3b8:	01 f1                	add    %esi,%ecx
     3ba:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
     3be:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
     3c5:	0f b6 79 08          	movzbl 0x8(%rcx),%edi
     3c9:	e9 ea 15 00 00       	jmp    19b8 <f_8001161d0+0x19b8>
     3ce:	81 f9 6d 04 00 00    	cmp    $0x46d,%ecx
     3d4:	0f 8e 25 02 00 00    	jle    5ff <f_8001161d0+0x5ff>
     3da:	44 8d 81 92 fb ff ff 	lea    -0x46e(%rcx),%r8d
     3e1:	41 83 f8 0c          	cmp    $0xc,%r8d
     3e5:	0f 86 86 07 00 00    	jbe    b71 <f_8001161d0+0xb71>
     3eb:	44 8d 81 36 fb ff ff 	lea    -0x4ca(%rcx),%r8d
     3f2:	41 83 f8 16          	cmp    $0x16,%r8d
     3f6:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
     3fb:	0f 87 8f 0f 00 00    	ja     1390 <f_8001161d0+0x1390>
     401:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 408 <f_8001161d0+0x408>
     408:	4a 63 34 81          	movslq (%rcx,%r8,4),%rsi
     40c:	48 01 ce             	add    %rcx,%rsi
     40f:	ff e6                	jmp    *%rsi
     411:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
     418:	00 
     419:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
     420:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     427:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     42b:	48 89 43 10          	mov    %rax,0x10(%rbx)
     42f:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
     434:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
     43b:	48 89 03             	mov    %rax,(%rbx)
     43e:	48 c7 43 18 01 00 00 	movq   $0x1,0x18(%rbx)
     445:	00 
     446:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
     44d:	00 00 00 
     450:	48 8d 85 92 18 51 fd 	lea    -0x2aee76e(%rbp),%rax
     457:	e9 2a 1a 00 00       	jmp    1e86 <f_8001161d0+0x1e86>
     45c:	81 f9 c7 01 00 00    	cmp    $0x1c7,%ecx
     462:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
     467:	0f 8f b2 05 00 00    	jg     a1f <f_8001161d0+0xa1f>
     46d:	81 f9 b1 01 00 00    	cmp    $0x1b1,%ecx
     473:	0f 8f 2a 0a 00 00    	jg     ea3 <f_8001161d0+0xea3>
     479:	81 f9 2e 01 00 00    	cmp    $0x12e,%ecx
     47f:	0f 84 c6 1f 00 00    	je     244b <f_8001161d0+0x244b>
     485:	81 f9 66 01 00 00    	cmp    $0x166,%ecx
     48b:	0f 85 8f 19 00 00    	jne    1e20 <f_8001161d0+0x1e20>
     491:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
     498:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
     49f:	48 8b b6 c8 1e 00 00 	mov    0x1ec8(%rsi),%rsi
     4a6:	48 89 73 08          	mov    %rsi,0x8(%rbx)
     4aa:	48 c7 83 80 00 00 00 	movq   $0x3ce0,0x80(%rbx)
     4b1:	e0 3c 00 00 
     4b5:	4c 8b 14 24          	mov    (%rsp),%r10
     4b9:	4c 89 53 60          	mov    %r10,0x60(%rbx)
     4bd:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
     4c1:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
     4c5:	4c 69 c1 e0 3c 00 00 	imul   $0x3ce0,%rcx,%r8
     4cc:	45 31 c9             	xor    %r9d,%r9d
     4cf:	39 4e 08             	cmp    %ecx,0x8(%rsi)
     4d2:	4d 0f 47 c8          	cmova  %r8,%r9
     4d6:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
     4da:	49 8b 8c 09 40 3c 00 	mov    0x3c40(%r9,%rcx,1),%rcx
     4e1:	00 
     4e2:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
     4e9:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     4f0:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
     4f7:	4c 89 91 88 00 00 00 	mov    %r10,0x88(%rcx)
     4fe:	48 be ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rsi
     505:	ff 7f 7f 
     508:	48 89 b1 90 00 00 00 	mov    %rsi,0x90(%rcx)
     50f:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     516:	00 
     517:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     51b:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
     522:	00 00 00 
     525:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
     52c:	00 
     52d:	48 89 51 50          	mov    %rdx,0x50(%rcx)
     531:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
     535:	c5 fa 7f 41 58       	vmovdqu %xmm0,0x58(%rcx)
     53a:	48 c7 41 30 08 00 00 	movq   $0x8,0x30(%rcx)
     541:	00 
     542:	48 b8 10 00 00 00 03 	movabs $0x300000010,%rax
     549:	00 00 00 
     54c:	48 89 01             	mov    %rax,(%rcx)
     54f:	48 c7 41 08 00 00 00 	movq   $0x0,0x8(%rcx)
     556:	00 
     557:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     55e:	00 
     55f:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     566:	ff ff ff 
     569:	48 8d 42 0d          	lea    0xd(%rdx),%rax
     56d:	48 89 41 18          	mov    %rax,0x18(%rcx)
     571:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     578:	00 00 00 
     57b:	48 89 41 20          	mov    %rax,0x20(%rcx)
     57f:	48 89 51 28          	mov    %rdx,0x28(%rcx)
     583:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     58a:	48 89 b8 a4 00 00 00 	mov    %rdi,0xa4(%rax)
     591:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
     598:	00 80 3f 
     59b:	48 89 41 38          	mov    %rax,0x38(%rcx)
     59f:	48 89 41 40          	mov    %rax,0x40(%rcx)
     5a3:	49 be ca 5d c0 02 08 	movabs $0x802c05dca,%r14
     5aa:	00 00 00 
     5ad:	49 8d 86 8b 0d 02 00 	lea    0x20d8b(%r14),%rax
     5b4:	48 89 43 70          	mov    %rax,0x70(%rbx)
     5b8:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
     5bf:	ff 7f ff 
     5c2:	48 89 73 78          	mov    %rsi,0x78(%rbx)
     5c6:	48 89 b1 98 00 00 00 	mov    %rsi,0x98(%rcx)
     5cd:	48 8b 53 58          	mov    0x58(%rbx),%rdx
     5d1:	48 89 51 78          	mov    %rdx,0x78(%rcx)
     5d5:	48 89 b1 80 00 00 00 	mov    %rsi,0x80(%rcx)
     5dc:	48 8d 93 80 00 00 00 	lea    0x80(%rbx),%rdx
     5e3:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
     5ea:	00 
     5eb:	48 89 41 70          	mov    %rax,0x70(%rcx)
     5ef:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
     5f3:	8b 71 08             	mov    0x8(%rcx),%esi
     5f6:	48 89 73 40          	mov    %rsi,0x40(%rbx)
     5fa:	e9 c4 1f 00 00       	jmp    25c3 <f_8001161d0+0x25c3>
     5ff:	81 f9 d4 02 00 00    	cmp    $0x2d4,%ecx
     605:	0f 8f b7 04 00 00    	jg     ac2 <f_8001161d0+0xac2>
     60b:	81 f9 b5 02 00 00    	cmp    $0x2b5,%ecx
     611:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
     616:	0f 8f 25 09 00 00    	jg     f41 <f_8001161d0+0xf41>
     61c:	81 f9 87 02 00 00    	cmp    $0x287,%ecx
     622:	0f 84 05 21 00 00    	je     272d <f_8001161d0+0x272d>
     628:	81 f9 97 02 00 00    	cmp    $0x297,%ecx
     62e:	0f 85 ec 17 00 00    	jne    1e20 <f_8001161d0+0x1e20>
     634:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     63b:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
     642:	48 c7 01 00 00 00 40 	movq   $0x40000000,(%rcx)
     649:	49 b8 00 00 00 00 00 	movabs $0x40000000000000,%r8
     650:	00 40 00 
     653:	4c 89 41 08          	mov    %r8,0x8(%rcx)
     657:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     65e:	00 
     65f:	49 89 f9             	mov    %rdi,%r9
     662:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     669:	ff ff ff 
     66c:	4c 8d 47 14          	lea    0x14(%rdi),%r8
     670:	4c 89 41 18          	mov    %r8,0x18(%rcx)
     674:	48 89 53 40          	mov    %rdx,0x40(%rbx)
     678:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     67c:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     683:	00 
     684:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
     68b:	00 00 00 
     68e:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     695:	00 00 00 
     698:	48 89 41 20          	mov    %rax,0x20(%rcx)
     69c:	48 89 79 28          	mov    %rdi,0x28(%rcx)
     6a0:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
     6a5:	48 89 41 30          	mov    %rax,0x30(%rcx)
     6a9:	49 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r8
     6b0:	00 80 3f 
     6b3:	4c 89 41 38          	mov    %r8,0x38(%rcx)
     6b7:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
     6be:	00 00 00 
     6c1:	48 8d 80 80 0d 02 00 	lea    0x20d80(%rax),%rax
     6c8:	48 89 41 70          	mov    %rax,0x70(%rcx)
     6cc:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
     6d3:	ff 7f 7f 
     6d6:	4c 89 59 78          	mov    %r11,0x78(%rcx)
     6da:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
     6e1:	ff 7f ff 
     6e4:	48 89 b9 80 00 00 00 	mov    %rdi,0x80(%rcx)
     6eb:	48 8b 04 24          	mov    (%rsp),%rax
     6ef:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
     6f6:	c5 fd 6f 05 00 00 00 	vmovdqa 0x0(%rip),%ymm0        # 6fe <f_8001161d0+0x6fe>
     6fd:	00 
     6fe:	c5 fe 7f 43 60       	vmovdqu %ymm0,0x60(%rbx)
     703:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     70a:	4c 89 88 a4 00 00 00 	mov    %r9,0xa4(%rax)
     711:	4c 89 41 40          	mov    %r8,0x40(%rcx)
     715:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
     71c:	00 
     71d:	4c 89 99 90 00 00 00 	mov    %r11,0x90(%rcx)
     724:	48 89 b9 98 00 00 00 	mov    %rdi,0x98(%rcx)
     72b:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
     732:	00 
     733:	48 89 51 50          	mov    %rdx,0x50(%rcx)
     737:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
     73b:	c5 fa 7f 41 58       	vmovdqu %xmm0,0x58(%rcx)
     740:	e9 02 26 00 00       	jmp    2d47 <f_8001161d0+0x2d47>
     745:	81 f9 c8 00 00 00    	cmp    $0xc8,%ecx
     74b:	0f 8f 43 04 00 00    	jg     b94 <f_8001161d0+0xb94>
     751:	83 f9 70             	cmp    $0x70,%ecx
     754:	0f 84 e6 19 00 00    	je     2140 <f_8001161d0+0x2140>
     75a:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
     760:	0f 85 ba 16 00 00    	jne    1e20 <f_8001161d0+0x1e20>
     766:	4d 8b 9c 24 c8 1e 00 	mov    0x1ec8(%r12),%r11
     76d:	00 
     76e:	4c 89 5b 08          	mov    %r11,0x8(%rbx)
     772:	4c 8b 14 24          	mov    (%rsp),%r10
     776:	4c 89 53 60          	mov    %r10,0x60(%rbx)
     77a:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
     781:	00 
     782:	41 0f b6 75 08       	movzbl 0x8(%r13),%esi
     787:	48 89 73 68          	mov    %rsi,0x68(%rbx)
     78b:	45 8b 4b 08          	mov    0x8(%r11),%r9d
     78f:	4d 8b 7b 10          	mov    0x10(%r11),%r15
     793:	4c 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%r8
     79a:	31 c9                	xor    %ecx,%ecx
     79c:	41 39 f1             	cmp    %esi,%r9d
     79f:	41 b9 00 00 00 00    	mov    $0x0,%r9d
     7a5:	4d 0f 47 c8          	cmova  %r8,%r9
     7a9:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
     7b0:	00 
     7b1:	4f 8b 8c 39 40 3c 00 	mov    0x3c40(%r9,%r15,1),%r9
     7b8:	00 
     7b9:	4c 89 8b b0 00 00 00 	mov    %r9,0xb0(%rbx)
     7c0:	44 89 b0 70 ff ff ff 	mov    %r14d,-0x90(%rax)
     7c7:	4c 89 90 58 ff ff ff 	mov    %r10,-0xa8(%rax)
     7ce:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     7d5:	ff 7f 7f 
     7d8:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
     7df:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     7e6:	00 
     7e7:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     7eb:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     7f2:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     7f9:	00 00 00 00 
     7fd:	48 89 90 20 ff ff ff 	mov    %rdx,-0xe0(%rax)
     804:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
     808:	c5 fa 7f 80 28 ff ff 	vmovdqu %xmm0,-0xd8(%rax)
     80f:	ff 
     810:	48 c7 80 00 ff ff ff 	movq   $0x5,-0x100(%rax)
     817:	05 00 00 00 
     81b:	48 ba 10 00 00 00 03 	movabs $0x300000010,%rdx
     822:	00 00 00 
     825:	48 81 c2 f0 00 00 00 	add    $0xf0,%rdx
     82c:	48 89 90 d0 fe ff ff 	mov    %rdx,-0x130(%rax)
     833:	48 ba 00 00 00 00 00 	movabs $0x60000000000000,%rdx
     83a:	00 60 00 
     83d:	48 89 90 d8 fe ff ff 	mov    %rdx,-0x128(%rax)
     844:	4c 89 0b             	mov    %r9,(%rbx)
     847:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     84e:	ff ff 00 00 
     852:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     859:	ff ff ff 
     85c:	49 89 f9             	mov    %rdi,%r9
     85f:	48 89 d7             	mov    %rdx,%rdi
     862:	48 83 c2 08          	add    $0x8,%rdx
     866:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
     86d:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
     874:	00 00 00 
     877:	48 89 90 f0 fe ff ff 	mov    %rdx,-0x110(%rax)
     87e:	48 89 b8 f8 fe ff ff 	mov    %rdi,-0x108(%rax)
     885:	48 8b 93 c0 00 00 00 	mov    0xc0(%rbx),%rdx
     88c:	4c 89 8a a4 00 00 00 	mov    %r9,0xa4(%rdx)
     893:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
     89a:	00 80 3f 
     89d:	48 89 90 08 ff ff ff 	mov    %rdx,-0xf8(%rax)
     8a4:	48 89 90 10 ff ff ff 	mov    %rdx,-0xf0(%rax)
     8ab:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
     8b2:	00 00 00 
     8b5:	48 8d 95 1d 54 09 00 	lea    0x9541d(%rbp),%rdx
     8bc:	48 89 53 78          	mov    %rdx,0x78(%rbx)
     8c0:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
     8c7:	ff 7f ff 
     8ca:	48 89 bb 80 00 00 00 	mov    %rdi,0x80(%rbx)
     8d1:	48 89 b8 68 ff ff ff 	mov    %rdi,-0x98(%rax)
     8d8:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
     8df:	48 89 b8 50 ff ff ff 	mov    %rdi,-0xb0(%rax)
     8e6:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
     8ed:	00 00 00 00 
     8f1:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
     8f8:	41 39 73 08          	cmp    %esi,0x8(%r11)
     8fc:	ba 00 00 00 00       	mov    $0x0,%edx
     901:	49 0f 47 d0          	cmova  %r8,%rdx
     905:	49 8b 7b 10          	mov    0x10(%r11),%rdi
     909:	c5 fa 6f 84 17 00 2e 	vmovdqu 0x2e00(%rdi,%rdx,1),%xmm0
     910:	00 00 
     912:	c5 fa 7f 80 48 ff ff 	vmovdqu %xmm0,-0xb8(%rax)
     919:	ff 
     91a:	41 8b 7b 08          	mov    0x8(%r11),%edi
     91e:	45 31 c9             	xor    %r9d,%r9d
     921:	31 d2                	xor    %edx,%edx
     923:	41 89 fa             	mov    %edi,%r10d
     926:	41 29 f2             	sub    %esi,%r10d
     929:	49 0f 47 c8          	cmova  %r8,%rcx
     92d:	41 0f 94 c1          	sete   %r9b
     931:	0f 93 c2             	setae  %dl
     934:	41 c1 e1 1e          	shl    $0x1e,%r9d
     938:	c1 e2 1d             	shl    $0x1d,%edx
     93b:	44 09 ca             	or     %r9d,%edx
     93e:	c4 e2 28 f2 f7       	andn   %edi,%r10d,%esi
     943:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
     94a:	44 09 d2             	or     %r10d,%edx
     94d:	49 8b 7b 10          	mov    0x10(%r11),%rdi
     951:	c1 ee 03             	shr    $0x3,%esi
     954:	81 e6 00 00 00 10    	and    $0x10000000,%esi
     95a:	09 d6                	or     %edx,%esi
     95c:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
     963:	48 8b 94 0f 80 30 00 	mov    0x3080(%rdi,%rcx,1),%rdx
     96a:	00 
     96b:	48 8b b4 0f 88 30 00 	mov    0x3088(%rdi,%rcx,1),%rsi
     972:	00 
     973:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     977:	48 89 90 60 ff ff ff 	mov    %rdx,-0xa0(%rax)
     97e:	48 89 b0 68 ff ff ff 	mov    %rsi,-0x98(%rax)
     985:	48 8b 94 0f 90 30 00 	mov    0x3090(%rdi,%rcx,1),%rdx
     98c:	00 
     98d:	48 89 53 48          	mov    %rdx,0x48(%rbx)
     991:	8b 8c 0f 98 30 00 00 	mov    0x3098(%rdi,%rcx,1),%ecx
     998:	89 88 78 ff ff ff    	mov    %ecx,-0x88(%rax)
     99e:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
     9a5:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
     9a9:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
     9ad:	48 89 90 70 ff ff ff 	mov    %rdx,-0x90(%rax)
     9b4:	48 8d 85 56 08 51 fd 	lea    -0x2aef7aa(%rbp),%rax
     9bb:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
     9c2:	48 89 df             	mov    %rbx,%rdi
     9c5:	c5 f8 77             	vzeroupper
     9c8:	e8 00 00 00 00       	call   9cd <f_8001161d0+0x9cd>
     9cd:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     9d4:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
     9db:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     9e2:	48 89 01             	mov    %rax,(%rcx)
     9e5:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     9ec:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     9f3:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
     9f7:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
     9fe:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     a02:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     a08:	48 89 43 40          	mov    %rax,0x40(%rbx)
     a0c:	88 51 08             	mov    %dl,0x8(%rcx)
     a0f:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     a16:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
     a1a:	e9 f4 1c 00 00       	jmp    2713 <f_8001161d0+0x2713>
     a1f:	81 f9 51 02 00 00    	cmp    $0x251,%ecx
     a25:	0f 8f ba 05 00 00    	jg     fe5 <f_8001161d0+0xfe5>
     a2b:	81 f9 c8 01 00 00    	cmp    $0x1c8,%ecx
     a31:	0f 84 7c 1d 00 00    	je     27b3 <f_8001161d0+0x27b3>
     a37:	81 f9 0f 02 00 00    	cmp    $0x20f,%ecx
     a3d:	0f 85 dd 13 00 00    	jne    1e20 <f_8001161d0+0x1e20>
     a43:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     a4a:	00 
     a4b:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     a52:	48 c7 01 00 08 00 00 	movq   $0x800,(%rcx)
     a59:	48 c7 41 08 01 00 00 	movq   $0x1,0x8(%rcx)
     a60:	00 
     a61:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     a68:	ff ff ff 
     a6b:	48 8d 77 0b          	lea    0xb(%rdi),%rsi
     a6f:	48 89 73 68          	mov    %rsi,0x68(%rbx)
     a73:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     a7a:	00 
     a7b:	48 89 71 18          	mov    %rsi,0x18(%rcx)
     a7f:	48 be 00 00 00 00 01 	movabs $0x100000000,%rsi
     a86:	00 00 00 
     a89:	48 89 71 20          	mov    %rsi,0x20(%rcx)
     a8d:	48 89 79 28          	mov    %rdi,0x28(%rcx)
     a91:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
     a98:	00 80 3f 
     a9b:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
     a9f:	be ff ff ff ff       	mov    $0xffffffff,%esi
     aa4:	48 89 71 30          	mov    %rsi,0x30(%rcx)
     aa8:	4c 89 79 38          	mov    %r15,0x38(%rcx)
     aac:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
     ab3:	00 00 00 
     ab6:	4c 8d 9d 07 a8 04 00 	lea    0x4a807(%rbp),%r11
     abd:	e9 ad 17 00 00       	jmp    226f <f_8001161d0+0x226f>
     ac2:	81 f9 ac 03 00 00    	cmp    $0x3ac,%ecx
     ac8:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
     acd:	0f 8f 90 06 00 00    	jg     1163 <f_8001161d0+0x1163>
     ad3:	81 f9 d5 02 00 00    	cmp    $0x2d5,%ecx
     ad9:	0f 84 65 1f 00 00    	je     2a44 <f_8001161d0+0x2a44>
     adf:	81 f9 f3 02 00 00    	cmp    $0x2f3,%ecx
     ae5:	0f 85 35 13 00 00    	jne    1e20 <f_8001161d0+0x1e20>
     aeb:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     af2:	00 
     af3:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
     afa:	49 c7 03 00 02 00 00 	movq   $0x200,(%r11)
     b01:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
     b08:	00 40 00 
     b0b:	49 89 4b 08          	mov    %rcx,0x8(%r11)
     b0f:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
     b16:	00 
     b17:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     b1e:	ff ff ff 
     b21:	48 8d 4f 13          	lea    0x13(%rdi),%rcx
     b25:	49 89 4b 18          	mov    %rcx,0x18(%r11)
     b29:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     b30:	00 00 00 
     b33:	49 89 4b 20          	mov    %rcx,0x20(%r11)
     b37:	49 89 7b 28          	mov    %rdi,0x28(%r11)
     b3b:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
     b41:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
     b45:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
     b4c:	00 80 3f 
     b4f:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
     b53:	49 8d 4b 30          	lea    0x30(%r11),%rcx
     b57:	49 83 c3 38          	add    $0x38,%r11
     b5b:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
     b62:	00 00 00 
     b65:	4c 8d 87 f9 7a ff ff 	lea    -0x8507(%rdi),%r8
     b6c:	e9 2b 21 00 00       	jmp    2c9c <f_8001161d0+0x2c9c>
     b71:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # b78 <f_8001161d0+0xb78>
     b78:	4a 63 34 81          	movslq (%rcx,%r8,4),%rsi
     b7c:	48 01 ce             	add    %rcx,%rsi
     b7f:	ff e6                	jmp    *%rsi
     b81:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
     b88:	00 00 00 
     b8b:	4c 8d 5d e0          	lea    -0x20(%rbp),%r11
     b8f:	e9 2d 09 00 00       	jmp    14c1 <f_8001161d0+0x14c1>
     b94:	81 f9 c9 00 00 00    	cmp    $0xc9,%ecx
     b9a:	0f 84 38 16 00 00    	je     21d8 <f_8001161d0+0x21d8>
     ba0:	81 f9 d9 00 00 00    	cmp    $0xd9,%ecx
     ba6:	0f 85 74 12 00 00    	jne    1e20 <f_8001161d0+0x1e20>
     bac:	49 8b 8c 24 c8 1e 00 	mov    0x1ec8(%r12),%rcx
     bb3:	00 
     bb4:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     bb8:	4c 8b 14 24          	mov    (%rsp),%r10
     bbc:	4c 89 53 60          	mov    %r10,0x60(%rbx)
     bc0:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
     bc7:	00 
     bc8:	45 0f b6 5d 08       	movzbl 0x8(%r13),%r11d
     bcd:	4c 89 5b 70          	mov    %r11,0x70(%rbx)
     bd1:	41 0f b7 ad 14 29 00 	movzwl 0x2914(%r13),%ebp
     bd8:	00 
     bd9:	83 e5 40             	and    $0x40,%ebp
     bdc:	8b 71 08             	mov    0x8(%rcx),%esi
     bdf:	4c 8b 49 10          	mov    0x10(%rcx),%r9
     be3:	45 31 c0             	xor    %r8d,%r8d
     be6:	44 39 de             	cmp    %r11d,%esi
     be9:	be 00 00 00 00       	mov    $0x0,%esi
     bee:	49 0f 47 f3          	cmova  %r11,%rsi
     bf2:	48 c7 43 78 e0 3c 00 	movq   $0x3ce0,0x78(%rbx)
     bf9:	00 
     bfa:	48 89 b3 88 00 00 00 	mov    %rsi,0x88(%rbx)
     c01:	48 69 f6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rsi
     c08:	4a 8b b4 0e 40 3c 00 	mov    0x3c40(%rsi,%r9,1),%rsi
     c0f:	00 
     c10:	48 89 b3 b0 00 00 00 	mov    %rsi,0xb0(%rbx)
     c17:	4c 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%r9
     c1e:	4d 8b 89 b8 1e 00 00 	mov    0x1eb8(%r9),%r9
     c25:	44 89 b0 70 ff ff ff 	mov    %r14d,-0x90(%rax)
     c2c:	4c 89 90 58 ff ff ff 	mov    %r10,-0xa8(%rax)
     c33:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     c3a:	ff 7f 7f 
     c3d:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
     c44:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     c4b:	00 
     c4c:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     c50:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     c57:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
     c5b:	c5 fa 7f 80 28 ff ff 	vmovdqu %xmm0,-0xd8(%rax)
     c62:	ff 
     c63:	41 80 b9 b0 06 00 00 	cmpb   $0x0,0x6b0(%r9)
     c6a:	00 
     c6b:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     c72:	00 00 00 00 
     c76:	48 89 90 20 ff ff ff 	mov    %rdx,-0xe0(%rax)
     c7d:	48 c7 80 00 ff ff ff 	movq   $0x4,-0x100(%rax)
     c84:	04 00 00 00 
     c88:	48 89 33             	mov    %rsi,(%rbx)
     c8b:	0f 95 c2             	setne  %dl
     c8e:	c1 ed 06             	shr    $0x6,%ebp
     c91:	40 20 d5             	and    %dl,%bpl
     c94:	c7 80 d8 fe ff ff 00 	movl   $0x0,-0x128(%rax)
     c9b:	00 00 00 
     c9e:	40 0f b6 d5          	movzbl %bpl,%edx
     ca2:	c1 e2 1a             	shl    $0x1a,%edx
     ca5:	81 ca 01 00 40 00    	or     $0x400001,%edx
     cab:	89 90 dc fe ff ff    	mov    %edx,-0x124(%rax)
     cb1:	48 ba 10 00 00 00 03 	movabs $0x300000010,%rdx
     cb8:	00 00 00 
     cbb:	48 89 90 d0 fe ff ff 	mov    %rdx,-0x130(%rax)
     cc2:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     cc9:	ff ff 00 00 
     ccd:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
     cd4:	ff ff ff 
     cd7:	48 8d 56 07          	lea    0x7(%rsi),%rdx
     cdb:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
     ce2:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
     ce9:	00 00 00 
     cec:	48 89 90 f0 fe ff ff 	mov    %rdx,-0x110(%rax)
     cf3:	48 89 b0 f8 fe ff ff 	mov    %rsi,-0x108(%rax)
     cfa:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
     d01:	00 80 3f 
     d04:	48 89 90 08 ff ff ff 	mov    %rdx,-0xf8(%rax)
     d0b:	48 89 90 10 ff ff ff 	mov    %rdx,-0xf0(%rax)
     d12:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
     d19:	00 00 00 
     d1c:	48 8d 95 00 54 09 00 	lea    0x95400(%rbp),%rdx
     d23:	48 89 53 68          	mov    %rdx,0x68(%rbx)
     d27:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
     d2e:	48 89 be a4 00 00 00 	mov    %rdi,0xa4(%rsi)
     d35:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
     d3c:	ff 7f ff 
     d3f:	48 89 b3 80 00 00 00 	mov    %rsi,0x80(%rbx)
     d46:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
     d4d:	48 89 b0 50 ff ff ff 	mov    %rsi,-0xb0(%rax)
     d54:	48 89 b0 68 ff ff ff 	mov    %rsi,-0x98(%rax)
     d5b:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
     d62:	00 00 00 00 
     d66:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
     d6d:	49 69 d3 e0 3c 00 00 	imul   $0x3ce0,%r11,%rdx
     d74:	44 39 59 08          	cmp    %r11d,0x8(%rcx)
     d78:	49 0f 46 d0          	cmovbe %r8,%rdx
     d7c:	48 8b 71 10          	mov    0x10(%rcx),%rsi
     d80:	c5 fa 6f 84 16 00 2e 	vmovdqu 0x2e00(%rsi,%rdx,1),%xmm0
     d87:	00 00 
     d89:	c5 fa 7f 80 48 ff ff 	vmovdqu %xmm0,-0xb8(%rax)
     d90:	ff 
     d91:	8b 71 08             	mov    0x8(%rcx),%esi
     d94:	31 ff                	xor    %edi,%edi
     d96:	31 c0                	xor    %eax,%eax
     d98:	41 89 f1             	mov    %esi,%r9d
     d9b:	45 29 d9             	sub    %r11d,%r9d
     d9e:	8b 53 70             	mov    0x70(%rbx),%edx
     da1:	49 0f 46 d0          	cmovbe %r8,%rdx
     da5:	40 0f 94 c7          	sete   %dil
     da9:	0f 93 c0             	setae  %al
     dac:	c1 e7 1e             	shl    $0x1e,%edi
     daf:	c1 e0 1d             	shl    $0x1d,%eax
     db2:	09 f8                	or     %edi,%eax
     db4:	48 8b 49 10          	mov    0x10(%rcx),%rcx
     db8:	c4 e2 30 f2 f6       	andn   %esi,%r9d,%esi
     dbd:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
     dc4:	44 09 c8             	or     %r9d,%eax
     dc7:	8b 7b 78             	mov    0x78(%rbx),%edi
     dca:	c1 ee 03             	shr    $0x3,%esi
     dcd:	81 e6 00 00 00 10    	and    $0x10000000,%esi
     dd3:	09 c6                	or     %eax,%esi
     dd5:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
     ddc:	48 0f af fa          	imul   %rdx,%rdi
     de0:	48 8b 84 0f 80 30 00 	mov    0x3080(%rdi,%rcx,1),%rax
     de7:	00 
     de8:	48 8b 94 0f 88 30 00 	mov    0x3088(%rdi,%rcx,1),%rdx
     def:	00 
     df0:	48 89 53 50          	mov    %rdx,0x50(%rbx)
     df4:	48 8b b3 d0 00 00 00 	mov    0xd0(%rbx),%rsi
     dfb:	48 89 06             	mov    %rax,(%rsi)
     dfe:	48 89 56 08          	mov    %rdx,0x8(%rsi)
     e02:	48 8b 84 0f 90 30 00 	mov    0x3090(%rdi,%rcx,1),%rax
     e09:	00 
     e0a:	48 89 43 48          	mov    %rax,0x48(%rbx)
     e0e:	8b 8c 0f 98 30 00 00 	mov    0x3098(%rdi,%rcx,1),%ecx
     e15:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
     e1c:	89 4a 08             	mov    %ecx,0x8(%rdx)
     e1f:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
     e26:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
     e2a:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
     e2e:	48 89 02             	mov    %rax,(%rdx)
     e31:	48 8d 85 e6 09 51 fd 	lea    -0x2aef61a(%rbp),%rax
     e38:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
     e3f:	48 89 df             	mov    %rbx,%rdi
     e42:	c5 f8 77             	vzeroupper
     e45:	e8 00 00 00 00       	call   e4a <f_8001161d0+0xe4a>
     e4a:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     e51:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
     e58:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     e5f:	48 89 01             	mov    %rax,(%rcx)
     e62:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     e69:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     e70:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
     e74:	48 89 53 48          	mov    %rdx,0x48(%rbx)
     e78:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
     e7f:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     e83:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     e89:	48 89 43 40          	mov    %rax,0x40(%rbx)
     e8d:	88 51 08             	mov    %dl,0x8(%rcx)
     e90:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     e97:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
     e9b:	89 41 24             	mov    %eax,0x24(%rcx)
     e9e:	e9 c4 1f 00 00       	jmp    2e67 <f_8001161d0+0x2e67>
     ea3:	81 f9 b2 01 00 00    	cmp    $0x1b2,%ecx
     ea9:	0f 84 9e 1c 00 00    	je     2b4d <f_8001161d0+0x2b4d>
     eaf:	81 f9 b8 01 00 00    	cmp    $0x1b8,%ecx
     eb5:	0f 85 65 0f 00 00    	jne    1e20 <f_8001161d0+0x1e20>
     ebb:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     ec2:	00 
     ec3:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
     eca:	49 c7 03 08 00 00 00 	movq   $0x8,(%r11)
     ed1:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
     ed8:	00 40 00 
     edb:	49 89 4b 08          	mov    %rcx,0x8(%r11)
     edf:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
     ee6:	00 
     ee7:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     eee:	ff ff ff 
     ef1:	48 8d 4f 15          	lea    0x15(%rdi),%rcx
     ef5:	49 89 4b 18          	mov    %rcx,0x18(%r11)
     ef9:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     f00:	00 00 00 
     f03:	49 89 4b 20          	mov    %rcx,0x20(%r11)
     f07:	49 89 7b 28          	mov    %rdi,0x28(%r11)
     f0b:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
     f11:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
     f15:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
     f1c:	00 80 3f 
     f1f:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
     f23:	49 8d 4b 30          	lea    0x30(%r11),%rcx
     f27:	49 83 c3 38          	add    $0x38,%r11
     f2b:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
     f32:	00 00 00 
     f35:	4c 8d 87 af 2c 05 00 	lea    0x52caf(%rdi),%r8
     f3c:	e9 5b 1d 00 00       	jmp    2c9c <f_8001161d0+0x2c9c>
     f41:	81 f9 b6 02 00 00    	cmp    $0x2b6,%ecx
     f47:	0f 84 55 1c 00 00    	je     2ba2 <f_8001161d0+0x2ba2>
     f4d:	81 f9 c5 02 00 00    	cmp    $0x2c5,%ecx
     f53:	0f 85 c7 0e 00 00    	jne    1e20 <f_8001161d0+0x1e20>
     f59:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     f60:	00 
     f61:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
     f68:	48 b9 01 00 00 00 04 	movabs $0x400000001,%rcx
     f6f:	00 00 00 
     f72:	49 89 0b             	mov    %rcx,(%r11)
     f75:	48 b9 00 00 00 00 02 	movabs $0x80200000000,%rcx
     f7c:	08 00 00 
     f7f:	49 89 4b 08          	mov    %rcx,0x8(%r11)
     f83:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
     f8a:	00 
     f8b:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     f92:	ff ff ff 
     f95:	48 8d 4f 0f          	lea    0xf(%rdi),%rcx
     f99:	49 89 4b 18          	mov    %rcx,0x18(%r11)
     f9d:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     fa4:	00 00 00 
     fa7:	49 89 4b 20          	mov    %rcx,0x20(%r11)
     fab:	49 89 7b 28          	mov    %rdi,0x28(%r11)
     faf:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
     fb5:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
     fb9:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
     fc0:	00 80 3f 
     fc3:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
     fc7:	49 8d 4b 30          	lea    0x30(%r11),%rcx
     fcb:	49 83 c3 38          	add    $0x38,%r11
     fcf:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
     fd6:	00 00 00 
     fd9:	4c 8d 87 88 db 0a 00 	lea    0xadb88(%rdi),%r8
     fe0:	e9 b7 1c 00 00       	jmp    2c9c <f_8001161d0+0x2c9c>
     fe5:	81 f9 52 02 00 00    	cmp    $0x252,%ecx
     feb:	0f 84 34 1c 00 00    	je     2c25 <f_8001161d0+0x2c25>
     ff1:	81 f9 61 02 00 00    	cmp    $0x261,%ecx
     ff7:	0f 85 23 0e 00 00    	jne    1e20 <f_8001161d0+0x1e20>
     ffd:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    1004:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    100b:	48 be 00 00 00 00 0f 	movabs $0xf00000000,%rsi
    1012:	00 00 00 
    1015:	48 89 71 14          	mov    %rsi,0x14(%rcx)
    1019:	48 be 00 00 00 00 ff 	movabs $0xffff00000000,%rsi
    1020:	ff 00 00 
    1023:	48 81 ce 00 00 40 08 	or     $0x8400000,%rsi
    102a:	48 89 71 0c          	mov    %rsi,0xc(%rcx)
    102e:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
    1035:	8b b6 8c 3a 00 00    	mov    0x3a8c(%rsi),%esi
    103b:	4c 8b 14 24          	mov    (%rsp),%r10
    103f:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    1043:	48 89 53 40          	mov    %rdx,0x40(%rbx)
    1047:	48 c7 41 04 00 00 00 	movq   $0x0,0x4(%rcx)
    104e:	00 
    104f:	4c 8b 43 78          	mov    0x78(%rbx),%r8
    1053:	4c 89 41 1c          	mov    %r8,0x1c(%rcx)
    1057:	41 89 f1             	mov    %esi,%r9d
    105a:	41 c1 e1 0d          	shl    $0xd,%r9d
    105e:	41 81 e1 00 00 00 40 	and    $0x40000000,%r9d
    1065:	49 81 f1 00 00 00 40 	xor    $0x40000000,%r9
    106c:	4c 89 8b 10 01 00 00 	mov    %r9,0x110(%rbx)
    1073:	48 c7 43 68 01 00 00 	movq   $0x1,0x68(%rbx)
    107a:	00 
    107b:	c7 41 34 00 00 00 00 	movl   $0x0,0x34(%rcx)
    1082:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1089:	00 
    108a:	48 c7 41 24 01 00 00 	movq   $0x1,0x24(%rcx)
    1091:	00 
    1092:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1096:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    109d:	00 00 00 
    10a0:	44 89 41 2c          	mov    %r8d,0x2c(%rcx)
    10a4:	c7 41 30 01 00 00 00 	movl   $0x1,0x30(%rcx)
    10ab:	c1 ee 08             	shr    $0x8,%esi
    10ae:	81 e6 00 02 00 00    	and    $0x200,%esi
    10b4:	81 ce 00 00 00 40    	or     $0x40000000,%esi
    10ba:	89 31                	mov    %esi,(%rcx)
    10bc:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    10c3:	00 00 00 
    10c6:	48 05 f0 85 00 00    	add    $0x85f0,%rax
    10cc:	48 89 43 70          	mov    %rax,0x70(%rbx)
    10d0:	48 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rsi
    10d7:	00 80 3f 
    10da:	48 89 71 38          	mov    %rsi,0x38(%rcx)
    10de:	48 89 71 40          	mov    %rsi,0x40(%rcx)
    10e2:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    10e9:	48 89 be a4 00 00 00 	mov    %rdi,0xa4(%rsi)
    10f0:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
    10f7:	ff 7f ff 
    10fa:	48 89 b3 80 00 00 00 	mov    %rsi,0x80(%rbx)
    1101:	48 89 b1 98 00 00 00 	mov    %rsi,0x98(%rcx)
    1108:	48 bf ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rdi
    110f:	ff 7f 7f 
    1112:	48 89 79 78          	mov    %rdi,0x78(%rcx)
    1116:	48 89 b1 80 00 00 00 	mov    %rsi,0x80(%rcx)
    111d:	4c 89 91 88 00 00 00 	mov    %r10,0x88(%rcx)
    1124:	48 89 b9 90 00 00 00 	mov    %rdi,0x90(%rcx)
    112b:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    112f:	c5 fa 7f 41 58       	vmovdqu %xmm0,0x58(%rcx)
    1134:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    113b:	00 
    113c:	48 89 41 70          	mov    %rax,0x70(%rcx)
    1140:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    1147:	48 c7 40 48 00 00 00 	movq   $0x0,0x48(%rax)
    114e:	00 
    114f:	48 89 50 50          	mov    %rdx,0x50(%rax)
    1153:	48 8b 73 48          	mov    0x48(%rbx),%rsi
    1157:	4c 8b b3 d0 00 00 00 	mov    0xd0(%rbx),%r14
    115e:	e9 e7 1b 00 00       	jmp    2d4a <f_8001161d0+0x2d4a>
    1163:	81 f9 ad 03 00 00    	cmp    $0x3ad,%ecx
    1169:	0f 84 b8 1f 00 00    	je     3127 <f_8001161d0+0x3127>
    116f:	81 f9 12 04 00 00    	cmp    $0x412,%ecx
    1175:	0f 85 a5 0c 00 00    	jne    1e20 <f_8001161d0+0x1e20>
    117b:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
    1182:	48 8b 89 c8 1e 00 00 	mov    0x1ec8(%rcx),%rcx
    1189:	48 89 4b 70          	mov    %rcx,0x70(%rbx)
    118d:	49 b9 00 00 00 00 01 	movabs $0x100000000,%r9
    1194:	00 00 00 
    1197:	4c 89 0b             	mov    %r9,(%rbx)
    119a:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    119e:	4c 8b 83 00 01 00 00 	mov    0x100(%rbx),%r8
    11a5:	49 c7 00 02 00 00 00 	movq   $0x2,(%r8)
    11ac:	48 be 00 00 00 00 00 	movabs $0x40000000000000,%rsi
    11b3:	00 40 00 
    11b6:	48 ff c6             	inc    %rsi
    11b9:	49 89 70 08          	mov    %rsi,0x8(%r8)
    11bd:	4d 89 48 20          	mov    %r9,0x20(%r8)
    11c1:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    11c8:	ff ff ff 
    11cb:	49 89 fb             	mov    %rdi,%r11
    11ce:	48 89 f7             	mov    %rsi,%rdi
    11d1:	49 89 70 28          	mov    %rsi,0x28(%r8)
    11d5:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    11dc:	00 00 00 
    11df:	48 89 6b 68          	mov    %rbp,0x68(%rbx)
    11e3:	49 b9 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r9
    11ea:	ff 7f ff 
    11ed:	4d 89 88 80 00 00 00 	mov    %r9,0x80(%r8)
    11f4:	48 8b 34 24          	mov    (%rsp),%rsi
    11f8:	49 89 b0 88 00 00 00 	mov    %rsi,0x88(%r8)
    11ff:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    1206:	4c 89 9e a4 00 00 00 	mov    %r11,0xa4(%rsi)
    120d:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
    1214:	ff 7f 7f 
    1217:	4d 89 90 90 00 00 00 	mov    %r10,0x90(%r8)
    121e:	4d 89 88 98 00 00 00 	mov    %r9,0x98(%r8)
    1225:	c5 fd 6f 05 00 00 00 	vmovdqa 0x0(%rip),%ymm0        # 122d <f_8001161d0+0x122d>
    122c:	00 
    122d:	c5 fe 7f 43 78       	vmovdqu %ymm0,0x78(%rbx)
    1232:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1239:	00 
    123a:	45 89 b0 a0 00 00 00 	mov    %r14d,0xa0(%r8)
    1241:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1248:	0f b6 70 08          	movzbl 0x8(%rax),%esi
    124c:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    1250:	41 c7 80 bc 00 00 00 	movl   $0x3,0xbc(%r8)
    1257:	03 00 00 00 
    125b:	49 c7 40 10 ff ff 00 	movq   $0xffff,0x10(%r8)
    1262:	00 
    1263:	48 8d 47 16          	lea    0x16(%rdi),%rax
    1267:	49 89 40 18          	mov    %rax,0x18(%r8)
    126b:	49 c7 40 68 00 00 00 	movq   $0x0,0x68(%r8)
    1272:	00 
    1273:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    1278:	49 89 40 30          	mov    %rax,0x30(%r8)
    127c:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    1283:	00 80 3f 
    1286:	49 89 40 38          	mov    %rax,0x38(%r8)
    128a:	49 89 40 40          	mov    %rax,0x40(%r8)
    128e:	49 c7 40 48 00 00 00 	movq   $0x0,0x48(%r8)
    1295:	00 
    1296:	49 89 50 50          	mov    %rdx,0x50(%r8)
    129a:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    129e:	c4 c1 7a 7f 40 58    	vmovdqu %xmm0,0x58(%r8)
    12a4:	49 89 68 70          	mov    %rbp,0x70(%r8)
    12a8:	4d 89 50 78          	mov    %r10,0x78(%r8)
    12ac:	48 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rax
    12b3:	31 ff                	xor    %edi,%edi
    12b5:	39 71 08             	cmp    %esi,0x8(%rcx)
    12b8:	48 0f 46 c7          	cmovbe %rdi,%rax
    12bc:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    12c0:	48 8b 94 08 b8 30 00 	mov    0x30b8(%rax,%rcx,1),%rdx
    12c7:	00 
    12c8:	48 89 53 60          	mov    %rdx,0x60(%rbx)
    12cc:	48 8b 84 08 b0 30 00 	mov    0x30b0(%rax,%rcx,1),%rax
    12d3:	00 
    12d4:	48 8b 4b 48          	mov    0x48(%rbx),%rcx
    12d8:	48 89 01             	mov    %rax,(%rcx)
    12db:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    12df:	48 8b 43 70          	mov    0x70(%rbx),%rax
    12e3:	44 8b 40 08          	mov    0x8(%rax),%r8d
    12e7:	4c 89 43 48          	mov    %r8,0x48(%rbx)
    12eb:	48 8b 48 10          	mov    0x10(%rax),%rcx
    12ef:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    12f3:	8b 53 40             	mov    0x40(%rbx),%edx
    12f6:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
    12fd:	45 31 d2             	xor    %r10d,%r10d
    1300:	45 31 c9             	xor    %r9d,%r9d
    1303:	45 89 c3             	mov    %r8d,%r11d
    1306:	41 29 f3             	sub    %esi,%r11d
    1309:	48 0f 46 d7          	cmovbe %rdi,%rdx
    130d:	41 0f 94 c2          	sete   %r10b
    1311:	41 0f 93 c1          	setae  %r9b
    1315:	41 c1 e2 1e          	shl    $0x1e,%r10d
    1319:	41 c1 e1 1d          	shl    $0x1d,%r9d
    131d:	45 09 d1             	or     %r10d,%r9d
    1320:	c4 c2 20 f2 f0       	andn   %r8d,%r11d,%esi
    1325:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    132c:	45 09 d9             	or     %r11d,%r9d
    132f:	c1 ee 03             	shr    $0x3,%esi
    1332:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    1338:	44 09 ce             	or     %r9d,%esi
    133b:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    1342:	48 8b b4 0a 30 33 00 	mov    0x3330(%rdx,%rcx,1),%rsi
    1349:	00 
    134a:	48 8b bc 0a 38 33 00 	mov    0x3338(%rdx,%rcx,1),%rdi
    1351:	00 
    1352:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    1356:	4c 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%r8
    135d:	49 89 30             	mov    %rsi,(%r8)
    1360:	49 89 78 08          	mov    %rdi,0x8(%r8)
    1364:	8b b4 0a 48 33 00 00 	mov    0x3348(%rdx,%rcx,1),%esi
    136b:	48 8b 8c 0a 40 33 00 	mov    0x3340(%rdx,%rcx,1),%rcx
    1372:	00 
    1373:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
    137a:	48 89 0a             	mov    %rcx,(%rdx)
    137d:	89 72 08             	mov    %esi,0x8(%rdx)
    1380:	8b 48 44             	mov    0x44(%rax),%ecx
    1383:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    1387:	48 83 c0 30          	add    $0x30,%rax
    138b:	e9 77 0d 00 00       	jmp    2107 <f_8001161d0+0x2107>
    1390:	81 f9 1a 05 00 00    	cmp    $0x51a,%ecx
    1396:	0f 85 84 0a 00 00    	jne    1e20 <f_8001161d0+0x1e20>
    139c:	b8 e8 0a 00 00       	mov    $0xae8,%eax
    13a1:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    13a8:	48 89 03             	mov    %rax,(%rbx)
    13ab:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    13b2:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    13b9:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    13bd:	48 89 43 10          	mov    %rax,0x10(%rbx)
    13c1:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    13c8:	00 00 00 
    13cb:	48 8d 85 ca 19 51 fd 	lea    -0x2aee636(%rbp),%rax
    13d2:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    13d9:	48 89 df             	mov    %rbx,%rdi
    13dc:	c5 f8 77             	vzeroupper
    13df:	e8 00 00 00 00       	call   13e4 <f_8001161d0+0x13e4>
    13e4:	e9 7e 1a 00 00       	jmp    2e67 <f_8001161d0+0x2e67>
    13e9:	83 f9 61             	cmp    $0x61,%ecx
    13ec:	0f 85 2e 0a 00 00    	jne    1e20 <f_8001161d0+0x1e20>
    13f2:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    13f9:	00 
    13fa:	48 c7 80 d0 fe ff ff 	movq   $0x8,-0x130(%rax)
    1401:	08 00 00 00 
    1405:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    140c:	00 40 00 
    140f:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    1416:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    141d:	ff ff 00 00 
    1421:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    1428:	ff ff ff 
    142b:	48 8d 4f 0f          	lea    0xf(%rdi),%rcx
    142f:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    1436:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    143d:	00 00 00 
    1440:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
    1444:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    144b:	48 89 b8 f8 fe ff ff 	mov    %rdi,-0x108(%rax)
    1452:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    1459:	00 80 3f 
    145c:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    1460:	48 8d 88 00 ff ff ff 	lea    -0x100(%rax),%rcx
    1467:	4c 8d 98 08 ff ff ff 	lea    -0xf8(%rax),%r11
    146e:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    1475:	00 00 00 
    1478:	4c 8d 87 ab f2 0c 00 	lea    0xcf2ab(%rdi),%r8
    147f:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    1485:	e9 12 18 00 00       	jmp    2c9c <f_8001161d0+0x2c9c>
    148a:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    1491:	00 00 00 
    1494:	4c 8d 9d 0b d1 09 00 	lea    0x9d10b(%rbp),%r11
    149b:	eb 24                	jmp    14c1 <f_8001161d0+0x14c1>
    149d:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    14a4:	00 00 00 
    14a7:	4c 8d 9d 2d 8c 01 00 	lea    0x18c2d(%rbp),%r11
    14ae:	eb 11                	jmp    14c1 <f_8001161d0+0x14c1>
    14b0:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    14b7:	00 00 00 
    14ba:	4c 8d 9d 4b 4f 0a 00 	lea    0xa4f4b(%rbp),%r11
    14c1:	4c 89 5b 68          	mov    %r11,0x68(%rbx)
    14c5:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    14cc:	c7 01 00 00 00 10    	movl   $0x10000000,(%rcx)
    14d2:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
    14d9:	4c 8b be f0 31 00 00 	mov    0x31f0(%rsi),%r15
    14e0:	4c 89 3b             	mov    %r15,(%rbx)
    14e3:	49 b8 10 00 00 00 03 	movabs $0x300000010,%r8
    14ea:	00 00 00 
    14ed:	4d 8d 48 f0          	lea    -0x10(%r8),%r9
    14f1:	4c 89 49 14          	mov    %r9,0x14(%rcx)
    14f5:	48 c7 43 78 01 00 00 	movq   $0x1,0x78(%rbx)
    14fc:	00 
    14fd:	49 83 c0 f6          	add    $0xfffffffffffffff6,%r8
    1501:	4c 89 41 04          	mov    %r8,0x4(%rcx)
    1505:	4c 8b 43 70          	mov    0x70(%rbx),%r8
    1509:	4c 89 41 2c          	mov    %r8,0x2c(%rcx)
    150d:	49 b8 00 00 00 00 ff 	movabs $0xffff00000000,%r8
    1514:	ff 00 00 
    1517:	4c 89 41 0c          	mov    %r8,0xc(%rcx)
    151b:	49 b9 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r9
    1522:	ff 7f ff 
    1525:	4c 89 4b 70          	mov    %r9,0x70(%rbx)
    1529:	bf ff ff ff ff       	mov    $0xffffffff,%edi
    152e:	48 89 79 1c          	mov    %rdi,0x1c(%rcx)
    1532:	4c 8b 14 24          	mov    (%rsp),%r10
    1536:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    153a:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
    1541:	00 80 3f 
    1544:	48 89 79 38          	mov    %rdi,0x38(%rcx)
    1548:	48 89 79 40          	mov    %rdi,0x40(%rcx)
    154c:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
    1551:	4c 89 6b 48          	mov    %r13,0x48(%rbx)
    1555:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    1559:	48 c7 41 24 01 00 00 	movq   $0x1,0x24(%rcx)
    1560:	00 
    1561:	c7 41 34 00 00 00 00 	movl   $0x0,0x34(%rcx)
    1568:	4c 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%r8
    156f:	4d 89 a8 a4 00 00 00 	mov    %r13,0xa4(%r8)
    1576:	4c 89 89 98 00 00 00 	mov    %r9,0x98(%rcx)
    157d:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1581:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1588:	00 
    1589:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    1590:	c7 81 bc 00 00 00 01 	movl   $0x1,0xbc(%rcx)
    1597:	00 00 00 
    159a:	48 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rax
    15a1:	ff 7f 7f 
    15a4:	48 89 41 78          	mov    %rax,0x78(%rcx)
    15a8:	4c 89 89 80 00 00 00 	mov    %r9,0x80(%rcx)
    15af:	4c 89 91 88 00 00 00 	mov    %r10,0x88(%rcx)
    15b6:	48 89 81 90 00 00 00 	mov    %rax,0x90(%rcx)
    15bd:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    15c1:	c5 fa 7f 41 58       	vmovdqu %xmm0,0x58(%rcx)
    15c6:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    15cd:	00 
    15ce:	4c 89 59 70          	mov    %r11,0x70(%rcx)
    15d2:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    15d9:	00 
    15da:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    15de:	4d 85 ff             	test   %r15,%r15
    15e1:	0f 84 80 18 00 00    	je     2e67 <f_8001161d0+0x2e67>
    15e7:	48 8b 86 c8 1e 00 00 	mov    0x1ec8(%rsi),%rax
    15ee:	48 8b 93 98 00 00 00 	mov    0x98(%rbx),%rdx
    15f5:	0f b6 72 08          	movzbl 0x8(%rdx),%esi
    15f9:	8b 78 08             	mov    0x8(%rax),%edi
    15fc:	48 8b 40 10          	mov    0x10(%rax),%rax
    1600:	31 d2                	xor    %edx,%edx
    1602:	45 31 c9             	xor    %r9d,%r9d
    1605:	45 31 d2             	xor    %r10d,%r10d
    1608:	41 89 fb             	mov    %edi,%r11d
    160b:	41 29 f3             	sub    %esi,%r11d
    160e:	41 0f 94 c1          	sete   %r9b
    1612:	48 0f 47 d6          	cmova  %rsi,%rdx
    1616:	41 0f 93 c2          	setae  %r10b
    161a:	c4 e2 20 f2 f7       	andn   %edi,%r11d,%esi
    161f:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    1626:	41 c1 e1 1e          	shl    $0x1e,%r9d
    162a:	41 c1 e2 1d          	shl    $0x1d,%r10d
    162e:	45 09 ca             	or     %r9d,%r10d
    1631:	45 09 da             	or     %r11d,%r10d
    1634:	c1 ee 03             	shr    $0x3,%esi
    1637:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    163d:	44 09 d6             	or     %r10d,%esi
    1640:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    1647:	48 c7 43 60 e0 3c 00 	movq   $0x3ce0,0x60(%rbx)
    164e:	00 
    164f:	48 89 53 58          	mov    %rdx,0x58(%rbx)
    1653:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
    165a:	48 8d 34 02          	lea    (%rdx,%rax,1),%rsi
    165e:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    1662:	8b b4 02 00 2e 00 00 	mov    0x2e00(%rdx,%rax,1),%esi
    1669:	4c 8d bb 00 02 00 00 	lea    0x200(%rbx),%r15
    1670:	48 89 b3 00 02 00 00 	mov    %rsi,0x200(%rbx)
    1677:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    167e:	00 00 00 00 
    1682:	8b b4 02 08 2e 00 00 	mov    0x2e08(%rdx,%rax,1),%esi
    1689:	48 8d bb 10 02 00 00 	lea    0x210(%rbx),%rdi
    1690:	48 89 3c 24          	mov    %rdi,(%rsp)
    1694:	48 89 b3 10 02 00 00 	mov    %rsi,0x210(%rbx)
    169b:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    16a2:	00 00 00 00 
    16a6:	8b b4 02 04 2e 00 00 	mov    0x2e04(%rdx,%rax,1),%esi
    16ad:	4c 8d a3 20 02 00 00 	lea    0x220(%rbx),%r12
    16b4:	48 89 b3 20 02 00 00 	mov    %rsi,0x220(%rbx)
    16bb:	48 c7 83 28 02 00 00 	movq   $0x0,0x228(%rbx)
    16c2:	00 00 00 00 
    16c6:	8b 84 02 0c 2e 00 00 	mov    0x2e0c(%rdx,%rax,1),%eax
    16cd:	48 89 83 30 02 00 00 	mov    %rax,0x230(%rbx)
    16d4:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    16db:	00 00 00 00 
    16df:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    16e6:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    16ed:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    16f1:	48 89 43 40          	mov    %rax,0x40(%rbx)
    16f5:	4d 89 a8 a4 00 00 00 	mov    %r13,0xa4(%r8)
    16fc:	48 89 df             	mov    %rbx,%rdi
    16ff:	be 01 00 00 00       	mov    $0x1,%esi
    1704:	31 d2                	xor    %edx,%edx
    1706:	b9 01 00 00 00       	mov    $0x1,%ecx
    170b:	45 31 c0             	xor    %r8d,%r8d
    170e:	c5 f8 77             	vzeroupper
    1711:	e8 00 00 00 00       	call   1716 <f_8001161d0+0x1716>
    1716:	48 89 df             	mov    %rbx,%rdi
    1719:	be 01 00 00 00       	mov    $0x1,%esi
    171e:	ba 01 00 00 00       	mov    $0x1,%edx
    1723:	b9 03 00 00 00       	mov    $0x3,%ecx
    1728:	41 b8 02 00 00 00    	mov    $0x2,%r8d
    172e:	e8 00 00 00 00       	call   1733 <f_8001161d0+0x1733>
    1733:	48 8b 03             	mov    (%rbx),%rax
    1736:	8b 88 08 03 00 00    	mov    0x308(%rax),%ecx
    173c:	48 89 8b 20 02 00 00 	mov    %rcx,0x220(%rbx)
    1743:	48 c7 83 28 02 00 00 	movq   $0x0,0x228(%rbx)
    174a:	00 00 00 00 
    174e:	8b 80 0c 03 00 00    	mov    0x30c(%rax),%eax
    1754:	48 89 83 30 02 00 00 	mov    %rax,0x230(%rbx)
    175b:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    1762:	00 00 00 00 
    1766:	48 89 df             	mov    %rbx,%rdi
    1769:	31 f6                	xor    %esi,%esi
    176b:	ba 01 00 00 00       	mov    $0x1,%edx
    1770:	b9 01 00 00 00       	mov    $0x1,%ecx
    1775:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    177b:	41 b9 03 00 00 00    	mov    $0x3,%r9d
    1781:	6a 00                	push   $0x0
    1783:	6a 00                	push   $0x0
    1785:	6a 01                	push   $0x1
    1787:	6a 00                	push   $0x0
    1789:	e8 00 00 00 00       	call   178e <f_8001161d0+0x178e>
    178e:	48 83 c4 20          	add    $0x20,%rsp
    1792:	48 89 df             	mov    %rbx,%rdi
    1795:	31 f6                	xor    %esi,%esi
    1797:	ba 01 00 00 00       	mov    $0x1,%edx
    179c:	b9 01 00 00 00       	mov    $0x1,%ecx
    17a1:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    17a7:	41 b9 03 00 00 00    	mov    $0x3,%r9d
    17ad:	6a 01                	push   $0x1
    17af:	6a 01                	push   $0x1
    17b1:	6a 01                	push   $0x1
    17b3:	6a 00                	push   $0x0
    17b5:	e8 00 00 00 00       	call   17ba <f_8001161d0+0x17ba>
    17ba:	48 83 c4 20          	add    $0x20,%rsp
    17be:	48 89 df             	mov    %rbx,%rdi
    17c1:	31 f6                	xor    %esi,%esi
    17c3:	31 d2                	xor    %edx,%edx
    17c5:	b9 01 00 00 00       	mov    $0x1,%ecx
    17ca:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    17d0:	45 31 c9             	xor    %r9d,%r9d
    17d3:	6a 00                	push   $0x0
    17d5:	6a 00                	push   $0x0
    17d7:	6a 01                	push   $0x1
    17d9:	6a 00                	push   $0x0
    17db:	e8 00 00 00 00       	call   17e0 <f_8001161d0+0x17e0>
    17e0:	48 83 c4 20          	add    $0x20,%rsp
    17e4:	48 89 df             	mov    %rbx,%rdi
    17e7:	be 02 00 00 00       	mov    $0x2,%esi
    17ec:	31 d2                	xor    %edx,%edx
    17ee:	b9 02 00 00 00       	mov    $0x2,%ecx
    17f3:	45 31 c0             	xor    %r8d,%r8d
    17f6:	e8 00 00 00 00       	call   17fb <f_8001161d0+0x17fb>
    17fb:	48 89 df             	mov    %rbx,%rdi
    17fe:	31 f6                	xor    %esi,%esi
    1800:	31 d2                	xor    %edx,%edx
    1802:	b9 01 00 00 00       	mov    $0x1,%ecx
    1807:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    180d:	45 31 c9             	xor    %r9d,%r9d
    1810:	6a 01                	push   $0x1
    1812:	6a 01                	push   $0x1
    1814:	6a 01                	push   $0x1
    1816:	6a 00                	push   $0x0
    1818:	e8 00 00 00 00       	call   181d <f_8001161d0+0x181d>
    181d:	48 83 c4 20          	add    $0x20,%rsp
    1821:	48 89 df             	mov    %rbx,%rdi
    1824:	be 02 00 00 00       	mov    $0x2,%esi
    1829:	ba 01 00 00 00       	mov    $0x1,%edx
    182e:	b9 03 00 00 00       	mov    $0x3,%ecx
    1833:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    1839:	e8 00 00 00 00       	call   183e <f_8001161d0+0x183e>
    183e:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    1842:	c5 f9 7f 83 20 02 00 	vmovdqa %xmm0,0x220(%rbx)
    1849:	00 
    184a:	48 89 df             	mov    %rbx,%rdi
    184d:	31 f6                	xor    %esi,%esi
    184f:	31 d2                	xor    %edx,%edx
    1851:	b9 01 00 00 00       	mov    $0x1,%ecx
    1856:	e8 00 00 00 00       	call   185b <f_8001161d0+0x185b>
    185b:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    1862:	48 89 df             	mov    %rbx,%rdi
    1865:	be 0d 00 00 00       	mov    $0xd,%esi
    186a:	ba 03 00 00 00       	mov    $0x3,%edx
    186f:	31 c9                	xor    %ecx,%ecx
    1871:	41 b8 02 00 00 00    	mov    $0x2,%r8d
    1877:	e8 00 00 00 00       	call   187c <f_8001161d0+0x187c>
    187c:	48 89 df             	mov    %rbx,%rdi
    187f:	be 0d 00 00 00       	mov    $0xd,%esi
    1884:	ba 04 00 00 00       	mov    $0x4,%edx
    1889:	b9 01 00 00 00       	mov    $0x1,%ecx
    188e:	41 b8 02 00 00 00    	mov    $0x2,%r8d
    1894:	e8 00 00 00 00       	call   1899 <f_8001161d0+0x1899>
    1899:	48 8b 83 10 01 00 00 	mov    0x110(%rbx),%rax
    18a0:	85 c0                	test   %eax,%eax
    18a2:	0f 98 c1             	sets   %cl
    18a5:	a9 00 00 00 10       	test   $0x10000000,%eax
    18aa:	0f 94 c2             	sete   %dl
    18ad:	30 ca                	xor    %cl,%dl
    18af:	4c 89 f9             	mov    %r15,%rcx
    18b2:	49 0f 45 cc          	cmovne %r12,%rcx
    18b6:	a9 00 00 00 40       	test   $0x40000000,%eax
    18bb:	49 0f 45 cf          	cmovne %r15,%rcx
    18bf:	8b 01                	mov    (%rcx),%eax
    18c1:	48 89 83 00 02 00 00 	mov    %rax,0x200(%rbx)
    18c8:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    18cf:	00 00 00 00 
    18d3:	48 89 df             	mov    %rbx,%rdi
    18d6:	be 01 00 00 00       	mov    $0x1,%esi
    18db:	31 d2                	xor    %edx,%edx
    18dd:	b9 01 00 00 00       	mov    $0x1,%ecx
    18e2:	e8 00 00 00 00       	call   18e7 <f_8001161d0+0x18e7>
    18e7:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    18ee:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    18f5:	8b 93 30 02 00 00    	mov    0x230(%rbx),%edx
    18fb:	85 c0                	test   %eax,%eax
    18fd:	40 0f 98 c6          	sets   %sil
    1901:	a9 00 00 00 10       	test   $0x10000000,%eax
    1906:	40 0f 94 c7          	sete   %dil
    190a:	40 30 f7             	xor    %sil,%dil
    190d:	8b b3 40 02 00 00    	mov    0x240(%rbx),%esi
    1913:	89 91 80 00 00 00    	mov    %edx,0x80(%rcx)
    1919:	89 b1 84 00 00 00    	mov    %esi,0x84(%rcx)
    191f:	48 8b 3c 24          	mov    (%rsp),%rdi
    1923:	4c 0f 44 e7          	cmove  %rdi,%r12
    1927:	89 91 98 00 00 00    	mov    %edx,0x98(%rcx)
    192d:	a9 00 00 00 40       	test   $0x40000000,%eax
    1932:	4c 0f 45 e7          	cmovne %rdi,%r12
    1936:	89 b1 9c 00 00 00    	mov    %esi,0x9c(%rcx)
    193c:	49 8b 04 24          	mov    (%r12),%rax
    1940:	89 c2                	mov    %eax,%edx
    1942:	48 89 93 10 02 00 00 	mov    %rdx,0x210(%rbx)
    1949:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    1950:	00 00 00 00 
    1954:	8b 93 00 02 00 00    	mov    0x200(%rbx),%edx
    195a:	89 51 78             	mov    %edx,0x78(%rcx)
    195d:	89 41 7c             	mov    %eax,0x7c(%rcx)
    1960:	89 91 90 00 00 00    	mov    %edx,0x90(%rcx)
    1966:	89 81 94 00 00 00    	mov    %eax,0x94(%rcx)
    196c:	48 8d 85 5e 18 51 fd 	lea    -0x2aee7a2(%rbp),%rax
    1973:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    197a:	48 89 df             	mov    %rbx,%rdi
    197d:	e8 00 00 00 00       	call   1982 <f_8001161d0+0x1982>
    1982:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    1989:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    1990:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    1997:	48 89 01             	mov    %rax,(%rcx)
    199a:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    19a1:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    19a5:	48 89 43 40          	mov    %rax,0x40(%rbx)
    19a9:	88 41 08             	mov    %al,0x8(%rcx)
    19ac:	e9 b6 14 00 00       	jmp    2e67 <f_8001161d0+0x2e67>
    19b1:	48 8b 7b 78          	mov    0x78(%rbx),%rdi
    19b5:	4c 89 c2             	mov    %r8,%rdx
    19b8:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
    19bf:	00 00 00 00 
    19c3:	48 89 90 20 ff ff ff 	mov    %rdx,-0xe0(%rax)
    19ca:	4c 8b bb a0 00 00 00 	mov    0xa0(%rbx),%r15
    19d1:	44 8b a3 a8 00 00 00 	mov    0xa8(%rbx),%r12d
    19d8:	45 8d 44 24 08       	lea    0x8(%r12),%r8d
    19dd:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    19e4:	c4 c2 43 f7 97 fc 0d 	shrx   %edi,0xdfc(%r15),%edx
    19eb:	00 00 
    19ed:	89 54 24 14          	mov    %edx,0x14(%rsp)
    19f1:	44 89 41 30          	mov    %r8d,0x30(%rcx)
    19f5:	48 8b 6b 68          	mov    0x68(%rbx),%rbp
    19f9:	89 69 34             	mov    %ebp,0x34(%rcx)
    19fc:	45 31 ed             	xor    %r13d,%r13d
    19ff:	41 f7 c3 00 02 00 00 	test   $0x200,%r11d
    1a06:	41 0f 94 c5          	sete   %r13b
    1a0a:	45 8b 87 20 0d 00 00 	mov    0xd20(%r15),%r8d
    1a11:	45 31 d2             	xor    %r10d,%r10d
    1a14:	41 39 f8             	cmp    %edi,%r8d
    1a17:	49 0f 46 fa          	cmovbe %r10,%rdi
    1a1b:	44 89 de             	mov    %r11d,%esi
    1a1e:	c1 e6 10             	shl    $0x10,%esi
    1a21:	81 e6 00 00 00 40    	and    $0x40000000,%esi
    1a27:	48 89 f2             	mov    %rsi,%rdx
    1a2a:	48 81 f2 00 00 00 40 	xor    $0x40000000,%rdx
    1a31:	41 89 f8             	mov    %edi,%r8d
    1a34:	4d 69 c0 b0 0b 00 00 	imul   $0xbb0,%r8,%r8
    1a3b:	45 31 c9             	xor    %r9d,%r9d
    1a3e:	85 f6                	test   %esi,%esi
    1a40:	41 0f 94 c1          	sete   %r9b
    1a44:	41 c1 e3 06          	shl    $0x6,%r11d
    1a48:	41 81 e3 00 00 04 00 	and    $0x40000,%r11d
    1a4f:	41 c1 e1 04          	shl    $0x4,%r9d
    1a53:	44 85 6c 24 14       	test   %r13d,0x14(%rsp)
    1a58:	be 01 00 00 00       	mov    $0x1,%esi
    1a5d:	c4 e2 51 f7 f6       	shlx   %ebp,%esi,%esi
    1a62:	48 c7 43 48 01 00 00 	movq   $0x1,0x48(%rbx)
    1a69:	00 
    1a6a:	48 89 73 08          	mov    %rsi,0x8(%rbx)
    1a6e:	4d 8b bf 28 0d 00 00 	mov    0xd28(%r15),%r15
    1a75:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    1a79:	48 89 7b 78          	mov    %rdi,0x78(%rbx)
    1a7d:	48 89 93 10 01 00 00 	mov    %rdx,0x110(%rbx)
    1a84:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1a8b:	00 
    1a8c:	4b 8d 14 07          	lea    (%r15,%r8,1),%rdx
    1a90:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    1a94:	ba 0f 00 00 00       	mov    $0xf,%edx
    1a99:	0f 45 d6             	cmovne %esi,%edx
    1a9c:	43 8d b4 19 00 00 20 	lea    0x200000(%r9,%r11,1),%esi
    1aa3:	00 
    1aa4:	48 c7 03 08 00 00 00 	movq   $0x8,(%rbx)
    1aab:	89 11                	mov    %edx,(%rcx)
    1aad:	c7 41 04 08 00 00 00 	movl   $0x8,0x4(%rcx)
    1ab4:	41 83 c4 04          	add    $0x4,%r12d
    1ab8:	44 89 61 08          	mov    %r12d,0x8(%rcx)
    1abc:	89 71 0c             	mov    %esi,0xc(%rcx)
    1abf:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    1ac6:	00 
    1ac7:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    1ace:	ff ff ff 
    1ad1:	48 8d 56 02          	lea    0x2(%rsi),%rdx
    1ad5:	48 89 51 18          	mov    %rdx,0x18(%rcx)
    1ad9:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    1ade:	4c 89 8b 90 00 00 00 	mov    %r9,0x90(%rbx)
    1ae5:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
    1aec:	00 00 00 
    1aef:	48 89 51 20          	mov    %rdx,0x20(%rcx)
    1af3:	48 89 71 28          	mov    %rsi,0x28(%rcx)
    1af7:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
    1afe:	00 80 3f 
    1b01:	48 89 51 38          	mov    %rdx,0x38(%rcx)
    1b05:	48 89 51 40          	mov    %rdx,0x40(%rcx)
    1b09:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    1b10:	00 00 00 
    1b13:	48 8d 95 b1 e5 0b 00 	lea    0xbe5b1(%rbp),%rdx
    1b1a:	48 89 93 80 00 00 00 	mov    %rdx,0x80(%rbx)
    1b21:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    1b28:	ff 7f ff 
    1b2b:	48 89 bb 88 00 00 00 	mov    %rdi,0x88(%rbx)
    1b32:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    1b39:	4c 89 8e a4 00 00 00 	mov    %r9,0xa4(%rsi)
    1b40:	48 8b 73 58          	mov    0x58(%rbx),%rsi
    1b44:	48 89 71 78          	mov    %rsi,0x78(%rcx)
    1b48:	48 89 b9 80 00 00 00 	mov    %rdi,0x80(%rcx)
    1b4f:	48 89 b9 98 00 00 00 	mov    %rdi,0x98(%rcx)
    1b56:	48 8b 3c 24          	mov    (%rsp),%rdi
    1b5a:	48 89 b9 88 00 00 00 	mov    %rdi,0x88(%rcx)
    1b61:	48 89 b1 90 00 00 00 	mov    %rsi,0x90(%rcx)
    1b68:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1b6c:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    1b73:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    1b7a:	00 00 00 
    1b7d:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    1b81:	c5 fa 7f 41 58       	vmovdqu %xmm0,0x58(%rcx)
    1b86:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    1b8d:	00 
    1b8e:	48 89 51 70          	mov    %rdx,0x70(%rcx)
    1b92:	43 8b 8c 07 d8 03 00 	mov    0x3d8(%r15,%r8,1),%ecx
    1b99:	00 
    1b9a:	43 8b 84 07 f8 03 00 	mov    0x3f8(%r15,%r8,1),%eax
    1ba1:	00 
    1ba2:	48 89 43 60          	mov    %rax,0x60(%rbx)
    1ba6:	89 c8                	mov    %ecx,%eax
    1ba8:	c1 f8 1f             	sar    $0x1f,%eax
    1bab:	c4 e2 78 f2 c1       	andn   %ecx,%eax,%eax
    1bb0:	48 89 43 68          	mov    %rax,0x68(%rbx)
    1bb4:	85 c9                	test   %ecx,%ecx
    1bb6:	41 0f 49 ca          	cmovns %r10d,%ecx
    1bba:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    1bbe:	48 83 ec 08          	sub    $0x8,%rsp
    1bc2:	48 89 df             	mov    %rbx,%rdi
    1bc5:	31 f6                	xor    %esi,%esi
    1bc7:	ba 01 00 00 00       	mov    $0x1,%edx
    1bcc:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1bd2:	45 31 c9             	xor    %r9d,%r9d
    1bd5:	6a 00                	push   $0x0
    1bd7:	c5 f8 77             	vzeroupper
    1bda:	e8 00 00 00 00       	call   1bdf <f_8001161d0+0x1bdf>
    1bdf:	48 83 c4 10          	add    $0x10,%rsp
    1be3:	8b 43 60             	mov    0x60(%rbx),%eax
    1be6:	89 c1                	mov    %eax,%ecx
    1be8:	c1 f9 1f             	sar    $0x1f,%ecx
    1beb:	c4 e2 70 f2 c8       	andn   %eax,%ecx,%ecx
    1bf0:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    1bf4:	48 83 ec 08          	sub    $0x8,%rsp
    1bf8:	48 89 df             	mov    %rbx,%rdi
    1bfb:	31 f6                	xor    %esi,%esi
    1bfd:	ba 02 00 00 00       	mov    $0x2,%edx
    1c02:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1c08:	45 31 c9             	xor    %r9d,%r9d
    1c0b:	6a 00                	push   $0x0
    1c0d:	e8 00 00 00 00       	call   1c12 <f_8001161d0+0x1c12>
    1c12:	48 83 c4 10          	add    $0x10,%rsp
    1c16:	8b 43 60             	mov    0x60(%rbx),%eax
    1c19:	8b 4b 68             	mov    0x68(%rbx),%ecx
    1c1c:	89 c2                	mov    %eax,%edx
    1c1e:	c1 fa 1f             	sar    $0x1f,%edx
    1c21:	21 c2                	and    %eax,%edx
    1c23:	48 89 53 58          	mov    %rdx,0x58(%rbx)
    1c27:	48 83 ec 08          	sub    $0x8,%rsp
    1c2b:	48 89 df             	mov    %rbx,%rdi
    1c2e:	31 f6                	xor    %esi,%esi
    1c30:	31 d2                	xor    %edx,%edx
    1c32:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1c38:	45 31 c9             	xor    %r9d,%r9d
    1c3b:	6a 00                	push   $0x0
    1c3d:	e8 00 00 00 00       	call   1c42 <f_8001161d0+0x1c42>
    1c42:	48 83 c4 10          	add    $0x10,%rsp
    1c46:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    1c4d:	8b 8b 00 02 00 00    	mov    0x200(%rbx),%ecx
    1c53:	8b 93 20 02 00 00    	mov    0x220(%rbx),%edx
    1c59:	89 88 80 00 00 00    	mov    %ecx,0x80(%rax)
    1c5f:	89 90 84 00 00 00    	mov    %edx,0x84(%rax)
    1c65:	8b 4b 58             	mov    0x58(%rbx),%ecx
    1c68:	48 83 ec 08          	sub    $0x8,%rsp
    1c6c:	48 89 df             	mov    %rbx,%rdi
    1c6f:	31 f6                	xor    %esi,%esi
    1c71:	ba 03 00 00 00       	mov    $0x3,%edx
    1c76:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1c7c:	45 31 c9             	xor    %r9d,%r9d
    1c7f:	6a 00                	push   $0x0
    1c81:	e8 00 00 00 00       	call   1c86 <f_8001161d0+0x1c86>
    1c86:	48 83 c4 10          	add    $0x10,%rsp
    1c8a:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    1c91:	8b 8b 10 02 00 00    	mov    0x210(%rbx),%ecx
    1c97:	8b 93 30 02 00 00    	mov    0x230(%rbx),%edx
    1c9d:	89 48 78             	mov    %ecx,0x78(%rax)
    1ca0:	89 50 7c             	mov    %edx,0x7c(%rax)
    1ca3:	48 8b 4b 50          	mov    0x50(%rbx),%rcx
    1ca7:	8b 91 d8 03 00 00    	mov    0x3d8(%rcx),%edx
    1cad:	8b 89 f8 03 00 00    	mov    0x3f8(%rcx),%ecx
    1cb3:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
    1cb7:	8b 4b 40             	mov    0x40(%rbx),%ecx
    1cba:	89 88 a0 00 00 00    	mov    %ecx,0xa0(%rax)
    1cc0:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
    1cc7:	48 8b 8b c0 00 00 00 	mov    0xc0(%rbx),%rcx
    1cce:	48 89 81 a4 00 00 00 	mov    %rax,0xa4(%rcx)
    1cd5:	89 d0                	mov    %edx,%eax
    1cd7:	c1 f8 1f             	sar    $0x1f,%eax
    1cda:	c4 e2 78 f2 c2       	andn   %edx,%eax,%eax
    1cdf:	85 d2                	test   %edx,%edx
    1ce1:	48 89 43 68          	mov    %rax,0x68(%rbx)
    1ce5:	b9 00 00 00 00       	mov    $0x0,%ecx
    1cea:	0f 48 ca             	cmovs  %edx,%ecx
    1ced:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    1cf1:	48 83 ec 08          	sub    $0x8,%rsp
    1cf5:	48 89 df             	mov    %rbx,%rdi
    1cf8:	31 f6                	xor    %esi,%esi
    1cfa:	ba 01 00 00 00       	mov    $0x1,%edx
    1cff:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1d05:	45 31 c9             	xor    %r9d,%r9d
    1d08:	6a 00                	push   $0x0
    1d0a:	e8 00 00 00 00       	call   1d0f <f_8001161d0+0x1d0f>
    1d0f:	48 83 c4 10          	add    $0x10,%rsp
    1d13:	8b 43 60             	mov    0x60(%rbx),%eax
    1d16:	8b 4b 68             	mov    0x68(%rbx),%ecx
    1d19:	89 c2                	mov    %eax,%edx
    1d1b:	c1 fa 1f             	sar    $0x1f,%edx
    1d1e:	c4 e2 68 f2 c0       	andn   %eax,%edx,%eax
    1d23:	48 89 43 58          	mov    %rax,0x58(%rbx)
    1d27:	48 83 ec 08          	sub    $0x8,%rsp
    1d2b:	48 89 df             	mov    %rbx,%rdi
    1d2e:	31 f6                	xor    %esi,%esi
    1d30:	31 d2                	xor    %edx,%edx
    1d32:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1d38:	45 31 c9             	xor    %r9d,%r9d
    1d3b:	6a 00                	push   $0x0
    1d3d:	e8 00 00 00 00       	call   1d42 <f_8001161d0+0x1d42>
    1d42:	48 83 c4 10          	add    $0x10,%rsp
    1d46:	8b 4b 58             	mov    0x58(%rbx),%ecx
    1d49:	48 83 ec 08          	sub    $0x8,%rsp
    1d4d:	48 89 df             	mov    %rbx,%rdi
    1d50:	31 f6                	xor    %esi,%esi
    1d52:	ba 02 00 00 00       	mov    $0x2,%edx
    1d57:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1d5d:	45 31 c9             	xor    %r9d,%r9d
    1d60:	6a 00                	push   $0x0
    1d62:	e8 00 00 00 00       	call   1d67 <f_8001161d0+0x1d67>
    1d67:	48 83 c4 10          	add    $0x10,%rsp
    1d6b:	8b 43 60             	mov    0x60(%rbx),%eax
    1d6e:	89 c1                	mov    %eax,%ecx
    1d70:	c1 f9 1f             	sar    $0x1f,%ecx
    1d73:	21 c1                	and    %eax,%ecx
    1d75:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    1d79:	48 83 ec 08          	sub    $0x8,%rsp
    1d7d:	48 89 df             	mov    %rbx,%rdi
    1d80:	31 f6                	xor    %esi,%esi
    1d82:	ba 03 00 00 00       	mov    $0x3,%edx
    1d87:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1d8d:	45 31 c9             	xor    %r9d,%r9d
    1d90:	6a 00                	push   $0x0
    1d92:	e8 00 00 00 00       	call   1d97 <f_8001161d0+0x1d97>
    1d97:	48 83 c4 10          	add    $0x10,%rsp
    1d9b:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    1da2:	8b 8b 00 02 00 00    	mov    0x200(%rbx),%ecx
    1da8:	8b 93 20 02 00 00    	mov    0x220(%rbx),%edx
    1dae:	89 88 98 00 00 00    	mov    %ecx,0x98(%rax)
    1db4:	89 90 9c 00 00 00    	mov    %edx,0x9c(%rax)
    1dba:	8b 8b 10 02 00 00    	mov    0x210(%rbx),%ecx
    1dc0:	8b 93 30 02 00 00    	mov    0x230(%rbx),%edx
    1dc6:	89 88 90 00 00 00    	mov    %ecx,0x90(%rax)
    1dcc:	89 90 94 00 00 00    	mov    %edx,0x94(%rax)
    1dd2:	48 8b 4b 50          	mov    0x50(%rbx),%rcx
    1dd6:	31 d2                	xor    %edx,%edx
    1dd8:	80 b9 58 04 00 00 00 	cmpb   $0x0,0x458(%rcx)
    1ddf:	48 c7 43 50 5b 00 00 	movq   $0x5b,0x50(%rbx)
    1de6:	00 
    1de7:	48 c7 80 b0 00 00 00 	movq   $0x0,0xb0(%rax)
    1dee:	00 00 00 00 
    1df2:	8b 4b 48             	mov    0x48(%rbx),%ecx
    1df5:	89 88 bc 00 00 00    	mov    %ecx,0xbc(%rax)
    1dfb:	0f 94 c2             	sete   %dl
    1dfe:	48 8d 0c 55 59 00 00 	lea    0x59(,%rdx,2),%rcx
    1e05:	00 
    1e06:	c1 e2 1e             	shl    $0x1e,%edx
    1e09:	48 81 ca 00 00 00 20 	or     $0x20000000,%rdx
    1e10:	48 89 93 10 01 00 00 	mov    %rdx,0x110(%rbx)
    1e17:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    1e1b:	e9 41 10 00 00       	jmp    2e61 <f_8001161d0+0x2e61>
    1e20:	4c 89 bb 08 01 00 00 	mov    %r15,0x108(%rbx)
    1e27:	48 89 df             	mov    %rbx,%rdi
    1e2a:	48 83 c4 18          	add    $0x18,%rsp
    1e2e:	5b                   	pop    %rbx
    1e2f:	41 5c                	pop    %r12
    1e31:	41 5d                	pop    %r13
    1e33:	41 5e                	pop    %r14
    1e35:	41 5f                	pop    %r15
    1e37:	5d                   	pop    %rbp
    1e38:	c5 f8 77             	vzeroupper
    1e3b:	e9 00 00 00 00       	jmp    1e40 <f_8001161d0+0x1e40>
    1e40:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    1e47:	00 
    1e48:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1e4f:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    1e56:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    1e5a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    1e5e:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1e63:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    1e6a:	48 89 03             	mov    %rax,(%rbx)
    1e6d:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
    1e74:	00 
    1e75:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    1e7c:	00 00 00 
    1e7f:	48 8d 85 ae 18 51 fd 	lea    -0x2aee752(%rbp),%rax
    1e86:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    1e8d:	48 89 df             	mov    %rbx,%rdi
    1e90:	c5 f8 77             	vzeroupper
    1e93:	e8 00 00 00 00       	call   1e98 <f_8001161d0+0x1e98>
    1e98:	e9 ca 0f 00 00       	jmp    2e67 <f_8001161d0+0x2e67>
    1e9d:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    1ea4:	00 
    1ea5:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1eac:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    1eb3:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    1eb7:	48 89 43 10          	mov    %rax,0x10(%rbx)
    1ebb:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1ec0:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    1ec7:	48 89 03             	mov    %rax,(%rbx)
    1eca:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    1ed1:	00 00 00 
    1ed4:	48 8d 85 ce 18 51 fd 	lea    -0x2aee732(%rbp),%rax
    1edb:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    1ee2:	48 89 df             	mov    %rbx,%rdi
    1ee5:	c5 f8 77             	vzeroupper
    1ee8:	e8 00 00 00 00       	call   1eed <f_8001161d0+0x1eed>
    1eed:	e9 75 0f 00 00       	jmp    2e67 <f_8001161d0+0x2e67>
    1ef2:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
    1ef9:	48 8b 89 c8 1e 00 00 	mov    0x1ec8(%rcx),%rcx
    1f00:	48 89 4b 70          	mov    %rcx,0x70(%rbx)
    1f04:	49 b9 00 00 00 00 01 	movabs $0x100000000,%r9
    1f0b:	00 00 00 
    1f0e:	4c 89 0b             	mov    %r9,(%rbx)
    1f11:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1f15:	4c 8b 83 00 01 00 00 	mov    0x100(%rbx),%r8
    1f1c:	49 c7 00 04 00 00 00 	movq   $0x4,(%r8)
    1f23:	48 be 00 00 00 00 00 	movabs $0x40000000000000,%rsi
    1f2a:	00 40 00 
    1f2d:	48 ff c6             	inc    %rsi
    1f30:	49 89 70 08          	mov    %rsi,0x8(%r8)
    1f34:	4d 89 48 20          	mov    %r9,0x20(%r8)
    1f38:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    1f3f:	ff ff ff 
    1f42:	49 89 ff             	mov    %rdi,%r15
    1f45:	48 89 f7             	mov    %rsi,%rdi
    1f48:	49 89 70 28          	mov    %rsi,0x28(%r8)
    1f4c:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    1f53:	00 00 00 
    1f56:	4c 8d 8d 25 74 0d 00 	lea    0xd7425(%rbp),%r9
    1f5d:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    1f61:	49 bb ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r11
    1f68:	ff 7f ff 
    1f6b:	4d 89 98 80 00 00 00 	mov    %r11,0x80(%r8)
    1f72:	48 8b 34 24          	mov    (%rsp),%rsi
    1f76:	49 89 b0 88 00 00 00 	mov    %rsi,0x88(%r8)
    1f7d:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    1f84:	4c 89 be a4 00 00 00 	mov    %r15,0xa4(%rsi)
    1f8b:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
    1f92:	ff 7f 7f 
    1f95:	4d 89 90 90 00 00 00 	mov    %r10,0x90(%r8)
    1f9c:	4d 89 98 98 00 00 00 	mov    %r11,0x98(%r8)
    1fa3:	c5 fd 6f 05 00 00 00 	vmovdqa 0x0(%rip),%ymm0        # 1fab <f_8001161d0+0x1fab>
    1faa:	00 
    1fab:	c5 fe 7f 43 78       	vmovdqu %ymm0,0x78(%rbx)
    1fb0:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1fb7:	00 
    1fb8:	45 89 b0 a0 00 00 00 	mov    %r14d,0xa0(%r8)
    1fbf:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1fc6:	0f b6 70 08          	movzbl 0x8(%rax),%esi
    1fca:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    1fce:	41 c7 80 bc 00 00 00 	movl   $0x3,0xbc(%r8)
    1fd5:	03 00 00 00 
    1fd9:	49 c7 40 10 ff ff 00 	movq   $0xffff,0x10(%r8)
    1fe0:	00 
    1fe1:	48 8d 47 17          	lea    0x17(%rdi),%rax
    1fe5:	49 89 40 18          	mov    %rax,0x18(%r8)
    1fe9:	49 c7 40 68 00 00 00 	movq   $0x0,0x68(%r8)
    1ff0:	00 
    1ff1:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    1ff6:	49 89 40 30          	mov    %rax,0x30(%r8)
    1ffa:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    2001:	00 80 3f 
    2004:	49 89 40 38          	mov    %rax,0x38(%r8)
    2008:	49 89 40 40          	mov    %rax,0x40(%r8)
    200c:	49 c7 40 48 00 00 00 	movq   $0x0,0x48(%r8)
    2013:	00 
    2014:	49 89 50 50          	mov    %rdx,0x50(%r8)
    2018:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    201c:	c4 c1 7a 7f 40 58    	vmovdqu %xmm0,0x58(%r8)
    2022:	4d 89 48 70          	mov    %r9,0x70(%r8)
    2026:	4d 89 50 78          	mov    %r10,0x78(%r8)
    202a:	48 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rax
    2031:	45 31 c0             	xor    %r8d,%r8d
    2034:	39 71 08             	cmp    %esi,0x8(%rcx)
    2037:	49 0f 46 c0          	cmovbe %r8,%rax
    203b:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    203f:	48 8b 94 08 68 33 00 	mov    0x3368(%rax,%rcx,1),%rdx
    2046:	00 
    2047:	48 89 53 60          	mov    %rdx,0x60(%rbx)
    204b:	48 8b 84 08 60 33 00 	mov    0x3360(%rax,%rcx,1),%rax
    2052:	00 
    2053:	48 8b 4b 48          	mov    0x48(%rbx),%rcx
    2057:	48 89 01             	mov    %rax,(%rcx)
    205a:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    205e:	48 8b 43 70          	mov    0x70(%rbx),%rax
    2062:	44 8b 48 08          	mov    0x8(%rax),%r9d
    2066:	48 8b 48 10          	mov    0x10(%rax),%rcx
    206a:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    206e:	8b 53 40             	mov    0x40(%rbx),%edx
    2071:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
    2078:	45 31 d2             	xor    %r10d,%r10d
    207b:	31 ff                	xor    %edi,%edi
    207d:	45 89 cb             	mov    %r9d,%r11d
    2080:	41 29 f3             	sub    %esi,%r11d
    2083:	49 0f 46 d0          	cmovbe %r8,%rdx
    2087:	41 0f 94 c2          	sete   %r10b
    208b:	40 0f 93 c7          	setae  %dil
    208f:	41 c1 e2 1e          	shl    $0x1e,%r10d
    2093:	c1 e7 1d             	shl    $0x1d,%edi
    2096:	44 09 d7             	or     %r10d,%edi
    2099:	c4 c2 20 f2 f1       	andn   %r9d,%r11d,%esi
    209e:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    20a5:	44 09 df             	or     %r11d,%edi
    20a8:	c1 ee 03             	shr    $0x3,%esi
    20ab:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    20b1:	09 fe                	or     %edi,%esi
    20b3:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    20ba:	48 8b b4 0a e8 35 00 	mov    0x35e8(%rdx,%rcx,1),%rsi
    20c1:	00 
    20c2:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    20c6:	48 8b bc 0a e0 35 00 	mov    0x35e0(%rdx,%rcx,1),%rdi
    20cd:	00 
    20ce:	48 89 7b 50          	mov    %rdi,0x50(%rbx)
    20d2:	4c 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%r8
    20d9:	49 89 38             	mov    %rdi,(%r8)
    20dc:	49 89 70 08          	mov    %rsi,0x8(%r8)
    20e0:	8b b4 0a f8 35 00 00 	mov    0x35f8(%rdx,%rcx,1),%esi
    20e7:	48 8b 8c 0a f0 35 00 	mov    0x35f0(%rdx,%rcx,1),%rcx
    20ee:	00 
    20ef:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
    20f6:	48 89 0a             	mov    %rcx,(%rdx)
    20f9:	89 72 08             	mov    %esi,0x8(%rdx)
    20fc:	8b 48 44             	mov    0x44(%rax),%ecx
    20ff:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    2103:	48 83 c0 3c          	add    $0x3c,%rax
    2107:	8b 00                	mov    (%rax),%eax
    2109:	48 89 43 48          	mov    %rax,0x48(%rbx)
    210d:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    2114:	88 8a b0 00 00 00    	mov    %cl,0xb0(%rdx)
    211a:	c7 82 b4 00 00 00 00 	movl   $0x0,0xb4(%rdx)
    2121:	00 00 00 
    2124:	48 8b 8b c0 00 00 00 	mov    0xc0(%rbx),%rcx
    212b:	c7 81 b1 00 00 00 00 	movl   $0x0,0xb1(%rcx)
    2132:	00 00 00 
    2135:	88 82 b8 00 00 00    	mov    %al,0xb8(%rdx)
    213b:	e9 27 0d 00 00       	jmp    2e67 <f_8001161d0+0x2e67>
    2140:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    2147:	00 
    2148:	48 c7 80 d0 fe ff ff 	movq   $0x100,-0x130(%rax)
    214f:	00 01 00 00 
    2153:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    215a:	00 40 00 
    215d:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    2164:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    216b:	ff ff 00 00 
    216f:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    2176:	ff ff ff 
    2179:	48 8d 4f 13          	lea    0x13(%rdi),%rcx
    217d:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    2184:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    218b:	00 00 00 
    218e:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
    2192:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    2199:	48 89 b8 f8 fe ff ff 	mov    %rdi,-0x108(%rax)
    21a0:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    21a7:	00 80 3f 
    21aa:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    21ae:	48 8d 88 00 ff ff ff 	lea    -0x100(%rax),%rcx
    21b5:	4c 8d 98 08 ff ff ff 	lea    -0xf8(%rax),%r11
    21bc:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    21c3:	00 00 00 
    21c6:	4c 8d 87 a1 6f fe ff 	lea    -0x1905f(%rdi),%r8
    21cd:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    21d3:	e9 c4 0a 00 00       	jmp    2c9c <f_8001161d0+0x2c9c>
    21d8:	48 c7 43 68 00 10 00 	movq   $0x1000,0x68(%rbx)
    21df:	00 
    21e0:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    21e7:	00 
    21e8:	48 c7 80 d0 fe ff ff 	movq   $0x1000,-0x130(%rax)
    21ef:	00 10 00 00 
    21f3:	48 c7 80 d8 fe ff ff 	movq   $0x1,-0x128(%rax)
    21fa:	01 00 00 00 
    21fe:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    2205:	ff ff 00 00 
    2209:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    2210:	ff ff ff 
    2213:	48 8d 4e 0c          	lea    0xc(%rsi),%rcx
    2217:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    221e:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2225:	00 00 00 
    2228:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    222f:	48 89 b0 f8 fe ff ff 	mov    %rsi,-0x108(%rax)
    2236:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    223d:	00 80 3f 
    2240:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    2244:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
    2249:	48 89 88 00 ff ff ff 	mov    %rcx,-0x100(%rax)
    2250:	4c 89 b8 08 ff ff ff 	mov    %r15,-0xf8(%rax)
    2257:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    225e:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    2265:	00 00 00 
    2268:	4c 8d 9d b2 a4 03 00 	lea    0x3a4b2(%rbp),%r11
    226f:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    2276:	4c 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%r8
    227d:	4d 8b 88 d0 2f 00 00 	mov    0x2fd0(%r8),%r9
    2284:	4c 89 4b 40          	mov    %r9,0x40(%rbx)
    2288:	4c 8b 14 24          	mov    (%rsp),%r10
    228c:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    2290:	4c 89 59 70          	mov    %r11,0x70(%rcx)
    2294:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
    229b:	ff 7f 7f 
    229e:	4c 89 59 78          	mov    %r11,0x78(%rcx)
    22a2:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    22a9:	ff 7f ff 
    22ac:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    22b0:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    22b4:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    22bb:	00 
    22bc:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    22c3:	00 00 00 
    22c6:	48 89 b9 80 00 00 00 	mov    %rdi,0x80(%rcx)
    22cd:	4c 89 91 88 00 00 00 	mov    %r10,0x88(%rcx)
    22d4:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    22db:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    22e0:	4c 89 96 a4 00 00 00 	mov    %r10,0xa4(%rsi)
    22e7:	4c 89 79 40          	mov    %r15,0x40(%rcx)
    22eb:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    22f2:	00 
    22f3:	4c 89 99 90 00 00 00 	mov    %r11,0x90(%rcx)
    22fa:	48 89 b9 98 00 00 00 	mov    %rdi,0x98(%rcx)
    2301:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    2308:	00 
    2309:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    230d:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    2311:	c5 fa 7f 41 58       	vmovdqu %xmm0,0x58(%rcx)
    2316:	4d 85 c9             	test   %r9,%r9
    2319:	0f 84 f0 0f 00 00    	je     330f <f_8001161d0+0x330f>
    231f:	48 8b 93 98 00 00 00 	mov    0x98(%rbx),%rdx
    2326:	0f b6 72 08          	movzbl 0x8(%rdx),%esi
    232a:	48 c7 43 68 e0 3c 00 	movq   $0x3ce0,0x68(%rbx)
    2331:	00 
    2332:	48 69 fe 60 0f 00 00 	imul   $0xf60,%rsi,%rdi
    2339:	31 d2                	xor    %edx,%edx
    233b:	41 39 71 10          	cmp    %esi,0x10(%r9)
    233f:	4d 8b 49 18          	mov    0x18(%r9),%r9
    2343:	48 0f 46 fa          	cmovbe %rdx,%rdi
    2347:	42 8b bc 0f 9c 02 00 	mov    0x29c(%rdi,%r9,1),%edi
    234e:	00 
    234f:	49 b9 00 00 00 00 01 	movabs $0x100000000,%r9
    2356:	00 00 00 
    2359:	4c 09 cf             	or     %r9,%rdi
    235c:	48 89 79 1c          	mov    %rdi,0x1c(%rcx)
    2360:	c7 81 bc 00 00 00 02 	movl   $0x2,0xbc(%rcx)
    2367:	00 00 00 
    236a:	49 8b 88 c8 1e 00 00 	mov    0x1ec8(%r8),%rcx
    2371:	48 69 fe e0 3c 00 00 	imul   $0x3ce0,%rsi,%rdi
    2378:	39 71 08             	cmp    %esi,0x8(%rcx)
    237b:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    2381:	4c 0f 47 c7          	cmova  %rdi,%r8
    2385:	4c 8b 49 10          	mov    0x10(%rcx),%r9
    2389:	4f 8b 94 01 b8 30 00 	mov    0x30b8(%r9,%r8,1),%r10
    2390:	00 
    2391:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    2395:	4f 8b 84 01 b0 30 00 	mov    0x30b0(%r9,%r8,1),%r8
    239c:	00 
    239d:	4c 89 43 58          	mov    %r8,0x58(%rbx)
    23a1:	4c 89 80 48 ff ff ff 	mov    %r8,-0xb8(%rax)
    23a8:	4c 89 90 50 ff ff ff 	mov    %r10,-0xb0(%rax)
    23af:	44 8b 41 08          	mov    0x8(%rcx),%r8d
    23b3:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    23b7:	45 31 c9             	xor    %r9d,%r9d
    23ba:	45 31 d2             	xor    %r10d,%r10d
    23bd:	45 89 c3             	mov    %r8d,%r11d
    23c0:	41 29 f3             	sub    %esi,%r11d
    23c3:	48 0f 47 d7          	cmova  %rdi,%rdx
    23c7:	41 0f 94 c1          	sete   %r9b
    23cb:	41 0f 93 c2          	setae  %r10b
    23cf:	c4 c2 20 f2 f0       	andn   %r8d,%r11d,%esi
    23d4:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    23db:	41 c1 e1 1e          	shl    $0x1e,%r9d
    23df:	41 c1 e2 1d          	shl    $0x1d,%r10d
    23e3:	45 09 ca             	or     %r9d,%r10d
    23e6:	45 09 da             	or     %r11d,%r10d
    23e9:	c1 ee 03             	shr    $0x3,%esi
    23ec:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    23f2:	44 09 d6             	or     %r10d,%esi
    23f5:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    23fc:	48 8d 34 0a          	lea    (%rdx,%rcx,1),%rsi
    2400:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    2404:	48 8b b4 0a 30 33 00 	mov    0x3330(%rdx,%rcx,1),%rsi
    240b:	00 
    240c:	48 8b bc 0a 38 33 00 	mov    0x3338(%rdx,%rcx,1),%rdi
    2413:	00 
    2414:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    2418:	48 89 b0 60 ff ff ff 	mov    %rsi,-0xa0(%rax)
    241f:	48 89 b8 68 ff ff ff 	mov    %rdi,-0x98(%rax)
    2426:	8b b4 0a 48 33 00 00 	mov    0x3348(%rdx,%rcx,1),%esi
    242d:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    2431:	48 8b 8c 0a 40 33 00 	mov    0x3340(%rdx,%rcx,1),%rcx
    2438:	00 
    2439:	48 89 88 70 ff ff ff 	mov    %rcx,-0x90(%rax)
    2440:	89 b0 78 ff ff ff    	mov    %esi,-0x88(%rax)
    2446:	e9 1c 0a 00 00       	jmp    2e67 <f_8001161d0+0x2e67>
    244b:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    2452:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
    2459:	48 8b b6 c8 1e 00 00 	mov    0x1ec8(%rsi),%rsi
    2460:	48 89 73 08          	mov    %rsi,0x8(%rbx)
    2464:	4c 8b 14 24          	mov    (%rsp),%r10
    2468:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    246c:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
    2470:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
    2474:	44 8b 46 08          	mov    0x8(%rsi),%r8d
    2478:	4c 69 c9 e0 3c 00 00 	imul   $0x3ce0,%rcx,%r9
    247f:	45 31 db             	xor    %r11d,%r11d
    2482:	41 39 c8             	cmp    %ecx,%r8d
    2485:	4d 0f 47 d9          	cmova  %r9,%r11
    2489:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    248d:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
    2494:	00 
    2495:	49 8b 8c 0b 40 3c 00 	mov    0x3c40(%r11,%rcx,1),%rcx
    249c:	00 
    249d:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
    24a4:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    24ab:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    24b2:	4c 89 91 88 00 00 00 	mov    %r10,0x88(%rcx)
    24b9:	48 be ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rsi
    24c0:	ff 7f 7f 
    24c3:	48 89 b1 90 00 00 00 	mov    %rsi,0x90(%rcx)
    24ca:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    24d1:	00 
    24d2:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    24d6:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    24dd:	00 00 00 
    24e0:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    24e7:	00 
    24e8:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    24ec:	48 c7 43 40 06 00 00 	movq   $0x6,0x40(%rbx)
    24f3:	00 
    24f4:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    24f8:	c5 fa 7f 41 58       	vmovdqu %xmm0,0x58(%rcx)
    24fd:	48 c7 41 30 06 00 00 	movq   $0x6,0x30(%rcx)
    2504:	00 
    2505:	48 b8 10 00 00 00 03 	movabs $0x300000010,%rax
    250c:	00 00 00 
    250f:	48 83 c0 10          	add    $0x10,%rax
    2513:	48 89 01             	mov    %rax,(%rcx)
    2516:	48 b8 00 00 00 00 01 	movabs $0x40000100000000,%rax
    251d:	00 40 00 
    2520:	48 89 41 08          	mov    %rax,0x8(%rcx)
    2524:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    252b:	00 
    252c:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    2533:	ff ff ff 
    2536:	48 8d 42 09          	lea    0x9(%rdx),%rax
    253a:	48 89 41 18          	mov    %rax,0x18(%rcx)
    253e:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2545:	00 00 00 
    2548:	48 89 41 20          	mov    %rax,0x20(%rcx)
    254c:	48 89 51 28          	mov    %rdx,0x28(%rcx)
    2550:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2557:	48 89 b8 a4 00 00 00 	mov    %rdi,0xa4(%rax)
    255e:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    2565:	00 80 3f 
    2568:	48 89 41 38          	mov    %rax,0x38(%rcx)
    256c:	48 89 41 40          	mov    %rax,0x40(%rcx)
    2570:	49 be ca 5d c0 02 08 	movabs $0x802c05dca,%r14
    2577:	00 00 00 
    257a:	49 8d 86 af c7 07 00 	lea    0x7c7af(%r14),%rax
    2581:	48 89 43 78          	mov    %rax,0x78(%rbx)
    2585:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
    258c:	ff 7f ff 
    258f:	48 89 b3 80 00 00 00 	mov    %rsi,0x80(%rbx)
    2596:	48 89 b1 98 00 00 00 	mov    %rsi,0x98(%rcx)
    259d:	48 8b 53 58          	mov    0x58(%rbx),%rdx
    25a1:	48 89 51 78          	mov    %rdx,0x78(%rcx)
    25a5:	48 89 b1 80 00 00 00 	mov    %rsi,0x80(%rcx)
    25ac:	48 8d 53 70          	lea    0x70(%rbx),%rdx
    25b0:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    25b7:	00 
    25b8:	48 89 41 70          	mov    %rax,0x70(%rcx)
    25bc:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
    25c0:	8b 71 08             	mov    0x8(%rcx),%esi
    25c3:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
    25c7:	41 89 f8             	mov    %edi,%r8d
    25ca:	31 c0                	xor    %eax,%eax
    25cc:	39 fe                	cmp    %edi,%esi
    25ce:	be 00 00 00 00       	mov    $0x0,%esi
    25d3:	49 0f 47 f0          	cmova  %r8,%rsi
    25d7:	4c 8b 4b 48          	mov    0x48(%rbx),%r9
    25db:	4c 8b 51 10          	mov    0x10(%rcx),%r10
    25df:	8b 12                	mov    (%rdx),%edx
    25e1:	48 0f af f2          	imul   %rdx,%rsi
    25e5:	c4 a1 7a 6f 84 16 00 	vmovdqu 0x2e00(%rsi,%r10,1),%xmm0
    25ec:	2e 00 00 
    25ef:	c4 c1 7a 7f 01       	vmovdqu %xmm0,(%r9)
    25f4:	8b 71 08             	mov    0x8(%rcx),%esi
    25f7:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    25fb:	45 31 c9             	xor    %r9d,%r9d
    25fe:	41 89 f2             	mov    %esi,%r10d
    2601:	41 31 fa             	xor    %edi,%r10d
    2604:	41 0f 94 c1          	sete   %r9b
    2608:	45 31 db             	xor    %r11d,%r11d
    260b:	89 f5                	mov    %esi,%ebp
    260d:	29 fd                	sub    %edi,%ebp
    260f:	41 0f 93 c3          	setae  %r11b
    2613:	49 0f 47 c0          	cmova  %r8,%rax
    2617:	31 ee                	xor    %ebp,%esi
    2619:	44 21 d6             	and    %r10d,%esi
    261c:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    2622:	41 c1 e1 1e          	shl    $0x1e,%r9d
    2626:	41 c1 e3 1d          	shl    $0x1d,%r11d
    262a:	45 09 cb             	or     %r9d,%r11d
    262d:	41 09 eb             	or     %ebp,%r11d
    2630:	c1 ee 03             	shr    $0x3,%esi
    2633:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    2639:	44 09 de             	or     %r11d,%esi
    263c:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    2643:	48 0f af c2          	imul   %rdx,%rax
    2647:	48 8b 94 08 80 30 00 	mov    0x3080(%rax,%rcx,1),%rdx
    264e:	00 
    264f:	48 8b b3 b0 00 00 00 	mov    0xb0(%rbx),%rsi
    2656:	48 8b bb d0 00 00 00 	mov    0xd0(%rbx),%rdi
    265d:	48 89 33             	mov    %rsi,(%rbx)
    2660:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
    2667:	00 
    2668:	48 8b b4 08 88 30 00 	mov    0x3088(%rax,%rcx,1),%rsi
    266f:	00 
    2670:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    2674:	48 89 17             	mov    %rdx,(%rdi)
    2677:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    267b:	48 8b 94 08 90 30 00 	mov    0x3090(%rax,%rcx,1),%rdx
    2682:	00 
    2683:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    2687:	8b 84 08 98 30 00 00 	mov    0x3098(%rax,%rcx,1),%eax
    268e:	48 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%rcx
    2695:	89 41 08             	mov    %eax,0x8(%rcx)
    2698:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    269f:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    26a3:	48 89 43 40          	mov    %rax,0x40(%rbx)
    26a7:	48 89 11             	mov    %rdx,(%rcx)
    26aa:	49 8d 86 ea 0b 51 fd 	lea    -0x2aef416(%r14),%rax
    26b1:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    26b8:	48 89 df             	mov    %rbx,%rdi
    26bb:	c5 f8 77             	vzeroupper
    26be:	e8 00 00 00 00       	call   26c3 <f_8001161d0+0x26c3>
    26c3:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    26ca:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    26d1:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    26d8:	48 89 01             	mov    %rax,(%rcx)
    26db:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
    26e2:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
    26e9:	48 8b b0 04 16 00 00 	mov    0x1604(%rax),%rsi
    26f0:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
    26f4:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    26f8:	88 51 08             	mov    %dl,0x8(%rcx)
    26fb:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    2702:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
    2706:	8b 80 0c 16 00 00    	mov    0x160c(%rax),%eax
    270c:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2710:	4c 89 f5             	mov    %r14,%rbp
    2713:	48 c7 43 48 02 00 00 	movq   $0x2,0x48(%rbx)
    271a:	00 
    271b:	89 41 24             	mov    %eax,0x24(%rcx)
    271e:	c7 81 bc 00 00 00 02 	movl   $0x2,0xbc(%rcx)
    2725:	00 00 00 
    2728:	e9 3a 07 00 00       	jmp    2e67 <f_8001161d0+0x2e67>
    272d:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    2734:	00 
    2735:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
    273c:	49 c7 03 80 00 00 00 	movq   $0x80,(%r11)
    2743:	48 b9 00 00 00 00 00 	movabs $0x60000000000000,%rcx
    274a:	00 60 00 
    274d:	49 89 4b 08          	mov    %rcx,0x8(%r11)
    2751:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
    2758:	00 
    2759:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    2760:	ff ff ff 
    2763:	48 8d 4f 12          	lea    0x12(%rdi),%rcx
    2767:	49 89 4b 18          	mov    %rcx,0x18(%r11)
    276b:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2772:	00 00 00 
    2775:	49 89 4b 20          	mov    %rcx,0x20(%r11)
    2779:	49 89 7b 28          	mov    %rdi,0x28(%r11)
    277d:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    2783:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    2787:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    278e:	00 80 3f 
    2791:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    2795:	49 8d 4b 30          	lea    0x30(%r11),%rcx
    2799:	49 83 c3 38          	add    $0x38,%r11
    279d:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    27a4:	00 00 00 
    27a7:	4c 8d 87 6d 4f 0a 00 	lea    0xa4f6d(%rdi),%r8
    27ae:	e9 e9 04 00 00       	jmp    2c9c <f_8001161d0+0x2c9c>
    27b3:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    27ba:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
    27c1:	48 8b b6 c8 1e 00 00 	mov    0x1ec8(%rsi),%rsi
    27c8:	48 89 73 08          	mov    %rsi,0x8(%rbx)
    27cc:	4c 8b 14 24          	mov    (%rsp),%r10
    27d0:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    27d4:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
    27db:	00 
    27dc:	44 0f b6 41 08       	movzbl 0x8(%rcx),%r8d
    27e1:	4c 89 43 68          	mov    %r8,0x68(%rbx)
    27e5:	44 8b 4e 08          	mov    0x8(%rsi),%r9d
    27e9:	4d 69 d8 e0 3c 00 00 	imul   $0x3ce0,%r8,%r11
    27f0:	31 c9                	xor    %ecx,%ecx
    27f2:	45 39 c1             	cmp    %r8d,%r9d
    27f5:	48 8b 76 10          	mov    0x10(%rsi),%rsi
    27f9:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
    2800:	00 
    2801:	4c 0f 46 d9          	cmovbe %rcx,%r11
    2805:	49 8b b4 33 40 3c 00 	mov    0x3c40(%r11,%rsi,1),%rsi
    280c:	00 
    280d:	48 89 33             	mov    %rsi,(%rbx)
    2810:	4c 8b 83 00 01 00 00 	mov    0x100(%rbx),%r8
    2817:	45 89 b0 a0 00 00 00 	mov    %r14d,0xa0(%r8)
    281e:	4d 89 90 88 00 00 00 	mov    %r10,0x88(%r8)
    2825:	48 be ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rsi
    282c:	ff 7f 7f 
    282f:	49 89 b0 90 00 00 00 	mov    %rsi,0x90(%r8)
    2836:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    283d:	00 
    283e:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2842:	41 c7 80 bc 00 00 00 	movl   $0x0,0xbc(%r8)
    2849:	00 00 00 00 
    284d:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    2851:	c4 c1 7a 7f 40 58    	vmovdqu %xmm0,0x58(%r8)
    2857:	49 c7 00 20 00 00 00 	movq   $0x20,(%r8)
    285e:	48 b8 00 00 00 00 00 	movabs $0x42080000000000,%rax
    2865:	08 42 00 
    2868:	49 89 40 08          	mov    %rax,0x8(%r8)
    286c:	49 c7 40 48 00 00 00 	movq   $0x0,0x48(%r8)
    2873:	00 
    2874:	49 89 50 50          	mov    %rdx,0x50(%r8)
    2878:	49 c7 40 30 07 00 00 	movq   $0x7,0x30(%r8)
    287f:	00 
    2880:	49 c7 40 10 ff ff 00 	movq   $0xffff,0x10(%r8)
    2887:	00 
    2888:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    288f:	ff ff ff 
    2892:	48 8d 42 0a          	lea    0xa(%rdx),%rax
    2896:	49 89 40 18          	mov    %rax,0x18(%r8)
    289a:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    28a1:	00 00 00 
    28a4:	49 89 40 20          	mov    %rax,0x20(%r8)
    28a8:	49 89 50 28          	mov    %rdx,0x28(%r8)
    28ac:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    28b3:	48 89 b8 a4 00 00 00 	mov    %rdi,0xa4(%rax)
    28ba:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    28c1:	00 80 3f 
    28c4:	49 89 40 38          	mov    %rax,0x38(%r8)
    28c8:	49 89 40 40          	mov    %rax,0x40(%r8)
    28cc:	49 be ca 5d c0 02 08 	movabs $0x802c05dca,%r14
    28d3:	00 00 00 
    28d6:	49 8d 86 c5 e4 0b 00 	lea    0xbe4c5(%r14),%rax
    28dd:	48 89 43 78          	mov    %rax,0x78(%rbx)
    28e1:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
    28e8:	ff 7f ff 
    28eb:	48 89 b3 80 00 00 00 	mov    %rsi,0x80(%rbx)
    28f2:	49 89 b0 98 00 00 00 	mov    %rsi,0x98(%r8)
    28f9:	48 8b 53 58          	mov    0x58(%rbx),%rdx
    28fd:	49 89 50 78          	mov    %rdx,0x78(%r8)
    2901:	49 89 b0 80 00 00 00 	mov    %rsi,0x80(%r8)
    2908:	49 c7 40 68 00 00 00 	movq   $0x0,0x68(%r8)
    290f:	00 
    2910:	49 89 40 70          	mov    %rax,0x70(%r8)
    2914:	48 8b 43 08          	mov    0x8(%rbx),%rax
    2918:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
    291c:	41 89 f8             	mov    %edi,%r8d
    291f:	39 78 08             	cmp    %edi,0x8(%rax)
    2922:	be 00 00 00 00       	mov    $0x0,%esi
    2927:	49 0f 47 f0          	cmova  %r8,%rsi
    292b:	4c 8b 4b 48          	mov    0x48(%rbx),%r9
    292f:	4c 8b 50 10          	mov    0x10(%rax),%r10
    2933:	8b 53 70             	mov    0x70(%rbx),%edx
    2936:	48 0f af f2          	imul   %rdx,%rsi
    293a:	c4 a1 7a 6f 84 16 b0 	vmovdqu 0x30b0(%rsi,%r10,1),%xmm0
    2941:	30 00 00 
    2944:	c4 c1 7a 7f 01       	vmovdqu %xmm0,(%r9)
    2949:	8b 70 08             	mov    0x8(%rax),%esi
    294c:	45 31 c9             	xor    %r9d,%r9d
    294f:	41 89 f2             	mov    %esi,%r10d
    2952:	41 31 fa             	xor    %edi,%r10d
    2955:	41 0f 94 c1          	sete   %r9b
    2959:	45 31 db             	xor    %r11d,%r11d
    295c:	89 f5                	mov    %esi,%ebp
    295e:	29 fd                	sub    %edi,%ebp
    2960:	49 0f 47 c8          	cmova  %r8,%rcx
    2964:	41 0f 93 c3          	setae  %r11b
    2968:	31 ee                	xor    %ebp,%esi
    296a:	44 21 d6             	and    %r10d,%esi
    296d:	41 c1 e1 1e          	shl    $0x1e,%r9d
    2971:	41 c1 e3 1d          	shl    $0x1d,%r11d
    2975:	45 09 cb             	or     %r9d,%r11d
    2978:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    297e:	41 09 eb             	or     %ebp,%r11d
    2981:	4c 89 f5             	mov    %r14,%rbp
    2984:	48 8b 40 10          	mov    0x10(%rax),%rax
    2988:	c1 ee 03             	shr    $0x3,%esi
    298b:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    2991:	44 09 de             	or     %r11d,%esi
    2994:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    299b:	48 0f af ca          	imul   %rdx,%rcx
    299f:	48 8b 94 01 30 33 00 	mov    0x3330(%rcx,%rax,1),%rdx
    29a6:	00 
    29a7:	48 8b b4 01 38 33 00 	mov    0x3338(%rcx,%rax,1),%rsi
    29ae:	00 
    29af:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    29b3:	48 8b bb d0 00 00 00 	mov    0xd0(%rbx),%rdi
    29ba:	48 89 17             	mov    %rdx,(%rdi)
    29bd:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    29c1:	48 8b 94 01 40 33 00 	mov    0x3340(%rcx,%rax,1),%rdx
    29c8:	00 
    29c9:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    29cd:	8b 84 01 48 33 00 00 	mov    0x3348(%rcx,%rax,1),%eax
    29d4:	48 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%rcx
    29db:	89 41 08             	mov    %eax,0x8(%rcx)
    29de:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    29e5:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    29e9:	48 89 43 40          	mov    %rax,0x40(%rbx)
    29ed:	48 89 11             	mov    %rdx,(%rcx)
    29f0:	49 8d 86 72 0d 51 fd 	lea    -0x2aef28e(%r14),%rax
    29f7:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    29fe:	48 89 df             	mov    %rbx,%rdi
    2a01:	c5 f8 77             	vzeroupper
    2a04:	e8 00 00 00 00       	call   2a09 <f_8001161d0+0x2a09>
    2a09:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2a10:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    2a17:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    2a1e:	48 89 01             	mov    %rax,(%rcx)
    2a21:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    2a28:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    2a2c:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2a30:	88 41 08             	mov    %al,0x8(%rcx)
    2a33:	b9 bc 00 00 00       	mov    $0xbc,%ecx
    2a38:	48 03 8b 00 01 00 00 	add    0x100(%rbx),%rcx
    2a3f:	e9 d2 08 00 00       	jmp    3316 <f_8001161d0+0x3316>
    2a44:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2a48:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    2a4f:	48 c7 01 01 00 00 00 	movq   $0x1,(%rcx)
    2a56:	49 b8 00 00 00 00 00 	movabs $0x40000000000000,%r8
    2a5d:	00 40 00 
    2a60:	4c 89 41 08          	mov    %r8,0x8(%rcx)
    2a64:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    2a6b:	00 
    2a6c:	49 89 f9             	mov    %rdi,%r9
    2a6f:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    2a76:	ff ff ff 
    2a79:	4c 8d 47 15          	lea    0x15(%rdi),%r8
    2a7d:	4c 89 41 18          	mov    %r8,0x18(%rcx)
    2a81:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2a88:	00 
    2a89:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2a90:	00 00 00 
    2a93:	48 89 41 20          	mov    %rax,0x20(%rcx)
    2a97:	48 89 79 28          	mov    %rdi,0x28(%rcx)
    2a9b:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    2aa0:	48 89 41 30          	mov    %rax,0x30(%rcx)
    2aa4:	49 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r8
    2aab:	00 80 3f 
    2aae:	4c 89 41 38          	mov    %r8,0x38(%rcx)
    2ab2:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    2ab9:	00 00 00 
    2abc:	48 8d 80 7c 4f 0a 00 	lea    0xa4f7c(%rax),%rax
    2ac3:	48 89 41 70          	mov    %rax,0x70(%rcx)
    2ac7:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
    2ace:	ff 7f 7f 
    2ad1:	4c 89 59 78          	mov    %r11,0x78(%rcx)
    2ad5:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    2adc:	ff 7f ff 
    2adf:	48 89 b9 80 00 00 00 	mov    %rdi,0x80(%rcx)
    2ae6:	48 8b 04 24          	mov    (%rsp),%rax
    2aea:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    2af1:	c5 fd 6f 05 00 00 00 	vmovdqa 0x0(%rip),%ymm0        # 2af9 <f_8001161d0+0x2af9>
    2af8:	00 
    2af9:	c5 fe 7f 43 60       	vmovdqu %ymm0,0x60(%rbx)
    2afe:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2b05:	4c 89 88 a4 00 00 00 	mov    %r9,0xa4(%rax)
    2b0c:	4c 89 41 40          	mov    %r8,0x40(%rcx)
    2b10:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    2b17:	00 
    2b18:	4c 89 99 90 00 00 00 	mov    %r11,0x90(%rcx)
    2b1f:	48 89 b9 98 00 00 00 	mov    %rdi,0x98(%rcx)
    2b26:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    2b2d:	00 
    2b2e:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    2b32:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    2b36:	c5 fa 7f 41 58       	vmovdqu %xmm0,0x58(%rcx)
    2b3b:	48 c7 43 50 03 00 00 	movq   $0x3,0x50(%rbx)
    2b42:	00 
    2b43:	b8 03 00 00 00       	mov    $0x3,%eax
    2b48:	e9 ed 01 00 00       	jmp    2d3a <f_8001161d0+0x2d3a>
    2b4d:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    2b54:	00 
    2b55:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    2b5c:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    2b63:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    2b67:	48 89 43 10          	mov    %rax,0x10(%rbx)
    2b6b:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    2b70:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    2b77:	48 89 03             	mov    %rax,(%rbx)
    2b7a:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    2b81:	00 00 00 
    2b84:	48 8d 85 2e 0c 51 fd 	lea    -0x2aef3d2(%rbp),%rax
    2b8b:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    2b92:	48 89 df             	mov    %rbx,%rdi
    2b95:	c5 f8 77             	vzeroupper
    2b98:	e8 00 00 00 00       	call   2b9d <f_8001161d0+0x2b9d>
    2b9d:	e9 c5 02 00 00       	jmp    2e67 <f_8001161d0+0x2e67>
    2ba2:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    2ba9:	00 
    2baa:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
    2bb1:	49 c7 03 03 00 00 00 	movq   $0x3,(%r11)
    2bb8:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    2bbf:	00 40 00 
    2bc2:	49 89 4b 08          	mov    %rcx,0x8(%r11)
    2bc6:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
    2bcd:	00 
    2bce:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    2bd5:	ff ff ff 
    2bd8:	48 8d 4f 0f          	lea    0xf(%rdi),%rcx
    2bdc:	49 89 4b 18          	mov    %rcx,0x18(%r11)
    2be0:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2be7:	00 00 00 
    2bea:	49 89 4b 20          	mov    %rcx,0x20(%r11)
    2bee:	49 89 7b 28          	mov    %rdi,0x28(%r11)
    2bf2:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    2bf8:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    2bfc:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    2c03:	00 80 3f 
    2c06:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    2c0a:	49 8d 4b 30          	lea    0x30(%r11),%rcx
    2c0e:	49 83 c3 38          	add    $0x38,%r11
    2c12:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    2c19:	00 00 00 
    2c1c:	4c 8d 87 fb b3 05 00 	lea    0x5b3fb(%rdi),%r8
    2c23:	eb 77                	jmp    2c9c <f_8001161d0+0x2c9c>
    2c25:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    2c2c:	ff ff ff 
    2c2f:	48 8d 4f 0e          	lea    0xe(%rdi),%rcx
    2c33:	48 89 4b 78          	mov    %rcx,0x78(%rbx)
    2c37:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
    2c3e:	49 c7 03 00 04 00 00 	movq   $0x400,(%r11)
    2c45:	49 c7 43 08 00 00 00 	movq   $0x0,0x8(%r11)
    2c4c:	00 
    2c4d:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
    2c54:	00 
    2c55:	49 89 4b 18          	mov    %rcx,0x18(%r11)
    2c59:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2c60:	00 00 00 
    2c63:	49 89 4b 20          	mov    %rcx,0x20(%r11)
    2c67:	49 89 7b 28          	mov    %rdi,0x28(%r11)
    2c6b:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    2c71:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    2c75:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    2c7c:	00 80 3f 
    2c7f:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    2c83:	49 8d 4b 30          	lea    0x30(%r11),%rcx
    2c87:	49 83 c3 38          	add    $0x38,%r11
    2c8b:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    2c92:	00 00 00 
    2c95:	4c 8d 87 d9 85 00 00 	lea    0x85d9(%rdi),%r8
    2c9c:	4c 89 09             	mov    %r9,(%rcx)
    2c9f:	4d 89 3b             	mov    %r15,(%r11)
    2ca2:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    2ca9:	4c 89 41 70          	mov    %r8,0x70(%rcx)
    2cad:	49 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r9
    2cb4:	ff 7f 7f 
    2cb7:	4c 89 49 78          	mov    %r9,0x78(%rcx)
    2cbb:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    2cc2:	ff 7f ff 
    2cc5:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    2cc9:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2ccd:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2cd4:	00 
    2cd5:	48 89 b9 80 00 00 00 	mov    %rdi,0x80(%rcx)
    2cdc:	48 8b 04 24          	mov    (%rsp),%rax
    2ce0:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    2ce7:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    2cec:	4c 89 43 60          	mov    %r8,0x60(%rbx)
    2cf0:	4c 89 79 40          	mov    %r15,0x40(%rcx)
    2cf4:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    2cfb:	00 
    2cfc:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2d03:	4c 89 80 a4 00 00 00 	mov    %r8,0xa4(%rax)
    2d0a:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    2d0e:	48 c7 41 58 00 00 00 	movq   $0x0,0x58(%rcx)
    2d15:	00 
    2d16:	48 c7 43 50 02 00 00 	movq   $0x2,0x50(%rbx)
    2d1d:	00 
    2d1e:	4c 89 89 90 00 00 00 	mov    %r9,0x90(%rcx)
    2d25:	48 89 b9 98 00 00 00 	mov    %rdi,0x98(%rcx)
    2d2c:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    2d30:	c5 fa 7f 41 60       	vmovdqu %xmm0,0x60(%rcx)
    2d35:	b8 02 00 00 00       	mov    $0x2,%eax
    2d3a:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    2d41:	89 81 bc 00 00 00    	mov    %eax,0xbc(%rcx)
    2d47:	4d 89 d6             	mov    %r10,%r14
    2d4a:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    2d51:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
    2d58:	48 8b 80 c8 1e 00 00 	mov    0x1ec8(%rax),%rax
    2d5f:	0f b6 79 08          	movzbl 0x8(%rcx),%edi
    2d63:	4c 69 c7 e0 3c 00 00 	imul   $0x3ce0,%rdi,%r8
    2d6a:	31 c9                	xor    %ecx,%ecx
    2d6c:	39 78 08             	cmp    %edi,0x8(%rax)
    2d6f:	ba 00 00 00 00       	mov    $0x0,%edx
    2d74:	49 0f 47 d0          	cmova  %r8,%rdx
    2d78:	4c 8b 48 10          	mov    0x10(%rax),%r9
    2d7c:	4e 8b 94 0a 08 2e 00 	mov    0x2e08(%rdx,%r9,1),%r10
    2d83:	00 
    2d84:	4c 89 53 68          	mov    %r10,0x68(%rbx)
    2d88:	4a 8b 94 0a 00 2e 00 	mov    0x2e00(%rdx,%r9,1),%rdx
    2d8f:	00 
    2d90:	48 89 16             	mov    %rdx,(%rsi)
    2d93:	4c 89 56 08          	mov    %r10,0x8(%rsi)
    2d97:	44 8b 48 08          	mov    0x8(%rax),%r9d
    2d9b:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2d9f:	48 89 53 60          	mov    %rdx,0x60(%rbx)
    2da3:	45 31 d2             	xor    %r10d,%r10d
    2da6:	45 31 db             	xor    %r11d,%r11d
    2da9:	44 89 cd             	mov    %r9d,%ebp
    2dac:	29 fd                	sub    %edi,%ebp
    2dae:	49 0f 47 c8          	cmova  %r8,%rcx
    2db2:	41 0f 94 c2          	sete   %r10b
    2db6:	41 0f 93 c3          	setae  %r11b
    2dba:	c4 c2 50 f2 f9       	andn   %r9d,%ebp,%edi
    2dbf:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    2dc5:	41 c1 e2 1e          	shl    $0x1e,%r10d
    2dc9:	41 c1 e3 1d          	shl    $0x1d,%r11d
    2dcd:	45 09 d3             	or     %r10d,%r11d
    2dd0:	41 09 eb             	or     %ebp,%r11d
    2dd3:	c1 ef 03             	shr    $0x3,%edi
    2dd6:	81 e7 00 00 00 10    	and    $0x10000000,%edi
    2ddc:	44 09 df             	or     %r11d,%edi
    2ddf:	48 89 bb 10 01 00 00 	mov    %rdi,0x110(%rbx)
    2de6:	48 8b bc 0a 80 30 00 	mov    0x3080(%rdx,%rcx,1),%rdi
    2ded:	00 
    2dee:	4c 8b 84 0a 88 30 00 	mov    0x3088(%rdx,%rcx,1),%r8
    2df5:	00 
    2df6:	48 89 7b 58          	mov    %rdi,0x58(%rbx)
    2dfa:	49 89 3e             	mov    %rdi,(%r14)
    2dfd:	4d 89 46 08          	mov    %r8,0x8(%r14)
    2e01:	8b b4 0a 98 30 00 00 	mov    0x3098(%rdx,%rcx,1),%esi
    2e08:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    2e0c:	48 8b 8c 0a 90 30 00 	mov    0x3090(%rdx,%rcx,1),%rcx
    2e13:	00 
    2e14:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
    2e1b:	48 89 0a             	mov    %rcx,(%rdx)
    2e1e:	89 72 08             	mov    %esi,0x8(%rdx)
    2e21:	8b 50 20             	mov    0x20(%rax),%edx
    2e24:	8b 48 24             	mov    0x24(%rax),%ecx
    2e27:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    2e2b:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    2e2f:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    2e36:	c7 80 b4 00 00 00 00 	movl   $0x0,0xb4(%rax)
    2e3d:	00 00 00 
    2e40:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    2e47:	c7 86 b1 00 00 00 00 	movl   $0x0,0xb1(%rsi)
    2e4e:	00 00 00 
    2e51:	88 90 b0 00 00 00    	mov    %dl,0xb0(%rax)
    2e57:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    2e5e:	00 00 00 
    2e61:	88 88 b8 00 00 00    	mov    %cl,0xb8(%rax)
    2e67:	4c 8b 83 b8 00 00 00 	mov    0xb8(%rbx),%r8
    2e6e:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    2e75:	8b 08                	mov    (%rax),%ecx
    2e77:	48 89 4b 50          	mov    %rcx,0x50(%rbx)
    2e7b:	49 8d 50 1c          	lea    0x1c(%r8),%rdx
    2e7f:	41 8b 70 1c          	mov    0x1c(%r8),%esi
    2e83:	48 89 53 40          	mov    %rdx,0x40(%rbx)
    2e87:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    2e8b:	89 70 48             	mov    %esi,0x48(%rax)
    2e8e:	4d 8d 48 2c          	lea    0x2c(%r8),%r9
    2e92:	41 8b 78 2c          	mov    0x2c(%r8),%edi
    2e96:	45 31 d2             	xor    %r10d,%r10d
    2e99:	48 85 ff             	test   %rdi,%rdi
    2e9c:	41 0f 94 c2          	sete   %r10b
    2ea0:	4c 89 8b b0 00 00 00 	mov    %r9,0xb0(%rbx)
    2ea7:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
    2eab:	45 8b 40 14          	mov    0x14(%r8),%r8d
    2eaf:	45 31 c9             	xor    %r9d,%r9d
    2eb2:	41 85 c8             	test   %ecx,%r8d
    2eb5:	41 0f 95 c1          	setne  %r9b
    2eb9:	4c 89 4b 58          	mov    %r9,0x58(%rbx)
    2ebd:	41 89 f9             	mov    %edi,%r9d
    2ec0:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    2ec7:	45 89 d3             	mov    %r10d,%r11d
    2eca:	41 c1 e3 1e          	shl    $0x1e,%r11d
    2ece:	4d 01 d9             	add    %r11,%r9
    2ed1:	49 81 c1 00 00 00 20 	add    $0x20000000,%r9
    2ed8:	4c 89 8b 10 01 00 00 	mov    %r9,0x110(%rbx)
    2edf:	c1 ef 1f             	shr    $0x1f,%edi
    2ee2:	41 08 fa             	or     %dil,%r10b
    2ee5:	74 0d                	je     2ef4 <f_8001161d0+0x2ef4>
    2ee7:	48 c7 43 58 00 00 00 	movq   $0x0,0x58(%rbx)
    2eee:	00 
    2eef:	e9 71 01 00 00       	jmp    3065 <f_8001161d0+0x3065>
    2ef4:	41 85 c8             	test   %ecx,%r8d
    2ef7:	0f 84 68 01 00 00    	je     3065 <f_8001161d0+0x3065>
    2efd:	4c 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%r8
    2f04:	4c 8b 8b a8 00 00 00 	mov    0xa8(%rbx),%r9
    2f0b:	49 8d b8 40 01 00 00 	lea    0x140(%r8),%rdi
    2f12:	48 89 bb c0 00 00 00 	mov    %rdi,0xc0(%rbx)
    2f19:	44 89 cf             	mov    %r9d,%edi
    2f1c:	4d 63 c9             	movslq %r9d,%r9
    2f1f:	49 c1 f9 1f          	sar    $0x1f,%r9
    2f23:	49 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%r10
    2f2a:	ff ff ff 
    2f2d:	4d 21 d1             	and    %r10,%r9
    2f30:	49 09 f9             	or     %rdi,%r9
    2f33:	4c 89 8b c8 00 00 00 	mov    %r9,0xc8(%rbx)
    2f3a:	47 0f b6 84 08 40 01 	movzbl 0x140(%r8,%r9,1),%r8d
    2f41:	00 00 
    2f43:	4c 89 43 58          	mov    %r8,0x58(%rbx)
    2f47:	41 f6 c0 01          	test   $0x1,%r8b
    2f4b:	0f 84 14 01 00 00    	je     3065 <f_8001161d0+0x3065>
    2f51:	49 89 ef             	mov    %rbp,%r15
    2f54:	44 0f b6 40 0c       	movzbl 0xc(%rax),%r8d
    2f59:	4c 89 43 58          	mov    %r8,0x58(%rbx)
    2f5d:	41 f6 c0 01          	test   $0x1,%r8b
    2f61:	74 09                	je     2f6c <f_8001161d0+0x2f6c>
    2f63:	48 09 ce             	or     %rcx,%rsi
    2f66:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    2f6a:	89 32                	mov    %esi,(%rdx)
    2f6c:	48 c7 43 40 d0 00 00 	movq   $0xd0,0x40(%rbx)
    2f73:	00 
    2f74:	48 89 43 08          	mov    %rax,0x8(%rbx)
    2f78:	48 63 c7             	movslq %edi,%rax
    2f7b:	48 69 c0 d0 00 00 00 	imul   $0xd0,%rax,%rax
    2f82:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    2f89:	48 8d 14 01          	lea    (%rcx,%rax,1),%rdx
    2f8d:	48 89 93 d0 00 00 00 	mov    %rdx,0xd0(%rbx)
    2f94:	48 c7 43 10 c0 00 00 	movq   $0xc0,0x10(%rbx)
    2f9b:	00 
    2f9c:	48 8d 84 01 40 0d 00 	lea    0xd40(%rcx,%rax,1),%rax
    2fa3:	00 
    2fa4:	48 89 83 a8 00 00 00 	mov    %rax,0xa8(%rbx)
    2fab:	48 89 03             	mov    %rax,(%rbx)
    2fae:	49 8d 87 6e 12 51 fd 	lea    -0x2aeed92(%r15),%rax
    2fb5:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    2fbc:	48 89 df             	mov    %rbx,%rdi
    2fbf:	c5 f8 77             	vzeroupper
    2fc2:	e8 00 00 00 00       	call   2fc7 <f_8001161d0+0x2fc7>
    2fc7:	48 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%rax
    2fce:	80 88 38 0d 00 00 01 	orb    $0x1,0xd38(%rax)
    2fd5:	48 8b bb a0 00 00 00 	mov    0xa0(%rbx),%rdi
    2fdc:	0f b6 87 81 3a 00 00 	movzbl 0x3a81(%rdi),%eax
    2fe3:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2fe7:	a8 40                	test   $0x40,%al
    2fe9:	74 7a                	je     3065 <f_8001161d0+0x3065>
    2feb:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2ff2:	48 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%rcx
    2ff9:	0f b6 04 01          	movzbl (%rcx,%rax,1),%eax
    2ffd:	48 89 43 40          	mov    %rax,0x40(%rbx)
    3001:	a8 02                	test   $0x2,%al
    3003:	74 60                	je     3065 <f_8001161d0+0x3065>
    3005:	48 8b 87 60 3b 00 00 	mov    0x3b60(%rdi),%rax
    300c:	48 89 43 40          	mov    %rax,0x40(%rbx)
    3010:	48 85 c0             	test   %rax,%rax
    3013:	74 50                	je     3065 <f_8001161d0+0x3065>
    3015:	0f b6 87 85 3a 00 00 	movzbl 0x3a85(%rdi),%eax
    301c:	48 89 43 40          	mov    %rax,0x40(%rbx)
    3020:	a8 02                	test   $0x2,%al
    3022:	74 41                	je     3065 <f_8001161d0+0x3065>
    3024:	48 8b 83 a8 00 00 00 	mov    0xa8(%rbx),%rax
    302b:	48 8b 8b b8 00 00 00 	mov    0xb8(%rbx),%rcx
    3032:	8b 00                	mov    (%rax),%eax
    3034:	48 89 43 40          	mov    %rax,0x40(%rbx)
    3038:	8b 49 10             	mov    0x10(%rcx),%ecx
    303b:	31 d2                	xor    %edx,%edx
    303d:	c4 e2 70 f2 c0       	andn   %eax,%ecx,%eax
    3042:	0f 94 c2             	sete   %dl
    3045:	89 c6                	mov    %eax,%esi
    3047:	81 e6 00 00 00 80    	and    $0x80000000,%esi
    304d:	c1 e2 1e             	shl    $0x1e,%edx
    3050:	09 f2                	or     %esi,%edx
    3052:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    3056:	48 89 93 10 01 00 00 	mov    %rdx,0x110(%rbx)
    305d:	85 c0                	test   %eax,%eax
    305f:	0f 84 c3 05 00 00    	je     3628 <f_8001161d0+0x3628>
    3065:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    306c:	48 8b 88 20 01 00 00 	mov    0x120(%rax),%rcx
    3073:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    307a:	48 89 8b a0 00 00 00 	mov    %rcx,0xa0(%rbx)
    3081:	48 89 93 98 00 00 00 	mov    %rdx,0x98(%rbx)
    3088:	48 8b 88 10 01 00 00 	mov    0x110(%rax),%rcx
    308f:	48 8b 90 18 01 00 00 	mov    0x118(%rax),%rdx
    3096:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
    309d:	48 89 93 a8 00 00 00 	mov    %rdx,0xa8(%rbx)
    30a4:	48 8b 88 00 01 00 00 	mov    0x100(%rax),%rcx
    30ab:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    30b2:	48 89 8b c0 00 00 00 	mov    %rcx,0xc0(%rbx)
    30b9:	48 89 93 b8 00 00 00 	mov    %rdx,0xb8(%rbx)
    30c0:	48 8b 88 f0 00 00 00 	mov    0xf0(%rax),%rcx
    30c7:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
    30ce:	48 89 8b d0 00 00 00 	mov    %rcx,0xd0(%rbx)
    30d5:	48 89 93 c8 00 00 00 	mov    %rdx,0xc8(%rbx)
    30dc:	48 8b 88 e0 00 00 00 	mov    0xe0(%rax),%rcx
    30e3:	48 8b 90 e8 00 00 00 	mov    0xe8(%rax),%rdx
    30ea:	48 89 8b e0 00 00 00 	mov    %rcx,0xe0(%rbx)
    30f1:	48 89 93 d8 00 00 00 	mov    %rdx,0xd8(%rbx)
    30f8:	c5 f8 10 80 d0 00 00 	vmovups 0xd0(%rax),%xmm0
    30ff:	00 
    3100:	c5 f8 11 83 e8 00 00 	vmovups %xmm0,0xe8(%rbx)
    3107:	00 
    3108:	48 05 30 01 00 00    	add    $0x130,%rax
    310e:	48 89 83 00 01 00 00 	mov    %rax,0x100(%rbx)
    3115:	48 83 c4 18          	add    $0x18,%rsp
    3119:	5b                   	pop    %rbx
    311a:	41 5c                	pop    %r12
    311c:	41 5d                	pop    %r13
    311e:	41 5e                	pop    %r14
    3120:	41 5f                	pop    %r15
    3122:	5d                   	pop    %rbp
    3123:	c5 f8 77             	vzeroupper
    3126:	c3                   	ret
    3127:	4c 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%r8
    312e:	49 8b 88 c8 1e 00 00 	mov    0x1ec8(%r8),%rcx
    3135:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
    313c:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
    3143:	ff ff ff 
    3146:	49 89 f9             	mov    %rdi,%r9
    3149:	48 89 cf             	mov    %rcx,%rdi
    314c:	48 8d 71 1a          	lea    0x1a(%rcx),%rsi
    3150:	48 89 73 70          	mov    %rsi,0x70(%rbx)
    3154:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    3158:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    315f:	48 c7 01 00 20 00 00 	movq   $0x2000,(%rcx)
    3166:	48 c7 41 08 00 00 00 	movq   $0x0,0x8(%rcx)
    316d:	00 
    316e:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    3175:	00 
    3176:	48 89 71 18          	mov    %rsi,0x18(%rcx)
    317a:	48 8b b3 98 00 00 00 	mov    0x98(%rbx),%rsi
    3181:	48 89 73 08          	mov    %rsi,0x8(%rbx)
    3185:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    318c:	00 
    318d:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    3194:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    319b:	00 00 00 
    319e:	48 89 41 20          	mov    %rax,0x20(%rcx)
    31a2:	48 89 79 28          	mov    %rdi,0x28(%rcx)
    31a6:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
    31ad:	00 80 3f 
    31b0:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    31b4:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    31b9:	48 89 41 30          	mov    %rax,0x30(%rcx)
    31bd:	48 89 79 38          	mov    %rdi,0x38(%rcx)
    31c1:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    31c8:	00 00 00 
    31cb:	48 8d 85 95 53 09 00 	lea    0x95395(%rbp),%rax
    31d2:	48 89 41 70          	mov    %rax,0x70(%rcx)
    31d6:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
    31dd:	ff 7f 7f 
    31e0:	4c 89 59 78          	mov    %r11,0x78(%rcx)
    31e4:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
    31eb:	ff 7f ff 
    31ee:	48 89 b1 80 00 00 00 	mov    %rsi,0x80(%rcx)
    31f5:	48 8b 04 24          	mov    (%rsp),%rax
    31f9:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    3200:	4c 89 4b 60          	mov    %r9,0x60(%rbx)
    3204:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    320b:	4c 89 88 a4 00 00 00 	mov    %r9,0xa4(%rax)
    3212:	4c 89 99 90 00 00 00 	mov    %r11,0x90(%rcx)
    3219:	48 89 b1 98 00 00 00 	mov    %rsi,0x98(%rcx)
    3220:	48 c7 43 50 b0 1e 00 	movq   $0x1eb0,0x50(%rbx)
    3227:	00 
    3228:	49 81 c0 b0 1e 00 00 	add    $0x1eb0,%r8
    322f:	4c 89 03             	mov    %r8,(%rbx)
    3232:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    3236:	48 c7 41 58 00 00 00 	movq   $0x0,0x58(%rcx)
    323d:	00 
    323e:	48 c7 43 48 03 00 00 	movq   $0x3,0x48(%rbx)
    3245:	00 
    3246:	c7 81 bc 00 00 00 03 	movl   $0x3,0xbc(%rcx)
    324d:	00 00 00 
    3250:	48 89 79 40          	mov    %rdi,0x40(%rcx)
    3254:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    325b:	00 
    325c:	c5 f9 ef c0          	vpxor  %xmm0,%xmm0,%xmm0
    3260:	c5 fa 7f 41 60       	vmovdqu %xmm0,0x60(%rcx)
    3265:	48 8d 85 92 14 51 fd 	lea    -0x2aeeb6e(%rbp),%rax
    326c:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    3273:	48 89 df             	mov    %rbx,%rdi
    3276:	c5 f8 77             	vzeroupper
    3279:	e8 00 00 00 00       	call   327e <f_8001161d0+0x327e>
    327e:	48 8b 33             	mov    (%rbx),%rsi
    3281:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    3288:	0f b6 48 08          	movzbl 0x8(%rax),%ecx
    328c:	48 8b 93 b0 00 00 00 	mov    0xb0(%rbx),%rdx
    3293:	8b 42 08             	mov    0x8(%rdx),%eax
    3296:	31 ff                	xor    %edi,%edi
    3298:	45 31 c0             	xor    %r8d,%r8d
    329b:	41 89 c1             	mov    %eax,%r9d
    329e:	41 29 c9             	sub    %ecx,%r9d
    32a1:	40 0f 94 c7          	sete   %dil
    32a5:	41 0f 93 c0          	setae  %r8b
    32a9:	c4 62 30 f2 d0       	andn   %eax,%r9d,%r10d
    32ae:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    32b5:	c1 e7 1e             	shl    $0x1e,%edi
    32b8:	41 c1 e0 1d          	shl    $0x1d,%r8d
    32bc:	41 09 f8             	or     %edi,%r8d
    32bf:	41 c1 ea 03          	shr    $0x3,%r10d
    32c3:	41 81 e2 00 00 00 10 	and    $0x10000000,%r10d
    32ca:	45 09 ca             	or     %r9d,%r10d
    32cd:	45 09 c2             	or     %r8d,%r10d
    32d0:	48 69 f9 e0 3c 00 00 	imul   $0x3ce0,%rcx,%rdi
    32d7:	31 c0                	xor    %eax,%eax
    32d9:	41 81 f8 00 00 00 20 	cmp    $0x20000000,%r8d
    32e0:	48 0f 44 c7          	cmove  %rdi,%rax
    32e4:	4c 89 93 10 01 00 00 	mov    %r10,0x110(%rbx)
    32eb:	48 03 42 10          	add    0x10(%rdx),%rax
    32ef:	40 f6 c6 01          	test   $0x1,%sil
    32f3:	75 34                	jne    3329 <f_8001161d0+0x3329>
    32f5:	41 b8 5c 00 00 00    	mov    $0x5c,%r8d
    32fb:	41 b9 58 00 00 00    	mov    $0x58,%r9d
    3301:	41 ba 54 00 00 00    	mov    $0x54,%r10d
    3307:	41 bb 50 00 00 00    	mov    $0x50,%r11d
    330d:	eb 36                	jmp    3345 <f_8001161d0+0x3345>
    330f:	48 81 c1 bc 00 00 00 	add    $0xbc,%rcx
    3316:	48 c7 43 40 02 00 00 	movq   $0x2,0x40(%rbx)
    331d:	00 
    331e:	c7 01 02 00 00 00    	movl   $0x2,(%rcx)
    3324:	e9 3e fb ff ff       	jmp    2e67 <f_8001161d0+0x2e67>
    3329:	48 89 43 68          	mov    %rax,0x68(%rbx)
    332d:	41 b8 0c 2e 00 00    	mov    $0x2e0c,%r8d
    3333:	41 b9 08 2e 00 00    	mov    $0x2e08,%r9d
    3339:	41 ba 04 2e 00 00    	mov    $0x2e04,%r10d
    333f:	41 bb 00 2e 00 00    	mov    $0x2e00,%r11d
    3345:	46 8b 1c 18          	mov    (%rax,%r11,1),%r11d
    3349:	4c 89 9b 00 02 00 00 	mov    %r11,0x200(%rbx)
    3350:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    3357:	00 00 00 00 
    335b:	46 8b 14 10          	mov    (%rax,%r10,1),%r10d
    335f:	4c 89 93 10 02 00 00 	mov    %r10,0x210(%rbx)
    3366:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    336d:	00 00 00 00 
    3371:	46 8b 0c 08          	mov    (%rax,%r9,1),%r9d
    3375:	4c 89 8b 20 02 00 00 	mov    %r9,0x220(%rbx)
    337c:	48 c7 83 28 02 00 00 	movq   $0x0,0x228(%rbx)
    3383:	00 00 00 00 
    3387:	48 c7 43 58 e0 3c 00 	movq   $0x3ce0,0x58(%rbx)
    338e:	00 
    338f:	46 8b 04 00          	mov    (%rax,%r8,1),%r8d
    3393:	4c 89 83 30 02 00 00 	mov    %r8,0x230(%rbx)
    339a:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    33a1:	00 00 00 00 
    33a5:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    33ac:	44 89 58 78          	mov    %r11d,0x78(%rax)
    33b0:	44 89 50 7c          	mov    %r10d,0x7c(%rax)
    33b4:	44 89 88 80 00 00 00 	mov    %r9d,0x80(%rax)
    33bb:	44 89 80 84 00 00 00 	mov    %r8d,0x84(%rax)
    33c2:	45 31 c0             	xor    %r8d,%r8d
    33c5:	39 4a 08             	cmp    %ecx,0x8(%rdx)
    33c8:	4c 0f 47 c7          	cmova  %rdi,%r8
    33cc:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
    33d0:	40 f6 c6 01          	test   $0x1,%sil
    33d4:	0f 85 9a 00 00 00    	jne    3474 <f_8001161d0+0x3474>
    33da:	4b 8b 74 08 20       	mov    0x20(%r8,%r9,1),%rsi
    33df:	4f 8b 54 08 28       	mov    0x28(%r8,%r9,1),%r10
    33e4:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    33e8:	4c 8b 9b d0 00 00 00 	mov    0xd0(%rbx),%r11
    33ef:	49 89 33             	mov    %rsi,(%r11)
    33f2:	4d 89 53 08          	mov    %r10,0x8(%r11)
    33f6:	4b 8b 74 08 30       	mov    0x30(%r8,%r9,1),%rsi
    33fb:	47 8b 44 08 38       	mov    0x38(%r8,%r9,1),%r8d
    3400:	4c 89 43 48          	mov    %r8,0x48(%rbx)
    3404:	4c 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%r9
    340b:	45 89 41 08          	mov    %r8d,0x8(%r9)
    340f:	49 89 31             	mov    %rsi,(%r9)
    3412:	44 8b 4a 08          	mov    0x8(%rdx),%r9d
    3416:	48 8b 72 10          	mov    0x10(%rdx),%rsi
    341a:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    341e:	45 31 c0             	xor    %r8d,%r8d
    3421:	45 31 d2             	xor    %r10d,%r10d
    3424:	45 31 db             	xor    %r11d,%r11d
    3427:	44 89 cd             	mov    %r9d,%ebp
    342a:	29 cd                	sub    %ecx,%ebp
    342c:	4c 0f 47 c7          	cmova  %rdi,%r8
    3430:	41 0f 94 c2          	sete   %r10b
    3434:	41 0f 93 c3          	setae  %r11b
    3438:	c4 c2 50 f2 d1       	andn   %r9d,%ebp,%edx
    343d:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    3443:	41 c1 e2 1e          	shl    $0x1e,%r10d
    3447:	41 c1 e3 1d          	shl    $0x1d,%r11d
    344b:	45 09 d3             	or     %r10d,%r11d
    344e:	41 09 eb             	or     %ebp,%r11d
    3451:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    3458:	00 00 00 
    345b:	c1 ea 03             	shr    $0x3,%edx
    345e:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    3464:	44 09 da             	or     %r11d,%edx
    3467:	4a 8d 0c 06          	lea    (%rsi,%r8,1),%rcx
    346b:	48 83 c1 40          	add    $0x40,%rcx
    346f:	e9 a9 00 00 00       	jmp    351d <f_8001161d0+0x351d>
    3474:	4b 8b b4 08 80 30 00 	mov    0x3080(%r8,%r9,1),%rsi
    347b:	00 
    347c:	4b 8b bc 08 88 30 00 	mov    0x3088(%r8,%r9,1),%rdi
    3483:	00 
    3484:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
    3488:	4c 8b 93 d0 00 00 00 	mov    0xd0(%rbx),%r10
    348f:	49 89 32             	mov    %rsi,(%r10)
    3492:	49 89 7a 08          	mov    %rdi,0x8(%r10)
    3496:	4b 8b b4 08 90 30 00 	mov    0x3090(%r8,%r9,1),%rsi
    349d:	00 
    349e:	43 8b bc 08 98 30 00 	mov    0x3098(%r8,%r9,1),%edi
    34a5:	00 
    34a6:	4c 8b 83 c8 00 00 00 	mov    0xc8(%rbx),%r8
    34ad:	41 89 78 08          	mov    %edi,0x8(%r8)
    34b1:	49 89 30             	mov    %rsi,(%r8)
    34b4:	44 8b 42 08          	mov    0x8(%rdx),%r8d
    34b8:	48 8b 72 10          	mov    0x10(%rdx),%rsi
    34bc:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    34c0:	31 ff                	xor    %edi,%edi
    34c2:	45 31 c9             	xor    %r9d,%r9d
    34c5:	45 31 d2             	xor    %r10d,%r10d
    34c8:	45 89 c3             	mov    %r8d,%r11d
    34cb:	41 29 cb             	sub    %ecx,%r11d
    34ce:	41 0f 94 c1          	sete   %r9b
    34d2:	41 0f 93 c2          	setae  %r10b
    34d6:	48 0f 47 f9          	cmova  %rcx,%rdi
    34da:	c4 c2 20 f2 d0       	andn   %r8d,%r11d,%edx
    34df:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    34e6:	41 c1 e1 1e          	shl    $0x1e,%r9d
    34ea:	41 c1 e2 1d          	shl    $0x1d,%r10d
    34ee:	45 09 ca             	or     %r9d,%r10d
    34f1:	45 09 da             	or     %r11d,%r10d
    34f4:	c1 ea 03             	shr    $0x3,%edx
    34f7:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    34fd:	44 09 d2             	or     %r10d,%edx
    3500:	48 c7 43 48 f0 2d 00 	movq   $0x2df0,0x48(%rbx)
    3507:	00 
    3508:	48 89 7b 40          	mov    %rdi,0x40(%rbx)
    350c:	48 69 cf e0 3c 00 00 	imul   $0x3ce0,%rdi,%rcx
    3513:	48 01 f1             	add    %rsi,%rcx
    3516:	48 81 c1 f0 2d 00 00 	add    $0x2df0,%rcx
    351d:	48 89 93 10 01 00 00 	mov    %rdx,0x110(%rbx)
    3524:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    3528:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    352c:	48 85 d2             	test   %rdx,%rdx
    352f:	74 0d                	je     353e <f_8001161d0+0x353e>
    3531:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3538:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    353c:	eb 02                	jmp    3540 <f_8001161d0+0x3540>
    353e:	31 d2                	xor    %edx,%edx
    3540:	88 90 b0 00 00 00    	mov    %dl,0xb0(%rax)
    3546:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    354a:	48 85 d2             	test   %rdx,%rdx
    354d:	74 09                	je     3558 <f_8001161d0+0x3558>
    354f:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3556:	eb 02                	jmp    355a <f_8001161d0+0x355a>
    3558:	31 d2                	xor    %edx,%edx
    355a:	88 90 b1 00 00 00    	mov    %dl,0xb1(%rax)
    3560:	48 8b 51 30          	mov    0x30(%rcx),%rdx
    3564:	48 85 d2             	test   %rdx,%rdx
    3567:	74 0d                	je     3576 <f_8001161d0+0x3576>
    3569:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3570:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    3574:	eb 02                	jmp    3578 <f_8001161d0+0x3578>
    3576:	31 d2                	xor    %edx,%edx
    3578:	88 90 b2 00 00 00    	mov    %dl,0xb2(%rax)
    357e:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    3582:	48 85 d2             	test   %rdx,%rdx
    3585:	74 09                	je     3590 <f_8001161d0+0x3590>
    3587:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    358e:	eb 02                	jmp    3592 <f_8001161d0+0x3592>
    3590:	31 d2                	xor    %edx,%edx
    3592:	88 90 b3 00 00 00    	mov    %dl,0xb3(%rax)
    3598:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    359c:	48 85 d2             	test   %rdx,%rdx
    359f:	74 0d                	je     35ae <f_8001161d0+0x35ae>
    35a1:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    35a8:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    35ac:	eb 02                	jmp    35b0 <f_8001161d0+0x35b0>
    35ae:	31 d2                	xor    %edx,%edx
    35b0:	88 90 b4 00 00 00    	mov    %dl,0xb4(%rax)
    35b6:	48 8b 51 48          	mov    0x48(%rcx),%rdx
    35ba:	48 85 d2             	test   %rdx,%rdx
    35bd:	74 09                	je     35c8 <f_8001161d0+0x35c8>
    35bf:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    35c6:	eb 02                	jmp    35ca <f_8001161d0+0x35ca>
    35c8:	31 d2                	xor    %edx,%edx
    35ca:	88 90 b5 00 00 00    	mov    %dl,0xb5(%rax)
    35d0:	48 8b 51 50          	mov    0x50(%rcx),%rdx
    35d4:	48 85 d2             	test   %rdx,%rdx
    35d7:	74 09                	je     35e2 <f_8001161d0+0x35e2>
    35d9:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    35e0:	eb 02                	jmp    35e4 <f_8001161d0+0x35e4>
    35e2:	31 d2                	xor    %edx,%edx
    35e4:	88 90 b6 00 00 00    	mov    %dl,0xb6(%rax)
    35ea:	48 8b 51 58          	mov    0x58(%rcx),%rdx
    35ee:	48 85 d2             	test   %rdx,%rdx
    35f1:	74 0d                	je     3600 <f_8001161d0+0x3600>
    35f3:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    35fa:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    35fe:	eb 02                	jmp    3602 <f_8001161d0+0x3602>
    3600:	31 d2                	xor    %edx,%edx
    3602:	88 90 b7 00 00 00    	mov    %dl,0xb7(%rax)
    3608:	48 8b 49 60          	mov    0x60(%rcx),%rcx
    360c:	48 85 c9             	test   %rcx,%rcx
    360f:	74 10                	je     3621 <f_8001161d0+0x3621>
    3611:	0f b6 89 c0 00 00 00 	movzbl 0xc0(%rcx),%ecx
    3618:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    361c:	e9 40 f8 ff ff       	jmp    2e61 <f_8001161d0+0x2e61>
    3621:	31 c9                	xor    %ecx,%ecx
    3623:	e9 39 f8 ff ff       	jmp    2e61 <f_8001161d0+0x2e61>
    3628:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
    362f:	8b 08                	mov    (%rax),%ecx
    3631:	44 8b 8f 90 3b 00 00 	mov    0x3b90(%rdi),%r9d
    3638:	44 8b 87 94 3b 00 00 	mov    0x3b94(%rdi),%r8d
    363f:	41 83 f9 01          	cmp    $0x1,%r9d
    3643:	44 89 ce             	mov    %r9d,%esi
    3646:	83 d6 00             	adc    $0x0,%esi
    3649:	89 c8                	mov    %ecx,%eax
    364b:	31 d2                	xor    %edx,%edx
    364d:	f7 f6                	div    %esi
    364f:	89 c6                	mov    %eax,%esi
    3651:	45 85 c9             	test   %r9d,%r9d
    3654:	41 0f 44 f1          	cmove  %r9d,%esi
    3658:	4c 89 43 48          	mov    %r8,0x48(%rbx)
    365c:	31 d2                	xor    %edx,%edx
    365e:	41 89 f1             	mov    %esi,%r9d
    3661:	45 31 c1             	xor    %r8d,%r9d
    3664:	0f 94 c2             	sete   %dl
    3667:	45 31 d2             	xor    %r10d,%r10d
    366a:	89 f0                	mov    %esi,%eax
    366c:	44 29 c0             	sub    %r8d,%eax
    366f:	41 0f 93 c2          	setae  %r10b
    3673:	41 89 f3             	mov    %esi,%r11d
    3676:	41 31 c3             	xor    %eax,%r11d
    3679:	45 21 cb             	and    %r9d,%r11d
    367c:	41 89 c1             	mov    %eax,%r9d
    367f:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    3686:	c1 e2 1e             	shl    $0x1e,%edx
    3689:	41 c1 e2 1d          	shl    $0x1d,%r10d
    368d:	41 09 d2             	or     %edx,%r10d
    3690:	45 09 ca             	or     %r9d,%r10d
    3693:	44 31 d8             	xor    %r11d,%eax
    3696:	41 c1 eb 03          	shr    $0x3,%r11d
    369a:	41 81 e3 00 00 00 10 	and    $0x10000000,%r11d
    36a1:	45 09 d3             	or     %r10d,%r11d
    36a4:	4c 89 9b 10 01 00 00 	mov    %r11,0x110(%rbx)
    36ab:	a9 00 00 00 80       	test   $0x80000000,%eax
    36b0:	49 0f 44 f0          	cmove  %r8,%rsi
    36b4:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    36b8:	48 85 f6             	test   %rsi,%rsi
    36bb:	0f 84 a4 f9 ff ff    	je     3065 <f_8001161d0+0x3065>
    36c1:	48 89 8b 88 00 00 00 	mov    %rcx,0x88(%rbx)
    36c8:	31 d2                	xor    %edx,%edx
    36ca:	89 f0                	mov    %esi,%eax
    36cc:	ff c8                	dec    %eax
    36ce:	0f 94 c2             	sete   %dl
    36d1:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    36d7:	49 81 c1 01 00 00 80 	add    $0xffffffff80000001,%r9
    36de:	45 31 c0             	xor    %r8d,%r8d
    36e1:	4d 89 cb             	mov    %r9,%r11
    36e4:	4c 39 ce             	cmp    %r9,%rsi
    36e7:	41 0f 94 c0          	sete   %r8b
    36eb:	41 89 c1             	mov    %eax,%r9d
    36ee:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    36f5:	c1 e2 1e             	shl    $0x1e,%edx
    36f8:	44 09 ca             	or     %r9d,%edx
    36fb:	45 89 c1             	mov    %r8d,%r9d
    36fe:	41 c1 e1 1c          	shl    $0x1c,%r9d
    3702:	41 09 d1             	or     %edx,%r9d
    3705:	49 81 c9 00 00 00 20 	or     $0x20000000,%r9
    370c:	4c 89 8b 10 01 00 00 	mov    %r9,0x110(%rbx)
    3713:	48 89 43 48          	mov    %rax,0x48(%rbx)
    3717:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
    371b:	c1 e8 1f             	shr    $0x1f,%eax
    371e:	41 30 c0             	xor    %al,%r8b
    3721:	0f 85 3e f9 ff ff    	jne    3065 <f_8001161d0+0x3065>
    3727:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    372d:	49 31 f0             	xor    %rsi,%r8
    3730:	41 be 00 00 00 80    	mov    $0x80000000,%r14d
    3736:	49 89 c9             	mov    %rcx,%r9
    3739:	4d 31 f1             	xor    %r14,%r9
    373c:	4c 89 c8             	mov    %r9,%rax
    373f:	4c 09 c0             	or     %r8,%rax
    3742:	b8 01 00 00 00       	mov    $0x1,%eax
    3747:	41 89 f2             	mov    %esi,%r10d
    374a:	44 0f 44 d0          	cmove  %eax,%r10d
    374e:	89 c8                	mov    %ecx,%eax
    3750:	99                   	cltd
    3751:	41 f7 fa             	idiv   %r10d
    3754:	48 8d 53 50          	lea    0x50(%rbx),%rdx
    3758:	4d 09 c1             	or     %r8,%r9
    375b:	41 89 c0             	mov    %eax,%r8d
    375e:	44 0f 44 c1          	cmove  %ecx,%r8d
    3762:	49 0f 44 c3          	cmove  %r11,%rax
    3766:	4c 8d 8f 80 3b 00 00 	lea    0x3b80(%rdi),%r9
    376d:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
    3771:	c5 f9 7f 0a          	vmovdqa %xmm1,(%rdx)
    3775:	4c 89 4b 70          	mov    %r9,0x70(%rbx)
    3779:	48 c7 43 78 28 00 00 	movq   $0x28,0x78(%rbx)
    3780:	00 
    3781:	48 c7 83 80 00 00 00 	movq   $0x3dcccccd,0x80(%rbx)
    3788:	cd cc cc 3d 
    378c:	41 0f af f0          	imul   %r8d,%esi
    3790:	29 f1                	sub    %esi,%ecx
    3792:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
    3796:	48 81 c7 78 3b 00 00 	add    $0x3b78,%rdi
    379d:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    37a1:	48 89 83 88 00 00 00 	mov    %rax,0x88(%rbx)
    37a8:	45 31 ed             	xor    %r13d,%r13d
    37ab:	c4 e2 79 59 15 00 00 	vpbroadcastq 0x0(%rip),%xmm2        # 37b4 <f_8001161d0+0x37b4>
    37b2:	00 00 
    37b4:	48 bd 00 00 00 00 f8 	movabs $0xfffffff800000000,%rbp
    37bb:	ff ff ff 
    37be:	eb 72                	jmp    3832 <f_8001161d0+0x3832>
    37c0:	c4 e3 e9 22 83 88 00 	vpinsrq $0x1,0x88(%rbx),%xmm2,%xmm0
    37c7:	00 00 01 
    37ca:	c5 f9 d4 43 50       	vpaddq 0x50(%rbx),%xmm0,%xmm0
    37cf:	c5 f9 7e c0          	vmovd  %xmm0,%eax
    37d3:	8b 4b 40             	mov    0x40(%rbx),%ecx
    37d6:	31 d2                	xor    %edx,%edx
    37d8:	89 c6                	mov    %eax,%esi
    37da:	31 ce                	xor    %ecx,%esi
    37dc:	0f 94 c2             	sete   %dl
    37df:	31 ff                	xor    %edi,%edi
    37e1:	41 89 c0             	mov    %eax,%r8d
    37e4:	41 29 c8             	sub    %ecx,%r8d
    37e7:	40 0f 93 c7          	setae  %dil
    37eb:	45 89 c1             	mov    %r8d,%r9d
    37ee:	41 31 c1             	xor    %eax,%r9d
    37f1:	41 21 f1             	and    %esi,%r9d
    37f4:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
    37fb:	c1 e2 1e             	shl    $0x1e,%edx
    37fe:	c1 e7 1d             	shl    $0x1d,%edi
    3801:	09 d7                	or     %edx,%edi
    3803:	44 09 c7             	or     %r8d,%edi
    3806:	41 c1 e9 03          	shr    $0x3,%r9d
    380a:	41 81 e1 00 00 00 10 	and    $0x10000000,%r9d
    3811:	41 09 f9             	or     %edi,%r9d
    3814:	31 c8                	xor    %ecx,%eax
    3816:	c4 e3 79 02 c1 0a    	vpblendd $0xa,%xmm1,%xmm0,%xmm0
    381c:	c5 f9 7f 43 50       	vmovdqa %xmm0,0x50(%rbx)
    3821:	4c 89 8b 10 01 00 00 	mov    %r9,0x110(%rbx)
    3828:	0f 84 37 f8 ff ff    	je     3065 <f_8001161d0+0x3065>
    382e:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
    3832:	8b 07                	mov    (%rdi),%eax
    3834:	48 89 83 30 01 00 00 	mov    %rax,0x130(%rbx)
    383b:	48 89 83 90 00 00 00 	mov    %rax,0x90(%rbx)
    3842:	8d 48 01             	lea    0x1(%rax),%ecx
    3845:	48 89 0b             	mov    %rcx,(%rbx)
    3848:	48 8b 53 68          	mov    0x68(%rbx),%rdx
    384c:	48 c7 83 28 01 00 00 	movq   $0xffffffffffffffff,0x128(%rbx)
    3853:	ff ff ff ff 
    3857:	48 39 d7             	cmp    %rdx,%rdi
    385a:	40 0f 94 c6          	sete   %sil
    385e:	f0 0f b1 0a          	lock cmpxchg %ecx,(%rdx)
    3862:	0f 94 c0             	sete   %al
    3865:	40 20 f0             	and    %sil,%al
    3868:	89 c1                	mov    %eax,%ecx
    386a:	80 f1 01             	xor    $0x1,%cl
    386d:	0f b6 c9             	movzbl %cl,%ecx
    3870:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    3874:	84 c0                	test   %al,%al
    3876:	74 b6                	je     382e <f_8001161d0+0x382e>
    3878:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
    387f:	8b b9 68 3b 00 00    	mov    0x3b68(%rcx),%edi
    3885:	8b 43 50             	mov    0x50(%rbx),%eax
    3888:	3b 43 48             	cmp    0x48(%rbx),%eax
    388b:	8b 43 60             	mov    0x60(%rbx),%eax
    388e:	49 0f 45 c5          	cmovne %r13,%rax
    3892:	48 8b b1 70 3b 00 00 	mov    0x3b70(%rcx),%rsi
    3899:	48 89 33             	mov    %rsi,(%rbx)
    389c:	48 8b 8b 90 00 00 00 	mov    0x90(%rbx),%rcx
    38a3:	ba 00 00 00 00       	mov    $0x0,%edx
    38a8:	39 cf                	cmp    %ecx,%edi
    38aa:	76 19                	jbe    38c5 <f_8001161d0+0x38c5>
    38ac:	89 c9                	mov    %ecx,%ecx
    38ae:	48 63 d1             	movslq %ecx,%rdx
    38b1:	48 c1 fa 1f          	sar    $0x1f,%rdx
    38b5:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    38bc:	ff ff ff 
    38bf:	48 21 fa             	and    %rdi,%rdx
    38c2:	48 09 ca             	or     %rcx,%rdx
    38c5:	48 89 53 08          	mov    %rdx,0x8(%rbx)
    38c9:	48 03 83 88 00 00 00 	add    0x88(%rbx),%rax
    38d0:	89 c1                	mov    %eax,%ecx
    38d2:	48 89 8b 88 00 00 00 	mov    %rcx,0x88(%rbx)
    38d9:	48 63 d2             	movslq %edx,%rdx
    38dc:	48 63 7b 78          	movslq 0x78(%rbx),%rdi
    38e0:	48 0f af fa          	imul   %rdx,%rdi
    38e4:	48 8d 14 37          	lea    (%rdi,%rsi,1),%rdx
    38e8:	48 89 93 90 00 00 00 	mov    %rdx,0x90(%rbx)
    38ef:	44 8b 43 58          	mov    0x58(%rbx),%r8d
    38f3:	49 89 c1             	mov    %rax,%r9
    38f6:	49 c1 e1 20          	shl    $0x20,%r9
    38fa:	4d 09 c1             	or     %r8,%r9
    38fd:	4c 8b 83 98 00 00 00 	mov    0x98(%rbx),%r8
    3904:	4c 89 04 37          	mov    %r8,(%rdi,%rsi,1)
    3908:	4c 8b 83 b8 00 00 00 	mov    0xb8(%rbx),%r8
    390f:	4c 89 44 37 08       	mov    %r8,0x8(%rdi,%rsi,1)
    3914:	4c 8b 83 a8 00 00 00 	mov    0xa8(%rbx),%r8
    391b:	4c 89 44 37 10       	mov    %r8,0x10(%rdi,%rsi,1)
    3920:	4c 89 4c 37 18       	mov    %r9,0x18(%rdi,%rsi,1)
    3925:	41 8b b0 bc 00 00 00 	mov    0xbc(%r8),%esi
    392c:	45 31 c0             	xor    %r8d,%r8d
    392f:	89 f7                	mov    %esi,%edi
    3931:	83 c7 fe             	add    $0xfffffffe,%edi
    3934:	41 0f 94 c0          	sete   %r8b
    3938:	45 31 c9             	xor    %r9d,%r9d
    393b:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    3941:	41 29 f2             	sub    %esi,%r10d
    3944:	41 0f 92 c1          	setb   %r9b
    3948:	41 21 f2             	and    %esi,%r10d
    394b:	41 89 fb             	mov    %edi,%r11d
    394e:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    3955:	41 c1 e0 1e          	shl    $0x1e,%r8d
    3959:	41 c1 e1 1d          	shl    $0x1d,%r9d
    395d:	45 09 d9             	or     %r11d,%r9d
    3960:	45 09 c1             	or     %r8d,%r9d
    3963:	41 c1 ea 03          	shr    $0x3,%r10d
    3967:	41 81 e2 00 00 00 10 	and    $0x10000000,%r10d
    396e:	45 09 ca             	or     %r9d,%r10d
    3971:	48 89 73 10          	mov    %rsi,0x10(%rbx)
    3975:	4c 89 93 10 01 00 00 	mov    %r10,0x110(%rbx)
    397c:	85 ff                	test   %edi,%edi
    397e:	0f 84 b1 00 00 00    	je     3a35 <f_8001161d0+0x3a35>
    3984:	31 ff                	xor    %edi,%edi
    3986:	48 85 f6             	test   %rsi,%rsi
    3989:	40 0f 95 c7          	setne  %dil
    398d:	45 31 c0             	xor    %r8d,%r8d
    3990:	41 89 f1             	mov    %esi,%r9d
    3993:	41 ff c9             	dec    %r9d
    3996:	41 0f 94 c0          	sete   %r8b
    399a:	45 31 d2             	xor    %r10d,%r10d
    399d:	4c 39 f6             	cmp    %r14,%rsi
    39a0:	41 0f 94 c2          	sete   %r10b
    39a4:	45 89 cb             	mov    %r9d,%r11d
    39a7:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    39ae:	41 c1 e0 1e          	shl    $0x1e,%r8d
    39b2:	c1 e7 1d             	shl    $0x1d,%edi
    39b5:	41 c1 e2 1c          	shl    $0x1c,%r10d
    39b9:	41 09 fa             	or     %edi,%r10d
    39bc:	45 09 da             	or     %r11d,%r10d
    39bf:	45 09 c2             	or     %r8d,%r10d
    39c2:	4c 89 93 10 01 00 00 	mov    %r10,0x110(%rbx)
    39c9:	45 85 c9             	test   %r9d,%r9d
    39cc:	0f 84 f9 00 00 00    	je     3acb <f_8001161d0+0x3acb>
    39d2:	45 31 c0             	xor    %r8d,%r8d
    39d5:	89 f7                	mov    %esi,%edi
    39d7:	83 c7 fd             	add    $0xfffffffd,%edi
    39da:	41 0f 94 c0          	sete   %r8b
    39de:	45 31 c9             	xor    %r9d,%r9d
    39e1:	83 fe 03             	cmp    $0x3,%esi
    39e4:	41 0f 93 c1          	setae  %r9b
    39e8:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    39ee:	41 29 f2             	sub    %esi,%r10d
    39f1:	41 21 f2             	and    %esi,%r10d
    39f4:	89 fe                	mov    %edi,%esi
    39f6:	81 e6 00 00 00 80    	and    $0x80000000,%esi
    39fc:	41 c1 e0 1e          	shl    $0x1e,%r8d
    3a00:	41 c1 e1 1d          	shl    $0x1d,%r9d
    3a04:	41 09 f1             	or     %esi,%r9d
    3a07:	45 09 c1             	or     %r8d,%r9d
    3a0a:	41 c1 ea 03          	shr    $0x3,%r10d
    3a0e:	41 81 e2 00 00 00 10 	and    $0x10000000,%r10d
    3a15:	45 09 ca             	or     %r9d,%r10d
    3a18:	4c 89 93 10 01 00 00 	mov    %r10,0x110(%rbx)
    3a1f:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
    3a23:	85 ff                	test   %edi,%edi
    3a25:	0f 85 dc 00 00 00    	jne    3b07 <f_8001161d0+0x3b07>
    3a2b:	01 c0                	add    %eax,%eax
    3a2d:	8d 0c 80             	lea    (%rax,%rax,4),%ecx
    3a30:	e9 ce 00 00 00       	jmp    3b03 <f_8001161d0+0x3b03>
    3a35:	48 83 ec 08          	sub    $0x8,%rsp
    3a39:	48 89 df             	mov    %rbx,%rdi
    3a3c:	31 f6                	xor    %esi,%esi
    3a3e:	31 d2                	xor    %edx,%edx
    3a40:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    3a46:	45 31 c9             	xor    %r9d,%r9d
    3a49:	6a 00                	push   $0x0
    3a4b:	e8 00 00 00 00       	call   3a50 <f_8001161d0+0x3a50>
    3a50:	48 83 c4 10          	add    $0x10,%rsp
    3a54:	8b 83 80 00 00 00    	mov    0x80(%rbx),%eax
    3a5a:	48 89 83 10 02 00 00 	mov    %rax,0x210(%rbx)
    3a61:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    3a68:	00 00 00 00 
    3a6c:	48 89 df             	mov    %rbx,%rdi
    3a6f:	be 02 00 00 00       	mov    $0x2,%esi
    3a74:	31 d2                	xor    %edx,%edx
    3a76:	31 c9                	xor    %ecx,%ecx
    3a78:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    3a7e:	e8 00 00 00 00       	call   3a83 <f_8001161d0+0x3a83>
    3a83:	48 83 ec 08          	sub    $0x8,%rsp
    3a87:	48 89 df             	mov    %rbx,%rdi
    3a8a:	31 f6                	xor    %esi,%esi
    3a8c:	31 d2                	xor    %edx,%edx
    3a8e:	b9 03 00 00 00       	mov    $0x3,%ecx
    3a93:	45 31 c0             	xor    %r8d,%r8d
    3a96:	41 b9 20 00 00 00    	mov    $0x20,%r9d
    3a9c:	6a 01                	push   $0x1
    3a9e:	e8 00 00 00 00       	call   3aa3 <f_8001161d0+0x3aa3>
    3aa3:	c4 e2 79 59 15 00 00 	vpbroadcastq 0x0(%rip),%xmm2        # 3aac <f_8001161d0+0x3aac>
    3aaa:	00 00 
    3aac:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
    3ab0:	48 83 c4 10          	add    $0x10,%rsp
    3ab4:	89 c1                	mov    %eax,%ecx
    3ab6:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
    3aba:	48 63 43 08          	movslq 0x8(%rbx),%rax
    3abe:	48 63 53 78          	movslq 0x78(%rbx),%rdx
    3ac2:	48 0f af d0          	imul   %rax,%rdx
    3ac6:	48 03 13             	add    (%rbx),%rdx
    3ac9:	eb 3c                	jmp    3b07 <f_8001161d0+0x3b07>
    3acb:	31 f6                	xor    %esi,%esi
    3acd:	48 85 c9             	test   %rcx,%rcx
    3ad0:	40 0f 94 c6          	sete   %sil
    3ad4:	89 c1                	mov    %eax,%ecx
    3ad6:	81 e1 00 00 00 80    	and    $0x80000000,%ecx
    3adc:	c1 e6 1e             	shl    $0x1e,%esi
    3adf:	48 01 f1             	add    %rsi,%rcx
    3ae2:	48 81 c1 00 00 00 20 	add    $0x20000000,%rcx
    3ae9:	48 89 8b 10 01 00 00 	mov    %rcx,0x110(%rbx)
    3af0:	89 c1                	mov    %eax,%ecx
    3af2:	c1 e9 1f             	shr    $0x1f,%ecx
    3af5:	01 c1                	add    %eax,%ecx
    3af7:	89 c8                	mov    %ecx,%eax
    3af9:	d1 e8                	shr    $1,%eax
    3afb:	81 e1 00 00 00 80    	and    $0x80000000,%ecx
    3b01:	09 c1                	or     %eax,%ecx
    3b03:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
    3b07:	48 89 13             	mov    %rdx,(%rbx)
    3b0a:	89 4a 20             	mov    %ecx,0x20(%rdx)
    3b0d:	0f 1f 00             	nopl   (%rax)
    3b10:	48 8b 4b 70          	mov    0x70(%rbx),%rcx
    3b14:	8b 01                	mov    (%rcx),%eax
    3b16:	48 89 83 30 01 00 00 	mov    %rax,0x130(%rbx)
    3b1d:	48 89 03             	mov    %rax,(%rbx)
    3b20:	8d 50 01             	lea    0x1(%rax),%edx
    3b23:	48 89 53 08          	mov    %rdx,0x8(%rbx)
    3b27:	48 8b 73 70          	mov    0x70(%rbx),%rsi
    3b2b:	48 c7 83 28 01 00 00 	movq   $0xffffffffffffffff,0x128(%rbx)
    3b32:	ff ff ff ff 
    3b36:	48 39 f1             	cmp    %rsi,%rcx
    3b39:	0f 94 c1             	sete   %cl
    3b3c:	f0 0f b1 16          	lock cmpxchg %edx,(%rsi)
    3b40:	0f 94 c0             	sete   %al
    3b43:	20 c8                	and    %cl,%al
    3b45:	89 c1                	mov    %eax,%ecx
    3b47:	80 f1 01             	xor    $0x1,%cl
    3b4a:	0f b6 c9             	movzbl %cl,%ecx
    3b4d:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
    3b51:	84 c0                	test   %al,%al
    3b53:	74 bb                	je     3b10 <f_8001161d0+0x3b10>
    3b55:	48 8b 03             	mov    (%rbx),%rax
    3b58:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
    3b5f:	8b 91 84 3b 00 00    	mov    0x3b84(%rcx),%edx
    3b65:	89 d6                	mov    %edx,%esi
    3b67:	31 c6                	xor    %eax,%esi
    3b69:	89 d7                	mov    %edx,%edi
    3b6b:	31 c7                	xor    %eax,%edi
    3b6d:	48 89 53 08          	mov    %rdx,0x8(%rbx)
    3b71:	0f 84 49 fc ff ff    	je     37c0 <f_8001161d0+0x37c0>
    3b77:	89 d7                	mov    %edx,%edi
    3b79:	29 c7                	sub    %eax,%edi
    3b7b:	c4 e2 48 f2 ff       	andn   %edi,%esi,%edi
    3b80:	21 d6                	and    %edx,%esi
    3b82:	09 fe                	or     %edi,%esi
    3b84:	0f 88 36 fc ff ff    	js     37c0 <f_8001161d0+0x37c0>
    3b8a:	48 8b 89 88 3b 00 00 	mov    0x3b88(%rcx),%rcx
    3b91:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    3b95:	48 8d 14 c5 00 00 00 	lea    0x0(,%rax,8),%rdx
    3b9c:	00 
    3b9d:	48 98                	cltq
    3b9f:	48 21 e8             	and    %rbp,%rax
    3ba2:	49 8d b7 2e a2 3f fd 	lea    -0x2c05dd2(%r15),%rsi
    3ba9:	48 21 d6             	and    %rdx,%rsi
    3bac:	48 09 c6             	or     %rax,%rsi
    3baf:	48 89 33             	mov    %rsi,(%rbx)
    3bb2:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
    3bb9:	48 89 04 31          	mov    %rax,(%rcx,%rsi,1)
    3bbd:	e9 fe fb ff ff       	jmp    37c0 <f_8001161d0+0x37c0>
