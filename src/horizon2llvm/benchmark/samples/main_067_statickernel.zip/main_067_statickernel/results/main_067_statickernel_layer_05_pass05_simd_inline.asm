
/home/leegao/meh/ultratears-main/src/horizon2llvm/benchmark/samples/main_067_statickernel/results/main_067_statickernel_layer_05_pass05_simd_inline.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <f_8001161d0>:
       0:	55                   	push   %rbp
       1:	41 57                	push   %r15
       3:	41 56                	push   %r14
       5:	41 55                	push   %r13
       7:	41 54                	push   %r12
       9:	53                   	push   %rbx
       a:	48 83 ec 18          	sub    $0x18,%rsp
       e:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
      15:	00 00 00 
      18:	48 8b 8f e8 00 00 00 	mov    0xe8(%rdi),%rcx
      1f:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
      26:	48 8d b0 d0 fe ff ff 	lea    -0x130(%rax),%rsi
      2d:	48 89 b7 00 01 00 00 	mov    %rsi,0x100(%rdi)
      34:	48 8d 50 a0          	lea    -0x60(%rax),%rdx
      38:	48 89 48 a0          	mov    %rcx,-0x60(%rax)
      3c:	48 8b 8f f0 00 00 00 	mov    0xf0(%rdi),%rcx
      43:	48 89 48 a8          	mov    %rcx,-0x58(%rax)
      47:	48 8b 8f e0 00 00 00 	mov    0xe0(%rdi),%rcx
      4e:	48 89 48 b0          	mov    %rcx,-0x50(%rax)
      52:	48 8b 8f d8 00 00 00 	mov    0xd8(%rdi),%rcx
      59:	48 89 48 b8          	mov    %rcx,-0x48(%rax)
      5d:	48 8b 8f d0 00 00 00 	mov    0xd0(%rdi),%rcx
      64:	48 89 48 c0          	mov    %rcx,-0x40(%rax)
      68:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
      6f:	48 89 48 c8          	mov    %rcx,-0x38(%rax)
      73:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
      7a:	48 89 48 d0          	mov    %rcx,-0x30(%rax)
      7e:	48 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%rcx
      85:	48 89 48 d8          	mov    %rcx,-0x28(%rax)
      89:	48 8b 8f b0 00 00 00 	mov    0xb0(%rdi),%rcx
      90:	48 89 48 e0          	mov    %rcx,-0x20(%rax)
      94:	48 8b 8f a8 00 00 00 	mov    0xa8(%rdi),%rcx
      9b:	48 89 48 e8          	mov    %rcx,-0x18(%rax)
      9f:	48 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%rcx
      a6:	48 89 48 f0          	mov    %rcx,-0x10(%rax)
      aa:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
      b1:	48 89 48 f8          	mov    %rcx,-0x8(%rax)
      b5:	48 89 97 e8 00 00 00 	mov    %rdx,0xe8(%rdi)
      bc:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
      c0:	48 89 9f a8 00 00 00 	mov    %rbx,0xa8(%rdi)
      c7:	4c 8b 3f             	mov    (%rdi),%r15
      ca:	4c 8b 77 08          	mov    0x8(%rdi),%r14
      ce:	4c 89 b7 98 00 00 00 	mov    %r14,0x98(%rdi)
      d5:	4c 89 bf a0 00 00 00 	mov    %r15,0xa0(%rdi)
      dc:	49 8d 8e 14 29 00 00 	lea    0x2914(%r14),%rcx
      e3:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
      e7:	83 fb 20             	cmp    $0x20,%ebx
      ea:	73 1d                	jae    109 <f_8001161d0+0x109>
      ec:	b9 1f 7d c3 f6       	mov    $0xf6c37d1f,%ecx
      f1:	0f a3 d9             	bt     %ebx,%ecx
      f4:	73 13                	jae    109 <f_8001161d0+0x109>
      f6:	89 d9                	mov    %ebx,%ecx
      f8:	83 e1 1f             	and    $0x1f,%ecx
      fb:	49 8b 8c cd be 6b 16 	mov    0x166bbe(%r13,%rcx,8),%rcx
     102:	00 
     103:	48 c1 e1 08          	shl    $0x8,%rcx
     107:	eb 0e                	jmp    117 <f_8001161d0+0x117>
     109:	31 d2                	xor    %edx,%edx
     10b:	83 fb 12             	cmp    $0x12,%ebx
     10e:	b9 00 03 00 00       	mov    $0x300,%ecx
     113:	48 0f 45 ca          	cmovne %rdx,%rcx
     117:	49 bb 00 00 00 00 ff 	movabs $0xffffffff00000000,%r11
     11e:	ff ff ff 
     121:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     128:	ff 7f ff 
     12b:	41 0f be 96 17 29 00 	movsbl 0x2917(%r14),%edx
     132:	00 
     133:	48 63 d2             	movslq %edx,%rdx
     136:	48 89 b7 c0 00 00 00 	mov    %rsi,0xc0(%rdi)
     13d:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
     142:	48 69 f2 48 07 00 00 	imul   $0x748,%rdx,%rsi
     149:	45 31 c9             	xor    %r9d,%r9d
     14c:	41 39 97 90 33 00 00 	cmp    %edx,0x3390(%r15)
     153:	48 bd ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rbp
     15a:	ff 7f 7f 
     15d:	4c 0f 47 ce          	cmova  %rsi,%r9
     161:	49 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r10
     168:	00 80 3f 
     16b:	48 be 00 00 00 00 01 	movabs $0x100000000,%rsi
     172:	00 00 00 
     175:	4d 03 8f 98 33 00 00 	add    0x3398(%r15),%r9
     17c:	48 c7 47 70 ff ff ff 	movq   $0xffffffffffffffff,0x70(%rdi)
     183:	ff 
     184:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 18c <f_8001161d0+0x18c>
     18b:	00 
     18c:	c5 fc 11 80 d0 fe ff 	vmovups %ymm0,-0x130(%rax)
     193:	ff 
     194:	ba ff ff ff ff       	mov    $0xffffffff,%edx
     199:	48 89 57 78          	mov    %rdx,0x78(%rdi)
     19d:	48 89 b0 f0 fe ff ff 	mov    %rsi,-0x110(%rax)
     1a4:	4c 89 98 f8 fe ff ff 	mov    %r11,-0x108(%rax)
     1ab:	4a 8d 8c 09 e8 01 00 	lea    0x1e8(%rcx,%r9,1),%rcx
     1b2:	00 
     1b3:	48 89 8f b8 00 00 00 	mov    %rcx,0xb8(%rdi)
     1ba:	48 89 90 00 ff ff ff 	mov    %rdx,-0x100(%rax)
     1c1:	4c 89 90 08 ff ff ff 	mov    %r10,-0xf8(%rax)
     1c8:	48 89 6f 58          	mov    %rbp,0x58(%rdi)
     1cc:	31 d2                	xor    %edx,%edx
     1ce:	89 de                	mov    %ebx,%esi
     1d0:	83 c6 df             	add    $0xffffffdf,%esi
     1d3:	0f 94 c2             	sete   %dl
     1d6:	31 c9                	xor    %ecx,%ecx
     1d8:	83 fb 21             	cmp    $0x21,%ebx
     1db:	0f 93 c1             	setae  %cl
     1de:	41 b9 20 00 00 00    	mov    $0x20,%r9d
     1e4:	41 29 d9             	sub    %ebx,%r9d
     1e7:	41 21 d9             	and    %ebx,%r9d
     1ea:	81 e6 00 00 00 80    	and    $0x80000000,%esi
     1f0:	c1 e2 1e             	shl    $0x1e,%edx
     1f3:	c1 e1 1d             	shl    $0x1d,%ecx
     1f6:	09 f1                	or     %esi,%ecx
     1f8:	09 d1                	or     %edx,%ecx
     1fa:	41 c1 e9 03          	shr    $0x3,%r9d
     1fe:	41 81 e1 00 00 00 10 	and    $0x10000000,%r9d
     205:	41 09 c9             	or     %ecx,%r9d
     208:	4c 89 8f 10 01 00 00 	mov    %r9,0x110(%rdi)
     20f:	4c 89 90 10 ff ff ff 	mov    %r10,-0xf0(%rax)
     216:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     21d:	00 00 00 00 
     221:	4d 8b 8d 7e 86 d5 00 	mov    0xd5867e(%r13),%r9
     228:	4c 89 4f 50          	mov    %r9,0x50(%rdi)
     22c:	49 8b 95 ae 5d d4 00 	mov    0xd45dae(%r13),%rdx
     233:	48 89 57 48          	mov    %rdx,0x48(%rdi)
     237:	49 8d 71 10          	lea    0x10(%r9),%rsi
     23b:	48 89 b0 20 ff ff ff 	mov    %rsi,-0xe0(%rax)
     242:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
     249:	4d 8b a5 b6 7e d5 00 	mov    0xd57eb6(%r13),%r12
     250:	4c 89 67 60          	mov    %r12,0x60(%rdi)
     254:	49 83 c4 10          	add    $0x10,%r12
     258:	4c 89 a7 80 00 00 00 	mov    %r12,0x80(%rdi)
     25f:	48 89 a8 48 ff ff ff 	mov    %rbp,-0xb8(%rax)
     266:	4c 89 80 50 ff ff ff 	mov    %r8,-0xb0(%rax)
     26d:	49 8d 92 00 00 80 c0 	lea    -0x3f800000(%r10),%rdx
     274:	48 89 90 74 ff ff ff 	mov    %rdx,-0x8c(%rax)
     27b:	4d 8b 95 c6 7d d5 00 	mov    0xd57dc6(%r13),%r10
     282:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
     289:	45 8b 1a             	mov    (%r10),%r11d
     28c:	4c 89 5f 40          	mov    %r11,0x40(%rdi)
     290:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
     295:	4c 89 a0 58 ff ff ff 	mov    %r12,-0xa8(%rax)
     29c:	48 89 a8 60 ff ff ff 	mov    %rbp,-0xa0(%rax)
     2a3:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     2aa:	00 
     2ab:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     2af:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     2b6:	44 89 98 70 ff ff ff 	mov    %r11d,-0x90(%rax)
     2bd:	81 e1 00 00 00 60    	and    $0x60000000,%ecx
     2c3:	81 f9 00 00 00 20    	cmp    $0x20000000,%ecx
     2c9:	0f 84 72 29 00 00    	je     2c41 <f_8001161d0+0x2c41>
     2cf:	48 89 f5             	mov    %rsi,%rbp
     2d2:	48 89 14 24          	mov    %rdx,(%rsp)
     2d6:	48 8d b0 48 ff ff ff 	lea    -0xb8(%rax),%rsi
     2dd:	4c 8d 90 60 ff ff ff 	lea    -0xa0(%rax),%r10
     2e4:	48 8d 50 80          	lea    -0x80(%rax),%rdx
     2e8:	4c 8d 80 70 ff ff ff 	lea    -0x90(%rax),%r8
     2ef:	49 8d 8d 76 6b 16 00 	lea    0x166b76(%r13),%rcx
     2f6:	48 89 8f 88 00 00 00 	mov    %rcx,0x88(%rdi)
     2fd:	89 db                	mov    %ebx,%ebx
     2ff:	48 89 9f 90 00 00 00 	mov    %rbx,0x90(%rdi)
     306:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
     30b:	48 89 8f 80 00 00 00 	mov    %rcx,0x80(%rdi)
     312:	41 0f b7 8c 5d 76 6b 	movzwl 0x166b76(%r13,%rbx,2),%ecx
     319:	16 00 
     31b:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
     31f:	4d 8d a4 8d 52 05 51 	lea    -0x2aefaae(%r13,%rcx,4),%r12
     326:	fd 
     327:	4d 89 d5             	mov    %r10,%r13
     32a:	4c 89 27             	mov    %r12,(%rdi)
     32d:	48 89 74 24 10       	mov    %rsi,0x10(%rsp)
     332:	48 89 77 48          	mov    %rsi,0x48(%rdi)
     336:	4c 89 97 d0 00 00 00 	mov    %r10,0xd0(%rdi)
     33d:	4c 89 87 c8 00 00 00 	mov    %r8,0xc8(%rdi)
     344:	48 89 97 d8 00 00 00 	mov    %rdx,0xd8(%rdi)
     34b:	81 f9 86 02 00 00    	cmp    $0x286,%ecx
     351:	7f 66                	jg     3b9 <f_8001161d0+0x3b9>
     353:	81 f9 2d 01 00 00    	cmp    $0x12d,%ecx
     359:	0f 8f f3 00 00 00    	jg     452 <f_8001161d0+0x452>
     35f:	83 f9 6f             	cmp    $0x6f,%ecx
     362:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     369:	ff 7f ff 
     36c:	4d 89 da             	mov    %r11,%r10
     36f:	0f 8f d3 03 00 00    	jg     748 <f_8001161d0+0x748>
     375:	83 f9 04             	cmp    $0x4,%ecx
     378:	0f 87 69 10 00 00    	ja     13e7 <f_8001161d0+0x13e7>
     37e:	89 c9                	mov    %ecx,%ecx
     380:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 387 <f_8001161d0+0x387>
     387:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
     38b:	48 01 d1             	add    %rdx,%rcx
     38e:	ff e1                	jmp    *%rcx
     390:	41 0f b7 9f e4 0c 00 	movzwl 0xce4(%r15),%ebx
     397:	00 
     398:	8b 8f a8 00 00 00    	mov    0xa8(%rdi),%ecx
     39e:	ba ff ff ff ff       	mov    $0xffffffff,%edx
     3a3:	01 d1                	add    %edx,%ecx
     3a5:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
     3a9:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
     3b0:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
     3b4:	e9 27 15 00 00       	jmp    18e0 <f_8001161d0+0x18e0>
     3b9:	81 f9 6d 04 00 00    	cmp    $0x46d,%ecx
     3bf:	0f 8e 32 02 00 00    	jle    5f7 <f_8001161d0+0x5f7>
     3c5:	44 8d 89 92 fb ff ff 	lea    -0x46e(%rcx),%r9d
     3cc:	41 83 f9 0c          	cmp    $0xc,%r9d
     3d0:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     3d7:	ff 7f ff 
     3da:	48 89 ee             	mov    %rbp,%rsi
     3dd:	4d 89 da             	mov    %r11,%r10
     3e0:	0f 86 81 07 00 00    	jbe    b67 <f_8001161d0+0xb67>
     3e6:	44 8d 89 36 fb ff ff 	lea    -0x4ca(%rcx),%r9d
     3ed:	41 83 f9 16          	cmp    $0x16,%r9d
     3f1:	0f 87 94 0f 00 00    	ja     138b <f_8001161d0+0x138b>
     3f7:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 3fe <f_8001161d0+0x3fe>
     3fe:	4a 63 14 89          	movslq (%rcx,%r9,4),%rdx
     402:	48 01 ca             	add    %rcx,%rdx
     405:	ff e2                	jmp    *%rdx
     407:	48 c7 47 40 b0 1e 00 	movq   $0x1eb0,0x40(%rdi)
     40e:	00 
     40f:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
     416:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
     41d:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
     421:	48 89 47 10          	mov    %rax,0x10(%rdi)
     425:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
     42a:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
     431:	48 89 07             	mov    %rax,(%rdi)
     434:	48 c7 47 18 01 00 00 	movq   $0x1,0x18(%rdi)
     43b:	00 
     43c:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     443:	00 00 00 
     446:	49 8d 85 92 18 51 fd 	lea    -0x2aee76e(%r13),%rax
     44d:	e9 32 18 00 00       	jmp    1c84 <f_8001161d0+0x1c84>
     452:	81 f9 c7 01 00 00    	cmp    $0x1c7,%ecx
     458:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     45f:	ff 7f ff 
     462:	4d 89 da             	mov    %r11,%r10
     465:	0f 8f ac 05 00 00    	jg     a17 <f_8001161d0+0xa17>
     46b:	81 f9 b1 01 00 00    	cmp    $0x1b1,%ecx
     471:	0f 8f 35 0a 00 00    	jg     eac <f_8001161d0+0xeac>
     477:	81 f9 2e 01 00 00    	cmp    $0x12e,%ecx
     47d:	0f 84 af 1d 00 00    	je     2232 <f_8001161d0+0x2232>
     483:	81 f9 66 01 00 00    	cmp    $0x166,%ecx
     489:	0f 85 92 17 00 00    	jne    1c21 <f_8001161d0+0x1c21>
     48f:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
     496:	48 8b 97 a0 00 00 00 	mov    0xa0(%rdi),%rdx
     49d:	48 8b 92 c8 1e 00 00 	mov    0x1ec8(%rdx),%rdx
     4a4:	48 89 57 08          	mov    %rdx,0x8(%rdi)
     4a8:	48 c7 87 80 00 00 00 	movq   $0x3ce0,0x80(%rdi)
     4af:	e0 3c 00 00 
     4b3:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
     4b8:	48 89 77 60          	mov    %rsi,0x60(%rdi)
     4bc:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
     4c0:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
     4c4:	4c 69 c9 e0 3c 00 00 	imul   $0x3ce0,%rcx,%r9
     4cb:	31 db                	xor    %ebx,%ebx
     4cd:	39 4a 08             	cmp    %ecx,0x8(%rdx)
     4d0:	49 0f 47 d9          	cmova  %r9,%rbx
     4d4:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
     4d8:	48 8b 8c 0b 40 3c 00 	mov    0x3c40(%rbx,%rcx,1),%rcx
     4df:	00 
     4e0:	48 89 8f b0 00 00 00 	mov    %rcx,0xb0(%rdi)
     4e7:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
     4ee:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
     4f5:	48 89 b1 88 00 00 00 	mov    %rsi,0x88(%rcx)
     4fc:	48 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rdx
     503:	ff 7f 7f 
     506:	48 89 91 90 00 00 00 	mov    %rdx,0x90(%rcx)
     50d:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     514:	00 
     515:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     519:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
     520:	00 00 00 
     523:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
     52a:	00 
     52b:	48 89 69 50          	mov    %rbp,0x50(%rcx)
     52f:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     533:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
     538:	48 c7 41 30 08 00 00 	movq   $0x8,0x30(%rcx)
     53f:	00 
     540:	48 b8 10 00 00 00 03 	movabs $0x300000010,%rax
     547:	00 00 00 
     54a:	48 89 01             	mov    %rax,(%rcx)
     54d:	48 c7 41 08 00 00 00 	movq   $0x0,0x8(%rcx)
     554:	00 
     555:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     55c:	00 
     55d:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     564:	ff ff ff 
     567:	48 8d 42 0d          	lea    0xd(%rdx),%rax
     56b:	48 89 41 18          	mov    %rax,0x18(%rcx)
     56f:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     576:	00 00 00 
     579:	48 89 41 20          	mov    %rax,0x20(%rcx)
     57d:	48 89 51 28          	mov    %rdx,0x28(%rcx)
     581:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
     588:	48 8b 14 24          	mov    (%rsp),%rdx
     58c:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
     593:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
     59a:	00 80 3f 
     59d:	48 89 41 38          	mov    %rax,0x38(%rcx)
     5a1:	48 89 41 40          	mov    %rax,0x40(%rcx)
     5a5:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     5ac:	00 00 00 
     5af:	49 8d 85 8b 0d 02 00 	lea    0x20d8b(%r13),%rax
     5b6:	48 89 47 70          	mov    %rax,0x70(%rdi)
     5ba:	4c 89 47 78          	mov    %r8,0x78(%rdi)
     5be:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
     5c5:	48 8b 57 58          	mov    0x58(%rdi),%rdx
     5c9:	48 89 51 78          	mov    %rdx,0x78(%rcx)
     5cd:	4c 89 81 80 00 00 00 	mov    %r8,0x80(%rcx)
     5d4:	48 8d 97 80 00 00 00 	lea    0x80(%rdi),%rdx
     5db:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
     5e2:	00 
     5e3:	48 89 41 70          	mov    %rax,0x70(%rcx)
     5e7:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
     5eb:	8b 71 08             	mov    0x8(%rcx),%esi
     5ee:	48 89 77 40          	mov    %rsi,0x40(%rdi)
     5f2:	e9 ae 1d 00 00       	jmp    23a5 <f_8001161d0+0x23a5>
     5f7:	81 f9 d4 02 00 00    	cmp    $0x2d4,%ecx
     5fd:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     604:	ff 7f ff 
     607:	4d 89 da             	mov    %r11,%r10
     60a:	0f 8f ad 04 00 00    	jg     abd <f_8001161d0+0xabd>
     610:	81 f9 b5 02 00 00    	cmp    $0x2b5,%ecx
     616:	0f 8f 2e 09 00 00    	jg     f4a <f_8001161d0+0xf4a>
     61c:	81 f9 87 02 00 00    	cmp    $0x287,%ecx
     622:	0f 84 e4 1e 00 00    	je     250c <f_8001161d0+0x250c>
     628:	81 f9 97 02 00 00    	cmp    $0x297,%ecx
     62e:	0f 85 ed 15 00 00    	jne    1c21 <f_8001161d0+0x1c21>
     634:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
     63b:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
     642:	48 c7 01 00 00 00 40 	movq   $0x40000000,(%rcx)
     649:	48 ba 00 00 00 00 00 	movabs $0x40000000000000,%rdx
     650:	00 40 00 
     653:	48 89 51 08          	mov    %rdx,0x8(%rcx)
     657:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     65e:	00 
     65f:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     666:	ff ff ff 
     669:	4d 89 c1             	mov    %r8,%r9
     66c:	49 89 d0             	mov    %rdx,%r8
     66f:	48 83 c2 14          	add    $0x14,%rdx
     673:	48 89 51 18          	mov    %rdx,0x18(%rcx)
     677:	48 89 6f 40          	mov    %rbp,0x40(%rdi)
     67b:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     67f:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     686:	00 
     687:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
     68e:	00 00 00 
     691:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     698:	00 00 00 
     69b:	48 89 41 20          	mov    %rax,0x20(%rcx)
     69f:	4c 89 41 28          	mov    %r8,0x28(%rcx)
     6a3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
     6a8:	48 89 41 30          	mov    %rax,0x30(%rcx)
     6ac:	49 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r8
     6b3:	00 80 3f 
     6b6:	4c 89 41 38          	mov    %r8,0x38(%rcx)
     6ba:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
     6c1:	00 00 00 
     6c4:	48 8d 80 80 0d 02 00 	lea    0x20d80(%rax),%rax
     6cb:	48 89 41 70          	mov    %rax,0x70(%rcx)
     6cf:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     6d6:	ff 7f 7f 
     6d9:	4c 89 51 78          	mov    %r10,0x78(%rcx)
     6dd:	4c 89 89 80 00 00 00 	mov    %r9,0x80(%rcx)
     6e4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
     6e9:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
     6f0:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 6f8 <f_8001161d0+0x6f8>
     6f7:	00 
     6f8:	c5 fc 11 47 60       	vmovups %ymm0,0x60(%rdi)
     6fd:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
     704:	48 8b 14 24          	mov    (%rsp),%rdx
     708:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
     70f:	4c 89 41 40          	mov    %r8,0x40(%rcx)
     713:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
     71a:	00 
     71b:	4c 89 91 90 00 00 00 	mov    %r10,0x90(%rcx)
     722:	4c 89 89 98 00 00 00 	mov    %r9,0x98(%rcx)
     729:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
     730:	00 
     731:	48 89 69 50          	mov    %rbp,0x50(%rcx)
     735:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     739:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
     73e:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
     743:	e9 db 23 00 00       	jmp    2b23 <f_8001161d0+0x2b23>
     748:	81 f9 c8 00 00 00    	cmp    $0xc8,%ecx
     74e:	0f 8f 36 04 00 00    	jg     b8a <f_8001161d0+0xb8a>
     754:	83 f9 70             	cmp    $0x70,%ecx
     757:	0f 84 dd 17 00 00    	je     1f3a <f_8001161d0+0x1f3a>
     75d:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
     763:	0f 85 b8 14 00 00    	jne    1c21 <f_8001161d0+0x1c21>
     769:	49 8b 9f c8 1e 00 00 	mov    0x1ec8(%r15),%rbx
     770:	48 89 5f 08          	mov    %rbx,0x8(%rdi)
     774:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
     779:	48 89 77 60          	mov    %rsi,0x60(%rdi)
     77d:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
     784:	00 
     785:	45 0f b6 76 08       	movzbl 0x8(%r14),%r14d
     78a:	4c 89 77 68          	mov    %r14,0x68(%rdi)
     78e:	8b 53 08             	mov    0x8(%rbx),%edx
     791:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
     795:	4d 69 ce e0 3c 00 00 	imul   $0x3ce0,%r14,%r9
     79c:	31 c9                	xor    %ecx,%ecx
     79e:	44 39 f2             	cmp    %r14d,%edx
     7a1:	ba 00 00 00 00       	mov    $0x0,%edx
     7a6:	49 0f 47 d1          	cmova  %r9,%rdx
     7aa:	48 c7 47 70 e0 3c 00 	movq   $0x3ce0,0x70(%rdi)
     7b1:	00 
     7b2:	4a 8b 94 3a 40 3c 00 	mov    0x3c40(%rdx,%r15,1),%rdx
     7b9:	00 
     7ba:	48 89 97 b0 00 00 00 	mov    %rdx,0xb0(%rdi)
     7c1:	44 89 90 70 ff ff ff 	mov    %r10d,-0x90(%rax)
     7c8:	48 89 b0 58 ff ff ff 	mov    %rsi,-0xa8(%rax)
     7cf:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     7d6:	ff 7f 7f 
     7d9:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
     7e0:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     7e7:	00 
     7e8:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     7ec:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     7f3:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     7fa:	00 00 00 00 
     7fe:	48 89 a8 20 ff ff ff 	mov    %rbp,-0xe0(%rax)
     805:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     809:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
     810:	ff 
     811:	48 c7 80 00 ff ff ff 	movq   $0x5,-0x100(%rax)
     818:	05 00 00 00 
     81c:	48 be 10 00 00 00 03 	movabs $0x300000010,%rsi
     823:	00 00 00 
     826:	48 81 c6 f0 00 00 00 	add    $0xf0,%rsi
     82d:	48 89 b0 d0 fe ff ff 	mov    %rsi,-0x130(%rax)
     834:	48 be 00 00 00 00 00 	movabs $0x60000000000000,%rsi
     83b:	00 60 00 
     83e:	48 89 b0 d8 fe ff ff 	mov    %rsi,-0x128(%rax)
     845:	48 89 17             	mov    %rdx,(%rdi)
     848:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     84f:	ff ff 00 00 
     853:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     85a:	ff ff ff 
     85d:	48 8d 55 08          	lea    0x8(%rbp),%rdx
     861:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
     868:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
     86f:	00 00 00 
     872:	48 89 90 f0 fe ff ff 	mov    %rdx,-0x110(%rax)
     879:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
     880:	48 8b 97 c0 00 00 00 	mov    0xc0(%rdi),%rdx
     887:	48 8b 34 24          	mov    (%rsp),%rsi
     88b:	48 89 b2 a4 00 00 00 	mov    %rsi,0xa4(%rdx)
     892:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
     899:	00 80 3f 
     89c:	48 89 90 08 ff ff ff 	mov    %rdx,-0xf8(%rax)
     8a3:	48 89 90 10 ff ff ff 	mov    %rdx,-0xf0(%rax)
     8aa:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     8b1:	00 00 00 
     8b4:	49 8d 95 1d 54 09 00 	lea    0x9541d(%r13),%rdx
     8bb:	48 89 57 78          	mov    %rdx,0x78(%rdi)
     8bf:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
     8c6:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
     8cd:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
     8d4:	4c 89 80 50 ff ff ff 	mov    %r8,-0xb0(%rax)
     8db:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
     8e2:	00 00 00 00 
     8e6:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
     8ed:	44 39 73 08          	cmp    %r14d,0x8(%rbx)
     8f1:	ba 00 00 00 00       	mov    $0x0,%edx
     8f6:	49 0f 47 d1          	cmova  %r9,%rdx
     8fa:	48 8b 73 10          	mov    0x10(%rbx),%rsi
     8fe:	c5 f8 10 84 16 00 2e 	vmovups 0x2e00(%rsi,%rdx,1),%xmm0
     905:	00 00 
     907:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
     90e:	ff 
     90f:	8b 73 08             	mov    0x8(%rbx),%esi
     912:	45 31 c0             	xor    %r8d,%r8d
     915:	31 d2                	xor    %edx,%edx
     917:	41 89 f2             	mov    %esi,%r10d
     91a:	45 29 f2             	sub    %r14d,%r10d
     91d:	49 0f 47 c9          	cmova  %r9,%rcx
     921:	41 0f 94 c0          	sete   %r8b
     925:	0f 93 c2             	setae  %dl
     928:	41 c1 e0 1e          	shl    $0x1e,%r8d
     92c:	c1 e2 1d             	shl    $0x1d,%edx
     92f:	44 09 c2             	or     %r8d,%edx
     932:	c4 e2 28 f2 f6       	andn   %esi,%r10d,%esi
     937:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
     93e:	44 09 d2             	or     %r10d,%edx
     941:	4c 8b 43 10          	mov    0x10(%rbx),%r8
     945:	c1 ee 03             	shr    $0x3,%esi
     948:	81 e6 00 00 00 10    	and    $0x10000000,%esi
     94e:	09 d6                	or     %edx,%esi
     950:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
     957:	49 8b 94 08 80 30 00 	mov    0x3080(%r8,%rcx,1),%rdx
     95e:	00 
     95f:	49 8b b4 08 88 30 00 	mov    0x3088(%r8,%rcx,1),%rsi
     966:	00 
     967:	48 89 77 50          	mov    %rsi,0x50(%rdi)
     96b:	48 89 90 60 ff ff ff 	mov    %rdx,-0xa0(%rax)
     972:	48 89 b0 68 ff ff ff 	mov    %rsi,-0x98(%rax)
     979:	49 8b 94 08 90 30 00 	mov    0x3090(%r8,%rcx,1),%rdx
     980:	00 
     981:	48 89 57 48          	mov    %rdx,0x48(%rdi)
     985:	41 8b 8c 08 98 30 00 	mov    0x3098(%r8,%rcx,1),%ecx
     98c:	00 
     98d:	89 88 78 ff ff ff    	mov    %ecx,-0x88(%rax)
     993:	48 8b 8f e8 00 00 00 	mov    0xe8(%rdi),%rcx
     99a:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
     99e:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
     9a2:	48 89 90 70 ff ff ff 	mov    %rdx,-0x90(%rax)
     9a9:	49 8d 85 56 08 51 fd 	lea    -0x2aef7aa(%r13),%rax
     9b0:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
     9b7:	48 89 fb             	mov    %rdi,%rbx
     9ba:	c5 f8 77             	vzeroupper
     9bd:	e8 00 00 00 00       	call   9c2 <f_8001161d0+0x9c2>
     9c2:	48 89 df             	mov    %rbx,%rdi
     9c5:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     9cc:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
     9d3:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     9da:	48 89 01             	mov    %rax,(%rcx)
     9dd:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     9e4:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     9eb:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
     9ef:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
     9f6:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     9fa:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     a00:	48 89 43 40          	mov    %rax,0x40(%rbx)
     a04:	88 51 08             	mov    %dl,0x8(%rcx)
     a07:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     a0e:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
     a12:	e9 db 1a 00 00       	jmp    24f2 <f_8001161d0+0x24f2>
     a17:	81 f9 51 02 00 00    	cmp    $0x251,%ecx
     a1d:	0f 8f cb 05 00 00    	jg     fee <f_8001161d0+0xfee>
     a23:	81 f9 c8 01 00 00    	cmp    $0x1c8,%ecx
     a29:	0f 84 63 1b 00 00    	je     2592 <f_8001161d0+0x2592>
     a2f:	81 f9 0f 02 00 00    	cmp    $0x20f,%ecx
     a35:	0f 85 e6 11 00 00    	jne    1c21 <f_8001161d0+0x1c21>
     a3b:	49 89 ec             	mov    %rbp,%r12
     a3e:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
     a45:	00 
     a46:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
     a4d:	48 c7 01 00 08 00 00 	movq   $0x800,(%rcx)
     a54:	48 c7 41 08 01 00 00 	movq   $0x1,0x8(%rcx)
     a5b:	00 
     a5c:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     a63:	ff ff ff 
     a66:	48 8d 55 0b          	lea    0xb(%rbp),%rdx
     a6a:	48 89 57 68          	mov    %rdx,0x68(%rdi)
     a6e:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     a75:	00 
     a76:	48 89 51 18          	mov    %rdx,0x18(%rcx)
     a7a:	49 bf 00 00 00 00 01 	movabs $0x100000000,%r15
     a81:	00 00 00 
     a84:	4c 89 79 20          	mov    %r15,0x20(%rcx)
     a88:	48 89 69 28          	mov    %rbp,0x28(%rcx)
     a8c:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
     a93:	00 80 3f 
     a96:	4c 89 77 70          	mov    %r14,0x70(%rdi)
     a9a:	ba ff ff ff ff       	mov    $0xffffffff,%edx
     a9f:	48 89 51 30          	mov    %rdx,0x30(%rcx)
     aa3:	4c 89 71 38          	mov    %r14,0x38(%rcx)
     aa7:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     aae:	00 00 00 
     ab1:	49 8d 9d 07 a8 04 00 	lea    0x4a807(%r13),%rbx
     ab8:	e9 af 15 00 00       	jmp    206c <f_8001161d0+0x206c>
     abd:	81 f9 ac 03 00 00    	cmp    $0x3ac,%ecx
     ac3:	0f 8f 9e 06 00 00    	jg     1167 <f_8001161d0+0x1167>
     ac9:	81 f9 d5 02 00 00    	cmp    $0x2d5,%ecx
     acf:	0f 84 45 1d 00 00    	je     281a <f_8001161d0+0x281a>
     ad5:	81 f9 f3 02 00 00    	cmp    $0x2f3,%ecx
     adb:	0f 85 40 11 00 00    	jne    1c21 <f_8001161d0+0x1c21>
     ae1:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
     ae8:	00 
     ae9:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
     af0:	48 c7 03 00 02 00 00 	movq   $0x200,(%rbx)
     af7:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
     afe:	00 40 00 
     b01:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     b05:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
     b0c:	00 
     b0d:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     b14:	ff ff ff 
     b17:	48 8d 4a 13          	lea    0x13(%rdx),%rcx
     b1b:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
     b1f:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     b26:	00 00 00 
     b29:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
     b2d:	48 89 53 28          	mov    %rdx,0x28(%rbx)
     b31:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
     b37:	4c 89 47 68          	mov    %r8,0x68(%rdi)
     b3b:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
     b42:	00 80 3f 
     b45:	4c 89 77 70          	mov    %r14,0x70(%rdi)
     b49:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
     b4d:	48 83 c3 38          	add    $0x38,%rbx
     b51:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
     b58:	00 00 00 
     b5b:	4c 8d 8a f9 7a ff ff 	lea    -0x8507(%rdx),%r9
     b62:	e9 0c 1f 00 00       	jmp    2a73 <f_8001161d0+0x2a73>
     b67:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # b6e <f_8001161d0+0xb6e>
     b6e:	4a 63 14 89          	movslq (%rcx,%r9,4),%rdx
     b72:	48 01 ca             	add    %rcx,%rdx
     b75:	ff e2                	jmp    *%rdx
     b77:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     b7e:	00 00 00 
     b81:	4d 8d 75 e0          	lea    -0x20(%r13),%r14
     b85:	e9 35 09 00 00       	jmp    14bf <f_8001161d0+0x14bf>
     b8a:	81 f9 c9 00 00 00    	cmp    $0xc9,%ecx
     b90:	0f 84 3c 14 00 00    	je     1fd2 <f_8001161d0+0x1fd2>
     b96:	81 f9 d9 00 00 00    	cmp    $0xd9,%ecx
     b9c:	0f 85 7f 10 00 00    	jne    1c21 <f_8001161d0+0x1c21>
     ba2:	4d 8b 8f c8 1e 00 00 	mov    0x1ec8(%r15),%r9
     ba9:	4c 89 4f 08          	mov    %r9,0x8(%rdi)
     bad:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
     bb2:	48 89 77 60          	mov    %rsi,0x60(%rdi)
     bb6:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
     bbd:	00 
     bbe:	41 0f b6 5e 08       	movzbl 0x8(%r14),%ebx
     bc3:	48 89 5f 70          	mov    %rbx,0x70(%rdi)
     bc7:	49 89 ef             	mov    %rbp,%r15
     bca:	41 0f b7 ae 14 29 00 	movzwl 0x2914(%r14),%ebp
     bd1:	00 
     bd2:	83 e5 40             	and    $0x40,%ebp
     bd5:	41 8b 51 08          	mov    0x8(%r9),%edx
     bd9:	4d 8b 71 10          	mov    0x10(%r9),%r14
     bdd:	31 c9                	xor    %ecx,%ecx
     bdf:	39 da                	cmp    %ebx,%edx
     be1:	ba 00 00 00 00       	mov    $0x0,%edx
     be6:	48 0f 47 d3          	cmova  %rbx,%rdx
     bea:	48 c7 47 78 e0 3c 00 	movq   $0x3ce0,0x78(%rdi)
     bf1:	00 
     bf2:	48 89 97 88 00 00 00 	mov    %rdx,0x88(%rdi)
     bf9:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
     c00:	4a 8b 94 32 40 3c 00 	mov    0x3c40(%rdx,%r14,1),%rdx
     c07:	00 
     c08:	48 89 97 b0 00 00 00 	mov    %rdx,0xb0(%rdi)
     c0f:	4c 8b b7 a0 00 00 00 	mov    0xa0(%rdi),%r14
     c16:	4d 8b b6 b8 1e 00 00 	mov    0x1eb8(%r14),%r14
     c1d:	44 89 90 70 ff ff ff 	mov    %r10d,-0x90(%rax)
     c24:	48 89 b0 58 ff ff ff 	mov    %rsi,-0xa8(%rax)
     c2b:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
     c32:	ff 7f 7f 
     c35:	4c 89 98 60 ff ff ff 	mov    %r11,-0xa0(%rax)
     c3c:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     c43:	00 
     c44:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     c48:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     c4f:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     c53:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
     c5a:	ff 
     c5b:	41 80 be b0 06 00 00 	cmpb   $0x0,0x6b0(%r14)
     c62:	00 
     c63:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     c6a:	00 00 00 00 
     c6e:	4c 89 b8 20 ff ff ff 	mov    %r15,-0xe0(%rax)
     c75:	48 c7 80 00 ff ff ff 	movq   $0x4,-0x100(%rax)
     c7c:	04 00 00 00 
     c80:	48 89 17             	mov    %rdx,(%rdi)
     c83:	0f 95 c2             	setne  %dl
     c86:	c1 ed 06             	shr    $0x6,%ebp
     c89:	40 20 d5             	and    %dl,%bpl
     c8c:	c7 80 d8 fe ff ff 00 	movl   $0x0,-0x128(%rax)
     c93:	00 00 00 
     c96:	40 0f b6 d5          	movzbl %bpl,%edx
     c9a:	c1 e2 1a             	shl    $0x1a,%edx
     c9d:	81 ca 01 00 40 00    	or     $0x400001,%edx
     ca3:	89 90 dc fe ff ff    	mov    %edx,-0x124(%rax)
     ca9:	48 ba 10 00 00 00 03 	movabs $0x300000010,%rdx
     cb0:	00 00 00 
     cb3:	48 89 90 d0 fe ff ff 	mov    %rdx,-0x130(%rax)
     cba:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     cc1:	ff ff 00 00 
     cc5:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     ccc:	ff ff ff 
     ccf:	48 8d 55 07          	lea    0x7(%rbp),%rdx
     cd3:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
     cda:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
     ce1:	00 00 00 
     ce4:	48 89 90 f0 fe ff ff 	mov    %rdx,-0x110(%rax)
     ceb:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
     cf2:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
     cf9:	00 80 3f 
     cfc:	48 89 90 08 ff ff ff 	mov    %rdx,-0xf8(%rax)
     d03:	48 89 90 10 ff ff ff 	mov    %rdx,-0xf0(%rax)
     d0a:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     d11:	00 00 00 
     d14:	49 8d 95 00 54 09 00 	lea    0x95400(%r13),%rdx
     d1b:	48 89 57 68          	mov    %rdx,0x68(%rdi)
     d1f:	48 8b b7 c0 00 00 00 	mov    0xc0(%rdi),%rsi
     d26:	4c 8b 14 24          	mov    (%rsp),%r10
     d2a:	4c 89 96 a4 00 00 00 	mov    %r10,0xa4(%rsi)
     d31:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
     d38:	4c 89 98 48 ff ff ff 	mov    %r11,-0xb8(%rax)
     d3f:	4c 89 80 50 ff ff ff 	mov    %r8,-0xb0(%rax)
     d46:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
     d4d:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
     d54:	00 00 00 00 
     d58:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
     d5f:	48 69 d3 e0 3c 00 00 	imul   $0x3ce0,%rbx,%rdx
     d66:	41 39 59 08          	cmp    %ebx,0x8(%r9)
     d6a:	48 0f 46 d1          	cmovbe %rcx,%rdx
     d6e:	49 8b 71 10          	mov    0x10(%r9),%rsi
     d72:	c5 f8 10 84 16 00 2e 	vmovups 0x2e00(%rsi,%rdx,1),%xmm0
     d79:	00 00 
     d7b:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
     d82:	ff 
     d83:	48 8b 57 08          	mov    0x8(%rdi),%rdx
     d87:	48 8b 77 70          	mov    0x70(%rdi),%rsi
     d8b:	8b 42 08             	mov    0x8(%rdx),%eax
     d8e:	45 31 c9             	xor    %r9d,%r9d
     d91:	41 89 c2             	mov    %eax,%r10d
     d94:	41 31 f2             	xor    %esi,%r10d
     d97:	41 0f 94 c1          	sete   %r9b
     d9b:	45 31 c0             	xor    %r8d,%r8d
     d9e:	41 89 c3             	mov    %eax,%r11d
     da1:	41 29 f3             	sub    %esi,%r11d
     da4:	89 f6                	mov    %esi,%esi
     da6:	48 0f 46 f1          	cmovbe %rcx,%rsi
     daa:	41 0f 93 c0          	setae  %r8b
     dae:	44 31 d8             	xor    %r11d,%eax
     db1:	44 21 d0             	and    %r10d,%eax
     db4:	41 c1 e1 1e          	shl    $0x1e,%r9d
     db8:	41 c1 e0 1d          	shl    $0x1d,%r8d
     dbc:	45 09 c8             	or     %r9d,%r8d
     dbf:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
     dc3:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
     dca:	45 09 d8             	or     %r11d,%r8d
     dcd:	c1 e8 03             	shr    $0x3,%eax
     dd0:	25 00 00 00 10       	and    $0x10000000,%eax
     dd5:	44 09 c0             	or     %r8d,%eax
     dd8:	48 89 87 10 01 00 00 	mov    %rax,0x110(%rdi)
     ddf:	8b 47 78             	mov    0x78(%rdi),%eax
     de2:	48 0f af c6          	imul   %rsi,%rax
     de6:	48 8b 94 08 80 30 00 	mov    0x3080(%rax,%rcx,1),%rdx
     ded:	00 
     dee:	48 8b b4 08 88 30 00 	mov    0x3088(%rax,%rcx,1),%rsi
     df5:	00 
     df6:	48 89 77 50          	mov    %rsi,0x50(%rdi)
     dfa:	4c 8b 87 d0 00 00 00 	mov    0xd0(%rdi),%r8
     e01:	49 89 10             	mov    %rdx,(%r8)
     e04:	49 89 70 08          	mov    %rsi,0x8(%r8)
     e08:	48 8b 94 08 90 30 00 	mov    0x3090(%rax,%rcx,1),%rdx
     e0f:	00 
     e10:	48 89 57 48          	mov    %rdx,0x48(%rdi)
     e14:	8b 84 08 98 30 00 00 	mov    0x3098(%rax,%rcx,1),%eax
     e1b:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
     e22:	89 41 08             	mov    %eax,0x8(%rcx)
     e25:	48 8b 87 e8 00 00 00 	mov    0xe8(%rdi),%rax
     e2c:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
     e30:	48 89 47 40          	mov    %rax,0x40(%rdi)
     e34:	48 89 11             	mov    %rdx,(%rcx)
     e37:	49 8d 85 e6 09 51 fd 	lea    -0x2aef61a(%r13),%rax
     e3e:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
     e45:	48 89 fb             	mov    %rdi,%rbx
     e48:	c5 f8 77             	vzeroupper
     e4b:	e8 00 00 00 00       	call   e50 <f_8001161d0+0xe50>
     e50:	48 89 df             	mov    %rbx,%rdi
     e53:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     e5a:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
     e61:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     e68:	48 89 01             	mov    %rax,(%rcx)
     e6b:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     e72:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     e79:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
     e7d:	48 89 53 48          	mov    %rdx,0x48(%rbx)
     e81:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
     e88:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     e8c:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     e92:	48 89 43 40          	mov    %rax,0x40(%rbx)
     e96:	88 51 08             	mov    %dl,0x8(%rcx)
     e99:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     ea0:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
     ea4:	89 41 24             	mov    %eax,0x24(%rcx)
     ea7:	e9 95 1d 00 00       	jmp    2c41 <f_8001161d0+0x2c41>
     eac:	81 f9 b2 01 00 00    	cmp    $0x1b2,%ecx
     eb2:	0f 84 69 1a 00 00    	je     2921 <f_8001161d0+0x2921>
     eb8:	81 f9 b8 01 00 00    	cmp    $0x1b8,%ecx
     ebe:	0f 85 5d 0d 00 00    	jne    1c21 <f_8001161d0+0x1c21>
     ec4:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
     ecb:	00 
     ecc:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
     ed3:	48 c7 03 08 00 00 00 	movq   $0x8,(%rbx)
     eda:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
     ee1:	00 40 00 
     ee4:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     ee8:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
     eef:	00 
     ef0:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     ef7:	ff ff ff 
     efa:	48 8d 4a 15          	lea    0x15(%rdx),%rcx
     efe:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
     f02:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     f09:	00 00 00 
     f0c:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
     f10:	48 89 53 28          	mov    %rdx,0x28(%rbx)
     f14:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
     f1a:	4c 89 47 68          	mov    %r8,0x68(%rdi)
     f1e:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
     f25:	00 80 3f 
     f28:	4c 89 77 70          	mov    %r14,0x70(%rdi)
     f2c:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
     f30:	48 83 c3 38          	add    $0x38,%rbx
     f34:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
     f3b:	00 00 00 
     f3e:	4c 8d 8a af 2c 05 00 	lea    0x52caf(%rdx),%r9
     f45:	e9 29 1b 00 00       	jmp    2a73 <f_8001161d0+0x2a73>
     f4a:	81 f9 b6 02 00 00    	cmp    $0x2b6,%ecx
     f50:	0f 84 23 1a 00 00    	je     2979 <f_8001161d0+0x2979>
     f56:	81 f9 c5 02 00 00    	cmp    $0x2c5,%ecx
     f5c:	0f 85 bf 0c 00 00    	jne    1c21 <f_8001161d0+0x1c21>
     f62:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
     f69:	00 
     f6a:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
     f71:	48 b9 01 00 00 00 04 	movabs $0x400000001,%rcx
     f78:	00 00 00 
     f7b:	48 89 0b             	mov    %rcx,(%rbx)
     f7e:	48 b9 00 00 00 00 02 	movabs $0x80200000000,%rcx
     f85:	08 00 00 
     f88:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     f8c:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
     f93:	00 
     f94:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     f9b:	ff ff ff 
     f9e:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
     fa2:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
     fa6:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     fad:	00 00 00 
     fb0:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
     fb4:	48 89 53 28          	mov    %rdx,0x28(%rbx)
     fb8:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
     fbe:	4c 89 47 68          	mov    %r8,0x68(%rdi)
     fc2:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
     fc9:	00 80 3f 
     fcc:	4c 89 77 70          	mov    %r14,0x70(%rdi)
     fd0:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
     fd4:	48 83 c3 38          	add    $0x38,%rbx
     fd8:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
     fdf:	00 00 00 
     fe2:	4c 8d 8a 88 db 0a 00 	lea    0xadb88(%rdx),%r9
     fe9:	e9 85 1a 00 00       	jmp    2a73 <f_8001161d0+0x2a73>
     fee:	81 f9 52 02 00 00    	cmp    $0x252,%ecx
     ff4:	0f 84 02 1a 00 00    	je     29fc <f_8001161d0+0x29fc>
     ffa:	81 f9 61 02 00 00    	cmp    $0x261,%ecx
    1000:	0f 85 1b 0c 00 00    	jne    1c21 <f_8001161d0+0x1c21>
    1006:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    100d:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
    1014:	48 ba 00 00 00 00 0f 	movabs $0xf00000000,%rdx
    101b:	00 00 00 
    101e:	48 89 51 14          	mov    %rdx,0x14(%rcx)
    1022:	48 ba 00 00 00 00 ff 	movabs $0xffff00000000,%rdx
    1029:	ff 00 00 
    102c:	48 81 ca 00 00 40 08 	or     $0x8400000,%rdx
    1033:	48 89 51 0c          	mov    %rdx,0xc(%rcx)
    1037:	48 8b 97 a0 00 00 00 	mov    0xa0(%rdi),%rdx
    103e:	8b 92 8c 3a 00 00    	mov    0x3a8c(%rdx),%edx
    1044:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    1049:	48 89 77 60          	mov    %rsi,0x60(%rdi)
    104d:	48 89 6f 40          	mov    %rbp,0x40(%rdi)
    1051:	48 c7 41 04 00 00 00 	movq   $0x0,0x4(%rcx)
    1058:	00 
    1059:	4c 8b 4f 78          	mov    0x78(%rdi),%r9
    105d:	4c 89 49 1c          	mov    %r9,0x1c(%rcx)
    1061:	41 89 d2             	mov    %edx,%r10d
    1064:	41 c1 e2 0d          	shl    $0xd,%r10d
    1068:	41 81 e2 00 00 00 40 	and    $0x40000000,%r10d
    106f:	49 81 f2 00 00 00 40 	xor    $0x40000000,%r10
    1076:	4c 89 97 10 01 00 00 	mov    %r10,0x110(%rdi)
    107d:	48 c7 47 68 01 00 00 	movq   $0x1,0x68(%rdi)
    1084:	00 
    1085:	c7 41 34 00 00 00 00 	movl   $0x0,0x34(%rcx)
    108c:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1093:	00 
    1094:	48 c7 41 24 01 00 00 	movq   $0x1,0x24(%rcx)
    109b:	00 
    109c:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    10a0:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    10a7:	00 00 00 
    10aa:	44 89 49 2c          	mov    %r9d,0x2c(%rcx)
    10ae:	c7 41 30 01 00 00 00 	movl   $0x1,0x30(%rcx)
    10b5:	c1 ea 08             	shr    $0x8,%edx
    10b8:	81 e2 00 02 00 00    	and    $0x200,%edx
    10be:	81 ca 00 00 00 40    	or     $0x40000000,%edx
    10c4:	89 11                	mov    %edx,(%rcx)
    10c6:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    10cd:	00 00 00 
    10d0:	48 05 f0 85 00 00    	add    $0x85f0,%rax
    10d6:	48 89 47 70          	mov    %rax,0x70(%rdi)
    10da:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
    10e1:	00 80 3f 
    10e4:	48 89 51 38          	mov    %rdx,0x38(%rcx)
    10e8:	48 89 51 40          	mov    %rdx,0x40(%rcx)
    10ec:	48 8b 97 c0 00 00 00 	mov    0xc0(%rdi),%rdx
    10f3:	4c 8b 0c 24          	mov    (%rsp),%r9
    10f7:	4c 89 8a a4 00 00 00 	mov    %r9,0xa4(%rdx)
    10fe:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
    1105:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    110c:	48 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rdx
    1113:	ff 7f 7f 
    1116:	48 89 51 78          	mov    %rdx,0x78(%rcx)
    111a:	4c 89 81 80 00 00 00 	mov    %r8,0x80(%rcx)
    1121:	48 89 b1 88 00 00 00 	mov    %rsi,0x88(%rcx)
    1128:	48 89 91 90 00 00 00 	mov    %rdx,0x90(%rcx)
    112f:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1133:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    1138:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    113f:	00 
    1140:	48 89 41 70          	mov    %rax,0x70(%rcx)
    1144:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    114b:	48 c7 40 48 00 00 00 	movq   $0x0,0x48(%rax)
    1152:	00 
    1153:	48 89 68 50          	mov    %rbp,0x50(%rax)
    1157:	4c 8b 5f 48          	mov    0x48(%rdi),%r11
    115b:	4c 8b af d0 00 00 00 	mov    0xd0(%rdi),%r13
    1162:	e9 bc 19 00 00       	jmp    2b23 <f_8001161d0+0x2b23>
    1167:	81 f9 ad 03 00 00    	cmp    $0x3ad,%ecx
    116d:	0f 84 90 1d 00 00    	je     2f03 <f_8001161d0+0x2f03>
    1173:	81 f9 12 04 00 00    	cmp    $0x412,%ecx
    1179:	0f 85 a2 0a 00 00    	jne    1c21 <f_8001161d0+0x1c21>
    117f:	48 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%rcx
    1186:	48 8b 89 c8 1e 00 00 	mov    0x1ec8(%rcx),%rcx
    118d:	48 89 4f 70          	mov    %rcx,0x70(%rdi)
    1191:	48 bb 00 00 00 00 01 	movabs $0x100000000,%rbx
    1198:	00 00 00 
    119b:	48 89 1f             	mov    %rbx,(%rdi)
    119e:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    11a2:	4c 8b 8f 00 01 00 00 	mov    0x100(%rdi),%r9
    11a9:	49 c7 01 02 00 00 00 	movq   $0x2,(%r9)
    11b0:	48 ba 00 00 00 00 00 	movabs $0x40000000000000,%rdx
    11b7:	00 40 00 
    11ba:	48 ff c2             	inc    %rdx
    11bd:	49 89 51 08          	mov    %rdx,0x8(%r9)
    11c1:	49 89 59 20          	mov    %rbx,0x20(%r9)
    11c5:	48 89 ee             	mov    %rbp,%rsi
    11c8:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    11cf:	ff ff ff 
    11d2:	49 89 69 28          	mov    %rbp,0x28(%r9)
    11d6:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    11dd:	00 00 00 
    11e0:	4c 89 6f 68          	mov    %r13,0x68(%rdi)
    11e4:	4d 89 81 80 00 00 00 	mov    %r8,0x80(%r9)
    11eb:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    11f0:	49 89 91 88 00 00 00 	mov    %rdx,0x88(%r9)
    11f7:	48 8b 97 c0 00 00 00 	mov    0xc0(%rdi),%rdx
    11fe:	4c 8b 1c 24          	mov    (%rsp),%r11
    1202:	4c 89 9a a4 00 00 00 	mov    %r11,0xa4(%rdx)
    1209:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
    1210:	ff 7f 7f 
    1213:	4d 89 99 90 00 00 00 	mov    %r11,0x90(%r9)
    121a:	4d 89 81 98 00 00 00 	mov    %r8,0x98(%r9)
    1221:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 1229 <f_8001161d0+0x1229>
    1228:	00 
    1229:	c5 fc 11 47 78       	vmovups %ymm0,0x78(%rdi)
    122e:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1235:	00 
    1236:	45 89 91 a0 00 00 00 	mov    %r10d,0xa0(%r9)
    123d:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    1244:	0f b6 50 08          	movzbl 0x8(%rax),%edx
    1248:	48 89 57 40          	mov    %rdx,0x40(%rdi)
    124c:	41 c7 81 bc 00 00 00 	movl   $0x3,0xbc(%r9)
    1253:	03 00 00 00 
    1257:	49 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%r9)
    125e:	00 
    125f:	48 8d 45 16          	lea    0x16(%rbp),%rax
    1263:	49 89 41 18          	mov    %rax,0x18(%r9)
    1267:	49 c7 41 68 00 00 00 	movq   $0x0,0x68(%r9)
    126e:	00 
    126f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    1274:	49 89 41 30          	mov    %rax,0x30(%r9)
    1278:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    127f:	00 80 3f 
    1282:	49 89 41 38          	mov    %rax,0x38(%r9)
    1286:	49 89 41 40          	mov    %rax,0x40(%r9)
    128a:	49 c7 41 48 00 00 00 	movq   $0x0,0x48(%r9)
    1291:	00 
    1292:	49 89 71 50          	mov    %rsi,0x50(%r9)
    1296:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    129a:	c4 c1 78 11 41 58    	vmovups %xmm0,0x58(%r9)
    12a0:	4d 89 69 70          	mov    %r13,0x70(%r9)
    12a4:	4d 89 59 78          	mov    %r11,0x78(%r9)
    12a8:	48 69 c2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rax
    12af:	45 31 c0             	xor    %r8d,%r8d
    12b2:	39 51 08             	cmp    %edx,0x8(%rcx)
    12b5:	49 0f 46 c0          	cmovbe %r8,%rax
    12b9:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    12bd:	48 8b b4 08 b8 30 00 	mov    0x30b8(%rax,%rcx,1),%rsi
    12c4:	00 
    12c5:	48 89 77 60          	mov    %rsi,0x60(%rdi)
    12c9:	48 8b 84 08 b0 30 00 	mov    0x30b0(%rax,%rcx,1),%rax
    12d0:	00 
    12d1:	48 8b 4f 48          	mov    0x48(%rdi),%rcx
    12d5:	48 89 01             	mov    %rax,(%rcx)
    12d8:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    12dc:	48 8b 47 70          	mov    0x70(%rdi),%rax
    12e0:	44 8b 48 08          	mov    0x8(%rax),%r9d
    12e4:	4c 89 4f 48          	mov    %r9,0x48(%rdi)
    12e8:	48 8b 48 10          	mov    0x10(%rax),%rcx
    12ec:	48 89 4f 58          	mov    %rcx,0x58(%rdi)
    12f0:	8b 77 40             	mov    0x40(%rdi),%esi
    12f3:	48 69 f6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rsi
    12fa:	45 31 db             	xor    %r11d,%r11d
    12fd:	45 31 d2             	xor    %r10d,%r10d
    1300:	44 89 cb             	mov    %r9d,%ebx
    1303:	29 d3                	sub    %edx,%ebx
    1305:	49 0f 46 f0          	cmovbe %r8,%rsi
    1309:	41 0f 94 c3          	sete   %r11b
    130d:	41 0f 93 c2          	setae  %r10b
    1311:	41 c1 e3 1e          	shl    $0x1e,%r11d
    1315:	41 c1 e2 1d          	shl    $0x1d,%r10d
    1319:	45 09 da             	or     %r11d,%r10d
    131c:	c4 c2 60 f2 d1       	andn   %r9d,%ebx,%edx
    1321:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    1327:	41 09 da             	or     %ebx,%r10d
    132a:	c1 ea 03             	shr    $0x3,%edx
    132d:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    1333:	44 09 d2             	or     %r10d,%edx
    1336:	48 89 97 10 01 00 00 	mov    %rdx,0x110(%rdi)
    133d:	48 8b 94 0e 30 33 00 	mov    0x3330(%rsi,%rcx,1),%rdx
    1344:	00 
    1345:	4c 8b 84 0e 38 33 00 	mov    0x3338(%rsi,%rcx,1),%r8
    134c:	00 
    134d:	48 89 57 50          	mov    %rdx,0x50(%rdi)
    1351:	4c 8b 8f d0 00 00 00 	mov    0xd0(%rdi),%r9
    1358:	49 89 11             	mov    %rdx,(%r9)
    135b:	4d 89 41 08          	mov    %r8,0x8(%r9)
    135f:	8b 94 0e 48 33 00 00 	mov    0x3348(%rsi,%rcx,1),%edx
    1366:	48 8b 8c 0e 40 33 00 	mov    0x3340(%rsi,%rcx,1),%rcx
    136d:	00 
    136e:	48 8b b7 c8 00 00 00 	mov    0xc8(%rdi),%rsi
    1375:	48 89 0e             	mov    %rcx,(%rsi)
    1378:	89 56 08             	mov    %edx,0x8(%rsi)
    137b:	8b 48 44             	mov    0x44(%rax),%ecx
    137e:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    1382:	48 83 c0 30          	add    $0x30,%rax
    1386:	e9 76 0b 00 00       	jmp    1f01 <f_8001161d0+0x1f01>
    138b:	81 f9 1a 05 00 00    	cmp    $0x51a,%ecx
    1391:	0f 85 8a 08 00 00    	jne    1c21 <f_8001161d0+0x1c21>
    1397:	b8 e8 0a 00 00       	mov    $0xae8,%eax
    139c:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
    13a3:	48 89 07             	mov    %rax,(%rdi)
    13a6:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    13ad:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    13b4:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    13b8:	48 89 47 10          	mov    %rax,0x10(%rdi)
    13bc:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    13c3:	00 00 00 
    13c6:	49 8d 85 ca 19 51 fd 	lea    -0x2aee636(%r13),%rax
    13cd:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    13d4:	48 89 fb             	mov    %rdi,%rbx
    13d7:	c5 f8 77             	vzeroupper
    13da:	e8 00 00 00 00       	call   13df <f_8001161d0+0x13df>
    13df:	48 89 df             	mov    %rbx,%rdi
    13e2:	e9 5a 18 00 00       	jmp    2c41 <f_8001161d0+0x2c41>
    13e7:	83 f9 61             	cmp    $0x61,%ecx
    13ea:	0f 85 31 08 00 00    	jne    1c21 <f_8001161d0+0x1c21>
    13f0:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    13f7:	00 
    13f8:	48 c7 80 d0 fe ff ff 	movq   $0x8,-0x130(%rax)
    13ff:	08 00 00 00 
    1403:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    140a:	00 40 00 
    140d:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    1414:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    141b:	ff ff 00 00 
    141f:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    1426:	ff ff ff 
    1429:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    142d:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    1434:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    143b:	00 00 00 
    143e:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
    1442:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    1449:	48 89 90 f8 fe ff ff 	mov    %rdx,-0x108(%rax)
    1450:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    1457:	00 80 3f 
    145a:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    145e:	48 8d 88 00 ff ff ff 	lea    -0x100(%rax),%rcx
    1465:	48 8d 98 08 ff ff ff 	lea    -0xf8(%rax),%rbx
    146c:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
    1473:	00 00 00 
    1476:	4c 8d 8a ab f2 0c 00 	lea    0xcf2ab(%rdx),%r9
    147d:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    1483:	e9 eb 15 00 00       	jmp    2a73 <f_8001161d0+0x2a73>
    1488:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    148f:	00 00 00 
    1492:	4d 8d b5 0b d1 09 00 	lea    0x9d10b(%r13),%r14
    1499:	eb 24                	jmp    14bf <f_8001161d0+0x14bf>
    149b:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    14a2:	00 00 00 
    14a5:	4d 8d b5 2d 8c 01 00 	lea    0x18c2d(%r13),%r14
    14ac:	eb 11                	jmp    14bf <f_8001161d0+0x14bf>
    14ae:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    14b5:	00 00 00 
    14b8:	4d 8d b5 4b 4f 0a 00 	lea    0xa4f4b(%r13),%r14
    14bf:	4c 89 77 68          	mov    %r14,0x68(%rdi)
    14c3:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    14ca:	c7 03 00 00 00 10    	movl   $0x10000000,(%rbx)
    14d0:	4c 8b bf a0 00 00 00 	mov    0xa0(%rdi),%r15
    14d7:	49 8b 8f f0 31 00 00 	mov    0x31f0(%r15),%rcx
    14de:	48 89 0f             	mov    %rcx,(%rdi)
    14e1:	48 ba 10 00 00 00 03 	movabs $0x300000010,%rdx
    14e8:	00 00 00 
    14eb:	4c 8d 4a f0          	lea    -0x10(%rdx),%r9
    14ef:	4c 89 4b 14          	mov    %r9,0x14(%rbx)
    14f3:	48 c7 47 78 01 00 00 	movq   $0x1,0x78(%rdi)
    14fa:	00 
    14fb:	48 83 c2 f6          	add    $0xfffffffffffffff6,%rdx
    14ff:	48 89 53 04          	mov    %rdx,0x4(%rbx)
    1503:	48 8b 57 70          	mov    0x70(%rdi),%rdx
    1507:	48 89 53 2c          	mov    %rdx,0x2c(%rbx)
    150b:	48 ba 00 00 00 00 ff 	movabs $0xffff00000000,%rdx
    1512:	ff 00 00 
    1515:	48 89 53 0c          	mov    %rdx,0xc(%rbx)
    1519:	4c 89 47 70          	mov    %r8,0x70(%rdi)
    151d:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    1522:	48 89 53 1c          	mov    %rdx,0x1c(%rbx)
    1526:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    152b:	4c 89 5f 60          	mov    %r11,0x60(%rdi)
    152f:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
    1536:	00 80 3f 
    1539:	48 89 53 38          	mov    %rdx,0x38(%rbx)
    153d:	48 89 53 40          	mov    %rdx,0x40(%rbx)
    1541:	4c 8b 24 24          	mov    (%rsp),%r12
    1545:	4c 89 67 48          	mov    %r12,0x48(%rdi)
    1549:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    154d:	48 c7 43 24 01 00 00 	movq   $0x1,0x24(%rbx)
    1554:	00 
    1555:	c7 43 34 00 00 00 00 	movl   $0x0,0x34(%rbx)
    155c:	4c 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%r9
    1563:	4d 89 a1 a4 00 00 00 	mov    %r12,0xa4(%r9)
    156a:	4c 89 83 98 00 00 00 	mov    %r8,0x98(%rbx)
    1571:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1575:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    157c:	00 
    157d:	44 89 93 a0 00 00 00 	mov    %r10d,0xa0(%rbx)
    1584:	c7 83 bc 00 00 00 01 	movl   $0x1,0xbc(%rbx)
    158b:	00 00 00 
    158e:	48 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rax
    1595:	ff 7f 7f 
    1598:	48 89 43 78          	mov    %rax,0x78(%rbx)
    159c:	4c 89 83 80 00 00 00 	mov    %r8,0x80(%rbx)
    15a3:	4c 89 9b 88 00 00 00 	mov    %r11,0x88(%rbx)
    15aa:	48 89 83 90 00 00 00 	mov    %rax,0x90(%rbx)
    15b1:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    15b5:	c5 f8 11 43 58       	vmovups %xmm0,0x58(%rbx)
    15ba:	48 c7 43 68 00 00 00 	movq   $0x0,0x68(%rbx)
    15c1:	00 
    15c2:	4c 89 73 70          	mov    %r14,0x70(%rbx)
    15c6:	48 c7 43 48 00 00 00 	movq   $0x0,0x48(%rbx)
    15cd:	00 
    15ce:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    15d2:	48 85 c9             	test   %rcx,%rcx
    15d5:	0f 84 66 16 00 00    	je     2c41 <f_8001161d0+0x2c41>
    15db:	49 8b 87 c8 1e 00 00 	mov    0x1ec8(%r15),%rax
    15e2:	48 8b 97 98 00 00 00 	mov    0x98(%rdi),%rdx
    15e9:	0f b6 52 08          	movzbl 0x8(%rdx),%edx
    15ed:	44 8b 40 08          	mov    0x8(%rax),%r8d
    15f1:	48 8b 70 10          	mov    0x10(%rax),%rsi
    15f5:	31 c0                	xor    %eax,%eax
    15f7:	45 31 db             	xor    %r11d,%r11d
    15fa:	31 ed                	xor    %ebp,%ebp
    15fc:	45 89 c6             	mov    %r8d,%r14d
    15ff:	41 29 d6             	sub    %edx,%r14d
    1602:	41 bf 00 00 00 00    	mov    $0x0,%r15d
    1608:	4c 0f 47 fa          	cmova  %rdx,%r15
    160c:	41 0f 94 c3          	sete   %r11b
    1610:	40 0f 93 c5          	setae  %bpl
    1614:	c4 c2 08 f2 d0       	andn   %r8d,%r14d,%edx
    1619:	41 81 e6 00 00 00 80 	and    $0x80000000,%r14d
    1620:	41 c1 e3 1e          	shl    $0x1e,%r11d
    1624:	c1 e5 1d             	shl    $0x1d,%ebp
    1627:	44 09 dd             	or     %r11d,%ebp
    162a:	44 09 f5             	or     %r14d,%ebp
    162d:	c1 ea 03             	shr    $0x3,%edx
    1630:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    1636:	09 ea                	or     %ebp,%edx
    1638:	48 89 97 10 01 00 00 	mov    %rdx,0x110(%rdi)
    163f:	48 c7 47 60 e0 3c 00 	movq   $0x3ce0,0x60(%rdi)
    1646:	00 
    1647:	4c 89 7f 58          	mov    %r15,0x58(%rdi)
    164b:	49 69 d7 e0 3c 00 00 	imul   $0x3ce0,%r15,%rdx
    1652:	4c 8d 04 32          	lea    (%rdx,%rsi,1),%r8
    1656:	4c 89 47 50          	mov    %r8,0x50(%rdi)
    165a:	4c 8d b7 10 02 00 00 	lea    0x210(%rdi),%r14
    1661:	c5 fa 10 8c 32 08 2e 	vmovss 0x2e08(%rdx,%rsi,1),%xmm1
    1668:	00 00 
    166a:	c5 fa 10 94 32 0c 2e 	vmovss 0x2e0c(%rdx,%rsi,1),%xmm2
    1671:	00 00 
    1673:	c5 f2 5c 9c 32 00 2e 	vsubss 0x2e00(%rdx,%rsi,1),%xmm1,%xmm3
    167a:	00 00 
    167c:	c5 ea 5c 8c 32 04 2e 	vsubss 0x2e04(%rdx,%rsi,1),%xmm2,%xmm1
    1683:	00 00 
    1685:	4c 8d bf 20 02 00 00 	lea    0x220(%rdi),%r15
    168c:	44 89 93 a0 00 00 00 	mov    %r10d,0xa0(%rbx)
    1693:	48 8b 97 e8 00 00 00 	mov    0xe8(%rdi),%rdx
    169a:	48 83 c2 f7          	add    $0xfffffffffffffff7,%rdx
    169e:	c4 e1 fa 2c f3       	vcvttss2si %xmm3,%rsi
    16a3:	c5 e8 57 d2          	vxorps %xmm2,%xmm2,%xmm2
    16a7:	c5 f8 2e da          	vucomiss %xmm2,%xmm3
    16ab:	0f 42 f0             	cmovb  %eax,%esi
    16ae:	c5 fa 10 25 00 00 00 	vmovss 0x0(%rip),%xmm4        # 16b6 <f_8001161d0+0x16b6>
    16b5:	00 
    16b6:	c5 f8 2e dc          	vucomiss %xmm4,%xmm3
    16ba:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    16c0:	41 0f 47 f0          	cmova  %r8d,%esi
    16c4:	48 89 57 40          	mov    %rdx,0x40(%rdi)
    16c8:	c4 e1 82 2a de       	vcvtsi2ss %rsi,%xmm15,%xmm3
    16cd:	4d 89 a1 a4 00 00 00 	mov    %r12,0xa4(%r9)
    16d4:	8b 91 0c 03 00 00    	mov    0x30c(%rcx),%edx
    16da:	c5 e2 59 99 08 03 00 	vmulss 0x308(%rcx),%xmm3,%xmm3
    16e1:	00 
    16e2:	48 89 97 30 02 00 00 	mov    %rdx,0x230(%rdi)
    16e9:	48 c7 87 38 02 00 00 	movq   $0x0,0x238(%rdi)
    16f0:	00 00 00 00 
    16f4:	c4 e1 fa 2c c9       	vcvttss2si %xmm1,%rcx
    16f9:	c5 f8 2e ca          	vucomiss %xmm2,%xmm1
    16fd:	0f 42 c8             	cmovb  %eax,%ecx
    1700:	c5 f8 2e cc          	vucomiss %xmm4,%xmm1
    1704:	41 0f 47 c8          	cmova  %r8d,%ecx
    1708:	c5 f9 7e d8          	vmovd  %xmm3,%eax
    170c:	48 89 87 00 02 00 00 	mov    %rax,0x200(%rdi)
    1713:	c4 e1 82 2a c9       	vcvtsi2ss %rcx,%xmm15,%xmm1
    1718:	48 c7 87 08 02 00 00 	movq   $0x0,0x208(%rdi)
    171f:	00 00 00 00 
    1723:	c5 f9 6e d2          	vmovd  %edx,%xmm2
    1727:	c5 f2 59 ca          	vmulss %xmm2,%xmm1,%xmm1
    172b:	c5 f9 7e c8          	vmovd  %xmm1,%eax
    172f:	c5 f8 11 87 18 02 00 	vmovups %xmm0,0x218(%rdi)
    1736:	00 
    1737:	48 89 87 10 02 00 00 	mov    %rax,0x210(%rdi)
    173e:	48 c7 87 28 02 00 00 	movq   $0x0,0x228(%rdi)
    1745:	00 00 00 00 
    1749:	48 89 fb             	mov    %rdi,%rbx
    174c:	31 f6                	xor    %esi,%esi
    174e:	31 d2                	xor    %edx,%edx
    1750:	b9 01 00 00 00       	mov    $0x1,%ecx
    1755:	c5 f8 77             	vzeroupper
    1758:	e8 00 00 00 00       	call   175d <f_8001161d0+0x175d>
    175d:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    1764:	48 8b 8b 00 02 00 00 	mov    0x200(%rbx),%rcx
    176b:	48 8b 93 20 02 00 00 	mov    0x220(%rbx),%rdx
    1772:	c5 f9 6e c1          	vmovd  %ecx,%xmm0
    1776:	c4 e3 79 22 83 10 02 	vpinsrd $0x1,0x210(%rbx),%xmm0,%xmm0
    177d:	00 00 01 
    1780:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    1784:	c4 e2 79 58 c9       	vpbroadcastd %xmm1,%xmm1
    1789:	c5 f0 5f d0          	vmaxps %xmm0,%xmm1,%xmm2
    178d:	c5 f8 c2 c0 03       	vcmpunordps %xmm0,%xmm0,%xmm0
    1792:	c4 e3 69 4a c1 00    	vblendvps %xmm0,%xmm1,%xmm2,%xmm0
    1798:	c4 e3 79 17 c6 00    	vextractps $0x0,%xmm0,%esi
    179e:	c4 e3 79 17 c7 01    	vextractps $0x1,%xmm0,%edi
    17a4:	48 89 bb 40 02 00 00 	mov    %rdi,0x240(%rbx)
    17ab:	48 89 b3 30 02 00 00 	mov    %rsi,0x230(%rbx)
    17b2:	48 c7 83 48 02 00 00 	movq   $0x0,0x248(%rbx)
    17b9:	00 00 00 00 
    17bd:	a9 00 00 00 40       	test   $0x40000000,%eax
    17c2:	40 0f 94 c6          	sete   %sil
    17c6:	85 c0                	test   %eax,%eax
    17c8:	40 0f 98 c7          	sets   %dil
    17cc:	a9 00 00 00 10       	test   $0x10000000,%eax
    17d1:	0f 94 c0             	sete   %al
    17d4:	40 30 f8             	xor    %dil,%al
    17d7:	40 84 c6             	test   %al,%sil
    17da:	48 0f 45 ca          	cmovne %rdx,%rcx
    17de:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    17e5:	00 00 00 00 
    17e9:	89 c8                	mov    %ecx,%eax
    17eb:	48 89 83 00 02 00 00 	mov    %rax,0x200(%rbx)
    17f2:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    17f9:	00 00 00 00 
    17fd:	48 89 df             	mov    %rbx,%rdi
    1800:	be 01 00 00 00       	mov    $0x1,%esi
    1805:	31 d2                	xor    %edx,%edx
    1807:	b9 01 00 00 00       	mov    $0x1,%ecx
    180c:	e8 00 00 00 00       	call   1811 <f_8001161d0+0x1811>
    1811:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    1818:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    181f:	8b 93 30 02 00 00    	mov    0x230(%rbx),%edx
    1825:	85 c0                	test   %eax,%eax
    1827:	40 0f 98 c6          	sets   %sil
    182b:	a9 00 00 00 10       	test   $0x10000000,%eax
    1830:	40 0f 94 c7          	sete   %dil
    1834:	40 30 f7             	xor    %sil,%dil
    1837:	8b b3 40 02 00 00    	mov    0x240(%rbx),%esi
    183d:	89 91 80 00 00 00    	mov    %edx,0x80(%rcx)
    1843:	89 b1 84 00 00 00    	mov    %esi,0x84(%rcx)
    1849:	4d 0f 44 fe          	cmove  %r14,%r15
    184d:	89 91 98 00 00 00    	mov    %edx,0x98(%rcx)
    1853:	a9 00 00 00 40       	test   $0x40000000,%eax
    1858:	4d 0f 45 fe          	cmovne %r14,%r15
    185c:	89 b1 9c 00 00 00    	mov    %esi,0x9c(%rcx)
    1862:	49 8b 07             	mov    (%r15),%rax
    1865:	89 c2                	mov    %eax,%edx
    1867:	48 89 93 10 02 00 00 	mov    %rdx,0x210(%rbx)
    186e:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    1875:	00 00 00 00 
    1879:	8b 93 00 02 00 00    	mov    0x200(%rbx),%edx
    187f:	89 51 78             	mov    %edx,0x78(%rcx)
    1882:	89 41 7c             	mov    %eax,0x7c(%rcx)
    1885:	89 91 90 00 00 00    	mov    %edx,0x90(%rcx)
    188b:	89 81 94 00 00 00    	mov    %eax,0x94(%rcx)
    1891:	49 8d 85 5e 18 51 fd 	lea    -0x2aee7a2(%r13),%rax
    1898:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    189f:	48 89 df             	mov    %rbx,%rdi
    18a2:	e8 00 00 00 00       	call   18a7 <f_8001161d0+0x18a7>
    18a7:	48 89 df             	mov    %rbx,%rdi
    18aa:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    18b1:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    18b8:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    18bf:	48 89 01             	mov    %rax,(%rcx)
    18c2:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    18c9:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    18cd:	48 89 43 40          	mov    %rax,0x40(%rbx)
    18d1:	88 41 08             	mov    %al,0x8(%rcx)
    18d4:	e9 68 13 00 00       	jmp    2c41 <f_8001161d0+0x2c41>
    18d9:	48 8b 4f 78          	mov    0x78(%rdi),%rcx
    18dd:	4c 89 cd             	mov    %r9,%rbp
    18e0:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
    18e7:	00 00 00 00 
    18eb:	48 89 a8 20 ff ff ff 	mov    %rbp,-0xe0(%rax)
    18f2:	4c 8b bf a0 00 00 00 	mov    0xa0(%rdi),%r15
    18f9:	8b b7 a8 00 00 00    	mov    0xa8(%rdi),%esi
    18ff:	44 8d 4e 08          	lea    0x8(%rsi),%r9d
    1903:	4c 8b 87 00 01 00 00 	mov    0x100(%rdi),%r8
    190a:	c4 c2 73 f7 af fc 0d 	shrx   %ecx,0xdfc(%r15),%ebp
    1911:	00 00 
    1913:	45 89 48 30          	mov    %r9d,0x30(%r8)
    1917:	4c 8b 67 68          	mov    0x68(%rdi),%r12
    191b:	45 89 60 34          	mov    %r12d,0x34(%r8)
    191f:	45 31 ed             	xor    %r13d,%r13d
    1922:	f7 c3 00 02 00 00    	test   $0x200,%ebx
    1928:	41 0f 94 c5          	sete   %r13b
    192c:	45 8b 8f 20 0d 00 00 	mov    0xd20(%r15),%r9d
    1933:	45 31 f6             	xor    %r14d,%r14d
    1936:	41 39 c9             	cmp    %ecx,%r9d
    1939:	49 0f 46 ce          	cmovbe %r14,%rcx
    193d:	41 89 c9             	mov    %ecx,%r9d
    1940:	4d 69 c9 b0 0b 00 00 	imul   $0xbb0,%r9,%r9
    1947:	31 d2                	xor    %edx,%edx
    1949:	f7 c3 00 40 00 00    	test   $0x4000,%ebx
    194f:	0f 94 c2             	sete   %dl
    1952:	c1 e3 06             	shl    $0x6,%ebx
    1955:	81 e3 00 00 04 00    	and    $0x40000,%ebx
    195b:	c1 e2 04             	shl    $0x4,%edx
    195e:	41 85 ed             	test   %ebp,%r13d
    1961:	bd 01 00 00 00       	mov    $0x1,%ebp
    1966:	c4 62 19 f7 e5       	shlx   %r12d,%ebp,%r12d
    196b:	48 c7 47 48 01 00 00 	movq   $0x1,0x48(%rdi)
    1972:	00 
    1973:	4c 89 67 08          	mov    %r12,0x8(%rdi)
    1977:	4d 8b bf 28 0d 00 00 	mov    0xd28(%r15),%r15
    197e:	4c 89 7f 70          	mov    %r15,0x70(%rdi)
    1982:	48 89 4f 78          	mov    %rcx,0x78(%rdi)
    1986:	8d 8c 1a 00 00 20 00 	lea    0x200000(%rdx,%rbx,1),%ecx
    198d:	ba 0f 00 00 00       	mov    $0xf,%edx
    1992:	41 0f 45 d4          	cmovne %r12d,%edx
    1996:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    199d:	00 
    199e:	48 c7 07 08 00 00 00 	movq   $0x8,(%rdi)
    19a5:	41 89 10             	mov    %edx,(%r8)
    19a8:	41 c7 40 04 08 00 00 	movl   $0x8,0x4(%r8)
    19af:	00 
    19b0:	83 c6 04             	add    $0x4,%esi
    19b3:	41 89 70 08          	mov    %esi,0x8(%r8)
    19b7:	41 89 48 0c          	mov    %ecx,0xc(%r8)
    19bb:	49 c7 40 10 ff ff 00 	movq   $0xffff,0x10(%r8)
    19c2:	00 
    19c3:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    19ca:	ff ff ff 
    19cd:	48 8d 4d 02          	lea    0x2(%rbp),%rcx
    19d1:	49 89 48 18          	mov    %rcx,0x18(%r8)
    19d5:	4c 8b 24 24          	mov    (%rsp),%r12
    19d9:	4c 89 a7 90 00 00 00 	mov    %r12,0x90(%rdi)
    19e0:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    19e7:	00 00 00 
    19ea:	49 89 48 20          	mov    %rcx,0x20(%r8)
    19ee:	49 89 68 28          	mov    %rbp,0x28(%r8)
    19f2:	48 b9 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rcx
    19f9:	00 80 3f 
    19fc:	49 89 48 38          	mov    %rcx,0x38(%r8)
    1a00:	49 89 48 40          	mov    %rcx,0x40(%r8)
    1a04:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1a0b:	00 00 00 
    1a0e:	49 8d 95 b1 e5 0b 00 	lea    0xbe5b1(%r13),%rdx
    1a15:	48 89 97 80 00 00 00 	mov    %rdx,0x80(%rdi)
    1a1c:	48 bb ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rbx
    1a23:	ff 7f ff 
    1a26:	48 89 9f 88 00 00 00 	mov    %rbx,0x88(%rdi)
    1a2d:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
    1a34:	4c 89 a1 a4 00 00 00 	mov    %r12,0xa4(%rcx)
    1a3b:	48 8b 77 58          	mov    0x58(%rdi),%rsi
    1a3f:	49 89 70 78          	mov    %rsi,0x78(%r8)
    1a43:	49 89 98 80 00 00 00 	mov    %rbx,0x80(%r8)
    1a4a:	49 89 98 98 00 00 00 	mov    %rbx,0x98(%r8)
    1a51:	4c 8b 5c 24 08       	mov    0x8(%rsp),%r11
    1a56:	4d 89 98 88 00 00 00 	mov    %r11,0x88(%r8)
    1a5d:	49 89 b0 90 00 00 00 	mov    %rsi,0x90(%r8)
    1a64:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1a68:	45 89 90 a0 00 00 00 	mov    %r10d,0xa0(%r8)
    1a6f:	41 c7 80 bc 00 00 00 	movl   $0x0,0xbc(%r8)
    1a76:	00 00 00 00 
    1a7a:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1a7e:	c4 c1 78 11 40 58    	vmovups %xmm0,0x58(%r8)
    1a84:	49 c7 40 68 00 00 00 	movq   $0x0,0x68(%r8)
    1a8b:	00 
    1a8c:	49 89 50 70          	mov    %rdx,0x70(%r8)
    1a90:	43 8b 84 0f d8 03 00 	mov    0x3d8(%r15,%r9,1),%eax
    1a97:	00 
    1a98:	89 c2                	mov    %eax,%edx
    1a9a:	c1 fa 1f             	sar    $0x1f,%edx
    1a9d:	c4 e2 68 f2 d0       	andn   %eax,%edx,%edx
    1aa2:	85 c0                	test   %eax,%eax
    1aa4:	41 0f 49 c6          	cmovns %r14d,%eax
    1aa8:	c5 82 2a c0          	vcvtsi2ss %eax,%xmm15,%xmm0
    1aac:	43 8b 84 0f f8 03 00 	mov    0x3f8(%r15,%r9,1),%eax
    1ab3:	00 
    1ab4:	89 c6                	mov    %eax,%esi
    1ab6:	c1 fe 1f             	sar    $0x1f,%esi
    1ab9:	c4 e2 48 f2 f0       	andn   %eax,%esi,%esi
    1abe:	85 c0                	test   %eax,%eax
    1ac0:	c5 82 2a ce          	vcvtsi2ss %esi,%xmm15,%xmm1
    1ac4:	41 0f 49 c6          	cmovns %r14d,%eax
    1ac8:	c5 82 2a d2          	vcvtsi2ss %edx,%xmm15,%xmm2
    1acc:	c4 c1 7a 11 90 80 00 	vmovss %xmm2,0x80(%r8)
    1ad3:	00 00 
    1ad5:	c4 c1 7a 11 88 84 00 	vmovss %xmm1,0x84(%r8)
    1adc:	00 00 
    1ade:	c5 82 2a c8          	vcvtsi2ss %eax,%xmm15,%xmm1
    1ae2:	c4 c1 7a 11 40 78    	vmovss %xmm0,0x78(%r8)
    1ae8:	c4 c1 7a 11 48 7c    	vmovss %xmm1,0x7c(%r8)
    1aee:	43 8b 94 0f d8 03 00 	mov    0x3d8(%r15,%r9,1),%edx
    1af5:	00 
    1af6:	43 8b 84 0f f8 03 00 	mov    0x3f8(%r15,%r9,1),%eax
    1afd:	00 
    1afe:	48 89 47 60          	mov    %rax,0x60(%rdi)
    1b02:	8b 77 40             	mov    0x40(%rdi),%esi
    1b05:	41 89 b0 a0 00 00 00 	mov    %esi,0xa0(%r8)
    1b0c:	89 d6                	mov    %edx,%esi
    1b0e:	c1 fe 1f             	sar    $0x1f,%esi
    1b11:	c4 e2 48 f2 f2       	andn   %edx,%esi,%esi
    1b16:	85 d2                	test   %edx,%edx
    1b18:	41 0f 49 d6          	cmovns %r14d,%edx
    1b1c:	c5 82 2a c2          	vcvtsi2ss %edx,%xmm15,%xmm0
    1b20:	4c 89 a1 a4 00 00 00 	mov    %r12,0xa4(%rcx)
    1b27:	85 c0                	test   %eax,%eax
    1b29:	44 0f 4f f0          	cmovg  %eax,%r14d
    1b2d:	c5 82 2a ce          	vcvtsi2ss %esi,%xmm15,%xmm1
    1b31:	c4 e3 79 17 c1 00    	vextractps $0x0,%xmm0,%ecx
    1b37:	48 89 77 68          	mov    %rsi,0x68(%rdi)
    1b3b:	48 89 8f 10 02 00 00 	mov    %rcx,0x210(%rdi)
    1b42:	c4 e3 79 17 c9 00    	vextractps $0x0,%xmm1,%ecx
    1b48:	48 89 8f 00 02 00 00 	mov    %rcx,0x200(%rdi)
    1b4f:	c4 c1 02 2a d6       	vcvtsi2ss %r14d,%xmm15,%xmm2
    1b54:	89 c1                	mov    %eax,%ecx
    1b56:	c1 f9 1f             	sar    $0x1f,%ecx
    1b59:	21 c1                	and    %eax,%ecx
    1b5b:	48 c7 87 18 02 00 00 	movq   $0x0,0x218(%rdi)
    1b62:	00 00 00 00 
    1b66:	48 c7 87 08 02 00 00 	movq   $0x0,0x208(%rdi)
    1b6d:	00 00 00 00 
    1b71:	48 89 4f 58          	mov    %rcx,0x58(%rdi)
    1b75:	c5 82 2a d9          	vcvtsi2ss %ecx,%xmm15,%xmm3
    1b79:	c4 e3 79 17 d8 00    	vextractps $0x0,%xmm3,%eax
    1b7f:	48 89 87 30 02 00 00 	mov    %rax,0x230(%rdi)
    1b86:	c4 e3 79 17 d0 00    	vextractps $0x0,%xmm2,%eax
    1b8c:	48 89 87 20 02 00 00 	mov    %rax,0x220(%rdi)
    1b93:	48 c7 87 38 02 00 00 	movq   $0x0,0x238(%rdi)
    1b9a:	00 00 00 00 
    1b9e:	48 c7 87 28 02 00 00 	movq   $0x0,0x228(%rdi)
    1ba5:	00 00 00 00 
    1ba9:	c4 c1 7a 11 88 98 00 	vmovss %xmm1,0x98(%r8)
    1bb0:	00 00 
    1bb2:	c4 c1 7a 11 90 9c 00 	vmovss %xmm2,0x9c(%r8)
    1bb9:	00 00 
    1bbb:	c4 c1 7a 11 80 90 00 	vmovss %xmm0,0x90(%r8)
    1bc2:	00 00 
    1bc4:	c4 c1 7a 11 98 94 00 	vmovss %xmm3,0x94(%r8)
    1bcb:	00 00 
    1bcd:	31 c0                	xor    %eax,%eax
    1bcf:	43 80 bc 0f 58 04 00 	cmpb   $0x0,0x458(%r15,%r9,1)
    1bd6:	00 00 
    1bd8:	48 c7 47 50 5b 00 00 	movq   $0x5b,0x50(%rdi)
    1bdf:	00 
    1be0:	49 c7 80 b0 00 00 00 	movq   $0x0,0xb0(%r8)
    1be7:	00 00 00 00 
    1beb:	41 c7 80 bc 00 00 00 	movl   $0x1,0xbc(%r8)
    1bf2:	01 00 00 00 
    1bf6:	0f 94 c0             	sete   %al
    1bf9:	48 8d 0c 45 59 00 00 	lea    0x59(,%rax,2),%rcx
    1c00:	00 
    1c01:	c1 e0 1e             	shl    $0x1e,%eax
    1c04:	48 0d 00 00 00 20    	or     $0x20000000,%rax
    1c0a:	48 89 87 10 01 00 00 	mov    %rax,0x110(%rdi)
    1c11:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    1c15:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    1c1c:	e9 1a 10 00 00       	jmp    2c3b <f_8001161d0+0x2c3b>
    1c21:	4c 89 a7 08 01 00 00 	mov    %r12,0x108(%rdi)
    1c28:	48 83 c4 18          	add    $0x18,%rsp
    1c2c:	5b                   	pop    %rbx
    1c2d:	41 5c                	pop    %r12
    1c2f:	41 5d                	pop    %r13
    1c31:	41 5e                	pop    %r14
    1c33:	41 5f                	pop    %r15
    1c35:	5d                   	pop    %rbp
    1c36:	c5 f8 77             	vzeroupper
    1c39:	e9 00 00 00 00       	jmp    1c3e <f_8001161d0+0x1c3e>
    1c3e:	48 c7 47 40 b0 1e 00 	movq   $0x1eb0,0x40(%rdi)
    1c45:	00 
    1c46:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    1c4d:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    1c54:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    1c58:	48 89 47 10          	mov    %rax,0x10(%rdi)
    1c5c:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1c61:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
    1c68:	48 89 07             	mov    %rax,(%rdi)
    1c6b:	48 c7 47 18 00 00 00 	movq   $0x0,0x18(%rdi)
    1c72:	00 
    1c73:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1c7a:	00 00 00 
    1c7d:	49 8d 85 ae 18 51 fd 	lea    -0x2aee752(%r13),%rax
    1c84:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    1c8b:	48 89 fb             	mov    %rdi,%rbx
    1c8e:	c5 f8 77             	vzeroupper
    1c91:	e8 00 00 00 00       	call   1c96 <f_8001161d0+0x1c96>
    1c96:	48 89 df             	mov    %rbx,%rdi
    1c99:	e9 a3 0f 00 00       	jmp    2c41 <f_8001161d0+0x2c41>
    1c9e:	48 c7 47 40 b0 1e 00 	movq   $0x1eb0,0x40(%rdi)
    1ca5:	00 
    1ca6:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    1cad:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    1cb4:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    1cb8:	48 89 47 10          	mov    %rax,0x10(%rdi)
    1cbc:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1cc1:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
    1cc8:	48 89 07             	mov    %rax,(%rdi)
    1ccb:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1cd2:	00 00 00 
    1cd5:	49 8d 85 ce 18 51 fd 	lea    -0x2aee732(%r13),%rax
    1cdc:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    1ce3:	48 89 fb             	mov    %rdi,%rbx
    1ce6:	c5 f8 77             	vzeroupper
    1ce9:	e8 00 00 00 00       	call   1cee <f_8001161d0+0x1cee>
    1cee:	48 89 df             	mov    %rbx,%rdi
    1cf1:	e9 4b 0f 00 00       	jmp    2c41 <f_8001161d0+0x2c41>
    1cf6:	48 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%rcx
    1cfd:	48 8b 89 c8 1e 00 00 	mov    0x1ec8(%rcx),%rcx
    1d04:	48 89 4f 70          	mov    %rcx,0x70(%rdi)
    1d08:	49 b9 00 00 00 00 01 	movabs $0x100000000,%r9
    1d0f:	00 00 00 
    1d12:	4c 89 0f             	mov    %r9,(%rdi)
    1d15:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1d19:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    1d20:	48 c7 03 04 00 00 00 	movq   $0x4,(%rbx)
    1d27:	48 ba 00 00 00 00 00 	movabs $0x40000000000000,%rdx
    1d2e:	00 40 00 
    1d31:	48 ff c2             	inc    %rdx
    1d34:	48 89 53 08          	mov    %rdx,0x8(%rbx)
    1d38:	4c 89 4b 20          	mov    %r9,0x20(%rbx)
    1d3c:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    1d43:	ff ff ff 
    1d46:	48 89 6b 28          	mov    %rbp,0x28(%rbx)
    1d4a:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1d51:	00 00 00 
    1d54:	49 8d 95 25 74 0d 00 	lea    0xd7425(%r13),%rdx
    1d5b:	48 89 57 68          	mov    %rdx,0x68(%rdi)
    1d5f:	4c 89 83 80 00 00 00 	mov    %r8,0x80(%rbx)
    1d66:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    1d6b:	4c 89 8b 88 00 00 00 	mov    %r9,0x88(%rbx)
    1d72:	4c 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%r9
    1d79:	4c 8b 1c 24          	mov    (%rsp),%r11
    1d7d:	4d 89 99 a4 00 00 00 	mov    %r11,0xa4(%r9)
    1d84:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
    1d8b:	ff 7f 7f 
    1d8e:	4c 89 9b 90 00 00 00 	mov    %r11,0x90(%rbx)
    1d95:	4c 89 83 98 00 00 00 	mov    %r8,0x98(%rbx)
    1d9c:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 1da4 <f_8001161d0+0x1da4>
    1da3:	00 
    1da4:	c5 fc 11 47 78       	vmovups %ymm0,0x78(%rdi)
    1da9:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1db0:	00 
    1db1:	44 89 93 a0 00 00 00 	mov    %r10d,0xa0(%rbx)
    1db8:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    1dbf:	44 0f b6 48 08       	movzbl 0x8(%rax),%r9d
    1dc4:	4c 89 4f 40          	mov    %r9,0x40(%rdi)
    1dc8:	c7 83 bc 00 00 00 03 	movl   $0x3,0xbc(%rbx)
    1dcf:	00 00 00 
    1dd2:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
    1dd9:	00 
    1dda:	48 8d 45 17          	lea    0x17(%rbp),%rax
    1dde:	48 89 43 18          	mov    %rax,0x18(%rbx)
    1de2:	48 c7 43 68 00 00 00 	movq   $0x0,0x68(%rbx)
    1de9:	00 
    1dea:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    1def:	48 89 43 30          	mov    %rax,0x30(%rbx)
    1df3:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    1dfa:	00 80 3f 
    1dfd:	48 89 43 38          	mov    %rax,0x38(%rbx)
    1e01:	48 89 43 40          	mov    %rax,0x40(%rbx)
    1e05:	48 c7 43 48 00 00 00 	movq   $0x0,0x48(%rbx)
    1e0c:	00 
    1e0d:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    1e11:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1e15:	c5 f8 11 43 58       	vmovups %xmm0,0x58(%rbx)
    1e1a:	48 89 53 70          	mov    %rdx,0x70(%rbx)
    1e1e:	4c 89 5b 78          	mov    %r11,0x78(%rbx)
    1e22:	49 69 c1 e0 3c 00 00 	imul   $0x3ce0,%r9,%rax
    1e29:	45 31 c0             	xor    %r8d,%r8d
    1e2c:	44 39 49 08          	cmp    %r9d,0x8(%rcx)
    1e30:	49 0f 46 c0          	cmovbe %r8,%rax
    1e34:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    1e38:	48 8b 94 08 68 33 00 	mov    0x3368(%rax,%rcx,1),%rdx
    1e3f:	00 
    1e40:	48 89 57 60          	mov    %rdx,0x60(%rdi)
    1e44:	48 8b 84 08 60 33 00 	mov    0x3360(%rax,%rcx,1),%rax
    1e4b:	00 
    1e4c:	48 8b 4f 48          	mov    0x48(%rdi),%rcx
    1e50:	48 89 01             	mov    %rax,(%rcx)
    1e53:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    1e57:	48 8b 47 70          	mov    0x70(%rdi),%rax
    1e5b:	44 8b 50 08          	mov    0x8(%rax),%r10d
    1e5f:	48 8b 48 10          	mov    0x10(%rax),%rcx
    1e63:	48 89 4f 58          	mov    %rcx,0x58(%rdi)
    1e67:	8b 57 40             	mov    0x40(%rdi),%edx
    1e6a:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
    1e71:	45 31 db             	xor    %r11d,%r11d
    1e74:	31 f6                	xor    %esi,%esi
    1e76:	44 89 d3             	mov    %r10d,%ebx
    1e79:	44 29 cb             	sub    %r9d,%ebx
    1e7c:	49 0f 46 d0          	cmovbe %r8,%rdx
    1e80:	41 0f 94 c3          	sete   %r11b
    1e84:	40 0f 93 c6          	setae  %sil
    1e88:	41 c1 e3 1e          	shl    $0x1e,%r11d
    1e8c:	c1 e6 1d             	shl    $0x1d,%esi
    1e8f:	44 09 de             	or     %r11d,%esi
    1e92:	c4 42 60 f2 c2       	andn   %r10d,%ebx,%r8d
    1e97:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    1e9d:	09 de                	or     %ebx,%esi
    1e9f:	41 c1 e8 03          	shr    $0x3,%r8d
    1ea3:	41 81 e0 00 00 00 10 	and    $0x10000000,%r8d
    1eaa:	41 09 f0             	or     %esi,%r8d
    1ead:	4c 89 87 10 01 00 00 	mov    %r8,0x110(%rdi)
    1eb4:	48 8b b4 0a e8 35 00 	mov    0x35e8(%rdx,%rcx,1),%rsi
    1ebb:	00 
    1ebc:	48 89 77 48          	mov    %rsi,0x48(%rdi)
    1ec0:	4c 8b 84 0a e0 35 00 	mov    0x35e0(%rdx,%rcx,1),%r8
    1ec7:	00 
    1ec8:	4c 89 47 50          	mov    %r8,0x50(%rdi)
    1ecc:	4c 8b 8f d0 00 00 00 	mov    0xd0(%rdi),%r9
    1ed3:	4d 89 01             	mov    %r8,(%r9)
    1ed6:	49 89 71 08          	mov    %rsi,0x8(%r9)
    1eda:	8b b4 0a f8 35 00 00 	mov    0x35f8(%rdx,%rcx,1),%esi
    1ee1:	48 8b 8c 0a f0 35 00 	mov    0x35f0(%rdx,%rcx,1),%rcx
    1ee8:	00 
    1ee9:	48 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%rdx
    1ef0:	48 89 0a             	mov    %rcx,(%rdx)
    1ef3:	89 72 08             	mov    %esi,0x8(%rdx)
    1ef6:	8b 48 44             	mov    0x44(%rax),%ecx
    1ef9:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    1efd:	48 83 c0 3c          	add    $0x3c,%rax
    1f01:	8b 00                	mov    (%rax),%eax
    1f03:	48 89 47 48          	mov    %rax,0x48(%rdi)
    1f07:	48 8b 97 00 01 00 00 	mov    0x100(%rdi),%rdx
    1f0e:	88 8a b0 00 00 00    	mov    %cl,0xb0(%rdx)
    1f14:	c7 82 b4 00 00 00 00 	movl   $0x0,0xb4(%rdx)
    1f1b:	00 00 00 
    1f1e:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
    1f25:	c7 81 b1 00 00 00 00 	movl   $0x0,0xb1(%rcx)
    1f2c:	00 00 00 
    1f2f:	88 82 b8 00 00 00    	mov    %al,0xb8(%rdx)
    1f35:	e9 07 0d 00 00       	jmp    2c41 <f_8001161d0+0x2c41>
    1f3a:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    1f41:	00 
    1f42:	48 c7 80 d0 fe ff ff 	movq   $0x100,-0x130(%rax)
    1f49:	00 01 00 00 
    1f4d:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    1f54:	00 40 00 
    1f57:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    1f5e:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    1f65:	ff ff 00 00 
    1f69:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    1f70:	ff ff ff 
    1f73:	48 8d 4a 13          	lea    0x13(%rdx),%rcx
    1f77:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    1f7e:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    1f85:	00 00 00 
    1f88:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
    1f8c:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    1f93:	48 89 90 f8 fe ff ff 	mov    %rdx,-0x108(%rax)
    1f9a:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    1fa1:	00 80 3f 
    1fa4:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    1fa8:	48 8d 88 00 ff ff ff 	lea    -0x100(%rax),%rcx
    1faf:	48 8d 98 08 ff ff ff 	lea    -0xf8(%rax),%rbx
    1fb6:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
    1fbd:	00 00 00 
    1fc0:	4c 8d 8a a1 6f fe ff 	lea    -0x1905f(%rdx),%r9
    1fc7:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    1fcd:	e9 a1 0a 00 00       	jmp    2a73 <f_8001161d0+0x2a73>
    1fd2:	49 89 ec             	mov    %rbp,%r12
    1fd5:	48 c7 47 68 00 10 00 	movq   $0x1000,0x68(%rdi)
    1fdc:	00 
    1fdd:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    1fe4:	00 
    1fe5:	48 c7 80 d0 fe ff ff 	movq   $0x1000,-0x130(%rax)
    1fec:	00 10 00 00 
    1ff0:	48 c7 80 d8 fe ff ff 	movq   $0x1,-0x128(%rax)
    1ff7:	01 00 00 00 
    1ffb:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    2002:	ff ff 00 00 
    2006:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    200d:	ff ff ff 
    2010:	48 8d 4d 0c          	lea    0xc(%rbp),%rcx
    2014:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    201b:	49 bf 00 00 00 00 01 	movabs $0x100000000,%r15
    2022:	00 00 00 
    2025:	4c 89 b8 f0 fe ff ff 	mov    %r15,-0x110(%rax)
    202c:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
    2033:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    203a:	00 80 3f 
    203d:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    2041:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
    2046:	48 89 88 00 ff ff ff 	mov    %rcx,-0x100(%rax)
    204d:	4c 89 b0 08 ff ff ff 	mov    %r14,-0xf8(%rax)
    2054:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    205b:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    2062:	00 00 00 
    2065:	49 8d 9d b2 a4 03 00 	lea    0x3a4b2(%r13),%rbx
    206c:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
    2073:	4c 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%r9
    207a:	4d 8b 91 d0 2f 00 00 	mov    0x2fd0(%r9),%r10
    2081:	4c 89 57 40          	mov    %r10,0x40(%rdi)
    2085:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    208a:	48 89 77 60          	mov    %rsi,0x60(%rdi)
    208e:	48 89 59 70          	mov    %rbx,0x70(%rcx)
    2092:	48 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rbx
    2099:	ff 7f 7f 
    209c:	48 89 59 78          	mov    %rbx,0x78(%rcx)
    20a0:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    20a4:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    20a8:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    20af:	00 
    20b0:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    20b7:	00 00 00 
    20ba:	4c 89 81 80 00 00 00 	mov    %r8,0x80(%rcx)
    20c1:	48 89 b1 88 00 00 00 	mov    %rsi,0x88(%rcx)
    20c8:	48 8b 97 c0 00 00 00 	mov    0xc0(%rdi),%rdx
    20cf:	4c 8b 1c 24          	mov    (%rsp),%r11
    20d3:	4c 89 9a a4 00 00 00 	mov    %r11,0xa4(%rdx)
    20da:	4c 89 71 40          	mov    %r14,0x40(%rcx)
    20de:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    20e5:	00 
    20e6:	48 89 99 90 00 00 00 	mov    %rbx,0x90(%rcx)
    20ed:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    20f4:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    20fb:	00 
    20fc:	4c 89 61 50          	mov    %r12,0x50(%rcx)
    2100:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2104:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    2109:	4d 85 d2             	test   %r10,%r10
    210c:	0f 84 d5 0f 00 00    	je     30e7 <f_8001161d0+0x30e7>
    2112:	48 8b 97 98 00 00 00 	mov    0x98(%rdi),%rdx
    2119:	0f b6 72 08          	movzbl 0x8(%rdx),%esi
    211d:	48 c7 47 68 e0 3c 00 	movq   $0x3ce0,0x68(%rdi)
    2124:	00 
    2125:	4c 69 c6 60 0f 00 00 	imul   $0xf60,%rsi,%r8
    212c:	31 d2                	xor    %edx,%edx
    212e:	41 39 72 10          	cmp    %esi,0x10(%r10)
    2132:	4d 8b 52 18          	mov    0x18(%r10),%r10
    2136:	4c 0f 46 c2          	cmovbe %rdx,%r8
    213a:	47 8b 84 10 9c 02 00 	mov    0x29c(%r8,%r10,1),%r8d
    2141:	00 
    2142:	4d 09 f8             	or     %r15,%r8
    2145:	4c 89 41 1c          	mov    %r8,0x1c(%rcx)
    2149:	c7 81 bc 00 00 00 02 	movl   $0x2,0xbc(%rcx)
    2150:	00 00 00 
    2153:	49 8b 89 c8 1e 00 00 	mov    0x1ec8(%r9),%rcx
    215a:	4c 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%r8
    2161:	39 71 08             	cmp    %esi,0x8(%rcx)
    2164:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    216a:	4d 0f 47 c8          	cmova  %r8,%r9
    216e:	4c 8b 51 10          	mov    0x10(%rcx),%r10
    2172:	4f 8b 9c 0a b8 30 00 	mov    0x30b8(%r10,%r9,1),%r11
    2179:	00 
    217a:	4c 89 5f 60          	mov    %r11,0x60(%rdi)
    217e:	4f 8b 8c 0a b0 30 00 	mov    0x30b0(%r10,%r9,1),%r9
    2185:	00 
    2186:	4c 89 4f 58          	mov    %r9,0x58(%rdi)
    218a:	4c 89 88 48 ff ff ff 	mov    %r9,-0xb8(%rax)
    2191:	4c 89 98 50 ff ff ff 	mov    %r11,-0xb0(%rax)
    2198:	44 8b 49 08          	mov    0x8(%rcx),%r9d
    219c:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    21a0:	45 31 d2             	xor    %r10d,%r10d
    21a3:	45 31 db             	xor    %r11d,%r11d
    21a6:	44 89 cb             	mov    %r9d,%ebx
    21a9:	29 f3                	sub    %esi,%ebx
    21ab:	49 0f 47 d0          	cmova  %r8,%rdx
    21af:	41 0f 94 c2          	sete   %r10b
    21b3:	41 0f 93 c3          	setae  %r11b
    21b7:	c4 c2 60 f2 f1       	andn   %r9d,%ebx,%esi
    21bc:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    21c2:	41 c1 e2 1e          	shl    $0x1e,%r10d
    21c6:	41 c1 e3 1d          	shl    $0x1d,%r11d
    21ca:	45 09 d3             	or     %r10d,%r11d
    21cd:	41 09 db             	or     %ebx,%r11d
    21d0:	c1 ee 03             	shr    $0x3,%esi
    21d3:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    21d9:	44 09 de             	or     %r11d,%esi
    21dc:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    21e3:	48 8d 34 0a          	lea    (%rdx,%rcx,1),%rsi
    21e7:	48 89 77 40          	mov    %rsi,0x40(%rdi)
    21eb:	48 8b b4 0a 30 33 00 	mov    0x3330(%rdx,%rcx,1),%rsi
    21f2:	00 
    21f3:	4c 8b 84 0a 38 33 00 	mov    0x3338(%rdx,%rcx,1),%r8
    21fa:	00 
    21fb:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    21ff:	48 89 b0 60 ff ff ff 	mov    %rsi,-0xa0(%rax)
    2206:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
    220d:	8b b4 0a 48 33 00 00 	mov    0x3348(%rdx,%rcx,1),%esi
    2214:	48 89 77 48          	mov    %rsi,0x48(%rdi)
    2218:	48 8b 8c 0a 40 33 00 	mov    0x3340(%rdx,%rcx,1),%rcx
    221f:	00 
    2220:	48 89 88 70 ff ff ff 	mov    %rcx,-0x90(%rax)
    2227:	89 b0 78 ff ff ff    	mov    %esi,-0x88(%rax)
    222d:	e9 0f 0a 00 00       	jmp    2c41 <f_8001161d0+0x2c41>
    2232:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
    2239:	48 8b 97 a0 00 00 00 	mov    0xa0(%rdi),%rdx
    2240:	48 8b 92 c8 1e 00 00 	mov    0x1ec8(%rdx),%rdx
    2247:	48 89 57 08          	mov    %rdx,0x8(%rdi)
    224b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    2250:	48 89 77 60          	mov    %rsi,0x60(%rdi)
    2254:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
    2258:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
    225c:	44 8b 4a 08          	mov    0x8(%rdx),%r9d
    2260:	48 69 d9 e0 3c 00 00 	imul   $0x3ce0,%rcx,%rbx
    2267:	45 31 f6             	xor    %r14d,%r14d
    226a:	41 39 c9             	cmp    %ecx,%r9d
    226d:	4c 0f 47 f3          	cmova  %rbx,%r14
    2271:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    2275:	48 c7 47 70 e0 3c 00 	movq   $0x3ce0,0x70(%rdi)
    227c:	00 
    227d:	49 8b 8c 0e 40 3c 00 	mov    0x3c40(%r14,%rcx,1),%rcx
    2284:	00 
    2285:	48 89 8f b0 00 00 00 	mov    %rcx,0xb0(%rdi)
    228c:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    2293:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
    229a:	48 89 b1 88 00 00 00 	mov    %rsi,0x88(%rcx)
    22a1:	48 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rdx
    22a8:	ff 7f 7f 
    22ab:	48 89 91 90 00 00 00 	mov    %rdx,0x90(%rcx)
    22b2:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    22b9:	00 
    22ba:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    22be:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    22c5:	00 00 00 
    22c8:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    22cf:	00 
    22d0:	48 89 69 50          	mov    %rbp,0x50(%rcx)
    22d4:	48 c7 47 40 06 00 00 	movq   $0x6,0x40(%rdi)
    22db:	00 
    22dc:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    22e0:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    22e5:	48 c7 41 30 06 00 00 	movq   $0x6,0x30(%rcx)
    22ec:	00 
    22ed:	48 b8 10 00 00 00 03 	movabs $0x300000010,%rax
    22f4:	00 00 00 
    22f7:	48 83 c0 10          	add    $0x10,%rax
    22fb:	48 89 01             	mov    %rax,(%rcx)
    22fe:	48 b8 00 00 00 00 01 	movabs $0x40000100000000,%rax
    2305:	00 40 00 
    2308:	48 89 41 08          	mov    %rax,0x8(%rcx)
    230c:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    2313:	00 
    2314:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    231b:	ff ff ff 
    231e:	48 8d 42 09          	lea    0x9(%rdx),%rax
    2322:	48 89 41 18          	mov    %rax,0x18(%rcx)
    2326:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    232d:	00 00 00 
    2330:	48 89 41 20          	mov    %rax,0x20(%rcx)
    2334:	48 89 51 28          	mov    %rdx,0x28(%rcx)
    2338:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    233f:	48 8b 14 24          	mov    (%rsp),%rdx
    2343:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
    234a:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    2351:	00 80 3f 
    2354:	48 89 41 38          	mov    %rax,0x38(%rcx)
    2358:	48 89 41 40          	mov    %rax,0x40(%rcx)
    235c:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    2363:	00 00 00 
    2366:	49 8d 85 af c7 07 00 	lea    0x7c7af(%r13),%rax
    236d:	48 89 47 78          	mov    %rax,0x78(%rdi)
    2371:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
    2378:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    237f:	48 8b 57 58          	mov    0x58(%rdi),%rdx
    2383:	48 89 51 78          	mov    %rdx,0x78(%rcx)
    2387:	4c 89 81 80 00 00 00 	mov    %r8,0x80(%rcx)
    238e:	48 8d 57 70          	lea    0x70(%rdi),%rdx
    2392:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    2399:	00 
    239a:	48 89 41 70          	mov    %rax,0x70(%rcx)
    239e:	48 8b 4f 08          	mov    0x8(%rdi),%rcx
    23a2:	8b 71 08             	mov    0x8(%rcx),%esi
    23a5:	4c 8b 47 68          	mov    0x68(%rdi),%r8
    23a9:	45 89 c1             	mov    %r8d,%r9d
    23ac:	31 c0                	xor    %eax,%eax
    23ae:	44 39 c6             	cmp    %r8d,%esi
    23b1:	be 00 00 00 00       	mov    $0x0,%esi
    23b6:	49 0f 47 f1          	cmova  %r9,%rsi
    23ba:	4c 8b 57 48          	mov    0x48(%rdi),%r10
    23be:	4c 8b 59 10          	mov    0x10(%rcx),%r11
    23c2:	8b 12                	mov    (%rdx),%edx
    23c4:	48 0f af f2          	imul   %rdx,%rsi
    23c8:	c4 a1 78 10 84 1e 00 	vmovups 0x2e00(%rsi,%r11,1),%xmm0
    23cf:	2e 00 00 
    23d2:	c4 c1 78 11 02       	vmovups %xmm0,(%r10)
    23d7:	8b 71 08             	mov    0x8(%rcx),%esi
    23da:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    23de:	45 31 d2             	xor    %r10d,%r10d
    23e1:	41 89 f3             	mov    %esi,%r11d
    23e4:	45 31 c3             	xor    %r8d,%r11d
    23e7:	41 0f 94 c2          	sete   %r10b
    23eb:	31 db                	xor    %ebx,%ebx
    23ed:	89 f5                	mov    %esi,%ebp
    23ef:	44 29 c5             	sub    %r8d,%ebp
    23f2:	0f 93 c3             	setae  %bl
    23f5:	49 0f 47 c1          	cmova  %r9,%rax
    23f9:	31 ee                	xor    %ebp,%esi
    23fb:	44 21 de             	and    %r11d,%esi
    23fe:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    2404:	41 c1 e2 1e          	shl    $0x1e,%r10d
    2408:	c1 e3 1d             	shl    $0x1d,%ebx
    240b:	44 09 d3             	or     %r10d,%ebx
    240e:	09 eb                	or     %ebp,%ebx
    2410:	c1 ee 03             	shr    $0x3,%esi
    2413:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    2419:	09 de                	or     %ebx,%esi
    241b:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    2422:	48 0f af c2          	imul   %rdx,%rax
    2426:	48 8b 94 08 80 30 00 	mov    0x3080(%rax,%rcx,1),%rdx
    242d:	00 
    242e:	48 8b b7 b0 00 00 00 	mov    0xb0(%rdi),%rsi
    2435:	4c 8b 87 d0 00 00 00 	mov    0xd0(%rdi),%r8
    243c:	48 89 37             	mov    %rsi,(%rdi)
    243f:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    2446:	00 
    2447:	48 8b b4 08 88 30 00 	mov    0x3088(%rax,%rcx,1),%rsi
    244e:	00 
    244f:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    2453:	49 89 10             	mov    %rdx,(%r8)
    2456:	49 89 70 08          	mov    %rsi,0x8(%r8)
    245a:	48 8b 94 08 90 30 00 	mov    0x3090(%rax,%rcx,1),%rdx
    2461:	00 
    2462:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    2466:	8b 84 08 98 30 00 00 	mov    0x3098(%rax,%rcx,1),%eax
    246d:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
    2474:	89 41 08             	mov    %eax,0x8(%rcx)
    2477:	48 8b 87 e8 00 00 00 	mov    0xe8(%rdi),%rax
    247e:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    2482:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2486:	48 89 11             	mov    %rdx,(%rcx)
    2489:	49 8d 85 ea 0b 51 fd 	lea    -0x2aef416(%r13),%rax
    2490:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    2497:	48 89 fb             	mov    %rdi,%rbx
    249a:	c5 f8 77             	vzeroupper
    249d:	e8 00 00 00 00       	call   24a2 <f_8001161d0+0x24a2>
    24a2:	48 89 df             	mov    %rbx,%rdi
    24a5:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    24ac:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    24b3:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    24ba:	48 89 01             	mov    %rax,(%rcx)
    24bd:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
    24c4:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
    24cb:	48 8b b0 04 16 00 00 	mov    0x1604(%rax),%rsi
    24d2:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
    24d6:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    24da:	88 51 08             	mov    %dl,0x8(%rcx)
    24dd:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    24e4:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
    24e8:	8b 80 0c 16 00 00    	mov    0x160c(%rax),%eax
    24ee:	48 89 43 40          	mov    %rax,0x40(%rbx)
    24f2:	48 c7 47 48 02 00 00 	movq   $0x2,0x48(%rdi)
    24f9:	00 
    24fa:	89 41 24             	mov    %eax,0x24(%rcx)
    24fd:	c7 81 bc 00 00 00 02 	movl   $0x2,0xbc(%rcx)
    2504:	00 00 00 
    2507:	e9 35 07 00 00       	jmp    2c41 <f_8001161d0+0x2c41>
    250c:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    2513:	00 
    2514:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    251b:	48 c7 03 80 00 00 00 	movq   $0x80,(%rbx)
    2522:	48 b9 00 00 00 00 00 	movabs $0x60000000000000,%rcx
    2529:	00 60 00 
    252c:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    2530:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
    2537:	00 
    2538:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    253f:	ff ff ff 
    2542:	48 8d 4a 12          	lea    0x12(%rdx),%rcx
    2546:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    254a:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2551:	00 00 00 
    2554:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
    2558:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    255c:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    2562:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    2566:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    256d:	00 80 3f 
    2570:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    2574:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
    2578:	48 83 c3 38          	add    $0x38,%rbx
    257c:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
    2583:	00 00 00 
    2586:	4c 8d 8a 6d 4f 0a 00 	lea    0xa4f6d(%rdx),%r9
    258d:	e9 e1 04 00 00       	jmp    2a73 <f_8001161d0+0x2a73>
    2592:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
    2599:	48 8b 97 a0 00 00 00 	mov    0xa0(%rdi),%rdx
    25a0:	48 8b 92 c8 1e 00 00 	mov    0x1ec8(%rdx),%rdx
    25a7:	48 89 57 08          	mov    %rdx,0x8(%rdi)
    25ab:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    25b0:	48 89 77 60          	mov    %rsi,0x60(%rdi)
    25b4:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    25bb:	00 
    25bc:	44 0f b6 49 08       	movzbl 0x8(%rcx),%r9d
    25c1:	4c 89 4f 68          	mov    %r9,0x68(%rdi)
    25c5:	8b 5a 08             	mov    0x8(%rdx),%ebx
    25c8:	4d 69 f1 e0 3c 00 00 	imul   $0x3ce0,%r9,%r14
    25cf:	31 c9                	xor    %ecx,%ecx
    25d1:	44 39 cb             	cmp    %r9d,%ebx
    25d4:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    25d8:	48 c7 47 70 e0 3c 00 	movq   $0x3ce0,0x70(%rdi)
    25df:	00 
    25e0:	4c 0f 46 f1          	cmovbe %rcx,%r14
    25e4:	49 8b 94 16 40 3c 00 	mov    0x3c40(%r14,%rdx,1),%rdx
    25eb:	00 
    25ec:	48 89 17             	mov    %rdx,(%rdi)
    25ef:	4c 8b 8f 00 01 00 00 	mov    0x100(%rdi),%r9
    25f6:	45 89 91 a0 00 00 00 	mov    %r10d,0xa0(%r9)
    25fd:	49 89 b1 88 00 00 00 	mov    %rsi,0x88(%r9)
    2604:	48 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rdx
    260b:	ff 7f 7f 
    260e:	49 89 91 90 00 00 00 	mov    %rdx,0x90(%r9)
    2615:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    261c:	00 
    261d:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2621:	41 c7 81 bc 00 00 00 	movl   $0x0,0xbc(%r9)
    2628:	00 00 00 00 
    262c:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2630:	c4 c1 78 11 41 58    	vmovups %xmm0,0x58(%r9)
    2636:	49 c7 01 20 00 00 00 	movq   $0x20,(%r9)
    263d:	48 b8 00 00 00 00 00 	movabs $0x42080000000000,%rax
    2644:	08 42 00 
    2647:	49 89 41 08          	mov    %rax,0x8(%r9)
    264b:	49 c7 41 48 00 00 00 	movq   $0x0,0x48(%r9)
    2652:	00 
    2653:	49 89 69 50          	mov    %rbp,0x50(%r9)
    2657:	49 c7 41 30 07 00 00 	movq   $0x7,0x30(%r9)
    265e:	00 
    265f:	49 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%r9)
    2666:	00 
    2667:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    266e:	ff ff ff 
    2671:	48 8d 42 0a          	lea    0xa(%rdx),%rax
    2675:	49 89 41 18          	mov    %rax,0x18(%r9)
    2679:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2680:	00 00 00 
    2683:	49 89 41 20          	mov    %rax,0x20(%r9)
    2687:	49 89 51 28          	mov    %rdx,0x28(%r9)
    268b:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    2692:	48 8b 14 24          	mov    (%rsp),%rdx
    2696:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
    269d:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    26a4:	00 80 3f 
    26a7:	49 89 41 38          	mov    %rax,0x38(%r9)
    26ab:	49 89 41 40          	mov    %rax,0x40(%r9)
    26af:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    26b6:	00 00 00 
    26b9:	49 8d 85 c5 e4 0b 00 	lea    0xbe4c5(%r13),%rax
    26c0:	48 89 47 78          	mov    %rax,0x78(%rdi)
    26c4:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
    26cb:	4d 89 81 98 00 00 00 	mov    %r8,0x98(%r9)
    26d2:	48 8b 57 58          	mov    0x58(%rdi),%rdx
    26d6:	49 89 51 78          	mov    %rdx,0x78(%r9)
    26da:	4d 89 81 80 00 00 00 	mov    %r8,0x80(%r9)
    26e1:	49 c7 41 68 00 00 00 	movq   $0x0,0x68(%r9)
    26e8:	00 
    26e9:	49 89 41 70          	mov    %rax,0x70(%r9)
    26ed:	48 8b 47 08          	mov    0x8(%rdi),%rax
    26f1:	4c 8b 47 68          	mov    0x68(%rdi),%r8
    26f5:	45 89 c1             	mov    %r8d,%r9d
    26f8:	44 39 40 08          	cmp    %r8d,0x8(%rax)
    26fc:	be 00 00 00 00       	mov    $0x0,%esi
    2701:	49 0f 47 f1          	cmova  %r9,%rsi
    2705:	4c 8b 57 48          	mov    0x48(%rdi),%r10
    2709:	4c 8b 58 10          	mov    0x10(%rax),%r11
    270d:	8b 57 70             	mov    0x70(%rdi),%edx
    2710:	48 0f af f2          	imul   %rdx,%rsi
    2714:	c4 a1 78 10 84 1e b0 	vmovups 0x30b0(%rsi,%r11,1),%xmm0
    271b:	30 00 00 
    271e:	c4 c1 78 11 02       	vmovups %xmm0,(%r10)
    2723:	8b 70 08             	mov    0x8(%rax),%esi
    2726:	45 31 d2             	xor    %r10d,%r10d
    2729:	41 89 f3             	mov    %esi,%r11d
    272c:	45 31 c3             	xor    %r8d,%r11d
    272f:	41 0f 94 c2          	sete   %r10b
    2733:	31 db                	xor    %ebx,%ebx
    2735:	89 f5                	mov    %esi,%ebp
    2737:	44 29 c5             	sub    %r8d,%ebp
    273a:	49 0f 47 c9          	cmova  %r9,%rcx
    273e:	0f 93 c3             	setae  %bl
    2741:	31 ee                	xor    %ebp,%esi
    2743:	44 21 de             	and    %r11d,%esi
    2746:	41 c1 e2 1e          	shl    $0x1e,%r10d
    274a:	c1 e3 1d             	shl    $0x1d,%ebx
    274d:	44 09 d3             	or     %r10d,%ebx
    2750:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    2756:	09 eb                	or     %ebp,%ebx
    2758:	48 8b 40 10          	mov    0x10(%rax),%rax
    275c:	c1 ee 03             	shr    $0x3,%esi
    275f:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    2765:	09 de                	or     %ebx,%esi
    2767:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    276e:	48 0f af ca          	imul   %rdx,%rcx
    2772:	48 8b 94 01 30 33 00 	mov    0x3330(%rcx,%rax,1),%rdx
    2779:	00 
    277a:	48 8b b4 01 38 33 00 	mov    0x3338(%rcx,%rax,1),%rsi
    2781:	00 
    2782:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    2786:	4c 8b 87 d0 00 00 00 	mov    0xd0(%rdi),%r8
    278d:	49 89 10             	mov    %rdx,(%r8)
    2790:	49 89 70 08          	mov    %rsi,0x8(%r8)
    2794:	48 8b 94 01 40 33 00 	mov    0x3340(%rcx,%rax,1),%rdx
    279b:	00 
    279c:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    27a0:	8b 84 01 48 33 00 00 	mov    0x3348(%rcx,%rax,1),%eax
    27a7:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
    27ae:	89 41 08             	mov    %eax,0x8(%rcx)
    27b1:	48 8b 87 e8 00 00 00 	mov    0xe8(%rdi),%rax
    27b8:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    27bc:	48 89 47 40          	mov    %rax,0x40(%rdi)
    27c0:	48 89 11             	mov    %rdx,(%rcx)
    27c3:	49 8d 85 72 0d 51 fd 	lea    -0x2aef28e(%r13),%rax
    27ca:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    27d1:	48 89 fb             	mov    %rdi,%rbx
    27d4:	c5 f8 77             	vzeroupper
    27d7:	e8 00 00 00 00       	call   27dc <f_8001161d0+0x27dc>
    27dc:	48 89 df             	mov    %rbx,%rdi
    27df:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    27e6:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    27ed:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    27f4:	48 89 01             	mov    %rax,(%rcx)
    27f7:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    27fe:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    2802:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2806:	88 41 08             	mov    %al,0x8(%rcx)
    2809:	b9 bc 00 00 00       	mov    $0xbc,%ecx
    280e:	48 03 8b 00 01 00 00 	add    0x100(%rbx),%rcx
    2815:	e9 d4 08 00 00       	jmp    30ee <f_8001161d0+0x30ee>
    281a:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    281e:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    2825:	48 c7 01 01 00 00 00 	movq   $0x1,(%rcx)
    282c:	48 ba 00 00 00 00 00 	movabs $0x40000000000000,%rdx
    2833:	00 40 00 
    2836:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    283a:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    2841:	00 
    2842:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    2849:	ff ff ff 
    284c:	4d 89 c1             	mov    %r8,%r9
    284f:	49 89 d0             	mov    %rdx,%r8
    2852:	48 83 c2 15          	add    $0x15,%rdx
    2856:	48 89 51 18          	mov    %rdx,0x18(%rcx)
    285a:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2861:	00 
    2862:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2869:	00 00 00 
    286c:	48 89 41 20          	mov    %rax,0x20(%rcx)
    2870:	4c 89 41 28          	mov    %r8,0x28(%rcx)
    2874:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    2879:	48 89 41 30          	mov    %rax,0x30(%rcx)
    287d:	49 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r8
    2884:	00 80 3f 
    2887:	4c 89 41 38          	mov    %r8,0x38(%rcx)
    288b:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    2892:	00 00 00 
    2895:	48 8d 80 7c 4f 0a 00 	lea    0xa4f7c(%rax),%rax
    289c:	48 89 41 70          	mov    %rax,0x70(%rcx)
    28a0:	48 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rbx
    28a7:	ff 7f 7f 
    28aa:	48 89 59 78          	mov    %rbx,0x78(%rcx)
    28ae:	4c 89 89 80 00 00 00 	mov    %r9,0x80(%rcx)
    28b5:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    28ba:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    28c1:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 28c9 <f_8001161d0+0x28c9>
    28c8:	00 
    28c9:	c5 fc 11 47 60       	vmovups %ymm0,0x60(%rdi)
    28ce:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    28d5:	48 8b 14 24          	mov    (%rsp),%rdx
    28d9:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
    28e0:	4c 89 41 40          	mov    %r8,0x40(%rcx)
    28e4:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    28eb:	00 
    28ec:	48 89 99 90 00 00 00 	mov    %rbx,0x90(%rcx)
    28f3:	4c 89 89 98 00 00 00 	mov    %r9,0x98(%rcx)
    28fa:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    2901:	00 
    2902:	48 89 69 50          	mov    %rbp,0x50(%rcx)
    2906:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    290a:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    290f:	48 c7 47 50 03 00 00 	movq   $0x3,0x50(%rdi)
    2916:	00 
    2917:	b8 03 00 00 00       	mov    $0x3,%eax
    291c:	e9 f0 01 00 00       	jmp    2b11 <f_8001161d0+0x2b11>
    2921:	48 c7 47 40 b0 1e 00 	movq   $0x1eb0,0x40(%rdi)
    2928:	00 
    2929:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    2930:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    2937:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    293b:	48 89 47 10          	mov    %rax,0x10(%rdi)
    293f:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    2944:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
    294b:	48 89 07             	mov    %rax,(%rdi)
    294e:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    2955:	00 00 00 
    2958:	49 8d 85 2e 0c 51 fd 	lea    -0x2aef3d2(%r13),%rax
    295f:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    2966:	48 89 fb             	mov    %rdi,%rbx
    2969:	c5 f8 77             	vzeroupper
    296c:	e8 00 00 00 00       	call   2971 <f_8001161d0+0x2971>
    2971:	48 89 df             	mov    %rbx,%rdi
    2974:	e9 c8 02 00 00       	jmp    2c41 <f_8001161d0+0x2c41>
    2979:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    2980:	00 
    2981:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    2988:	48 c7 03 03 00 00 00 	movq   $0x3,(%rbx)
    298f:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    2996:	00 40 00 
    2999:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    299d:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
    29a4:	00 
    29a5:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    29ac:	ff ff ff 
    29af:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    29b3:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    29b7:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    29be:	00 00 00 
    29c1:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
    29c5:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    29c9:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    29cf:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    29d3:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    29da:	00 80 3f 
    29dd:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    29e1:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
    29e5:	48 83 c3 38          	add    $0x38,%rbx
    29e9:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
    29f0:	00 00 00 
    29f3:	4c 8d 8a fb b3 05 00 	lea    0x5b3fb(%rdx),%r9
    29fa:	eb 77                	jmp    2a73 <f_8001161d0+0x2a73>
    29fc:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    2a03:	ff ff ff 
    2a06:	48 8d 4a 0e          	lea    0xe(%rdx),%rcx
    2a0a:	48 89 4f 78          	mov    %rcx,0x78(%rdi)
    2a0e:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    2a15:	48 c7 03 00 04 00 00 	movq   $0x400,(%rbx)
    2a1c:	48 c7 43 08 00 00 00 	movq   $0x0,0x8(%rbx)
    2a23:	00 
    2a24:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
    2a2b:	00 
    2a2c:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    2a30:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2a37:	00 00 00 
    2a3a:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
    2a3e:	48 89 53 28          	mov    %rdx,0x28(%rbx)
    2a42:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    2a48:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    2a4c:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    2a53:	00 80 3f 
    2a56:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    2a5a:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
    2a5e:	48 83 c3 38          	add    $0x38,%rbx
    2a62:	48 ba ca 5d c0 02 08 	movabs $0x802c05dca,%rdx
    2a69:	00 00 00 
    2a6c:	4c 8d 8a d9 85 00 00 	lea    0x85d9(%rdx),%r9
    2a73:	4c 89 01             	mov    %r8,(%rcx)
    2a76:	4c 89 33             	mov    %r14,(%rbx)
    2a79:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    2a80:	4c 89 49 70          	mov    %r9,0x70(%rcx)
    2a84:	49 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r9
    2a8b:	ff 7f 7f 
    2a8e:	4c 89 49 78          	mov    %r9,0x78(%rcx)
    2a92:	48 ba ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdx
    2a99:	ff 7f ff 
    2a9c:	48 89 57 68          	mov    %rdx,0x68(%rdi)
    2aa0:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2aa4:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2aab:	00 
    2aac:	48 89 91 80 00 00 00 	mov    %rdx,0x80(%rcx)
    2ab3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2ab8:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    2abf:	4c 8b 04 24          	mov    (%rsp),%r8
    2ac3:	4c 89 47 60          	mov    %r8,0x60(%rdi)
    2ac7:	4c 89 71 40          	mov    %r14,0x40(%rcx)
    2acb:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    2ad2:	00 
    2ad3:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    2ada:	4c 89 80 a4 00 00 00 	mov    %r8,0xa4(%rax)
    2ae1:	48 89 69 50          	mov    %rbp,0x50(%rcx)
    2ae5:	48 c7 41 58 00 00 00 	movq   $0x0,0x58(%rcx)
    2aec:	00 
    2aed:	48 c7 47 50 02 00 00 	movq   $0x2,0x50(%rdi)
    2af4:	00 
    2af5:	4c 89 89 90 00 00 00 	mov    %r9,0x90(%rcx)
    2afc:	48 89 91 98 00 00 00 	mov    %rdx,0x98(%rcx)
    2b03:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2b07:	c5 f8 11 41 60       	vmovups %xmm0,0x60(%rcx)
    2b0c:	b8 02 00 00 00       	mov    $0x2,%eax
    2b11:	4c 8b 5c 24 10       	mov    0x10(%rsp),%r11
    2b16:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
    2b1d:	89 81 bc 00 00 00    	mov    %eax,0xbc(%rcx)
    2b23:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
    2b2a:	48 8b 87 a0 00 00 00 	mov    0xa0(%rdi),%rax
    2b31:	48 8b 80 c8 1e 00 00 	mov    0x1ec8(%rax),%rax
    2b38:	0f b6 71 08          	movzbl 0x8(%rcx),%esi
    2b3c:	4c 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%r8
    2b43:	31 c9                	xor    %ecx,%ecx
    2b45:	39 70 08             	cmp    %esi,0x8(%rax)
    2b48:	ba 00 00 00 00       	mov    $0x0,%edx
    2b4d:	49 0f 47 d0          	cmova  %r8,%rdx
    2b51:	4c 8b 48 10          	mov    0x10(%rax),%r9
    2b55:	4e 8b 94 0a 08 2e 00 	mov    0x2e08(%rdx,%r9,1),%r10
    2b5c:	00 
    2b5d:	4c 89 57 68          	mov    %r10,0x68(%rdi)
    2b61:	4a 8b 94 0a 00 2e 00 	mov    0x2e00(%rdx,%r9,1),%rdx
    2b68:	00 
    2b69:	49 89 13             	mov    %rdx,(%r11)
    2b6c:	4d 89 53 08          	mov    %r10,0x8(%r11)
    2b70:	44 8b 48 08          	mov    0x8(%rax),%r9d
    2b74:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2b78:	48 89 57 60          	mov    %rdx,0x60(%rdi)
    2b7c:	45 31 d2             	xor    %r10d,%r10d
    2b7f:	45 31 db             	xor    %r11d,%r11d
    2b82:	44 89 cb             	mov    %r9d,%ebx
    2b85:	29 f3                	sub    %esi,%ebx
    2b87:	49 0f 47 c8          	cmova  %r8,%rcx
    2b8b:	41 0f 94 c2          	sete   %r10b
    2b8f:	41 0f 93 c3          	setae  %r11b
    2b93:	c4 c2 60 f2 f1       	andn   %r9d,%ebx,%esi
    2b98:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    2b9e:	41 c1 e2 1e          	shl    $0x1e,%r10d
    2ba2:	41 c1 e3 1d          	shl    $0x1d,%r11d
    2ba6:	45 09 d3             	or     %r10d,%r11d
    2ba9:	41 09 db             	or     %ebx,%r11d
    2bac:	c1 ee 03             	shr    $0x3,%esi
    2baf:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    2bb5:	44 09 de             	or     %r11d,%esi
    2bb8:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    2bbf:	48 8b b4 0a 80 30 00 	mov    0x3080(%rdx,%rcx,1),%rsi
    2bc6:	00 
    2bc7:	4c 8b 84 0a 88 30 00 	mov    0x3088(%rdx,%rcx,1),%r8
    2bce:	00 
    2bcf:	48 89 77 58          	mov    %rsi,0x58(%rdi)
    2bd3:	49 89 75 00          	mov    %rsi,0x0(%r13)
    2bd7:	4d 89 45 08          	mov    %r8,0x8(%r13)
    2bdb:	8b b4 0a 98 30 00 00 	mov    0x3098(%rdx,%rcx,1),%esi
    2be2:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    2be6:	48 8b 8c 0a 90 30 00 	mov    0x3090(%rdx,%rcx,1),%rcx
    2bed:	00 
    2bee:	48 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%rdx
    2bf5:	48 89 0a             	mov    %rcx,(%rdx)
    2bf8:	89 72 08             	mov    %esi,0x8(%rdx)
    2bfb:	8b 50 20             	mov    0x20(%rax),%edx
    2bfe:	8b 48 24             	mov    0x24(%rax),%ecx
    2c01:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    2c05:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    2c09:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    2c10:	c7 80 b4 00 00 00 00 	movl   $0x0,0xb4(%rax)
    2c17:	00 00 00 
    2c1a:	48 8b b7 c0 00 00 00 	mov    0xc0(%rdi),%rsi
    2c21:	c7 86 b1 00 00 00 00 	movl   $0x0,0xb1(%rsi)
    2c28:	00 00 00 
    2c2b:	88 90 b0 00 00 00    	mov    %dl,0xb0(%rax)
    2c31:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    2c38:	00 00 00 
    2c3b:	88 88 b8 00 00 00    	mov    %cl,0xb8(%rax)
    2c41:	4c 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%r9
    2c48:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    2c4f:	8b 08                	mov    (%rax),%ecx
    2c51:	48 89 4f 50          	mov    %rcx,0x50(%rdi)
    2c55:	49 8d 51 1c          	lea    0x1c(%r9),%rdx
    2c59:	41 8b 71 1c          	mov    0x1c(%r9),%esi
    2c5d:	48 89 57 40          	mov    %rdx,0x40(%rdi)
    2c61:	48 89 77 48          	mov    %rsi,0x48(%rdi)
    2c65:	89 70 48             	mov    %esi,0x48(%rax)
    2c68:	4d 8d 51 2c          	lea    0x2c(%r9),%r10
    2c6c:	45 8b 41 2c          	mov    0x2c(%r9),%r8d
    2c70:	45 31 db             	xor    %r11d,%r11d
    2c73:	4d 85 c0             	test   %r8,%r8
    2c76:	41 0f 94 c3          	sete   %r11b
    2c7a:	4c 89 97 b0 00 00 00 	mov    %r10,0xb0(%rdi)
    2c81:	4c 89 47 60          	mov    %r8,0x60(%rdi)
    2c85:	45 8b 49 14          	mov    0x14(%r9),%r9d
    2c89:	45 31 d2             	xor    %r10d,%r10d
    2c8c:	41 85 c9             	test   %ecx,%r9d
    2c8f:	41 0f 95 c2          	setne  %r10b
    2c93:	4c 89 57 58          	mov    %r10,0x58(%rdi)
    2c97:	45 89 c2             	mov    %r8d,%r10d
    2c9a:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    2ca1:	44 89 db             	mov    %r11d,%ebx
    2ca4:	c1 e3 1e             	shl    $0x1e,%ebx
    2ca7:	49 01 da             	add    %rbx,%r10
    2caa:	49 81 c2 00 00 00 20 	add    $0x20000000,%r10
    2cb1:	4c 89 97 10 01 00 00 	mov    %r10,0x110(%rdi)
    2cb8:	41 c1 e8 1f          	shr    $0x1f,%r8d
    2cbc:	45 08 c3             	or     %r8b,%r11b
    2cbf:	74 0d                	je     2cce <f_8001161d0+0x2cce>
    2cc1:	48 c7 47 58 00 00 00 	movq   $0x0,0x58(%rdi)
    2cc8:	00 
    2cc9:	e9 73 01 00 00       	jmp    2e41 <f_8001161d0+0x2e41>
    2cce:	41 85 c9             	test   %ecx,%r9d
    2cd1:	0f 84 6a 01 00 00    	je     2e41 <f_8001161d0+0x2e41>
    2cd7:	4c 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%r9
    2cde:	4c 8b 97 a8 00 00 00 	mov    0xa8(%rdi),%r10
    2ce5:	4d 8d 81 40 01 00 00 	lea    0x140(%r9),%r8
    2cec:	4c 89 87 c0 00 00 00 	mov    %r8,0xc0(%rdi)
    2cf3:	45 89 d0             	mov    %r10d,%r8d
    2cf6:	4d 63 d2             	movslq %r10d,%r10
    2cf9:	49 c1 fa 1f          	sar    $0x1f,%r10
    2cfd:	49 bb 00 00 00 00 ff 	movabs $0xffffffff00000000,%r11
    2d04:	ff ff ff 
    2d07:	4d 21 da             	and    %r11,%r10
    2d0a:	4d 09 c2             	or     %r8,%r10
    2d0d:	4c 89 97 c8 00 00 00 	mov    %r10,0xc8(%rdi)
    2d14:	47 0f b6 8c 11 40 01 	movzbl 0x140(%r9,%r10,1),%r9d
    2d1b:	00 00 
    2d1d:	4c 89 4f 58          	mov    %r9,0x58(%rdi)
    2d21:	41 f6 c1 01          	test   $0x1,%r9b
    2d25:	0f 84 16 01 00 00    	je     2e41 <f_8001161d0+0x2e41>
    2d2b:	44 0f b6 48 0c       	movzbl 0xc(%rax),%r9d
    2d30:	4c 89 4f 58          	mov    %r9,0x58(%rdi)
    2d34:	41 f6 c1 01          	test   $0x1,%r9b
    2d38:	74 09                	je     2d43 <f_8001161d0+0x2d43>
    2d3a:	48 09 ce             	or     %rcx,%rsi
    2d3d:	48 89 77 48          	mov    %rsi,0x48(%rdi)
    2d41:	89 32                	mov    %esi,(%rdx)
    2d43:	48 c7 47 40 d0 00 00 	movq   $0xd0,0x40(%rdi)
    2d4a:	00 
    2d4b:	48 89 47 08          	mov    %rax,0x8(%rdi)
    2d4f:	49 63 c0             	movslq %r8d,%rax
    2d52:	48 69 c0 d0 00 00 00 	imul   $0xd0,%rax,%rax
    2d59:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
    2d60:	48 8d 14 01          	lea    (%rcx,%rax,1),%rdx
    2d64:	48 89 97 d0 00 00 00 	mov    %rdx,0xd0(%rdi)
    2d6b:	48 c7 47 10 c0 00 00 	movq   $0xc0,0x10(%rdi)
    2d72:	00 
    2d73:	48 8d 84 01 40 0d 00 	lea    0xd40(%rcx,%rax,1),%rax
    2d7a:	00 
    2d7b:	48 89 87 a8 00 00 00 	mov    %rax,0xa8(%rdi)
    2d82:	48 89 07             	mov    %rax,(%rdi)
    2d85:	49 8d 85 6e 12 51 fd 	lea    -0x2aeed92(%r13),%rax
    2d8c:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    2d93:	48 89 fb             	mov    %rdi,%rbx
    2d96:	c5 f8 77             	vzeroupper
    2d99:	e8 00 00 00 00       	call   2d9e <f_8001161d0+0x2d9e>
    2d9e:	48 89 df             	mov    %rbx,%rdi
    2da1:	48 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%rax
    2da8:	80 88 38 0d 00 00 01 	orb    $0x1,0xd38(%rax)
    2daf:	4c 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%r8
    2db6:	41 0f b6 80 81 3a 00 	movzbl 0x3a81(%r8),%eax
    2dbd:	00 
    2dbe:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2dc2:	a8 40                	test   $0x40,%al
    2dc4:	74 7b                	je     2e41 <f_8001161d0+0x2e41>
    2dc6:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    2dcd:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
    2dd4:	0f b6 04 01          	movzbl (%rcx,%rax,1),%eax
    2dd8:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2ddc:	a8 02                	test   $0x2,%al
    2dde:	74 61                	je     2e41 <f_8001161d0+0x2e41>
    2de0:	49 8b 80 60 3b 00 00 	mov    0x3b60(%r8),%rax
    2de7:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2deb:	48 85 c0             	test   %rax,%rax
    2dee:	74 51                	je     2e41 <f_8001161d0+0x2e41>
    2df0:	41 0f b6 80 85 3a 00 	movzbl 0x3a85(%r8),%eax
    2df7:	00 
    2df8:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2dfc:	a8 02                	test   $0x2,%al
    2dfe:	74 41                	je     2e41 <f_8001161d0+0x2e41>
    2e00:	48 8b 87 a8 00 00 00 	mov    0xa8(%rdi),%rax
    2e07:	48 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%rcx
    2e0e:	8b 00                	mov    (%rax),%eax
    2e10:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2e14:	8b 49 10             	mov    0x10(%rcx),%ecx
    2e17:	31 d2                	xor    %edx,%edx
    2e19:	c4 e2 70 f2 c0       	andn   %eax,%ecx,%eax
    2e1e:	0f 94 c2             	sete   %dl
    2e21:	89 c6                	mov    %eax,%esi
    2e23:	81 e6 00 00 00 80    	and    $0x80000000,%esi
    2e29:	c1 e2 1e             	shl    $0x1e,%edx
    2e2c:	09 f2                	or     %esi,%edx
    2e2e:	48 89 4f 48          	mov    %rcx,0x48(%rdi)
    2e32:	48 89 97 10 01 00 00 	mov    %rdx,0x110(%rdi)
    2e39:	85 c0                	test   %eax,%eax
    2e3b:	0f 84 ac 05 00 00    	je     33ed <f_8001161d0+0x33ed>
    2e41:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    2e48:	48 8b 88 20 01 00 00 	mov    0x120(%rax),%rcx
    2e4f:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    2e56:	48 89 8f a0 00 00 00 	mov    %rcx,0xa0(%rdi)
    2e5d:	48 89 97 98 00 00 00 	mov    %rdx,0x98(%rdi)
    2e64:	48 8b 88 10 01 00 00 	mov    0x110(%rax),%rcx
    2e6b:	48 8b 90 18 01 00 00 	mov    0x118(%rax),%rdx
    2e72:	48 89 8f b0 00 00 00 	mov    %rcx,0xb0(%rdi)
    2e79:	48 89 97 a8 00 00 00 	mov    %rdx,0xa8(%rdi)
    2e80:	48 8b 88 00 01 00 00 	mov    0x100(%rax),%rcx
    2e87:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    2e8e:	48 89 8f c0 00 00 00 	mov    %rcx,0xc0(%rdi)
    2e95:	48 89 97 b8 00 00 00 	mov    %rdx,0xb8(%rdi)
    2e9c:	48 8b 88 f0 00 00 00 	mov    0xf0(%rax),%rcx
    2ea3:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
    2eaa:	48 89 8f d0 00 00 00 	mov    %rcx,0xd0(%rdi)
    2eb1:	48 89 97 c8 00 00 00 	mov    %rdx,0xc8(%rdi)
    2eb8:	48 8b 88 e0 00 00 00 	mov    0xe0(%rax),%rcx
    2ebf:	48 8b 90 e8 00 00 00 	mov    0xe8(%rax),%rdx
    2ec6:	48 89 8f e0 00 00 00 	mov    %rcx,0xe0(%rdi)
    2ecd:	48 89 97 d8 00 00 00 	mov    %rdx,0xd8(%rdi)
    2ed4:	c5 f8 10 80 d0 00 00 	vmovups 0xd0(%rax),%xmm0
    2edb:	00 
    2edc:	c5 f8 11 87 e8 00 00 	vmovups %xmm0,0xe8(%rdi)
    2ee3:	00 
    2ee4:	48 05 30 01 00 00    	add    $0x130,%rax
    2eea:	48 89 87 00 01 00 00 	mov    %rax,0x100(%rdi)
    2ef1:	48 83 c4 18          	add    $0x18,%rsp
    2ef5:	5b                   	pop    %rbx
    2ef6:	41 5c                	pop    %r12
    2ef8:	41 5d                	pop    %r13
    2efa:	41 5e                	pop    %r14
    2efc:	41 5f                	pop    %r15
    2efe:	5d                   	pop    %rbp
    2eff:	c5 f8 77             	vzeroupper
    2f02:	c3                   	ret
    2f03:	4c 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%r9
    2f0a:	49 8b 89 c8 1e 00 00 	mov    0x1ec8(%r9),%rcx
    2f11:	48 89 8f b0 00 00 00 	mov    %rcx,0xb0(%rdi)
    2f18:	48 89 ee             	mov    %rbp,%rsi
    2f1b:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    2f22:	ff ff ff 
    2f25:	48 8d 55 1a          	lea    0x1a(%rbp),%rdx
    2f29:	48 89 57 70          	mov    %rdx,0x70(%rdi)
    2f2d:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2f31:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    2f38:	48 c7 01 00 20 00 00 	movq   $0x2000,(%rcx)
    2f3f:	48 c7 41 08 00 00 00 	movq   $0x0,0x8(%rcx)
    2f46:	00 
    2f47:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    2f4e:	00 
    2f4f:	48 89 51 18          	mov    %rdx,0x18(%rcx)
    2f53:	48 8b 97 98 00 00 00 	mov    0x98(%rdi),%rdx
    2f5a:	48 89 57 08          	mov    %rdx,0x8(%rdi)
    2f5e:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2f65:	00 
    2f66:	44 89 91 a0 00 00 00 	mov    %r10d,0xa0(%rcx)
    2f6d:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2f74:	00 00 00 
    2f77:	48 89 41 20          	mov    %rax,0x20(%rcx)
    2f7b:	48 89 69 28          	mov    %rbp,0x28(%rcx)
    2f7f:	49 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r10
    2f86:	00 80 3f 
    2f89:	4c 89 57 68          	mov    %r10,0x68(%rdi)
    2f8d:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    2f92:	48 89 41 30          	mov    %rax,0x30(%rcx)
    2f96:	4c 89 51 38          	mov    %r10,0x38(%rcx)
    2f9a:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    2fa1:	00 00 00 
    2fa4:	49 8d 85 95 53 09 00 	lea    0x95395(%r13),%rax
    2fab:	48 89 41 70          	mov    %rax,0x70(%rcx)
    2faf:	48 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rbx
    2fb6:	ff 7f 7f 
    2fb9:	48 89 59 78          	mov    %rbx,0x78(%rcx)
    2fbd:	4c 89 81 80 00 00 00 	mov    %r8,0x80(%rcx)
    2fc4:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2fc9:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    2fd0:	48 8b 14 24          	mov    (%rsp),%rdx
    2fd4:	48 89 57 60          	mov    %rdx,0x60(%rdi)
    2fd8:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    2fdf:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
    2fe6:	48 89 99 90 00 00 00 	mov    %rbx,0x90(%rcx)
    2fed:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    2ff4:	48 c7 47 50 b0 1e 00 	movq   $0x1eb0,0x50(%rdi)
    2ffb:	00 
    2ffc:	49 81 c1 b0 1e 00 00 	add    $0x1eb0,%r9
    3003:	4c 89 0f             	mov    %r9,(%rdi)
    3006:	48 89 71 50          	mov    %rsi,0x50(%rcx)
    300a:	48 c7 41 58 00 00 00 	movq   $0x0,0x58(%rcx)
    3011:	00 
    3012:	48 c7 47 48 03 00 00 	movq   $0x3,0x48(%rdi)
    3019:	00 
    301a:	c7 81 bc 00 00 00 03 	movl   $0x3,0xbc(%rcx)
    3021:	00 00 00 
    3024:	4c 89 51 40          	mov    %r10,0x40(%rcx)
    3028:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    302f:	00 
    3030:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    3034:	c5 f8 11 41 60       	vmovups %xmm0,0x60(%rcx)
    3039:	49 8d 85 92 14 51 fd 	lea    -0x2aeeb6e(%r13),%rax
    3040:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    3047:	48 89 fb             	mov    %rdi,%rbx
    304a:	c5 f8 77             	vzeroupper
    304d:	e8 00 00 00 00       	call   3052 <f_8001161d0+0x3052>
    3052:	48 89 df             	mov    %rbx,%rdi
    3055:	48 8b 33             	mov    (%rbx),%rsi
    3058:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    305f:	0f b6 48 08          	movzbl 0x8(%rax),%ecx
    3063:	48 8b 93 b0 00 00 00 	mov    0xb0(%rbx),%rdx
    306a:	8b 42 08             	mov    0x8(%rdx),%eax
    306d:	45 31 c0             	xor    %r8d,%r8d
    3070:	45 31 c9             	xor    %r9d,%r9d
    3073:	41 89 c2             	mov    %eax,%r10d
    3076:	41 29 ca             	sub    %ecx,%r10d
    3079:	41 0f 94 c0          	sete   %r8b
    307d:	41 0f 93 c1          	setae  %r9b
    3081:	c4 62 28 f2 d8       	andn   %eax,%r10d,%r11d
    3086:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    308d:	41 c1 e0 1e          	shl    $0x1e,%r8d
    3091:	41 c1 e1 1d          	shl    $0x1d,%r9d
    3095:	45 09 c1             	or     %r8d,%r9d
    3098:	41 c1 eb 03          	shr    $0x3,%r11d
    309c:	41 81 e3 00 00 00 10 	and    $0x10000000,%r11d
    30a3:	45 09 d3             	or     %r10d,%r11d
    30a6:	45 09 cb             	or     %r9d,%r11d
    30a9:	4c 69 c1 e0 3c 00 00 	imul   $0x3ce0,%rcx,%r8
    30b0:	31 c0                	xor    %eax,%eax
    30b2:	41 81 f9 00 00 00 20 	cmp    $0x20000000,%r9d
    30b9:	49 0f 44 c0          	cmove  %r8,%rax
    30bd:	4c 89 9b 10 01 00 00 	mov    %r11,0x110(%rbx)
    30c4:	48 03 42 10          	add    0x10(%rdx),%rax
    30c8:	40 f6 c6 01          	test   $0x1,%sil
    30cc:	75 33                	jne    3101 <f_8001161d0+0x3101>
    30ce:	41 b9 5c 00 00 00    	mov    $0x5c,%r9d
    30d4:	41 ba 58 00 00 00    	mov    $0x58,%r10d
    30da:	41 bb 54 00 00 00    	mov    $0x54,%r11d
    30e0:	bb 50 00 00 00       	mov    $0x50,%ebx
    30e5:	eb 35                	jmp    311c <f_8001161d0+0x311c>
    30e7:	48 81 c1 bc 00 00 00 	add    $0xbc,%rcx
    30ee:	48 c7 47 40 02 00 00 	movq   $0x2,0x40(%rdi)
    30f5:	00 
    30f6:	c7 01 02 00 00 00    	movl   $0x2,(%rcx)
    30fc:	e9 40 fb ff ff       	jmp    2c41 <f_8001161d0+0x2c41>
    3101:	48 89 47 68          	mov    %rax,0x68(%rdi)
    3105:	41 b9 0c 2e 00 00    	mov    $0x2e0c,%r9d
    310b:	41 ba 08 2e 00 00    	mov    $0x2e08,%r10d
    3111:	41 bb 04 2e 00 00    	mov    $0x2e04,%r11d
    3117:	bb 00 2e 00 00       	mov    $0x2e00,%ebx
    311c:	8b 1c 18             	mov    (%rax,%rbx,1),%ebx
    311f:	48 89 9f 00 02 00 00 	mov    %rbx,0x200(%rdi)
    3126:	48 c7 87 08 02 00 00 	movq   $0x0,0x208(%rdi)
    312d:	00 00 00 00 
    3131:	46 8b 1c 18          	mov    (%rax,%r11,1),%r11d
    3135:	4c 89 9f 10 02 00 00 	mov    %r11,0x210(%rdi)
    313c:	48 c7 87 18 02 00 00 	movq   $0x0,0x218(%rdi)
    3143:	00 00 00 00 
    3147:	46 8b 14 10          	mov    (%rax,%r10,1),%r10d
    314b:	4c 89 97 20 02 00 00 	mov    %r10,0x220(%rdi)
    3152:	48 c7 87 28 02 00 00 	movq   $0x0,0x228(%rdi)
    3159:	00 00 00 00 
    315d:	48 c7 47 58 e0 3c 00 	movq   $0x3ce0,0x58(%rdi)
    3164:	00 
    3165:	46 8b 0c 08          	mov    (%rax,%r9,1),%r9d
    3169:	4c 89 8f 30 02 00 00 	mov    %r9,0x230(%rdi)
    3170:	48 c7 87 38 02 00 00 	movq   $0x0,0x238(%rdi)
    3177:	00 00 00 00 
    317b:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    3182:	89 58 78             	mov    %ebx,0x78(%rax)
    3185:	44 89 58 7c          	mov    %r11d,0x7c(%rax)
    3189:	44 89 90 80 00 00 00 	mov    %r10d,0x80(%rax)
    3190:	44 89 88 84 00 00 00 	mov    %r9d,0x84(%rax)
    3197:	45 31 c9             	xor    %r9d,%r9d
    319a:	39 4a 08             	cmp    %ecx,0x8(%rdx)
    319d:	4d 0f 47 c8          	cmova  %r8,%r9
    31a1:	4c 8b 52 10          	mov    0x10(%rdx),%r10
    31a5:	40 f6 c6 01          	test   $0x1,%sil
    31a9:	0f 85 8b 00 00 00    	jne    323a <f_8001161d0+0x323a>
    31af:	4b 8b 74 11 20       	mov    0x20(%r9,%r10,1),%rsi
    31b4:	4f 8b 5c 11 28       	mov    0x28(%r9,%r10,1),%r11
    31b9:	4c 89 5f 60          	mov    %r11,0x60(%rdi)
    31bd:	48 8b 9f d0 00 00 00 	mov    0xd0(%rdi),%rbx
    31c4:	48 89 33             	mov    %rsi,(%rbx)
    31c7:	4c 89 5b 08          	mov    %r11,0x8(%rbx)
    31cb:	4b 8b 74 11 30       	mov    0x30(%r9,%r10,1),%rsi
    31d0:	47 8b 4c 11 38       	mov    0x38(%r9,%r10,1),%r9d
    31d5:	4c 89 4f 48          	mov    %r9,0x48(%rdi)
    31d9:	4c 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%r10
    31e0:	45 89 4a 08          	mov    %r9d,0x8(%r10)
    31e4:	49 89 32             	mov    %rsi,(%r10)
    31e7:	44 8b 52 08          	mov    0x8(%rdx),%r10d
    31eb:	48 8b 72 10          	mov    0x10(%rdx),%rsi
    31ef:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    31f3:	45 31 c9             	xor    %r9d,%r9d
    31f6:	45 31 db             	xor    %r11d,%r11d
    31f9:	31 db                	xor    %ebx,%ebx
    31fb:	44 89 d5             	mov    %r10d,%ebp
    31fe:	29 cd                	sub    %ecx,%ebp
    3200:	4d 0f 47 c8          	cmova  %r8,%r9
    3204:	41 0f 94 c3          	sete   %r11b
    3208:	0f 93 c3             	setae  %bl
    320b:	c4 c2 50 f2 d2       	andn   %r10d,%ebp,%edx
    3210:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    3216:	41 c1 e3 1e          	shl    $0x1e,%r11d
    321a:	c1 e3 1d             	shl    $0x1d,%ebx
    321d:	44 09 db             	or     %r11d,%ebx
    3220:	09 eb                	or     %ebp,%ebx
    3222:	c1 ea 03             	shr    $0x3,%edx
    3225:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    322b:	09 da                	or     %ebx,%edx
    322d:	4a 8d 0c 0e          	lea    (%rsi,%r9,1),%rcx
    3231:	48 83 c1 40          	add    $0x40,%rcx
    3235:	e9 a8 00 00 00       	jmp    32e2 <f_8001161d0+0x32e2>
    323a:	4b 8b b4 11 80 30 00 	mov    0x3080(%r9,%r10,1),%rsi
    3241:	00 
    3242:	4f 8b 84 11 88 30 00 	mov    0x3088(%r9,%r10,1),%r8
    3249:	00 
    324a:	4c 89 47 60          	mov    %r8,0x60(%rdi)
    324e:	4c 8b 9f d0 00 00 00 	mov    0xd0(%rdi),%r11
    3255:	49 89 33             	mov    %rsi,(%r11)
    3258:	4d 89 43 08          	mov    %r8,0x8(%r11)
    325c:	4b 8b b4 11 90 30 00 	mov    0x3090(%r9,%r10,1),%rsi
    3263:	00 
    3264:	47 8b 84 11 98 30 00 	mov    0x3098(%r9,%r10,1),%r8d
    326b:	00 
    326c:	4c 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%r9
    3273:	45 89 41 08          	mov    %r8d,0x8(%r9)
    3277:	49 89 31             	mov    %rsi,(%r9)
    327a:	44 8b 4a 08          	mov    0x8(%rdx),%r9d
    327e:	48 8b 72 10          	mov    0x10(%rdx),%rsi
    3282:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    3286:	45 31 c0             	xor    %r8d,%r8d
    3289:	45 31 d2             	xor    %r10d,%r10d
    328c:	45 31 db             	xor    %r11d,%r11d
    328f:	44 89 cb             	mov    %r9d,%ebx
    3292:	29 cb                	sub    %ecx,%ebx
    3294:	41 0f 94 c2          	sete   %r10b
    3298:	41 0f 93 c3          	setae  %r11b
    329c:	4c 0f 47 c1          	cmova  %rcx,%r8
    32a0:	c4 c2 60 f2 d1       	andn   %r9d,%ebx,%edx
    32a5:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    32ab:	41 c1 e2 1e          	shl    $0x1e,%r10d
    32af:	41 c1 e3 1d          	shl    $0x1d,%r11d
    32b3:	45 09 d3             	or     %r10d,%r11d
    32b6:	41 09 db             	or     %ebx,%r11d
    32b9:	c1 ea 03             	shr    $0x3,%edx
    32bc:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    32c2:	44 09 da             	or     %r11d,%edx
    32c5:	48 c7 47 48 f0 2d 00 	movq   $0x2df0,0x48(%rdi)
    32cc:	00 
    32cd:	4c 89 47 40          	mov    %r8,0x40(%rdi)
    32d1:	49 69 c8 e0 3c 00 00 	imul   $0x3ce0,%r8,%rcx
    32d8:	48 01 f1             	add    %rsi,%rcx
    32db:	48 81 c1 f0 2d 00 00 	add    $0x2df0,%rcx
    32e2:	48 89 97 10 01 00 00 	mov    %rdx,0x110(%rdi)
    32e9:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    32ed:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    32f1:	48 85 d2             	test   %rdx,%rdx
    32f4:	74 0d                	je     3303 <f_8001161d0+0x3303>
    32f6:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    32fd:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    3301:	eb 02                	jmp    3305 <f_8001161d0+0x3305>
    3303:	31 d2                	xor    %edx,%edx
    3305:	88 90 b0 00 00 00    	mov    %dl,0xb0(%rax)
    330b:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    330f:	48 85 d2             	test   %rdx,%rdx
    3312:	74 09                	je     331d <f_8001161d0+0x331d>
    3314:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    331b:	eb 02                	jmp    331f <f_8001161d0+0x331f>
    331d:	31 d2                	xor    %edx,%edx
    331f:	88 90 b1 00 00 00    	mov    %dl,0xb1(%rax)
    3325:	48 8b 51 30          	mov    0x30(%rcx),%rdx
    3329:	48 85 d2             	test   %rdx,%rdx
    332c:	74 0d                	je     333b <f_8001161d0+0x333b>
    332e:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3335:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    3339:	eb 02                	jmp    333d <f_8001161d0+0x333d>
    333b:	31 d2                	xor    %edx,%edx
    333d:	88 90 b2 00 00 00    	mov    %dl,0xb2(%rax)
    3343:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    3347:	48 85 d2             	test   %rdx,%rdx
    334a:	74 09                	je     3355 <f_8001161d0+0x3355>
    334c:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3353:	eb 02                	jmp    3357 <f_8001161d0+0x3357>
    3355:	31 d2                	xor    %edx,%edx
    3357:	88 90 b3 00 00 00    	mov    %dl,0xb3(%rax)
    335d:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    3361:	48 85 d2             	test   %rdx,%rdx
    3364:	74 0d                	je     3373 <f_8001161d0+0x3373>
    3366:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    336d:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    3371:	eb 02                	jmp    3375 <f_8001161d0+0x3375>
    3373:	31 d2                	xor    %edx,%edx
    3375:	88 90 b4 00 00 00    	mov    %dl,0xb4(%rax)
    337b:	48 8b 51 48          	mov    0x48(%rcx),%rdx
    337f:	48 85 d2             	test   %rdx,%rdx
    3382:	74 09                	je     338d <f_8001161d0+0x338d>
    3384:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    338b:	eb 02                	jmp    338f <f_8001161d0+0x338f>
    338d:	31 d2                	xor    %edx,%edx
    338f:	88 90 b5 00 00 00    	mov    %dl,0xb5(%rax)
    3395:	48 8b 51 50          	mov    0x50(%rcx),%rdx
    3399:	48 85 d2             	test   %rdx,%rdx
    339c:	74 09                	je     33a7 <f_8001161d0+0x33a7>
    339e:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    33a5:	eb 02                	jmp    33a9 <f_8001161d0+0x33a9>
    33a7:	31 d2                	xor    %edx,%edx
    33a9:	88 90 b6 00 00 00    	mov    %dl,0xb6(%rax)
    33af:	48 8b 51 58          	mov    0x58(%rcx),%rdx
    33b3:	48 85 d2             	test   %rdx,%rdx
    33b6:	74 0d                	je     33c5 <f_8001161d0+0x33c5>
    33b8:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    33bf:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    33c3:	eb 02                	jmp    33c7 <f_8001161d0+0x33c7>
    33c5:	31 d2                	xor    %edx,%edx
    33c7:	88 90 b7 00 00 00    	mov    %dl,0xb7(%rax)
    33cd:	48 8b 49 60          	mov    0x60(%rcx),%rcx
    33d1:	48 85 c9             	test   %rcx,%rcx
    33d4:	74 10                	je     33e6 <f_8001161d0+0x33e6>
    33d6:	0f b6 89 c0 00 00 00 	movzbl 0xc0(%rcx),%ecx
    33dd:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    33e1:	e9 55 f8 ff ff       	jmp    2c3b <f_8001161d0+0x2c3b>
    33e6:	31 c9                	xor    %ecx,%ecx
    33e8:	e9 4e f8 ff ff       	jmp    2c3b <f_8001161d0+0x2c3b>
    33ed:	48 8b 87 b0 00 00 00 	mov    0xb0(%rdi),%rax
    33f4:	8b 08                	mov    (%rax),%ecx
    33f6:	45 8b 90 90 3b 00 00 	mov    0x3b90(%r8),%r10d
    33fd:	45 8b 88 94 3b 00 00 	mov    0x3b94(%r8),%r9d
    3404:	41 83 fa 01          	cmp    $0x1,%r10d
    3408:	44 89 d6             	mov    %r10d,%esi
    340b:	83 d6 00             	adc    $0x0,%esi
    340e:	89 c8                	mov    %ecx,%eax
    3410:	31 d2                	xor    %edx,%edx
    3412:	f7 f6                	div    %esi
    3414:	89 c6                	mov    %eax,%esi
    3416:	45 85 d2             	test   %r10d,%r10d
    3419:	41 0f 44 f2          	cmove  %r10d,%esi
    341d:	4c 89 4f 48          	mov    %r9,0x48(%rdi)
    3421:	31 d2                	xor    %edx,%edx
    3423:	41 89 f2             	mov    %esi,%r10d
    3426:	45 31 ca             	xor    %r9d,%r10d
    3429:	0f 94 c2             	sete   %dl
    342c:	45 31 db             	xor    %r11d,%r11d
    342f:	89 f0                	mov    %esi,%eax
    3431:	44 29 c8             	sub    %r9d,%eax
    3434:	41 0f 93 c3          	setae  %r11b
    3438:	89 f3                	mov    %esi,%ebx
    343a:	31 c3                	xor    %eax,%ebx
    343c:	44 21 d3             	and    %r10d,%ebx
    343f:	41 89 c2             	mov    %eax,%r10d
    3442:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    3449:	c1 e2 1e             	shl    $0x1e,%edx
    344c:	41 c1 e3 1d          	shl    $0x1d,%r11d
    3450:	41 09 d3             	or     %edx,%r11d
    3453:	45 09 d3             	or     %r10d,%r11d
    3456:	31 d8                	xor    %ebx,%eax
    3458:	c1 eb 03             	shr    $0x3,%ebx
    345b:	81 e3 00 00 00 10    	and    $0x10000000,%ebx
    3461:	44 09 db             	or     %r11d,%ebx
    3464:	48 89 9f 10 01 00 00 	mov    %rbx,0x110(%rdi)
    346b:	a9 00 00 00 80       	test   $0x80000000,%eax
    3470:	49 0f 44 f1          	cmove  %r9,%rsi
    3474:	48 89 77 40          	mov    %rsi,0x40(%rdi)
    3478:	48 85 f6             	test   %rsi,%rsi
    347b:	0f 84 c0 f9 ff ff    	je     2e41 <f_8001161d0+0x2e41>
    3481:	48 89 8f 88 00 00 00 	mov    %rcx,0x88(%rdi)
    3488:	31 d2                	xor    %edx,%edx
    348a:	89 f0                	mov    %esi,%eax
    348c:	ff c8                	dec    %eax
    348e:	0f 94 c2             	sete   %dl
    3491:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
    3497:	49 81 c2 01 00 00 80 	add    $0xffffffff80000001,%r10
    349e:	45 31 c9             	xor    %r9d,%r9d
    34a1:	4c 89 d3             	mov    %r10,%rbx
    34a4:	4c 39 d6             	cmp    %r10,%rsi
    34a7:	41 0f 94 c1          	sete   %r9b
    34ab:	41 89 c2             	mov    %eax,%r10d
    34ae:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    34b5:	c1 e2 1e             	shl    $0x1e,%edx
    34b8:	44 09 d2             	or     %r10d,%edx
    34bb:	45 89 ca             	mov    %r9d,%r10d
    34be:	41 c1 e2 1c          	shl    $0x1c,%r10d
    34c2:	41 09 d2             	or     %edx,%r10d
    34c5:	49 81 ca 00 00 00 20 	or     $0x20000000,%r10
    34cc:	4c 89 97 10 01 00 00 	mov    %r10,0x110(%rdi)
    34d3:	48 89 47 48          	mov    %rax,0x48(%rdi)
    34d7:	48 89 4f 60          	mov    %rcx,0x60(%rdi)
    34db:	c1 e8 1f             	shr    $0x1f,%eax
    34de:	41 30 c1             	xor    %al,%r9b
    34e1:	0f 85 5a f9 ff ff    	jne    2e41 <f_8001161d0+0x2e41>
    34e7:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    34ed:	49 31 f1             	xor    %rsi,%r9
    34f0:	41 ba 00 00 00 80    	mov    $0x80000000,%r10d
    34f6:	49 31 ca             	xor    %rcx,%r10
    34f9:	4c 89 d0             	mov    %r10,%rax
    34fc:	4c 09 c8             	or     %r9,%rax
    34ff:	b8 01 00 00 00       	mov    $0x1,%eax
    3504:	41 89 f3             	mov    %esi,%r11d
    3507:	44 0f 44 d8          	cmove  %eax,%r11d
    350b:	89 c8                	mov    %ecx,%eax
    350d:	99                   	cltd
    350e:	41 f7 fb             	idiv   %r11d
    3511:	4d 09 ca             	or     %r9,%r10
    3514:	89 c2                	mov    %eax,%edx
    3516:	0f 44 d1             	cmove  %ecx,%edx
    3519:	48 0f 44 c3          	cmove  %rbx,%rax
    351d:	4c 8d 4f 50          	lea    0x50(%rdi),%r9
    3521:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    3525:	c4 c1 78 29 01       	vmovaps %xmm0,(%r9)
    352a:	4d 8d 88 80 3b 00 00 	lea    0x3b80(%r8),%r9
    3531:	4c 89 4f 70          	mov    %r9,0x70(%rdi)
    3535:	48 c7 47 78 28 00 00 	movq   $0x28,0x78(%rdi)
    353c:	00 
    353d:	48 c7 87 80 00 00 00 	movq   $0x3dcccccd,0x80(%rdi)
    3544:	cd cc cc 3d 
    3548:	0f af f2             	imul   %edx,%esi
    354b:	29 f1                	sub    %esi,%ecx
    354d:	48 89 4f 60          	mov    %rcx,0x60(%rdi)
    3551:	49 81 c0 78 3b 00 00 	add    $0x3b78,%r8
    3558:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    355c:	48 89 87 88 00 00 00 	mov    %rax,0x88(%rdi)
    3563:	31 c9                	xor    %ecx,%ecx
    3565:	c5 f0 57 c9          	vxorps %xmm1,%xmm1,%xmm1
    3569:	c5 fa 10 15 00 00 00 	vmovss 0x0(%rip),%xmm2        # 3571 <f_8001161d0+0x3571>
    3570:	00 
    3571:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    3576:	c4 e2 79 59 1d 00 00 	vpbroadcastq 0x0(%rip),%xmm3        # 357f <f_8001161d0+0x357f>
    357d:	00 00 
    357f:	48 be 00 00 00 00 f8 	movabs $0xfffffff800000000,%rsi
    3586:	ff ff ff 
    3589:	eb 7a                	jmp    3605 <f_8001161d0+0x3605>
    358b:	c4 e3 e1 22 a7 88 00 	vpinsrq $0x1,0x88(%rdi),%xmm3,%xmm4
    3592:	00 00 01 
    3595:	c5 d9 d4 67 50       	vpaddq 0x50(%rdi),%xmm4,%xmm4
    359a:	c5 f9 7e e0          	vmovd  %xmm4,%eax
    359e:	44 8b 47 40          	mov    0x40(%rdi),%r8d
    35a2:	45 31 c9             	xor    %r9d,%r9d
    35a5:	41 89 c2             	mov    %eax,%r10d
    35a8:	45 31 c2             	xor    %r8d,%r10d
    35ab:	41 0f 94 c1          	sete   %r9b
    35af:	45 31 db             	xor    %r11d,%r11d
    35b2:	89 c3                	mov    %eax,%ebx
    35b4:	44 29 c3             	sub    %r8d,%ebx
    35b7:	41 0f 93 c3          	setae  %r11b
    35bb:	41 89 de             	mov    %ebx,%r14d
    35be:	41 31 c6             	xor    %eax,%r14d
    35c1:	45 21 d6             	and    %r10d,%r14d
    35c4:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    35ca:	41 c1 e1 1e          	shl    $0x1e,%r9d
    35ce:	41 c1 e3 1d          	shl    $0x1d,%r11d
    35d2:	45 09 cb             	or     %r9d,%r11d
    35d5:	41 09 db             	or     %ebx,%r11d
    35d8:	41 c1 ee 03          	shr    $0x3,%r14d
    35dc:	41 81 e6 00 00 00 10 	and    $0x10000000,%r14d
    35e3:	45 09 de             	or     %r11d,%r14d
    35e6:	44 31 c0             	xor    %r8d,%eax
    35e9:	c4 e3 59 02 e0 0a    	vpblendd $0xa,%xmm0,%xmm4,%xmm4
    35ef:	c5 f9 7f 67 50       	vmovdqa %xmm4,0x50(%rdi)
    35f4:	4c 89 b7 10 01 00 00 	mov    %r14,0x110(%rdi)
    35fb:	0f 84 40 f8 ff ff    	je     2e41 <f_8001161d0+0x2e41>
    3601:	4c 8b 47 68          	mov    0x68(%rdi),%r8
    3605:	41 8b 00             	mov    (%r8),%eax
    3608:	48 89 87 30 01 00 00 	mov    %rax,0x130(%rdi)
    360f:	48 89 87 90 00 00 00 	mov    %rax,0x90(%rdi)
    3616:	44 8d 48 01          	lea    0x1(%rax),%r9d
    361a:	4c 89 0f             	mov    %r9,(%rdi)
    361d:	4c 8b 57 68          	mov    0x68(%rdi),%r10
    3621:	48 c7 87 28 01 00 00 	movq   $0xffffffffffffffff,0x128(%rdi)
    3628:	ff ff ff ff 
    362c:	4d 39 d0             	cmp    %r10,%r8
    362f:	41 0f 94 c0          	sete   %r8b
    3633:	f0 45 0f b1 0a       	lock cmpxchg %r9d,(%r10)
    3638:	0f 94 c0             	sete   %al
    363b:	44 20 c0             	and    %r8b,%al
    363e:	41 89 c0             	mov    %eax,%r8d
    3641:	41 80 f0 01          	xor    $0x1,%r8b
    3645:	45 0f b6 c0          	movzbl %r8b,%r8d
    3649:	4c 89 47 08          	mov    %r8,0x8(%rdi)
    364d:	84 c0                	test   %al,%al
    364f:	74 b0                	je     3601 <f_8001161d0+0x3601>
    3651:	4c 8b 9f a0 00 00 00 	mov    0xa0(%rdi),%r11
    3658:	8b 47 50             	mov    0x50(%rdi),%eax
    365b:	3b 47 48             	cmp    0x48(%rdi),%eax
    365e:	44 8b 47 60          	mov    0x60(%rdi),%r8d
    3662:	4c 0f 45 c1          	cmovne %rcx,%r8
    3666:	4d 8b 93 70 3b 00 00 	mov    0x3b70(%r11),%r10
    366d:	4c 8b 8f 90 00 00 00 	mov    0x90(%rdi),%r9
    3674:	b8 00 00 00 00       	mov    $0x0,%eax
    3679:	45 39 8b 68 3b 00 00 	cmp    %r9d,0x3b68(%r11)
    3680:	76 1a                	jbe    369c <f_8001161d0+0x369c>
    3682:	45 89 c9             	mov    %r9d,%r9d
    3685:	49 63 c1             	movslq %r9d,%rax
    3688:	48 c1 f8 1f          	sar    $0x1f,%rax
    368c:	49 bb 00 00 00 00 ff 	movabs $0xffffffff00000000,%r11
    3693:	ff ff ff 
    3696:	4c 21 d8             	and    %r11,%rax
    3699:	4c 09 c8             	or     %r9,%rax
    369c:	48 89 47 08          	mov    %rax,0x8(%rdi)
    36a0:	4c 03 87 88 00 00 00 	add    0x88(%rdi),%r8
    36a7:	45 89 c1             	mov    %r8d,%r9d
    36aa:	4c 89 8f 88 00 00 00 	mov    %r9,0x88(%rdi)
    36b1:	48 98                	cltq
    36b3:	4c 63 5f 78          	movslq 0x78(%rdi),%r11
    36b7:	4c 0f af d8          	imul   %rax,%r11
    36bb:	4b 8d 04 13          	lea    (%r11,%r10,1),%rax
    36bf:	48 89 87 90 00 00 00 	mov    %rax,0x90(%rdi)
    36c6:	8b 5f 58             	mov    0x58(%rdi),%ebx
    36c9:	4d 89 c6             	mov    %r8,%r14
    36cc:	49 c1 e6 20          	shl    $0x20,%r14
    36d0:	49 09 de             	or     %rbx,%r14
    36d3:	48 8b 9f 98 00 00 00 	mov    0x98(%rdi),%rbx
    36da:	4b 89 1c 13          	mov    %rbx,(%r11,%r10,1)
    36de:	48 8b 9f b8 00 00 00 	mov    0xb8(%rdi),%rbx
    36e5:	4b 89 5c 13 08       	mov    %rbx,0x8(%r11,%r10,1)
    36ea:	48 8b 9f a8 00 00 00 	mov    0xa8(%rdi),%rbx
    36f1:	4b 89 5c 13 10       	mov    %rbx,0x10(%r11,%r10,1)
    36f6:	4f 89 74 13 18       	mov    %r14,0x18(%r11,%r10,1)
    36fb:	44 8b 93 bc 00 00 00 	mov    0xbc(%rbx),%r10d
    3702:	31 db                	xor    %ebx,%ebx
    3704:	45 89 d3             	mov    %r10d,%r11d
    3707:	41 83 c3 fe          	add    $0xfffffffe,%r11d
    370b:	0f 94 c3             	sete   %bl
    370e:	31 ed                	xor    %ebp,%ebp
    3710:	41 be 01 00 00 00    	mov    $0x1,%r14d
    3716:	45 29 d6             	sub    %r10d,%r14d
    3719:	40 0f 92 c5          	setb   %bpl
    371d:	45 21 d6             	and    %r10d,%r14d
    3720:	45 89 df             	mov    %r11d,%r15d
    3723:	41 81 e7 00 00 00 80 	and    $0x80000000,%r15d
    372a:	c1 e3 1e             	shl    $0x1e,%ebx
    372d:	c1 e5 1d             	shl    $0x1d,%ebp
    3730:	44 09 fd             	or     %r15d,%ebp
    3733:	09 dd                	or     %ebx,%ebp
    3735:	41 c1 ee 03          	shr    $0x3,%r14d
    3739:	41 81 e6 00 00 00 10 	and    $0x10000000,%r14d
    3740:	41 09 ee             	or     %ebp,%r14d
    3743:	4c 89 b7 10 01 00 00 	mov    %r14,0x110(%rdi)
    374a:	45 85 db             	test   %r11d,%r11d
    374d:	0f 84 aa 00 00 00    	je     37fd <f_8001161d0+0x37fd>
    3753:	45 31 db             	xor    %r11d,%r11d
    3756:	44 89 d3             	mov    %r10d,%ebx
    3759:	f7 db                	neg    %ebx
    375b:	41 0f 90 c3          	seto   %r11b
    375f:	31 db                	xor    %ebx,%ebx
    3761:	31 ed                	xor    %ebp,%ebp
    3763:	45 89 d6             	mov    %r10d,%r14d
    3766:	41 83 ee 01          	sub    $0x1,%r14d
    376a:	0f 94 c3             	sete   %bl
    376d:	40 0f 93 c5          	setae  %bpl
    3771:	41 81 e6 00 00 00 80 	and    $0x80000000,%r14d
    3778:	c1 e3 1e             	shl    $0x1e,%ebx
    377b:	c1 e5 1d             	shl    $0x1d,%ebp
    377e:	41 c1 e3 1c          	shl    $0x1c,%r11d
    3782:	41 09 eb             	or     %ebp,%r11d
    3785:	45 09 f3             	or     %r14d,%r11d
    3788:	41 09 db             	or     %ebx,%r11d
    378b:	4c 89 9f 10 01 00 00 	mov    %r11,0x110(%rdi)
    3792:	41 83 fa 01          	cmp    $0x1,%r10d
    3796:	0f 84 b9 00 00 00    	je     3855 <f_8001161d0+0x3855>
    379c:	31 db                	xor    %ebx,%ebx
    379e:	45 89 d3             	mov    %r10d,%r11d
    37a1:	41 83 c3 fd          	add    $0xfffffffd,%r11d
    37a5:	0f 94 c3             	sete   %bl
    37a8:	31 ed                	xor    %ebp,%ebp
    37aa:	41 be 02 00 00 00    	mov    $0x2,%r14d
    37b0:	45 29 d6             	sub    %r10d,%r14d
    37b3:	40 0f 92 c5          	setb   %bpl
    37b7:	45 21 d6             	and    %r10d,%r14d
    37ba:	45 89 da             	mov    %r11d,%r10d
    37bd:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    37c4:	c1 e3 1e             	shl    $0x1e,%ebx
    37c7:	c1 e5 1d             	shl    $0x1d,%ebp
    37ca:	44 09 d5             	or     %r10d,%ebp
    37cd:	09 dd                	or     %ebx,%ebp
    37cf:	41 c1 ee 03          	shr    $0x3,%r14d
    37d3:	41 81 e6 00 00 00 10 	and    $0x10000000,%r14d
    37da:	41 09 ee             	or     %ebp,%r14d
    37dd:	4c 89 b7 10 01 00 00 	mov    %r14,0x110(%rdi)
    37e4:	4c 89 4f 10          	mov    %r9,0x10(%rdi)
    37e8:	45 85 db             	test   %r11d,%r11d
    37eb:	0f 85 ab 00 00 00    	jne    389c <f_8001161d0+0x389c>
    37f1:	45 01 c0             	add    %r8d,%r8d
    37f4:	47 8d 0c 80          	lea    (%r8,%r8,4),%r9d
    37f8:	e9 9b 00 00 00       	jmp    3898 <f_8001161d0+0x3898>
    37fd:	c4 c1 02 2a e0       	vcvtsi2ss %r8d,%xmm15,%xmm4
    3802:	4c 8b 87 80 00 00 00 	mov    0x80(%rdi),%r8
    3809:	45 89 c1             	mov    %r8d,%r9d
    380c:	4c 89 8f 10 02 00 00 	mov    %r9,0x210(%rdi)
    3813:	48 c7 87 18 02 00 00 	movq   $0x0,0x218(%rdi)
    381a:	00 00 00 00 
    381e:	c4 c1 79 6e e8       	vmovd  %r8d,%xmm5
    3823:	c5 da 59 e5          	vmulss %xmm5,%xmm4,%xmm4
    3827:	c4 c1 79 7e e0       	vmovd  %xmm4,%r8d
    382c:	4c 89 87 00 02 00 00 	mov    %r8,0x200(%rdi)
    3833:	c4 61 fa 2c cc       	vcvttss2si %xmm4,%r9
    3838:	48 c7 87 08 02 00 00 	movq   $0x0,0x208(%rdi)
    383f:	00 00 00 00 
    3843:	c5 f8 2e e1          	vucomiss %xmm1,%xmm4
    3847:	44 0f 42 c9          	cmovb  %ecx,%r9d
    384b:	c5 f8 2e e2          	vucomiss %xmm2,%xmm4
    384f:	44 0f 47 ca          	cmova  %edx,%r9d
    3853:	eb 43                	jmp    3898 <f_8001161d0+0x3898>
    3855:	45 31 d2             	xor    %r10d,%r10d
    3858:	4d 85 c9             	test   %r9,%r9
    385b:	41 0f 94 c2          	sete   %r10b
    385f:	45 89 c1             	mov    %r8d,%r9d
    3862:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    3869:	41 c1 e2 1e          	shl    $0x1e,%r10d
    386d:	4d 01 d1             	add    %r10,%r9
    3870:	49 81 c1 00 00 00 20 	add    $0x20000000,%r9
    3877:	4c 89 8f 10 01 00 00 	mov    %r9,0x110(%rdi)
    387e:	45 89 c1             	mov    %r8d,%r9d
    3881:	41 c1 e9 1f          	shr    $0x1f,%r9d
    3885:	45 01 c1             	add    %r8d,%r9d
    3888:	45 89 c8             	mov    %r9d,%r8d
    388b:	41 d1 e8             	shr    $1,%r8d
    388e:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    3895:	45 09 c1             	or     %r8d,%r9d
    3898:	4c 89 4f 10          	mov    %r9,0x10(%rdi)
    389c:	48 89 07             	mov    %rax,(%rdi)
    389f:	44 89 48 20          	mov    %r9d,0x20(%rax)
    38a3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
    38aa:	84 00 00 00 00 00 
    38b0:	4c 8b 47 70          	mov    0x70(%rdi),%r8
    38b4:	41 8b 00             	mov    (%r8),%eax
    38b7:	48 89 87 30 01 00 00 	mov    %rax,0x130(%rdi)
    38be:	48 89 07             	mov    %rax,(%rdi)
    38c1:	44 8d 48 01          	lea    0x1(%rax),%r9d
    38c5:	4c 89 4f 08          	mov    %r9,0x8(%rdi)
    38c9:	4c 8b 57 70          	mov    0x70(%rdi),%r10
    38cd:	48 c7 87 28 01 00 00 	movq   $0xffffffffffffffff,0x128(%rdi)
    38d4:	ff ff ff ff 
    38d8:	4d 39 d0             	cmp    %r10,%r8
    38db:	41 0f 94 c0          	sete   %r8b
    38df:	f0 45 0f b1 0a       	lock cmpxchg %r9d,(%r10)
    38e4:	0f 94 c0             	sete   %al
    38e7:	44 20 c0             	and    %r8b,%al
    38ea:	41 89 c0             	mov    %eax,%r8d
    38ed:	41 80 f0 01          	xor    $0x1,%r8b
    38f1:	45 0f b6 c0          	movzbl %r8b,%r8d
    38f5:	4c 89 47 10          	mov    %r8,0x10(%rdi)
    38f9:	84 c0                	test   %al,%al
    38fb:	74 b3                	je     38b0 <f_8001161d0+0x38b0>
    38fd:	48 8b 07             	mov    (%rdi),%rax
    3900:	4c 8b 87 a0 00 00 00 	mov    0xa0(%rdi),%r8
    3907:	45 8b 88 84 3b 00 00 	mov    0x3b84(%r8),%r9d
    390e:	45 89 ca             	mov    %r9d,%r10d
    3911:	41 31 c2             	xor    %eax,%r10d
    3914:	45 89 cb             	mov    %r9d,%r11d
    3917:	41 31 c3             	xor    %eax,%r11d
    391a:	4c 89 4f 08          	mov    %r9,0x8(%rdi)
    391e:	0f 84 67 fc ff ff    	je     358b <f_8001161d0+0x358b>
    3924:	45 89 cb             	mov    %r9d,%r11d
    3927:	41 29 c3             	sub    %eax,%r11d
    392a:	c4 42 28 f2 db       	andn   %r11d,%r10d,%r11d
    392f:	45 21 ca             	and    %r9d,%r10d
    3932:	45 09 da             	or     %r11d,%r10d
    3935:	0f 88 50 fc ff ff    	js     358b <f_8001161d0+0x358b>
    393b:	4d 8b 80 88 3b 00 00 	mov    0x3b88(%r8),%r8
    3942:	4c 89 47 08          	mov    %r8,0x8(%rdi)
    3946:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    394d:	00 
    394e:	48 98                	cltq
    3950:	48 21 f0             	and    %rsi,%rax
    3953:	4d 8d 95 2e a2 3f fd 	lea    -0x2c05dd2(%r13),%r10
    395a:	4d 21 ca             	and    %r9,%r10
    395d:	49 09 c2             	or     %rax,%r10
    3960:	4c 89 17             	mov    %r10,(%rdi)
    3963:	48 8b 87 90 00 00 00 	mov    0x90(%rdi),%rax
    396a:	4b 89 04 10          	mov    %rax,(%r8,%r10,1)
    396e:	e9 18 fc ff ff       	jmp    358b <f_8001161d0+0x358b>
