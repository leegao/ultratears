
/home/leegao/meh/ultratears-main/src/horizon2llvm/benchmark/samples/main_067_statickernel/results/main_067_statickernel_layer_04_pass04_fastfp.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <f_8001161d0>:
       0:	55                   	push   %rbp
       1:	41 57                	push   %r15
       3:	41 56                	push   %r14
       5:	41 55                	push   %r13
       7:	41 54                	push   %r12
       9:	53                   	push   %rbx
       a:	48 83 ec 18          	sub    $0x18,%rsp
       e:	48 89 fb             	mov    %rdi,%rbx
      11:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
      18:	00 00 00 
      1b:	48 8b 8f e8 00 00 00 	mov    0xe8(%rdi),%rcx
      22:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
      29:	4c 8d a8 d0 fe ff ff 	lea    -0x130(%rax),%r13
      30:	4c 89 af 00 01 00 00 	mov    %r13,0x100(%rdi)
      37:	48 8d 50 a0          	lea    -0x60(%rax),%rdx
      3b:	48 89 48 a0          	mov    %rcx,-0x60(%rax)
      3f:	48 8b 8f f0 00 00 00 	mov    0xf0(%rdi),%rcx
      46:	48 89 48 a8          	mov    %rcx,-0x58(%rax)
      4a:	48 8b 8f e0 00 00 00 	mov    0xe0(%rdi),%rcx
      51:	48 89 48 b0          	mov    %rcx,-0x50(%rax)
      55:	48 8b 8f d8 00 00 00 	mov    0xd8(%rdi),%rcx
      5c:	48 89 48 b8          	mov    %rcx,-0x48(%rax)
      60:	48 8b 8f d0 00 00 00 	mov    0xd0(%rdi),%rcx
      67:	48 89 48 c0          	mov    %rcx,-0x40(%rax)
      6b:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
      72:	48 89 48 c8          	mov    %rcx,-0x38(%rax)
      76:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
      7d:	48 89 48 d0          	mov    %rcx,-0x30(%rax)
      81:	48 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%rcx
      88:	48 89 48 d8          	mov    %rcx,-0x28(%rax)
      8c:	48 8b 8f b0 00 00 00 	mov    0xb0(%rdi),%rcx
      93:	48 89 48 e0          	mov    %rcx,-0x20(%rax)
      97:	48 8b 8f a8 00 00 00 	mov    0xa8(%rdi),%rcx
      9e:	48 89 48 e8          	mov    %rcx,-0x18(%rax)
      a2:	48 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%rcx
      a9:	48 89 48 f0          	mov    %rcx,-0x10(%rax)
      ad:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
      b4:	48 89 48 f8          	mov    %rcx,-0x8(%rax)
      b8:	48 89 97 e8 00 00 00 	mov    %rdx,0xe8(%rdi)
      bf:	4c 8b 5f 10          	mov    0x10(%rdi),%r11
      c3:	4c 89 9f a8 00 00 00 	mov    %r11,0xa8(%rdi)
      ca:	4c 8b 27             	mov    (%rdi),%r12
      cd:	4c 8b 7f 08          	mov    0x8(%rdi),%r15
      d1:	4c 89 bf 98 00 00 00 	mov    %r15,0x98(%rdi)
      d8:	4c 89 a7 a0 00 00 00 	mov    %r12,0xa0(%rdi)
      df:	49 8d 8f 14 29 00 00 	lea    0x2914(%r15),%rcx
      e6:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
      ea:	41 83 fb 20          	cmp    $0x20,%r11d
      ee:	73 1f                	jae    10f <f_8001161d0+0x10f>
      f0:	b9 1f 7d c3 f6       	mov    $0xf6c37d1f,%ecx
      f5:	44 0f a3 d9          	bt     %r11d,%ecx
      f9:	73 14                	jae    10f <f_8001161d0+0x10f>
      fb:	44 89 d9             	mov    %r11d,%ecx
      fe:	83 e1 1f             	and    $0x1f,%ecx
     101:	48 8b 8c cd be 6b 16 	mov    0x166bbe(%rbp,%rcx,8),%rcx
     108:	00 
     109:	48 c1 e1 08          	shl    $0x8,%rcx
     10d:	eb 0f                	jmp    11e <f_8001161d0+0x11e>
     10f:	31 d2                	xor    %edx,%edx
     111:	41 83 fb 12          	cmp    $0x12,%r11d
     115:	b9 00 03 00 00       	mov    $0x300,%ecx
     11a:	48 0f 45 ca          	cmovne %rdx,%rcx
     11e:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     125:	ff ff ff 
     128:	49 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r14
     12f:	ff 7f ff 
     132:	41 0f be 97 17 29 00 	movsbl 0x2917(%r15),%edx
     139:	00 
     13a:	48 63 d2             	movslq %edx,%rdx
     13d:	4c 89 ab c0 00 00 00 	mov    %r13,0xc0(%rbx)
     144:	48 69 f2 48 07 00 00 	imul   $0x748,%rdx,%rsi
     14b:	45 31 c0             	xor    %r8d,%r8d
     14e:	41 39 94 24 90 33 00 	cmp    %edx,0x3390(%r12)
     155:	00 
     156:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     15d:	ff 7f 7f 
     160:	4c 0f 47 c6          	cmova  %rsi,%r8
     164:	49 b9 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r9
     16b:	00 80 3f 
     16e:	48 be 00 00 00 00 01 	movabs $0x100000000,%rsi
     175:	00 00 00 
     178:	4d 03 84 24 98 33 00 	add    0x3398(%r12),%r8
     17f:	00 
     180:	48 c7 43 70 ff ff ff 	movq   $0xffffffffffffffff,0x70(%rbx)
     187:	ff 
     188:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 190 <f_8001161d0+0x190>
     18f:	00 
     190:	c5 fc 11 80 d0 fe ff 	vmovups %ymm0,-0x130(%rax)
     197:	ff 
     198:	ba ff ff ff ff       	mov    $0xffffffff,%edx
     19d:	48 89 53 78          	mov    %rdx,0x78(%rbx)
     1a1:	48 89 b0 f0 fe ff ff 	mov    %rsi,-0x110(%rax)
     1a8:	48 89 b8 f8 fe ff ff 	mov    %rdi,-0x108(%rax)
     1af:	4a 8d 8c 01 e8 01 00 	lea    0x1e8(%rcx,%r8,1),%rcx
     1b6:	00 
     1b7:	48 89 8b b8 00 00 00 	mov    %rcx,0xb8(%rbx)
     1be:	48 89 90 00 ff ff ff 	mov    %rdx,-0x100(%rax)
     1c5:	4c 89 88 08 ff ff ff 	mov    %r9,-0xf8(%rax)
     1cc:	4c 89 53 58          	mov    %r10,0x58(%rbx)
     1d0:	31 d2                	xor    %edx,%edx
     1d2:	44 89 de             	mov    %r11d,%esi
     1d5:	83 c6 df             	add    $0xffffffdf,%esi
     1d8:	0f 94 c2             	sete   %dl
     1db:	31 c9                	xor    %ecx,%ecx
     1dd:	41 83 fb 21          	cmp    $0x21,%r11d
     1e1:	0f 93 c1             	setae  %cl
     1e4:	41 b8 20 00 00 00    	mov    $0x20,%r8d
     1ea:	45 29 d8             	sub    %r11d,%r8d
     1ed:	45 21 d8             	and    %r11d,%r8d
     1f0:	81 e6 00 00 00 80    	and    $0x80000000,%esi
     1f6:	c1 e2 1e             	shl    $0x1e,%edx
     1f9:	c1 e1 1d             	shl    $0x1d,%ecx
     1fc:	09 f1                	or     %esi,%ecx
     1fe:	09 d1                	or     %edx,%ecx
     200:	41 c1 e8 03          	shr    $0x3,%r8d
     204:	41 81 e0 00 00 00 10 	and    $0x10000000,%r8d
     20b:	41 09 c8             	or     %ecx,%r8d
     20e:	4c 89 83 10 01 00 00 	mov    %r8,0x110(%rbx)
     215:	4c 89 88 10 ff ff ff 	mov    %r9,-0xf0(%rax)
     21c:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     223:	00 00 00 00 
     227:	4c 8b 85 7e 86 d5 00 	mov    0xd5867e(%rbp),%r8
     22e:	4c 89 43 50          	mov    %r8,0x50(%rbx)
     232:	48 8b b5 ae 5d d4 00 	mov    0xd45dae(%rbp),%rsi
     239:	48 89 73 48          	mov    %rsi,0x48(%rbx)
     23d:	49 8d 50 10          	lea    0x10(%r8),%rdx
     241:	48 89 90 20 ff ff ff 	mov    %rdx,-0xe0(%rax)
     248:	48 89 b0 40 ff ff ff 	mov    %rsi,-0xc0(%rax)
     24f:	48 8b bd b6 7e d5 00 	mov    0xd57eb6(%rbp),%rdi
     256:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
     25a:	48 83 c7 10          	add    $0x10,%rdi
     25e:	48 89 bb 80 00 00 00 	mov    %rdi,0x80(%rbx)
     265:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
     26c:	4c 89 b0 50 ff ff ff 	mov    %r14,-0xb0(%rax)
     273:	49 8d b1 00 00 80 c0 	lea    -0x3f800000(%r9),%rsi
     27a:	48 89 b0 74 ff ff ff 	mov    %rsi,-0x8c(%rax)
     281:	4c 8b 8d c6 7d d5 00 	mov    0xd57dc6(%rbp),%r9
     288:	4c 89 b0 68 ff ff ff 	mov    %r14,-0x98(%rax)
     28f:	45 8b 31             	mov    (%r9),%r14d
     292:	4c 89 73 40          	mov    %r14,0x40(%rbx)
     296:	48 89 7c 24 08       	mov    %rdi,0x8(%rsp)
     29b:	48 89 b8 58 ff ff ff 	mov    %rdi,-0xa8(%rax)
     2a2:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
     2a9:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     2b0:	00 
     2b1:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     2b5:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     2bc:	44 89 b0 70 ff ff ff 	mov    %r14d,-0x90(%rax)
     2c3:	81 e1 00 00 00 60    	and    $0x60000000,%ecx
     2c9:	81 f9 00 00 00 20    	cmp    $0x20000000,%ecx
     2cf:	0f 84 dc 2a 00 00    	je     2db1 <f_8001161d0+0x2db1>
     2d5:	48 89 34 24          	mov    %rsi,(%rsp)
     2d9:	48 8d b0 48 ff ff ff 	lea    -0xb8(%rax),%rsi
     2e0:	4c 8d 90 60 ff ff ff 	lea    -0xa0(%rax),%r10
     2e7:	4c 8d 48 80          	lea    -0x80(%rax),%r9
     2eb:	48 8d b8 70 ff ff ff 	lea    -0x90(%rax),%rdi
     2f2:	48 8d 8d 76 6b 16 00 	lea    0x166b76(%rbp),%rcx
     2f9:	48 89 8b 88 00 00 00 	mov    %rcx,0x88(%rbx)
     300:	45 89 db             	mov    %r11d,%r11d
     303:	4c 89 9b 90 00 00 00 	mov    %r11,0x90(%rbx)
     30a:	4c 89 ab 80 00 00 00 	mov    %r13,0x80(%rbx)
     311:	42 0f b7 8c 5d 76 6b 	movzwl 0x166b76(%rbp,%r11,2),%ecx
     318:	16 00 
     31a:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     31e:	4c 8d ac 8d 52 05 51 	lea    -0x2aefaae(%rbp,%rcx,4),%r13
     325:	fd 
     326:	4c 89 2b             	mov    %r13,(%rbx)
     329:	48 89 73 48          	mov    %rsi,0x48(%rbx)
     32d:	4c 89 93 d0 00 00 00 	mov    %r10,0xd0(%rbx)
     334:	48 89 bb c8 00 00 00 	mov    %rdi,0xc8(%rbx)
     33b:	4c 89 8b d8 00 00 00 	mov    %r9,0xd8(%rbx)
     342:	81 f9 86 02 00 00    	cmp    $0x286,%ecx
     348:	7f 5a                	jg     3a4 <f_8001161d0+0x3a4>
     34a:	81 f9 2d 01 00 00    	cmp    $0x12d,%ecx
     350:	0f 8f cd 00 00 00    	jg     423 <f_8001161d0+0x423>
     356:	83 f9 6f             	cmp    $0x6f,%ecx
     359:	0f 8f ad 03 00 00    	jg     70c <f_8001161d0+0x70c>
     35f:	83 f9 04             	cmp    $0x4,%ecx
     362:	0f 87 22 10 00 00    	ja     138a <f_8001161d0+0x138a>
     368:	89 c9                	mov    %ecx,%ecx
     36a:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 371 <f_8001161d0+0x371>
     371:	48 63 0c 8e          	movslq (%rsi,%rcx,4),%rcx
     375:	48 01 f1             	add    %rsi,%rcx
     378:	ff e1                	jmp    *%rcx
     37a:	45 0f b7 9c 24 e4 0c 	movzwl 0xce4(%r12),%r11d
     381:	00 00 
     383:	8b 8b a8 00 00 00    	mov    0xa8(%rbx),%ecx
     389:	be ff ff ff ff       	mov    $0xffffffff,%esi
     38e:	01 f1                	add    %esi,%ecx
     390:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
     394:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
     39b:	0f b6 79 08          	movzbl 0x8(%rcx),%edi
     39f:	e9 81 15 00 00       	jmp    1925 <f_8001161d0+0x1925>
     3a4:	81 f9 6d 04 00 00    	cmp    $0x46d,%ecx
     3aa:	0f 8e 16 02 00 00    	jle    5c6 <f_8001161d0+0x5c6>
     3b0:	44 8d 81 92 fb ff ff 	lea    -0x46e(%rcx),%r8d
     3b7:	41 83 f8 0c          	cmp    $0xc,%r8d
     3bb:	0f 86 60 07 00 00    	jbe    b21 <f_8001161d0+0xb21>
     3c1:	44 8d 81 36 fb ff ff 	lea    -0x4ca(%rcx),%r8d
     3c8:	41 83 f8 16          	cmp    $0x16,%r8d
     3cc:	0f 87 69 0f 00 00    	ja     133b <f_8001161d0+0x133b>
     3d2:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 3d9 <f_8001161d0+0x3d9>
     3d9:	4a 63 34 81          	movslq (%rcx,%r8,4),%rsi
     3dd:	48 01 ce             	add    %rcx,%rsi
     3e0:	ff e6                	jmp    *%rsi
     3e2:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
     3e9:	00 
     3ea:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
     3f1:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     3f8:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     3fc:	48 89 43 10          	mov    %rax,0x10(%rbx)
     400:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
     405:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
     40c:	48 89 03             	mov    %rax,(%rbx)
     40f:	48 c7 43 18 01 00 00 	movq   $0x1,0x18(%rbx)
     416:	00 
     417:	48 8d 85 92 18 51 fd 	lea    -0x2aee76e(%rbp),%rax
     41e:	e9 c6 19 00 00       	jmp    1de9 <f_8001161d0+0x1de9>
     423:	81 f9 c7 01 00 00    	cmp    $0x1c7,%ecx
     429:	0f 8f ac 05 00 00    	jg     9db <f_8001161d0+0x9db>
     42f:	81 f9 b1 01 00 00    	cmp    $0x1b1,%ecx
     435:	0f 8f 13 0a 00 00    	jg     e4e <f_8001161d0+0xe4e>
     43b:	81 f9 2e 01 00 00    	cmp    $0x12e,%ecx
     441:	0f 84 41 1f 00 00    	je     2388 <f_8001161d0+0x2388>
     447:	81 f9 66 01 00 00    	cmp    $0x166,%ecx
     44d:	0f 85 3a 19 00 00    	jne    1d8d <f_8001161d0+0x1d8d>
     453:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
     45a:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
     461:	48 8b b6 c8 1e 00 00 	mov    0x1ec8(%rsi),%rsi
     468:	48 89 73 08          	mov    %rsi,0x8(%rbx)
     46c:	48 c7 83 80 00 00 00 	movq   $0x3ce0,0x80(%rbx)
     473:	e0 3c 00 00 
     477:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
     47c:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
     480:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
     484:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
     488:	4c 69 c1 e0 3c 00 00 	imul   $0x3ce0,%rcx,%r8
     48f:	45 31 c9             	xor    %r9d,%r9d
     492:	39 4e 08             	cmp    %ecx,0x8(%rsi)
     495:	4d 0f 47 c8          	cmova  %r8,%r9
     499:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
     49d:	49 8b 8c 09 40 3c 00 	mov    0x3c40(%r9,%rcx,1),%rcx
     4a4:	00 
     4a5:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
     4ac:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     4b3:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
     4ba:	48 89 b9 88 00 00 00 	mov    %rdi,0x88(%rcx)
     4c1:	48 be ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rsi
     4c8:	ff 7f 7f 
     4cb:	48 89 b1 90 00 00 00 	mov    %rsi,0x90(%rcx)
     4d2:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     4d9:	00 
     4da:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     4de:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
     4e5:	00 00 00 
     4e8:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
     4ef:	00 
     4f0:	48 89 51 50          	mov    %rdx,0x50(%rcx)
     4f4:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     4f8:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
     4fd:	48 c7 41 30 08 00 00 	movq   $0x8,0x30(%rcx)
     504:	00 
     505:	48 b8 10 00 00 00 03 	movabs $0x300000010,%rax
     50c:	00 00 00 
     50f:	48 89 01             	mov    %rax,(%rcx)
     512:	48 c7 41 08 00 00 00 	movq   $0x0,0x8(%rcx)
     519:	00 
     51a:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     521:	00 
     522:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     529:	ff ff ff 
     52c:	48 8d 42 0d          	lea    0xd(%rdx),%rax
     530:	48 89 41 18          	mov    %rax,0x18(%rcx)
     534:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     53b:	00 00 00 
     53e:	48 89 41 20          	mov    %rax,0x20(%rcx)
     542:	48 89 51 28          	mov    %rdx,0x28(%rcx)
     546:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     54d:	48 8b 14 24          	mov    (%rsp),%rdx
     551:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
     558:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
     55f:	00 80 3f 
     562:	48 89 41 38          	mov    %rax,0x38(%rcx)
     566:	48 89 41 40          	mov    %rax,0x40(%rcx)
     56a:	49 be ca 5d c0 02 08 	movabs $0x802c05dca,%r14
     571:	00 00 00 
     574:	49 8d 86 8b 0d 02 00 	lea    0x20d8b(%r14),%rax
     57b:	48 89 43 70          	mov    %rax,0x70(%rbx)
     57f:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
     586:	ff 7f ff 
     589:	48 89 73 78          	mov    %rsi,0x78(%rbx)
     58d:	48 89 b1 98 00 00 00 	mov    %rsi,0x98(%rcx)
     594:	48 8b 53 58          	mov    0x58(%rbx),%rdx
     598:	48 89 51 78          	mov    %rdx,0x78(%rcx)
     59c:	48 89 b1 80 00 00 00 	mov    %rsi,0x80(%rcx)
     5a3:	48 8d 93 80 00 00 00 	lea    0x80(%rbx),%rdx
     5aa:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
     5b1:	00 
     5b2:	48 89 41 70          	mov    %rax,0x70(%rcx)
     5b6:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
     5ba:	8b 71 08             	mov    0x8(%rcx),%esi
     5bd:	48 89 73 40          	mov    %rsi,0x40(%rbx)
     5c1:	e9 3f 1f 00 00       	jmp    2505 <f_8001161d0+0x2505>
     5c6:	81 f9 d4 02 00 00    	cmp    $0x2d4,%ecx
     5cc:	0f 8f a2 04 00 00    	jg     a74 <f_8001161d0+0xa74>
     5d2:	81 f9 b5 02 00 00    	cmp    $0x2b5,%ecx
     5d8:	0f 8f 11 09 00 00    	jg     eef <f_8001161d0+0xeef>
     5de:	81 f9 87 02 00 00    	cmp    $0x287,%ecx
     5e4:	0f 84 85 20 00 00    	je     266f <f_8001161d0+0x266f>
     5ea:	81 f9 97 02 00 00    	cmp    $0x297,%ecx
     5f0:	0f 85 97 17 00 00    	jne    1d8d <f_8001161d0+0x1d8d>
     5f6:	4d 89 d4             	mov    %r10,%r12
     5f9:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     600:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
     607:	48 c7 01 00 00 00 40 	movq   $0x40000000,(%rcx)
     60e:	49 b8 00 00 00 00 00 	movabs $0x40000000000000,%r8
     615:	00 40 00 
     618:	4c 89 41 08          	mov    %r8,0x8(%rcx)
     61c:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     623:	00 
     624:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     62b:	ff ff ff 
     62e:	4c 8d 47 14          	lea    0x14(%rdi),%r8
     632:	4c 89 41 18          	mov    %r8,0x18(%rcx)
     636:	48 89 53 40          	mov    %rdx,0x40(%rbx)
     63a:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     63e:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     645:	00 
     646:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
     64d:	00 00 00 
     650:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     657:	00 00 00 
     65a:	48 89 41 20          	mov    %rax,0x20(%rcx)
     65e:	48 89 79 28          	mov    %rdi,0x28(%rcx)
     662:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
     667:	48 89 41 30          	mov    %rax,0x30(%rcx)
     66b:	49 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r8
     672:	00 80 3f 
     675:	4c 89 41 38          	mov    %r8,0x38(%rcx)
     679:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
     680:	00 00 00 
     683:	48 8d 80 80 0d 02 00 	lea    0x20d80(%rax),%rax
     68a:	48 89 41 70          	mov    %rax,0x70(%rcx)
     68e:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     695:	ff 7f 7f 
     698:	4c 89 51 78          	mov    %r10,0x78(%rcx)
     69c:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
     6a3:	ff 7f ff 
     6a6:	48 89 b9 80 00 00 00 	mov    %rdi,0x80(%rcx)
     6ad:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
     6b2:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
     6b9:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 6c1 <f_8001161d0+0x6c1>
     6c0:	00 
     6c1:	c5 fc 11 43 60       	vmovups %ymm0,0x60(%rbx)
     6c6:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     6cd:	4c 8b 0c 24          	mov    (%rsp),%r9
     6d1:	4c 89 88 a4 00 00 00 	mov    %r9,0xa4(%rax)
     6d8:	4c 89 41 40          	mov    %r8,0x40(%rcx)
     6dc:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
     6e3:	00 
     6e4:	4c 89 91 90 00 00 00 	mov    %r10,0x90(%rcx)
     6eb:	48 89 b9 98 00 00 00 	mov    %rdi,0x98(%rcx)
     6f2:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
     6f9:	00 
     6fa:	48 89 51 50          	mov    %rdx,0x50(%rcx)
     6fe:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     702:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
     707:	e9 86 25 00 00       	jmp    2c92 <f_8001161d0+0x2c92>
     70c:	81 f9 c8 00 00 00    	cmp    $0xc8,%ecx
     712:	0f 8f 22 04 00 00    	jg     b3a <f_8001161d0+0xb3a>
     718:	83 f9 70             	cmp    $0x70,%ecx
     71b:	0f 84 6d 19 00 00    	je     208e <f_8001161d0+0x208e>
     721:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
     727:	0f 85 60 16 00 00    	jne    1d8d <f_8001161d0+0x1d8d>
     72d:	4d 8b 9c 24 c8 1e 00 	mov    0x1ec8(%r12),%r11
     734:	00 
     735:	4c 89 5b 08          	mov    %r11,0x8(%rbx)
     739:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
     73e:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
     742:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
     749:	00 
     74a:	41 0f b6 77 08       	movzbl 0x8(%r15),%esi
     74f:	48 89 73 68          	mov    %rsi,0x68(%rbx)
     753:	45 8b 4b 08          	mov    0x8(%r11),%r9d
     757:	4d 8b 7b 10          	mov    0x10(%r11),%r15
     75b:	4c 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%r8
     762:	31 c9                	xor    %ecx,%ecx
     764:	41 39 f1             	cmp    %esi,%r9d
     767:	41 b9 00 00 00 00    	mov    $0x0,%r9d
     76d:	4d 0f 47 c8          	cmova  %r8,%r9
     771:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
     778:	00 
     779:	4f 8b 8c 39 40 3c 00 	mov    0x3c40(%r9,%r15,1),%r9
     780:	00 
     781:	4c 89 8b b0 00 00 00 	mov    %r9,0xb0(%rbx)
     788:	44 89 b0 70 ff ff ff 	mov    %r14d,-0x90(%rax)
     78f:	48 89 b8 58 ff ff ff 	mov    %rdi,-0xa8(%rax)
     796:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     79d:	ff 7f 7f 
     7a0:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
     7a7:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     7ae:	00 
     7af:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     7b3:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     7ba:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     7c1:	00 00 00 00 
     7c5:	48 89 90 20 ff ff ff 	mov    %rdx,-0xe0(%rax)
     7cc:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     7d0:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
     7d7:	ff 
     7d8:	48 c7 80 00 ff ff ff 	movq   $0x5,-0x100(%rax)
     7df:	05 00 00 00 
     7e3:	48 ba 10 00 00 00 03 	movabs $0x300000010,%rdx
     7ea:	00 00 00 
     7ed:	48 81 c2 f0 00 00 00 	add    $0xf0,%rdx
     7f4:	48 89 90 d0 fe ff ff 	mov    %rdx,-0x130(%rax)
     7fb:	48 ba 00 00 00 00 00 	movabs $0x60000000000000,%rdx
     802:	00 60 00 
     805:	48 89 90 d8 fe ff ff 	mov    %rdx,-0x128(%rax)
     80c:	4c 89 0b             	mov    %r9,(%rbx)
     80f:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     816:	ff ff 00 00 
     81a:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     821:	ff ff ff 
     824:	48 8d 57 08          	lea    0x8(%rdi),%rdx
     828:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
     82f:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
     836:	00 00 00 
     839:	48 89 90 f0 fe ff ff 	mov    %rdx,-0x110(%rax)
     840:	48 89 b8 f8 fe ff ff 	mov    %rdi,-0x108(%rax)
     847:	48 8b 93 c0 00 00 00 	mov    0xc0(%rbx),%rdx
     84e:	48 8b 3c 24          	mov    (%rsp),%rdi
     852:	48 89 ba a4 00 00 00 	mov    %rdi,0xa4(%rdx)
     859:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
     860:	00 80 3f 
     863:	48 89 90 08 ff ff ff 	mov    %rdx,-0xf8(%rax)
     86a:	48 89 90 10 ff ff ff 	mov    %rdx,-0xf0(%rax)
     871:	48 8d 95 1d 54 09 00 	lea    0x9541d(%rbp),%rdx
     878:	48 89 53 78          	mov    %rdx,0x78(%rbx)
     87c:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
     883:	ff 7f ff 
     886:	48 89 bb 80 00 00 00 	mov    %rdi,0x80(%rbx)
     88d:	48 89 b8 68 ff ff ff 	mov    %rdi,-0x98(%rax)
     894:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
     89b:	48 89 b8 50 ff ff ff 	mov    %rdi,-0xb0(%rax)
     8a2:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
     8a9:	00 00 00 00 
     8ad:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
     8b4:	41 39 73 08          	cmp    %esi,0x8(%r11)
     8b8:	ba 00 00 00 00       	mov    $0x0,%edx
     8bd:	49 0f 47 d0          	cmova  %r8,%rdx
     8c1:	49 8b 7b 10          	mov    0x10(%r11),%rdi
     8c5:	c5 f8 10 84 17 00 2e 	vmovups 0x2e00(%rdi,%rdx,1),%xmm0
     8cc:	00 00 
     8ce:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
     8d5:	ff 
     8d6:	41 8b 7b 08          	mov    0x8(%r11),%edi
     8da:	45 31 c9             	xor    %r9d,%r9d
     8dd:	31 d2                	xor    %edx,%edx
     8df:	41 89 fa             	mov    %edi,%r10d
     8e2:	41 29 f2             	sub    %esi,%r10d
     8e5:	49 0f 47 c8          	cmova  %r8,%rcx
     8e9:	41 0f 94 c1          	sete   %r9b
     8ed:	0f 93 c2             	setae  %dl
     8f0:	41 c1 e1 1e          	shl    $0x1e,%r9d
     8f4:	c1 e2 1d             	shl    $0x1d,%edx
     8f7:	44 09 ca             	or     %r9d,%edx
     8fa:	c4 e2 28 f2 f7       	andn   %edi,%r10d,%esi
     8ff:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
     906:	44 09 d2             	or     %r10d,%edx
     909:	49 8b 7b 10          	mov    0x10(%r11),%rdi
     90d:	c1 ee 03             	shr    $0x3,%esi
     910:	81 e6 00 00 00 10    	and    $0x10000000,%esi
     916:	09 d6                	or     %edx,%esi
     918:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
     91f:	48 8b 94 0f 80 30 00 	mov    0x3080(%rdi,%rcx,1),%rdx
     926:	00 
     927:	48 8b b4 0f 88 30 00 	mov    0x3088(%rdi,%rcx,1),%rsi
     92e:	00 
     92f:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     933:	48 89 90 60 ff ff ff 	mov    %rdx,-0xa0(%rax)
     93a:	48 89 b0 68 ff ff ff 	mov    %rsi,-0x98(%rax)
     941:	48 8b 94 0f 90 30 00 	mov    0x3090(%rdi,%rcx,1),%rdx
     948:	00 
     949:	48 89 53 48          	mov    %rdx,0x48(%rbx)
     94d:	8b 8c 0f 98 30 00 00 	mov    0x3098(%rdi,%rcx,1),%ecx
     954:	89 88 78 ff ff ff    	mov    %ecx,-0x88(%rax)
     95a:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
     961:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
     965:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
     969:	48 89 90 70 ff ff ff 	mov    %rdx,-0x90(%rax)
     970:	48 8d 85 56 08 51 fd 	lea    -0x2aef7aa(%rbp),%rax
     977:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
     97e:	48 89 df             	mov    %rbx,%rdi
     981:	c5 f8 77             	vzeroupper
     984:	e8 00 00 00 00       	call   989 <f_8001161d0+0x989>
     989:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     990:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
     997:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     99e:	48 89 01             	mov    %rax,(%rcx)
     9a1:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     9a8:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     9af:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
     9b3:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
     9ba:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     9be:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     9c4:	48 89 43 40          	mov    %rax,0x40(%rbx)
     9c8:	88 51 08             	mov    %dl,0x8(%rcx)
     9cb:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     9d2:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
     9d6:	e9 7a 1c 00 00       	jmp    2655 <f_8001161d0+0x2655>
     9db:	81 f9 51 02 00 00    	cmp    $0x251,%ecx
     9e1:	0f 8f af 05 00 00    	jg     f96 <f_8001161d0+0xf96>
     9e7:	81 f9 c8 01 00 00    	cmp    $0x1c8,%ecx
     9ed:	0f 84 05 1d 00 00    	je     26f8 <f_8001161d0+0x26f8>
     9f3:	81 f9 0f 02 00 00    	cmp    $0x20f,%ecx
     9f9:	0f 85 8e 13 00 00    	jne    1d8d <f_8001161d0+0x1d8d>
     9ff:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     a06:	00 
     a07:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     a0e:	48 c7 01 00 08 00 00 	movq   $0x800,(%rcx)
     a15:	48 c7 41 08 01 00 00 	movq   $0x1,0x8(%rcx)
     a1c:	00 
     a1d:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     a24:	ff ff ff 
     a27:	48 8d 77 0b          	lea    0xb(%rdi),%rsi
     a2b:	48 89 73 68          	mov    %rsi,0x68(%rbx)
     a2f:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     a36:	00 
     a37:	48 89 71 18          	mov    %rsi,0x18(%rcx)
     a3b:	49 bc 00 00 00 00 01 	movabs $0x100000000,%r12
     a42:	00 00 00 
     a45:	4c 89 61 20          	mov    %r12,0x20(%rcx)
     a49:	48 89 79 28          	mov    %rdi,0x28(%rcx)
     a4d:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
     a54:	00 80 3f 
     a57:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
     a5b:	be ff ff ff ff       	mov    $0xffffffff,%esi
     a60:	48 89 71 30          	mov    %rsi,0x30(%rcx)
     a64:	4c 89 79 38          	mov    %r15,0x38(%rcx)
     a68:	4c 8d 9d 07 a8 04 00 	lea    0x4a807(%rbp),%r11
     a6f:	e9 42 17 00 00       	jmp    21b6 <f_8001161d0+0x21b6>
     a74:	81 f9 ac 03 00 00    	cmp    $0x3ac,%ecx
     a7a:	0f 8f 99 06 00 00    	jg     1119 <f_8001161d0+0x1119>
     a80:	81 f9 d5 02 00 00    	cmp    $0x2d5,%ecx
     a86:	0f 84 02 1f 00 00    	je     298e <f_8001161d0+0x298e>
     a8c:	81 f9 f3 02 00 00    	cmp    $0x2f3,%ecx
     a92:	0f 85 f5 12 00 00    	jne    1d8d <f_8001161d0+0x1d8d>
     a98:	4d 89 d4             	mov    %r10,%r12
     a9b:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     aa2:	00 
     aa3:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
     aaa:	49 c7 03 00 02 00 00 	movq   $0x200,(%r11)
     ab1:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
     ab8:	00 40 00 
     abb:	49 89 4b 08          	mov    %rcx,0x8(%r11)
     abf:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
     ac6:	00 
     ac7:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     ace:	ff ff ff 
     ad1:	48 8d 4f 13          	lea    0x13(%rdi),%rcx
     ad5:	49 89 4b 18          	mov    %rcx,0x18(%r11)
     ad9:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     ae0:	00 00 00 
     ae3:	49 89 4b 20          	mov    %rcx,0x20(%r11)
     ae7:	49 89 7b 28          	mov    %rdi,0x28(%r11)
     aeb:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
     af1:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
     af5:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
     afc:	00 80 3f 
     aff:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
     b03:	49 8d 4b 30          	lea    0x30(%r11),%rcx
     b07:	49 83 c3 38          	add    $0x38,%r11
     b0b:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
     b12:	00 00 00 
     b15:	4c 8d 87 f9 7a ff ff 	lea    -0x8507(%rdi),%r8
     b1c:	e9 c6 20 00 00       	jmp    2be7 <f_8001161d0+0x2be7>
     b21:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # b28 <f_8001161d0+0xb28>
     b28:	4a 63 34 81          	movslq (%rcx,%r8,4),%rsi
     b2c:	48 01 ce             	add    %rcx,%rsi
     b2f:	ff e6                	jmp    *%rsi
     b31:	48 8d 75 e0          	lea    -0x20(%rbp),%rsi
     b35:	e9 0d 09 00 00       	jmp    1447 <f_8001161d0+0x1447>
     b3a:	81 f9 c9 00 00 00    	cmp    $0xc9,%ecx
     b40:	0f 84 e3 15 00 00    	je     2129 <f_8001161d0+0x2129>
     b46:	81 f9 d9 00 00 00    	cmp    $0xd9,%ecx
     b4c:	0f 85 3b 12 00 00    	jne    1d8d <f_8001161d0+0x1d8d>
     b52:	49 8b 8c 24 c8 1e 00 	mov    0x1ec8(%r12),%rcx
     b59:	00 
     b5a:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     b5e:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
     b63:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
     b67:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
     b6e:	00 
     b6f:	45 0f b6 5f 08       	movzbl 0x8(%r15),%r11d
     b74:	4c 89 5b 70          	mov    %r11,0x70(%rbx)
     b78:	41 0f b7 af 14 29 00 	movzwl 0x2914(%r15),%ebp
     b7f:	00 
     b80:	83 e5 40             	and    $0x40,%ebp
     b83:	8b 71 08             	mov    0x8(%rcx),%esi
     b86:	4c 8b 49 10          	mov    0x10(%rcx),%r9
     b8a:	45 31 c0             	xor    %r8d,%r8d
     b8d:	44 39 de             	cmp    %r11d,%esi
     b90:	be 00 00 00 00       	mov    $0x0,%esi
     b95:	49 0f 47 f3          	cmova  %r11,%rsi
     b99:	48 c7 43 78 e0 3c 00 	movq   $0x3ce0,0x78(%rbx)
     ba0:	00 
     ba1:	48 89 b3 88 00 00 00 	mov    %rsi,0x88(%rbx)
     ba8:	48 69 f6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rsi
     baf:	4a 8b b4 0e 40 3c 00 	mov    0x3c40(%rsi,%r9,1),%rsi
     bb6:	00 
     bb7:	48 89 b3 b0 00 00 00 	mov    %rsi,0xb0(%rbx)
     bbe:	4c 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%r9
     bc5:	4d 8b 89 b8 1e 00 00 	mov    0x1eb8(%r9),%r9
     bcc:	44 89 b0 70 ff ff ff 	mov    %r14d,-0x90(%rax)
     bd3:	48 89 b8 58 ff ff ff 	mov    %rdi,-0xa8(%rax)
     bda:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     be1:	ff 7f 7f 
     be4:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
     beb:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     bf2:	00 
     bf3:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     bf7:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     bfe:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     c02:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
     c09:	ff 
     c0a:	41 80 b9 b0 06 00 00 	cmpb   $0x0,0x6b0(%r9)
     c11:	00 
     c12:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     c19:	00 00 00 00 
     c1d:	48 89 90 20 ff ff ff 	mov    %rdx,-0xe0(%rax)
     c24:	48 c7 80 00 ff ff ff 	movq   $0x4,-0x100(%rax)
     c2b:	04 00 00 00 
     c2f:	48 89 33             	mov    %rsi,(%rbx)
     c32:	0f 95 c2             	setne  %dl
     c35:	c1 ed 06             	shr    $0x6,%ebp
     c38:	40 20 d5             	and    %dl,%bpl
     c3b:	c7 80 d8 fe ff ff 00 	movl   $0x0,-0x128(%rax)
     c42:	00 00 00 
     c45:	40 0f b6 d5          	movzbl %bpl,%edx
     c49:	c1 e2 1a             	shl    $0x1a,%edx
     c4c:	81 ca 01 00 40 00    	or     $0x400001,%edx
     c52:	89 90 dc fe ff ff    	mov    %edx,-0x124(%rax)
     c58:	48 ba 10 00 00 00 03 	movabs $0x300000010,%rdx
     c5f:	00 00 00 
     c62:	48 89 90 d0 fe ff ff 	mov    %rdx,-0x130(%rax)
     c69:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     c70:	ff ff 00 00 
     c74:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
     c7b:	ff ff ff 
     c7e:	48 8d 56 07          	lea    0x7(%rsi),%rdx
     c82:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
     c89:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
     c90:	00 00 00 
     c93:	48 89 90 f0 fe ff ff 	mov    %rdx,-0x110(%rax)
     c9a:	48 89 b0 f8 fe ff ff 	mov    %rsi,-0x108(%rax)
     ca1:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
     ca8:	00 80 3f 
     cab:	48 89 90 08 ff ff ff 	mov    %rdx,-0xf8(%rax)
     cb2:	48 89 90 10 ff ff ff 	mov    %rdx,-0xf0(%rax)
     cb9:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
     cc0:	00 00 00 
     cc3:	48 8d 95 00 54 09 00 	lea    0x95400(%rbp),%rdx
     cca:	48 89 53 68          	mov    %rdx,0x68(%rbx)
     cce:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
     cd5:	48 8b 3c 24          	mov    (%rsp),%rdi
     cd9:	48 89 be a4 00 00 00 	mov    %rdi,0xa4(%rsi)
     ce0:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
     ce7:	ff 7f ff 
     cea:	48 89 b3 80 00 00 00 	mov    %rsi,0x80(%rbx)
     cf1:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
     cf8:	48 89 b0 50 ff ff ff 	mov    %rsi,-0xb0(%rax)
     cff:	48 89 b0 68 ff ff ff 	mov    %rsi,-0x98(%rax)
     d06:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
     d0d:	00 00 00 00 
     d11:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
     d18:	49 69 d3 e0 3c 00 00 	imul   $0x3ce0,%r11,%rdx
     d1f:	44 39 59 08          	cmp    %r11d,0x8(%rcx)
     d23:	49 0f 46 d0          	cmovbe %r8,%rdx
     d27:	48 8b 71 10          	mov    0x10(%rcx),%rsi
     d2b:	c5 f8 10 84 16 00 2e 	vmovups 0x2e00(%rsi,%rdx,1),%xmm0
     d32:	00 00 
     d34:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
     d3b:	ff 
     d3c:	8b 71 08             	mov    0x8(%rcx),%esi
     d3f:	31 ff                	xor    %edi,%edi
     d41:	31 c0                	xor    %eax,%eax
     d43:	41 89 f1             	mov    %esi,%r9d
     d46:	45 29 d9             	sub    %r11d,%r9d
     d49:	8b 53 70             	mov    0x70(%rbx),%edx
     d4c:	49 0f 46 d0          	cmovbe %r8,%rdx
     d50:	40 0f 94 c7          	sete   %dil
     d54:	0f 93 c0             	setae  %al
     d57:	c1 e7 1e             	shl    $0x1e,%edi
     d5a:	c1 e0 1d             	shl    $0x1d,%eax
     d5d:	09 f8                	or     %edi,%eax
     d5f:	48 8b 49 10          	mov    0x10(%rcx),%rcx
     d63:	c4 e2 30 f2 f6       	andn   %esi,%r9d,%esi
     d68:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
     d6f:	44 09 c8             	or     %r9d,%eax
     d72:	8b 7b 78             	mov    0x78(%rbx),%edi
     d75:	c1 ee 03             	shr    $0x3,%esi
     d78:	81 e6 00 00 00 10    	and    $0x10000000,%esi
     d7e:	09 c6                	or     %eax,%esi
     d80:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
     d87:	48 0f af fa          	imul   %rdx,%rdi
     d8b:	48 8b 84 0f 80 30 00 	mov    0x3080(%rdi,%rcx,1),%rax
     d92:	00 
     d93:	48 8b 94 0f 88 30 00 	mov    0x3088(%rdi,%rcx,1),%rdx
     d9a:	00 
     d9b:	48 89 53 50          	mov    %rdx,0x50(%rbx)
     d9f:	48 8b b3 d0 00 00 00 	mov    0xd0(%rbx),%rsi
     da6:	48 89 06             	mov    %rax,(%rsi)
     da9:	48 89 56 08          	mov    %rdx,0x8(%rsi)
     dad:	48 8b 84 0f 90 30 00 	mov    0x3090(%rdi,%rcx,1),%rax
     db4:	00 
     db5:	48 89 43 48          	mov    %rax,0x48(%rbx)
     db9:	8b 8c 0f 98 30 00 00 	mov    0x3098(%rdi,%rcx,1),%ecx
     dc0:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
     dc7:	89 4a 08             	mov    %ecx,0x8(%rdx)
     dca:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
     dd1:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
     dd5:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
     dd9:	48 89 02             	mov    %rax,(%rdx)
     ddc:	48 8d 85 e6 09 51 fd 	lea    -0x2aef61a(%rbp),%rax
     de3:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
     dea:	48 89 df             	mov    %rbx,%rdi
     ded:	c5 f8 77             	vzeroupper
     df0:	e8 00 00 00 00       	call   df5 <f_8001161d0+0xdf5>
     df5:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     dfc:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
     e03:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     e0a:	48 89 01             	mov    %rax,(%rcx)
     e0d:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     e14:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     e1b:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
     e1f:	48 89 53 48          	mov    %rdx,0x48(%rbx)
     e23:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
     e2a:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     e2e:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     e34:	48 89 43 40          	mov    %rax,0x40(%rbx)
     e38:	88 51 08             	mov    %dl,0x8(%rcx)
     e3b:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     e42:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
     e46:	89 41 24             	mov    %eax,0x24(%rcx)
     e49:	e9 63 1f 00 00       	jmp    2db1 <f_8001161d0+0x2db1>
     e4e:	81 f9 b2 01 00 00    	cmp    $0x1b2,%ecx
     e54:	0f 84 42 1c 00 00    	je     2a9c <f_8001161d0+0x2a9c>
     e5a:	81 f9 b8 01 00 00    	cmp    $0x1b8,%ecx
     e60:	0f 85 27 0f 00 00    	jne    1d8d <f_8001161d0+0x1d8d>
     e66:	4d 89 d4             	mov    %r10,%r12
     e69:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     e70:	00 
     e71:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
     e78:	49 c7 03 08 00 00 00 	movq   $0x8,(%r11)
     e7f:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
     e86:	00 40 00 
     e89:	49 89 4b 08          	mov    %rcx,0x8(%r11)
     e8d:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
     e94:	00 
     e95:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     e9c:	ff ff ff 
     e9f:	48 8d 4f 15          	lea    0x15(%rdi),%rcx
     ea3:	49 89 4b 18          	mov    %rcx,0x18(%r11)
     ea7:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     eae:	00 00 00 
     eb1:	49 89 4b 20          	mov    %rcx,0x20(%r11)
     eb5:	49 89 7b 28          	mov    %rdi,0x28(%r11)
     eb9:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
     ebf:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
     ec3:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
     eca:	00 80 3f 
     ecd:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
     ed1:	49 8d 4b 30          	lea    0x30(%r11),%rcx
     ed5:	49 83 c3 38          	add    $0x38,%r11
     ed9:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
     ee0:	00 00 00 
     ee3:	4c 8d 87 af 2c 05 00 	lea    0x52caf(%rdi),%r8
     eea:	e9 f8 1c 00 00       	jmp    2be7 <f_8001161d0+0x2be7>
     eef:	81 f9 b6 02 00 00    	cmp    $0x2b6,%ecx
     ef5:	0f 84 ec 1b 00 00    	je     2ae7 <f_8001161d0+0x2ae7>
     efb:	81 f9 c5 02 00 00    	cmp    $0x2c5,%ecx
     f01:	0f 85 86 0e 00 00    	jne    1d8d <f_8001161d0+0x1d8d>
     f07:	4d 89 d4             	mov    %r10,%r12
     f0a:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     f11:	00 
     f12:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
     f19:	48 b9 01 00 00 00 04 	movabs $0x400000001,%rcx
     f20:	00 00 00 
     f23:	49 89 0b             	mov    %rcx,(%r11)
     f26:	48 b9 00 00 00 00 02 	movabs $0x80200000000,%rcx
     f2d:	08 00 00 
     f30:	49 89 4b 08          	mov    %rcx,0x8(%r11)
     f34:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
     f3b:	00 
     f3c:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
     f43:	ff ff ff 
     f46:	48 8d 4f 0f          	lea    0xf(%rdi),%rcx
     f4a:	49 89 4b 18          	mov    %rcx,0x18(%r11)
     f4e:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     f55:	00 00 00 
     f58:	49 89 4b 20          	mov    %rcx,0x20(%r11)
     f5c:	49 89 7b 28          	mov    %rdi,0x28(%r11)
     f60:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
     f66:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
     f6a:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
     f71:	00 80 3f 
     f74:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
     f78:	49 8d 4b 30          	lea    0x30(%r11),%rcx
     f7c:	49 83 c3 38          	add    $0x38,%r11
     f80:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
     f87:	00 00 00 
     f8a:	4c 8d 87 88 db 0a 00 	lea    0xadb88(%rdi),%r8
     f91:	e9 51 1c 00 00       	jmp    2be7 <f_8001161d0+0x2be7>
     f96:	81 f9 52 02 00 00    	cmp    $0x252,%ecx
     f9c:	0f 84 cb 1b 00 00    	je     2b6d <f_8001161d0+0x2b6d>
     fa2:	81 f9 61 02 00 00    	cmp    $0x261,%ecx
     fa8:	0f 85 df 0d 00 00    	jne    1d8d <f_8001161d0+0x1d8d>
     fae:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     fb5:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
     fbc:	48 be 00 00 00 00 0f 	movabs $0xf00000000,%rsi
     fc3:	00 00 00 
     fc6:	48 89 71 14          	mov    %rsi,0x14(%rcx)
     fca:	48 be 00 00 00 00 ff 	movabs $0xffff00000000,%rsi
     fd1:	ff 00 00 
     fd4:	48 81 ce 00 00 40 08 	or     $0x8400000,%rsi
     fdb:	48 89 71 0c          	mov    %rsi,0xc(%rcx)
     fdf:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
     fe6:	8b b6 8c 3a 00 00    	mov    0x3a8c(%rsi),%esi
     fec:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
     ff1:	4c 89 53 60          	mov    %r10,0x60(%rbx)
     ff5:	48 89 53 40          	mov    %rdx,0x40(%rbx)
     ff9:	48 c7 41 04 00 00 00 	movq   $0x0,0x4(%rcx)
    1000:	00 
    1001:	4c 8b 43 78          	mov    0x78(%rbx),%r8
    1005:	4c 89 41 1c          	mov    %r8,0x1c(%rcx)
    1009:	41 89 f1             	mov    %esi,%r9d
    100c:	41 c1 e1 0d          	shl    $0xd,%r9d
    1010:	41 81 e1 00 00 00 40 	and    $0x40000000,%r9d
    1017:	49 81 f1 00 00 00 40 	xor    $0x40000000,%r9
    101e:	4c 89 8b 10 01 00 00 	mov    %r9,0x110(%rbx)
    1025:	48 c7 43 68 01 00 00 	movq   $0x1,0x68(%rbx)
    102c:	00 
    102d:	c7 41 34 00 00 00 00 	movl   $0x0,0x34(%rcx)
    1034:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    103b:	00 
    103c:	48 c7 41 24 01 00 00 	movq   $0x1,0x24(%rcx)
    1043:	00 
    1044:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1048:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    104f:	00 00 00 
    1052:	44 89 41 2c          	mov    %r8d,0x2c(%rcx)
    1056:	c7 41 30 01 00 00 00 	movl   $0x1,0x30(%rcx)
    105d:	c1 ee 08             	shr    $0x8,%esi
    1060:	81 e6 00 02 00 00    	and    $0x200,%esi
    1066:	81 ce 00 00 00 40    	or     $0x40000000,%esi
    106c:	89 31                	mov    %esi,(%rcx)
    106e:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    1075:	00 00 00 
    1078:	48 05 f0 85 00 00    	add    $0x85f0,%rax
    107e:	48 89 43 70          	mov    %rax,0x70(%rbx)
    1082:	48 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rsi
    1089:	00 80 3f 
    108c:	48 89 71 38          	mov    %rsi,0x38(%rcx)
    1090:	48 89 71 40          	mov    %rsi,0x40(%rcx)
    1094:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    109b:	48 8b 3c 24          	mov    (%rsp),%rdi
    109f:	48 89 be a4 00 00 00 	mov    %rdi,0xa4(%rsi)
    10a6:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
    10ad:	ff 7f ff 
    10b0:	48 89 b3 80 00 00 00 	mov    %rsi,0x80(%rbx)
    10b7:	48 89 b1 98 00 00 00 	mov    %rsi,0x98(%rcx)
    10be:	48 bf ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rdi
    10c5:	ff 7f 7f 
    10c8:	48 89 79 78          	mov    %rdi,0x78(%rcx)
    10cc:	48 89 b1 80 00 00 00 	mov    %rsi,0x80(%rcx)
    10d3:	4c 89 91 88 00 00 00 	mov    %r10,0x88(%rcx)
    10da:	48 89 b9 90 00 00 00 	mov    %rdi,0x90(%rcx)
    10e1:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    10e5:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    10ea:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    10f1:	00 
    10f2:	48 89 41 70          	mov    %rax,0x70(%rcx)
    10f6:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    10fd:	48 c7 40 48 00 00 00 	movq   $0x0,0x48(%rax)
    1104:	00 
    1105:	48 89 50 50          	mov    %rdx,0x50(%rax)
    1109:	48 8b 73 48          	mov    0x48(%rbx),%rsi
    110d:	4c 8b a3 d0 00 00 00 	mov    0xd0(%rbx),%r12
    1114:	e9 79 1b 00 00       	jmp    2c92 <f_8001161d0+0x2c92>
    1119:	81 f9 ad 03 00 00    	cmp    $0x3ad,%ecx
    111f:	0f 84 4c 1f 00 00    	je     3071 <f_8001161d0+0x3071>
    1125:	81 f9 12 04 00 00    	cmp    $0x412,%ecx
    112b:	0f 85 5c 0c 00 00    	jne    1d8d <f_8001161d0+0x1d8d>
    1131:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
    1138:	48 8b 89 c8 1e 00 00 	mov    0x1ec8(%rcx),%rcx
    113f:	48 89 4b 70          	mov    %rcx,0x70(%rbx)
    1143:	48 bf 00 00 00 00 01 	movabs $0x100000000,%rdi
    114a:	00 00 00 
    114d:	48 89 3b             	mov    %rdi,(%rbx)
    1150:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1154:	4c 8b 83 00 01 00 00 	mov    0x100(%rbx),%r8
    115b:	49 c7 00 02 00 00 00 	movq   $0x2,(%r8)
    1162:	48 be 00 00 00 00 00 	movabs $0x40000000000000,%rsi
    1169:	00 40 00 
    116c:	48 ff c6             	inc    %rsi
    116f:	49 89 70 08          	mov    %rsi,0x8(%r8)
    1173:	49 89 78 20          	mov    %rdi,0x20(%r8)
    1177:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    117e:	ff ff ff 
    1181:	49 89 78 28          	mov    %rdi,0x28(%r8)
    1185:	48 89 6b 68          	mov    %rbp,0x68(%rbx)
    1189:	49 b9 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r9
    1190:	ff 7f ff 
    1193:	4d 89 88 80 00 00 00 	mov    %r9,0x80(%r8)
    119a:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    119f:	49 89 b0 88 00 00 00 	mov    %rsi,0x88(%r8)
    11a6:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    11ad:	4c 8b 14 24          	mov    (%rsp),%r10
    11b1:	4c 89 96 a4 00 00 00 	mov    %r10,0xa4(%rsi)
    11b8:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
    11bf:	ff 7f 7f 
    11c2:	4d 89 90 90 00 00 00 	mov    %r10,0x90(%r8)
    11c9:	4d 89 88 98 00 00 00 	mov    %r9,0x98(%r8)
    11d0:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 11d8 <f_8001161d0+0x11d8>
    11d7:	00 
    11d8:	c5 fc 11 43 78       	vmovups %ymm0,0x78(%rbx)
    11dd:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    11e4:	00 
    11e5:	45 89 b0 a0 00 00 00 	mov    %r14d,0xa0(%r8)
    11ec:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    11f3:	0f b6 70 08          	movzbl 0x8(%rax),%esi
    11f7:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    11fb:	41 c7 80 bc 00 00 00 	movl   $0x3,0xbc(%r8)
    1202:	03 00 00 00 
    1206:	49 c7 40 10 ff ff 00 	movq   $0xffff,0x10(%r8)
    120d:	00 
    120e:	48 8d 47 16          	lea    0x16(%rdi),%rax
    1212:	49 89 40 18          	mov    %rax,0x18(%r8)
    1216:	49 c7 40 68 00 00 00 	movq   $0x0,0x68(%r8)
    121d:	00 
    121e:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    1223:	49 89 40 30          	mov    %rax,0x30(%r8)
    1227:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    122e:	00 80 3f 
    1231:	49 89 40 38          	mov    %rax,0x38(%r8)
    1235:	49 89 40 40          	mov    %rax,0x40(%r8)
    1239:	49 c7 40 48 00 00 00 	movq   $0x0,0x48(%r8)
    1240:	00 
    1241:	49 89 50 50          	mov    %rdx,0x50(%r8)
    1245:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1249:	c4 c1 78 11 40 58    	vmovups %xmm0,0x58(%r8)
    124f:	49 89 68 70          	mov    %rbp,0x70(%r8)
    1253:	4d 89 50 78          	mov    %r10,0x78(%r8)
    1257:	48 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rax
    125e:	31 ff                	xor    %edi,%edi
    1260:	39 71 08             	cmp    %esi,0x8(%rcx)
    1263:	48 0f 46 c7          	cmovbe %rdi,%rax
    1267:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    126b:	48 8b 94 08 b8 30 00 	mov    0x30b8(%rax,%rcx,1),%rdx
    1272:	00 
    1273:	48 89 53 60          	mov    %rdx,0x60(%rbx)
    1277:	48 8b 84 08 b0 30 00 	mov    0x30b0(%rax,%rcx,1),%rax
    127e:	00 
    127f:	48 8b 4b 48          	mov    0x48(%rbx),%rcx
    1283:	48 89 01             	mov    %rax,(%rcx)
    1286:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    128a:	48 8b 43 70          	mov    0x70(%rbx),%rax
    128e:	44 8b 40 08          	mov    0x8(%rax),%r8d
    1292:	4c 89 43 48          	mov    %r8,0x48(%rbx)
    1296:	48 8b 48 10          	mov    0x10(%rax),%rcx
    129a:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    129e:	8b 53 40             	mov    0x40(%rbx),%edx
    12a1:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
    12a8:	45 31 d2             	xor    %r10d,%r10d
    12ab:	45 31 c9             	xor    %r9d,%r9d
    12ae:	45 89 c3             	mov    %r8d,%r11d
    12b1:	41 29 f3             	sub    %esi,%r11d
    12b4:	48 0f 46 d7          	cmovbe %rdi,%rdx
    12b8:	41 0f 94 c2          	sete   %r10b
    12bc:	41 0f 93 c1          	setae  %r9b
    12c0:	41 c1 e2 1e          	shl    $0x1e,%r10d
    12c4:	41 c1 e1 1d          	shl    $0x1d,%r9d
    12c8:	45 09 d1             	or     %r10d,%r9d
    12cb:	c4 c2 20 f2 f0       	andn   %r8d,%r11d,%esi
    12d0:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    12d7:	45 09 d9             	or     %r11d,%r9d
    12da:	c1 ee 03             	shr    $0x3,%esi
    12dd:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    12e3:	44 09 ce             	or     %r9d,%esi
    12e6:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    12ed:	48 8b b4 0a 30 33 00 	mov    0x3330(%rdx,%rcx,1),%rsi
    12f4:	00 
    12f5:	48 8b bc 0a 38 33 00 	mov    0x3338(%rdx,%rcx,1),%rdi
    12fc:	00 
    12fd:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    1301:	4c 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%r8
    1308:	49 89 30             	mov    %rsi,(%r8)
    130b:	49 89 78 08          	mov    %rdi,0x8(%r8)
    130f:	8b b4 0a 48 33 00 00 	mov    0x3348(%rdx,%rcx,1),%esi
    1316:	48 8b 8c 0a 40 33 00 	mov    0x3340(%rdx,%rcx,1),%rcx
    131d:	00 
    131e:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
    1325:	48 89 0a             	mov    %rcx,(%rdx)
    1328:	89 72 08             	mov    %esi,0x8(%rdx)
    132b:	8b 48 44             	mov    0x44(%rax),%ecx
    132e:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    1332:	48 83 c0 30          	add    $0x30,%rax
    1336:	e9 1a 0d 00 00       	jmp    2055 <f_8001161d0+0x2055>
    133b:	81 f9 1a 05 00 00    	cmp    $0x51a,%ecx
    1341:	0f 85 46 0a 00 00    	jne    1d8d <f_8001161d0+0x1d8d>
    1347:	b8 e8 0a 00 00       	mov    $0xae8,%eax
    134c:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    1353:	48 89 03             	mov    %rax,(%rbx)
    1356:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    135d:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    1364:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    1368:	48 89 43 10          	mov    %rax,0x10(%rbx)
    136c:	48 8d 85 ca 19 51 fd 	lea    -0x2aee636(%rbp),%rax
    1373:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    137a:	48 89 df             	mov    %rbx,%rdi
    137d:	c5 f8 77             	vzeroupper
    1380:	e8 00 00 00 00       	call   1385 <f_8001161d0+0x1385>
    1385:	e9 27 1a 00 00       	jmp    2db1 <f_8001161d0+0x2db1>
    138a:	83 f9 61             	cmp    $0x61,%ecx
    138d:	0f 85 fa 09 00 00    	jne    1d8d <f_8001161d0+0x1d8d>
    1393:	4d 89 d4             	mov    %r10,%r12
    1396:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    139d:	00 
    139e:	48 c7 80 d0 fe ff ff 	movq   $0x8,-0x130(%rax)
    13a5:	08 00 00 00 
    13a9:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    13b0:	00 40 00 
    13b3:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    13ba:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    13c1:	ff ff 00 00 
    13c5:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    13cc:	ff ff ff 
    13cf:	48 8d 4f 0f          	lea    0xf(%rdi),%rcx
    13d3:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    13da:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    13e1:	00 00 00 
    13e4:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
    13e8:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    13ef:	48 89 b8 f8 fe ff ff 	mov    %rdi,-0x108(%rax)
    13f6:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    13fd:	00 80 3f 
    1400:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    1404:	48 8d 88 00 ff ff ff 	lea    -0x100(%rax),%rcx
    140b:	4c 8d 98 08 ff ff ff 	lea    -0xf8(%rax),%r11
    1412:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    1419:	00 00 00 
    141c:	4c 8d 87 ab f2 0c 00 	lea    0xcf2ab(%rdi),%r8
    1423:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    1429:	e9 b9 17 00 00       	jmp    2be7 <f_8001161d0+0x2be7>
    142e:	48 8d b5 0b d1 09 00 	lea    0x9d10b(%rbp),%rsi
    1435:	eb 10                	jmp    1447 <f_8001161d0+0x1447>
    1437:	48 8d b5 2d 8c 01 00 	lea    0x18c2d(%rbp),%rsi
    143e:	eb 07                	jmp    1447 <f_8001161d0+0x1447>
    1440:	48 8d b5 4b 4f 0a 00 	lea    0xa4f4b(%rbp),%rsi
    1447:	48 89 73 68          	mov    %rsi,0x68(%rbx)
    144b:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
    1452:	41 c7 03 00 00 00 10 	movl   $0x10000000,(%r11)
    1459:	4c 8b bb a0 00 00 00 	mov    0xa0(%rbx),%r15
    1460:	49 8b 8f f0 31 00 00 	mov    0x31f0(%r15),%rcx
    1467:	48 89 0b             	mov    %rcx,(%rbx)
    146a:	49 b8 10 00 00 00 03 	movabs $0x300000010,%r8
    1471:	00 00 00 
    1474:	4d 8d 48 f0          	lea    -0x10(%r8),%r9
    1478:	4d 89 4b 14          	mov    %r9,0x14(%r11)
    147c:	48 c7 43 78 01 00 00 	movq   $0x1,0x78(%rbx)
    1483:	00 
    1484:	49 83 c0 f6          	add    $0xfffffffffffffff6,%r8
    1488:	4d 89 43 04          	mov    %r8,0x4(%r11)
    148c:	4c 8b 43 70          	mov    0x70(%rbx),%r8
    1490:	4d 89 43 2c          	mov    %r8,0x2c(%r11)
    1494:	49 b8 00 00 00 00 ff 	movabs $0xffff00000000,%r8
    149b:	ff 00 00 
    149e:	4d 89 43 0c          	mov    %r8,0xc(%r11)
    14a2:	49 b9 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r9
    14a9:	ff 7f ff 
    14ac:	4c 89 4b 70          	mov    %r9,0x70(%rbx)
    14b0:	bf ff ff ff ff       	mov    $0xffffffff,%edi
    14b5:	49 89 7b 1c          	mov    %rdi,0x1c(%r11)
    14b9:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    14be:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    14c2:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
    14c9:	00 80 3f 
    14cc:	49 89 7b 38          	mov    %rdi,0x38(%r11)
    14d0:	49 89 7b 40          	mov    %rdi,0x40(%r11)
    14d4:	4c 8b 2c 24          	mov    (%rsp),%r13
    14d8:	4c 89 6b 48          	mov    %r13,0x48(%rbx)
    14dc:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    14e0:	49 c7 43 24 01 00 00 	movq   $0x1,0x24(%r11)
    14e7:	00 
    14e8:	41 c7 43 34 00 00 00 	movl   $0x0,0x34(%r11)
    14ef:	00 
    14f0:	4c 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%r8
    14f7:	4d 89 a8 a4 00 00 00 	mov    %r13,0xa4(%r8)
    14fe:	4d 89 8b 98 00 00 00 	mov    %r9,0x98(%r11)
    1505:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1509:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1510:	00 
    1511:	45 89 b3 a0 00 00 00 	mov    %r14d,0xa0(%r11)
    1518:	41 c7 83 bc 00 00 00 	movl   $0x1,0xbc(%r11)
    151f:	01 00 00 00 
    1523:	48 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rax
    152a:	ff 7f 7f 
    152d:	49 89 43 78          	mov    %rax,0x78(%r11)
    1531:	4d 89 8b 80 00 00 00 	mov    %r9,0x80(%r11)
    1538:	4d 89 93 88 00 00 00 	mov    %r10,0x88(%r11)
    153f:	49 89 83 90 00 00 00 	mov    %rax,0x90(%r11)
    1546:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    154a:	c4 c1 78 11 43 58    	vmovups %xmm0,0x58(%r11)
    1550:	49 c7 43 68 00 00 00 	movq   $0x0,0x68(%r11)
    1557:	00 
    1558:	49 89 73 70          	mov    %rsi,0x70(%r11)
    155c:	49 c7 43 48 00 00 00 	movq   $0x0,0x48(%r11)
    1563:	00 
    1564:	49 89 53 50          	mov    %rdx,0x50(%r11)
    1568:	48 85 c9             	test   %rcx,%rcx
    156b:	0f 84 40 18 00 00    	je     2db1 <f_8001161d0+0x2db1>
    1571:	49 8b 87 c8 1e 00 00 	mov    0x1ec8(%r15),%rax
    1578:	48 8b 93 98 00 00 00 	mov    0x98(%rbx),%rdx
    157f:	0f b6 72 08          	movzbl 0x8(%rdx),%esi
    1583:	8b 78 08             	mov    0x8(%rax),%edi
    1586:	48 8b 40 10          	mov    0x10(%rax),%rax
    158a:	31 d2                	xor    %edx,%edx
    158c:	45 31 c9             	xor    %r9d,%r9d
    158f:	45 31 d2             	xor    %r10d,%r10d
    1592:	89 fd                	mov    %edi,%ebp
    1594:	29 f5                	sub    %esi,%ebp
    1596:	41 0f 94 c1          	sete   %r9b
    159a:	48 0f 47 d6          	cmova  %rsi,%rdx
    159e:	41 0f 93 c2          	setae  %r10b
    15a2:	c4 e2 50 f2 f7       	andn   %edi,%ebp,%esi
    15a7:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    15ad:	41 c1 e1 1e          	shl    $0x1e,%r9d
    15b1:	41 c1 e2 1d          	shl    $0x1d,%r10d
    15b5:	45 09 ca             	or     %r9d,%r10d
    15b8:	41 09 ea             	or     %ebp,%r10d
    15bb:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    15c2:	00 00 00 
    15c5:	c1 ee 03             	shr    $0x3,%esi
    15c8:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    15ce:	44 09 d6             	or     %r10d,%esi
    15d1:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    15d8:	48 c7 43 60 e0 3c 00 	movq   $0x3ce0,0x60(%rbx)
    15df:	00 
    15e0:	48 89 53 58          	mov    %rdx,0x58(%rbx)
    15e4:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
    15eb:	48 8d 34 02          	lea    (%rdx,%rax,1),%rsi
    15ef:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    15f3:	4c 8d bb 10 02 00 00 	lea    0x210(%rbx),%r15
    15fa:	4c 8d a3 20 02 00 00 	lea    0x220(%rbx),%r12
    1601:	c5 fb 10 84 02 00 2e 	vmovsd 0x2e00(%rdx,%rax,1),%xmm0
    1608:	00 00 
    160a:	c5 fb 10 8c 02 08 2e 	vmovsd 0x2e08(%rdx,%rax,1),%xmm1
    1611:	00 00 
    1613:	c5 f0 5c c0          	vsubps %xmm0,%xmm1,%xmm0
    1617:	45 89 b3 a0 00 00 00 	mov    %r14d,0xa0(%r11)
    161e:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    1625:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    1629:	48 89 43 40          	mov    %rax,0x40(%rbx)
    162d:	4d 89 a8 a4 00 00 00 	mov    %r13,0xa4(%r8)
    1634:	c4 e3 79 17 c0 00    	vextractps $0x0,%xmm0,%eax
    163a:	c4 e3 79 17 c2 01    	vextractps $0x1,%xmm0,%edx
    1640:	48 89 93 10 02 00 00 	mov    %rdx,0x210(%rbx)
    1647:	48 89 83 00 02 00 00 	mov    %rax,0x200(%rbx)
    164e:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    1655:	00 00 00 00 
    1659:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    1660:	00 00 00 00 
    1664:	8b 81 08 03 00 00    	mov    0x308(%rcx),%eax
    166a:	48 89 83 20 02 00 00 	mov    %rax,0x220(%rbx)
    1671:	48 c7 83 28 02 00 00 	movq   $0x0,0x228(%rbx)
    1678:	00 00 00 00 
    167c:	8b 81 0c 03 00 00    	mov    0x30c(%rcx),%eax
    1682:	48 89 83 30 02 00 00 	mov    %rax,0x230(%rbx)
    1689:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    1690:	00 00 00 00 
    1694:	48 89 df             	mov    %rbx,%rdi
    1697:	31 f6                	xor    %esi,%esi
    1699:	ba 01 00 00 00       	mov    $0x1,%edx
    169e:	b9 01 00 00 00       	mov    $0x1,%ecx
    16a3:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    16a9:	41 b9 03 00 00 00    	mov    $0x3,%r9d
    16af:	6a 00                	push   $0x0
    16b1:	6a 00                	push   $0x0
    16b3:	6a 01                	push   $0x1
    16b5:	6a 00                	push   $0x0
    16b7:	c5 f8 77             	vzeroupper
    16ba:	e8 00 00 00 00       	call   16bf <f_8001161d0+0x16bf>
    16bf:	48 83 c4 20          	add    $0x20,%rsp
    16c3:	48 89 df             	mov    %rbx,%rdi
    16c6:	31 f6                	xor    %esi,%esi
    16c8:	ba 01 00 00 00       	mov    $0x1,%edx
    16cd:	b9 01 00 00 00       	mov    $0x1,%ecx
    16d2:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    16d8:	41 b9 03 00 00 00    	mov    $0x3,%r9d
    16de:	6a 01                	push   $0x1
    16e0:	6a 01                	push   $0x1
    16e2:	6a 01                	push   $0x1
    16e4:	6a 00                	push   $0x0
    16e6:	e8 00 00 00 00       	call   16eb <f_8001161d0+0x16eb>
    16eb:	48 83 c4 20          	add    $0x20,%rsp
    16ef:	48 89 df             	mov    %rbx,%rdi
    16f2:	31 f6                	xor    %esi,%esi
    16f4:	31 d2                	xor    %edx,%edx
    16f6:	b9 01 00 00 00       	mov    $0x1,%ecx
    16fb:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    1701:	45 31 c9             	xor    %r9d,%r9d
    1704:	6a 00                	push   $0x0
    1706:	6a 00                	push   $0x0
    1708:	6a 01                	push   $0x1
    170a:	6a 00                	push   $0x0
    170c:	e8 00 00 00 00       	call   1711 <f_8001161d0+0x1711>
    1711:	48 83 c4 20          	add    $0x20,%rsp
    1715:	c5 fa 10 83 20 02 00 	vmovss 0x220(%rbx),%xmm0
    171c:	00 
    171d:	c5 fa 59 83 00 02 00 	vmulss 0x200(%rbx),%xmm0,%xmm0
    1724:	00 
    1725:	c5 f9 7e c0          	vmovd  %xmm0,%eax
    1729:	48 89 83 00 02 00 00 	mov    %rax,0x200(%rbx)
    1730:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    1737:	00 00 00 00 
    173b:	48 89 df             	mov    %rbx,%rdi
    173e:	31 f6                	xor    %esi,%esi
    1740:	31 d2                	xor    %edx,%edx
    1742:	b9 01 00 00 00       	mov    $0x1,%ecx
    1747:	41 b8 01 00 00 00    	mov    $0x1,%r8d
    174d:	45 31 c9             	xor    %r9d,%r9d
    1750:	6a 01                	push   $0x1
    1752:	6a 01                	push   $0x1
    1754:	6a 01                	push   $0x1
    1756:	6a 00                	push   $0x0
    1758:	e8 00 00 00 00       	call   175d <f_8001161d0+0x175d>
    175d:	48 83 c4 20          	add    $0x20,%rsp
    1761:	c5 fa 10 83 30 02 00 	vmovss 0x230(%rbx),%xmm0
    1768:	00 
    1769:	c5 fa 59 83 10 02 00 	vmulss 0x210(%rbx),%xmm0,%xmm0
    1770:	00 
    1771:	c5 f9 7e c0          	vmovd  %xmm0,%eax
    1775:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1779:	c5 f8 11 83 18 02 00 	vmovups %xmm0,0x218(%rbx)
    1780:	00 
    1781:	48 89 83 10 02 00 00 	mov    %rax,0x210(%rbx)
    1788:	48 c7 83 28 02 00 00 	movq   $0x0,0x228(%rbx)
    178f:	00 00 00 00 
    1793:	48 89 df             	mov    %rbx,%rdi
    1796:	31 f6                	xor    %esi,%esi
    1798:	31 d2                	xor    %edx,%edx
    179a:	b9 01 00 00 00       	mov    $0x1,%ecx
    179f:	e8 00 00 00 00       	call   17a4 <f_8001161d0+0x17a4>
    17a4:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    17ab:	48 8b 8b 00 02 00 00 	mov    0x200(%rbx),%rcx
    17b2:	48 8b 93 20 02 00 00 	mov    0x220(%rbx),%rdx
    17b9:	c5 f9 6e c1          	vmovd  %ecx,%xmm0
    17bd:	c4 e3 79 22 83 10 02 	vpinsrd $0x1,0x210(%rbx),%xmm0,%xmm0
    17c4:	00 00 01 
    17c7:	c5 f9 6e ca          	vmovd  %edx,%xmm1
    17cb:	c4 e2 79 58 c9       	vpbroadcastd %xmm1,%xmm1
    17d0:	c5 f0 5f d0          	vmaxps %xmm0,%xmm1,%xmm2
    17d4:	c5 f8 c2 c0 03       	vcmpunordps %xmm0,%xmm0,%xmm0
    17d9:	c4 e3 69 4a c1 00    	vblendvps %xmm0,%xmm1,%xmm2,%xmm0
    17df:	c4 e3 79 17 c6 00    	vextractps $0x0,%xmm0,%esi
    17e5:	c4 e3 79 17 c7 01    	vextractps $0x1,%xmm0,%edi
    17eb:	48 89 bb 40 02 00 00 	mov    %rdi,0x240(%rbx)
    17f2:	48 89 b3 30 02 00 00 	mov    %rsi,0x230(%rbx)
    17f9:	48 c7 83 48 02 00 00 	movq   $0x0,0x248(%rbx)
    1800:	00 00 00 00 
    1804:	a9 00 00 00 40       	test   $0x40000000,%eax
    1809:	40 0f 94 c6          	sete   %sil
    180d:	85 c0                	test   %eax,%eax
    180f:	40 0f 98 c7          	sets   %dil
    1813:	a9 00 00 00 10       	test   $0x10000000,%eax
    1818:	0f 94 c0             	sete   %al
    181b:	40 30 f8             	xor    %dil,%al
    181e:	40 84 c6             	test   %al,%sil
    1821:	48 0f 45 ca          	cmovne %rdx,%rcx
    1825:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    182c:	00 00 00 00 
    1830:	89 c8                	mov    %ecx,%eax
    1832:	48 89 83 00 02 00 00 	mov    %rax,0x200(%rbx)
    1839:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    1840:	00 00 00 00 
    1844:	48 89 df             	mov    %rbx,%rdi
    1847:	be 01 00 00 00       	mov    $0x1,%esi
    184c:	31 d2                	xor    %edx,%edx
    184e:	b9 01 00 00 00       	mov    $0x1,%ecx
    1853:	e8 00 00 00 00       	call   1858 <f_8001161d0+0x1858>
    1858:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    185f:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    1866:	8b 93 30 02 00 00    	mov    0x230(%rbx),%edx
    186c:	85 c0                	test   %eax,%eax
    186e:	40 0f 98 c6          	sets   %sil
    1872:	a9 00 00 00 10       	test   $0x10000000,%eax
    1877:	40 0f 94 c7          	sete   %dil
    187b:	40 30 f7             	xor    %sil,%dil
    187e:	8b b3 40 02 00 00    	mov    0x240(%rbx),%esi
    1884:	89 91 80 00 00 00    	mov    %edx,0x80(%rcx)
    188a:	89 b1 84 00 00 00    	mov    %esi,0x84(%rcx)
    1890:	4d 0f 44 e7          	cmove  %r15,%r12
    1894:	89 91 98 00 00 00    	mov    %edx,0x98(%rcx)
    189a:	a9 00 00 00 40       	test   $0x40000000,%eax
    189f:	4d 0f 45 e7          	cmovne %r15,%r12
    18a3:	89 b1 9c 00 00 00    	mov    %esi,0x9c(%rcx)
    18a9:	49 8b 04 24          	mov    (%r12),%rax
    18ad:	89 c2                	mov    %eax,%edx
    18af:	48 89 93 10 02 00 00 	mov    %rdx,0x210(%rbx)
    18b6:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    18bd:	00 00 00 00 
    18c1:	8b 93 00 02 00 00    	mov    0x200(%rbx),%edx
    18c7:	89 51 78             	mov    %edx,0x78(%rcx)
    18ca:	89 41 7c             	mov    %eax,0x7c(%rcx)
    18cd:	89 91 90 00 00 00    	mov    %edx,0x90(%rcx)
    18d3:	89 81 94 00 00 00    	mov    %eax,0x94(%rcx)
    18d9:	48 8d 85 5e 18 51 fd 	lea    -0x2aee7a2(%rbp),%rax
    18e0:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    18e7:	48 89 df             	mov    %rbx,%rdi
    18ea:	e8 00 00 00 00       	call   18ef <f_8001161d0+0x18ef>
    18ef:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    18f6:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    18fd:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    1904:	48 89 01             	mov    %rax,(%rcx)
    1907:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    190e:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    1912:	48 89 43 40          	mov    %rax,0x40(%rbx)
    1916:	88 41 08             	mov    %al,0x8(%rcx)
    1919:	e9 93 14 00 00       	jmp    2db1 <f_8001161d0+0x2db1>
    191e:	48 8b 7b 78          	mov    0x78(%rbx),%rdi
    1922:	4c 89 c2             	mov    %r8,%rdx
    1925:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
    192c:	00 00 00 00 
    1930:	48 89 90 20 ff ff ff 	mov    %rdx,-0xe0(%rax)
    1937:	4c 8b bb a0 00 00 00 	mov    0xa0(%rbx),%r15
    193e:	44 8b a3 a8 00 00 00 	mov    0xa8(%rbx),%r12d
    1945:	45 8d 44 24 08       	lea    0x8(%r12),%r8d
    194a:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    1951:	c4 c2 43 f7 97 fc 0d 	shrx   %edi,0xdfc(%r15),%edx
    1958:	00 00 
    195a:	89 54 24 14          	mov    %edx,0x14(%rsp)
    195e:	44 89 41 30          	mov    %r8d,0x30(%rcx)
    1962:	48 8b 6b 68          	mov    0x68(%rbx),%rbp
    1966:	89 69 34             	mov    %ebp,0x34(%rcx)
    1969:	45 31 ed             	xor    %r13d,%r13d
    196c:	41 f7 c3 00 02 00 00 	test   $0x200,%r11d
    1973:	41 0f 94 c5          	sete   %r13b
    1977:	45 8b 87 20 0d 00 00 	mov    0xd20(%r15),%r8d
    197e:	45 31 d2             	xor    %r10d,%r10d
    1981:	41 39 f8             	cmp    %edi,%r8d
    1984:	49 0f 46 fa          	cmovbe %r10,%rdi
    1988:	44 89 de             	mov    %r11d,%esi
    198b:	c1 e6 10             	shl    $0x10,%esi
    198e:	81 e6 00 00 00 40    	and    $0x40000000,%esi
    1994:	48 89 f2             	mov    %rsi,%rdx
    1997:	48 81 f2 00 00 00 40 	xor    $0x40000000,%rdx
    199e:	41 89 f8             	mov    %edi,%r8d
    19a1:	4d 69 c0 b0 0b 00 00 	imul   $0xbb0,%r8,%r8
    19a8:	45 31 c9             	xor    %r9d,%r9d
    19ab:	85 f6                	test   %esi,%esi
    19ad:	41 0f 94 c1          	sete   %r9b
    19b1:	41 c1 e3 06          	shl    $0x6,%r11d
    19b5:	41 81 e3 00 00 04 00 	and    $0x40000,%r11d
    19bc:	41 c1 e1 04          	shl    $0x4,%r9d
    19c0:	44 85 6c 24 14       	test   %r13d,0x14(%rsp)
    19c5:	be 01 00 00 00       	mov    $0x1,%esi
    19ca:	c4 e2 51 f7 f6       	shlx   %ebp,%esi,%esi
    19cf:	48 c7 43 48 01 00 00 	movq   $0x1,0x48(%rbx)
    19d6:	00 
    19d7:	48 89 73 08          	mov    %rsi,0x8(%rbx)
    19db:	4d 8b bf 28 0d 00 00 	mov    0xd28(%r15),%r15
    19e2:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    19e6:	48 89 7b 78          	mov    %rdi,0x78(%rbx)
    19ea:	48 89 93 10 01 00 00 	mov    %rdx,0x110(%rbx)
    19f1:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    19f8:	00 
    19f9:	4b 8d 14 07          	lea    (%r15,%r8,1),%rdx
    19fd:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    1a01:	ba 0f 00 00 00       	mov    $0xf,%edx
    1a06:	0f 45 d6             	cmovne %esi,%edx
    1a09:	43 8d b4 19 00 00 20 	lea    0x200000(%r9,%r11,1),%esi
    1a10:	00 
    1a11:	48 c7 03 08 00 00 00 	movq   $0x8,(%rbx)
    1a18:	89 11                	mov    %edx,(%rcx)
    1a1a:	c7 41 04 08 00 00 00 	movl   $0x8,0x4(%rcx)
    1a21:	41 83 c4 04          	add    $0x4,%r12d
    1a25:	44 89 61 08          	mov    %r12d,0x8(%rcx)
    1a29:	89 71 0c             	mov    %esi,0xc(%rcx)
    1a2c:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    1a33:	00 
    1a34:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    1a3b:	ff ff ff 
    1a3e:	48 8d 56 02          	lea    0x2(%rsi),%rdx
    1a42:	48 89 51 18          	mov    %rdx,0x18(%rcx)
    1a46:	4c 8b 0c 24          	mov    (%rsp),%r9
    1a4a:	4c 89 8b 90 00 00 00 	mov    %r9,0x90(%rbx)
    1a51:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
    1a58:	00 00 00 
    1a5b:	48 89 51 20          	mov    %rdx,0x20(%rcx)
    1a5f:	48 89 71 28          	mov    %rsi,0x28(%rcx)
    1a63:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
    1a6a:	00 80 3f 
    1a6d:	48 89 51 38          	mov    %rdx,0x38(%rcx)
    1a71:	48 89 51 40          	mov    %rdx,0x40(%rcx)
    1a75:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    1a7c:	00 00 00 
    1a7f:	48 8d 95 b1 e5 0b 00 	lea    0xbe5b1(%rbp),%rdx
    1a86:	48 89 93 80 00 00 00 	mov    %rdx,0x80(%rbx)
    1a8d:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    1a94:	ff 7f ff 
    1a97:	48 89 bb 88 00 00 00 	mov    %rdi,0x88(%rbx)
    1a9e:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    1aa5:	4c 89 8e a4 00 00 00 	mov    %r9,0xa4(%rsi)
    1aac:	48 8b 73 58          	mov    0x58(%rbx),%rsi
    1ab0:	48 89 71 78          	mov    %rsi,0x78(%rcx)
    1ab4:	48 89 b9 80 00 00 00 	mov    %rdi,0x80(%rcx)
    1abb:	48 89 b9 98 00 00 00 	mov    %rdi,0x98(%rcx)
    1ac2:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    1ac7:	48 89 b9 88 00 00 00 	mov    %rdi,0x88(%rcx)
    1ace:	48 89 b1 90 00 00 00 	mov    %rsi,0x90(%rcx)
    1ad5:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1ad9:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    1ae0:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    1ae7:	00 00 00 
    1aea:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1aee:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    1af3:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    1afa:	00 
    1afb:	48 89 51 70          	mov    %rdx,0x70(%rcx)
    1aff:	43 8b 8c 07 d8 03 00 	mov    0x3d8(%r15,%r8,1),%ecx
    1b06:	00 
    1b07:	43 8b 84 07 f8 03 00 	mov    0x3f8(%r15,%r8,1),%eax
    1b0e:	00 
    1b0f:	48 89 43 60          	mov    %rax,0x60(%rbx)
    1b13:	89 c8                	mov    %ecx,%eax
    1b15:	c1 f8 1f             	sar    $0x1f,%eax
    1b18:	c4 e2 78 f2 c1       	andn   %ecx,%eax,%eax
    1b1d:	48 89 43 68          	mov    %rax,0x68(%rbx)
    1b21:	85 c9                	test   %ecx,%ecx
    1b23:	41 0f 49 ca          	cmovns %r10d,%ecx
    1b27:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    1b2b:	48 83 ec 08          	sub    $0x8,%rsp
    1b2f:	48 89 df             	mov    %rbx,%rdi
    1b32:	31 f6                	xor    %esi,%esi
    1b34:	ba 01 00 00 00       	mov    $0x1,%edx
    1b39:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1b3f:	45 31 c9             	xor    %r9d,%r9d
    1b42:	6a 00                	push   $0x0
    1b44:	c5 f8 77             	vzeroupper
    1b47:	e8 00 00 00 00       	call   1b4c <f_8001161d0+0x1b4c>
    1b4c:	48 83 c4 10          	add    $0x10,%rsp
    1b50:	8b 43 60             	mov    0x60(%rbx),%eax
    1b53:	89 c1                	mov    %eax,%ecx
    1b55:	c1 f9 1f             	sar    $0x1f,%ecx
    1b58:	c4 e2 70 f2 c8       	andn   %eax,%ecx,%ecx
    1b5d:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    1b61:	48 83 ec 08          	sub    $0x8,%rsp
    1b65:	48 89 df             	mov    %rbx,%rdi
    1b68:	31 f6                	xor    %esi,%esi
    1b6a:	ba 02 00 00 00       	mov    $0x2,%edx
    1b6f:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1b75:	45 31 c9             	xor    %r9d,%r9d
    1b78:	6a 00                	push   $0x0
    1b7a:	e8 00 00 00 00       	call   1b7f <f_8001161d0+0x1b7f>
    1b7f:	48 83 c4 10          	add    $0x10,%rsp
    1b83:	8b 43 60             	mov    0x60(%rbx),%eax
    1b86:	8b 4b 68             	mov    0x68(%rbx),%ecx
    1b89:	89 c2                	mov    %eax,%edx
    1b8b:	c1 fa 1f             	sar    $0x1f,%edx
    1b8e:	21 c2                	and    %eax,%edx
    1b90:	48 89 53 58          	mov    %rdx,0x58(%rbx)
    1b94:	48 83 ec 08          	sub    $0x8,%rsp
    1b98:	48 89 df             	mov    %rbx,%rdi
    1b9b:	31 f6                	xor    %esi,%esi
    1b9d:	31 d2                	xor    %edx,%edx
    1b9f:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1ba5:	45 31 c9             	xor    %r9d,%r9d
    1ba8:	6a 00                	push   $0x0
    1baa:	e8 00 00 00 00       	call   1baf <f_8001161d0+0x1baf>
    1baf:	48 83 c4 10          	add    $0x10,%rsp
    1bb3:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    1bba:	8b 8b 00 02 00 00    	mov    0x200(%rbx),%ecx
    1bc0:	8b 93 20 02 00 00    	mov    0x220(%rbx),%edx
    1bc6:	89 88 80 00 00 00    	mov    %ecx,0x80(%rax)
    1bcc:	89 90 84 00 00 00    	mov    %edx,0x84(%rax)
    1bd2:	8b 4b 58             	mov    0x58(%rbx),%ecx
    1bd5:	48 83 ec 08          	sub    $0x8,%rsp
    1bd9:	48 89 df             	mov    %rbx,%rdi
    1bdc:	31 f6                	xor    %esi,%esi
    1bde:	ba 03 00 00 00       	mov    $0x3,%edx
    1be3:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1be9:	45 31 c9             	xor    %r9d,%r9d
    1bec:	6a 00                	push   $0x0
    1bee:	e8 00 00 00 00       	call   1bf3 <f_8001161d0+0x1bf3>
    1bf3:	48 83 c4 10          	add    $0x10,%rsp
    1bf7:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    1bfe:	8b 8b 10 02 00 00    	mov    0x210(%rbx),%ecx
    1c04:	8b 93 30 02 00 00    	mov    0x230(%rbx),%edx
    1c0a:	89 48 78             	mov    %ecx,0x78(%rax)
    1c0d:	89 50 7c             	mov    %edx,0x7c(%rax)
    1c10:	48 8b 4b 50          	mov    0x50(%rbx),%rcx
    1c14:	8b 91 d8 03 00 00    	mov    0x3d8(%rcx),%edx
    1c1a:	8b 89 f8 03 00 00    	mov    0x3f8(%rcx),%ecx
    1c20:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
    1c24:	8b 4b 40             	mov    0x40(%rbx),%ecx
    1c27:	89 88 a0 00 00 00    	mov    %ecx,0xa0(%rax)
    1c2d:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
    1c34:	48 8b 8b c0 00 00 00 	mov    0xc0(%rbx),%rcx
    1c3b:	48 89 81 a4 00 00 00 	mov    %rax,0xa4(%rcx)
    1c42:	89 d0                	mov    %edx,%eax
    1c44:	c1 f8 1f             	sar    $0x1f,%eax
    1c47:	c4 e2 78 f2 c2       	andn   %edx,%eax,%eax
    1c4c:	85 d2                	test   %edx,%edx
    1c4e:	48 89 43 68          	mov    %rax,0x68(%rbx)
    1c52:	b9 00 00 00 00       	mov    $0x0,%ecx
    1c57:	0f 48 ca             	cmovs  %edx,%ecx
    1c5a:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    1c5e:	48 83 ec 08          	sub    $0x8,%rsp
    1c62:	48 89 df             	mov    %rbx,%rdi
    1c65:	31 f6                	xor    %esi,%esi
    1c67:	ba 01 00 00 00       	mov    $0x1,%edx
    1c6c:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1c72:	45 31 c9             	xor    %r9d,%r9d
    1c75:	6a 00                	push   $0x0
    1c77:	e8 00 00 00 00       	call   1c7c <f_8001161d0+0x1c7c>
    1c7c:	48 83 c4 10          	add    $0x10,%rsp
    1c80:	8b 43 60             	mov    0x60(%rbx),%eax
    1c83:	8b 4b 68             	mov    0x68(%rbx),%ecx
    1c86:	89 c2                	mov    %eax,%edx
    1c88:	c1 fa 1f             	sar    $0x1f,%edx
    1c8b:	c4 e2 68 f2 c0       	andn   %eax,%edx,%eax
    1c90:	48 89 43 58          	mov    %rax,0x58(%rbx)
    1c94:	48 83 ec 08          	sub    $0x8,%rsp
    1c98:	48 89 df             	mov    %rbx,%rdi
    1c9b:	31 f6                	xor    %esi,%esi
    1c9d:	31 d2                	xor    %edx,%edx
    1c9f:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1ca5:	45 31 c9             	xor    %r9d,%r9d
    1ca8:	6a 00                	push   $0x0
    1caa:	e8 00 00 00 00       	call   1caf <f_8001161d0+0x1caf>
    1caf:	48 83 c4 10          	add    $0x10,%rsp
    1cb3:	8b 4b 58             	mov    0x58(%rbx),%ecx
    1cb6:	48 83 ec 08          	sub    $0x8,%rsp
    1cba:	48 89 df             	mov    %rbx,%rdi
    1cbd:	31 f6                	xor    %esi,%esi
    1cbf:	ba 02 00 00 00       	mov    $0x2,%edx
    1cc4:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1cca:	45 31 c9             	xor    %r9d,%r9d
    1ccd:	6a 00                	push   $0x0
    1ccf:	e8 00 00 00 00       	call   1cd4 <f_8001161d0+0x1cd4>
    1cd4:	48 83 c4 10          	add    $0x10,%rsp
    1cd8:	8b 43 60             	mov    0x60(%rbx),%eax
    1cdb:	89 c1                	mov    %eax,%ecx
    1cdd:	c1 f9 1f             	sar    $0x1f,%ecx
    1ce0:	21 c1                	and    %eax,%ecx
    1ce2:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    1ce6:	48 83 ec 08          	sub    $0x8,%rsp
    1cea:	48 89 df             	mov    %rbx,%rdi
    1ced:	31 f6                	xor    %esi,%esi
    1cef:	ba 03 00 00 00       	mov    $0x3,%edx
    1cf4:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    1cfa:	45 31 c9             	xor    %r9d,%r9d
    1cfd:	6a 00                	push   $0x0
    1cff:	e8 00 00 00 00       	call   1d04 <f_8001161d0+0x1d04>
    1d04:	48 83 c4 10          	add    $0x10,%rsp
    1d08:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    1d0f:	8b 8b 00 02 00 00    	mov    0x200(%rbx),%ecx
    1d15:	8b 93 20 02 00 00    	mov    0x220(%rbx),%edx
    1d1b:	89 88 98 00 00 00    	mov    %ecx,0x98(%rax)
    1d21:	89 90 9c 00 00 00    	mov    %edx,0x9c(%rax)
    1d27:	8b 8b 10 02 00 00    	mov    0x210(%rbx),%ecx
    1d2d:	8b 93 30 02 00 00    	mov    0x230(%rbx),%edx
    1d33:	89 88 90 00 00 00    	mov    %ecx,0x90(%rax)
    1d39:	89 90 94 00 00 00    	mov    %edx,0x94(%rax)
    1d3f:	48 8b 4b 50          	mov    0x50(%rbx),%rcx
    1d43:	31 d2                	xor    %edx,%edx
    1d45:	80 b9 58 04 00 00 00 	cmpb   $0x0,0x458(%rcx)
    1d4c:	48 c7 43 50 5b 00 00 	movq   $0x5b,0x50(%rbx)
    1d53:	00 
    1d54:	48 c7 80 b0 00 00 00 	movq   $0x0,0xb0(%rax)
    1d5b:	00 00 00 00 
    1d5f:	8b 4b 48             	mov    0x48(%rbx),%ecx
    1d62:	89 88 bc 00 00 00    	mov    %ecx,0xbc(%rax)
    1d68:	0f 94 c2             	sete   %dl
    1d6b:	48 8d 0c 55 59 00 00 	lea    0x59(,%rdx,2),%rcx
    1d72:	00 
    1d73:	c1 e2 1e             	shl    $0x1e,%edx
    1d76:	48 81 ca 00 00 00 20 	or     $0x20000000,%rdx
    1d7d:	48 89 93 10 01 00 00 	mov    %rdx,0x110(%rbx)
    1d84:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    1d88:	e9 1e 10 00 00       	jmp    2dab <f_8001161d0+0x2dab>
    1d8d:	4c 89 ab 08 01 00 00 	mov    %r13,0x108(%rbx)
    1d94:	48 89 df             	mov    %rbx,%rdi
    1d97:	48 83 c4 18          	add    $0x18,%rsp
    1d9b:	5b                   	pop    %rbx
    1d9c:	41 5c                	pop    %r12
    1d9e:	41 5d                	pop    %r13
    1da0:	41 5e                	pop    %r14
    1da2:	41 5f                	pop    %r15
    1da4:	5d                   	pop    %rbp
    1da5:	c5 f8 77             	vzeroupper
    1da8:	e9 00 00 00 00       	jmp    1dad <f_8001161d0+0x1dad>
    1dad:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    1db4:	00 
    1db5:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1dbc:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    1dc3:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    1dc7:	48 89 43 10          	mov    %rax,0x10(%rbx)
    1dcb:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1dd0:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    1dd7:	48 89 03             	mov    %rax,(%rbx)
    1dda:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
    1de1:	00 
    1de2:	48 8d 85 ae 18 51 fd 	lea    -0x2aee752(%rbp),%rax
    1de9:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    1df0:	48 89 df             	mov    %rbx,%rdi
    1df3:	c5 f8 77             	vzeroupper
    1df6:	e8 00 00 00 00       	call   1dfb <f_8001161d0+0x1dfb>
    1dfb:	e9 b1 0f 00 00       	jmp    2db1 <f_8001161d0+0x2db1>
    1e00:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    1e07:	00 
    1e08:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1e0f:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    1e16:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    1e1a:	48 89 43 10          	mov    %rax,0x10(%rbx)
    1e1e:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1e23:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    1e2a:	48 89 03             	mov    %rax,(%rbx)
    1e2d:	48 8d 85 ce 18 51 fd 	lea    -0x2aee732(%rbp),%rax
    1e34:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    1e3b:	48 89 df             	mov    %rbx,%rdi
    1e3e:	c5 f8 77             	vzeroupper
    1e41:	e8 00 00 00 00       	call   1e46 <f_8001161d0+0x1e46>
    1e46:	e9 66 0f 00 00       	jmp    2db1 <f_8001161d0+0x2db1>
    1e4b:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
    1e52:	48 8b 89 c8 1e 00 00 	mov    0x1ec8(%rcx),%rcx
    1e59:	48 89 4b 70          	mov    %rcx,0x70(%rbx)
    1e5d:	48 bf 00 00 00 00 01 	movabs $0x100000000,%rdi
    1e64:	00 00 00 
    1e67:	48 89 3b             	mov    %rdi,(%rbx)
    1e6a:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1e6e:	4c 8b 83 00 01 00 00 	mov    0x100(%rbx),%r8
    1e75:	49 c7 00 04 00 00 00 	movq   $0x4,(%r8)
    1e7c:	48 be 00 00 00 00 00 	movabs $0x40000000000000,%rsi
    1e83:	00 40 00 
    1e86:	48 ff c6             	inc    %rsi
    1e89:	49 89 70 08          	mov    %rsi,0x8(%r8)
    1e8d:	49 89 78 20          	mov    %rdi,0x20(%r8)
    1e91:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    1e98:	ff ff ff 
    1e9b:	49 89 78 28          	mov    %rdi,0x28(%r8)
    1e9f:	4c 8d 8d 25 74 0d 00 	lea    0xd7425(%rbp),%r9
    1ea6:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    1eaa:	49 bb ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r11
    1eb1:	ff 7f ff 
    1eb4:	4d 89 98 80 00 00 00 	mov    %r11,0x80(%r8)
    1ebb:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    1ec0:	49 89 b0 88 00 00 00 	mov    %rsi,0x88(%r8)
    1ec7:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    1ece:	4c 8b 14 24          	mov    (%rsp),%r10
    1ed2:	4c 89 96 a4 00 00 00 	mov    %r10,0xa4(%rsi)
    1ed9:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
    1ee0:	ff 7f 7f 
    1ee3:	4d 89 90 90 00 00 00 	mov    %r10,0x90(%r8)
    1eea:	4d 89 98 98 00 00 00 	mov    %r11,0x98(%r8)
    1ef1:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 1ef9 <f_8001161d0+0x1ef9>
    1ef8:	00 
    1ef9:	c5 fc 11 43 78       	vmovups %ymm0,0x78(%rbx)
    1efe:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1f05:	00 
    1f06:	45 89 b0 a0 00 00 00 	mov    %r14d,0xa0(%r8)
    1f0d:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1f14:	0f b6 70 08          	movzbl 0x8(%rax),%esi
    1f18:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    1f1c:	41 c7 80 bc 00 00 00 	movl   $0x3,0xbc(%r8)
    1f23:	03 00 00 00 
    1f27:	49 c7 40 10 ff ff 00 	movq   $0xffff,0x10(%r8)
    1f2e:	00 
    1f2f:	48 8d 47 17          	lea    0x17(%rdi),%rax
    1f33:	49 89 40 18          	mov    %rax,0x18(%r8)
    1f37:	49 c7 40 68 00 00 00 	movq   $0x0,0x68(%r8)
    1f3e:	00 
    1f3f:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    1f44:	49 89 40 30          	mov    %rax,0x30(%r8)
    1f48:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    1f4f:	00 80 3f 
    1f52:	49 89 40 38          	mov    %rax,0x38(%r8)
    1f56:	49 89 40 40          	mov    %rax,0x40(%r8)
    1f5a:	49 c7 40 48 00 00 00 	movq   $0x0,0x48(%r8)
    1f61:	00 
    1f62:	49 89 50 50          	mov    %rdx,0x50(%r8)
    1f66:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1f6a:	c4 c1 78 11 40 58    	vmovups %xmm0,0x58(%r8)
    1f70:	4d 89 48 70          	mov    %r9,0x70(%r8)
    1f74:	4d 89 50 78          	mov    %r10,0x78(%r8)
    1f78:	48 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rax
    1f7f:	45 31 c0             	xor    %r8d,%r8d
    1f82:	39 71 08             	cmp    %esi,0x8(%rcx)
    1f85:	49 0f 46 c0          	cmovbe %r8,%rax
    1f89:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    1f8d:	48 8b 94 08 68 33 00 	mov    0x3368(%rax,%rcx,1),%rdx
    1f94:	00 
    1f95:	48 89 53 60          	mov    %rdx,0x60(%rbx)
    1f99:	48 8b 84 08 60 33 00 	mov    0x3360(%rax,%rcx,1),%rax
    1fa0:	00 
    1fa1:	48 8b 4b 48          	mov    0x48(%rbx),%rcx
    1fa5:	48 89 01             	mov    %rax,(%rcx)
    1fa8:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    1fac:	48 8b 43 70          	mov    0x70(%rbx),%rax
    1fb0:	44 8b 48 08          	mov    0x8(%rax),%r9d
    1fb4:	48 8b 48 10          	mov    0x10(%rax),%rcx
    1fb8:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    1fbc:	8b 53 40             	mov    0x40(%rbx),%edx
    1fbf:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
    1fc6:	45 31 d2             	xor    %r10d,%r10d
    1fc9:	31 ff                	xor    %edi,%edi
    1fcb:	45 89 cb             	mov    %r9d,%r11d
    1fce:	41 29 f3             	sub    %esi,%r11d
    1fd1:	49 0f 46 d0          	cmovbe %r8,%rdx
    1fd5:	41 0f 94 c2          	sete   %r10b
    1fd9:	40 0f 93 c7          	setae  %dil
    1fdd:	41 c1 e2 1e          	shl    $0x1e,%r10d
    1fe1:	c1 e7 1d             	shl    $0x1d,%edi
    1fe4:	44 09 d7             	or     %r10d,%edi
    1fe7:	c4 c2 20 f2 f1       	andn   %r9d,%r11d,%esi
    1fec:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    1ff3:	44 09 df             	or     %r11d,%edi
    1ff6:	c1 ee 03             	shr    $0x3,%esi
    1ff9:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    1fff:	09 fe                	or     %edi,%esi
    2001:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    2008:	48 8b b4 0a e8 35 00 	mov    0x35e8(%rdx,%rcx,1),%rsi
    200f:	00 
    2010:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    2014:	48 8b bc 0a e0 35 00 	mov    0x35e0(%rdx,%rcx,1),%rdi
    201b:	00 
    201c:	48 89 7b 50          	mov    %rdi,0x50(%rbx)
    2020:	4c 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%r8
    2027:	49 89 38             	mov    %rdi,(%r8)
    202a:	49 89 70 08          	mov    %rsi,0x8(%r8)
    202e:	8b b4 0a f8 35 00 00 	mov    0x35f8(%rdx,%rcx,1),%esi
    2035:	48 8b 8c 0a f0 35 00 	mov    0x35f0(%rdx,%rcx,1),%rcx
    203c:	00 
    203d:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
    2044:	48 89 0a             	mov    %rcx,(%rdx)
    2047:	89 72 08             	mov    %esi,0x8(%rdx)
    204a:	8b 48 44             	mov    0x44(%rax),%ecx
    204d:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    2051:	48 83 c0 3c          	add    $0x3c,%rax
    2055:	8b 00                	mov    (%rax),%eax
    2057:	48 89 43 48          	mov    %rax,0x48(%rbx)
    205b:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    2062:	88 8a b0 00 00 00    	mov    %cl,0xb0(%rdx)
    2068:	c7 82 b4 00 00 00 00 	movl   $0x0,0xb4(%rdx)
    206f:	00 00 00 
    2072:	48 8b 8b c0 00 00 00 	mov    0xc0(%rbx),%rcx
    2079:	c7 81 b1 00 00 00 00 	movl   $0x0,0xb1(%rcx)
    2080:	00 00 00 
    2083:	88 82 b8 00 00 00    	mov    %al,0xb8(%rdx)
    2089:	e9 23 0d 00 00       	jmp    2db1 <f_8001161d0+0x2db1>
    208e:	4d 89 d4             	mov    %r10,%r12
    2091:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    2098:	00 
    2099:	48 c7 80 d0 fe ff ff 	movq   $0x100,-0x130(%rax)
    20a0:	00 01 00 00 
    20a4:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    20ab:	00 40 00 
    20ae:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    20b5:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    20bc:	ff ff 00 00 
    20c0:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    20c7:	ff ff ff 
    20ca:	48 8d 4f 13          	lea    0x13(%rdi),%rcx
    20ce:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    20d5:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    20dc:	00 00 00 
    20df:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
    20e3:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    20ea:	48 89 b8 f8 fe ff ff 	mov    %rdi,-0x108(%rax)
    20f1:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    20f8:	00 80 3f 
    20fb:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    20ff:	48 8d 88 00 ff ff ff 	lea    -0x100(%rax),%rcx
    2106:	4c 8d 98 08 ff ff ff 	lea    -0xf8(%rax),%r11
    210d:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    2114:	00 00 00 
    2117:	4c 8d 87 a1 6f fe ff 	lea    -0x1905f(%rdi),%r8
    211e:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    2124:	e9 be 0a 00 00       	jmp    2be7 <f_8001161d0+0x2be7>
    2129:	48 c7 43 68 00 10 00 	movq   $0x1000,0x68(%rbx)
    2130:	00 
    2131:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    2138:	00 
    2139:	48 c7 80 d0 fe ff ff 	movq   $0x1000,-0x130(%rax)
    2140:	00 10 00 00 
    2144:	48 c7 80 d8 fe ff ff 	movq   $0x1,-0x128(%rax)
    214b:	01 00 00 00 
    214f:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    2156:	ff ff 00 00 
    215a:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    2161:	ff ff ff 
    2164:	48 8d 4e 0c          	lea    0xc(%rsi),%rcx
    2168:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    216f:	49 bc 00 00 00 00 01 	movabs $0x100000000,%r12
    2176:	00 00 00 
    2179:	4c 89 a0 f0 fe ff ff 	mov    %r12,-0x110(%rax)
    2180:	48 89 b0 f8 fe ff ff 	mov    %rsi,-0x108(%rax)
    2187:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    218e:	00 80 3f 
    2191:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    2195:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
    219a:	48 89 88 00 ff ff ff 	mov    %rcx,-0x100(%rax)
    21a1:	4c 89 b8 08 ff ff ff 	mov    %r15,-0xf8(%rax)
    21a8:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    21af:	4c 8d 9d b2 a4 03 00 	lea    0x3a4b2(%rbp),%r11
    21b6:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    21bd:	4c 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%r8
    21c4:	4d 8b 88 d0 2f 00 00 	mov    0x2fd0(%r8),%r9
    21cb:	4c 89 4b 40          	mov    %r9,0x40(%rbx)
    21cf:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    21d4:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    21d8:	4c 89 59 70          	mov    %r11,0x70(%rcx)
    21dc:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
    21e3:	ff 7f 7f 
    21e6:	4c 89 59 78          	mov    %r11,0x78(%rcx)
    21ea:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    21f1:	ff 7f ff 
    21f4:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    21f8:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    21fc:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2203:	00 
    2204:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    220b:	00 00 00 
    220e:	48 89 b9 80 00 00 00 	mov    %rdi,0x80(%rcx)
    2215:	4c 89 91 88 00 00 00 	mov    %r10,0x88(%rcx)
    221c:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    2223:	4c 8b 14 24          	mov    (%rsp),%r10
    2227:	4c 89 96 a4 00 00 00 	mov    %r10,0xa4(%rsi)
    222e:	4c 89 79 40          	mov    %r15,0x40(%rcx)
    2232:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    2239:	00 
    223a:	4c 89 99 90 00 00 00 	mov    %r11,0x90(%rcx)
    2241:	48 89 b9 98 00 00 00 	mov    %rdi,0x98(%rcx)
    2248:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    224f:	00 
    2250:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    2254:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2258:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    225d:	4d 85 c9             	test   %r9,%r9
    2260:	0f 84 e8 0f 00 00    	je     324e <f_8001161d0+0x324e>
    2266:	48 8b 93 98 00 00 00 	mov    0x98(%rbx),%rdx
    226d:	0f b6 72 08          	movzbl 0x8(%rdx),%esi
    2271:	48 c7 43 68 e0 3c 00 	movq   $0x3ce0,0x68(%rbx)
    2278:	00 
    2279:	48 69 fe 60 0f 00 00 	imul   $0xf60,%rsi,%rdi
    2280:	31 d2                	xor    %edx,%edx
    2282:	41 39 71 10          	cmp    %esi,0x10(%r9)
    2286:	4d 8b 49 18          	mov    0x18(%r9),%r9
    228a:	48 0f 46 fa          	cmovbe %rdx,%rdi
    228e:	42 8b bc 0f 9c 02 00 	mov    0x29c(%rdi,%r9,1),%edi
    2295:	00 
    2296:	4c 09 e7             	or     %r12,%rdi
    2299:	48 89 79 1c          	mov    %rdi,0x1c(%rcx)
    229d:	c7 81 bc 00 00 00 02 	movl   $0x2,0xbc(%rcx)
    22a4:	00 00 00 
    22a7:	49 8b 88 c8 1e 00 00 	mov    0x1ec8(%r8),%rcx
    22ae:	48 69 fe e0 3c 00 00 	imul   $0x3ce0,%rsi,%rdi
    22b5:	39 71 08             	cmp    %esi,0x8(%rcx)
    22b8:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    22be:	4c 0f 47 c7          	cmova  %rdi,%r8
    22c2:	4c 8b 49 10          	mov    0x10(%rcx),%r9
    22c6:	4f 8b 94 01 b8 30 00 	mov    0x30b8(%r9,%r8,1),%r10
    22cd:	00 
    22ce:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    22d2:	4f 8b 84 01 b0 30 00 	mov    0x30b0(%r9,%r8,1),%r8
    22d9:	00 
    22da:	4c 89 43 58          	mov    %r8,0x58(%rbx)
    22de:	4c 89 80 48 ff ff ff 	mov    %r8,-0xb8(%rax)
    22e5:	4c 89 90 50 ff ff ff 	mov    %r10,-0xb0(%rax)
    22ec:	44 8b 41 08          	mov    0x8(%rcx),%r8d
    22f0:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    22f4:	45 31 c9             	xor    %r9d,%r9d
    22f7:	45 31 d2             	xor    %r10d,%r10d
    22fa:	45 89 c3             	mov    %r8d,%r11d
    22fd:	41 29 f3             	sub    %esi,%r11d
    2300:	48 0f 47 d7          	cmova  %rdi,%rdx
    2304:	41 0f 94 c1          	sete   %r9b
    2308:	41 0f 93 c2          	setae  %r10b
    230c:	c4 c2 20 f2 f0       	andn   %r8d,%r11d,%esi
    2311:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    2318:	41 c1 e1 1e          	shl    $0x1e,%r9d
    231c:	41 c1 e2 1d          	shl    $0x1d,%r10d
    2320:	45 09 ca             	or     %r9d,%r10d
    2323:	45 09 da             	or     %r11d,%r10d
    2326:	c1 ee 03             	shr    $0x3,%esi
    2329:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    232f:	44 09 d6             	or     %r10d,%esi
    2332:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    2339:	48 8d 34 0a          	lea    (%rdx,%rcx,1),%rsi
    233d:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    2341:	48 8b b4 0a 30 33 00 	mov    0x3330(%rdx,%rcx,1),%rsi
    2348:	00 
    2349:	48 8b bc 0a 38 33 00 	mov    0x3338(%rdx,%rcx,1),%rdi
    2350:	00 
    2351:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    2355:	48 89 b0 60 ff ff ff 	mov    %rsi,-0xa0(%rax)
    235c:	48 89 b8 68 ff ff ff 	mov    %rdi,-0x98(%rax)
    2363:	8b b4 0a 48 33 00 00 	mov    0x3348(%rdx,%rcx,1),%esi
    236a:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    236e:	48 8b 8c 0a 40 33 00 	mov    0x3340(%rdx,%rcx,1),%rcx
    2375:	00 
    2376:	48 89 88 70 ff ff ff 	mov    %rcx,-0x90(%rax)
    237d:	89 b0 78 ff ff ff    	mov    %esi,-0x88(%rax)
    2383:	e9 29 0a 00 00       	jmp    2db1 <f_8001161d0+0x2db1>
    2388:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    238f:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
    2396:	48 8b b6 c8 1e 00 00 	mov    0x1ec8(%rsi),%rsi
    239d:	48 89 73 08          	mov    %rsi,0x8(%rbx)
    23a1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    23a6:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
    23aa:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
    23ae:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
    23b2:	44 8b 46 08          	mov    0x8(%rsi),%r8d
    23b6:	4c 69 c9 e0 3c 00 00 	imul   $0x3ce0,%rcx,%r9
    23bd:	45 31 db             	xor    %r11d,%r11d
    23c0:	41 39 c8             	cmp    %ecx,%r8d
    23c3:	4d 0f 47 d9          	cmova  %r9,%r11
    23c7:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    23cb:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
    23d2:	00 
    23d3:	49 8b 8c 0b 40 3c 00 	mov    0x3c40(%r11,%rcx,1),%rcx
    23da:	00 
    23db:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
    23e2:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    23e9:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    23f0:	48 89 b9 88 00 00 00 	mov    %rdi,0x88(%rcx)
    23f7:	48 be ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rsi
    23fe:	ff 7f 7f 
    2401:	48 89 b1 90 00 00 00 	mov    %rsi,0x90(%rcx)
    2408:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    240f:	00 
    2410:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2414:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    241b:	00 00 00 
    241e:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    2425:	00 
    2426:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    242a:	48 c7 43 40 06 00 00 	movq   $0x6,0x40(%rbx)
    2431:	00 
    2432:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2436:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    243b:	48 c7 41 30 06 00 00 	movq   $0x6,0x30(%rcx)
    2442:	00 
    2443:	48 b8 10 00 00 00 03 	movabs $0x300000010,%rax
    244a:	00 00 00 
    244d:	48 83 c0 10          	add    $0x10,%rax
    2451:	48 89 01             	mov    %rax,(%rcx)
    2454:	48 b8 00 00 00 00 01 	movabs $0x40000100000000,%rax
    245b:	00 40 00 
    245e:	48 89 41 08          	mov    %rax,0x8(%rcx)
    2462:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    2469:	00 
    246a:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    2471:	ff ff ff 
    2474:	48 8d 42 09          	lea    0x9(%rdx),%rax
    2478:	48 89 41 18          	mov    %rax,0x18(%rcx)
    247c:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2483:	00 00 00 
    2486:	48 89 41 20          	mov    %rax,0x20(%rcx)
    248a:	48 89 51 28          	mov    %rdx,0x28(%rcx)
    248e:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2495:	48 8b 14 24          	mov    (%rsp),%rdx
    2499:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
    24a0:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    24a7:	00 80 3f 
    24aa:	48 89 41 38          	mov    %rax,0x38(%rcx)
    24ae:	48 89 41 40          	mov    %rax,0x40(%rcx)
    24b2:	49 be ca 5d c0 02 08 	movabs $0x802c05dca,%r14
    24b9:	00 00 00 
    24bc:	49 8d 86 af c7 07 00 	lea    0x7c7af(%r14),%rax
    24c3:	48 89 43 78          	mov    %rax,0x78(%rbx)
    24c7:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
    24ce:	ff 7f ff 
    24d1:	48 89 b3 80 00 00 00 	mov    %rsi,0x80(%rbx)
    24d8:	48 89 b1 98 00 00 00 	mov    %rsi,0x98(%rcx)
    24df:	48 8b 53 58          	mov    0x58(%rbx),%rdx
    24e3:	48 89 51 78          	mov    %rdx,0x78(%rcx)
    24e7:	48 89 b1 80 00 00 00 	mov    %rsi,0x80(%rcx)
    24ee:	48 8d 53 70          	lea    0x70(%rbx),%rdx
    24f2:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    24f9:	00 
    24fa:	48 89 41 70          	mov    %rax,0x70(%rcx)
    24fe:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
    2502:	8b 71 08             	mov    0x8(%rcx),%esi
    2505:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
    2509:	41 89 f8             	mov    %edi,%r8d
    250c:	31 c0                	xor    %eax,%eax
    250e:	39 fe                	cmp    %edi,%esi
    2510:	be 00 00 00 00       	mov    $0x0,%esi
    2515:	49 0f 47 f0          	cmova  %r8,%rsi
    2519:	4c 8b 4b 48          	mov    0x48(%rbx),%r9
    251d:	4c 8b 51 10          	mov    0x10(%rcx),%r10
    2521:	8b 12                	mov    (%rdx),%edx
    2523:	48 0f af f2          	imul   %rdx,%rsi
    2527:	c4 a1 78 10 84 16 00 	vmovups 0x2e00(%rsi,%r10,1),%xmm0
    252e:	2e 00 00 
    2531:	c4 c1 78 11 01       	vmovups %xmm0,(%r9)
    2536:	8b 71 08             	mov    0x8(%rcx),%esi
    2539:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    253d:	45 31 c9             	xor    %r9d,%r9d
    2540:	41 89 f2             	mov    %esi,%r10d
    2543:	41 31 fa             	xor    %edi,%r10d
    2546:	41 0f 94 c1          	sete   %r9b
    254a:	45 31 db             	xor    %r11d,%r11d
    254d:	89 f5                	mov    %esi,%ebp
    254f:	29 fd                	sub    %edi,%ebp
    2551:	41 0f 93 c3          	setae  %r11b
    2555:	49 0f 47 c0          	cmova  %r8,%rax
    2559:	31 ee                	xor    %ebp,%esi
    255b:	44 21 d6             	and    %r10d,%esi
    255e:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    2564:	41 c1 e1 1e          	shl    $0x1e,%r9d
    2568:	41 c1 e3 1d          	shl    $0x1d,%r11d
    256c:	45 09 cb             	or     %r9d,%r11d
    256f:	41 09 eb             	or     %ebp,%r11d
    2572:	c1 ee 03             	shr    $0x3,%esi
    2575:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    257b:	44 09 de             	or     %r11d,%esi
    257e:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    2585:	48 0f af c2          	imul   %rdx,%rax
    2589:	48 8b 94 08 80 30 00 	mov    0x3080(%rax,%rcx,1),%rdx
    2590:	00 
    2591:	48 8b b3 b0 00 00 00 	mov    0xb0(%rbx),%rsi
    2598:	48 8b bb d0 00 00 00 	mov    0xd0(%rbx),%rdi
    259f:	48 89 33             	mov    %rsi,(%rbx)
    25a2:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
    25a9:	00 
    25aa:	48 8b b4 08 88 30 00 	mov    0x3088(%rax,%rcx,1),%rsi
    25b1:	00 
    25b2:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    25b6:	48 89 17             	mov    %rdx,(%rdi)
    25b9:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    25bd:	48 8b 94 08 90 30 00 	mov    0x3090(%rax,%rcx,1),%rdx
    25c4:	00 
    25c5:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    25c9:	8b 84 08 98 30 00 00 	mov    0x3098(%rax,%rcx,1),%eax
    25d0:	48 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%rcx
    25d7:	89 41 08             	mov    %eax,0x8(%rcx)
    25da:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    25e1:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    25e5:	48 89 43 40          	mov    %rax,0x40(%rbx)
    25e9:	48 89 11             	mov    %rdx,(%rcx)
    25ec:	49 8d 86 ea 0b 51 fd 	lea    -0x2aef416(%r14),%rax
    25f3:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    25fa:	48 89 df             	mov    %rbx,%rdi
    25fd:	c5 f8 77             	vzeroupper
    2600:	e8 00 00 00 00       	call   2605 <f_8001161d0+0x2605>
    2605:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    260c:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    2613:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    261a:	48 89 01             	mov    %rax,(%rcx)
    261d:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
    2624:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
    262b:	48 8b b0 04 16 00 00 	mov    0x1604(%rax),%rsi
    2632:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
    2636:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    263a:	88 51 08             	mov    %dl,0x8(%rcx)
    263d:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    2644:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
    2648:	8b 80 0c 16 00 00    	mov    0x160c(%rax),%eax
    264e:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2652:	4c 89 f5             	mov    %r14,%rbp
    2655:	48 c7 43 48 02 00 00 	movq   $0x2,0x48(%rbx)
    265c:	00 
    265d:	89 41 24             	mov    %eax,0x24(%rcx)
    2660:	c7 81 bc 00 00 00 02 	movl   $0x2,0xbc(%rcx)
    2667:	00 00 00 
    266a:	e9 42 07 00 00       	jmp    2db1 <f_8001161d0+0x2db1>
    266f:	4d 89 d4             	mov    %r10,%r12
    2672:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    2679:	00 
    267a:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
    2681:	49 c7 03 80 00 00 00 	movq   $0x80,(%r11)
    2688:	48 b9 00 00 00 00 00 	movabs $0x60000000000000,%rcx
    268f:	00 60 00 
    2692:	49 89 4b 08          	mov    %rcx,0x8(%r11)
    2696:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
    269d:	00 
    269e:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    26a5:	ff ff ff 
    26a8:	48 8d 4f 12          	lea    0x12(%rdi),%rcx
    26ac:	49 89 4b 18          	mov    %rcx,0x18(%r11)
    26b0:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    26b7:	00 00 00 
    26ba:	49 89 4b 20          	mov    %rcx,0x20(%r11)
    26be:	49 89 7b 28          	mov    %rdi,0x28(%r11)
    26c2:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    26c8:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    26cc:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    26d3:	00 80 3f 
    26d6:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    26da:	49 8d 4b 30          	lea    0x30(%r11),%rcx
    26de:	49 83 c3 38          	add    $0x38,%r11
    26e2:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    26e9:	00 00 00 
    26ec:	4c 8d 87 6d 4f 0a 00 	lea    0xa4f6d(%rdi),%r8
    26f3:	e9 ef 04 00 00       	jmp    2be7 <f_8001161d0+0x2be7>
    26f8:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    26ff:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
    2706:	48 8b b6 c8 1e 00 00 	mov    0x1ec8(%rsi),%rsi
    270d:	48 89 73 08          	mov    %rsi,0x8(%rbx)
    2711:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    2716:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
    271a:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
    2721:	00 
    2722:	44 0f b6 41 08       	movzbl 0x8(%rcx),%r8d
    2727:	4c 89 43 68          	mov    %r8,0x68(%rbx)
    272b:	44 8b 4e 08          	mov    0x8(%rsi),%r9d
    272f:	4d 69 d8 e0 3c 00 00 	imul   $0x3ce0,%r8,%r11
    2736:	31 c9                	xor    %ecx,%ecx
    2738:	45 39 c1             	cmp    %r8d,%r9d
    273b:	48 8b 76 10          	mov    0x10(%rsi),%rsi
    273f:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
    2746:	00 
    2747:	4c 0f 46 d9          	cmovbe %rcx,%r11
    274b:	49 8b b4 33 40 3c 00 	mov    0x3c40(%r11,%rsi,1),%rsi
    2752:	00 
    2753:	48 89 33             	mov    %rsi,(%rbx)
    2756:	4c 8b 83 00 01 00 00 	mov    0x100(%rbx),%r8
    275d:	45 89 b0 a0 00 00 00 	mov    %r14d,0xa0(%r8)
    2764:	49 89 b8 88 00 00 00 	mov    %rdi,0x88(%r8)
    276b:	48 be ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rsi
    2772:	ff 7f 7f 
    2775:	49 89 b0 90 00 00 00 	mov    %rsi,0x90(%r8)
    277c:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2783:	00 
    2784:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2788:	41 c7 80 bc 00 00 00 	movl   $0x0,0xbc(%r8)
    278f:	00 00 00 00 
    2793:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2797:	c4 c1 78 11 40 58    	vmovups %xmm0,0x58(%r8)
    279d:	49 c7 00 20 00 00 00 	movq   $0x20,(%r8)
    27a4:	48 b8 00 00 00 00 00 	movabs $0x42080000000000,%rax
    27ab:	08 42 00 
    27ae:	49 89 40 08          	mov    %rax,0x8(%r8)
    27b2:	49 c7 40 48 00 00 00 	movq   $0x0,0x48(%r8)
    27b9:	00 
    27ba:	49 89 50 50          	mov    %rdx,0x50(%r8)
    27be:	49 c7 40 30 07 00 00 	movq   $0x7,0x30(%r8)
    27c5:	00 
    27c6:	49 c7 40 10 ff ff 00 	movq   $0xffff,0x10(%r8)
    27cd:	00 
    27ce:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    27d5:	ff ff ff 
    27d8:	48 8d 42 0a          	lea    0xa(%rdx),%rax
    27dc:	49 89 40 18          	mov    %rax,0x18(%r8)
    27e0:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    27e7:	00 00 00 
    27ea:	49 89 40 20          	mov    %rax,0x20(%r8)
    27ee:	49 89 50 28          	mov    %rdx,0x28(%r8)
    27f2:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    27f9:	48 8b 14 24          	mov    (%rsp),%rdx
    27fd:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
    2804:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    280b:	00 80 3f 
    280e:	49 89 40 38          	mov    %rax,0x38(%r8)
    2812:	49 89 40 40          	mov    %rax,0x40(%r8)
    2816:	49 be ca 5d c0 02 08 	movabs $0x802c05dca,%r14
    281d:	00 00 00 
    2820:	49 8d 86 c5 e4 0b 00 	lea    0xbe4c5(%r14),%rax
    2827:	48 89 43 78          	mov    %rax,0x78(%rbx)
    282b:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
    2832:	ff 7f ff 
    2835:	48 89 b3 80 00 00 00 	mov    %rsi,0x80(%rbx)
    283c:	49 89 b0 98 00 00 00 	mov    %rsi,0x98(%r8)
    2843:	48 8b 53 58          	mov    0x58(%rbx),%rdx
    2847:	49 89 50 78          	mov    %rdx,0x78(%r8)
    284b:	49 89 b0 80 00 00 00 	mov    %rsi,0x80(%r8)
    2852:	49 c7 40 68 00 00 00 	movq   $0x0,0x68(%r8)
    2859:	00 
    285a:	49 89 40 70          	mov    %rax,0x70(%r8)
    285e:	48 8b 43 08          	mov    0x8(%rbx),%rax
    2862:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
    2866:	41 89 f8             	mov    %edi,%r8d
    2869:	39 78 08             	cmp    %edi,0x8(%rax)
    286c:	be 00 00 00 00       	mov    $0x0,%esi
    2871:	49 0f 47 f0          	cmova  %r8,%rsi
    2875:	4c 8b 4b 48          	mov    0x48(%rbx),%r9
    2879:	4c 8b 50 10          	mov    0x10(%rax),%r10
    287d:	8b 53 70             	mov    0x70(%rbx),%edx
    2880:	48 0f af f2          	imul   %rdx,%rsi
    2884:	c4 a1 78 10 84 16 b0 	vmovups 0x30b0(%rsi,%r10,1),%xmm0
    288b:	30 00 00 
    288e:	c4 c1 78 11 01       	vmovups %xmm0,(%r9)
    2893:	8b 70 08             	mov    0x8(%rax),%esi
    2896:	45 31 c9             	xor    %r9d,%r9d
    2899:	41 89 f2             	mov    %esi,%r10d
    289c:	41 31 fa             	xor    %edi,%r10d
    289f:	41 0f 94 c1          	sete   %r9b
    28a3:	45 31 db             	xor    %r11d,%r11d
    28a6:	89 f5                	mov    %esi,%ebp
    28a8:	29 fd                	sub    %edi,%ebp
    28aa:	49 0f 47 c8          	cmova  %r8,%rcx
    28ae:	41 0f 93 c3          	setae  %r11b
    28b2:	31 ee                	xor    %ebp,%esi
    28b4:	44 21 d6             	and    %r10d,%esi
    28b7:	41 c1 e1 1e          	shl    $0x1e,%r9d
    28bb:	41 c1 e3 1d          	shl    $0x1d,%r11d
    28bf:	45 09 cb             	or     %r9d,%r11d
    28c2:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    28c8:	41 09 eb             	or     %ebp,%r11d
    28cb:	4c 89 f5             	mov    %r14,%rbp
    28ce:	48 8b 40 10          	mov    0x10(%rax),%rax
    28d2:	c1 ee 03             	shr    $0x3,%esi
    28d5:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    28db:	44 09 de             	or     %r11d,%esi
    28de:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    28e5:	48 0f af ca          	imul   %rdx,%rcx
    28e9:	48 8b 94 01 30 33 00 	mov    0x3330(%rcx,%rax,1),%rdx
    28f0:	00 
    28f1:	48 8b b4 01 38 33 00 	mov    0x3338(%rcx,%rax,1),%rsi
    28f8:	00 
    28f9:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    28fd:	48 8b bb d0 00 00 00 	mov    0xd0(%rbx),%rdi
    2904:	48 89 17             	mov    %rdx,(%rdi)
    2907:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    290b:	48 8b 94 01 40 33 00 	mov    0x3340(%rcx,%rax,1),%rdx
    2912:	00 
    2913:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    2917:	8b 84 01 48 33 00 00 	mov    0x3348(%rcx,%rax,1),%eax
    291e:	48 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%rcx
    2925:	89 41 08             	mov    %eax,0x8(%rcx)
    2928:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    292f:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    2933:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2937:	48 89 11             	mov    %rdx,(%rcx)
    293a:	49 8d 86 72 0d 51 fd 	lea    -0x2aef28e(%r14),%rax
    2941:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    2948:	48 89 df             	mov    %rbx,%rdi
    294b:	c5 f8 77             	vzeroupper
    294e:	e8 00 00 00 00       	call   2953 <f_8001161d0+0x2953>
    2953:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    295a:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    2961:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    2968:	48 89 01             	mov    %rax,(%rcx)
    296b:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    2972:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    2976:	48 89 43 40          	mov    %rax,0x40(%rbx)
    297a:	88 41 08             	mov    %al,0x8(%rcx)
    297d:	b9 bc 00 00 00       	mov    $0xbc,%ecx
    2982:	48 03 8b 00 01 00 00 	add    0x100(%rbx),%rcx
    2989:	e9 c7 08 00 00       	jmp    3255 <f_8001161d0+0x3255>
    298e:	4d 89 d4             	mov    %r10,%r12
    2991:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2995:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    299c:	48 c7 01 01 00 00 00 	movq   $0x1,(%rcx)
    29a3:	49 b8 00 00 00 00 00 	movabs $0x40000000000000,%r8
    29aa:	00 40 00 
    29ad:	4c 89 41 08          	mov    %r8,0x8(%rcx)
    29b1:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    29b8:	00 
    29b9:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    29c0:	ff ff ff 
    29c3:	4c 8d 47 15          	lea    0x15(%rdi),%r8
    29c7:	4c 89 41 18          	mov    %r8,0x18(%rcx)
    29cb:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    29d2:	00 
    29d3:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    29da:	00 00 00 
    29dd:	48 89 41 20          	mov    %rax,0x20(%rcx)
    29e1:	48 89 79 28          	mov    %rdi,0x28(%rcx)
    29e5:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    29ea:	48 89 41 30          	mov    %rax,0x30(%rcx)
    29ee:	49 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r8
    29f5:	00 80 3f 
    29f8:	4c 89 41 38          	mov    %r8,0x38(%rcx)
    29fc:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    2a03:	00 00 00 
    2a06:	48 8d 80 7c 4f 0a 00 	lea    0xa4f7c(%rax),%rax
    2a0d:	48 89 41 70          	mov    %rax,0x70(%rcx)
    2a11:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
    2a18:	ff 7f 7f 
    2a1b:	4c 89 51 78          	mov    %r10,0x78(%rcx)
    2a1f:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    2a26:	ff 7f ff 
    2a29:	48 89 b9 80 00 00 00 	mov    %rdi,0x80(%rcx)
    2a30:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2a35:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    2a3c:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 2a44 <f_8001161d0+0x2a44>
    2a43:	00 
    2a44:	c5 fc 11 43 60       	vmovups %ymm0,0x60(%rbx)
    2a49:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2a50:	4c 8b 0c 24          	mov    (%rsp),%r9
    2a54:	4c 89 88 a4 00 00 00 	mov    %r9,0xa4(%rax)
    2a5b:	4c 89 41 40          	mov    %r8,0x40(%rcx)
    2a5f:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    2a66:	00 
    2a67:	4c 89 91 90 00 00 00 	mov    %r10,0x90(%rcx)
    2a6e:	48 89 b9 98 00 00 00 	mov    %rdi,0x98(%rcx)
    2a75:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    2a7c:	00 
    2a7d:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    2a81:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2a85:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    2a8a:	48 c7 43 50 03 00 00 	movq   $0x3,0x50(%rbx)
    2a91:	00 
    2a92:	b8 03 00 00 00       	mov    $0x3,%eax
    2a97:	e9 e9 01 00 00       	jmp    2c85 <f_8001161d0+0x2c85>
    2a9c:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    2aa3:	00 
    2aa4:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    2aab:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    2ab2:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    2ab6:	48 89 43 10          	mov    %rax,0x10(%rbx)
    2aba:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    2abf:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    2ac6:	48 89 03             	mov    %rax,(%rbx)
    2ac9:	48 8d 85 2e 0c 51 fd 	lea    -0x2aef3d2(%rbp),%rax
    2ad0:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    2ad7:	48 89 df             	mov    %rbx,%rdi
    2ada:	c5 f8 77             	vzeroupper
    2add:	e8 00 00 00 00       	call   2ae2 <f_8001161d0+0x2ae2>
    2ae2:	e9 ca 02 00 00       	jmp    2db1 <f_8001161d0+0x2db1>
    2ae7:	4d 89 d4             	mov    %r10,%r12
    2aea:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    2af1:	00 
    2af2:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
    2af9:	49 c7 03 03 00 00 00 	movq   $0x3,(%r11)
    2b00:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    2b07:	00 40 00 
    2b0a:	49 89 4b 08          	mov    %rcx,0x8(%r11)
    2b0e:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
    2b15:	00 
    2b16:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    2b1d:	ff ff ff 
    2b20:	48 8d 4f 0f          	lea    0xf(%rdi),%rcx
    2b24:	49 89 4b 18          	mov    %rcx,0x18(%r11)
    2b28:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2b2f:	00 00 00 
    2b32:	49 89 4b 20          	mov    %rcx,0x20(%r11)
    2b36:	49 89 7b 28          	mov    %rdi,0x28(%r11)
    2b3a:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    2b40:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    2b44:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    2b4b:	00 80 3f 
    2b4e:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    2b52:	49 8d 4b 30          	lea    0x30(%r11),%rcx
    2b56:	49 83 c3 38          	add    $0x38,%r11
    2b5a:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    2b61:	00 00 00 
    2b64:	4c 8d 87 fb b3 05 00 	lea    0x5b3fb(%rdi),%r8
    2b6b:	eb 7a                	jmp    2be7 <f_8001161d0+0x2be7>
    2b6d:	4d 89 d4             	mov    %r10,%r12
    2b70:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    2b77:	ff ff ff 
    2b7a:	48 8d 4f 0e          	lea    0xe(%rdi),%rcx
    2b7e:	48 89 4b 78          	mov    %rcx,0x78(%rbx)
    2b82:	4c 8b 9b 00 01 00 00 	mov    0x100(%rbx),%r11
    2b89:	49 c7 03 00 04 00 00 	movq   $0x400,(%r11)
    2b90:	49 c7 43 08 00 00 00 	movq   $0x0,0x8(%r11)
    2b97:	00 
    2b98:	49 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%r11)
    2b9f:	00 
    2ba0:	49 89 4b 18          	mov    %rcx,0x18(%r11)
    2ba4:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2bab:	00 00 00 
    2bae:	49 89 4b 20          	mov    %rcx,0x20(%r11)
    2bb2:	49 89 7b 28          	mov    %rdi,0x28(%r11)
    2bb6:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    2bbc:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    2bc0:	49 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r15
    2bc7:	00 80 3f 
    2bca:	4c 89 7b 70          	mov    %r15,0x70(%rbx)
    2bce:	49 8d 4b 30          	lea    0x30(%r11),%rcx
    2bd2:	49 83 c3 38          	add    $0x38,%r11
    2bd6:	48 bf ca 5d c0 02 08 	movabs $0x802c05dca,%rdi
    2bdd:	00 00 00 
    2be0:	4c 8d 87 d9 85 00 00 	lea    0x85d9(%rdi),%r8
    2be7:	4c 89 09             	mov    %r9,(%rcx)
    2bea:	4d 89 3b             	mov    %r15,(%r11)
    2bed:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    2bf4:	4c 89 41 70          	mov    %r8,0x70(%rcx)
    2bf8:	49 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r9
    2bff:	ff 7f 7f 
    2c02:	4c 89 49 78          	mov    %r9,0x78(%rcx)
    2c06:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    2c0d:	ff 7f ff 
    2c10:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    2c14:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2c18:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2c1f:	00 
    2c20:	48 89 b9 80 00 00 00 	mov    %rdi,0x80(%rcx)
    2c27:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    2c2c:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    2c33:	4c 8b 04 24          	mov    (%rsp),%r8
    2c37:	4c 89 43 60          	mov    %r8,0x60(%rbx)
    2c3b:	4c 89 79 40          	mov    %r15,0x40(%rcx)
    2c3f:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    2c46:	00 
    2c47:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2c4e:	4c 89 80 a4 00 00 00 	mov    %r8,0xa4(%rax)
    2c55:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    2c59:	48 c7 41 58 00 00 00 	movq   $0x0,0x58(%rcx)
    2c60:	00 
    2c61:	48 c7 43 50 02 00 00 	movq   $0x2,0x50(%rbx)
    2c68:	00 
    2c69:	4c 89 89 90 00 00 00 	mov    %r9,0x90(%rcx)
    2c70:	48 89 b9 98 00 00 00 	mov    %rdi,0x98(%rcx)
    2c77:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2c7b:	c5 f8 11 41 60       	vmovups %xmm0,0x60(%rcx)
    2c80:	b8 02 00 00 00       	mov    $0x2,%eax
    2c85:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    2c8c:	89 81 bc 00 00 00    	mov    %eax,0xbc(%rcx)
    2c92:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    2c99:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
    2ca0:	48 8b 80 c8 1e 00 00 	mov    0x1ec8(%rax),%rax
    2ca7:	0f b6 79 08          	movzbl 0x8(%rcx),%edi
    2cab:	4c 69 c7 e0 3c 00 00 	imul   $0x3ce0,%rdi,%r8
    2cb2:	31 c9                	xor    %ecx,%ecx
    2cb4:	39 78 08             	cmp    %edi,0x8(%rax)
    2cb7:	ba 00 00 00 00       	mov    $0x0,%edx
    2cbc:	49 0f 47 d0          	cmova  %r8,%rdx
    2cc0:	4c 8b 48 10          	mov    0x10(%rax),%r9
    2cc4:	4e 8b 94 0a 08 2e 00 	mov    0x2e08(%rdx,%r9,1),%r10
    2ccb:	00 
    2ccc:	4c 89 53 68          	mov    %r10,0x68(%rbx)
    2cd0:	4a 8b 94 0a 00 2e 00 	mov    0x2e00(%rdx,%r9,1),%rdx
    2cd7:	00 
    2cd8:	48 89 16             	mov    %rdx,(%rsi)
    2cdb:	4c 89 56 08          	mov    %r10,0x8(%rsi)
    2cdf:	44 8b 48 08          	mov    0x8(%rax),%r9d
    2ce3:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2ce7:	48 89 53 60          	mov    %rdx,0x60(%rbx)
    2ceb:	45 31 d2             	xor    %r10d,%r10d
    2cee:	45 31 db             	xor    %r11d,%r11d
    2cf1:	44 89 cd             	mov    %r9d,%ebp
    2cf4:	29 fd                	sub    %edi,%ebp
    2cf6:	49 0f 47 c8          	cmova  %r8,%rcx
    2cfa:	41 0f 94 c2          	sete   %r10b
    2cfe:	41 0f 93 c3          	setae  %r11b
    2d02:	c4 c2 50 f2 f9       	andn   %r9d,%ebp,%edi
    2d07:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    2d0d:	41 c1 e2 1e          	shl    $0x1e,%r10d
    2d11:	41 c1 e3 1d          	shl    $0x1d,%r11d
    2d15:	45 09 d3             	or     %r10d,%r11d
    2d18:	41 09 eb             	or     %ebp,%r11d
    2d1b:	c1 ef 03             	shr    $0x3,%edi
    2d1e:	81 e7 00 00 00 10    	and    $0x10000000,%edi
    2d24:	44 09 df             	or     %r11d,%edi
    2d27:	48 89 bb 10 01 00 00 	mov    %rdi,0x110(%rbx)
    2d2e:	48 8b bc 0a 80 30 00 	mov    0x3080(%rdx,%rcx,1),%rdi
    2d35:	00 
    2d36:	4c 8b 84 0a 88 30 00 	mov    0x3088(%rdx,%rcx,1),%r8
    2d3d:	00 
    2d3e:	48 89 7b 58          	mov    %rdi,0x58(%rbx)
    2d42:	49 89 3c 24          	mov    %rdi,(%r12)
    2d46:	4d 89 44 24 08       	mov    %r8,0x8(%r12)
    2d4b:	8b b4 0a 98 30 00 00 	mov    0x3098(%rdx,%rcx,1),%esi
    2d52:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    2d56:	48 8b 8c 0a 90 30 00 	mov    0x3090(%rdx,%rcx,1),%rcx
    2d5d:	00 
    2d5e:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
    2d65:	48 89 0a             	mov    %rcx,(%rdx)
    2d68:	89 72 08             	mov    %esi,0x8(%rdx)
    2d6b:	8b 50 20             	mov    0x20(%rax),%edx
    2d6e:	8b 48 24             	mov    0x24(%rax),%ecx
    2d71:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    2d75:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    2d79:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    2d80:	c7 80 b4 00 00 00 00 	movl   $0x0,0xb4(%rax)
    2d87:	00 00 00 
    2d8a:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    2d91:	c7 86 b1 00 00 00 00 	movl   $0x0,0xb1(%rsi)
    2d98:	00 00 00 
    2d9b:	88 90 b0 00 00 00    	mov    %dl,0xb0(%rax)
    2da1:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    2da8:	00 00 00 
    2dab:	88 88 b8 00 00 00    	mov    %cl,0xb8(%rax)
    2db1:	4c 8b 83 b8 00 00 00 	mov    0xb8(%rbx),%r8
    2db8:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    2dbf:	8b 08                	mov    (%rax),%ecx
    2dc1:	48 89 4b 50          	mov    %rcx,0x50(%rbx)
    2dc5:	49 8d 50 1c          	lea    0x1c(%r8),%rdx
    2dc9:	41 8b 70 1c          	mov    0x1c(%r8),%esi
    2dcd:	48 89 53 40          	mov    %rdx,0x40(%rbx)
    2dd1:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    2dd5:	89 70 48             	mov    %esi,0x48(%rax)
    2dd8:	4d 8d 48 2c          	lea    0x2c(%r8),%r9
    2ddc:	41 8b 78 2c          	mov    0x2c(%r8),%edi
    2de0:	45 31 d2             	xor    %r10d,%r10d
    2de3:	48 85 ff             	test   %rdi,%rdi
    2de6:	41 0f 94 c2          	sete   %r10b
    2dea:	4c 89 8b b0 00 00 00 	mov    %r9,0xb0(%rbx)
    2df1:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
    2df5:	45 8b 40 14          	mov    0x14(%r8),%r8d
    2df9:	45 31 c9             	xor    %r9d,%r9d
    2dfc:	41 85 c8             	test   %ecx,%r8d
    2dff:	41 0f 95 c1          	setne  %r9b
    2e03:	4c 89 4b 58          	mov    %r9,0x58(%rbx)
    2e07:	41 89 f9             	mov    %edi,%r9d
    2e0a:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    2e11:	45 89 d3             	mov    %r10d,%r11d
    2e14:	41 c1 e3 1e          	shl    $0x1e,%r11d
    2e18:	4d 01 d9             	add    %r11,%r9
    2e1b:	49 81 c1 00 00 00 20 	add    $0x20000000,%r9
    2e22:	4c 89 8b 10 01 00 00 	mov    %r9,0x110(%rbx)
    2e29:	c1 ef 1f             	shr    $0x1f,%edi
    2e2c:	41 08 fa             	or     %dil,%r10b
    2e2f:	74 0d                	je     2e3e <f_8001161d0+0x2e3e>
    2e31:	48 c7 43 58 00 00 00 	movq   $0x0,0x58(%rbx)
    2e38:	00 
    2e39:	e9 71 01 00 00       	jmp    2faf <f_8001161d0+0x2faf>
    2e3e:	41 85 c8             	test   %ecx,%r8d
    2e41:	0f 84 68 01 00 00    	je     2faf <f_8001161d0+0x2faf>
    2e47:	4c 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%r8
    2e4e:	4c 8b 8b a8 00 00 00 	mov    0xa8(%rbx),%r9
    2e55:	49 8d b8 40 01 00 00 	lea    0x140(%r8),%rdi
    2e5c:	48 89 bb c0 00 00 00 	mov    %rdi,0xc0(%rbx)
    2e63:	44 89 cf             	mov    %r9d,%edi
    2e66:	4d 63 c9             	movslq %r9d,%r9
    2e69:	49 c1 f9 1f          	sar    $0x1f,%r9
    2e6d:	49 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%r10
    2e74:	ff ff ff 
    2e77:	4d 21 d1             	and    %r10,%r9
    2e7a:	49 09 f9             	or     %rdi,%r9
    2e7d:	4c 89 8b c8 00 00 00 	mov    %r9,0xc8(%rbx)
    2e84:	47 0f b6 84 08 40 01 	movzbl 0x140(%r8,%r9,1),%r8d
    2e8b:	00 00 
    2e8d:	4c 89 43 58          	mov    %r8,0x58(%rbx)
    2e91:	41 f6 c0 01          	test   $0x1,%r8b
    2e95:	0f 84 14 01 00 00    	je     2faf <f_8001161d0+0x2faf>
    2e9b:	49 89 ef             	mov    %rbp,%r15
    2e9e:	44 0f b6 40 0c       	movzbl 0xc(%rax),%r8d
    2ea3:	4c 89 43 58          	mov    %r8,0x58(%rbx)
    2ea7:	41 f6 c0 01          	test   $0x1,%r8b
    2eab:	74 09                	je     2eb6 <f_8001161d0+0x2eb6>
    2ead:	48 09 ce             	or     %rcx,%rsi
    2eb0:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    2eb4:	89 32                	mov    %esi,(%rdx)
    2eb6:	48 c7 43 40 d0 00 00 	movq   $0xd0,0x40(%rbx)
    2ebd:	00 
    2ebe:	48 89 43 08          	mov    %rax,0x8(%rbx)
    2ec2:	48 63 c7             	movslq %edi,%rax
    2ec5:	48 69 c0 d0 00 00 00 	imul   $0xd0,%rax,%rax
    2ecc:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    2ed3:	48 8d 14 01          	lea    (%rcx,%rax,1),%rdx
    2ed7:	48 89 93 d0 00 00 00 	mov    %rdx,0xd0(%rbx)
    2ede:	48 c7 43 10 c0 00 00 	movq   $0xc0,0x10(%rbx)
    2ee5:	00 
    2ee6:	48 8d 84 01 40 0d 00 	lea    0xd40(%rcx,%rax,1),%rax
    2eed:	00 
    2eee:	48 89 83 a8 00 00 00 	mov    %rax,0xa8(%rbx)
    2ef5:	48 89 03             	mov    %rax,(%rbx)
    2ef8:	49 8d 87 6e 12 51 fd 	lea    -0x2aeed92(%r15),%rax
    2eff:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    2f06:	48 89 df             	mov    %rbx,%rdi
    2f09:	c5 f8 77             	vzeroupper
    2f0c:	e8 00 00 00 00       	call   2f11 <f_8001161d0+0x2f11>
    2f11:	48 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%rax
    2f18:	80 88 38 0d 00 00 01 	orb    $0x1,0xd38(%rax)
    2f1f:	48 8b bb a0 00 00 00 	mov    0xa0(%rbx),%rdi
    2f26:	0f b6 87 81 3a 00 00 	movzbl 0x3a81(%rdi),%eax
    2f2d:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2f31:	a8 40                	test   $0x40,%al
    2f33:	74 7a                	je     2faf <f_8001161d0+0x2faf>
    2f35:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2f3c:	48 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%rcx
    2f43:	0f b6 04 01          	movzbl (%rcx,%rax,1),%eax
    2f47:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2f4b:	a8 02                	test   $0x2,%al
    2f4d:	74 60                	je     2faf <f_8001161d0+0x2faf>
    2f4f:	48 8b 87 60 3b 00 00 	mov    0x3b60(%rdi),%rax
    2f56:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2f5a:	48 85 c0             	test   %rax,%rax
    2f5d:	74 50                	je     2faf <f_8001161d0+0x2faf>
    2f5f:	0f b6 87 85 3a 00 00 	movzbl 0x3a85(%rdi),%eax
    2f66:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2f6a:	a8 02                	test   $0x2,%al
    2f6c:	74 41                	je     2faf <f_8001161d0+0x2faf>
    2f6e:	48 8b 83 a8 00 00 00 	mov    0xa8(%rbx),%rax
    2f75:	48 8b 8b b8 00 00 00 	mov    0xb8(%rbx),%rcx
    2f7c:	8b 00                	mov    (%rax),%eax
    2f7e:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2f82:	8b 49 10             	mov    0x10(%rcx),%ecx
    2f85:	31 d2                	xor    %edx,%edx
    2f87:	c4 e2 70 f2 c0       	andn   %eax,%ecx,%eax
    2f8c:	0f 94 c2             	sete   %dl
    2f8f:	89 c6                	mov    %eax,%esi
    2f91:	81 e6 00 00 00 80    	and    $0x80000000,%esi
    2f97:	c1 e2 1e             	shl    $0x1e,%edx
    2f9a:	09 f2                	or     %esi,%edx
    2f9c:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    2fa0:	48 89 93 10 01 00 00 	mov    %rdx,0x110(%rbx)
    2fa7:	85 c0                	test   %eax,%eax
    2fa9:	0f 84 b8 05 00 00    	je     3567 <f_8001161d0+0x3567>
    2faf:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    2fb6:	48 8b 88 20 01 00 00 	mov    0x120(%rax),%rcx
    2fbd:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    2fc4:	48 89 8b a0 00 00 00 	mov    %rcx,0xa0(%rbx)
    2fcb:	48 89 93 98 00 00 00 	mov    %rdx,0x98(%rbx)
    2fd2:	48 8b 88 10 01 00 00 	mov    0x110(%rax),%rcx
    2fd9:	48 8b 90 18 01 00 00 	mov    0x118(%rax),%rdx
    2fe0:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
    2fe7:	48 89 93 a8 00 00 00 	mov    %rdx,0xa8(%rbx)
    2fee:	48 8b 88 00 01 00 00 	mov    0x100(%rax),%rcx
    2ff5:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    2ffc:	48 89 8b c0 00 00 00 	mov    %rcx,0xc0(%rbx)
    3003:	48 89 93 b8 00 00 00 	mov    %rdx,0xb8(%rbx)
    300a:	48 8b 88 f0 00 00 00 	mov    0xf0(%rax),%rcx
    3011:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
    3018:	48 89 8b d0 00 00 00 	mov    %rcx,0xd0(%rbx)
    301f:	48 89 93 c8 00 00 00 	mov    %rdx,0xc8(%rbx)
    3026:	48 8b 88 e0 00 00 00 	mov    0xe0(%rax),%rcx
    302d:	48 8b 90 e8 00 00 00 	mov    0xe8(%rax),%rdx
    3034:	48 89 8b e0 00 00 00 	mov    %rcx,0xe0(%rbx)
    303b:	48 89 93 d8 00 00 00 	mov    %rdx,0xd8(%rbx)
    3042:	c5 f8 10 80 d0 00 00 	vmovups 0xd0(%rax),%xmm0
    3049:	00 
    304a:	c5 f8 11 83 e8 00 00 	vmovups %xmm0,0xe8(%rbx)
    3051:	00 
    3052:	48 05 30 01 00 00    	add    $0x130,%rax
    3058:	48 89 83 00 01 00 00 	mov    %rax,0x100(%rbx)
    305f:	48 83 c4 18          	add    $0x18,%rsp
    3063:	5b                   	pop    %rbx
    3064:	41 5c                	pop    %r12
    3066:	41 5d                	pop    %r13
    3068:	41 5e                	pop    %r14
    306a:	41 5f                	pop    %r15
    306c:	5d                   	pop    %rbp
    306d:	c5 f8 77             	vzeroupper
    3070:	c3                   	ret
    3071:	4c 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%r8
    3078:	49 8b 88 c8 1e 00 00 	mov    0x1ec8(%r8),%rcx
    307f:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
    3086:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    308d:	ff ff ff 
    3090:	48 8d 77 1a          	lea    0x1a(%rdi),%rsi
    3094:	48 89 73 70          	mov    %rsi,0x70(%rbx)
    3098:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    309c:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    30a3:	48 c7 01 00 20 00 00 	movq   $0x2000,(%rcx)
    30aa:	48 c7 41 08 00 00 00 	movq   $0x0,0x8(%rcx)
    30b1:	00 
    30b2:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    30b9:	00 
    30ba:	48 89 71 18          	mov    %rsi,0x18(%rcx)
    30be:	48 8b b3 98 00 00 00 	mov    0x98(%rbx),%rsi
    30c5:	48 89 73 08          	mov    %rsi,0x8(%rbx)
    30c9:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    30d0:	00 
    30d1:	44 89 b1 a0 00 00 00 	mov    %r14d,0xa0(%rcx)
    30d8:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    30df:	00 00 00 
    30e2:	48 89 41 20          	mov    %rax,0x20(%rcx)
    30e6:	48 89 79 28          	mov    %rdi,0x28(%rcx)
    30ea:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
    30f1:	00 80 3f 
    30f4:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    30f8:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    30fd:	48 89 41 30          	mov    %rax,0x30(%rcx)
    3101:	48 89 79 38          	mov    %rdi,0x38(%rcx)
    3105:	48 8d 85 95 53 09 00 	lea    0x95395(%rbp),%rax
    310c:	48 89 41 70          	mov    %rax,0x70(%rcx)
    3110:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
    3117:	ff 7f 7f 
    311a:	4c 89 51 78          	mov    %r10,0x78(%rcx)
    311e:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
    3125:	ff 7f ff 
    3128:	48 89 b1 80 00 00 00 	mov    %rsi,0x80(%rcx)
    312f:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
    3134:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    313b:	4c 8b 0c 24          	mov    (%rsp),%r9
    313f:	4c 89 4b 60          	mov    %r9,0x60(%rbx)
    3143:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    314a:	4c 89 88 a4 00 00 00 	mov    %r9,0xa4(%rax)
    3151:	4c 89 91 90 00 00 00 	mov    %r10,0x90(%rcx)
    3158:	48 89 b1 98 00 00 00 	mov    %rsi,0x98(%rcx)
    315f:	48 c7 43 50 b0 1e 00 	movq   $0x1eb0,0x50(%rbx)
    3166:	00 
    3167:	49 81 c0 b0 1e 00 00 	add    $0x1eb0,%r8
    316e:	4c 89 03             	mov    %r8,(%rbx)
    3171:	48 89 51 50          	mov    %rdx,0x50(%rcx)
    3175:	48 c7 41 58 00 00 00 	movq   $0x0,0x58(%rcx)
    317c:	00 
    317d:	48 c7 43 48 03 00 00 	movq   $0x3,0x48(%rbx)
    3184:	00 
    3185:	c7 81 bc 00 00 00 03 	movl   $0x3,0xbc(%rcx)
    318c:	00 00 00 
    318f:	48 89 79 40          	mov    %rdi,0x40(%rcx)
    3193:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    319a:	00 
    319b:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    319f:	c5 f8 11 41 60       	vmovups %xmm0,0x60(%rcx)
    31a4:	48 8d 85 92 14 51 fd 	lea    -0x2aeeb6e(%rbp),%rax
    31ab:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    31b2:	48 89 df             	mov    %rbx,%rdi
    31b5:	c5 f8 77             	vzeroupper
    31b8:	e8 00 00 00 00       	call   31bd <f_8001161d0+0x31bd>
    31bd:	48 8b 33             	mov    (%rbx),%rsi
    31c0:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    31c7:	0f b6 48 08          	movzbl 0x8(%rax),%ecx
    31cb:	48 8b 93 b0 00 00 00 	mov    0xb0(%rbx),%rdx
    31d2:	8b 42 08             	mov    0x8(%rdx),%eax
    31d5:	31 ff                	xor    %edi,%edi
    31d7:	45 31 c0             	xor    %r8d,%r8d
    31da:	41 89 c1             	mov    %eax,%r9d
    31dd:	41 29 c9             	sub    %ecx,%r9d
    31e0:	40 0f 94 c7          	sete   %dil
    31e4:	41 0f 93 c0          	setae  %r8b
    31e8:	c4 62 30 f2 d0       	andn   %eax,%r9d,%r10d
    31ed:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    31f4:	c1 e7 1e             	shl    $0x1e,%edi
    31f7:	41 c1 e0 1d          	shl    $0x1d,%r8d
    31fb:	41 09 f8             	or     %edi,%r8d
    31fe:	41 c1 ea 03          	shr    $0x3,%r10d
    3202:	41 81 e2 00 00 00 10 	and    $0x10000000,%r10d
    3209:	45 09 ca             	or     %r9d,%r10d
    320c:	45 09 c2             	or     %r8d,%r10d
    320f:	48 69 f9 e0 3c 00 00 	imul   $0x3ce0,%rcx,%rdi
    3216:	31 c0                	xor    %eax,%eax
    3218:	41 81 f8 00 00 00 20 	cmp    $0x20000000,%r8d
    321f:	48 0f 44 c7          	cmove  %rdi,%rax
    3223:	4c 89 93 10 01 00 00 	mov    %r10,0x110(%rbx)
    322a:	48 03 42 10          	add    0x10(%rdx),%rax
    322e:	40 f6 c6 01          	test   $0x1,%sil
    3232:	75 34                	jne    3268 <f_8001161d0+0x3268>
    3234:	41 b8 5c 00 00 00    	mov    $0x5c,%r8d
    323a:	41 b9 58 00 00 00    	mov    $0x58,%r9d
    3240:	41 ba 54 00 00 00    	mov    $0x54,%r10d
    3246:	41 bb 50 00 00 00    	mov    $0x50,%r11d
    324c:	eb 36                	jmp    3284 <f_8001161d0+0x3284>
    324e:	48 81 c1 bc 00 00 00 	add    $0xbc,%rcx
    3255:	48 c7 43 40 02 00 00 	movq   $0x2,0x40(%rbx)
    325c:	00 
    325d:	c7 01 02 00 00 00    	movl   $0x2,(%rcx)
    3263:	e9 49 fb ff ff       	jmp    2db1 <f_8001161d0+0x2db1>
    3268:	48 89 43 68          	mov    %rax,0x68(%rbx)
    326c:	41 b8 0c 2e 00 00    	mov    $0x2e0c,%r8d
    3272:	41 b9 08 2e 00 00    	mov    $0x2e08,%r9d
    3278:	41 ba 04 2e 00 00    	mov    $0x2e04,%r10d
    327e:	41 bb 00 2e 00 00    	mov    $0x2e00,%r11d
    3284:	46 8b 1c 18          	mov    (%rax,%r11,1),%r11d
    3288:	4c 89 9b 00 02 00 00 	mov    %r11,0x200(%rbx)
    328f:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    3296:	00 00 00 00 
    329a:	46 8b 14 10          	mov    (%rax,%r10,1),%r10d
    329e:	4c 89 93 10 02 00 00 	mov    %r10,0x210(%rbx)
    32a5:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    32ac:	00 00 00 00 
    32b0:	46 8b 0c 08          	mov    (%rax,%r9,1),%r9d
    32b4:	4c 89 8b 20 02 00 00 	mov    %r9,0x220(%rbx)
    32bb:	48 c7 83 28 02 00 00 	movq   $0x0,0x228(%rbx)
    32c2:	00 00 00 00 
    32c6:	48 c7 43 58 e0 3c 00 	movq   $0x3ce0,0x58(%rbx)
    32cd:	00 
    32ce:	46 8b 04 00          	mov    (%rax,%r8,1),%r8d
    32d2:	4c 89 83 30 02 00 00 	mov    %r8,0x230(%rbx)
    32d9:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    32e0:	00 00 00 00 
    32e4:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    32eb:	44 89 58 78          	mov    %r11d,0x78(%rax)
    32ef:	44 89 50 7c          	mov    %r10d,0x7c(%rax)
    32f3:	44 89 88 80 00 00 00 	mov    %r9d,0x80(%rax)
    32fa:	44 89 80 84 00 00 00 	mov    %r8d,0x84(%rax)
    3301:	45 31 c0             	xor    %r8d,%r8d
    3304:	39 4a 08             	cmp    %ecx,0x8(%rdx)
    3307:	4c 0f 47 c7          	cmova  %rdi,%r8
    330b:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
    330f:	40 f6 c6 01          	test   $0x1,%sil
    3313:	0f 85 9a 00 00 00    	jne    33b3 <f_8001161d0+0x33b3>
    3319:	4b 8b 74 08 20       	mov    0x20(%r8,%r9,1),%rsi
    331e:	4f 8b 54 08 28       	mov    0x28(%r8,%r9,1),%r10
    3323:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    3327:	4c 8b 9b d0 00 00 00 	mov    0xd0(%rbx),%r11
    332e:	49 89 33             	mov    %rsi,(%r11)
    3331:	4d 89 53 08          	mov    %r10,0x8(%r11)
    3335:	4b 8b 74 08 30       	mov    0x30(%r8,%r9,1),%rsi
    333a:	47 8b 44 08 38       	mov    0x38(%r8,%r9,1),%r8d
    333f:	4c 89 43 48          	mov    %r8,0x48(%rbx)
    3343:	4c 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%r9
    334a:	45 89 41 08          	mov    %r8d,0x8(%r9)
    334e:	49 89 31             	mov    %rsi,(%r9)
    3351:	44 8b 4a 08          	mov    0x8(%rdx),%r9d
    3355:	48 8b 72 10          	mov    0x10(%rdx),%rsi
    3359:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    335d:	45 31 c0             	xor    %r8d,%r8d
    3360:	45 31 d2             	xor    %r10d,%r10d
    3363:	45 31 db             	xor    %r11d,%r11d
    3366:	44 89 cd             	mov    %r9d,%ebp
    3369:	29 cd                	sub    %ecx,%ebp
    336b:	4c 0f 47 c7          	cmova  %rdi,%r8
    336f:	41 0f 94 c2          	sete   %r10b
    3373:	41 0f 93 c3          	setae  %r11b
    3377:	c4 c2 50 f2 d1       	andn   %r9d,%ebp,%edx
    337c:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    3382:	41 c1 e2 1e          	shl    $0x1e,%r10d
    3386:	41 c1 e3 1d          	shl    $0x1d,%r11d
    338a:	45 09 d3             	or     %r10d,%r11d
    338d:	41 09 eb             	or     %ebp,%r11d
    3390:	48 bd ca 5d c0 02 08 	movabs $0x802c05dca,%rbp
    3397:	00 00 00 
    339a:	c1 ea 03             	shr    $0x3,%edx
    339d:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    33a3:	44 09 da             	or     %r11d,%edx
    33a6:	4a 8d 0c 06          	lea    (%rsi,%r8,1),%rcx
    33aa:	48 83 c1 40          	add    $0x40,%rcx
    33ae:	e9 a9 00 00 00       	jmp    345c <f_8001161d0+0x345c>
    33b3:	4b 8b b4 08 80 30 00 	mov    0x3080(%r8,%r9,1),%rsi
    33ba:	00 
    33bb:	4b 8b bc 08 88 30 00 	mov    0x3088(%r8,%r9,1),%rdi
    33c2:	00 
    33c3:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
    33c7:	4c 8b 93 d0 00 00 00 	mov    0xd0(%rbx),%r10
    33ce:	49 89 32             	mov    %rsi,(%r10)
    33d1:	49 89 7a 08          	mov    %rdi,0x8(%r10)
    33d5:	4b 8b b4 08 90 30 00 	mov    0x3090(%r8,%r9,1),%rsi
    33dc:	00 
    33dd:	43 8b bc 08 98 30 00 	mov    0x3098(%r8,%r9,1),%edi
    33e4:	00 
    33e5:	4c 8b 83 c8 00 00 00 	mov    0xc8(%rbx),%r8
    33ec:	41 89 78 08          	mov    %edi,0x8(%r8)
    33f0:	49 89 30             	mov    %rsi,(%r8)
    33f3:	44 8b 42 08          	mov    0x8(%rdx),%r8d
    33f7:	48 8b 72 10          	mov    0x10(%rdx),%rsi
    33fb:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    33ff:	31 ff                	xor    %edi,%edi
    3401:	45 31 c9             	xor    %r9d,%r9d
    3404:	45 31 d2             	xor    %r10d,%r10d
    3407:	45 89 c3             	mov    %r8d,%r11d
    340a:	41 29 cb             	sub    %ecx,%r11d
    340d:	41 0f 94 c1          	sete   %r9b
    3411:	41 0f 93 c2          	setae  %r10b
    3415:	48 0f 47 f9          	cmova  %rcx,%rdi
    3419:	c4 c2 20 f2 d0       	andn   %r8d,%r11d,%edx
    341e:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    3425:	41 c1 e1 1e          	shl    $0x1e,%r9d
    3429:	41 c1 e2 1d          	shl    $0x1d,%r10d
    342d:	45 09 ca             	or     %r9d,%r10d
    3430:	45 09 da             	or     %r11d,%r10d
    3433:	c1 ea 03             	shr    $0x3,%edx
    3436:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    343c:	44 09 d2             	or     %r10d,%edx
    343f:	48 c7 43 48 f0 2d 00 	movq   $0x2df0,0x48(%rbx)
    3446:	00 
    3447:	48 89 7b 40          	mov    %rdi,0x40(%rbx)
    344b:	48 69 cf e0 3c 00 00 	imul   $0x3ce0,%rdi,%rcx
    3452:	48 01 f1             	add    %rsi,%rcx
    3455:	48 81 c1 f0 2d 00 00 	add    $0x2df0,%rcx
    345c:	48 89 93 10 01 00 00 	mov    %rdx,0x110(%rbx)
    3463:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    3467:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    346b:	48 85 d2             	test   %rdx,%rdx
    346e:	74 0d                	je     347d <f_8001161d0+0x347d>
    3470:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3477:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    347b:	eb 02                	jmp    347f <f_8001161d0+0x347f>
    347d:	31 d2                	xor    %edx,%edx
    347f:	88 90 b0 00 00 00    	mov    %dl,0xb0(%rax)
    3485:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    3489:	48 85 d2             	test   %rdx,%rdx
    348c:	74 09                	je     3497 <f_8001161d0+0x3497>
    348e:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3495:	eb 02                	jmp    3499 <f_8001161d0+0x3499>
    3497:	31 d2                	xor    %edx,%edx
    3499:	88 90 b1 00 00 00    	mov    %dl,0xb1(%rax)
    349f:	48 8b 51 30          	mov    0x30(%rcx),%rdx
    34a3:	48 85 d2             	test   %rdx,%rdx
    34a6:	74 0d                	je     34b5 <f_8001161d0+0x34b5>
    34a8:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    34af:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    34b3:	eb 02                	jmp    34b7 <f_8001161d0+0x34b7>
    34b5:	31 d2                	xor    %edx,%edx
    34b7:	88 90 b2 00 00 00    	mov    %dl,0xb2(%rax)
    34bd:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    34c1:	48 85 d2             	test   %rdx,%rdx
    34c4:	74 09                	je     34cf <f_8001161d0+0x34cf>
    34c6:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    34cd:	eb 02                	jmp    34d1 <f_8001161d0+0x34d1>
    34cf:	31 d2                	xor    %edx,%edx
    34d1:	88 90 b3 00 00 00    	mov    %dl,0xb3(%rax)
    34d7:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    34db:	48 85 d2             	test   %rdx,%rdx
    34de:	74 0d                	je     34ed <f_8001161d0+0x34ed>
    34e0:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    34e7:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    34eb:	eb 02                	jmp    34ef <f_8001161d0+0x34ef>
    34ed:	31 d2                	xor    %edx,%edx
    34ef:	88 90 b4 00 00 00    	mov    %dl,0xb4(%rax)
    34f5:	48 8b 51 48          	mov    0x48(%rcx),%rdx
    34f9:	48 85 d2             	test   %rdx,%rdx
    34fc:	74 09                	je     3507 <f_8001161d0+0x3507>
    34fe:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3505:	eb 02                	jmp    3509 <f_8001161d0+0x3509>
    3507:	31 d2                	xor    %edx,%edx
    3509:	88 90 b5 00 00 00    	mov    %dl,0xb5(%rax)
    350f:	48 8b 51 50          	mov    0x50(%rcx),%rdx
    3513:	48 85 d2             	test   %rdx,%rdx
    3516:	74 09                	je     3521 <f_8001161d0+0x3521>
    3518:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    351f:	eb 02                	jmp    3523 <f_8001161d0+0x3523>
    3521:	31 d2                	xor    %edx,%edx
    3523:	88 90 b6 00 00 00    	mov    %dl,0xb6(%rax)
    3529:	48 8b 51 58          	mov    0x58(%rcx),%rdx
    352d:	48 85 d2             	test   %rdx,%rdx
    3530:	74 0d                	je     353f <f_8001161d0+0x353f>
    3532:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3539:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    353d:	eb 02                	jmp    3541 <f_8001161d0+0x3541>
    353f:	31 d2                	xor    %edx,%edx
    3541:	88 90 b7 00 00 00    	mov    %dl,0xb7(%rax)
    3547:	48 8b 49 60          	mov    0x60(%rcx),%rcx
    354b:	48 85 c9             	test   %rcx,%rcx
    354e:	74 10                	je     3560 <f_8001161d0+0x3560>
    3550:	0f b6 89 c0 00 00 00 	movzbl 0xc0(%rcx),%ecx
    3557:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    355b:	e9 4b f8 ff ff       	jmp    2dab <f_8001161d0+0x2dab>
    3560:	31 c9                	xor    %ecx,%ecx
    3562:	e9 44 f8 ff ff       	jmp    2dab <f_8001161d0+0x2dab>
    3567:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
    356e:	8b 08                	mov    (%rax),%ecx
    3570:	44 8b 8f 90 3b 00 00 	mov    0x3b90(%rdi),%r9d
    3577:	44 8b 87 94 3b 00 00 	mov    0x3b94(%rdi),%r8d
    357e:	41 83 f9 01          	cmp    $0x1,%r9d
    3582:	44 89 ce             	mov    %r9d,%esi
    3585:	83 d6 00             	adc    $0x0,%esi
    3588:	89 c8                	mov    %ecx,%eax
    358a:	31 d2                	xor    %edx,%edx
    358c:	f7 f6                	div    %esi
    358e:	89 c6                	mov    %eax,%esi
    3590:	45 85 c9             	test   %r9d,%r9d
    3593:	41 0f 44 f1          	cmove  %r9d,%esi
    3597:	4c 89 43 48          	mov    %r8,0x48(%rbx)
    359b:	31 d2                	xor    %edx,%edx
    359d:	41 89 f1             	mov    %esi,%r9d
    35a0:	45 31 c1             	xor    %r8d,%r9d
    35a3:	0f 94 c2             	sete   %dl
    35a6:	45 31 d2             	xor    %r10d,%r10d
    35a9:	89 f0                	mov    %esi,%eax
    35ab:	44 29 c0             	sub    %r8d,%eax
    35ae:	41 0f 93 c2          	setae  %r10b
    35b2:	41 89 f3             	mov    %esi,%r11d
    35b5:	41 31 c3             	xor    %eax,%r11d
    35b8:	45 21 cb             	and    %r9d,%r11d
    35bb:	41 89 c1             	mov    %eax,%r9d
    35be:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    35c5:	c1 e2 1e             	shl    $0x1e,%edx
    35c8:	41 c1 e2 1d          	shl    $0x1d,%r10d
    35cc:	41 09 d2             	or     %edx,%r10d
    35cf:	45 09 ca             	or     %r9d,%r10d
    35d2:	44 31 d8             	xor    %r11d,%eax
    35d5:	41 c1 eb 03          	shr    $0x3,%r11d
    35d9:	41 81 e3 00 00 00 10 	and    $0x10000000,%r11d
    35e0:	45 09 d3             	or     %r10d,%r11d
    35e3:	4c 89 9b 10 01 00 00 	mov    %r11,0x110(%rbx)
    35ea:	a9 00 00 00 80       	test   $0x80000000,%eax
    35ef:	49 0f 44 f0          	cmove  %r8,%rsi
    35f3:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    35f7:	48 85 f6             	test   %rsi,%rsi
    35fa:	0f 84 af f9 ff ff    	je     2faf <f_8001161d0+0x2faf>
    3600:	48 89 8b 88 00 00 00 	mov    %rcx,0x88(%rbx)
    3607:	31 d2                	xor    %edx,%edx
    3609:	89 f0                	mov    %esi,%eax
    360b:	ff c8                	dec    %eax
    360d:	0f 94 c2             	sete   %dl
    3610:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    3616:	49 81 c1 01 00 00 80 	add    $0xffffffff80000001,%r9
    361d:	45 31 c0             	xor    %r8d,%r8d
    3620:	4d 89 cb             	mov    %r9,%r11
    3623:	4c 39 ce             	cmp    %r9,%rsi
    3626:	41 0f 94 c0          	sete   %r8b
    362a:	41 89 c1             	mov    %eax,%r9d
    362d:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    3634:	c1 e2 1e             	shl    $0x1e,%edx
    3637:	44 09 ca             	or     %r9d,%edx
    363a:	45 89 c1             	mov    %r8d,%r9d
    363d:	41 c1 e1 1c          	shl    $0x1c,%r9d
    3641:	41 09 d1             	or     %edx,%r9d
    3644:	49 81 c9 00 00 00 20 	or     $0x20000000,%r9
    364b:	4c 89 8b 10 01 00 00 	mov    %r9,0x110(%rbx)
    3652:	48 89 43 48          	mov    %rax,0x48(%rbx)
    3656:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
    365a:	c1 e8 1f             	shr    $0x1f,%eax
    365d:	41 30 c0             	xor    %al,%r8b
    3660:	0f 85 49 f9 ff ff    	jne    2faf <f_8001161d0+0x2faf>
    3666:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    366c:	49 31 f0             	xor    %rsi,%r8
    366f:	41 be 00 00 00 80    	mov    $0x80000000,%r14d
    3675:	49 89 c9             	mov    %rcx,%r9
    3678:	4d 31 f1             	xor    %r14,%r9
    367b:	4c 89 c8             	mov    %r9,%rax
    367e:	4c 09 c0             	or     %r8,%rax
    3681:	b8 01 00 00 00       	mov    $0x1,%eax
    3686:	41 89 f2             	mov    %esi,%r10d
    3689:	44 0f 44 d0          	cmove  %eax,%r10d
    368d:	89 c8                	mov    %ecx,%eax
    368f:	99                   	cltd
    3690:	41 f7 fa             	idiv   %r10d
    3693:	48 8d 53 50          	lea    0x50(%rbx),%rdx
    3697:	4d 09 c1             	or     %r8,%r9
    369a:	41 89 c0             	mov    %eax,%r8d
    369d:	44 0f 44 c1          	cmove  %ecx,%r8d
    36a1:	49 0f 44 c3          	cmove  %r11,%rax
    36a5:	4c 8d 8f 80 3b 00 00 	lea    0x3b80(%rdi),%r9
    36ac:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
    36b0:	c5 f9 7f 0a          	vmovdqa %xmm1,(%rdx)
    36b4:	4c 89 4b 70          	mov    %r9,0x70(%rbx)
    36b8:	48 c7 43 78 28 00 00 	movq   $0x28,0x78(%rbx)
    36bf:	00 
    36c0:	48 c7 83 80 00 00 00 	movq   $0x3dcccccd,0x80(%rbx)
    36c7:	cd cc cc 3d 
    36cb:	41 0f af f0          	imul   %r8d,%esi
    36cf:	29 f1                	sub    %esi,%ecx
    36d1:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
    36d5:	48 81 c7 78 3b 00 00 	add    $0x3b78,%rdi
    36dc:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    36e0:	48 89 83 88 00 00 00 	mov    %rax,0x88(%rbx)
    36e7:	45 31 ed             	xor    %r13d,%r13d
    36ea:	c4 e2 79 59 15 00 00 	vpbroadcastq 0x0(%rip),%xmm2        # 36f3 <f_8001161d0+0x36f3>
    36f1:	00 00 
    36f3:	48 bd 00 00 00 00 f8 	movabs $0xfffffff800000000,%rbp
    36fa:	ff ff ff 
    36fd:	eb 72                	jmp    3771 <f_8001161d0+0x3771>
    36ff:	c4 e3 e9 22 83 88 00 	vpinsrq $0x1,0x88(%rbx),%xmm2,%xmm0
    3706:	00 00 01 
    3709:	c5 f9 d4 43 50       	vpaddq 0x50(%rbx),%xmm0,%xmm0
    370e:	c5 f9 7e c0          	vmovd  %xmm0,%eax
    3712:	8b 4b 40             	mov    0x40(%rbx),%ecx
    3715:	31 d2                	xor    %edx,%edx
    3717:	89 c6                	mov    %eax,%esi
    3719:	31 ce                	xor    %ecx,%esi
    371b:	0f 94 c2             	sete   %dl
    371e:	31 ff                	xor    %edi,%edi
    3720:	41 89 c0             	mov    %eax,%r8d
    3723:	41 29 c8             	sub    %ecx,%r8d
    3726:	40 0f 93 c7          	setae  %dil
    372a:	45 89 c1             	mov    %r8d,%r9d
    372d:	41 31 c1             	xor    %eax,%r9d
    3730:	41 21 f1             	and    %esi,%r9d
    3733:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
    373a:	c1 e2 1e             	shl    $0x1e,%edx
    373d:	c1 e7 1d             	shl    $0x1d,%edi
    3740:	09 d7                	or     %edx,%edi
    3742:	44 09 c7             	or     %r8d,%edi
    3745:	41 c1 e9 03          	shr    $0x3,%r9d
    3749:	41 81 e1 00 00 00 10 	and    $0x10000000,%r9d
    3750:	41 09 f9             	or     %edi,%r9d
    3753:	31 c8                	xor    %ecx,%eax
    3755:	c4 e3 79 02 c1 0a    	vpblendd $0xa,%xmm1,%xmm0,%xmm0
    375b:	c5 f9 7f 43 50       	vmovdqa %xmm0,0x50(%rbx)
    3760:	4c 89 8b 10 01 00 00 	mov    %r9,0x110(%rbx)
    3767:	0f 84 42 f8 ff ff    	je     2faf <f_8001161d0+0x2faf>
    376d:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
    3771:	8b 07                	mov    (%rdi),%eax
    3773:	48 89 83 30 01 00 00 	mov    %rax,0x130(%rbx)
    377a:	48 89 83 90 00 00 00 	mov    %rax,0x90(%rbx)
    3781:	8d 48 01             	lea    0x1(%rax),%ecx
    3784:	48 89 0b             	mov    %rcx,(%rbx)
    3787:	48 8b 53 68          	mov    0x68(%rbx),%rdx
    378b:	48 c7 83 28 01 00 00 	movq   $0xffffffffffffffff,0x128(%rbx)
    3792:	ff ff ff ff 
    3796:	48 39 d7             	cmp    %rdx,%rdi
    3799:	40 0f 94 c6          	sete   %sil
    379d:	f0 0f b1 0a          	lock cmpxchg %ecx,(%rdx)
    37a1:	0f 94 c0             	sete   %al
    37a4:	40 20 f0             	and    %sil,%al
    37a7:	89 c1                	mov    %eax,%ecx
    37a9:	80 f1 01             	xor    $0x1,%cl
    37ac:	0f b6 c9             	movzbl %cl,%ecx
    37af:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    37b3:	84 c0                	test   %al,%al
    37b5:	74 b6                	je     376d <f_8001161d0+0x376d>
    37b7:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
    37be:	8b b9 68 3b 00 00    	mov    0x3b68(%rcx),%edi
    37c4:	8b 43 50             	mov    0x50(%rbx),%eax
    37c7:	3b 43 48             	cmp    0x48(%rbx),%eax
    37ca:	8b 43 60             	mov    0x60(%rbx),%eax
    37cd:	49 0f 45 c5          	cmovne %r13,%rax
    37d1:	48 8b b1 70 3b 00 00 	mov    0x3b70(%rcx),%rsi
    37d8:	48 89 33             	mov    %rsi,(%rbx)
    37db:	48 8b 8b 90 00 00 00 	mov    0x90(%rbx),%rcx
    37e2:	ba 00 00 00 00       	mov    $0x0,%edx
    37e7:	39 cf                	cmp    %ecx,%edi
    37e9:	76 19                	jbe    3804 <f_8001161d0+0x3804>
    37eb:	89 c9                	mov    %ecx,%ecx
    37ed:	48 63 d1             	movslq %ecx,%rdx
    37f0:	48 c1 fa 1f          	sar    $0x1f,%rdx
    37f4:	48 bf 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdi
    37fb:	ff ff ff 
    37fe:	48 21 fa             	and    %rdi,%rdx
    3801:	48 09 ca             	or     %rcx,%rdx
    3804:	48 89 53 08          	mov    %rdx,0x8(%rbx)
    3808:	48 03 83 88 00 00 00 	add    0x88(%rbx),%rax
    380f:	89 c1                	mov    %eax,%ecx
    3811:	48 89 8b 88 00 00 00 	mov    %rcx,0x88(%rbx)
    3818:	48 63 d2             	movslq %edx,%rdx
    381b:	48 63 7b 78          	movslq 0x78(%rbx),%rdi
    381f:	48 0f af fa          	imul   %rdx,%rdi
    3823:	48 8d 14 37          	lea    (%rdi,%rsi,1),%rdx
    3827:	48 89 93 90 00 00 00 	mov    %rdx,0x90(%rbx)
    382e:	44 8b 43 58          	mov    0x58(%rbx),%r8d
    3832:	49 89 c1             	mov    %rax,%r9
    3835:	49 c1 e1 20          	shl    $0x20,%r9
    3839:	4d 09 c1             	or     %r8,%r9
    383c:	4c 8b 83 98 00 00 00 	mov    0x98(%rbx),%r8
    3843:	4c 89 04 37          	mov    %r8,(%rdi,%rsi,1)
    3847:	4c 8b 83 b8 00 00 00 	mov    0xb8(%rbx),%r8
    384e:	4c 89 44 37 08       	mov    %r8,0x8(%rdi,%rsi,1)
    3853:	4c 8b 83 a8 00 00 00 	mov    0xa8(%rbx),%r8
    385a:	4c 89 44 37 10       	mov    %r8,0x10(%rdi,%rsi,1)
    385f:	4c 89 4c 37 18       	mov    %r9,0x18(%rdi,%rsi,1)
    3864:	41 8b b0 bc 00 00 00 	mov    0xbc(%r8),%esi
    386b:	45 31 c0             	xor    %r8d,%r8d
    386e:	89 f7                	mov    %esi,%edi
    3870:	83 c7 fe             	add    $0xfffffffe,%edi
    3873:	41 0f 94 c0          	sete   %r8b
    3877:	45 31 c9             	xor    %r9d,%r9d
    387a:	41 ba 01 00 00 00    	mov    $0x1,%r10d
    3880:	41 29 f2             	sub    %esi,%r10d
    3883:	41 0f 92 c1          	setb   %r9b
    3887:	41 21 f2             	and    %esi,%r10d
    388a:	41 89 fb             	mov    %edi,%r11d
    388d:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    3894:	41 c1 e0 1e          	shl    $0x1e,%r8d
    3898:	41 c1 e1 1d          	shl    $0x1d,%r9d
    389c:	45 09 d9             	or     %r11d,%r9d
    389f:	45 09 c1             	or     %r8d,%r9d
    38a2:	41 c1 ea 03          	shr    $0x3,%r10d
    38a6:	41 81 e2 00 00 00 10 	and    $0x10000000,%r10d
    38ad:	45 09 ca             	or     %r9d,%r10d
    38b0:	48 89 73 10          	mov    %rsi,0x10(%rbx)
    38b4:	4c 89 93 10 01 00 00 	mov    %r10,0x110(%rbx)
    38bb:	85 ff                	test   %edi,%edi
    38bd:	0f 84 b1 00 00 00    	je     3974 <f_8001161d0+0x3974>
    38c3:	31 ff                	xor    %edi,%edi
    38c5:	48 85 f6             	test   %rsi,%rsi
    38c8:	40 0f 95 c7          	setne  %dil
    38cc:	45 31 c0             	xor    %r8d,%r8d
    38cf:	41 89 f1             	mov    %esi,%r9d
    38d2:	41 ff c9             	dec    %r9d
    38d5:	41 0f 94 c0          	sete   %r8b
    38d9:	45 31 d2             	xor    %r10d,%r10d
    38dc:	4c 39 f6             	cmp    %r14,%rsi
    38df:	41 0f 94 c2          	sete   %r10b
    38e3:	45 89 cb             	mov    %r9d,%r11d
    38e6:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    38ed:	41 c1 e0 1e          	shl    $0x1e,%r8d
    38f1:	c1 e7 1d             	shl    $0x1d,%edi
    38f4:	41 c1 e2 1c          	shl    $0x1c,%r10d
    38f8:	41 09 fa             	or     %edi,%r10d
    38fb:	45 09 da             	or     %r11d,%r10d
    38fe:	45 09 c2             	or     %r8d,%r10d
    3901:	4c 89 93 10 01 00 00 	mov    %r10,0x110(%rbx)
    3908:	45 85 c9             	test   %r9d,%r9d
    390b:	0f 84 07 01 00 00    	je     3a18 <f_8001161d0+0x3a18>
    3911:	45 31 c0             	xor    %r8d,%r8d
    3914:	89 f7                	mov    %esi,%edi
    3916:	83 c7 fd             	add    $0xfffffffd,%edi
    3919:	41 0f 94 c0          	sete   %r8b
    391d:	45 31 c9             	xor    %r9d,%r9d
    3920:	83 fe 03             	cmp    $0x3,%esi
    3923:	41 0f 93 c1          	setae  %r9b
    3927:	41 ba 02 00 00 00    	mov    $0x2,%r10d
    392d:	41 29 f2             	sub    %esi,%r10d
    3930:	41 21 f2             	and    %esi,%r10d
    3933:	89 fe                	mov    %edi,%esi
    3935:	81 e6 00 00 00 80    	and    $0x80000000,%esi
    393b:	41 c1 e0 1e          	shl    $0x1e,%r8d
    393f:	41 c1 e1 1d          	shl    $0x1d,%r9d
    3943:	41 09 f1             	or     %esi,%r9d
    3946:	45 09 c1             	or     %r8d,%r9d
    3949:	41 c1 ea 03          	shr    $0x3,%r10d
    394d:	41 81 e2 00 00 00 10 	and    $0x10000000,%r10d
    3954:	45 09 ca             	or     %r9d,%r10d
    3957:	4c 89 93 10 01 00 00 	mov    %r10,0x110(%rbx)
    395e:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
    3962:	85 ff                	test   %edi,%edi
    3964:	0f 85 ea 00 00 00    	jne    3a54 <f_8001161d0+0x3a54>
    396a:	01 c0                	add    %eax,%eax
    396c:	8d 0c 80             	lea    (%rax,%rax,4),%ecx
    396f:	e9 dc 00 00 00       	jmp    3a50 <f_8001161d0+0x3a50>
    3974:	48 83 ec 08          	sub    $0x8,%rsp
    3978:	48 89 df             	mov    %rbx,%rdi
    397b:	31 f6                	xor    %esi,%esi
    397d:	31 d2                	xor    %edx,%edx
    397f:	41 b8 20 00 00 00    	mov    $0x20,%r8d
    3985:	45 31 c9             	xor    %r9d,%r9d
    3988:	6a 00                	push   $0x0
    398a:	e8 00 00 00 00       	call   398f <f_8001161d0+0x398f>
    398f:	48 83 c4 10          	add    $0x10,%rsp
    3993:	48 8b 83 80 00 00 00 	mov    0x80(%rbx),%rax
    399a:	89 c1                	mov    %eax,%ecx
    399c:	48 89 8b 10 02 00 00 	mov    %rcx,0x210(%rbx)
    39a3:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    39aa:	00 00 00 00 
    39ae:	c5 f9 6e c0          	vmovd  %eax,%xmm0
    39b2:	c5 fa 59 83 00 02 00 	vmulss 0x200(%rbx),%xmm0,%xmm0
    39b9:	00 
    39ba:	c5 f9 7e c0          	vmovd  %xmm0,%eax
    39be:	48 89 83 00 02 00 00 	mov    %rax,0x200(%rbx)
    39c5:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    39cc:	00 00 00 00 
    39d0:	48 83 ec 08          	sub    $0x8,%rsp
    39d4:	48 89 df             	mov    %rbx,%rdi
    39d7:	31 f6                	xor    %esi,%esi
    39d9:	31 d2                	xor    %edx,%edx
    39db:	b9 03 00 00 00       	mov    $0x3,%ecx
    39e0:	45 31 c0             	xor    %r8d,%r8d
    39e3:	41 b9 20 00 00 00    	mov    $0x20,%r9d
    39e9:	6a 01                	push   $0x1
    39eb:	e8 00 00 00 00       	call   39f0 <f_8001161d0+0x39f0>
    39f0:	c4 e2 79 59 15 00 00 	vpbroadcastq 0x0(%rip),%xmm2        # 39f9 <f_8001161d0+0x39f9>
    39f7:	00 00 
    39f9:	c5 f1 ef c9          	vpxor  %xmm1,%xmm1,%xmm1
    39fd:	48 83 c4 10          	add    $0x10,%rsp
    3a01:	89 c1                	mov    %eax,%ecx
    3a03:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
    3a07:	48 63 43 08          	movslq 0x8(%rbx),%rax
    3a0b:	48 63 53 78          	movslq 0x78(%rbx),%rdx
    3a0f:	48 0f af d0          	imul   %rax,%rdx
    3a13:	48 03 13             	add    (%rbx),%rdx
    3a16:	eb 3c                	jmp    3a54 <f_8001161d0+0x3a54>
    3a18:	31 f6                	xor    %esi,%esi
    3a1a:	48 85 c9             	test   %rcx,%rcx
    3a1d:	40 0f 94 c6          	sete   %sil
    3a21:	89 c1                	mov    %eax,%ecx
    3a23:	81 e1 00 00 00 80    	and    $0x80000000,%ecx
    3a29:	c1 e6 1e             	shl    $0x1e,%esi
    3a2c:	48 01 f1             	add    %rsi,%rcx
    3a2f:	48 81 c1 00 00 00 20 	add    $0x20000000,%rcx
    3a36:	48 89 8b 10 01 00 00 	mov    %rcx,0x110(%rbx)
    3a3d:	89 c1                	mov    %eax,%ecx
    3a3f:	c1 e9 1f             	shr    $0x1f,%ecx
    3a42:	01 c1                	add    %eax,%ecx
    3a44:	89 c8                	mov    %ecx,%eax
    3a46:	d1 e8                	shr    $1,%eax
    3a48:	81 e1 00 00 00 80    	and    $0x80000000,%ecx
    3a4e:	09 c1                	or     %eax,%ecx
    3a50:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
    3a54:	48 89 13             	mov    %rdx,(%rbx)
    3a57:	89 4a 20             	mov    %ecx,0x20(%rdx)
    3a5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
    3a60:	48 8b 4b 70          	mov    0x70(%rbx),%rcx
    3a64:	8b 01                	mov    (%rcx),%eax
    3a66:	48 89 83 30 01 00 00 	mov    %rax,0x130(%rbx)
    3a6d:	48 89 03             	mov    %rax,(%rbx)
    3a70:	8d 50 01             	lea    0x1(%rax),%edx
    3a73:	48 89 53 08          	mov    %rdx,0x8(%rbx)
    3a77:	48 8b 73 70          	mov    0x70(%rbx),%rsi
    3a7b:	48 c7 83 28 01 00 00 	movq   $0xffffffffffffffff,0x128(%rbx)
    3a82:	ff ff ff ff 
    3a86:	48 39 f1             	cmp    %rsi,%rcx
    3a89:	0f 94 c1             	sete   %cl
    3a8c:	f0 0f b1 16          	lock cmpxchg %edx,(%rsi)
    3a90:	0f 94 c0             	sete   %al
    3a93:	20 c8                	and    %cl,%al
    3a95:	89 c1                	mov    %eax,%ecx
    3a97:	80 f1 01             	xor    $0x1,%cl
    3a9a:	0f b6 c9             	movzbl %cl,%ecx
    3a9d:	48 89 4b 10          	mov    %rcx,0x10(%rbx)
    3aa1:	84 c0                	test   %al,%al
    3aa3:	74 bb                	je     3a60 <f_8001161d0+0x3a60>
    3aa5:	48 8b 03             	mov    (%rbx),%rax
    3aa8:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
    3aaf:	8b 91 84 3b 00 00    	mov    0x3b84(%rcx),%edx
    3ab5:	89 d6                	mov    %edx,%esi
    3ab7:	31 c6                	xor    %eax,%esi
    3ab9:	89 d7                	mov    %edx,%edi
    3abb:	31 c7                	xor    %eax,%edi
    3abd:	48 89 53 08          	mov    %rdx,0x8(%rbx)
    3ac1:	0f 84 38 fc ff ff    	je     36ff <f_8001161d0+0x36ff>
    3ac7:	89 d7                	mov    %edx,%edi
    3ac9:	29 c7                	sub    %eax,%edi
    3acb:	c4 e2 48 f2 ff       	andn   %edi,%esi,%edi
    3ad0:	21 d6                	and    %edx,%esi
    3ad2:	09 fe                	or     %edi,%esi
    3ad4:	0f 88 25 fc ff ff    	js     36ff <f_8001161d0+0x36ff>
    3ada:	48 8b 89 88 3b 00 00 	mov    0x3b88(%rcx),%rcx
    3ae1:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    3ae5:	48 8d 14 c5 00 00 00 	lea    0x0(,%rax,8),%rdx
    3aec:	00 
    3aed:	48 98                	cltq
    3aef:	48 21 e8             	and    %rbp,%rax
    3af2:	49 8d b7 2e a2 3f fd 	lea    -0x2c05dd2(%r15),%rsi
    3af9:	48 21 d6             	and    %rdx,%rsi
    3afc:	48 09 c6             	or     %rax,%rsi
    3aff:	48 89 33             	mov    %rsi,(%rbx)
    3b02:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
    3b09:	48 89 04 31          	mov    %rax,(%rcx,%rsi,1)
    3b0d:	e9 ed fb ff ff       	jmp    36ff <f_8001161d0+0x36ff>
