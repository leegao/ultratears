
/home/leegao/meh/ultratears-main/src/horizon2llvm/benchmark/samples/main_067_statickernel/results/main_067_statickernel_layer_15_pass15_fcmp_fusion.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <f_8001161d0>:
       0:	55                   	push   %rbp
       1:	41 57                	push   %r15
       3:	41 56                	push   %r14
       5:	41 55                	push   %r13
       7:	41 54                	push   %r12
       9:	53                   	push   %rbx
       a:	48 83 ec 28          	sub    $0x28,%rsp
       e:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
      15:	00 00 00 
      18:	48 8b 8f e8 00 00 00 	mov    0xe8(%rdi),%rcx
      1f:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
      26:	4c 8d a0 d0 fe ff ff 	lea    -0x130(%rax),%r12
      2d:	4c 89 a7 00 01 00 00 	mov    %r12,0x100(%rdi)
      34:	48 8d 50 a0          	lea    -0x60(%rax),%rdx
      38:	48 89 48 a0          	mov    %rcx,-0x60(%rax)
      3c:	48 8b 8f f0 00 00 00 	mov    0xf0(%rdi),%rcx
      43:	48 89 48 a8          	mov    %rcx,-0x58(%rax)
      47:	48 8b 8f e0 00 00 00 	mov    0xe0(%rdi),%rcx
      4e:	48 89 48 b0          	mov    %rcx,-0x50(%rax)
      52:	48 8b 8f d8 00 00 00 	mov    0xd8(%rdi),%rcx
      59:	48 89 48 b8          	mov    %rcx,-0x48(%rax)
      5d:	48 8b 8f d0 00 00 00 	mov    0xd0(%rdi),%rcx
      64:	48 89 48 c0          	mov    %rcx,-0x40(%rax)
      68:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
      6f:	48 89 48 c8          	mov    %rcx,-0x38(%rax)
      73:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
      7a:	48 89 48 d0          	mov    %rcx,-0x30(%rax)
      7e:	48 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%rcx
      85:	48 89 48 d8          	mov    %rcx,-0x28(%rax)
      89:	48 8b 8f b0 00 00 00 	mov    0xb0(%rdi),%rcx
      90:	48 89 48 e0          	mov    %rcx,-0x20(%rax)
      94:	48 8b 8f a8 00 00 00 	mov    0xa8(%rdi),%rcx
      9b:	48 89 48 e8          	mov    %rcx,-0x18(%rax)
      9f:	48 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%rcx
      a6:	48 89 48 f0          	mov    %rcx,-0x10(%rax)
      aa:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
      b1:	48 89 48 f8          	mov    %rcx,-0x8(%rax)
      b5:	48 89 97 e8 00 00 00 	mov    %rdx,0xe8(%rdi)
      bc:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
      c0:	48 89 9f a8 00 00 00 	mov    %rbx,0xa8(%rdi)
      c7:	4c 8b 3f             	mov    (%rdi),%r15
      ca:	4c 8b 77 08          	mov    0x8(%rdi),%r14
      ce:	4c 89 b7 98 00 00 00 	mov    %r14,0x98(%rdi)
      d5:	4c 89 bf a0 00 00 00 	mov    %r15,0xa0(%rdi)
      dc:	49 8d 8e 14 29 00 00 	lea    0x2914(%r14),%rcx
      e3:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
      e7:	83 fb 20             	cmp    $0x20,%ebx
      ea:	73 1d                	jae    109 <f_8001161d0+0x109>
      ec:	b9 1f 7d c3 f6       	mov    $0xf6c37d1f,%ecx
      f1:	0f a3 d9             	bt     %ebx,%ecx
      f4:	73 13                	jae    109 <f_8001161d0+0x109>
      f6:	89 d9                	mov    %ebx,%ecx
      f8:	83 e1 1f             	and    $0x1f,%ecx
      fb:	49 8b 8c cd be 6b 16 	mov    0x166bbe(%r13,%rcx,8),%rcx
     102:	00 
     103:	48 c1 e1 08          	shl    $0x8,%rcx
     107:	eb 0e                	jmp    117 <f_8001161d0+0x117>
     109:	31 d2                	xor    %edx,%edx
     10b:	83 fb 12             	cmp    $0x12,%ebx
     10e:	b9 00 03 00 00       	mov    $0x300,%ecx
     113:	48 0f 45 ca          	cmovne %rdx,%rcx
     117:	49 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%r10
     11e:	ff ff ff 
     121:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     128:	ff 7f ff 
     12b:	41 0f be 96 17 29 00 	movsbl 0x2917(%r14),%edx
     132:	00 
     133:	48 63 d2             	movslq %edx,%rdx
     136:	4c 89 a7 c0 00 00 00 	mov    %r12,0xc0(%rdi)
     13d:	48 69 f2 48 07 00 00 	imul   $0x748,%rdx,%rsi
     144:	45 31 c9             	xor    %r9d,%r9d
     147:	41 39 97 90 33 00 00 	cmp    %edx,0x3390(%r15)
     14e:	48 bd ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rbp
     155:	ff 7f 7f 
     158:	4c 0f 47 ce          	cmova  %rsi,%r9
     15c:	49 bb 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r11
     163:	00 80 3f 
     166:	48 be 00 00 00 00 01 	movabs $0x100000000,%rsi
     16d:	00 00 00 
     170:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
     175:	4d 03 8f 98 33 00 00 	add    0x3398(%r15),%r9
     17c:	48 c7 47 70 ff ff ff 	movq   $0xffffffffffffffff,0x70(%rdi)
     183:	ff 
     184:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 18c <f_8001161d0+0x18c>
     18b:	00 
     18c:	c5 fc 11 80 d0 fe ff 	vmovups %ymm0,-0x130(%rax)
     193:	ff 
     194:	ba ff ff ff ff       	mov    $0xffffffff,%edx
     199:	48 89 57 78          	mov    %rdx,0x78(%rdi)
     19d:	48 89 b0 f0 fe ff ff 	mov    %rsi,-0x110(%rax)
     1a4:	4c 89 90 f8 fe ff ff 	mov    %r10,-0x108(%rax)
     1ab:	4a 8d 8c 09 e8 01 00 	lea    0x1e8(%rcx,%r9,1),%rcx
     1b2:	00 
     1b3:	48 89 8f b8 00 00 00 	mov    %rcx,0xb8(%rdi)
     1ba:	48 89 90 00 ff ff ff 	mov    %rdx,-0x100(%rax)
     1c1:	4c 89 98 08 ff ff ff 	mov    %r11,-0xf8(%rax)
     1c8:	48 89 6f 58          	mov    %rbp,0x58(%rdi)
     1cc:	31 d2                	xor    %edx,%edx
     1ce:	89 de                	mov    %ebx,%esi
     1d0:	83 c6 df             	add    $0xffffffdf,%esi
     1d3:	0f 94 c2             	sete   %dl
     1d6:	31 c9                	xor    %ecx,%ecx
     1d8:	83 fb 21             	cmp    $0x21,%ebx
     1db:	0f 93 c1             	setae  %cl
     1de:	41 b9 20 00 00 00    	mov    $0x20,%r9d
     1e4:	41 29 d9             	sub    %ebx,%r9d
     1e7:	41 21 d9             	and    %ebx,%r9d
     1ea:	81 e6 00 00 00 80    	and    $0x80000000,%esi
     1f0:	c1 e2 1e             	shl    $0x1e,%edx
     1f3:	c1 e1 1d             	shl    $0x1d,%ecx
     1f6:	09 f1                	or     %esi,%ecx
     1f8:	09 d1                	or     %edx,%ecx
     1fa:	41 c1 e9 03          	shr    $0x3,%r9d
     1fe:	41 81 e1 00 00 00 10 	and    $0x10000000,%r9d
     205:	41 09 c9             	or     %ecx,%r9d
     208:	4c 89 8f 10 01 00 00 	mov    %r9,0x110(%rdi)
     20f:	4c 89 98 10 ff ff ff 	mov    %r11,-0xf0(%rax)
     216:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     21d:	00 00 00 00 
     221:	4d 8b 8d 7e 86 d5 00 	mov    0xd5867e(%r13),%r9
     228:	4c 89 4f 50          	mov    %r9,0x50(%rdi)
     22c:	49 8b b5 ae 5d d4 00 	mov    0xd45dae(%r13),%rsi
     233:	48 89 77 48          	mov    %rsi,0x48(%rdi)
     237:	49 8d 51 10          	lea    0x10(%r9),%rdx
     23b:	48 89 90 20 ff ff ff 	mov    %rdx,-0xe0(%rax)
     242:	48 89 b0 40 ff ff ff 	mov    %rsi,-0xc0(%rax)
     249:	4d 8b bd b6 7e d5 00 	mov    0xd57eb6(%r13),%r15
     250:	4c 89 7f 60          	mov    %r15,0x60(%rdi)
     254:	49 83 c7 10          	add    $0x10,%r15
     258:	4c 89 bf 80 00 00 00 	mov    %r15,0x80(%rdi)
     25f:	48 89 a8 48 ff ff ff 	mov    %rbp,-0xb8(%rax)
     266:	4c 89 80 50 ff ff ff 	mov    %r8,-0xb0(%rax)
     26d:	49 8d b3 00 00 80 c0 	lea    -0x3f800000(%r11),%rsi
     274:	48 89 b0 74 ff ff ff 	mov    %rsi,-0x8c(%rax)
     27b:	4d 8b 9d c6 7d d5 00 	mov    0xd57dc6(%r13),%r11
     282:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
     289:	45 8b 13             	mov    (%r11),%r10d
     28c:	4c 89 57 40          	mov    %r10,0x40(%rdi)
     290:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
     295:	4c 89 b8 58 ff ff ff 	mov    %r15,-0xa8(%rax)
     29c:	48 89 a8 60 ff ff ff 	mov    %rbp,-0xa0(%rax)
     2a3:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     2aa:	00 
     2ab:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     2af:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     2b6:	44 89 90 70 ff ff ff 	mov    %r10d,-0x90(%rax)
     2bd:	81 e1 00 00 00 60    	and    $0x60000000,%ecx
     2c3:	81 f9 00 00 00 20    	cmp    $0x20000000,%ecx
     2c9:	0f 84 6a 29 00 00    	je     2c39 <f_8001161d0+0x2c39>
     2cf:	48 89 d5             	mov    %rdx,%rbp
     2d2:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
     2d7:	48 8d 90 48 ff ff ff 	lea    -0xb8(%rax),%rdx
     2de:	4c 8d 98 60 ff ff ff 	lea    -0xa0(%rax),%r11
     2e5:	48 8d 70 80          	lea    -0x80(%rax),%rsi
     2e9:	4c 8d 80 70 ff ff ff 	lea    -0x90(%rax),%r8
     2f0:	49 8d 8d 76 6b 16 00 	lea    0x166b76(%r13),%rcx
     2f7:	48 89 8f 88 00 00 00 	mov    %rcx,0x88(%rdi)
     2fe:	89 db                	mov    %ebx,%ebx
     300:	48 89 9f 90 00 00 00 	mov    %rbx,0x90(%rdi)
     307:	4c 89 a7 80 00 00 00 	mov    %r12,0x80(%rdi)
     30e:	41 0f b7 8c 5d 76 6b 	movzwl 0x166b76(%r13,%rbx,2),%ecx
     315:	16 00 
     317:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
     31b:	4d 8d a4 8d 52 05 51 	lea    -0x2aefaae(%r13,%rcx,4),%r12
     322:	fd 
     323:	4d 89 dd             	mov    %r11,%r13
     326:	4c 89 27             	mov    %r12,(%rdi)
     329:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
     32e:	48 89 57 48          	mov    %rdx,0x48(%rdi)
     332:	4c 89 9f d0 00 00 00 	mov    %r11,0xd0(%rdi)
     339:	4c 89 87 c8 00 00 00 	mov    %r8,0xc8(%rdi)
     340:	48 89 b7 d8 00 00 00 	mov    %rsi,0xd8(%rdi)
     347:	81 f9 86 02 00 00    	cmp    $0x286,%ecx
     34d:	7f 6d                	jg     3bc <f_8001161d0+0x3bc>
     34f:	81 f9 2d 01 00 00    	cmp    $0x12d,%ecx
     355:	0f 8f fa 00 00 00    	jg     455 <f_8001161d0+0x455>
     35b:	83 f9 6f             	cmp    $0x6f,%ecx
     35e:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     365:	ff 7f ff 
     368:	49 89 ef             	mov    %rbp,%r15
     36b:	4d 89 d3             	mov    %r10,%r11
     36e:	0f 8f 67 04 00 00    	jg     7db <f_8001161d0+0x7db>
     374:	83 f9 04             	cmp    $0x4,%ecx
     377:	0f 87 ee 10 00 00    	ja     146b <f_8001161d0+0x146b>
     37d:	89 c9                	mov    %ecx,%ecx
     37f:	48 8d 35 00 00 00 00 	lea    0x0(%rip),%rsi        # 386 <f_8001161d0+0x386>
     386:	48 63 0c 8e          	movslq (%rsi,%rcx,4),%rcx
     38a:	48 01 f1             	add    %rsi,%rcx
     38d:	ff e1                	jmp    *%rcx
     38f:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
     394:	0f b7 99 e4 0c 00 00 	movzwl 0xce4(%rcx),%ebx
     39b:	8b 8f a8 00 00 00    	mov    0xa8(%rdi),%ecx
     3a1:	be ff ff ff ff       	mov    $0xffffffff,%esi
     3a6:	01 f1                	add    %esi,%ecx
     3a8:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
     3ac:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
     3b3:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
     3b7:	e9 19 15 00 00       	jmp    18d5 <f_8001161d0+0x18d5>
     3bc:	81 f9 6d 04 00 00    	cmp    $0x46d,%ecx
     3c2:	0f 8e be 02 00 00    	jle    686 <f_8001161d0+0x686>
     3c8:	44 8d 89 92 fb ff ff 	lea    -0x46e(%rcx),%r9d
     3cf:	41 83 f9 0c          	cmp    $0xc,%r9d
     3d3:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     3da:	ff 7f ff 
     3dd:	48 89 ea             	mov    %rbp,%rdx
     3e0:	4d 89 d3             	mov    %r10,%r11
     3e3:	0f 86 1a 08 00 00    	jbe    c03 <f_8001161d0+0xc03>
     3e9:	44 8d 89 36 fb ff ff 	lea    -0x4ca(%rcx),%r9d
     3f0:	41 83 f9 16          	cmp    $0x16,%r9d
     3f4:	0f 87 15 10 00 00    	ja     140f <f_8001161d0+0x140f>
     3fa:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 401 <f_8001161d0+0x401>
     401:	4a 63 34 89          	movslq (%rcx,%r9,4),%rsi
     405:	48 01 ce             	add    %rcx,%rsi
     408:	ff e6                	jmp    *%rsi
     40a:	48 c7 47 40 b0 1e 00 	movq   $0x1eb0,0x40(%rdi)
     411:	00 
     412:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
     419:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
     420:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
     424:	48 89 47 10          	mov    %rax,0x10(%rdi)
     428:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
     42d:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
     434:	48 89 07             	mov    %rax,(%rdi)
     437:	48 c7 47 18 01 00 00 	movq   $0x1,0x18(%rdi)
     43e:	00 
     43f:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     446:	00 00 00 
     449:	49 8d 85 92 18 51 fd 	lea    -0x2aee76e(%r13),%rax
     450:	e9 26 18 00 00       	jmp    1c7b <f_8001161d0+0x1c7b>
     455:	81 f9 c7 01 00 00    	cmp    $0x1c7,%ecx
     45b:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     462:	ff 7f ff 
     465:	49 89 ef             	mov    %rbp,%r15
     468:	4d 89 d3             	mov    %r10,%r11
     46b:	0f 8f 42 06 00 00    	jg     ab3 <f_8001161d0+0xab3>
     471:	81 f9 b1 01 00 00    	cmp    $0x1b1,%ecx
     477:	0f 8f bb 0a 00 00    	jg     f38 <f_8001161d0+0xf38>
     47d:	81 f9 2e 01 00 00    	cmp    $0x12e,%ecx
     483:	0f 84 a2 1d 00 00    	je     222b <f_8001161d0+0x222b>
     489:	81 f9 66 01 00 00    	cmp    $0x166,%ecx
     48f:	0f 85 83 17 00 00    	jne    1c18 <f_8001161d0+0x1c18>
     495:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
     49c:	48 8b b7 a0 00 00 00 	mov    0xa0(%rdi),%rsi
     4a3:	48 8b b6 c8 1e 00 00 	mov    0x1ec8(%rsi),%rsi
     4aa:	48 89 77 08          	mov    %rsi,0x8(%rdi)
     4ae:	48 c7 87 80 00 00 00 	movq   $0x3ce0,0x80(%rdi)
     4b5:	e0 3c 00 00 
     4b9:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
     4be:	48 89 57 60          	mov    %rdx,0x60(%rdi)
     4c2:	44 0f b6 49 08       	movzbl 0x8(%rcx),%r9d
     4c7:	4c 89 4f 68          	mov    %r9,0x68(%rdi)
     4cb:	49 69 d9 e0 3c 00 00 	imul   $0x3ce0,%r9,%rbx
     4d2:	31 c9                	xor    %ecx,%ecx
     4d4:	44 39 4e 08          	cmp    %r9d,0x8(%rsi)
     4d8:	48 0f 46 d9          	cmovbe %rcx,%rbx
     4dc:	48 8b 76 10          	mov    0x10(%rsi),%rsi
     4e0:	48 8b b4 33 40 3c 00 	mov    0x3c40(%rbx,%rsi,1),%rsi
     4e7:	00 
     4e8:	48 89 b7 b0 00 00 00 	mov    %rsi,0xb0(%rdi)
     4ef:	4c 8b 8f 00 01 00 00 	mov    0x100(%rdi),%r9
     4f6:	45 89 99 a0 00 00 00 	mov    %r11d,0xa0(%r9)
     4fd:	49 89 91 88 00 00 00 	mov    %rdx,0x88(%r9)
     504:	48 be ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rsi
     50b:	ff 7f 7f 
     50e:	49 89 b1 90 00 00 00 	mov    %rsi,0x90(%r9)
     515:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     51c:	00 
     51d:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     521:	41 c7 81 bc 00 00 00 	movl   $0x0,0xbc(%r9)
     528:	00 00 00 00 
     52c:	49 c7 41 48 00 00 00 	movq   $0x0,0x48(%r9)
     533:	00 
     534:	4d 89 79 50          	mov    %r15,0x50(%r9)
     538:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     53c:	c4 c1 78 11 41 58    	vmovups %xmm0,0x58(%r9)
     542:	49 c7 41 30 08 00 00 	movq   $0x8,0x30(%r9)
     549:	00 
     54a:	48 b8 10 00 00 00 03 	movabs $0x300000010,%rax
     551:	00 00 00 
     554:	49 89 01             	mov    %rax,(%r9)
     557:	49 c7 41 08 00 00 00 	movq   $0x0,0x8(%r9)
     55e:	00 
     55f:	49 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%r9)
     566:	00 
     567:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     56e:	ff ff ff 
     571:	48 8d 42 0d          	lea    0xd(%rdx),%rax
     575:	49 89 41 18          	mov    %rax,0x18(%r9)
     579:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     580:	00 00 00 
     583:	49 89 41 20          	mov    %rax,0x20(%r9)
     587:	49 89 51 28          	mov    %rdx,0x28(%r9)
     58b:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
     592:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
     597:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
     59e:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
     5a5:	00 80 3f 
     5a8:	49 89 41 38          	mov    %rax,0x38(%r9)
     5ac:	49 89 41 40          	mov    %rax,0x40(%r9)
     5b0:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     5b7:	00 00 00 
     5ba:	49 8d 85 8b 0d 02 00 	lea    0x20d8b(%r13),%rax
     5c1:	48 89 47 70          	mov    %rax,0x70(%rdi)
     5c5:	4c 89 47 78          	mov    %r8,0x78(%rdi)
     5c9:	4d 89 81 98 00 00 00 	mov    %r8,0x98(%r9)
     5d0:	48 8b 57 58          	mov    0x58(%rdi),%rdx
     5d4:	49 89 51 78          	mov    %rdx,0x78(%r9)
     5d8:	4d 89 81 80 00 00 00 	mov    %r8,0x80(%r9)
     5df:	49 c7 41 68 00 00 00 	movq   $0x0,0x68(%r9)
     5e6:	00 
     5e7:	49 89 41 70          	mov    %rax,0x70(%r9)
     5eb:	48 8b 47 08          	mov    0x8(%rdi),%rax
     5ef:	48 8b 57 48          	mov    0x48(%rdi),%rdx
     5f3:	4c 8b 40 10          	mov    0x10(%rax),%r8
     5f7:	4c 8b 57 68          	mov    0x68(%rdi),%r10
     5fb:	44 39 50 08          	cmp    %r10d,0x8(%rax)
     5ff:	4c 89 d6             	mov    %r10,%rsi
     602:	48 0f 46 f1          	cmovbe %rcx,%rsi
     606:	48 89 77 40          	mov    %rsi,0x40(%rdi)
     60a:	41 89 f1             	mov    %esi,%r9d
     60d:	8b b7 80 00 00 00    	mov    0x80(%rdi),%esi
     613:	4c 0f af ce          	imul   %rsi,%r9
     617:	c4 81 78 10 84 01 00 	vmovups 0x2e00(%r9,%r8,1),%xmm0
     61e:	2e 00 00 
     621:	c5 f8 11 02          	vmovups %xmm0,(%rdx)
     625:	44 8b 40 08          	mov    0x8(%rax),%r8d
     629:	45 31 db             	xor    %r11d,%r11d
     62c:	44 89 c3             	mov    %r8d,%ebx
     62f:	44 31 d3             	xor    %r10d,%ebx
     632:	41 0f 94 c3          	sete   %r11b
     636:	45 31 c9             	xor    %r9d,%r9d
     639:	44 89 c5             	mov    %r8d,%ebp
     63c:	44 29 d5             	sub    %r10d,%ebp
     63f:	44 89 d2             	mov    %r10d,%edx
     642:	48 0f 46 d1          	cmovbe %rcx,%rdx
     646:	41 0f 93 c1          	setae  %r9b
     64a:	41 31 e8             	xor    %ebp,%r8d
     64d:	41 21 d8             	and    %ebx,%r8d
     650:	41 c1 e3 1e          	shl    $0x1e,%r11d
     654:	41 c1 e1 1d          	shl    $0x1d,%r9d
     658:	45 09 d9             	or     %r11d,%r9d
     65b:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
     661:	41 09 e9             	or     %ebp,%r9d
     664:	41 c1 e8 03          	shr    $0x3,%r8d
     668:	41 81 e0 00 00 00 10 	and    $0x10000000,%r8d
     66f:	45 09 c8             	or     %r9d,%r8d
     672:	48 0f af d6          	imul   %rsi,%rdx
     676:	48 03 50 10          	add    0x10(%rax),%rdx
     67a:	4c 89 87 10 01 00 00 	mov    %r8,0x110(%rdi)
     681:	e9 99 1d 00 00       	jmp    241f <f_8001161d0+0x241f>
     686:	81 f9 d4 02 00 00    	cmp    $0x2d4,%ecx
     68c:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
     693:	ff 7f ff 
     696:	49 89 ef             	mov    %rbp,%r15
     699:	4d 89 d3             	mov    %r10,%r11
     69c:	0f 8f b7 04 00 00    	jg     b59 <f_8001161d0+0xb59>
     6a2:	81 f9 b5 02 00 00    	cmp    $0x2b5,%ecx
     6a8:	0f 8f 28 09 00 00    	jg     fd6 <f_8001161d0+0xfd6>
     6ae:	81 f9 87 02 00 00    	cmp    $0x287,%ecx
     6b4:	0f 84 47 1e 00 00    	je     2501 <f_8001161d0+0x2501>
     6ba:	81 f9 97 02 00 00    	cmp    $0x297,%ecx
     6c0:	0f 85 52 15 00 00    	jne    1c18 <f_8001161d0+0x1c18>
     6c6:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
     6cd:	44 89 99 a0 00 00 00 	mov    %r11d,0xa0(%rcx)
     6d4:	48 c7 01 00 00 00 40 	movq   $0x40000000,(%rcx)
     6db:	48 be 00 00 00 00 00 	movabs $0x40000000000000,%rsi
     6e2:	00 40 00 
     6e5:	48 89 71 08          	mov    %rsi,0x8(%rcx)
     6e9:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     6f0:	00 
     6f1:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
     6f8:	ff ff ff 
     6fb:	4d 89 c1             	mov    %r8,%r9
     6fe:	49 89 f0             	mov    %rsi,%r8
     701:	48 83 c6 14          	add    $0x14,%rsi
     705:	48 89 71 18          	mov    %rsi,0x18(%rcx)
     709:	4c 89 7f 40          	mov    %r15,0x40(%rdi)
     70d:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     711:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     718:	00 
     719:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
     720:	00 00 00 
     723:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     72a:	00 00 00 
     72d:	48 89 41 20          	mov    %rax,0x20(%rcx)
     731:	4c 89 41 28          	mov    %r8,0x28(%rcx)
     735:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
     73a:	48 89 41 30          	mov    %rax,0x30(%rcx)
     73e:	48 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rsi
     745:	00 80 3f 
     748:	48 89 71 38          	mov    %rsi,0x38(%rcx)
     74c:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
     753:	00 00 00 
     756:	48 8d 80 80 0d 02 00 	lea    0x20d80(%rax),%rax
     75d:	48 89 41 70          	mov    %rax,0x70(%rcx)
     761:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
     768:	ff 7f 7f 
     76b:	4c 89 59 78          	mov    %r11,0x78(%rcx)
     76f:	4c 89 89 80 00 00 00 	mov    %r9,0x80(%rcx)
     776:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
     77b:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
     782:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 78a <f_8001161d0+0x78a>
     789:	00 
     78a:	c5 fc 11 47 60       	vmovups %ymm0,0x60(%rdi)
     78f:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
     796:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
     79b:	4c 89 80 a4 00 00 00 	mov    %r8,0xa4(%rax)
     7a2:	48 89 71 40          	mov    %rsi,0x40(%rcx)
     7a6:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
     7ad:	00 
     7ae:	4c 89 99 90 00 00 00 	mov    %r11,0x90(%rcx)
     7b5:	4c 89 89 98 00 00 00 	mov    %r9,0x98(%rcx)
     7bc:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
     7c3:	00 
     7c4:	4c 89 79 50          	mov    %r15,0x50(%rcx)
     7c8:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     7cc:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
     7d1:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
     7d6:	e9 40 23 00 00       	jmp    2b1b <f_8001161d0+0x2b1b>
     7db:	81 f9 c8 00 00 00    	cmp    $0xc8,%ecx
     7e1:	0f 8f 3f 04 00 00    	jg     c26 <f_8001161d0+0xc26>
     7e7:	83 f9 70             	cmp    $0x70,%ecx
     7ea:	0f 84 42 17 00 00    	je     1f32 <f_8001161d0+0x1f32>
     7f0:	81 f9 80 00 00 00    	cmp    $0x80,%ecx
     7f6:	0f 85 1c 14 00 00    	jne    1c18 <f_8001161d0+0x1c18>
     7fc:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
     801:	48 8b 99 c8 1e 00 00 	mov    0x1ec8(%rcx),%rbx
     808:	48 89 5f 08          	mov    %rbx,0x8(%rdi)
     80c:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
     811:	48 89 57 60          	mov    %rdx,0x60(%rdi)
     815:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
     81c:	00 
     81d:	45 0f b6 76 08       	movzbl 0x8(%r14),%r14d
     822:	4c 89 77 68          	mov    %r14,0x68(%rdi)
     826:	8b 73 08             	mov    0x8(%rbx),%esi
     829:	4d 89 fc             	mov    %r15,%r12
     82c:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
     830:	4d 69 ce e0 3c 00 00 	imul   $0x3ce0,%r14,%r9
     837:	31 c9                	xor    %ecx,%ecx
     839:	44 39 f6             	cmp    %r14d,%esi
     83c:	be 00 00 00 00       	mov    $0x0,%esi
     841:	49 0f 47 f1          	cmova  %r9,%rsi
     845:	48 c7 47 70 e0 3c 00 	movq   $0x3ce0,0x70(%rdi)
     84c:	00 
     84d:	4a 8b b4 3e 40 3c 00 	mov    0x3c40(%rsi,%r15,1),%rsi
     854:	00 
     855:	48 89 b7 b0 00 00 00 	mov    %rsi,0xb0(%rdi)
     85c:	44 89 98 70 ff ff ff 	mov    %r11d,-0x90(%rax)
     863:	48 89 90 58 ff ff ff 	mov    %rdx,-0xa8(%rax)
     86a:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     871:	ff 7f 7f 
     874:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
     87b:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     882:	00 
     883:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     887:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     88e:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     895:	00 00 00 00 
     899:	4c 89 a0 20 ff ff ff 	mov    %r12,-0xe0(%rax)
     8a0:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     8a4:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
     8ab:	ff 
     8ac:	48 c7 80 00 ff ff ff 	movq   $0x5,-0x100(%rax)
     8b3:	05 00 00 00 
     8b7:	48 ba 10 00 00 00 03 	movabs $0x300000010,%rdx
     8be:	00 00 00 
     8c1:	48 81 c2 f0 00 00 00 	add    $0xf0,%rdx
     8c8:	48 89 90 d0 fe ff ff 	mov    %rdx,-0x130(%rax)
     8cf:	48 ba 00 00 00 00 00 	movabs $0x60000000000000,%rdx
     8d6:	00 60 00 
     8d9:	48 89 90 d8 fe ff ff 	mov    %rdx,-0x128(%rax)
     8e0:	48 89 37             	mov    %rsi,(%rdi)
     8e3:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     8ea:	ff ff 00 00 
     8ee:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     8f5:	ff ff ff 
     8f8:	48 8d 55 08          	lea    0x8(%rbp),%rdx
     8fc:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
     903:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
     90a:	00 00 00 
     90d:	48 89 90 f0 fe ff ff 	mov    %rdx,-0x110(%rax)
     914:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
     91b:	48 8b 97 c0 00 00 00 	mov    0xc0(%rdi),%rdx
     922:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
     927:	48 89 b2 a4 00 00 00 	mov    %rsi,0xa4(%rdx)
     92e:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
     935:	00 80 3f 
     938:	48 89 90 08 ff ff ff 	mov    %rdx,-0xf8(%rax)
     93f:	48 89 90 10 ff ff ff 	mov    %rdx,-0xf0(%rax)
     946:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     94d:	00 00 00 
     950:	49 8d 95 1d 54 09 00 	lea    0x9541d(%r13),%rdx
     957:	48 89 57 78          	mov    %rdx,0x78(%rdi)
     95b:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
     962:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
     969:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
     970:	4c 89 80 50 ff ff ff 	mov    %r8,-0xb0(%rax)
     977:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
     97e:	00 00 00 00 
     982:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
     989:	44 39 73 08          	cmp    %r14d,0x8(%rbx)
     98d:	ba 00 00 00 00       	mov    $0x0,%edx
     992:	49 0f 47 d1          	cmova  %r9,%rdx
     996:	48 8b 73 10          	mov    0x10(%rbx),%rsi
     99a:	c5 f8 10 84 16 00 2e 	vmovups 0x2e00(%rsi,%rdx,1),%xmm0
     9a1:	00 00 
     9a3:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
     9aa:	ff 
     9ab:	8b 73 08             	mov    0x8(%rbx),%esi
     9ae:	45 31 c0             	xor    %r8d,%r8d
     9b1:	31 d2                	xor    %edx,%edx
     9b3:	41 89 f2             	mov    %esi,%r10d
     9b6:	45 29 f2             	sub    %r14d,%r10d
     9b9:	49 0f 47 c9          	cmova  %r9,%rcx
     9bd:	41 0f 94 c0          	sete   %r8b
     9c1:	0f 93 c2             	setae  %dl
     9c4:	41 c1 e0 1e          	shl    $0x1e,%r8d
     9c8:	c1 e2 1d             	shl    $0x1d,%edx
     9cb:	44 09 c2             	or     %r8d,%edx
     9ce:	c4 e2 28 f2 f6       	andn   %esi,%r10d,%esi
     9d3:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
     9da:	44 09 d2             	or     %r10d,%edx
     9dd:	4c 8b 43 10          	mov    0x10(%rbx),%r8
     9e1:	c1 ee 03             	shr    $0x3,%esi
     9e4:	81 e6 00 00 00 10    	and    $0x10000000,%esi
     9ea:	09 d6                	or     %edx,%esi
     9ec:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
     9f3:	49 8b 94 08 80 30 00 	mov    0x3080(%r8,%rcx,1),%rdx
     9fa:	00 
     9fb:	49 8b b4 08 88 30 00 	mov    0x3088(%r8,%rcx,1),%rsi
     a02:	00 
     a03:	48 89 77 50          	mov    %rsi,0x50(%rdi)
     a07:	48 89 90 60 ff ff ff 	mov    %rdx,-0xa0(%rax)
     a0e:	48 89 b0 68 ff ff ff 	mov    %rsi,-0x98(%rax)
     a15:	49 8b 94 08 90 30 00 	mov    0x3090(%r8,%rcx,1),%rdx
     a1c:	00 
     a1d:	48 89 57 48          	mov    %rdx,0x48(%rdi)
     a21:	41 8b 8c 08 98 30 00 	mov    0x3098(%r8,%rcx,1),%ecx
     a28:	00 
     a29:	89 88 78 ff ff ff    	mov    %ecx,-0x88(%rax)
     a2f:	48 8b 8f e8 00 00 00 	mov    0xe8(%rdi),%rcx
     a36:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
     a3a:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
     a3e:	48 89 90 70 ff ff ff 	mov    %rdx,-0x90(%rax)
     a45:	49 8d 85 56 08 51 fd 	lea    -0x2aef7aa(%r13),%rax
     a4c:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
     a53:	48 89 fb             	mov    %rdi,%rbx
     a56:	c5 f8 77             	vzeroupper
     a59:	e8 00 00 00 00       	call   a5e <f_8001161d0+0xa5e>
     a5e:	48 89 df             	mov    %rbx,%rdi
     a61:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     a68:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
     a6f:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     a76:	48 89 01             	mov    %rax,(%rcx)
     a79:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     a80:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     a87:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
     a8b:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
     a92:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     a96:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     a9c:	48 89 43 40          	mov    %rax,0x40(%rbx)
     aa0:	88 51 08             	mov    %dl,0x8(%rcx)
     aa3:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     aaa:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
     aae:	e9 34 1a 00 00       	jmp    24e7 <f_8001161d0+0x24e7>
     ab3:	81 f9 51 02 00 00    	cmp    $0x251,%ecx
     ab9:	0f 8f bb 05 00 00    	jg     107a <f_8001161d0+0x107a>
     abf:	81 f9 c8 01 00 00    	cmp    $0x1c8,%ecx
     ac5:	0f 84 bc 1a 00 00    	je     2587 <f_8001161d0+0x2587>
     acb:	81 f9 0f 02 00 00    	cmp    $0x20f,%ecx
     ad1:	0f 85 41 11 00 00    	jne    1c18 <f_8001161d0+0x1c18>
     ad7:	4d 89 fc             	mov    %r15,%r12
     ada:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
     ae1:	00 
     ae2:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
     ae9:	48 c7 01 00 08 00 00 	movq   $0x800,(%rcx)
     af0:	48 c7 41 08 01 00 00 	movq   $0x1,0x8(%rcx)
     af7:	00 
     af8:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     aff:	ff ff ff 
     b02:	48 8d 75 0b          	lea    0xb(%rbp),%rsi
     b06:	48 89 77 68          	mov    %rsi,0x68(%rdi)
     b0a:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
     b11:	00 
     b12:	48 89 71 18          	mov    %rsi,0x18(%rcx)
     b16:	49 bf 00 00 00 00 01 	movabs $0x100000000,%r15
     b1d:	00 00 00 
     b20:	4c 89 79 20          	mov    %r15,0x20(%rcx)
     b24:	48 89 69 28          	mov    %rbp,0x28(%rcx)
     b28:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
     b2f:	00 80 3f 
     b32:	4c 89 77 70          	mov    %r14,0x70(%rdi)
     b36:	be ff ff ff ff       	mov    $0xffffffff,%esi
     b3b:	48 89 71 30          	mov    %rsi,0x30(%rcx)
     b3f:	4c 89 71 38          	mov    %r14,0x38(%rcx)
     b43:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     b4a:	00 00 00 
     b4d:	49 8d 9d 07 a8 04 00 	lea    0x4a807(%r13),%rbx
     b54:	e9 0b 15 00 00       	jmp    2064 <f_8001161d0+0x2064>
     b59:	81 f9 ac 03 00 00    	cmp    $0x3ac,%ecx
     b5f:	0f 8f 88 06 00 00    	jg     11ed <f_8001161d0+0x11ed>
     b65:	81 f9 d5 02 00 00    	cmp    $0x2d5,%ecx
     b6b:	0f 84 9f 1c 00 00    	je     2810 <f_8001161d0+0x2810>
     b71:	81 f9 f3 02 00 00    	cmp    $0x2f3,%ecx
     b77:	0f 85 9b 10 00 00    	jne    1c18 <f_8001161d0+0x1c18>
     b7d:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
     b84:	00 
     b85:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
     b8c:	48 c7 03 00 02 00 00 	movq   $0x200,(%rbx)
     b93:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
     b9a:	00 40 00 
     b9d:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     ba1:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
     ba8:	00 
     ba9:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
     bb0:	ff ff ff 
     bb3:	48 8d 4e 13          	lea    0x13(%rsi),%rcx
     bb7:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
     bbb:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     bc2:	00 00 00 
     bc5:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
     bc9:	48 89 73 28          	mov    %rsi,0x28(%rbx)
     bcd:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
     bd3:	4c 89 47 68          	mov    %r8,0x68(%rdi)
     bd7:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
     bde:	00 80 3f 
     be1:	4c 89 77 70          	mov    %r14,0x70(%rdi)
     be5:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
     be9:	48 83 c3 38          	add    $0x38,%rbx
     bed:	48 be ca 5d c0 02 08 	movabs $0x802c05dca,%rsi
     bf4:	00 00 00 
     bf7:	4c 8d 8e f9 7a ff ff 	lea    -0x8507(%rsi),%r9
     bfe:	e9 67 1e 00 00       	jmp    2a6a <f_8001161d0+0x2a6a>
     c03:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # c0a <f_8001161d0+0xc0a>
     c0a:	4a 63 34 89          	movslq (%rcx,%r9,4),%rsi
     c0e:	48 01 ce             	add    %rcx,%rsi
     c11:	ff e6                	jmp    *%rsi
     c13:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     c1a:	00 00 00 
     c1d:	49 8d 5d e0          	lea    -0x20(%r13),%rbx
     c21:	e9 1d 09 00 00       	jmp    1543 <f_8001161d0+0x1543>
     c26:	81 f9 c9 00 00 00    	cmp    $0xc9,%ecx
     c2c:	0f 84 98 13 00 00    	je     1fca <f_8001161d0+0x1fca>
     c32:	81 f9 d9 00 00 00    	cmp    $0xd9,%ecx
     c38:	0f 85 da 0f 00 00    	jne    1c18 <f_8001161d0+0x1c18>
     c3e:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
     c43:	48 8b 99 c8 1e 00 00 	mov    0x1ec8(%rcx),%rbx
     c4a:	48 89 5f 08          	mov    %rbx,0x8(%rdi)
     c4e:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
     c53:	48 89 57 60          	mov    %rdx,0x60(%rdi)
     c57:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
     c5e:	00 
     c5f:	45 0f b6 4e 08       	movzbl 0x8(%r14),%r9d
     c64:	4c 89 4f 70          	mov    %r9,0x70(%rdi)
     c68:	41 0f b7 ae 14 29 00 	movzwl 0x2914(%r14),%ebp
     c6f:	00 
     c70:	83 e5 40             	and    $0x40,%ebp
     c73:	8b 73 08             	mov    0x8(%rbx),%esi
     c76:	4c 8b 73 10          	mov    0x10(%rbx),%r14
     c7a:	31 c9                	xor    %ecx,%ecx
     c7c:	44 39 ce             	cmp    %r9d,%esi
     c7f:	be 00 00 00 00       	mov    $0x0,%esi
     c84:	49 0f 47 f1          	cmova  %r9,%rsi
     c88:	48 c7 47 78 e0 3c 00 	movq   $0x3ce0,0x78(%rdi)
     c8f:	00 
     c90:	48 89 b7 88 00 00 00 	mov    %rsi,0x88(%rdi)
     c97:	48 69 f6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rsi
     c9e:	4a 8b b4 36 40 3c 00 	mov    0x3c40(%rsi,%r14,1),%rsi
     ca5:	00 
     ca6:	48 89 b7 b0 00 00 00 	mov    %rsi,0xb0(%rdi)
     cad:	4c 8b b7 a0 00 00 00 	mov    0xa0(%rdi),%r14
     cb4:	4d 8b b6 b8 1e 00 00 	mov    0x1eb8(%r14),%r14
     cbb:	44 89 98 70 ff ff ff 	mov    %r11d,-0x90(%rax)
     cc2:	48 89 90 58 ff ff ff 	mov    %rdx,-0xa8(%rax)
     cc9:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
     cd0:	ff 7f 7f 
     cd3:	4c 89 98 60 ff ff ff 	mov    %r11,-0xa0(%rax)
     cda:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     ce1:	00 
     ce2:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     ce6:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     ced:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     cf1:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
     cf8:	ff 
     cf9:	41 80 be b0 06 00 00 	cmpb   $0x0,0x6b0(%r14)
     d00:	00 
     d01:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     d08:	00 00 00 00 
     d0c:	4c 89 b8 20 ff ff ff 	mov    %r15,-0xe0(%rax)
     d13:	48 c7 80 00 ff ff ff 	movq   $0x4,-0x100(%rax)
     d1a:	04 00 00 00 
     d1e:	48 89 37             	mov    %rsi,(%rdi)
     d21:	0f 95 c2             	setne  %dl
     d24:	c1 ed 06             	shr    $0x6,%ebp
     d27:	40 20 d5             	and    %dl,%bpl
     d2a:	c7 80 d8 fe ff ff 00 	movl   $0x0,-0x128(%rax)
     d31:	00 00 00 
     d34:	40 0f b6 d5          	movzbl %bpl,%edx
     d38:	c1 e2 1a             	shl    $0x1a,%edx
     d3b:	81 ca 01 00 40 00    	or     $0x400001,%edx
     d41:	89 90 dc fe ff ff    	mov    %edx,-0x124(%rax)
     d47:	48 ba 10 00 00 00 03 	movabs $0x300000010,%rdx
     d4e:	00 00 00 
     d51:	48 89 90 d0 fe ff ff 	mov    %rdx,-0x130(%rax)
     d58:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     d5f:	ff ff 00 00 
     d63:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     d6a:	ff ff ff 
     d6d:	48 8d 55 07          	lea    0x7(%rbp),%rdx
     d71:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
     d78:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
     d7f:	00 00 00 
     d82:	48 89 90 f0 fe ff ff 	mov    %rdx,-0x110(%rax)
     d89:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
     d90:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
     d97:	00 80 3f 
     d9a:	48 89 90 08 ff ff ff 	mov    %rdx,-0xf8(%rax)
     da1:	48 89 90 10 ff ff ff 	mov    %rdx,-0xf0(%rax)
     da8:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     daf:	00 00 00 
     db2:	49 8d 95 00 54 09 00 	lea    0x95400(%r13),%rdx
     db9:	48 89 57 68          	mov    %rdx,0x68(%rdi)
     dbd:	48 8b b7 c0 00 00 00 	mov    0xc0(%rdi),%rsi
     dc4:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
     dc9:	4c 89 96 a4 00 00 00 	mov    %r10,0xa4(%rsi)
     dd0:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
     dd7:	4c 89 98 48 ff ff ff 	mov    %r11,-0xb8(%rax)
     dde:	4c 89 80 50 ff ff ff 	mov    %r8,-0xb0(%rax)
     de5:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
     dec:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
     df3:	00 00 00 00 
     df7:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
     dfe:	49 69 f1 e0 3c 00 00 	imul   $0x3ce0,%r9,%rsi
     e05:	44 39 4b 08          	cmp    %r9d,0x8(%rbx)
     e09:	ba 00 00 00 00       	mov    $0x0,%edx
     e0e:	48 0f 47 d6          	cmova  %rsi,%rdx
     e12:	4c 8b 43 10          	mov    0x10(%rbx),%r8
     e16:	c4 c1 78 10 84 10 00 	vmovups 0x2e00(%r8,%rdx,1),%xmm0
     e1d:	2e 00 00 
     e20:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
     e27:	ff 
     e28:	44 8b 43 08          	mov    0x8(%rbx),%r8d
     e2c:	45 31 d2             	xor    %r10d,%r10d
     e2f:	31 d2                	xor    %edx,%edx
     e31:	45 89 c3             	mov    %r8d,%r11d
     e34:	45 29 cb             	sub    %r9d,%r11d
     e37:	48 0f 47 ce          	cmova  %rsi,%rcx
     e3b:	41 0f 94 c2          	sete   %r10b
     e3f:	0f 93 c2             	setae  %dl
     e42:	41 c1 e2 1e          	shl    $0x1e,%r10d
     e46:	c1 e2 1d             	shl    $0x1d,%edx
     e49:	44 09 d2             	or     %r10d,%edx
     e4c:	c4 c2 20 f2 f0       	andn   %r8d,%r11d,%esi
     e51:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
     e58:	44 09 da             	or     %r11d,%edx
     e5b:	4c 8b 43 10          	mov    0x10(%rbx),%r8
     e5f:	c1 ee 03             	shr    $0x3,%esi
     e62:	81 e6 00 00 00 10    	and    $0x10000000,%esi
     e68:	09 d6                	or     %edx,%esi
     e6a:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
     e71:	49 8b 94 08 80 30 00 	mov    0x3080(%r8,%rcx,1),%rdx
     e78:	00 
     e79:	49 8b b4 08 88 30 00 	mov    0x3088(%r8,%rcx,1),%rsi
     e80:	00 
     e81:	48 89 77 50          	mov    %rsi,0x50(%rdi)
     e85:	48 89 90 60 ff ff ff 	mov    %rdx,-0xa0(%rax)
     e8c:	48 89 b0 68 ff ff ff 	mov    %rsi,-0x98(%rax)
     e93:	49 8b 94 08 90 30 00 	mov    0x3090(%r8,%rcx,1),%rdx
     e9a:	00 
     e9b:	48 89 57 48          	mov    %rdx,0x48(%rdi)
     e9f:	41 8b 8c 08 98 30 00 	mov    0x3098(%r8,%rcx,1),%ecx
     ea6:	00 
     ea7:	89 88 78 ff ff ff    	mov    %ecx,-0x88(%rax)
     ead:	48 8b 8f e8 00 00 00 	mov    0xe8(%rdi),%rcx
     eb4:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
     eb8:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
     ebc:	48 89 90 70 ff ff ff 	mov    %rdx,-0x90(%rax)
     ec3:	49 8d 85 e6 09 51 fd 	lea    -0x2aef61a(%r13),%rax
     eca:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
     ed1:	48 89 fb             	mov    %rdi,%rbx
     ed4:	c5 f8 77             	vzeroupper
     ed7:	e8 00 00 00 00       	call   edc <f_8001161d0+0xedc>
     edc:	48 89 df             	mov    %rbx,%rdi
     edf:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     ee6:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
     eed:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     ef4:	48 89 01             	mov    %rax,(%rcx)
     ef7:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     efe:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     f05:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
     f09:	48 89 53 48          	mov    %rdx,0x48(%rbx)
     f0d:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
     f14:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     f18:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     f1e:	48 89 43 40          	mov    %rax,0x40(%rbx)
     f22:	88 51 08             	mov    %dl,0x8(%rcx)
     f25:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     f2c:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
     f30:	89 41 24             	mov    %eax,0x24(%rcx)
     f33:	e9 01 1d 00 00       	jmp    2c39 <f_8001161d0+0x2c39>
     f38:	81 f9 b2 01 00 00    	cmp    $0x1b2,%ecx
     f3e:	0f 84 d4 19 00 00    	je     2918 <f_8001161d0+0x2918>
     f44:	81 f9 b8 01 00 00    	cmp    $0x1b8,%ecx
     f4a:	0f 85 c8 0c 00 00    	jne    1c18 <f_8001161d0+0x1c18>
     f50:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
     f57:	00 
     f58:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
     f5f:	48 c7 03 08 00 00 00 	movq   $0x8,(%rbx)
     f66:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
     f6d:	00 40 00 
     f70:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     f74:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
     f7b:	00 
     f7c:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
     f83:	ff ff ff 
     f86:	48 8d 4e 15          	lea    0x15(%rsi),%rcx
     f8a:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
     f8e:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     f95:	00 00 00 
     f98:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
     f9c:	48 89 73 28          	mov    %rsi,0x28(%rbx)
     fa0:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
     fa6:	4c 89 47 68          	mov    %r8,0x68(%rdi)
     faa:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
     fb1:	00 80 3f 
     fb4:	4c 89 77 70          	mov    %r14,0x70(%rdi)
     fb8:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
     fbc:	48 83 c3 38          	add    $0x38,%rbx
     fc0:	48 be ca 5d c0 02 08 	movabs $0x802c05dca,%rsi
     fc7:	00 00 00 
     fca:	4c 8d 8e af 2c 05 00 	lea    0x52caf(%rsi),%r9
     fd1:	e9 94 1a 00 00       	jmp    2a6a <f_8001161d0+0x2a6a>
     fd6:	81 f9 b6 02 00 00    	cmp    $0x2b6,%ecx
     fdc:	0f 84 8e 19 00 00    	je     2970 <f_8001161d0+0x2970>
     fe2:	81 f9 c5 02 00 00    	cmp    $0x2c5,%ecx
     fe8:	0f 85 2a 0c 00 00    	jne    1c18 <f_8001161d0+0x1c18>
     fee:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
     ff5:	00 
     ff6:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
     ffd:	48 b9 01 00 00 00 04 	movabs $0x400000001,%rcx
    1004:	00 00 00 
    1007:	48 89 0b             	mov    %rcx,(%rbx)
    100a:	48 b9 00 00 00 00 02 	movabs $0x80200000000,%rcx
    1011:	08 00 00 
    1014:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    1018:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
    101f:	00 
    1020:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    1027:	ff ff ff 
    102a:	48 8d 4e 0f          	lea    0xf(%rsi),%rcx
    102e:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    1032:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    1039:	00 00 00 
    103c:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
    1040:	48 89 73 28          	mov    %rsi,0x28(%rbx)
    1044:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    104a:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    104e:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    1055:	00 80 3f 
    1058:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    105c:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
    1060:	48 83 c3 38          	add    $0x38,%rbx
    1064:	48 be ca 5d c0 02 08 	movabs $0x802c05dca,%rsi
    106b:	00 00 00 
    106e:	4c 8d 8e 88 db 0a 00 	lea    0xadb88(%rsi),%r9
    1075:	e9 f0 19 00 00       	jmp    2a6a <f_8001161d0+0x2a6a>
    107a:	81 f9 52 02 00 00    	cmp    $0x252,%ecx
    1080:	0f 84 6d 19 00 00    	je     29f3 <f_8001161d0+0x29f3>
    1086:	81 f9 61 02 00 00    	cmp    $0x261,%ecx
    108c:	0f 85 86 0b 00 00    	jne    1c18 <f_8001161d0+0x1c18>
    1092:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    1099:	44 89 99 a0 00 00 00 	mov    %r11d,0xa0(%rcx)
    10a0:	48 be 00 00 00 00 0f 	movabs $0xf00000000,%rsi
    10a7:	00 00 00 
    10aa:	48 89 71 14          	mov    %rsi,0x14(%rcx)
    10ae:	48 be 00 00 00 00 ff 	movabs $0xffff00000000,%rsi
    10b5:	ff 00 00 
    10b8:	48 81 ce 00 00 40 08 	or     $0x8400000,%rsi
    10bf:	48 89 71 0c          	mov    %rsi,0xc(%rcx)
    10c3:	48 8b b7 a0 00 00 00 	mov    0xa0(%rdi),%rsi
    10ca:	8b b6 8c 3a 00 00    	mov    0x3a8c(%rsi),%esi
    10d0:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    10d5:	48 89 57 60          	mov    %rdx,0x60(%rdi)
    10d9:	4c 89 7f 40          	mov    %r15,0x40(%rdi)
    10dd:	48 c7 41 04 00 00 00 	movq   $0x0,0x4(%rcx)
    10e4:	00 
    10e5:	4c 8b 4f 78          	mov    0x78(%rdi),%r9
    10e9:	4c 89 49 1c          	mov    %r9,0x1c(%rcx)
    10ed:	41 89 f3             	mov    %esi,%r11d
    10f0:	41 c1 e3 0d          	shl    $0xd,%r11d
    10f4:	41 81 e3 00 00 00 40 	and    $0x40000000,%r11d
    10fb:	49 81 f3 00 00 00 40 	xor    $0x40000000,%r11
    1102:	4c 89 9f 10 01 00 00 	mov    %r11,0x110(%rdi)
    1109:	48 c7 47 68 01 00 00 	movq   $0x1,0x68(%rdi)
    1110:	00 
    1111:	c7 41 34 00 00 00 00 	movl   $0x0,0x34(%rcx)
    1118:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    111f:	00 
    1120:	48 c7 41 24 01 00 00 	movq   $0x1,0x24(%rcx)
    1127:	00 
    1128:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    112c:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    1133:	00 00 00 
    1136:	44 89 49 2c          	mov    %r9d,0x2c(%rcx)
    113a:	c7 41 30 01 00 00 00 	movl   $0x1,0x30(%rcx)
    1141:	c1 ee 08             	shr    $0x8,%esi
    1144:	81 e6 00 02 00 00    	and    $0x200,%esi
    114a:	81 ce 00 00 00 40    	or     $0x40000000,%esi
    1150:	89 31                	mov    %esi,(%rcx)
    1152:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    1159:	00 00 00 
    115c:	48 05 f0 85 00 00    	add    $0x85f0,%rax
    1162:	48 89 47 70          	mov    %rax,0x70(%rdi)
    1166:	48 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rsi
    116d:	00 80 3f 
    1170:	48 89 71 38          	mov    %rsi,0x38(%rcx)
    1174:	48 89 71 40          	mov    %rsi,0x40(%rcx)
    1178:	48 8b b7 c0 00 00 00 	mov    0xc0(%rdi),%rsi
    117f:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
    1184:	4c 89 8e a4 00 00 00 	mov    %r9,0xa4(%rsi)
    118b:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
    1192:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    1199:	48 be ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rsi
    11a0:	ff 7f 7f 
    11a3:	48 89 71 78          	mov    %rsi,0x78(%rcx)
    11a7:	4c 89 81 80 00 00 00 	mov    %r8,0x80(%rcx)
    11ae:	48 89 91 88 00 00 00 	mov    %rdx,0x88(%rcx)
    11b5:	48 89 b1 90 00 00 00 	mov    %rsi,0x90(%rcx)
    11bc:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    11c0:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    11c5:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    11cc:	00 
    11cd:	48 89 41 70          	mov    %rax,0x70(%rcx)
    11d1:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    11d8:	00 
    11d9:	4c 89 79 50          	mov    %r15,0x50(%rcx)
    11dd:	48 8b 5f 48          	mov    0x48(%rdi),%rbx
    11e1:	4c 8b af d0 00 00 00 	mov    0xd0(%rdi),%r13
    11e8:	e9 2e 19 00 00       	jmp    2b1b <f_8001161d0+0x2b1b>
    11ed:	81 f9 ad 03 00 00    	cmp    $0x3ad,%ecx
    11f3:	0f 84 02 1d 00 00    	je     2efb <f_8001161d0+0x2efb>
    11f9:	81 f9 12 04 00 00    	cmp    $0x412,%ecx
    11ff:	0f 85 13 0a 00 00    	jne    1c18 <f_8001161d0+0x1c18>
    1205:	48 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%rcx
    120c:	48 8b 89 c8 1e 00 00 	mov    0x1ec8(%rcx),%rcx
    1213:	48 89 4f 70          	mov    %rcx,0x70(%rdi)
    1217:	48 bb 00 00 00 00 01 	movabs $0x100000000,%rbx
    121e:	00 00 00 
    1221:	48 89 1f             	mov    %rbx,(%rdi)
    1224:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1228:	4c 8b 8f 00 01 00 00 	mov    0x100(%rdi),%r9
    122f:	49 c7 01 02 00 00 00 	movq   $0x2,(%r9)
    1236:	48 be 00 00 00 00 00 	movabs $0x40000000000000,%rsi
    123d:	00 40 00 
    1240:	48 ff c6             	inc    %rsi
    1243:	49 89 71 08          	mov    %rsi,0x8(%r9)
    1247:	49 89 59 20          	mov    %rbx,0x20(%r9)
    124b:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    1252:	ff ff ff 
    1255:	49 89 69 28          	mov    %rbp,0x28(%r9)
    1259:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1260:	00 00 00 
    1263:	4c 89 6f 68          	mov    %r13,0x68(%rdi)
    1267:	4d 89 81 80 00 00 00 	mov    %r8,0x80(%r9)
    126e:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    1273:	49 89 91 88 00 00 00 	mov    %rdx,0x88(%r9)
    127a:	48 8b b7 c0 00 00 00 	mov    0xc0(%rdi),%rsi
    1281:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    1286:	4c 89 96 a4 00 00 00 	mov    %r10,0xa4(%rsi)
    128d:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
    1294:	ff 7f 7f 
    1297:	4d 89 91 90 00 00 00 	mov    %r10,0x90(%r9)
    129e:	4d 89 81 98 00 00 00 	mov    %r8,0x98(%r9)
    12a5:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 12ad <f_8001161d0+0x12ad>
    12ac:	00 
    12ad:	c5 fc 11 47 78       	vmovups %ymm0,0x78(%rdi)
    12b2:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    12b9:	00 
    12ba:	45 89 99 a0 00 00 00 	mov    %r11d,0xa0(%r9)
    12c1:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    12c8:	0f b6 70 08          	movzbl 0x8(%rax),%esi
    12cc:	48 89 77 40          	mov    %rsi,0x40(%rdi)
    12d0:	41 c7 81 bc 00 00 00 	movl   $0x3,0xbc(%r9)
    12d7:	03 00 00 00 
    12db:	49 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%r9)
    12e2:	00 
    12e3:	48 8d 45 16          	lea    0x16(%rbp),%rax
    12e7:	49 89 41 18          	mov    %rax,0x18(%r9)
    12eb:	49 c7 41 68 00 00 00 	movq   $0x0,0x68(%r9)
    12f2:	00 
    12f3:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    12f8:	49 89 41 30          	mov    %rax,0x30(%r9)
    12fc:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    1303:	00 80 3f 
    1306:	49 89 41 38          	mov    %rax,0x38(%r9)
    130a:	49 89 41 40          	mov    %rax,0x40(%r9)
    130e:	49 c7 41 48 00 00 00 	movq   $0x0,0x48(%r9)
    1315:	00 
    1316:	4d 89 79 50          	mov    %r15,0x50(%r9)
    131a:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    131e:	c4 c1 78 11 41 58    	vmovups %xmm0,0x58(%r9)
    1324:	4d 89 69 70          	mov    %r13,0x70(%r9)
    1328:	4d 89 51 78          	mov    %r10,0x78(%r9)
    132c:	48 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rax
    1333:	45 31 c0             	xor    %r8d,%r8d
    1336:	39 71 08             	cmp    %esi,0x8(%rcx)
    1339:	49 0f 46 c0          	cmovbe %r8,%rax
    133d:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    1341:	48 8b 94 08 b8 30 00 	mov    0x30b8(%rax,%rcx,1),%rdx
    1348:	00 
    1349:	48 89 57 60          	mov    %rdx,0x60(%rdi)
    134d:	48 8b 84 08 b0 30 00 	mov    0x30b0(%rax,%rcx,1),%rax
    1354:	00 
    1355:	48 8b 4f 48          	mov    0x48(%rdi),%rcx
    1359:	48 89 01             	mov    %rax,(%rcx)
    135c:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    1360:	48 8b 47 70          	mov    0x70(%rdi),%rax
    1364:	44 8b 48 08          	mov    0x8(%rax),%r9d
    1368:	4c 89 4f 48          	mov    %r9,0x48(%rdi)
    136c:	48 8b 48 10          	mov    0x10(%rax),%rcx
    1370:	48 89 4f 58          	mov    %rcx,0x58(%rdi)
    1374:	8b 57 40             	mov    0x40(%rdi),%edx
    1377:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
    137e:	45 31 db             	xor    %r11d,%r11d
    1381:	45 31 d2             	xor    %r10d,%r10d
    1384:	44 89 cb             	mov    %r9d,%ebx
    1387:	29 f3                	sub    %esi,%ebx
    1389:	49 0f 46 d0          	cmovbe %r8,%rdx
    138d:	41 0f 94 c3          	sete   %r11b
    1391:	41 0f 93 c2          	setae  %r10b
    1395:	41 c1 e3 1e          	shl    $0x1e,%r11d
    1399:	41 c1 e2 1d          	shl    $0x1d,%r10d
    139d:	45 09 da             	or     %r11d,%r10d
    13a0:	c4 c2 60 f2 f1       	andn   %r9d,%ebx,%esi
    13a5:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    13ab:	41 09 da             	or     %ebx,%r10d
    13ae:	c1 ee 03             	shr    $0x3,%esi
    13b1:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    13b7:	44 09 d6             	or     %r10d,%esi
    13ba:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    13c1:	48 8b b4 0a 30 33 00 	mov    0x3330(%rdx,%rcx,1),%rsi
    13c8:	00 
    13c9:	4c 8b 84 0a 38 33 00 	mov    0x3338(%rdx,%rcx,1),%r8
    13d0:	00 
    13d1:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    13d5:	4c 8b 8f d0 00 00 00 	mov    0xd0(%rdi),%r9
    13dc:	49 89 31             	mov    %rsi,(%r9)
    13df:	4d 89 41 08          	mov    %r8,0x8(%r9)
    13e3:	8b b4 0a 48 33 00 00 	mov    0x3348(%rdx,%rcx,1),%esi
    13ea:	48 8b 8c 0a 40 33 00 	mov    0x3340(%rdx,%rcx,1),%rcx
    13f1:	00 
    13f2:	48 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%rdx
    13f9:	48 89 0a             	mov    %rcx,(%rdx)
    13fc:	89 72 08             	mov    %esi,0x8(%rdx)
    13ff:	8b 48 44             	mov    0x44(%rax),%ecx
    1402:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    1406:	48 83 c0 30          	add    $0x30,%rax
    140a:	e9 ea 0a 00 00       	jmp    1ef9 <f_8001161d0+0x1ef9>
    140f:	81 f9 1a 05 00 00    	cmp    $0x51a,%ecx
    1415:	0f 85 fd 07 00 00    	jne    1c18 <f_8001161d0+0x1c18>
    141b:	b8 e8 0a 00 00       	mov    $0xae8,%eax
    1420:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
    1427:	48 89 07             	mov    %rax,(%rdi)
    142a:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    1431:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    1438:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    143c:	48 89 47 10          	mov    %rax,0x10(%rdi)
    1440:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1447:	00 00 00 
    144a:	49 8d 85 ca 19 51 fd 	lea    -0x2aee636(%r13),%rax
    1451:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    1458:	48 89 fb             	mov    %rdi,%rbx
    145b:	c5 f8 77             	vzeroupper
    145e:	e8 00 00 00 00       	call   1463 <f_8001161d0+0x1463>
    1463:	48 89 df             	mov    %rbx,%rdi
    1466:	e9 ce 17 00 00       	jmp    2c39 <f_8001161d0+0x2c39>
    146b:	83 f9 61             	cmp    $0x61,%ecx
    146e:	0f 85 a4 07 00 00    	jne    1c18 <f_8001161d0+0x1c18>
    1474:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    147b:	00 
    147c:	48 c7 80 d0 fe ff ff 	movq   $0x8,-0x130(%rax)
    1483:	08 00 00 00 
    1487:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    148e:	00 40 00 
    1491:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    1498:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    149f:	ff ff 00 00 
    14a3:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    14aa:	ff ff ff 
    14ad:	48 8d 4e 0f          	lea    0xf(%rsi),%rcx
    14b1:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    14b8:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    14bf:	00 00 00 
    14c2:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
    14c6:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    14cd:	48 89 b0 f8 fe ff ff 	mov    %rsi,-0x108(%rax)
    14d4:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    14db:	00 80 3f 
    14de:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    14e2:	48 8d 88 00 ff ff ff 	lea    -0x100(%rax),%rcx
    14e9:	48 8d 98 08 ff ff ff 	lea    -0xf8(%rax),%rbx
    14f0:	48 be ca 5d c0 02 08 	movabs $0x802c05dca,%rsi
    14f7:	00 00 00 
    14fa:	4c 8d 8e ab f2 0c 00 	lea    0xcf2ab(%rsi),%r9
    1501:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    1507:	e9 5e 15 00 00       	jmp    2a6a <f_8001161d0+0x2a6a>
    150c:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1513:	00 00 00 
    1516:	49 8d 9d 0b d1 09 00 	lea    0x9d10b(%r13),%rbx
    151d:	eb 24                	jmp    1543 <f_8001161d0+0x1543>
    151f:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1526:	00 00 00 
    1529:	49 8d 9d 2d 8c 01 00 	lea    0x18c2d(%r13),%rbx
    1530:	eb 11                	jmp    1543 <f_8001161d0+0x1543>
    1532:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1539:	00 00 00 
    153c:	49 8d 9d 4b 4f 0a 00 	lea    0xa4f4b(%r13),%rbx
    1543:	48 89 5f 68          	mov    %rbx,0x68(%rdi)
    1547:	4c 8b 8f 00 01 00 00 	mov    0x100(%rdi),%r9
    154e:	41 c7 01 00 00 00 10 	movl   $0x10000000,(%r9)
    1555:	4c 8b bf a0 00 00 00 	mov    0xa0(%rdi),%r15
    155c:	49 8b 8f f0 31 00 00 	mov    0x31f0(%r15),%rcx
    1563:	48 89 0f             	mov    %rcx,(%rdi)
    1566:	48 be 10 00 00 00 03 	movabs $0x300000010,%rsi
    156d:	00 00 00 
    1570:	4c 8d 76 f0          	lea    -0x10(%rsi),%r14
    1574:	4d 89 71 14          	mov    %r14,0x14(%r9)
    1578:	48 c7 47 78 01 00 00 	movq   $0x1,0x78(%rdi)
    157f:	00 
    1580:	48 83 c6 f6          	add    $0xfffffffffffffff6,%rsi
    1584:	49 89 71 04          	mov    %rsi,0x4(%r9)
    1588:	48 8b 77 70          	mov    0x70(%rdi),%rsi
    158c:	49 89 71 2c          	mov    %rsi,0x2c(%r9)
    1590:	48 be 00 00 00 00 ff 	movabs $0xffff00000000,%rsi
    1597:	ff 00 00 
    159a:	49 89 71 0c          	mov    %rsi,0xc(%r9)
    159e:	4c 89 47 70          	mov    %r8,0x70(%rdi)
    15a2:	be ff ff ff ff       	mov    $0xffffffff,%esi
    15a7:	49 89 71 1c          	mov    %rsi,0x1c(%r9)
    15ab:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    15b0:	4c 89 57 60          	mov    %r10,0x60(%rdi)
    15b4:	48 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rsi
    15bb:	00 80 3f 
    15be:	49 89 71 38          	mov    %rsi,0x38(%r9)
    15c2:	49 89 71 40          	mov    %rsi,0x40(%r9)
    15c6:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    15cb:	48 89 77 48          	mov    %rsi,0x48(%rdi)
    15cf:	48 89 57 50          	mov    %rdx,0x50(%rdi)
    15d3:	49 c7 41 24 01 00 00 	movq   $0x1,0x24(%r9)
    15da:	00 
    15db:	41 c7 41 34 00 00 00 	movl   $0x0,0x34(%r9)
    15e2:	00 
    15e3:	4c 8b b7 c0 00 00 00 	mov    0xc0(%rdi),%r14
    15ea:	49 89 b6 a4 00 00 00 	mov    %rsi,0xa4(%r14)
    15f1:	4d 89 81 98 00 00 00 	mov    %r8,0x98(%r9)
    15f8:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    15fc:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1603:	00 
    1604:	45 89 99 a0 00 00 00 	mov    %r11d,0xa0(%r9)
    160b:	41 c7 81 bc 00 00 00 	movl   $0x1,0xbc(%r9)
    1612:	01 00 00 00 
    1616:	48 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rax
    161d:	ff 7f 7f 
    1620:	49 89 41 78          	mov    %rax,0x78(%r9)
    1624:	4d 89 81 80 00 00 00 	mov    %r8,0x80(%r9)
    162b:	4d 89 91 88 00 00 00 	mov    %r10,0x88(%r9)
    1632:	49 89 81 90 00 00 00 	mov    %rax,0x90(%r9)
    1639:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    163d:	c4 c1 78 11 41 58    	vmovups %xmm0,0x58(%r9)
    1643:	49 c7 41 68 00 00 00 	movq   $0x0,0x68(%r9)
    164a:	00 
    164b:	49 89 59 70          	mov    %rbx,0x70(%r9)
    164f:	49 c7 41 48 00 00 00 	movq   $0x0,0x48(%r9)
    1656:	00 
    1657:	49 89 51 50          	mov    %rdx,0x50(%r9)
    165b:	48 85 c9             	test   %rcx,%rcx
    165e:	0f 84 d5 15 00 00    	je     2c39 <f_8001161d0+0x2c39>
    1664:	49 8b 87 c8 1e 00 00 	mov    0x1ec8(%r15),%rax
    166b:	48 8b 97 98 00 00 00 	mov    0x98(%rdi),%rdx
    1672:	49 89 f2             	mov    %rsi,%r10
    1675:	0f b6 72 08          	movzbl 0x8(%rdx),%esi
    1679:	44 8b 40 08          	mov    0x8(%rax),%r8d
    167d:	48 8b 40 10          	mov    0x10(%rax),%rax
    1681:	48 c7 47 60 e0 3c 00 	movq   $0x3ce0,0x60(%rdi)
    1688:	00 
    1689:	31 d2                	xor    %edx,%edx
    168b:	41 39 f0             	cmp    %esi,%r8d
    168e:	41 b8 00 00 00 00    	mov    $0x0,%r8d
    1694:	4c 0f 47 c6          	cmova  %rsi,%r8
    1698:	4c 89 47 58          	mov    %r8,0x58(%rdi)
    169c:	49 69 f0 e0 3c 00 00 	imul   $0x3ce0,%r8,%rsi
    16a3:	4c 8d 04 06          	lea    (%rsi,%rax,1),%r8
    16a7:	4c 89 47 50          	mov    %r8,0x50(%rdi)
    16ab:	c5 fb 10 8c 06 00 2e 	vmovsd 0x2e00(%rsi,%rax,1),%xmm1
    16b2:	00 00 
    16b4:	c5 fb 10 94 06 08 2e 	vmovsd 0x2e08(%rsi,%rax,1),%xmm2
    16bb:	00 00 
    16bd:	c5 e8 5c c9          	vsubps %xmm1,%xmm2,%xmm1
    16c1:	45 89 99 a0 00 00 00 	mov    %r11d,0xa0(%r9)
    16c8:	48 8b 87 e8 00 00 00 	mov    0xe8(%rdi),%rax
    16cf:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    16d3:	48 89 47 40          	mov    %rax,0x40(%rdi)
    16d7:	4d 89 96 a4 00 00 00 	mov    %r10,0xa4(%r14)
    16de:	c5 fb 10 91 08 03 00 	vmovsd 0x308(%rcx),%xmm2
    16e5:	00 
    16e6:	c5 f8 29 87 20 02 00 	vmovaps %xmm0,0x220(%rdi)
    16ed:	00 
    16ee:	c5 fa 16 d9          	vmovshdup %xmm1,%xmm3
    16f2:	c4 e1 fa 2c cb       	vcvttss2si %xmm3,%rcx
    16f7:	c5 d8 57 e4          	vxorps %xmm4,%xmm4,%xmm4
    16fb:	c5 f8 2e dc          	vucomiss %xmm4,%xmm3
    16ff:	0f 42 ca             	cmovb  %edx,%ecx
    1702:	c5 fa 10 2d 00 00 00 	vmovss 0x0(%rip),%xmm5        # 170a <f_8001161d0+0x170a>
    1709:	00 
    170a:	c5 f8 2e dd          	vucomiss %xmm5,%xmm3
    170e:	be ff ff ff ff       	mov    $0xffffffff,%esi
    1713:	0f 47 ce             	cmova  %esi,%ecx
    1716:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    171d:	c4 61 fa 2c c1       	vcvttss2si %xmm1,%r8
    1722:	c5 f8 2e cc          	vucomiss %xmm4,%xmm1
    1726:	44 0f 42 c2          	cmovb  %edx,%r8d
    172a:	c5 f8 2e cd          	vucomiss %xmm5,%xmm1
    172e:	44 0f 47 c6          	cmova  %esi,%r8d
    1732:	c4 c1 79 6e c8       	vmovd  %r8d,%xmm1
    1737:	c5 f9 6e d9          	vmovd  %ecx,%xmm3
    173b:	c5 f1 6c cb          	vpunpcklqdq %xmm3,%xmm1,%xmm1
    173f:	c4 e2 79 59 1d 00 00 	vpbroadcastq 0x0(%rip),%xmm3        # 1748 <f_8001161d0+0x1748>
    1746:	00 00 
    1748:	c5 f1 eb cb          	vpor   %xmm3,%xmm1,%xmm1
    174c:	c5 f1 5c cb          	vsubpd %xmm3,%xmm1,%xmm1
    1750:	c5 f9 5a c9          	vcvtpd2ps %xmm1,%xmm1
    1754:	c5 e8 59 c9          	vmulps %xmm1,%xmm2,%xmm1
    1758:	c5 f2 5f d4          	vmaxss %xmm4,%xmm1,%xmm2
    175c:	c5 f9 7e d1          	vmovd  %xmm2,%ecx
    1760:	48 89 8f 30 02 00 00 	mov    %rcx,0x230(%rdi)
    1767:	48 c7 87 38 02 00 00 	movq   $0x0,0x238(%rdi)
    176e:	00 00 00 00 
    1772:	c5 fa 16 d9          	vmovshdup %xmm1,%xmm3
    1776:	c5 e2 5f dc          	vmaxss %xmm4,%xmm3,%xmm3
    177a:	c5 f9 7e d9          	vmovd  %xmm3,%ecx
    177e:	48 89 8f 40 02 00 00 	mov    %rcx,0x240(%rdi)
    1785:	c5 f0 c2 e0 04       	vcmpneqps %xmm0,%xmm1,%xmm4
    178a:	c5 f0 c2 e8 01       	vcmpltps %xmm0,%xmm1,%xmm5
    178f:	c5 f8 c2 f1 01       	vcmpltps %xmm1,%xmm0,%xmm6
    1794:	c5 c8 c6 f6 50       	vshufps $0x50,%xmm6,%xmm6,%xmm6
    1799:	c5 fb 12 3d 00 00 00 	vmovddup 0x0(%rip),%xmm7        # 17a1 <f_8001161d0+0x17a1>
    17a0:	00 
    17a1:	c4 e3 41 4b 35 00 00 	vblendvpd %xmm6,0x0(%rip),%xmm7,%xmm6        # 17ab <f_8001161d0+0x17ab>
    17a8:	00 00 60 
    17ab:	c5 d0 c6 ed 50       	vshufps $0x50,%xmm5,%xmm5,%xmm5
    17b0:	c4 e3 49 4b 35 00 00 	vblendvpd %xmm5,0x0(%rip),%xmm6,%xmm6        # 17ba <f_8001161d0+0x17ba>
    17b7:	00 00 50 
    17ba:	c5 d8 c6 e4 50       	vshufps $0x50,%xmm4,%xmm4,%xmm4
    17bf:	c5 fb 12 3d 00 00 00 	vmovddup 0x0(%rip),%xmm7        # 17c7 <f_8001161d0+0x17c7>
    17c6:	00 
    17c7:	c4 e3 41 4b e6 40    	vblendvpd %xmm4,%xmm6,%xmm7,%xmm4
    17cd:	48 c7 87 48 02 00 00 	movq   $0x0,0x248(%rdi)
    17d4:	00 00 00 00 
    17d8:	c4 e3 f9 16 a7 10 01 	vpextrq $0x1,%xmm4,0x110(%rdi)
    17df:	00 00 01 
    17e2:	c5 fa 11 90 80 00 00 	vmovss %xmm2,0x80(%rax)
    17e9:	00 
    17ea:	c5 fa 11 98 84 00 00 	vmovss %xmm3,0x84(%rax)
    17f1:	00 
    17f2:	c5 fa 11 90 98 00 00 	vmovss %xmm2,0x98(%rax)
    17f9:	00 
    17fa:	c5 fa 11 98 9c 00 00 	vmovss %xmm3,0x9c(%rax)
    1801:	00 
    1802:	c5 d9 db 15 00 00 00 	vpand  0x0(%rip),%xmm4,%xmm2        # 180a <f_8001161d0+0x180a>
    1809:	00 
    180a:	c4 e2 69 29 d0       	vpcmpeqq %xmm0,%xmm2,%xmm2
    180f:	c5 d9 db 1d 00 00 00 	vpand  0x0(%rip),%xmm4,%xmm3        # 1817 <f_8001161d0+0x1817>
    1816:	00 
    1817:	c4 e2 61 29 c0       	vpcmpeqq %xmm0,%xmm3,%xmm0
    181c:	c5 d0 57 c0          	vxorps %xmm0,%xmm5,%xmm0
    1820:	c5 e9 db c0          	vpand  %xmm0,%xmm2,%xmm0
    1824:	c5 f9 70 c0 e8       	vpshufd $0xe8,%xmm0,%xmm0
    1829:	c5 f9 72 f0 1f       	vpslld $0x1f,%xmm0,%xmm0
    182e:	c5 f9 72 e0 1f       	vpsrad $0x1f,%xmm0,%xmm0
    1833:	c5 f9 df c1          	vpandn %xmm1,%xmm0,%xmm0
    1837:	c4 e3 79 16 c1 01    	vpextrd $0x1,%xmm0,%ecx
    183d:	c5 f9 7e c2          	vmovd  %xmm0,%edx
    1841:	48 89 8f 10 02 00 00 	mov    %rcx,0x210(%rdi)
    1848:	48 89 97 00 02 00 00 	mov    %rdx,0x200(%rdi)
    184f:	48 c7 87 18 02 00 00 	movq   $0x0,0x218(%rdi)
    1856:	00 00 00 00 
    185a:	48 c7 87 08 02 00 00 	movq   $0x0,0x208(%rdi)
    1861:	00 00 00 00 
    1865:	c5 f9 7e 40 78       	vmovd  %xmm0,0x78(%rax)
    186a:	c4 e3 79 16 40 7c 01 	vpextrd $0x1,%xmm0,0x7c(%rax)
    1871:	c5 f9 7e 80 90 00 00 	vmovd  %xmm0,0x90(%rax)
    1878:	00 
    1879:	c4 e3 79 16 80 94 00 	vpextrd $0x1,%xmm0,0x94(%rax)
    1880:	00 00 01 
    1883:	49 8d 85 5e 18 51 fd 	lea    -0x2aee7a2(%r13),%rax
    188a:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    1891:	48 89 fb             	mov    %rdi,%rbx
    1894:	c5 f8 77             	vzeroupper
    1897:	e8 00 00 00 00       	call   189c <f_8001161d0+0x189c>
    189c:	48 89 df             	mov    %rbx,%rdi
    189f:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    18a6:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    18ad:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    18b4:	48 89 01             	mov    %rax,(%rcx)
    18b7:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    18be:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    18c2:	48 89 43 40          	mov    %rax,0x40(%rbx)
    18c6:	88 41 08             	mov    %al,0x8(%rcx)
    18c9:	e9 6b 13 00 00       	jmp    2c39 <f_8001161d0+0x2c39>
    18ce:	48 8b 4f 78          	mov    0x78(%rdi),%rcx
    18d2:	4d 89 cf             	mov    %r9,%r15
    18d5:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
    18dc:	00 00 00 00 
    18e0:	4c 89 b8 20 ff ff ff 	mov    %r15,-0xe0(%rax)
    18e7:	4c 8b bf a0 00 00 00 	mov    0xa0(%rdi),%r15
    18ee:	8b 97 a8 00 00 00    	mov    0xa8(%rdi),%edx
    18f4:	44 8d 4a 08          	lea    0x8(%rdx),%r9d
    18f8:	4c 8b 87 00 01 00 00 	mov    0x100(%rdi),%r8
    18ff:	c4 c2 73 f7 af fc 0d 	shrx   %ecx,0xdfc(%r15),%ebp
    1906:	00 00 
    1908:	45 89 48 30          	mov    %r9d,0x30(%r8)
    190c:	4c 8b 67 68          	mov    0x68(%rdi),%r12
    1910:	45 89 60 34          	mov    %r12d,0x34(%r8)
    1914:	45 31 ed             	xor    %r13d,%r13d
    1917:	f7 c3 00 02 00 00    	test   $0x200,%ebx
    191d:	41 0f 94 c5          	sete   %r13b
    1921:	45 8b 8f 20 0d 00 00 	mov    0xd20(%r15),%r9d
    1928:	45 31 f6             	xor    %r14d,%r14d
    192b:	41 39 c9             	cmp    %ecx,%r9d
    192e:	49 0f 46 ce          	cmovbe %r14,%rcx
    1932:	41 89 c9             	mov    %ecx,%r9d
    1935:	4d 69 c9 b0 0b 00 00 	imul   $0xbb0,%r9,%r9
    193c:	31 f6                	xor    %esi,%esi
    193e:	f7 c3 00 40 00 00    	test   $0x4000,%ebx
    1944:	40 0f 94 c6          	sete   %sil
    1948:	c1 e3 06             	shl    $0x6,%ebx
    194b:	81 e3 00 00 04 00    	and    $0x40000,%ebx
    1951:	c1 e6 04             	shl    $0x4,%esi
    1954:	41 85 ed             	test   %ebp,%r13d
    1957:	bd 01 00 00 00       	mov    $0x1,%ebp
    195c:	c4 62 19 f7 e5       	shlx   %r12d,%ebp,%r12d
    1961:	48 c7 47 48 01 00 00 	movq   $0x1,0x48(%rdi)
    1968:	00 
    1969:	4c 89 67 08          	mov    %r12,0x8(%rdi)
    196d:	4d 8b bf 28 0d 00 00 	mov    0xd28(%r15),%r15
    1974:	4c 89 7f 70          	mov    %r15,0x70(%rdi)
    1978:	48 89 4f 78          	mov    %rcx,0x78(%rdi)
    197c:	8d 8c 1e 00 00 20 00 	lea    0x200000(%rsi,%rbx,1),%ecx
    1983:	be 0f 00 00 00       	mov    $0xf,%esi
    1988:	41 0f 45 f4          	cmovne %r12d,%esi
    198c:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1993:	00 
    1994:	48 c7 07 08 00 00 00 	movq   $0x8,(%rdi)
    199b:	41 89 30             	mov    %esi,(%r8)
    199e:	41 c7 40 04 08 00 00 	movl   $0x8,0x4(%r8)
    19a5:	00 
    19a6:	83 c2 04             	add    $0x4,%edx
    19a9:	41 89 50 08          	mov    %edx,0x8(%r8)
    19ad:	41 89 48 0c          	mov    %ecx,0xc(%r8)
    19b1:	49 c7 40 10 ff ff 00 	movq   $0xffff,0x10(%r8)
    19b8:	00 
    19b9:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    19c0:	ff ff ff 
    19c3:	48 8d 4d 02          	lea    0x2(%rbp),%rcx
    19c7:	49 89 48 18          	mov    %rcx,0x18(%r8)
    19cb:	4c 8b 64 24 08       	mov    0x8(%rsp),%r12
    19d0:	4c 89 a7 90 00 00 00 	mov    %r12,0x90(%rdi)
    19d7:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    19de:	00 00 00 
    19e1:	49 89 48 20          	mov    %rcx,0x20(%r8)
    19e5:	49 89 68 28          	mov    %rbp,0x28(%r8)
    19e9:	48 b9 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rcx
    19f0:	00 80 3f 
    19f3:	49 89 48 38          	mov    %rcx,0x38(%r8)
    19f7:	49 89 48 40          	mov    %rcx,0x40(%r8)
    19fb:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1a02:	00 00 00 
    1a05:	49 8d 95 b1 e5 0b 00 	lea    0xbe5b1(%r13),%rdx
    1a0c:	48 89 97 80 00 00 00 	mov    %rdx,0x80(%rdi)
    1a13:	48 bb ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rbx
    1a1a:	ff 7f ff 
    1a1d:	48 89 9f 88 00 00 00 	mov    %rbx,0x88(%rdi)
    1a24:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
    1a2b:	4c 89 a1 a4 00 00 00 	mov    %r12,0xa4(%rcx)
    1a32:	48 8b 77 58          	mov    0x58(%rdi),%rsi
    1a36:	49 89 70 78          	mov    %rsi,0x78(%r8)
    1a3a:	49 89 98 80 00 00 00 	mov    %rbx,0x80(%r8)
    1a41:	49 89 98 98 00 00 00 	mov    %rbx,0x98(%r8)
    1a48:	4c 8b 54 24 10       	mov    0x10(%rsp),%r10
    1a4d:	4d 89 90 88 00 00 00 	mov    %r10,0x88(%r8)
    1a54:	49 89 b0 90 00 00 00 	mov    %rsi,0x90(%r8)
    1a5b:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1a5f:	45 89 98 a0 00 00 00 	mov    %r11d,0xa0(%r8)
    1a66:	41 c7 80 bc 00 00 00 	movl   $0x0,0xbc(%r8)
    1a6d:	00 00 00 00 
    1a71:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1a75:	c4 c1 78 11 40 58    	vmovups %xmm0,0x58(%r8)
    1a7b:	49 c7 40 68 00 00 00 	movq   $0x0,0x68(%r8)
    1a82:	00 
    1a83:	49 89 50 70          	mov    %rdx,0x70(%r8)
    1a87:	43 8b 84 0f d8 03 00 	mov    0x3d8(%r15,%r9,1),%eax
    1a8e:	00 
    1a8f:	89 c2                	mov    %eax,%edx
    1a91:	c1 fa 1f             	sar    $0x1f,%edx
    1a94:	c4 e2 68 f2 d0       	andn   %eax,%edx,%edx
    1a99:	85 c0                	test   %eax,%eax
    1a9b:	41 0f 49 c6          	cmovns %r14d,%eax
    1a9f:	c5 82 2a c0          	vcvtsi2ss %eax,%xmm15,%xmm0
    1aa3:	43 8b 84 0f f8 03 00 	mov    0x3f8(%r15,%r9,1),%eax
    1aaa:	00 
    1aab:	89 c6                	mov    %eax,%esi
    1aad:	c1 fe 1f             	sar    $0x1f,%esi
    1ab0:	c4 e2 48 f2 f0       	andn   %eax,%esi,%esi
    1ab5:	85 c0                	test   %eax,%eax
    1ab7:	c5 82 2a ce          	vcvtsi2ss %esi,%xmm15,%xmm1
    1abb:	41 0f 49 c6          	cmovns %r14d,%eax
    1abf:	c5 82 2a d2          	vcvtsi2ss %edx,%xmm15,%xmm2
    1ac3:	c4 c1 7a 11 90 80 00 	vmovss %xmm2,0x80(%r8)
    1aca:	00 00 
    1acc:	c4 c1 7a 11 88 84 00 	vmovss %xmm1,0x84(%r8)
    1ad3:	00 00 
    1ad5:	c5 82 2a c8          	vcvtsi2ss %eax,%xmm15,%xmm1
    1ad9:	c4 c1 7a 11 40 78    	vmovss %xmm0,0x78(%r8)
    1adf:	c4 c1 7a 11 48 7c    	vmovss %xmm1,0x7c(%r8)
    1ae5:	43 8b 94 0f d8 03 00 	mov    0x3d8(%r15,%r9,1),%edx
    1aec:	00 
    1aed:	43 8b 84 0f f8 03 00 	mov    0x3f8(%r15,%r9,1),%eax
    1af4:	00 
    1af5:	48 89 47 60          	mov    %rax,0x60(%rdi)
    1af9:	8b 77 40             	mov    0x40(%rdi),%esi
    1afc:	41 89 b0 a0 00 00 00 	mov    %esi,0xa0(%r8)
    1b03:	89 d6                	mov    %edx,%esi
    1b05:	c1 fe 1f             	sar    $0x1f,%esi
    1b08:	c4 e2 48 f2 f2       	andn   %edx,%esi,%esi
    1b0d:	85 d2                	test   %edx,%edx
    1b0f:	41 0f 49 d6          	cmovns %r14d,%edx
    1b13:	c5 82 2a c2          	vcvtsi2ss %edx,%xmm15,%xmm0
    1b17:	4c 89 a1 a4 00 00 00 	mov    %r12,0xa4(%rcx)
    1b1e:	85 c0                	test   %eax,%eax
    1b20:	44 0f 4f f0          	cmovg  %eax,%r14d
    1b24:	c5 82 2a ce          	vcvtsi2ss %esi,%xmm15,%xmm1
    1b28:	c4 e3 79 17 c1 00    	vextractps $0x0,%xmm0,%ecx
    1b2e:	48 89 77 68          	mov    %rsi,0x68(%rdi)
    1b32:	48 89 8f 10 02 00 00 	mov    %rcx,0x210(%rdi)
    1b39:	c4 e3 79 17 c9 00    	vextractps $0x0,%xmm1,%ecx
    1b3f:	48 89 8f 00 02 00 00 	mov    %rcx,0x200(%rdi)
    1b46:	c4 c1 02 2a d6       	vcvtsi2ss %r14d,%xmm15,%xmm2
    1b4b:	89 c1                	mov    %eax,%ecx
    1b4d:	c1 f9 1f             	sar    $0x1f,%ecx
    1b50:	21 c1                	and    %eax,%ecx
    1b52:	48 c7 87 18 02 00 00 	movq   $0x0,0x218(%rdi)
    1b59:	00 00 00 00 
    1b5d:	48 c7 87 08 02 00 00 	movq   $0x0,0x208(%rdi)
    1b64:	00 00 00 00 
    1b68:	48 89 4f 58          	mov    %rcx,0x58(%rdi)
    1b6c:	c5 82 2a d9          	vcvtsi2ss %ecx,%xmm15,%xmm3
    1b70:	c4 e3 79 17 d8 00    	vextractps $0x0,%xmm3,%eax
    1b76:	48 89 87 30 02 00 00 	mov    %rax,0x230(%rdi)
    1b7d:	c4 e3 79 17 d0 00    	vextractps $0x0,%xmm2,%eax
    1b83:	48 89 87 20 02 00 00 	mov    %rax,0x220(%rdi)
    1b8a:	48 c7 87 38 02 00 00 	movq   $0x0,0x238(%rdi)
    1b91:	00 00 00 00 
    1b95:	48 c7 87 28 02 00 00 	movq   $0x0,0x228(%rdi)
    1b9c:	00 00 00 00 
    1ba0:	c4 c1 7a 11 88 98 00 	vmovss %xmm1,0x98(%r8)
    1ba7:	00 00 
    1ba9:	c4 c1 7a 11 90 9c 00 	vmovss %xmm2,0x9c(%r8)
    1bb0:	00 00 
    1bb2:	c4 c1 7a 11 80 90 00 	vmovss %xmm0,0x90(%r8)
    1bb9:	00 00 
    1bbb:	c4 c1 7a 11 98 94 00 	vmovss %xmm3,0x94(%r8)
    1bc2:	00 00 
    1bc4:	31 c0                	xor    %eax,%eax
    1bc6:	43 80 bc 0f 58 04 00 	cmpb   $0x0,0x458(%r15,%r9,1)
    1bcd:	00 00 
    1bcf:	48 c7 47 50 5b 00 00 	movq   $0x5b,0x50(%rdi)
    1bd6:	00 
    1bd7:	49 c7 80 b0 00 00 00 	movq   $0x0,0xb0(%r8)
    1bde:	00 00 00 00 
    1be2:	41 c7 80 bc 00 00 00 	movl   $0x1,0xbc(%r8)
    1be9:	01 00 00 00 
    1bed:	0f 94 c0             	sete   %al
    1bf0:	48 8d 0c 45 59 00 00 	lea    0x59(,%rax,2),%rcx
    1bf7:	00 
    1bf8:	c1 e0 1e             	shl    $0x1e,%eax
    1bfb:	48 0d 00 00 00 20    	or     $0x20000000,%rax
    1c01:	48 89 87 10 01 00 00 	mov    %rax,0x110(%rdi)
    1c08:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    1c0c:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    1c13:	e9 1b 10 00 00       	jmp    2c33 <f_8001161d0+0x2c33>
    1c18:	4c 89 a7 08 01 00 00 	mov    %r12,0x108(%rdi)
    1c1f:	48 83 c4 28          	add    $0x28,%rsp
    1c23:	5b                   	pop    %rbx
    1c24:	41 5c                	pop    %r12
    1c26:	41 5d                	pop    %r13
    1c28:	41 5e                	pop    %r14
    1c2a:	41 5f                	pop    %r15
    1c2c:	5d                   	pop    %rbp
    1c2d:	c5 f8 77             	vzeroupper
    1c30:	e9 00 00 00 00       	jmp    1c35 <f_8001161d0+0x1c35>
    1c35:	48 c7 47 40 b0 1e 00 	movq   $0x1eb0,0x40(%rdi)
    1c3c:	00 
    1c3d:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    1c44:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    1c4b:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    1c4f:	48 89 47 10          	mov    %rax,0x10(%rdi)
    1c53:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1c58:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
    1c5f:	48 89 07             	mov    %rax,(%rdi)
    1c62:	48 c7 47 18 00 00 00 	movq   $0x0,0x18(%rdi)
    1c69:	00 
    1c6a:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1c71:	00 00 00 
    1c74:	49 8d 85 ae 18 51 fd 	lea    -0x2aee752(%r13),%rax
    1c7b:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    1c82:	48 89 fb             	mov    %rdi,%rbx
    1c85:	c5 f8 77             	vzeroupper
    1c88:	e8 00 00 00 00       	call   1c8d <f_8001161d0+0x1c8d>
    1c8d:	48 89 df             	mov    %rbx,%rdi
    1c90:	e9 a4 0f 00 00       	jmp    2c39 <f_8001161d0+0x2c39>
    1c95:	48 c7 47 40 b0 1e 00 	movq   $0x1eb0,0x40(%rdi)
    1c9c:	00 
    1c9d:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    1ca4:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    1cab:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    1caf:	48 89 47 10          	mov    %rax,0x10(%rdi)
    1cb3:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1cb8:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
    1cbf:	48 89 07             	mov    %rax,(%rdi)
    1cc2:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1cc9:	00 00 00 
    1ccc:	49 8d 85 ce 18 51 fd 	lea    -0x2aee732(%r13),%rax
    1cd3:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    1cda:	48 89 fb             	mov    %rdi,%rbx
    1cdd:	c5 f8 77             	vzeroupper
    1ce0:	e8 00 00 00 00       	call   1ce5 <f_8001161d0+0x1ce5>
    1ce5:	48 89 df             	mov    %rbx,%rdi
    1ce8:	e9 4c 0f 00 00       	jmp    2c39 <f_8001161d0+0x2c39>
    1ced:	48 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%rcx
    1cf4:	48 8b 89 c8 1e 00 00 	mov    0x1ec8(%rcx),%rcx
    1cfb:	48 89 4f 70          	mov    %rcx,0x70(%rdi)
    1cff:	48 bb 00 00 00 00 01 	movabs $0x100000000,%rbx
    1d06:	00 00 00 
    1d09:	48 89 1f             	mov    %rbx,(%rdi)
    1d0c:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1d10:	4c 8b 8f 00 01 00 00 	mov    0x100(%rdi),%r9
    1d17:	49 c7 01 04 00 00 00 	movq   $0x4,(%r9)
    1d1e:	48 be 00 00 00 00 00 	movabs $0x40000000000000,%rsi
    1d25:	00 40 00 
    1d28:	48 ff c6             	inc    %rsi
    1d2b:	49 89 71 08          	mov    %rsi,0x8(%r9)
    1d2f:	49 89 59 20          	mov    %rbx,0x20(%r9)
    1d33:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    1d3a:	ff ff ff 
    1d3d:	49 89 69 28          	mov    %rbp,0x28(%r9)
    1d41:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1d48:	00 00 00 
    1d4b:	49 8d 9d 25 74 0d 00 	lea    0xd7425(%r13),%rbx
    1d52:	48 89 5f 68          	mov    %rbx,0x68(%rdi)
    1d56:	4d 89 81 80 00 00 00 	mov    %r8,0x80(%r9)
    1d5d:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    1d62:	49 89 b1 88 00 00 00 	mov    %rsi,0x88(%r9)
    1d69:	48 8b b7 c0 00 00 00 	mov    0xc0(%rdi),%rsi
    1d70:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    1d75:	4c 89 96 a4 00 00 00 	mov    %r10,0xa4(%rsi)
    1d7c:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
    1d83:	ff 7f 7f 
    1d86:	4d 89 91 90 00 00 00 	mov    %r10,0x90(%r9)
    1d8d:	4d 89 81 98 00 00 00 	mov    %r8,0x98(%r9)
    1d94:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 1d9c <f_8001161d0+0x1d9c>
    1d9b:	00 
    1d9c:	c5 fc 11 47 78       	vmovups %ymm0,0x78(%rdi)
    1da1:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1da8:	00 
    1da9:	45 89 99 a0 00 00 00 	mov    %r11d,0xa0(%r9)
    1db0:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    1db7:	0f b6 70 08          	movzbl 0x8(%rax),%esi
    1dbb:	48 89 77 40          	mov    %rsi,0x40(%rdi)
    1dbf:	41 c7 81 bc 00 00 00 	movl   $0x3,0xbc(%r9)
    1dc6:	03 00 00 00 
    1dca:	49 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%r9)
    1dd1:	00 
    1dd2:	48 8d 45 17          	lea    0x17(%rbp),%rax
    1dd6:	49 89 41 18          	mov    %rax,0x18(%r9)
    1dda:	49 c7 41 68 00 00 00 	movq   $0x0,0x68(%r9)
    1de1:	00 
    1de2:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    1de7:	49 89 41 30          	mov    %rax,0x30(%r9)
    1deb:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    1df2:	00 80 3f 
    1df5:	49 89 41 38          	mov    %rax,0x38(%r9)
    1df9:	49 89 41 40          	mov    %rax,0x40(%r9)
    1dfd:	49 c7 41 48 00 00 00 	movq   $0x0,0x48(%r9)
    1e04:	00 
    1e05:	49 89 51 50          	mov    %rdx,0x50(%r9)
    1e09:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1e0d:	c4 c1 78 11 41 58    	vmovups %xmm0,0x58(%r9)
    1e13:	49 89 59 70          	mov    %rbx,0x70(%r9)
    1e17:	4d 89 51 78          	mov    %r10,0x78(%r9)
    1e1b:	48 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rax
    1e22:	45 31 c9             	xor    %r9d,%r9d
    1e25:	39 71 08             	cmp    %esi,0x8(%rcx)
    1e28:	49 0f 46 c1          	cmovbe %r9,%rax
    1e2c:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    1e30:	48 8b 94 08 68 33 00 	mov    0x3368(%rax,%rcx,1),%rdx
    1e37:	00 
    1e38:	48 89 57 60          	mov    %rdx,0x60(%rdi)
    1e3c:	48 8b 84 08 60 33 00 	mov    0x3360(%rax,%rcx,1),%rax
    1e43:	00 
    1e44:	48 8b 4f 48          	mov    0x48(%rdi),%rcx
    1e48:	48 89 01             	mov    %rax,(%rcx)
    1e4b:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    1e4f:	48 8b 47 70          	mov    0x70(%rdi),%rax
    1e53:	44 8b 50 08          	mov    0x8(%rax),%r10d
    1e57:	48 8b 48 10          	mov    0x10(%rax),%rcx
    1e5b:	48 89 4f 58          	mov    %rcx,0x58(%rdi)
    1e5f:	8b 57 40             	mov    0x40(%rdi),%edx
    1e62:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
    1e69:	45 31 db             	xor    %r11d,%r11d
    1e6c:	45 31 c0             	xor    %r8d,%r8d
    1e6f:	44 89 d3             	mov    %r10d,%ebx
    1e72:	29 f3                	sub    %esi,%ebx
    1e74:	49 0f 46 d1          	cmovbe %r9,%rdx
    1e78:	41 0f 94 c3          	sete   %r11b
    1e7c:	41 0f 93 c0          	setae  %r8b
    1e80:	41 c1 e3 1e          	shl    $0x1e,%r11d
    1e84:	41 c1 e0 1d          	shl    $0x1d,%r8d
    1e88:	45 09 d8             	or     %r11d,%r8d
    1e8b:	c4 c2 60 f2 f2       	andn   %r10d,%ebx,%esi
    1e90:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    1e96:	41 09 d8             	or     %ebx,%r8d
    1e99:	c1 ee 03             	shr    $0x3,%esi
    1e9c:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    1ea2:	44 09 c6             	or     %r8d,%esi
    1ea5:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    1eac:	48 8b b4 0a e8 35 00 	mov    0x35e8(%rdx,%rcx,1),%rsi
    1eb3:	00 
    1eb4:	48 89 77 48          	mov    %rsi,0x48(%rdi)
    1eb8:	4c 8b 84 0a e0 35 00 	mov    0x35e0(%rdx,%rcx,1),%r8
    1ebf:	00 
    1ec0:	4c 89 47 50          	mov    %r8,0x50(%rdi)
    1ec4:	4c 8b 8f d0 00 00 00 	mov    0xd0(%rdi),%r9
    1ecb:	4d 89 01             	mov    %r8,(%r9)
    1ece:	49 89 71 08          	mov    %rsi,0x8(%r9)
    1ed2:	8b b4 0a f8 35 00 00 	mov    0x35f8(%rdx,%rcx,1),%esi
    1ed9:	48 8b 8c 0a f0 35 00 	mov    0x35f0(%rdx,%rcx,1),%rcx
    1ee0:	00 
    1ee1:	48 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%rdx
    1ee8:	48 89 0a             	mov    %rcx,(%rdx)
    1eeb:	89 72 08             	mov    %esi,0x8(%rdx)
    1eee:	8b 48 44             	mov    0x44(%rax),%ecx
    1ef1:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    1ef5:	48 83 c0 3c          	add    $0x3c,%rax
    1ef9:	8b 00                	mov    (%rax),%eax
    1efb:	48 89 47 48          	mov    %rax,0x48(%rdi)
    1eff:	48 8b 97 00 01 00 00 	mov    0x100(%rdi),%rdx
    1f06:	88 8a b0 00 00 00    	mov    %cl,0xb0(%rdx)
    1f0c:	c7 82 b4 00 00 00 00 	movl   $0x0,0xb4(%rdx)
    1f13:	00 00 00 
    1f16:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
    1f1d:	c7 81 b1 00 00 00 00 	movl   $0x0,0xb1(%rcx)
    1f24:	00 00 00 
    1f27:	88 82 b8 00 00 00    	mov    %al,0xb8(%rdx)
    1f2d:	e9 07 0d 00 00       	jmp    2c39 <f_8001161d0+0x2c39>
    1f32:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    1f39:	00 
    1f3a:	48 c7 80 d0 fe ff ff 	movq   $0x100,-0x130(%rax)
    1f41:	00 01 00 00 
    1f45:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    1f4c:	00 40 00 
    1f4f:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    1f56:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    1f5d:	ff ff 00 00 
    1f61:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    1f68:	ff ff ff 
    1f6b:	48 8d 4e 13          	lea    0x13(%rsi),%rcx
    1f6f:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    1f76:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    1f7d:	00 00 00 
    1f80:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
    1f84:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    1f8b:	48 89 b0 f8 fe ff ff 	mov    %rsi,-0x108(%rax)
    1f92:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    1f99:	00 80 3f 
    1f9c:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    1fa0:	48 8d 88 00 ff ff ff 	lea    -0x100(%rax),%rcx
    1fa7:	48 8d 98 08 ff ff ff 	lea    -0xf8(%rax),%rbx
    1fae:	48 be ca 5d c0 02 08 	movabs $0x802c05dca,%rsi
    1fb5:	00 00 00 
    1fb8:	4c 8d 8e a1 6f fe ff 	lea    -0x1905f(%rsi),%r9
    1fbf:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    1fc5:	e9 a0 0a 00 00       	jmp    2a6a <f_8001161d0+0x2a6a>
    1fca:	4d 89 fc             	mov    %r15,%r12
    1fcd:	48 c7 47 68 00 10 00 	movq   $0x1000,0x68(%rdi)
    1fd4:	00 
    1fd5:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    1fdc:	00 
    1fdd:	48 c7 80 d0 fe ff ff 	movq   $0x1000,-0x130(%rax)
    1fe4:	00 10 00 00 
    1fe8:	48 c7 80 d8 fe ff ff 	movq   $0x1,-0x128(%rax)
    1fef:	01 00 00 00 
    1ff3:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    1ffa:	ff ff 00 00 
    1ffe:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    2005:	ff ff ff 
    2008:	48 8d 4d 0c          	lea    0xc(%rbp),%rcx
    200c:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    2013:	49 bf 00 00 00 00 01 	movabs $0x100000000,%r15
    201a:	00 00 00 
    201d:	4c 89 b8 f0 fe ff ff 	mov    %r15,-0x110(%rax)
    2024:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
    202b:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    2032:	00 80 3f 
    2035:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    2039:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
    203e:	48 89 88 00 ff ff ff 	mov    %rcx,-0x100(%rax)
    2045:	4c 89 b0 08 ff ff ff 	mov    %r14,-0xf8(%rax)
    204c:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    2053:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    205a:	00 00 00 
    205d:	49 8d 9d b2 a4 03 00 	lea    0x3a4b2(%r13),%rbx
    2064:	44 89 99 a0 00 00 00 	mov    %r11d,0xa0(%rcx)
    206b:	4c 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%r9
    2072:	4d 8b 99 d0 2f 00 00 	mov    0x2fd0(%r9),%r11
    2079:	4c 89 5f 40          	mov    %r11,0x40(%rdi)
    207d:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    2082:	48 89 57 60          	mov    %rdx,0x60(%rdi)
    2086:	48 89 59 70          	mov    %rbx,0x70(%rcx)
    208a:	48 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rbx
    2091:	ff 7f 7f 
    2094:	48 89 59 78          	mov    %rbx,0x78(%rcx)
    2098:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    209c:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    20a0:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    20a7:	00 
    20a8:	c7 81 bc 00 00 00 00 	movl   $0x0,0xbc(%rcx)
    20af:	00 00 00 
    20b2:	4c 89 81 80 00 00 00 	mov    %r8,0x80(%rcx)
    20b9:	48 89 91 88 00 00 00 	mov    %rdx,0x88(%rcx)
    20c0:	48 8b b7 c0 00 00 00 	mov    0xc0(%rdi),%rsi
    20c7:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    20cc:	4c 89 96 a4 00 00 00 	mov    %r10,0xa4(%rsi)
    20d3:	4c 89 71 40          	mov    %r14,0x40(%rcx)
    20d7:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    20de:	00 
    20df:	48 89 99 90 00 00 00 	mov    %rbx,0x90(%rcx)
    20e6:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    20ed:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    20f4:	00 
    20f5:	4c 89 61 50          	mov    %r12,0x50(%rcx)
    20f9:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    20fd:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    2102:	4d 85 db             	test   %r11,%r11
    2105:	0f 84 d2 0f 00 00    	je     30dd <f_8001161d0+0x30dd>
    210b:	48 8b 97 98 00 00 00 	mov    0x98(%rdi),%rdx
    2112:	0f b6 72 08          	movzbl 0x8(%rdx),%esi
    2116:	48 c7 47 68 e0 3c 00 	movq   $0x3ce0,0x68(%rdi)
    211d:	00 
    211e:	4c 69 c6 60 0f 00 00 	imul   $0xf60,%rsi,%r8
    2125:	31 d2                	xor    %edx,%edx
    2127:	41 39 73 10          	cmp    %esi,0x10(%r11)
    212b:	4d 8b 53 18          	mov    0x18(%r11),%r10
    212f:	4c 0f 46 c2          	cmovbe %rdx,%r8
    2133:	47 8b 84 10 9c 02 00 	mov    0x29c(%r8,%r10,1),%r8d
    213a:	00 
    213b:	4d 09 f8             	or     %r15,%r8
    213e:	4c 89 41 1c          	mov    %r8,0x1c(%rcx)
    2142:	c7 81 bc 00 00 00 02 	movl   $0x2,0xbc(%rcx)
    2149:	00 00 00 
    214c:	49 8b 89 c8 1e 00 00 	mov    0x1ec8(%r9),%rcx
    2153:	4c 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%r8
    215a:	39 71 08             	cmp    %esi,0x8(%rcx)
    215d:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    2163:	4d 0f 47 c8          	cmova  %r8,%r9
    2167:	4c 8b 51 10          	mov    0x10(%rcx),%r10
    216b:	4f 8b 9c 0a b8 30 00 	mov    0x30b8(%r10,%r9,1),%r11
    2172:	00 
    2173:	4c 89 5f 60          	mov    %r11,0x60(%rdi)
    2177:	4f 8b 8c 0a b0 30 00 	mov    0x30b0(%r10,%r9,1),%r9
    217e:	00 
    217f:	4c 89 4f 58          	mov    %r9,0x58(%rdi)
    2183:	4c 89 88 48 ff ff ff 	mov    %r9,-0xb8(%rax)
    218a:	4c 89 98 50 ff ff ff 	mov    %r11,-0xb0(%rax)
    2191:	44 8b 49 08          	mov    0x8(%rcx),%r9d
    2195:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    2199:	45 31 d2             	xor    %r10d,%r10d
    219c:	45 31 db             	xor    %r11d,%r11d
    219f:	44 89 cb             	mov    %r9d,%ebx
    21a2:	29 f3                	sub    %esi,%ebx
    21a4:	49 0f 47 d0          	cmova  %r8,%rdx
    21a8:	41 0f 94 c2          	sete   %r10b
    21ac:	41 0f 93 c3          	setae  %r11b
    21b0:	c4 c2 60 f2 f1       	andn   %r9d,%ebx,%esi
    21b5:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    21bb:	41 c1 e2 1e          	shl    $0x1e,%r10d
    21bf:	41 c1 e3 1d          	shl    $0x1d,%r11d
    21c3:	45 09 d3             	or     %r10d,%r11d
    21c6:	41 09 db             	or     %ebx,%r11d
    21c9:	c1 ee 03             	shr    $0x3,%esi
    21cc:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    21d2:	44 09 de             	or     %r11d,%esi
    21d5:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    21dc:	48 8d 34 0a          	lea    (%rdx,%rcx,1),%rsi
    21e0:	48 89 77 40          	mov    %rsi,0x40(%rdi)
    21e4:	48 8b b4 0a 30 33 00 	mov    0x3330(%rdx,%rcx,1),%rsi
    21eb:	00 
    21ec:	4c 8b 84 0a 38 33 00 	mov    0x3338(%rdx,%rcx,1),%r8
    21f3:	00 
    21f4:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    21f8:	48 89 b0 60 ff ff ff 	mov    %rsi,-0xa0(%rax)
    21ff:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
    2206:	8b b4 0a 48 33 00 00 	mov    0x3348(%rdx,%rcx,1),%esi
    220d:	48 89 77 48          	mov    %rsi,0x48(%rdi)
    2211:	48 8b 8c 0a 40 33 00 	mov    0x3340(%rdx,%rcx,1),%rcx
    2218:	00 
    2219:	48 89 88 70 ff ff ff 	mov    %rcx,-0x90(%rax)
    2220:	89 b0 78 ff ff ff    	mov    %esi,-0x88(%rax)
    2226:	e9 0e 0a 00 00       	jmp    2c39 <f_8001161d0+0x2c39>
    222b:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
    2230:	48 8b 89 c8 1e 00 00 	mov    0x1ec8(%rcx),%rcx
    2237:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    223b:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    2240:	48 89 57 60          	mov    %rdx,0x60(%rdi)
    2244:	41 0f b6 5e 08       	movzbl 0x8(%r14),%ebx
    2249:	48 89 5f 68          	mov    %rbx,0x68(%rdi)
    224d:	8b 71 08             	mov    0x8(%rcx),%esi
    2250:	4d 89 fc             	mov    %r15,%r12
    2253:	4c 8b 79 10          	mov    0x10(%rcx),%r15
    2257:	4c 69 f3 e0 3c 00 00 	imul   $0x3ce0,%rbx,%r14
    225e:	45 31 c9             	xor    %r9d,%r9d
    2261:	39 de                	cmp    %ebx,%esi
    2263:	be 00 00 00 00       	mov    $0x0,%esi
    2268:	49 0f 47 f6          	cmova  %r14,%rsi
    226c:	48 c7 47 70 e0 3c 00 	movq   $0x3ce0,0x70(%rdi)
    2273:	00 
    2274:	4a 8b b4 3e 40 3c 00 	mov    0x3c40(%rsi,%r15,1),%rsi
    227b:	00 
    227c:	48 89 b7 b0 00 00 00 	mov    %rsi,0xb0(%rdi)
    2283:	44 89 98 70 ff ff ff 	mov    %r11d,-0x90(%rax)
    228a:	48 89 90 58 ff ff ff 	mov    %rdx,-0xa8(%rax)
    2291:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
    2298:	ff 7f 7f 
    229b:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
    22a2:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    22a9:	00 
    22aa:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    22ae:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
    22b5:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
    22bc:	00 00 00 00 
    22c0:	4c 89 a0 20 ff ff ff 	mov    %r12,-0xe0(%rax)
    22c7:	48 c7 47 40 06 00 00 	movq   $0x6,0x40(%rdi)
    22ce:	00 
    22cf:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    22d3:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
    22da:	ff 
    22db:	48 c7 80 00 ff ff ff 	movq   $0x6,-0x100(%rax)
    22e2:	06 00 00 00 
    22e6:	48 ba 10 00 00 00 03 	movabs $0x300000010,%rdx
    22ed:	00 00 00 
    22f0:	48 83 c2 10          	add    $0x10,%rdx
    22f4:	48 89 90 d0 fe ff ff 	mov    %rdx,-0x130(%rax)
    22fb:	48 ba 00 00 00 00 01 	movabs $0x40000100000000,%rdx
    2302:	00 40 00 
    2305:	48 89 90 d8 fe ff ff 	mov    %rdx,-0x128(%rax)
    230c:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    2313:	ff ff 00 00 
    2317:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    231e:	ff ff ff 
    2321:	48 8d 55 09          	lea    0x9(%rbp),%rdx
    2325:	48 89 90 e8 fe ff ff 	mov    %rdx,-0x118(%rax)
    232c:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
    2333:	00 00 00 
    2336:	48 89 90 f0 fe ff ff 	mov    %rdx,-0x110(%rax)
    233d:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
    2344:	48 8b 97 c0 00 00 00 	mov    0xc0(%rdi),%rdx
    234b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    2350:	48 89 b2 a4 00 00 00 	mov    %rsi,0xa4(%rdx)
    2357:	48 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdx
    235e:	00 80 3f 
    2361:	48 89 90 08 ff ff ff 	mov    %rdx,-0xf8(%rax)
    2368:	48 89 90 10 ff ff ff 	mov    %rdx,-0xf0(%rax)
    236f:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    2376:	00 00 00 
    2379:	49 8d 95 af c7 07 00 	lea    0x7c7af(%r13),%rdx
    2380:	48 89 57 78          	mov    %rdx,0x78(%rdi)
    2384:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
    238b:	4c 89 80 68 ff ff ff 	mov    %r8,-0x98(%rax)
    2392:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
    2399:	4c 89 80 50 ff ff ff 	mov    %r8,-0xb0(%rax)
    23a0:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
    23a7:	00 00 00 00 
    23ab:	48 89 90 40 ff ff ff 	mov    %rdx,-0xc0(%rax)
    23b2:	39 59 08             	cmp    %ebx,0x8(%rcx)
    23b5:	4d 0f 46 f1          	cmovbe %r9,%r14
    23b9:	48 8b 51 10          	mov    0x10(%rcx),%rdx
    23bd:	c4 a1 78 10 84 32 00 	vmovups 0x2e00(%rdx,%r14,1),%xmm0
    23c4:	2e 00 00 
    23c7:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
    23ce:	ff 
    23cf:	8b 51 08             	mov    0x8(%rcx),%edx
    23d2:	31 f6                	xor    %esi,%esi
    23d4:	31 c0                	xor    %eax,%eax
    23d6:	41 89 d0             	mov    %edx,%r8d
    23d9:	41 29 d8             	sub    %ebx,%r8d
    23dc:	44 8b 57 68          	mov    0x68(%rdi),%r10d
    23e0:	4d 0f 46 d1          	cmovbe %r9,%r10
    23e4:	40 0f 94 c6          	sete   %sil
    23e8:	0f 93 c0             	setae  %al
    23eb:	c1 e6 1e             	shl    $0x1e,%esi
    23ee:	c1 e0 1d             	shl    $0x1d,%eax
    23f1:	09 f0                	or     %esi,%eax
    23f3:	c4 e2 38 f2 f2       	andn   %edx,%r8d,%esi
    23f8:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
    23ff:	44 09 c0             	or     %r8d,%eax
    2402:	c1 ee 03             	shr    $0x3,%esi
    2405:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    240b:	09 c6                	or     %eax,%esi
    240d:	8b 57 70             	mov    0x70(%rdi),%edx
    2410:	49 0f af d2          	imul   %r10,%rdx
    2414:	48 03 51 10          	add    0x10(%rcx),%rdx
    2418:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    241f:	48 8b 82 80 30 00 00 	mov    0x3080(%rdx),%rax
    2426:	48 8b 8f b0 00 00 00 	mov    0xb0(%rdi),%rcx
    242d:	48 8b b7 d0 00 00 00 	mov    0xd0(%rdi),%rsi
    2434:	48 89 0f             	mov    %rcx,(%rdi)
    2437:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    243e:	00 
    243f:	48 8b 8a 88 30 00 00 	mov    0x3088(%rdx),%rcx
    2446:	48 89 4f 50          	mov    %rcx,0x50(%rdi)
    244a:	48 89 06             	mov    %rax,(%rsi)
    244d:	48 89 4e 08          	mov    %rcx,0x8(%rsi)
    2451:	48 8b 82 90 30 00 00 	mov    0x3090(%rdx),%rax
    2458:	48 89 47 48          	mov    %rax,0x48(%rdi)
    245c:	8b 8a 98 30 00 00    	mov    0x3098(%rdx),%ecx
    2462:	48 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%rdx
    2469:	89 4a 08             	mov    %ecx,0x8(%rdx)
    246c:	48 8b 8f e8 00 00 00 	mov    0xe8(%rdi),%rcx
    2473:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
    2477:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    247b:	48 89 02             	mov    %rax,(%rdx)
    247e:	49 8d 85 ea 0b 51 fd 	lea    -0x2aef416(%r13),%rax
    2485:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    248c:	48 89 fb             	mov    %rdi,%rbx
    248f:	c5 f8 77             	vzeroupper
    2492:	e8 00 00 00 00       	call   2497 <f_8001161d0+0x2497>
    2497:	48 89 df             	mov    %rbx,%rdi
    249a:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    24a1:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    24a8:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    24af:	48 89 01             	mov    %rax,(%rcx)
    24b2:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
    24b9:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
    24c0:	48 8b b0 04 16 00 00 	mov    0x1604(%rax),%rsi
    24c7:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
    24cb:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    24cf:	88 51 08             	mov    %dl,0x8(%rcx)
    24d2:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    24d9:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
    24dd:	8b 80 0c 16 00 00    	mov    0x160c(%rax),%eax
    24e3:	48 89 43 40          	mov    %rax,0x40(%rbx)
    24e7:	48 c7 47 48 02 00 00 	movq   $0x2,0x48(%rdi)
    24ee:	00 
    24ef:	89 41 24             	mov    %eax,0x24(%rcx)
    24f2:	c7 81 bc 00 00 00 02 	movl   $0x2,0xbc(%rcx)
    24f9:	00 00 00 
    24fc:	e9 38 07 00 00       	jmp    2c39 <f_8001161d0+0x2c39>
    2501:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    2508:	00 
    2509:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    2510:	48 c7 03 80 00 00 00 	movq   $0x80,(%rbx)
    2517:	48 b9 00 00 00 00 00 	movabs $0x60000000000000,%rcx
    251e:	00 60 00 
    2521:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    2525:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
    252c:	00 
    252d:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    2534:	ff ff ff 
    2537:	48 8d 4e 12          	lea    0x12(%rsi),%rcx
    253b:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    253f:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2546:	00 00 00 
    2549:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
    254d:	48 89 73 28          	mov    %rsi,0x28(%rbx)
    2551:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    2557:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    255b:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    2562:	00 80 3f 
    2565:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    2569:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
    256d:	48 83 c3 38          	add    $0x38,%rbx
    2571:	48 be ca 5d c0 02 08 	movabs $0x802c05dca,%rsi
    2578:	00 00 00 
    257b:	4c 8d 8e 6d 4f 0a 00 	lea    0xa4f6d(%rsi),%r9
    2582:	e9 e3 04 00 00       	jmp    2a6a <f_8001161d0+0x2a6a>
    2587:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
    258e:	48 8b b7 a0 00 00 00 	mov    0xa0(%rdi),%rsi
    2595:	48 8b b6 c8 1e 00 00 	mov    0x1ec8(%rsi),%rsi
    259c:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    25a0:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
    25a5:	48 89 57 60          	mov    %rdx,0x60(%rdi)
    25a9:	48 c7 47 10 00 00 00 	movq   $0x0,0x10(%rdi)
    25b0:	00 
    25b1:	44 0f b6 49 08       	movzbl 0x8(%rcx),%r9d
    25b6:	4c 89 4f 68          	mov    %r9,0x68(%rdi)
    25ba:	8b 5e 08             	mov    0x8(%rsi),%ebx
    25bd:	4d 69 f1 e0 3c 00 00 	imul   $0x3ce0,%r9,%r14
    25c4:	31 c9                	xor    %ecx,%ecx
    25c6:	44 39 cb             	cmp    %r9d,%ebx
    25c9:	48 8b 76 10          	mov    0x10(%rsi),%rsi
    25cd:	48 c7 47 70 e0 3c 00 	movq   $0x3ce0,0x70(%rdi)
    25d4:	00 
    25d5:	4c 0f 46 f1          	cmovbe %rcx,%r14
    25d9:	49 8b b4 36 40 3c 00 	mov    0x3c40(%r14,%rsi,1),%rsi
    25e0:	00 
    25e1:	48 89 37             	mov    %rsi,(%rdi)
    25e4:	4c 8b 8f 00 01 00 00 	mov    0x100(%rdi),%r9
    25eb:	45 89 99 a0 00 00 00 	mov    %r11d,0xa0(%r9)
    25f2:	49 89 91 88 00 00 00 	mov    %rdx,0x88(%r9)
    25f9:	48 be ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rsi
    2600:	ff 7f 7f 
    2603:	49 89 b1 90 00 00 00 	mov    %rsi,0x90(%r9)
    260a:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2611:	00 
    2612:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2616:	41 c7 81 bc 00 00 00 	movl   $0x0,0xbc(%r9)
    261d:	00 00 00 00 
    2621:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2625:	c4 c1 78 11 41 58    	vmovups %xmm0,0x58(%r9)
    262b:	49 c7 01 20 00 00 00 	movq   $0x20,(%r9)
    2632:	48 b8 00 00 00 00 00 	movabs $0x42080000000000,%rax
    2639:	08 42 00 
    263c:	49 89 41 08          	mov    %rax,0x8(%r9)
    2640:	49 c7 41 48 00 00 00 	movq   $0x0,0x48(%r9)
    2647:	00 
    2648:	4d 89 79 50          	mov    %r15,0x50(%r9)
    264c:	49 c7 41 30 07 00 00 	movq   $0x7,0x30(%r9)
    2653:	00 
    2654:	49 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%r9)
    265b:	00 
    265c:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    2663:	ff ff ff 
    2666:	48 8d 42 0a          	lea    0xa(%rdx),%rax
    266a:	49 89 41 18          	mov    %rax,0x18(%r9)
    266e:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2675:	00 00 00 
    2678:	49 89 41 20          	mov    %rax,0x20(%r9)
    267c:	49 89 51 28          	mov    %rdx,0x28(%r9)
    2680:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    2687:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
    268c:	48 89 90 a4 00 00 00 	mov    %rdx,0xa4(%rax)
    2693:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    269a:	00 80 3f 
    269d:	49 89 41 38          	mov    %rax,0x38(%r9)
    26a1:	49 89 41 40          	mov    %rax,0x40(%r9)
    26a5:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    26ac:	00 00 00 
    26af:	49 8d 85 c5 e4 0b 00 	lea    0xbe4c5(%r13),%rax
    26b6:	48 89 47 78          	mov    %rax,0x78(%rdi)
    26ba:	4c 89 87 80 00 00 00 	mov    %r8,0x80(%rdi)
    26c1:	4d 89 81 98 00 00 00 	mov    %r8,0x98(%r9)
    26c8:	48 8b 57 58          	mov    0x58(%rdi),%rdx
    26cc:	49 89 51 78          	mov    %rdx,0x78(%r9)
    26d0:	4d 89 81 80 00 00 00 	mov    %r8,0x80(%r9)
    26d7:	49 c7 41 68 00 00 00 	movq   $0x0,0x68(%r9)
    26de:	00 
    26df:	49 89 41 70          	mov    %rax,0x70(%r9)
    26e3:	48 8b 47 08          	mov    0x8(%rdi),%rax
    26e7:	4c 8b 47 68          	mov    0x68(%rdi),%r8
    26eb:	45 89 c1             	mov    %r8d,%r9d
    26ee:	44 39 40 08          	cmp    %r8d,0x8(%rax)
    26f2:	be 00 00 00 00       	mov    $0x0,%esi
    26f7:	49 0f 47 f1          	cmova  %r9,%rsi
    26fb:	4c 8b 57 48          	mov    0x48(%rdi),%r10
    26ff:	4c 8b 58 10          	mov    0x10(%rax),%r11
    2703:	8b 57 70             	mov    0x70(%rdi),%edx
    2706:	48 0f af f2          	imul   %rdx,%rsi
    270a:	c4 a1 78 10 84 1e b0 	vmovups 0x30b0(%rsi,%r11,1),%xmm0
    2711:	30 00 00 
    2714:	c4 c1 78 11 02       	vmovups %xmm0,(%r10)
    2719:	8b 70 08             	mov    0x8(%rax),%esi
    271c:	45 31 d2             	xor    %r10d,%r10d
    271f:	41 89 f3             	mov    %esi,%r11d
    2722:	45 31 c3             	xor    %r8d,%r11d
    2725:	41 0f 94 c2          	sete   %r10b
    2729:	31 db                	xor    %ebx,%ebx
    272b:	89 f5                	mov    %esi,%ebp
    272d:	44 29 c5             	sub    %r8d,%ebp
    2730:	49 0f 47 c9          	cmova  %r9,%rcx
    2734:	0f 93 c3             	setae  %bl
    2737:	31 ee                	xor    %ebp,%esi
    2739:	44 21 de             	and    %r11d,%esi
    273c:	41 c1 e2 1e          	shl    $0x1e,%r10d
    2740:	c1 e3 1d             	shl    $0x1d,%ebx
    2743:	44 09 d3             	or     %r10d,%ebx
    2746:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    274c:	09 eb                	or     %ebp,%ebx
    274e:	48 8b 40 10          	mov    0x10(%rax),%rax
    2752:	c1 ee 03             	shr    $0x3,%esi
    2755:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    275b:	09 de                	or     %ebx,%esi
    275d:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    2764:	48 0f af ca          	imul   %rdx,%rcx
    2768:	48 8b 94 01 30 33 00 	mov    0x3330(%rcx,%rax,1),%rdx
    276f:	00 
    2770:	48 8b b4 01 38 33 00 	mov    0x3338(%rcx,%rax,1),%rsi
    2777:	00 
    2778:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    277c:	4c 8b 87 d0 00 00 00 	mov    0xd0(%rdi),%r8
    2783:	49 89 10             	mov    %rdx,(%r8)
    2786:	49 89 70 08          	mov    %rsi,0x8(%r8)
    278a:	48 8b 94 01 40 33 00 	mov    0x3340(%rcx,%rax,1),%rdx
    2791:	00 
    2792:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    2796:	8b 84 01 48 33 00 00 	mov    0x3348(%rcx,%rax,1),%eax
    279d:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
    27a4:	89 41 08             	mov    %eax,0x8(%rcx)
    27a7:	48 8b 87 e8 00 00 00 	mov    0xe8(%rdi),%rax
    27ae:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    27b2:	48 89 47 40          	mov    %rax,0x40(%rdi)
    27b6:	48 89 11             	mov    %rdx,(%rcx)
    27b9:	49 8d 85 72 0d 51 fd 	lea    -0x2aef28e(%r13),%rax
    27c0:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    27c7:	48 89 fb             	mov    %rdi,%rbx
    27ca:	c5 f8 77             	vzeroupper
    27cd:	e8 00 00 00 00       	call   27d2 <f_8001161d0+0x27d2>
    27d2:	48 89 df             	mov    %rbx,%rdi
    27d5:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    27dc:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    27e3:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    27ea:	48 89 01             	mov    %rax,(%rcx)
    27ed:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    27f4:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    27f8:	48 89 43 40          	mov    %rax,0x40(%rbx)
    27fc:	88 41 08             	mov    %al,0x8(%rcx)
    27ff:	b9 bc 00 00 00       	mov    $0xbc,%ecx
    2804:	48 03 8b 00 01 00 00 	add    0x100(%rbx),%rcx
    280b:	e9 d4 08 00 00       	jmp    30e4 <f_8001161d0+0x30e4>
    2810:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2814:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    281b:	48 c7 01 01 00 00 00 	movq   $0x1,(%rcx)
    2822:	48 be 00 00 00 00 00 	movabs $0x40000000000000,%rsi
    2829:	00 40 00 
    282c:	48 89 71 08          	mov    %rsi,0x8(%rcx)
    2830:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    2837:	00 
    2838:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    283f:	ff ff ff 
    2842:	4d 89 c1             	mov    %r8,%r9
    2845:	49 89 f0             	mov    %rsi,%r8
    2848:	48 83 c6 15          	add    $0x15,%rsi
    284c:	48 89 71 18          	mov    %rsi,0x18(%rcx)
    2850:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2857:	00 
    2858:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    285f:	00 00 00 
    2862:	48 89 41 20          	mov    %rax,0x20(%rcx)
    2866:	4c 89 41 28          	mov    %r8,0x28(%rcx)
    286a:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    286f:	48 89 41 30          	mov    %rax,0x30(%rcx)
    2873:	48 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rsi
    287a:	00 80 3f 
    287d:	48 89 71 38          	mov    %rsi,0x38(%rcx)
    2881:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    2888:	00 00 00 
    288b:	48 8d 80 7c 4f 0a 00 	lea    0xa4f7c(%rax),%rax
    2892:	48 89 41 70          	mov    %rax,0x70(%rcx)
    2896:	48 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rbx
    289d:	ff 7f 7f 
    28a0:	48 89 59 78          	mov    %rbx,0x78(%rcx)
    28a4:	4c 89 89 80 00 00 00 	mov    %r9,0x80(%rcx)
    28ab:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    28b0:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    28b7:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 28bf <f_8001161d0+0x28bf>
    28be:	00 
    28bf:	c5 fc 11 47 60       	vmovups %ymm0,0x60(%rdi)
    28c4:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    28cb:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    28d0:	4c 89 80 a4 00 00 00 	mov    %r8,0xa4(%rax)
    28d7:	48 89 71 40          	mov    %rsi,0x40(%rcx)
    28db:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    28e2:	00 
    28e3:	48 89 99 90 00 00 00 	mov    %rbx,0x90(%rcx)
    28ea:	4c 89 89 98 00 00 00 	mov    %r9,0x98(%rcx)
    28f1:	48 c7 41 68 00 00 00 	movq   $0x0,0x68(%rcx)
    28f8:	00 
    28f9:	4c 89 79 50          	mov    %r15,0x50(%rcx)
    28fd:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2901:	c5 f8 11 41 58       	vmovups %xmm0,0x58(%rcx)
    2906:	48 c7 47 50 03 00 00 	movq   $0x3,0x50(%rdi)
    290d:	00 
    290e:	b8 03 00 00 00       	mov    $0x3,%eax
    2913:	e9 f1 01 00 00       	jmp    2b09 <f_8001161d0+0x2b09>
    2918:	48 c7 47 40 b0 1e 00 	movq   $0x1eb0,0x40(%rdi)
    291f:	00 
    2920:	48 8b 87 98 00 00 00 	mov    0x98(%rdi),%rax
    2927:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    292e:	48 89 4f 08          	mov    %rcx,0x8(%rdi)
    2932:	48 89 47 10          	mov    %rax,0x10(%rdi)
    2936:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    293b:	48 03 87 a0 00 00 00 	add    0xa0(%rdi),%rax
    2942:	48 89 07             	mov    %rax,(%rdi)
    2945:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    294c:	00 00 00 
    294f:	49 8d 85 2e 0c 51 fd 	lea    -0x2aef3d2(%r13),%rax
    2956:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    295d:	48 89 fb             	mov    %rdi,%rbx
    2960:	c5 f8 77             	vzeroupper
    2963:	e8 00 00 00 00       	call   2968 <f_8001161d0+0x2968>
    2968:	48 89 df             	mov    %rbx,%rdi
    296b:	e9 c9 02 00 00       	jmp    2c39 <f_8001161d0+0x2c39>
    2970:	48 c7 47 78 ff ff 00 	movq   $0xffff,0x78(%rdi)
    2977:	00 
    2978:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    297f:	48 c7 03 03 00 00 00 	movq   $0x3,(%rbx)
    2986:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    298d:	00 40 00 
    2990:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    2994:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
    299b:	00 
    299c:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    29a3:	ff ff ff 
    29a6:	48 8d 4e 0f          	lea    0xf(%rsi),%rcx
    29aa:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    29ae:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    29b5:	00 00 00 
    29b8:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
    29bc:	48 89 73 28          	mov    %rsi,0x28(%rbx)
    29c0:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    29c6:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    29ca:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    29d1:	00 80 3f 
    29d4:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    29d8:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
    29dc:	48 83 c3 38          	add    $0x38,%rbx
    29e0:	48 be ca 5d c0 02 08 	movabs $0x802c05dca,%rsi
    29e7:	00 00 00 
    29ea:	4c 8d 8e fb b3 05 00 	lea    0x5b3fb(%rsi),%r9
    29f1:	eb 77                	jmp    2a6a <f_8001161d0+0x2a6a>
    29f3:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    29fa:	ff ff ff 
    29fd:	48 8d 4e 0e          	lea    0xe(%rsi),%rcx
    2a01:	48 89 4f 78          	mov    %rcx,0x78(%rdi)
    2a05:	48 8b 9f 00 01 00 00 	mov    0x100(%rdi),%rbx
    2a0c:	48 c7 03 00 04 00 00 	movq   $0x400,(%rbx)
    2a13:	48 c7 43 08 00 00 00 	movq   $0x0,0x8(%rbx)
    2a1a:	00 
    2a1b:	48 c7 43 10 ff ff 00 	movq   $0xffff,0x10(%rbx)
    2a22:	00 
    2a23:	48 89 4b 18          	mov    %rcx,0x18(%rbx)
    2a27:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2a2e:	00 00 00 
    2a31:	48 89 4b 20          	mov    %rcx,0x20(%rbx)
    2a35:	48 89 73 28          	mov    %rsi,0x28(%rbx)
    2a39:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
    2a3f:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    2a43:	49 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r14
    2a4a:	00 80 3f 
    2a4d:	4c 89 77 70          	mov    %r14,0x70(%rdi)
    2a51:	48 8d 4b 30          	lea    0x30(%rbx),%rcx
    2a55:	48 83 c3 38          	add    $0x38,%rbx
    2a59:	48 be ca 5d c0 02 08 	movabs $0x802c05dca,%rsi
    2a60:	00 00 00 
    2a63:	4c 8d 8e d9 85 00 00 	lea    0x85d9(%rsi),%r9
    2a6a:	4c 89 01             	mov    %r8,(%rcx)
    2a6d:	4c 89 33             	mov    %r14,(%rbx)
    2a70:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    2a77:	4c 89 49 70          	mov    %r9,0x70(%rcx)
    2a7b:	49 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r9
    2a82:	ff 7f 7f 
    2a85:	4c 89 49 78          	mov    %r9,0x78(%rcx)
    2a89:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
    2a90:	ff 7f ff 
    2a93:	48 89 77 68          	mov    %rsi,0x68(%rdi)
    2a97:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2a9b:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2aa2:	00 
    2aa3:	48 89 b1 80 00 00 00 	mov    %rsi,0x80(%rcx)
    2aaa:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    2aaf:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    2ab6:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
    2abb:	4c 89 47 60          	mov    %r8,0x60(%rdi)
    2abf:	4c 89 71 40          	mov    %r14,0x40(%rcx)
    2ac3:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    2aca:	00 
    2acb:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    2ad2:	4c 89 80 a4 00 00 00 	mov    %r8,0xa4(%rax)
    2ad9:	4c 89 79 50          	mov    %r15,0x50(%rcx)
    2add:	48 c7 41 58 00 00 00 	movq   $0x0,0x58(%rcx)
    2ae4:	00 
    2ae5:	48 c7 47 50 02 00 00 	movq   $0x2,0x50(%rdi)
    2aec:	00 
    2aed:	4c 89 89 90 00 00 00 	mov    %r9,0x90(%rcx)
    2af4:	48 89 b1 98 00 00 00 	mov    %rsi,0x98(%rcx)
    2afb:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2aff:	c5 f8 11 41 60       	vmovups %xmm0,0x60(%rcx)
    2b04:	b8 02 00 00 00       	mov    $0x2,%eax
    2b09:	48 8b 5c 24 20       	mov    0x20(%rsp),%rbx
    2b0e:	44 89 99 a0 00 00 00 	mov    %r11d,0xa0(%rcx)
    2b15:	89 81 bc 00 00 00    	mov    %eax,0xbc(%rcx)
    2b1b:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
    2b22:	48 8b 87 a0 00 00 00 	mov    0xa0(%rdi),%rax
    2b29:	48 8b 80 c8 1e 00 00 	mov    0x1ec8(%rax),%rax
    2b30:	0f b6 71 08          	movzbl 0x8(%rcx),%esi
    2b34:	4c 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%r8
    2b3b:	31 c9                	xor    %ecx,%ecx
    2b3d:	39 70 08             	cmp    %esi,0x8(%rax)
    2b40:	ba 00 00 00 00       	mov    $0x0,%edx
    2b45:	49 0f 47 d0          	cmova  %r8,%rdx
    2b49:	4c 8b 48 10          	mov    0x10(%rax),%r9
    2b4d:	4e 8b 94 0a 08 2e 00 	mov    0x2e08(%rdx,%r9,1),%r10
    2b54:	00 
    2b55:	4c 89 57 68          	mov    %r10,0x68(%rdi)
    2b59:	4a 8b 94 0a 00 2e 00 	mov    0x2e00(%rdx,%r9,1),%rdx
    2b60:	00 
    2b61:	48 89 13             	mov    %rdx,(%rbx)
    2b64:	4c 89 53 08          	mov    %r10,0x8(%rbx)
    2b68:	44 8b 48 08          	mov    0x8(%rax),%r9d
    2b6c:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2b70:	48 89 57 60          	mov    %rdx,0x60(%rdi)
    2b74:	45 31 d2             	xor    %r10d,%r10d
    2b77:	45 31 db             	xor    %r11d,%r11d
    2b7a:	44 89 cb             	mov    %r9d,%ebx
    2b7d:	29 f3                	sub    %esi,%ebx
    2b7f:	49 0f 47 c8          	cmova  %r8,%rcx
    2b83:	41 0f 94 c2          	sete   %r10b
    2b87:	41 0f 93 c3          	setae  %r11b
    2b8b:	c4 c2 60 f2 f1       	andn   %r9d,%ebx,%esi
    2b90:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    2b96:	41 c1 e2 1e          	shl    $0x1e,%r10d
    2b9a:	41 c1 e3 1d          	shl    $0x1d,%r11d
    2b9e:	45 09 d3             	or     %r10d,%r11d
    2ba1:	41 09 db             	or     %ebx,%r11d
    2ba4:	c1 ee 03             	shr    $0x3,%esi
    2ba7:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    2bad:	44 09 de             	or     %r11d,%esi
    2bb0:	48 89 b7 10 01 00 00 	mov    %rsi,0x110(%rdi)
    2bb7:	48 8b b4 0a 80 30 00 	mov    0x3080(%rdx,%rcx,1),%rsi
    2bbe:	00 
    2bbf:	4c 8b 84 0a 88 30 00 	mov    0x3088(%rdx,%rcx,1),%r8
    2bc6:	00 
    2bc7:	48 89 77 58          	mov    %rsi,0x58(%rdi)
    2bcb:	49 89 75 00          	mov    %rsi,0x0(%r13)
    2bcf:	4d 89 45 08          	mov    %r8,0x8(%r13)
    2bd3:	8b b4 0a 98 30 00 00 	mov    0x3098(%rdx,%rcx,1),%esi
    2bda:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    2bde:	48 8b 8c 0a 90 30 00 	mov    0x3090(%rdx,%rcx,1),%rcx
    2be5:	00 
    2be6:	48 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%rdx
    2bed:	48 89 0a             	mov    %rcx,(%rdx)
    2bf0:	89 72 08             	mov    %esi,0x8(%rdx)
    2bf3:	8b 50 20             	mov    0x20(%rax),%edx
    2bf6:	8b 48 24             	mov    0x24(%rax),%ecx
    2bf9:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    2bfd:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    2c01:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    2c08:	c7 80 b4 00 00 00 00 	movl   $0x0,0xb4(%rax)
    2c0f:	00 00 00 
    2c12:	48 8b b7 c0 00 00 00 	mov    0xc0(%rdi),%rsi
    2c19:	c7 86 b1 00 00 00 00 	movl   $0x0,0xb1(%rsi)
    2c20:	00 00 00 
    2c23:	88 90 b0 00 00 00    	mov    %dl,0xb0(%rax)
    2c29:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    2c30:	00 00 00 
    2c33:	88 88 b8 00 00 00    	mov    %cl,0xb8(%rax)
    2c39:	4c 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%r9
    2c40:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    2c47:	8b 08                	mov    (%rax),%ecx
    2c49:	48 89 4f 50          	mov    %rcx,0x50(%rdi)
    2c4d:	49 8d 51 1c          	lea    0x1c(%r9),%rdx
    2c51:	41 8b 71 1c          	mov    0x1c(%r9),%esi
    2c55:	48 89 57 40          	mov    %rdx,0x40(%rdi)
    2c59:	48 89 77 48          	mov    %rsi,0x48(%rdi)
    2c5d:	89 70 48             	mov    %esi,0x48(%rax)
    2c60:	4d 8d 51 2c          	lea    0x2c(%r9),%r10
    2c64:	45 8b 41 2c          	mov    0x2c(%r9),%r8d
    2c68:	45 31 db             	xor    %r11d,%r11d
    2c6b:	4d 85 c0             	test   %r8,%r8
    2c6e:	41 0f 94 c3          	sete   %r11b
    2c72:	4c 89 97 b0 00 00 00 	mov    %r10,0xb0(%rdi)
    2c79:	4c 89 47 60          	mov    %r8,0x60(%rdi)
    2c7d:	45 8b 49 14          	mov    0x14(%r9),%r9d
    2c81:	45 31 d2             	xor    %r10d,%r10d
    2c84:	41 85 c9             	test   %ecx,%r9d
    2c87:	41 0f 95 c2          	setne  %r10b
    2c8b:	4c 89 57 58          	mov    %r10,0x58(%rdi)
    2c8f:	45 89 c2             	mov    %r8d,%r10d
    2c92:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    2c99:	44 89 db             	mov    %r11d,%ebx
    2c9c:	c1 e3 1e             	shl    $0x1e,%ebx
    2c9f:	49 01 da             	add    %rbx,%r10
    2ca2:	49 81 c2 00 00 00 20 	add    $0x20000000,%r10
    2ca9:	4c 89 97 10 01 00 00 	mov    %r10,0x110(%rdi)
    2cb0:	41 c1 e8 1f          	shr    $0x1f,%r8d
    2cb4:	45 08 c3             	or     %r8b,%r11b
    2cb7:	74 0d                	je     2cc6 <f_8001161d0+0x2cc6>
    2cb9:	48 c7 47 58 00 00 00 	movq   $0x0,0x58(%rdi)
    2cc0:	00 
    2cc1:	e9 73 01 00 00       	jmp    2e39 <f_8001161d0+0x2e39>
    2cc6:	41 85 c9             	test   %ecx,%r9d
    2cc9:	0f 84 6a 01 00 00    	je     2e39 <f_8001161d0+0x2e39>
    2ccf:	4c 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%r9
    2cd6:	4c 8b 97 a8 00 00 00 	mov    0xa8(%rdi),%r10
    2cdd:	4d 8d 81 40 01 00 00 	lea    0x140(%r9),%r8
    2ce4:	4c 89 87 c0 00 00 00 	mov    %r8,0xc0(%rdi)
    2ceb:	45 89 d0             	mov    %r10d,%r8d
    2cee:	4d 63 d2             	movslq %r10d,%r10
    2cf1:	49 c1 fa 1f          	sar    $0x1f,%r10
    2cf5:	49 bb 00 00 00 00 ff 	movabs $0xffffffff00000000,%r11
    2cfc:	ff ff ff 
    2cff:	4d 21 da             	and    %r11,%r10
    2d02:	4d 09 c2             	or     %r8,%r10
    2d05:	4c 89 97 c8 00 00 00 	mov    %r10,0xc8(%rdi)
    2d0c:	47 0f b6 8c 11 40 01 	movzbl 0x140(%r9,%r10,1),%r9d
    2d13:	00 00 
    2d15:	4c 89 4f 58          	mov    %r9,0x58(%rdi)
    2d19:	41 f6 c1 01          	test   $0x1,%r9b
    2d1d:	0f 84 16 01 00 00    	je     2e39 <f_8001161d0+0x2e39>
    2d23:	44 0f b6 48 0c       	movzbl 0xc(%rax),%r9d
    2d28:	4c 89 4f 58          	mov    %r9,0x58(%rdi)
    2d2c:	41 f6 c1 01          	test   $0x1,%r9b
    2d30:	74 09                	je     2d3b <f_8001161d0+0x2d3b>
    2d32:	48 09 ce             	or     %rcx,%rsi
    2d35:	48 89 77 48          	mov    %rsi,0x48(%rdi)
    2d39:	89 32                	mov    %esi,(%rdx)
    2d3b:	48 c7 47 40 d0 00 00 	movq   $0xd0,0x40(%rdi)
    2d42:	00 
    2d43:	48 89 47 08          	mov    %rax,0x8(%rdi)
    2d47:	49 63 c0             	movslq %r8d,%rax
    2d4a:	48 69 c0 d0 00 00 00 	imul   $0xd0,%rax,%rax
    2d51:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
    2d58:	48 8d 14 01          	lea    (%rcx,%rax,1),%rdx
    2d5c:	48 89 97 d0 00 00 00 	mov    %rdx,0xd0(%rdi)
    2d63:	48 c7 47 10 c0 00 00 	movq   $0xc0,0x10(%rdi)
    2d6a:	00 
    2d6b:	48 8d 84 01 40 0d 00 	lea    0xd40(%rcx,%rax,1),%rax
    2d72:	00 
    2d73:	48 89 87 a8 00 00 00 	mov    %rax,0xa8(%rdi)
    2d7a:	48 89 07             	mov    %rax,(%rdi)
    2d7d:	49 8d 85 6e 12 51 fd 	lea    -0x2aeed92(%r13),%rax
    2d84:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    2d8b:	48 89 fb             	mov    %rdi,%rbx
    2d8e:	c5 f8 77             	vzeroupper
    2d91:	e8 00 00 00 00       	call   2d96 <f_8001161d0+0x2d96>
    2d96:	48 89 df             	mov    %rbx,%rdi
    2d99:	48 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%rax
    2da0:	80 88 38 0d 00 00 01 	orb    $0x1,0xd38(%rax)
    2da7:	4c 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%r8
    2dae:	41 0f b6 80 81 3a 00 	movzbl 0x3a81(%r8),%eax
    2db5:	00 
    2db6:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2dba:	a8 40                	test   $0x40,%al
    2dbc:	74 7b                	je     2e39 <f_8001161d0+0x2e39>
    2dbe:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    2dc5:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
    2dcc:	0f b6 04 01          	movzbl (%rcx,%rax,1),%eax
    2dd0:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2dd4:	a8 02                	test   $0x2,%al
    2dd6:	74 61                	je     2e39 <f_8001161d0+0x2e39>
    2dd8:	49 8b 80 60 3b 00 00 	mov    0x3b60(%r8),%rax
    2ddf:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2de3:	48 85 c0             	test   %rax,%rax
    2de6:	74 51                	je     2e39 <f_8001161d0+0x2e39>
    2de8:	41 0f b6 80 85 3a 00 	movzbl 0x3a85(%r8),%eax
    2def:	00 
    2df0:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2df4:	a8 02                	test   $0x2,%al
    2df6:	74 41                	je     2e39 <f_8001161d0+0x2e39>
    2df8:	48 8b 87 a8 00 00 00 	mov    0xa8(%rdi),%rax
    2dff:	48 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%rcx
    2e06:	8b 00                	mov    (%rax),%eax
    2e08:	48 89 47 40          	mov    %rax,0x40(%rdi)
    2e0c:	8b 49 10             	mov    0x10(%rcx),%ecx
    2e0f:	31 d2                	xor    %edx,%edx
    2e11:	c4 e2 70 f2 c0       	andn   %eax,%ecx,%eax
    2e16:	0f 94 c2             	sete   %dl
    2e19:	89 c6                	mov    %eax,%esi
    2e1b:	81 e6 00 00 00 80    	and    $0x80000000,%esi
    2e21:	c1 e2 1e             	shl    $0x1e,%edx
    2e24:	09 f2                	or     %esi,%edx
    2e26:	48 89 4f 48          	mov    %rcx,0x48(%rdi)
    2e2a:	48 89 97 10 01 00 00 	mov    %rdx,0x110(%rdi)
    2e31:	85 c0                	test   %eax,%eax
    2e33:	0f 84 aa 05 00 00    	je     33e3 <f_8001161d0+0x33e3>
    2e39:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    2e40:	48 8b 88 20 01 00 00 	mov    0x120(%rax),%rcx
    2e47:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    2e4e:	48 89 8f a0 00 00 00 	mov    %rcx,0xa0(%rdi)
    2e55:	48 89 97 98 00 00 00 	mov    %rdx,0x98(%rdi)
    2e5c:	48 8b 88 10 01 00 00 	mov    0x110(%rax),%rcx
    2e63:	48 8b 90 18 01 00 00 	mov    0x118(%rax),%rdx
    2e6a:	48 89 8f b0 00 00 00 	mov    %rcx,0xb0(%rdi)
    2e71:	48 89 97 a8 00 00 00 	mov    %rdx,0xa8(%rdi)
    2e78:	48 8b 88 00 01 00 00 	mov    0x100(%rax),%rcx
    2e7f:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    2e86:	48 89 8f c0 00 00 00 	mov    %rcx,0xc0(%rdi)
    2e8d:	48 89 97 b8 00 00 00 	mov    %rdx,0xb8(%rdi)
    2e94:	48 8b 88 f0 00 00 00 	mov    0xf0(%rax),%rcx
    2e9b:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
    2ea2:	48 89 8f d0 00 00 00 	mov    %rcx,0xd0(%rdi)
    2ea9:	48 89 97 c8 00 00 00 	mov    %rdx,0xc8(%rdi)
    2eb0:	48 8b 88 e0 00 00 00 	mov    0xe0(%rax),%rcx
    2eb7:	48 8b 90 e8 00 00 00 	mov    0xe8(%rax),%rdx
    2ebe:	48 89 8f e0 00 00 00 	mov    %rcx,0xe0(%rdi)
    2ec5:	48 89 97 d8 00 00 00 	mov    %rdx,0xd8(%rdi)
    2ecc:	c5 f8 10 80 d0 00 00 	vmovups 0xd0(%rax),%xmm0
    2ed3:	00 
    2ed4:	c5 f8 11 87 e8 00 00 	vmovups %xmm0,0xe8(%rdi)
    2edb:	00 
    2edc:	48 05 30 01 00 00    	add    $0x130,%rax
    2ee2:	48 89 87 00 01 00 00 	mov    %rax,0x100(%rdi)
    2ee9:	48 83 c4 28          	add    $0x28,%rsp
    2eed:	5b                   	pop    %rbx
    2eee:	41 5c                	pop    %r12
    2ef0:	41 5d                	pop    %r13
    2ef2:	41 5e                	pop    %r14
    2ef4:	41 5f                	pop    %r15
    2ef6:	5d                   	pop    %rbp
    2ef7:	c5 f8 77             	vzeroupper
    2efa:	c3                   	ret
    2efb:	4c 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%r9
    2f02:	49 8b 89 c8 1e 00 00 	mov    0x1ec8(%r9),%rcx
    2f09:	48 89 8f b0 00 00 00 	mov    %rcx,0xb0(%rdi)
    2f10:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    2f17:	ff ff ff 
    2f1a:	48 8d 75 1a          	lea    0x1a(%rbp),%rsi
    2f1e:	48 89 77 70          	mov    %rsi,0x70(%rdi)
    2f22:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2f26:	48 8b 8f 00 01 00 00 	mov    0x100(%rdi),%rcx
    2f2d:	48 c7 01 00 20 00 00 	movq   $0x2000,(%rcx)
    2f34:	48 c7 41 08 00 00 00 	movq   $0x0,0x8(%rcx)
    2f3b:	00 
    2f3c:	48 c7 41 10 ff ff 00 	movq   $0xffff,0x10(%rcx)
    2f43:	00 
    2f44:	48 89 71 18          	mov    %rsi,0x18(%rcx)
    2f48:	48 8b b7 98 00 00 00 	mov    0x98(%rdi),%rsi
    2f4f:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    2f53:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2f5a:	00 
    2f5b:	44 89 99 a0 00 00 00 	mov    %r11d,0xa0(%rcx)
    2f62:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    2f69:	00 00 00 
    2f6c:	48 89 41 20          	mov    %rax,0x20(%rcx)
    2f70:	48 89 69 28          	mov    %rbp,0x28(%rcx)
    2f74:	48 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rsi
    2f7b:	00 80 3f 
    2f7e:	48 89 77 68          	mov    %rsi,0x68(%rdi)
    2f82:	b8 ff ff ff ff       	mov    $0xffffffff,%eax
    2f87:	48 89 41 30          	mov    %rax,0x30(%rcx)
    2f8b:	48 89 71 38          	mov    %rsi,0x38(%rcx)
    2f8f:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    2f96:	00 00 00 
    2f99:	49 8d 85 95 53 09 00 	lea    0x95395(%r13),%rax
    2fa0:	48 89 41 70          	mov    %rax,0x70(%rcx)
    2fa4:	49 bb ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r11
    2fab:	ff 7f 7f 
    2fae:	4c 89 59 78          	mov    %r11,0x78(%rcx)
    2fb2:	4c 89 81 80 00 00 00 	mov    %r8,0x80(%rcx)
    2fb9:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    2fbe:	48 89 81 88 00 00 00 	mov    %rax,0x88(%rcx)
    2fc5:	4c 8b 54 24 08       	mov    0x8(%rsp),%r10
    2fca:	4c 89 57 60          	mov    %r10,0x60(%rdi)
    2fce:	48 8b 87 c0 00 00 00 	mov    0xc0(%rdi),%rax
    2fd5:	4c 89 90 a4 00 00 00 	mov    %r10,0xa4(%rax)
    2fdc:	4c 89 99 90 00 00 00 	mov    %r11,0x90(%rcx)
    2fe3:	4c 89 81 98 00 00 00 	mov    %r8,0x98(%rcx)
    2fea:	48 c7 47 50 b0 1e 00 	movq   $0x1eb0,0x50(%rdi)
    2ff1:	00 
    2ff2:	49 81 c1 b0 1e 00 00 	add    $0x1eb0,%r9
    2ff9:	4c 89 0f             	mov    %r9,(%rdi)
    2ffc:	4c 89 79 50          	mov    %r15,0x50(%rcx)
    3000:	48 c7 41 58 00 00 00 	movq   $0x0,0x58(%rcx)
    3007:	00 
    3008:	48 c7 47 48 03 00 00 	movq   $0x3,0x48(%rdi)
    300f:	00 
    3010:	c7 81 bc 00 00 00 03 	movl   $0x3,0xbc(%rcx)
    3017:	00 00 00 
    301a:	48 89 71 40          	mov    %rsi,0x40(%rcx)
    301e:	48 c7 41 48 00 00 00 	movq   $0x0,0x48(%rcx)
    3025:	00 
    3026:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    302a:	c5 f8 11 41 60       	vmovups %xmm0,0x60(%rcx)
    302f:	49 8d 85 92 14 51 fd 	lea    -0x2aeeb6e(%r13),%rax
    3036:	48 89 87 f0 00 00 00 	mov    %rax,0xf0(%rdi)
    303d:	48 89 fb             	mov    %rdi,%rbx
    3040:	c5 f8 77             	vzeroupper
    3043:	e8 00 00 00 00       	call   3048 <f_8001161d0+0x3048>
    3048:	48 89 df             	mov    %rbx,%rdi
    304b:	48 8b 33             	mov    (%rbx),%rsi
    304e:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    3055:	0f b6 48 08          	movzbl 0x8(%rax),%ecx
    3059:	48 8b 93 b0 00 00 00 	mov    0xb0(%rbx),%rdx
    3060:	8b 42 08             	mov    0x8(%rdx),%eax
    3063:	45 31 c0             	xor    %r8d,%r8d
    3066:	45 31 c9             	xor    %r9d,%r9d
    3069:	41 89 c2             	mov    %eax,%r10d
    306c:	41 29 ca             	sub    %ecx,%r10d
    306f:	41 0f 94 c0          	sete   %r8b
    3073:	41 0f 93 c1          	setae  %r9b
    3077:	c4 62 28 f2 d8       	andn   %eax,%r10d,%r11d
    307c:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    3083:	41 c1 e0 1e          	shl    $0x1e,%r8d
    3087:	41 c1 e1 1d          	shl    $0x1d,%r9d
    308b:	45 09 c1             	or     %r8d,%r9d
    308e:	41 c1 eb 03          	shr    $0x3,%r11d
    3092:	41 81 e3 00 00 00 10 	and    $0x10000000,%r11d
    3099:	45 09 d3             	or     %r10d,%r11d
    309c:	45 09 cb             	or     %r9d,%r11d
    309f:	4c 69 c1 e0 3c 00 00 	imul   $0x3ce0,%rcx,%r8
    30a6:	31 c0                	xor    %eax,%eax
    30a8:	41 81 f9 00 00 00 20 	cmp    $0x20000000,%r9d
    30af:	49 0f 44 c0          	cmove  %r8,%rax
    30b3:	4c 89 9b 10 01 00 00 	mov    %r11,0x110(%rbx)
    30ba:	48 03 42 10          	add    0x10(%rdx),%rax
    30be:	40 f6 c6 01          	test   $0x1,%sil
    30c2:	75 33                	jne    30f7 <f_8001161d0+0x30f7>
    30c4:	41 b9 5c 00 00 00    	mov    $0x5c,%r9d
    30ca:	41 ba 58 00 00 00    	mov    $0x58,%r10d
    30d0:	41 bb 54 00 00 00    	mov    $0x54,%r11d
    30d6:	bb 50 00 00 00       	mov    $0x50,%ebx
    30db:	eb 35                	jmp    3112 <f_8001161d0+0x3112>
    30dd:	48 81 c1 bc 00 00 00 	add    $0xbc,%rcx
    30e4:	48 c7 47 40 02 00 00 	movq   $0x2,0x40(%rdi)
    30eb:	00 
    30ec:	c7 01 02 00 00 00    	movl   $0x2,(%rcx)
    30f2:	e9 42 fb ff ff       	jmp    2c39 <f_8001161d0+0x2c39>
    30f7:	48 89 47 68          	mov    %rax,0x68(%rdi)
    30fb:	41 b9 0c 2e 00 00    	mov    $0x2e0c,%r9d
    3101:	41 ba 08 2e 00 00    	mov    $0x2e08,%r10d
    3107:	41 bb 04 2e 00 00    	mov    $0x2e04,%r11d
    310d:	bb 00 2e 00 00       	mov    $0x2e00,%ebx
    3112:	8b 1c 18             	mov    (%rax,%rbx,1),%ebx
    3115:	48 89 9f 00 02 00 00 	mov    %rbx,0x200(%rdi)
    311c:	48 c7 87 08 02 00 00 	movq   $0x0,0x208(%rdi)
    3123:	00 00 00 00 
    3127:	46 8b 1c 18          	mov    (%rax,%r11,1),%r11d
    312b:	4c 89 9f 10 02 00 00 	mov    %r11,0x210(%rdi)
    3132:	48 c7 87 18 02 00 00 	movq   $0x0,0x218(%rdi)
    3139:	00 00 00 00 
    313d:	46 8b 14 10          	mov    (%rax,%r10,1),%r10d
    3141:	4c 89 97 20 02 00 00 	mov    %r10,0x220(%rdi)
    3148:	48 c7 87 28 02 00 00 	movq   $0x0,0x228(%rdi)
    314f:	00 00 00 00 
    3153:	48 c7 47 58 e0 3c 00 	movq   $0x3ce0,0x58(%rdi)
    315a:	00 
    315b:	46 8b 0c 08          	mov    (%rax,%r9,1),%r9d
    315f:	4c 89 8f 30 02 00 00 	mov    %r9,0x230(%rdi)
    3166:	48 c7 87 38 02 00 00 	movq   $0x0,0x238(%rdi)
    316d:	00 00 00 00 
    3171:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
    3178:	89 58 78             	mov    %ebx,0x78(%rax)
    317b:	44 89 58 7c          	mov    %r11d,0x7c(%rax)
    317f:	44 89 90 80 00 00 00 	mov    %r10d,0x80(%rax)
    3186:	44 89 88 84 00 00 00 	mov    %r9d,0x84(%rax)
    318d:	45 31 c9             	xor    %r9d,%r9d
    3190:	39 4a 08             	cmp    %ecx,0x8(%rdx)
    3193:	4d 0f 47 c8          	cmova  %r8,%r9
    3197:	4c 8b 52 10          	mov    0x10(%rdx),%r10
    319b:	40 f6 c6 01          	test   $0x1,%sil
    319f:	0f 85 8b 00 00 00    	jne    3230 <f_8001161d0+0x3230>
    31a5:	4b 8b 74 11 20       	mov    0x20(%r9,%r10,1),%rsi
    31aa:	4f 8b 5c 11 28       	mov    0x28(%r9,%r10,1),%r11
    31af:	4c 89 5f 60          	mov    %r11,0x60(%rdi)
    31b3:	48 8b 9f d0 00 00 00 	mov    0xd0(%rdi),%rbx
    31ba:	48 89 33             	mov    %rsi,(%rbx)
    31bd:	4c 89 5b 08          	mov    %r11,0x8(%rbx)
    31c1:	4b 8b 74 11 30       	mov    0x30(%r9,%r10,1),%rsi
    31c6:	47 8b 4c 11 38       	mov    0x38(%r9,%r10,1),%r9d
    31cb:	4c 89 4f 48          	mov    %r9,0x48(%rdi)
    31cf:	4c 8b 97 c8 00 00 00 	mov    0xc8(%rdi),%r10
    31d6:	45 89 4a 08          	mov    %r9d,0x8(%r10)
    31da:	49 89 32             	mov    %rsi,(%r10)
    31dd:	44 8b 52 08          	mov    0x8(%rdx),%r10d
    31e1:	48 8b 72 10          	mov    0x10(%rdx),%rsi
    31e5:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    31e9:	45 31 c9             	xor    %r9d,%r9d
    31ec:	45 31 db             	xor    %r11d,%r11d
    31ef:	31 db                	xor    %ebx,%ebx
    31f1:	44 89 d5             	mov    %r10d,%ebp
    31f4:	29 cd                	sub    %ecx,%ebp
    31f6:	4d 0f 47 c8          	cmova  %r8,%r9
    31fa:	41 0f 94 c3          	sete   %r11b
    31fe:	0f 93 c3             	setae  %bl
    3201:	c4 c2 50 f2 d2       	andn   %r10d,%ebp,%edx
    3206:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    320c:	41 c1 e3 1e          	shl    $0x1e,%r11d
    3210:	c1 e3 1d             	shl    $0x1d,%ebx
    3213:	44 09 db             	or     %r11d,%ebx
    3216:	09 eb                	or     %ebp,%ebx
    3218:	c1 ea 03             	shr    $0x3,%edx
    321b:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    3221:	09 da                	or     %ebx,%edx
    3223:	4a 8d 0c 0e          	lea    (%rsi,%r9,1),%rcx
    3227:	48 83 c1 40          	add    $0x40,%rcx
    322b:	e9 a8 00 00 00       	jmp    32d8 <f_8001161d0+0x32d8>
    3230:	4b 8b b4 11 80 30 00 	mov    0x3080(%r9,%r10,1),%rsi
    3237:	00 
    3238:	4f 8b 84 11 88 30 00 	mov    0x3088(%r9,%r10,1),%r8
    323f:	00 
    3240:	4c 89 47 60          	mov    %r8,0x60(%rdi)
    3244:	4c 8b 9f d0 00 00 00 	mov    0xd0(%rdi),%r11
    324b:	49 89 33             	mov    %rsi,(%r11)
    324e:	4d 89 43 08          	mov    %r8,0x8(%r11)
    3252:	4b 8b b4 11 90 30 00 	mov    0x3090(%r9,%r10,1),%rsi
    3259:	00 
    325a:	47 8b 84 11 98 30 00 	mov    0x3098(%r9,%r10,1),%r8d
    3261:	00 
    3262:	4c 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%r9
    3269:	45 89 41 08          	mov    %r8d,0x8(%r9)
    326d:	49 89 31             	mov    %rsi,(%r9)
    3270:	44 8b 4a 08          	mov    0x8(%rdx),%r9d
    3274:	48 8b 72 10          	mov    0x10(%rdx),%rsi
    3278:	48 89 77 50          	mov    %rsi,0x50(%rdi)
    327c:	45 31 c0             	xor    %r8d,%r8d
    327f:	45 31 d2             	xor    %r10d,%r10d
    3282:	45 31 db             	xor    %r11d,%r11d
    3285:	44 89 cb             	mov    %r9d,%ebx
    3288:	29 cb                	sub    %ecx,%ebx
    328a:	41 0f 94 c2          	sete   %r10b
    328e:	41 0f 93 c3          	setae  %r11b
    3292:	4c 0f 47 c1          	cmova  %rcx,%r8
    3296:	c4 c2 60 f2 d1       	andn   %r9d,%ebx,%edx
    329b:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    32a1:	41 c1 e2 1e          	shl    $0x1e,%r10d
    32a5:	41 c1 e3 1d          	shl    $0x1d,%r11d
    32a9:	45 09 d3             	or     %r10d,%r11d
    32ac:	41 09 db             	or     %ebx,%r11d
    32af:	c1 ea 03             	shr    $0x3,%edx
    32b2:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    32b8:	44 09 da             	or     %r11d,%edx
    32bb:	48 c7 47 48 f0 2d 00 	movq   $0x2df0,0x48(%rdi)
    32c2:	00 
    32c3:	4c 89 47 40          	mov    %r8,0x40(%rdi)
    32c7:	49 69 c8 e0 3c 00 00 	imul   $0x3ce0,%r8,%rcx
    32ce:	48 01 f1             	add    %rsi,%rcx
    32d1:	48 81 c1 f0 2d 00 00 	add    $0x2df0,%rcx
    32d8:	48 89 97 10 01 00 00 	mov    %rdx,0x110(%rdi)
    32df:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    32e3:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    32e7:	48 85 d2             	test   %rdx,%rdx
    32ea:	74 0d                	je     32f9 <f_8001161d0+0x32f9>
    32ec:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    32f3:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    32f7:	eb 02                	jmp    32fb <f_8001161d0+0x32fb>
    32f9:	31 d2                	xor    %edx,%edx
    32fb:	88 90 b0 00 00 00    	mov    %dl,0xb0(%rax)
    3301:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    3305:	48 85 d2             	test   %rdx,%rdx
    3308:	74 09                	je     3313 <f_8001161d0+0x3313>
    330a:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3311:	eb 02                	jmp    3315 <f_8001161d0+0x3315>
    3313:	31 d2                	xor    %edx,%edx
    3315:	88 90 b1 00 00 00    	mov    %dl,0xb1(%rax)
    331b:	48 8b 51 30          	mov    0x30(%rcx),%rdx
    331f:	48 85 d2             	test   %rdx,%rdx
    3322:	74 0d                	je     3331 <f_8001161d0+0x3331>
    3324:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    332b:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    332f:	eb 02                	jmp    3333 <f_8001161d0+0x3333>
    3331:	31 d2                	xor    %edx,%edx
    3333:	88 90 b2 00 00 00    	mov    %dl,0xb2(%rax)
    3339:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    333d:	48 85 d2             	test   %rdx,%rdx
    3340:	74 09                	je     334b <f_8001161d0+0x334b>
    3342:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3349:	eb 02                	jmp    334d <f_8001161d0+0x334d>
    334b:	31 d2                	xor    %edx,%edx
    334d:	88 90 b3 00 00 00    	mov    %dl,0xb3(%rax)
    3353:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    3357:	48 85 d2             	test   %rdx,%rdx
    335a:	74 0d                	je     3369 <f_8001161d0+0x3369>
    335c:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3363:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    3367:	eb 02                	jmp    336b <f_8001161d0+0x336b>
    3369:	31 d2                	xor    %edx,%edx
    336b:	88 90 b4 00 00 00    	mov    %dl,0xb4(%rax)
    3371:	48 8b 51 48          	mov    0x48(%rcx),%rdx
    3375:	48 85 d2             	test   %rdx,%rdx
    3378:	74 09                	je     3383 <f_8001161d0+0x3383>
    337a:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3381:	eb 02                	jmp    3385 <f_8001161d0+0x3385>
    3383:	31 d2                	xor    %edx,%edx
    3385:	88 90 b5 00 00 00    	mov    %dl,0xb5(%rax)
    338b:	48 8b 51 50          	mov    0x50(%rcx),%rdx
    338f:	48 85 d2             	test   %rdx,%rdx
    3392:	74 09                	je     339d <f_8001161d0+0x339d>
    3394:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    339b:	eb 02                	jmp    339f <f_8001161d0+0x339f>
    339d:	31 d2                	xor    %edx,%edx
    339f:	88 90 b6 00 00 00    	mov    %dl,0xb6(%rax)
    33a5:	48 8b 51 58          	mov    0x58(%rcx),%rdx
    33a9:	48 85 d2             	test   %rdx,%rdx
    33ac:	74 0d                	je     33bb <f_8001161d0+0x33bb>
    33ae:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    33b5:	48 89 57 48          	mov    %rdx,0x48(%rdi)
    33b9:	eb 02                	jmp    33bd <f_8001161d0+0x33bd>
    33bb:	31 d2                	xor    %edx,%edx
    33bd:	88 90 b7 00 00 00    	mov    %dl,0xb7(%rax)
    33c3:	48 8b 49 60          	mov    0x60(%rcx),%rcx
    33c7:	48 85 c9             	test   %rcx,%rcx
    33ca:	74 10                	je     33dc <f_8001161d0+0x33dc>
    33cc:	0f b6 89 c0 00 00 00 	movzbl 0xc0(%rcx),%ecx
    33d3:	48 89 4f 40          	mov    %rcx,0x40(%rdi)
    33d7:	e9 57 f8 ff ff       	jmp    2c33 <f_8001161d0+0x2c33>
    33dc:	31 c9                	xor    %ecx,%ecx
    33de:	e9 50 f8 ff ff       	jmp    2c33 <f_8001161d0+0x2c33>
    33e3:	48 8b 87 b0 00 00 00 	mov    0xb0(%rdi),%rax
    33ea:	8b 08                	mov    (%rax),%ecx
    33ec:	45 8b 90 90 3b 00 00 	mov    0x3b90(%r8),%r10d
    33f3:	45 8b 88 94 3b 00 00 	mov    0x3b94(%r8),%r9d
    33fa:	41 83 fa 01          	cmp    $0x1,%r10d
    33fe:	44 89 d6             	mov    %r10d,%esi
    3401:	83 d6 00             	adc    $0x0,%esi
    3404:	89 c8                	mov    %ecx,%eax
    3406:	31 d2                	xor    %edx,%edx
    3408:	f7 f6                	div    %esi
    340a:	89 c6                	mov    %eax,%esi
    340c:	45 85 d2             	test   %r10d,%r10d
    340f:	41 0f 44 f2          	cmove  %r10d,%esi
    3413:	4c 89 4f 48          	mov    %r9,0x48(%rdi)
    3417:	31 d2                	xor    %edx,%edx
    3419:	41 89 f2             	mov    %esi,%r10d
    341c:	45 31 ca             	xor    %r9d,%r10d
    341f:	0f 94 c2             	sete   %dl
    3422:	45 31 db             	xor    %r11d,%r11d
    3425:	89 f0                	mov    %esi,%eax
    3427:	44 29 c8             	sub    %r9d,%eax
    342a:	41 0f 93 c3          	setae  %r11b
    342e:	89 f3                	mov    %esi,%ebx
    3430:	31 c3                	xor    %eax,%ebx
    3432:	44 21 d3             	and    %r10d,%ebx
    3435:	41 89 c2             	mov    %eax,%r10d
    3438:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    343f:	c1 e2 1e             	shl    $0x1e,%edx
    3442:	41 c1 e3 1d          	shl    $0x1d,%r11d
    3446:	41 09 d3             	or     %edx,%r11d
    3449:	45 09 d3             	or     %r10d,%r11d
    344c:	31 d8                	xor    %ebx,%eax
    344e:	c1 eb 03             	shr    $0x3,%ebx
    3451:	81 e3 00 00 00 10    	and    $0x10000000,%ebx
    3457:	44 09 db             	or     %r11d,%ebx
    345a:	48 89 9f 10 01 00 00 	mov    %rbx,0x110(%rdi)
    3461:	a9 00 00 00 80       	test   $0x80000000,%eax
    3466:	49 0f 44 f1          	cmove  %r9,%rsi
    346a:	48 89 77 40          	mov    %rsi,0x40(%rdi)
    346e:	48 85 f6             	test   %rsi,%rsi
    3471:	0f 84 c2 f9 ff ff    	je     2e39 <f_8001161d0+0x2e39>
    3477:	48 89 8f 88 00 00 00 	mov    %rcx,0x88(%rdi)
    347e:	31 d2                	xor    %edx,%edx
    3480:	89 f0                	mov    %esi,%eax
    3482:	ff c8                	dec    %eax
    3484:	0f 94 c2             	sete   %dl
    3487:	41 ba ff ff ff ff    	mov    $0xffffffff,%r10d
    348d:	49 81 c2 01 00 00 80 	add    $0xffffffff80000001,%r10
    3494:	45 31 c9             	xor    %r9d,%r9d
    3497:	4c 89 d3             	mov    %r10,%rbx
    349a:	4c 39 d6             	cmp    %r10,%rsi
    349d:	41 0f 94 c1          	sete   %r9b
    34a1:	41 89 c2             	mov    %eax,%r10d
    34a4:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    34ab:	c1 e2 1e             	shl    $0x1e,%edx
    34ae:	44 09 d2             	or     %r10d,%edx
    34b1:	45 89 ca             	mov    %r9d,%r10d
    34b4:	41 c1 e2 1c          	shl    $0x1c,%r10d
    34b8:	41 09 d2             	or     %edx,%r10d
    34bb:	49 81 ca 00 00 00 20 	or     $0x20000000,%r10
    34c2:	4c 89 97 10 01 00 00 	mov    %r10,0x110(%rdi)
    34c9:	48 89 47 48          	mov    %rax,0x48(%rdi)
    34cd:	48 89 4f 60          	mov    %rcx,0x60(%rdi)
    34d1:	c1 e8 1f             	shr    $0x1f,%eax
    34d4:	41 30 c1             	xor    %al,%r9b
    34d7:	0f 85 5c f9 ff ff    	jne    2e39 <f_8001161d0+0x2e39>
    34dd:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    34e3:	49 31 f1             	xor    %rsi,%r9
    34e6:	41 ba 00 00 00 80    	mov    $0x80000000,%r10d
    34ec:	49 31 ca             	xor    %rcx,%r10
    34ef:	4c 89 d0             	mov    %r10,%rax
    34f2:	4c 09 c8             	or     %r9,%rax
    34f5:	b8 01 00 00 00       	mov    $0x1,%eax
    34fa:	41 89 f3             	mov    %esi,%r11d
    34fd:	44 0f 44 d8          	cmove  %eax,%r11d
    3501:	89 c8                	mov    %ecx,%eax
    3503:	99                   	cltd
    3504:	41 f7 fb             	idiv   %r11d
    3507:	4d 09 ca             	or     %r9,%r10
    350a:	89 c2                	mov    %eax,%edx
    350c:	0f 44 d1             	cmove  %ecx,%edx
    350f:	48 0f 44 c3          	cmove  %rbx,%rax
    3513:	4c 8d 4f 50          	lea    0x50(%rdi),%r9
    3517:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    351b:	c4 c1 78 29 01       	vmovaps %xmm0,(%r9)
    3520:	4d 8d 88 80 3b 00 00 	lea    0x3b80(%r8),%r9
    3527:	4c 89 4f 70          	mov    %r9,0x70(%rdi)
    352b:	48 c7 47 78 28 00 00 	movq   $0x28,0x78(%rdi)
    3532:	00 
    3533:	48 c7 87 80 00 00 00 	movq   $0x3dcccccd,0x80(%rdi)
    353a:	cd cc cc 3d 
    353e:	0f af f2             	imul   %edx,%esi
    3541:	29 f1                	sub    %esi,%ecx
    3543:	48 89 4f 60          	mov    %rcx,0x60(%rdi)
    3547:	49 81 c0 78 3b 00 00 	add    $0x3b78,%r8
    354e:	4c 89 47 68          	mov    %r8,0x68(%rdi)
    3552:	48 89 87 88 00 00 00 	mov    %rax,0x88(%rdi)
    3559:	31 c9                	xor    %ecx,%ecx
    355b:	c5 f0 57 c9          	vxorps %xmm1,%xmm1,%xmm1
    355f:	c5 fa 10 15 00 00 00 	vmovss 0x0(%rip),%xmm2        # 3567 <f_8001161d0+0x3567>
    3566:	00 
    3567:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    356c:	c4 e2 79 59 1d 00 00 	vpbroadcastq 0x0(%rip),%xmm3        # 3575 <f_8001161d0+0x3575>
    3573:	00 00 
    3575:	48 be 00 00 00 00 f8 	movabs $0xfffffff800000000,%rsi
    357c:	ff ff ff 
    357f:	eb 7a                	jmp    35fb <f_8001161d0+0x35fb>
    3581:	c4 e3 e1 22 a7 88 00 	vpinsrq $0x1,0x88(%rdi),%xmm3,%xmm4
    3588:	00 00 01 
    358b:	c5 d9 d4 67 50       	vpaddq 0x50(%rdi),%xmm4,%xmm4
    3590:	c5 f9 7e e0          	vmovd  %xmm4,%eax
    3594:	44 8b 47 40          	mov    0x40(%rdi),%r8d
    3598:	45 31 c9             	xor    %r9d,%r9d
    359b:	41 89 c2             	mov    %eax,%r10d
    359e:	45 31 c2             	xor    %r8d,%r10d
    35a1:	41 0f 94 c1          	sete   %r9b
    35a5:	45 31 db             	xor    %r11d,%r11d
    35a8:	89 c3                	mov    %eax,%ebx
    35aa:	44 29 c3             	sub    %r8d,%ebx
    35ad:	41 0f 93 c3          	setae  %r11b
    35b1:	41 89 de             	mov    %ebx,%r14d
    35b4:	41 31 c6             	xor    %eax,%r14d
    35b7:	45 21 d6             	and    %r10d,%r14d
    35ba:	81 e3 00 00 00 80    	and    $0x80000000,%ebx
    35c0:	41 c1 e1 1e          	shl    $0x1e,%r9d
    35c4:	41 c1 e3 1d          	shl    $0x1d,%r11d
    35c8:	45 09 cb             	or     %r9d,%r11d
    35cb:	41 09 db             	or     %ebx,%r11d
    35ce:	41 c1 ee 03          	shr    $0x3,%r14d
    35d2:	41 81 e6 00 00 00 10 	and    $0x10000000,%r14d
    35d9:	45 09 de             	or     %r11d,%r14d
    35dc:	44 31 c0             	xor    %r8d,%eax
    35df:	c4 e3 59 02 e0 0a    	vpblendd $0xa,%xmm0,%xmm4,%xmm4
    35e5:	c5 f9 7f 67 50       	vmovdqa %xmm4,0x50(%rdi)
    35ea:	4c 89 b7 10 01 00 00 	mov    %r14,0x110(%rdi)
    35f1:	0f 84 42 f8 ff ff    	je     2e39 <f_8001161d0+0x2e39>
    35f7:	4c 8b 47 68          	mov    0x68(%rdi),%r8
    35fb:	41 8b 00             	mov    (%r8),%eax
    35fe:	48 89 87 90 00 00 00 	mov    %rax,0x90(%rdi)
    3605:	44 8d 40 01          	lea    0x1(%rax),%r8d
    3609:	4c 89 07             	mov    %r8,(%rdi)
    360c:	4c 8b 4f 68          	mov    0x68(%rdi),%r9
    3610:	45 31 d2             	xor    %r10d,%r10d
    3613:	f0 45 0f b1 01       	lock cmpxchg %r8d,(%r9)
    3618:	41 0f 95 c2          	setne  %r10b
    361c:	4c 89 57 08          	mov    %r10,0x8(%rdi)
    3620:	75 d5                	jne    35f7 <f_8001161d0+0x35f7>
    3622:	4c 8b 9f a0 00 00 00 	mov    0xa0(%rdi),%r11
    3629:	8b 47 50             	mov    0x50(%rdi),%eax
    362c:	3b 47 48             	cmp    0x48(%rdi),%eax
    362f:	44 8b 47 60          	mov    0x60(%rdi),%r8d
    3633:	4c 0f 45 c1          	cmovne %rcx,%r8
    3637:	4d 8b 93 70 3b 00 00 	mov    0x3b70(%r11),%r10
    363e:	4c 8b 8f 90 00 00 00 	mov    0x90(%rdi),%r9
    3645:	b8 00 00 00 00       	mov    $0x0,%eax
    364a:	45 39 8b 68 3b 00 00 	cmp    %r9d,0x3b68(%r11)
    3651:	76 1a                	jbe    366d <f_8001161d0+0x366d>
    3653:	45 89 c9             	mov    %r9d,%r9d
    3656:	49 63 c1             	movslq %r9d,%rax
    3659:	48 c1 f8 1f          	sar    $0x1f,%rax
    365d:	49 bb 00 00 00 00 ff 	movabs $0xffffffff00000000,%r11
    3664:	ff ff ff 
    3667:	4c 21 d8             	and    %r11,%rax
    366a:	4c 09 c8             	or     %r9,%rax
    366d:	48 89 47 08          	mov    %rax,0x8(%rdi)
    3671:	4c 03 87 88 00 00 00 	add    0x88(%rdi),%r8
    3678:	45 89 c1             	mov    %r8d,%r9d
    367b:	4c 89 8f 88 00 00 00 	mov    %r9,0x88(%rdi)
    3682:	48 98                	cltq
    3684:	4c 63 5f 78          	movslq 0x78(%rdi),%r11
    3688:	4c 0f af d8          	imul   %rax,%r11
    368c:	4b 8d 04 13          	lea    (%r11,%r10,1),%rax
    3690:	48 89 87 90 00 00 00 	mov    %rax,0x90(%rdi)
    3697:	8b 5f 58             	mov    0x58(%rdi),%ebx
    369a:	4d 89 c6             	mov    %r8,%r14
    369d:	49 c1 e6 20          	shl    $0x20,%r14
    36a1:	49 09 de             	or     %rbx,%r14
    36a4:	48 8b 9f 98 00 00 00 	mov    0x98(%rdi),%rbx
    36ab:	4b 89 1c 13          	mov    %rbx,(%r11,%r10,1)
    36af:	48 8b 9f b8 00 00 00 	mov    0xb8(%rdi),%rbx
    36b6:	4b 89 5c 13 08       	mov    %rbx,0x8(%r11,%r10,1)
    36bb:	48 8b 9f a8 00 00 00 	mov    0xa8(%rdi),%rbx
    36c2:	4b 89 5c 13 10       	mov    %rbx,0x10(%r11,%r10,1)
    36c7:	4f 89 74 13 18       	mov    %r14,0x18(%r11,%r10,1)
    36cc:	44 8b 93 bc 00 00 00 	mov    0xbc(%rbx),%r10d
    36d3:	31 db                	xor    %ebx,%ebx
    36d5:	45 89 d3             	mov    %r10d,%r11d
    36d8:	41 83 c3 fe          	add    $0xfffffffe,%r11d
    36dc:	0f 94 c3             	sete   %bl
    36df:	31 ed                	xor    %ebp,%ebp
    36e1:	41 be 01 00 00 00    	mov    $0x1,%r14d
    36e7:	45 29 d6             	sub    %r10d,%r14d
    36ea:	40 0f 92 c5          	setb   %bpl
    36ee:	45 21 d6             	and    %r10d,%r14d
    36f1:	45 89 df             	mov    %r11d,%r15d
    36f4:	41 81 e7 00 00 00 80 	and    $0x80000000,%r15d
    36fb:	c1 e3 1e             	shl    $0x1e,%ebx
    36fe:	c1 e5 1d             	shl    $0x1d,%ebp
    3701:	44 09 fd             	or     %r15d,%ebp
    3704:	09 dd                	or     %ebx,%ebp
    3706:	41 c1 ee 03          	shr    $0x3,%r14d
    370a:	41 81 e6 00 00 00 10 	and    $0x10000000,%r14d
    3711:	41 09 ee             	or     %ebp,%r14d
    3714:	4c 89 b7 10 01 00 00 	mov    %r14,0x110(%rdi)
    371b:	45 85 db             	test   %r11d,%r11d
    371e:	0f 84 aa 00 00 00    	je     37ce <f_8001161d0+0x37ce>
    3724:	45 31 db             	xor    %r11d,%r11d
    3727:	44 89 d3             	mov    %r10d,%ebx
    372a:	f7 db                	neg    %ebx
    372c:	41 0f 90 c3          	seto   %r11b
    3730:	31 db                	xor    %ebx,%ebx
    3732:	31 ed                	xor    %ebp,%ebp
    3734:	45 89 d6             	mov    %r10d,%r14d
    3737:	41 83 ee 01          	sub    $0x1,%r14d
    373b:	0f 94 c3             	sete   %bl
    373e:	40 0f 93 c5          	setae  %bpl
    3742:	41 81 e6 00 00 00 80 	and    $0x80000000,%r14d
    3749:	c1 e3 1e             	shl    $0x1e,%ebx
    374c:	c1 e5 1d             	shl    $0x1d,%ebp
    374f:	41 c1 e3 1c          	shl    $0x1c,%r11d
    3753:	41 09 eb             	or     %ebp,%r11d
    3756:	45 09 f3             	or     %r14d,%r11d
    3759:	41 09 db             	or     %ebx,%r11d
    375c:	4c 89 9f 10 01 00 00 	mov    %r11,0x110(%rdi)
    3763:	41 83 fa 01          	cmp    $0x1,%r10d
    3767:	0f 84 b9 00 00 00    	je     3826 <f_8001161d0+0x3826>
    376d:	31 db                	xor    %ebx,%ebx
    376f:	45 89 d3             	mov    %r10d,%r11d
    3772:	41 83 c3 fd          	add    $0xfffffffd,%r11d
    3776:	0f 94 c3             	sete   %bl
    3779:	31 ed                	xor    %ebp,%ebp
    377b:	41 be 02 00 00 00    	mov    $0x2,%r14d
    3781:	45 29 d6             	sub    %r10d,%r14d
    3784:	40 0f 92 c5          	setb   %bpl
    3788:	45 21 d6             	and    %r10d,%r14d
    378b:	45 89 da             	mov    %r11d,%r10d
    378e:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    3795:	c1 e3 1e             	shl    $0x1e,%ebx
    3798:	c1 e5 1d             	shl    $0x1d,%ebp
    379b:	44 09 d5             	or     %r10d,%ebp
    379e:	09 dd                	or     %ebx,%ebp
    37a0:	41 c1 ee 03          	shr    $0x3,%r14d
    37a4:	41 81 e6 00 00 00 10 	and    $0x10000000,%r14d
    37ab:	41 09 ee             	or     %ebp,%r14d
    37ae:	4c 89 b7 10 01 00 00 	mov    %r14,0x110(%rdi)
    37b5:	4c 89 4f 10          	mov    %r9,0x10(%rdi)
    37b9:	45 85 db             	test   %r11d,%r11d
    37bc:	0f 85 ab 00 00 00    	jne    386d <f_8001161d0+0x386d>
    37c2:	45 01 c0             	add    %r8d,%r8d
    37c5:	47 8d 0c 80          	lea    (%r8,%r8,4),%r9d
    37c9:	e9 9b 00 00 00       	jmp    3869 <f_8001161d0+0x3869>
    37ce:	c4 c1 02 2a e0       	vcvtsi2ss %r8d,%xmm15,%xmm4
    37d3:	4c 8b 87 80 00 00 00 	mov    0x80(%rdi),%r8
    37da:	45 89 c1             	mov    %r8d,%r9d
    37dd:	4c 89 8f 10 02 00 00 	mov    %r9,0x210(%rdi)
    37e4:	48 c7 87 18 02 00 00 	movq   $0x0,0x218(%rdi)
    37eb:	00 00 00 00 
    37ef:	c4 c1 79 6e e8       	vmovd  %r8d,%xmm5
    37f4:	c5 da 59 e5          	vmulss %xmm5,%xmm4,%xmm4
    37f8:	c4 c1 79 7e e0       	vmovd  %xmm4,%r8d
    37fd:	4c 89 87 00 02 00 00 	mov    %r8,0x200(%rdi)
    3804:	c4 61 fa 2c cc       	vcvttss2si %xmm4,%r9
    3809:	48 c7 87 08 02 00 00 	movq   $0x0,0x208(%rdi)
    3810:	00 00 00 00 
    3814:	c5 f8 2e e1          	vucomiss %xmm1,%xmm4
    3818:	44 0f 42 c9          	cmovb  %ecx,%r9d
    381c:	c5 f8 2e e2          	vucomiss %xmm2,%xmm4
    3820:	44 0f 47 ca          	cmova  %edx,%r9d
    3824:	eb 43                	jmp    3869 <f_8001161d0+0x3869>
    3826:	45 31 d2             	xor    %r10d,%r10d
    3829:	4d 85 c9             	test   %r9,%r9
    382c:	41 0f 94 c2          	sete   %r10b
    3830:	45 89 c1             	mov    %r8d,%r9d
    3833:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    383a:	41 c1 e2 1e          	shl    $0x1e,%r10d
    383e:	4d 01 d1             	add    %r10,%r9
    3841:	49 81 c1 00 00 00 20 	add    $0x20000000,%r9
    3848:	4c 89 8f 10 01 00 00 	mov    %r9,0x110(%rdi)
    384f:	45 89 c1             	mov    %r8d,%r9d
    3852:	41 c1 e9 1f          	shr    $0x1f,%r9d
    3856:	45 01 c1             	add    %r8d,%r9d
    3859:	45 89 c8             	mov    %r9d,%r8d
    385c:	41 d1 e8             	shr    $1,%r8d
    385f:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    3866:	45 09 c1             	or     %r8d,%r9d
    3869:	4c 89 4f 10          	mov    %r9,0x10(%rdi)
    386d:	48 89 07             	mov    %rax,(%rdi)
    3870:	44 89 48 20          	mov    %r9d,0x20(%rax)
    3874:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
    387b:	00 00 00 00 00 
    3880:	48 8b 47 70          	mov    0x70(%rdi),%rax
    3884:	8b 00                	mov    (%rax),%eax
    3886:	48 89 07             	mov    %rax,(%rdi)
    3889:	44 8d 40 01          	lea    0x1(%rax),%r8d
    388d:	4c 89 47 08          	mov    %r8,0x8(%rdi)
    3891:	4c 8b 4f 70          	mov    0x70(%rdi),%r9
    3895:	45 31 d2             	xor    %r10d,%r10d
    3898:	f0 45 0f b1 01       	lock cmpxchg %r8d,(%r9)
    389d:	41 0f 95 c2          	setne  %r10b
    38a1:	4c 89 57 10          	mov    %r10,0x10(%rdi)
    38a5:	75 d9                	jne    3880 <f_8001161d0+0x3880>
    38a7:	48 8b 07             	mov    (%rdi),%rax
    38aa:	4c 8b 87 a0 00 00 00 	mov    0xa0(%rdi),%r8
    38b1:	45 8b 88 84 3b 00 00 	mov    0x3b84(%r8),%r9d
    38b8:	45 89 ca             	mov    %r9d,%r10d
    38bb:	41 31 c2             	xor    %eax,%r10d
    38be:	45 89 cb             	mov    %r9d,%r11d
    38c1:	41 31 c3             	xor    %eax,%r11d
    38c4:	4c 89 4f 08          	mov    %r9,0x8(%rdi)
    38c8:	0f 84 b3 fc ff ff    	je     3581 <f_8001161d0+0x3581>
    38ce:	45 89 cb             	mov    %r9d,%r11d
    38d1:	41 29 c3             	sub    %eax,%r11d
    38d4:	c4 42 28 f2 db       	andn   %r11d,%r10d,%r11d
    38d9:	45 21 ca             	and    %r9d,%r10d
    38dc:	45 09 da             	or     %r11d,%r10d
    38df:	0f 88 9c fc ff ff    	js     3581 <f_8001161d0+0x3581>
    38e5:	4d 8b 80 88 3b 00 00 	mov    0x3b88(%r8),%r8
    38ec:	4c 89 47 08          	mov    %r8,0x8(%rdi)
    38f0:	4c 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%r9
    38f7:	00 
    38f8:	48 98                	cltq
    38fa:	48 21 f0             	and    %rsi,%rax
    38fd:	4d 8d 95 2e a2 3f fd 	lea    -0x2c05dd2(%r13),%r10
    3904:	4d 21 ca             	and    %r9,%r10
    3907:	49 09 c2             	or     %rax,%r10
    390a:	4c 89 17             	mov    %r10,(%rdi)
    390d:	48 8b 87 90 00 00 00 	mov    0x90(%rdi),%rax
    3914:	4b 89 04 10          	mov    %rax,(%r8,%r10,1)
    3918:	e9 64 fc ff ff       	jmp    3581 <f_8001161d0+0x3581>
