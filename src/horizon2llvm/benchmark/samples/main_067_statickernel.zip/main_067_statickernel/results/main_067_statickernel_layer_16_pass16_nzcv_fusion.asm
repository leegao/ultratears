
/home/leegao/meh/ultratears-main/src/horizon2llvm/benchmark/samples/main_067_statickernel/results/main_067_statickernel_layer_16_pass16_nzcv_fusion.o:     file format elf64-x86-64


Disassembly of section .text:

0000000000000000 <f_8001161d0>:
       0:	55                   	push   %rbp
       1:	41 57                	push   %r15
       3:	41 56                	push   %r14
       5:	41 55                	push   %r13
       7:	41 54                	push   %r12
       9:	53                   	push   %rbx
       a:	48 83 ec 18          	sub    $0x18,%rsp
       e:	48 89 fb             	mov    %rdi,%rbx
      11:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
      18:	00 00 00 
      1b:	48 8b 8f e8 00 00 00 	mov    0xe8(%rdi),%rcx
      22:	48 8b 87 00 01 00 00 	mov    0x100(%rdi),%rax
      29:	48 8d b0 d0 fe ff ff 	lea    -0x130(%rax),%rsi
      30:	48 89 b7 00 01 00 00 	mov    %rsi,0x100(%rdi)
      37:	48 8d 50 a0          	lea    -0x60(%rax),%rdx
      3b:	48 89 48 a0          	mov    %rcx,-0x60(%rax)
      3f:	48 8b 8f f0 00 00 00 	mov    0xf0(%rdi),%rcx
      46:	48 89 48 a8          	mov    %rcx,-0x58(%rax)
      4a:	48 8b 8f e0 00 00 00 	mov    0xe0(%rdi),%rcx
      51:	48 89 48 b0          	mov    %rcx,-0x50(%rax)
      55:	48 8b 8f d8 00 00 00 	mov    0xd8(%rdi),%rcx
      5c:	48 89 48 b8          	mov    %rcx,-0x48(%rax)
      60:	48 8b 8f d0 00 00 00 	mov    0xd0(%rdi),%rcx
      67:	48 89 48 c0          	mov    %rcx,-0x40(%rax)
      6b:	48 8b 8f c8 00 00 00 	mov    0xc8(%rdi),%rcx
      72:	48 89 48 c8          	mov    %rcx,-0x38(%rax)
      76:	48 8b 8f c0 00 00 00 	mov    0xc0(%rdi),%rcx
      7d:	48 89 48 d0          	mov    %rcx,-0x30(%rax)
      81:	48 8b 8f b8 00 00 00 	mov    0xb8(%rdi),%rcx
      88:	48 89 48 d8          	mov    %rcx,-0x28(%rax)
      8c:	48 8b 8f b0 00 00 00 	mov    0xb0(%rdi),%rcx
      93:	48 89 48 e0          	mov    %rcx,-0x20(%rax)
      97:	48 8b 8f a8 00 00 00 	mov    0xa8(%rdi),%rcx
      9e:	48 89 48 e8          	mov    %rcx,-0x18(%rax)
      a2:	48 8b 8f a0 00 00 00 	mov    0xa0(%rdi),%rcx
      a9:	48 89 48 f0          	mov    %rcx,-0x10(%rax)
      ad:	48 8b 8f 98 00 00 00 	mov    0x98(%rdi),%rcx
      b4:	48 89 48 f8          	mov    %rcx,-0x8(%rax)
      b8:	48 89 97 e8 00 00 00 	mov    %rdx,0xe8(%rdi)
      bf:	4c 8b 7f 10          	mov    0x10(%rdi),%r15
      c3:	4c 89 bf a8 00 00 00 	mov    %r15,0xa8(%rdi)
      ca:	4c 8b 37             	mov    (%rdi),%r14
      cd:	4c 8b 5f 08          	mov    0x8(%rdi),%r11
      d1:	4c 89 9f 98 00 00 00 	mov    %r11,0x98(%rdi)
      d8:	4c 89 b7 a0 00 00 00 	mov    %r14,0xa0(%rdi)
      df:	49 8d 8b 14 29 00 00 	lea    0x2914(%r11),%rcx
      e6:	48 89 4f 68          	mov    %rcx,0x68(%rdi)
      ea:	41 83 ff 20          	cmp    $0x20,%r15d
      ee:	73 1f                	jae    10f <f_8001161d0+0x10f>
      f0:	b9 1f 7d c3 f6       	mov    $0xf6c37d1f,%ecx
      f5:	44 0f a3 f9          	bt     %r15d,%ecx
      f9:	73 14                	jae    10f <f_8001161d0+0x10f>
      fb:	44 89 f9             	mov    %r15d,%ecx
      fe:	83 e1 1f             	and    $0x1f,%ecx
     101:	49 8b 8c cd be 6b 16 	mov    0x166bbe(%r13,%rcx,8),%rcx
     108:	00 
     109:	48 c1 e1 08          	shl    $0x8,%rcx
     10d:	eb 0f                	jmp    11e <f_8001161d0+0x11e>
     10f:	31 d2                	xor    %edx,%edx
     111:	41 83 ff 12          	cmp    $0x12,%r15d
     115:	b9 00 03 00 00       	mov    $0x300,%ecx
     11a:	48 0f 45 ca          	cmovne %rdx,%rcx
     11e:	41 0f be 93 17 29 00 	movsbl 0x2917(%r11),%edx
     125:	00 
     126:	48 63 d2             	movslq %edx,%rdx
     129:	48 89 b3 c0 00 00 00 	mov    %rsi,0xc0(%rbx)
     130:	48 69 fa 48 07 00 00 	imul   $0x748,%rdx,%rdi
     137:	45 31 c0             	xor    %r8d,%r8d
     13a:	41 39 96 90 33 00 00 	cmp    %edx,0x3390(%r14)
     141:	4c 0f 47 c7          	cmova  %rdi,%r8
     145:	4d 03 86 98 33 00 00 	add    0x3398(%r14),%r8
     14c:	48 c7 43 70 ff ff ff 	movq   $0xffffffffffffffff,0x70(%rbx)
     153:	ff 
     154:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 15c <f_8001161d0+0x15c>
     15b:	00 
     15c:	c5 fc 11 80 d0 fe ff 	vmovups %ymm0,-0x130(%rax)
     163:	ff 
     164:	bf ff ff ff ff       	mov    $0xffffffff,%edi
     169:	48 89 7b 78          	mov    %rdi,0x78(%rbx)
     16d:	48 ba 00 00 00 00 01 	movabs $0x100000000,%rdx
     174:	00 00 00 
     177:	48 89 90 f0 fe ff ff 	mov    %rdx,-0x110(%rax)
     17e:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     185:	ff ff ff 
     188:	48 89 90 f8 fe ff ff 	mov    %rdx,-0x108(%rax)
     18f:	4a 8d 8c 01 e8 01 00 	lea    0x1e8(%rcx,%r8,1),%rcx
     196:	00 
     197:	48 89 8b b8 00 00 00 	mov    %rcx,0xb8(%rbx)
     19e:	48 89 b8 00 ff ff ff 	mov    %rdi,-0x100(%rax)
     1a5:	49 ba 00 00 80 3f 00 	movabs $0x3f8000003f800000,%r10
     1ac:	00 80 3f 
     1af:	4c 89 90 08 ff ff ff 	mov    %r10,-0xf8(%rax)
     1b6:	48 bd ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rbp
     1bd:	ff 7f 7f 
     1c0:	48 89 6b 58          	mov    %rbp,0x58(%rbx)
     1c4:	31 c9                	xor    %ecx,%ecx
     1c6:	44 89 fa             	mov    %r15d,%edx
     1c9:	83 c2 df             	add    $0xffffffdf,%edx
     1cc:	0f 94 c1             	sete   %cl
     1cf:	31 ff                	xor    %edi,%edi
     1d1:	41 83 ff 21          	cmp    $0x21,%r15d
     1d5:	40 0f 93 c7          	setae  %dil
     1d9:	41 b8 20 00 00 00    	mov    $0x20,%r8d
     1df:	45 29 f8             	sub    %r15d,%r8d
     1e2:	45 21 f8             	and    %r15d,%r8d
     1e5:	81 e2 00 00 00 80    	and    $0x80000000,%edx
     1eb:	c1 e1 1e             	shl    $0x1e,%ecx
     1ee:	c1 e7 1d             	shl    $0x1d,%edi
     1f1:	09 d7                	or     %edx,%edi
     1f3:	09 cf                	or     %ecx,%edi
     1f5:	41 c1 e8 03          	shr    $0x3,%r8d
     1f9:	41 81 e0 00 00 00 10 	and    $0x10000000,%r8d
     200:	41 09 f8             	or     %edi,%r8d
     203:	4c 89 83 10 01 00 00 	mov    %r8,0x110(%rbx)
     20a:	4c 89 90 10 ff ff ff 	mov    %r10,-0xf0(%rax)
     211:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     218:	00 00 00 00 
     21c:	4d 8b 85 7e 86 d5 00 	mov    0xd5867e(%r13),%r8
     223:	4c 89 43 50          	mov    %r8,0x50(%rbx)
     227:	49 8b 8d ae 5d d4 00 	mov    0xd45dae(%r13),%rcx
     22e:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
     232:	49 8d 50 10          	lea    0x10(%r8),%rdx
     236:	48 89 14 24          	mov    %rdx,(%rsp)
     23a:	48 89 90 20 ff ff ff 	mov    %rdx,-0xe0(%rax)
     241:	48 89 88 40 ff ff ff 	mov    %rcx,-0xc0(%rax)
     248:	49 8b 95 b6 7e d5 00 	mov    0xd57eb6(%r13),%rdx
     24f:	4c 8d 62 10          	lea    0x10(%rdx),%r12
     253:	49 8d 8a 00 00 80 c0 	lea    -0x3f800000(%r10),%rcx
     25a:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
     261:	ff 7f ff 
     264:	48 89 53 60          	mov    %rdx,0x60(%rbx)
     268:	4c 89 a3 80 00 00 00 	mov    %r12,0x80(%rbx)
     26f:	48 89 a8 48 ff ff ff 	mov    %rbp,-0xb8(%rax)
     276:	48 89 b8 50 ff ff ff 	mov    %rdi,-0xb0(%rax)
     27d:	48 89 88 74 ff ff ff 	mov    %rcx,-0x8c(%rax)
     284:	49 8b 95 c6 7d d5 00 	mov    0xd57dc6(%r13),%rdx
     28b:	48 89 b8 68 ff ff ff 	mov    %rdi,-0x98(%rax)
     292:	44 8b 0a             	mov    (%rdx),%r9d
     295:	4c 89 4b 40          	mov    %r9,0x40(%rbx)
     299:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
     29e:	4c 89 a0 58 ff ff ff 	mov    %r12,-0xa8(%rax)
     2a5:	48 89 a8 60 ff ff ff 	mov    %rbp,-0xa0(%rax)
     2ac:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     2b3:	00 
     2b4:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     2b8:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     2bf:	44 89 88 70 ff ff ff 	mov    %r9d,-0x90(%rax)
     2c6:	41 83 ff 21          	cmp    $0x21,%r15d
     2ca:	0f 87 08 29 00 00    	ja     2bd8 <f_8001161d0+0x2bd8>
     2d0:	41 bc ff ff ff ff    	mov    $0xffffffff,%r12d
     2d6:	48 89 4c 24 08       	mov    %rcx,0x8(%rsp)
     2db:	4c 8d 90 48 ff ff ff 	lea    -0xb8(%rax),%r10
     2e2:	48 8d a8 60 ff ff ff 	lea    -0xa0(%rax),%rbp
     2e9:	48 8d 48 80          	lea    -0x80(%rax),%rcx
     2ed:	48 8d b8 70 ff ff ff 	lea    -0x90(%rax),%rdi
     2f4:	49 8d 95 76 6b 16 00 	lea    0x166b76(%r13),%rdx
     2fb:	48 89 93 88 00 00 00 	mov    %rdx,0x88(%rbx)
     302:	41 83 e7 3f          	and    $0x3f,%r15d
     306:	4c 89 bb 90 00 00 00 	mov    %r15,0x90(%rbx)
     30d:	48 89 b3 80 00 00 00 	mov    %rsi,0x80(%rbx)
     314:	44 89 fa             	mov    %r15d,%edx
     317:	41 0f b7 94 55 76 6b 	movzwl 0x166b76(%r13,%rdx,2),%edx
     31e:	16 00 
     320:	48 89 53 08          	mov    %rdx,0x8(%rbx)
     324:	49 8d b4 95 52 05 51 	lea    -0x2aefaae(%r13,%rdx,4),%rsi
     32b:	fd 
     32c:	49 89 ed             	mov    %rbp,%r13
     32f:	4c 89 d5             	mov    %r10,%rbp
     332:	48 89 33             	mov    %rsi,(%rbx)
     335:	4c 89 53 48          	mov    %r10,0x48(%rbx)
     339:	4c 89 ab d0 00 00 00 	mov    %r13,0xd0(%rbx)
     340:	48 89 bb c8 00 00 00 	mov    %rdi,0xc8(%rbx)
     347:	48 89 8b d8 00 00 00 	mov    %rcx,0xd8(%rbx)
     34e:	81 fa 86 02 00 00    	cmp    $0x286,%edx
     354:	7f 5e                	jg     3b4 <f_8001161d0+0x3b4>
     356:	81 fa 2d 01 00 00    	cmp    $0x12d,%edx
     35c:	0f 8f de 00 00 00    	jg     440 <f_8001161d0+0x440>
     362:	83 fa 6f             	cmp    $0x6f,%edx
     365:	4d 89 ca             	mov    %r9,%r10
     368:	0f 8f 52 04 00 00    	jg     7c0 <f_8001161d0+0x7c0>
     36e:	83 fa 04             	cmp    $0x4,%edx
     371:	0f 87 d7 10 00 00    	ja     144e <f_8001161d0+0x144e>
     377:	89 d1                	mov    %edx,%ecx
     379:	48 8d 15 00 00 00 00 	lea    0x0(%rip),%rdx        # 380 <f_8001161d0+0x380>
     380:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
     384:	48 01 d1             	add    %rdx,%rcx
     387:	ff e1                	jmp    *%rcx
     389:	45 0f b7 be e4 0c 00 	movzwl 0xce4(%r14),%r15d
     390:	00 
     391:	b9 ff ff ff ff       	mov    $0xffffffff,%ecx
     396:	03 8b a8 00 00 00    	add    0xa8(%rbx),%ecx
     39c:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
     3a0:	4c 8b 04 24          	mov    (%rsp),%r8
     3a4:	48 8b 93 98 00 00 00 	mov    0x98(%rbx),%rdx
     3ab:	0f b6 52 08          	movzbl 0x8(%rdx),%edx
     3af:	e9 a7 14 00 00       	jmp    185b <f_8001161d0+0x185b>
     3b4:	81 fa 6d 04 00 00    	cmp    $0x46d,%edx
     3ba:	0f 8e af 02 00 00    	jle    66f <f_8001161d0+0x66f>
     3c0:	44 8d 82 92 fb ff ff 	lea    -0x46e(%rdx),%r8d
     3c7:	41 83 f8 0c          	cmp    $0xc,%r8d
     3cb:	4d 89 ca             	mov    %r9,%r10
     3ce:	0f 86 14 08 00 00    	jbe    be8 <f_8001161d0+0xbe8>
     3d4:	44 8d 82 36 fb ff ff 	lea    -0x4ca(%rdx),%r8d
     3db:	41 83 f8 16          	cmp    $0x16,%r8d
     3df:	0f 87 10 10 00 00    	ja     13f5 <f_8001161d0+0x13f5>
     3e5:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # 3ec <f_8001161d0+0x3ec>
     3ec:	4a 63 14 81          	movslq (%rcx,%r8,4),%rdx
     3f0:	48 01 ca             	add    %rcx,%rdx
     3f3:	ff e2                	jmp    *%rdx
     3f5:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
     3fc:	00 
     3fd:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
     404:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     40b:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
     40f:	48 89 43 10          	mov    %rax,0x10(%rbx)
     413:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
     418:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
     41f:	48 89 03             	mov    %rax,(%rbx)
     422:	48 c7 43 18 01 00 00 	movq   $0x1,0x18(%rbx)
     429:	00 
     42a:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     431:	00 00 00 
     434:	49 8d 85 92 18 51 fd 	lea    -0x2aee76e(%r13),%rax
     43b:	e9 c0 17 00 00       	jmp    1c00 <f_8001161d0+0x1c00>
     440:	81 fa c7 01 00 00    	cmp    $0x1c7,%edx
     446:	4d 89 ca             	mov    %r9,%r10
     449:	0f 8f 4b 06 00 00    	jg     a9a <f_8001161d0+0xa9a>
     44f:	81 fa b1 01 00 00    	cmp    $0x1b1,%edx
     455:	0f 8f c9 0a 00 00    	jg     f24 <f_8001161d0+0xf24>
     45b:	81 fa 2e 01 00 00    	cmp    $0x12e,%edx
     461:	0f 84 5d 1d 00 00    	je     21c4 <f_8001161d0+0x21c4>
     467:	81 fa 66 01 00 00    	cmp    $0x166,%edx
     46d:	0f 85 27 17 00 00    	jne    1b9a <f_8001161d0+0x1b9a>
     473:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
     47a:	48 8b 93 a0 00 00 00 	mov    0xa0(%rbx),%rdx
     481:	48 8b 92 c8 1e 00 00 	mov    0x1ec8(%rdx),%rdx
     488:	48 89 53 08          	mov    %rdx,0x8(%rbx)
     48c:	48 c7 83 80 00 00 00 	movq   $0x3ce0,0x80(%rbx)
     493:	e0 3c 00 00 
     497:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
     49c:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
     4a0:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
     4a4:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
     4a8:	48 69 f1 e0 3c 00 00 	imul   $0x3ce0,%rcx,%rsi
     4af:	45 31 db             	xor    %r11d,%r11d
     4b2:	39 4a 08             	cmp    %ecx,0x8(%rdx)
     4b5:	49 0f 46 f3          	cmovbe %r11,%rsi
     4b9:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
     4bd:	48 8b 8c 0e 40 3c 00 	mov    0x3c40(%rsi,%rcx,1),%rcx
     4c4:	00 
     4c5:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
     4cc:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
     4d3:	44 89 92 a0 00 00 00 	mov    %r10d,0xa0(%rdx)
     4da:	48 89 ba 88 00 00 00 	mov    %rdi,0x88(%rdx)
     4e1:	48 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rcx
     4e8:	ff 7f 7f 
     4eb:	48 89 8a 90 00 00 00 	mov    %rcx,0x90(%rdx)
     4f2:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     4f9:	00 
     4fa:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     4fe:	c7 82 bc 00 00 00 00 	movl   $0x0,0xbc(%rdx)
     505:	00 00 00 
     508:	48 c7 42 48 00 00 00 	movq   $0x0,0x48(%rdx)
     50f:	00 
     510:	48 8b 04 24          	mov    (%rsp),%rax
     514:	48 89 42 50          	mov    %rax,0x50(%rdx)
     518:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     51c:	c5 f8 11 42 58       	vmovups %xmm0,0x58(%rdx)
     521:	48 c7 42 30 08 00 00 	movq   $0x8,0x30(%rdx)
     528:	00 
     529:	48 b8 10 00 00 00 03 	movabs $0x300000010,%rax
     530:	00 00 00 
     533:	48 89 02             	mov    %rax,(%rdx)
     536:	48 c7 42 08 00 00 00 	movq   $0x0,0x8(%rdx)
     53d:	00 
     53e:	48 c7 42 10 ff ff 00 	movq   $0xffff,0x10(%rdx)
     545:	00 
     546:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
     54d:	ff ff ff 
     550:	48 8d 41 0d          	lea    0xd(%rcx),%rax
     554:	48 89 42 18          	mov    %rax,0x18(%rdx)
     558:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     55f:	00 00 00 
     562:	48 89 42 20          	mov    %rax,0x20(%rdx)
     566:	48 89 4a 28          	mov    %rcx,0x28(%rdx)
     56a:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     571:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
     576:	48 89 88 a4 00 00 00 	mov    %rcx,0xa4(%rax)
     57d:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
     584:	00 80 3f 
     587:	48 89 42 38          	mov    %rax,0x38(%rdx)
     58b:	48 89 42 40          	mov    %rax,0x40(%rdx)
     58f:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     596:	00 00 00 
     599:	49 8d 85 8b 0d 02 00 	lea    0x20d8b(%r13),%rax
     5a0:	48 89 43 70          	mov    %rax,0x70(%rbx)
     5a4:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
     5ab:	ff 7f ff 
     5ae:	48 89 73 78          	mov    %rsi,0x78(%rbx)
     5b2:	48 89 b2 98 00 00 00 	mov    %rsi,0x98(%rdx)
     5b9:	48 8b 4b 58          	mov    0x58(%rbx),%rcx
     5bd:	48 89 4a 78          	mov    %rcx,0x78(%rdx)
     5c1:	48 89 b2 80 00 00 00 	mov    %rsi,0x80(%rdx)
     5c8:	48 c7 42 68 00 00 00 	movq   $0x0,0x68(%rdx)
     5cf:	00 
     5d0:	48 89 42 70          	mov    %rax,0x70(%rdx)
     5d4:	48 8b 43 08          	mov    0x8(%rbx),%rax
     5d8:	48 8b 4b 48          	mov    0x48(%rbx),%rcx
     5dc:	44 8b 40 08          	mov    0x8(%rax),%r8d
     5e0:	4c 89 43 40          	mov    %r8,0x40(%rbx)
     5e4:	48 8b 53 68          	mov    0x68(%rbx),%rdx
     5e8:	89 d6                	mov    %edx,%esi
     5ea:	45 31 c9             	xor    %r9d,%r9d
     5ed:	45 89 c2             	mov    %r8d,%r10d
     5f0:	41 31 d2             	xor    %edx,%r10d
     5f3:	41 0f 94 c1          	sete   %r9b
     5f7:	31 ed                	xor    %ebp,%ebp
     5f9:	45 89 c6             	mov    %r8d,%r14d
     5fc:	41 29 d6             	sub    %edx,%r14d
     5ff:	bf 00 00 00 00       	mov    $0x0,%edi
     604:	48 0f 47 fe          	cmova  %rsi,%rdi
     608:	40 0f 93 c5          	setae  %bpl
     60c:	45 89 f7             	mov    %r14d,%r15d
     60f:	45 31 c7             	xor    %r8d,%r15d
     612:	45 21 d7             	and    %r10d,%r15d
     615:	41 c1 e1 1e          	shl    $0x1e,%r9d
     619:	c1 e5 1d             	shl    $0x1d,%ebp
     61c:	44 09 cd             	or     %r9d,%ebp
     61f:	41 81 e6 00 00 00 80 	and    $0x80000000,%r14d
     626:	44 09 f5             	or     %r14d,%ebp
     629:	41 c1 ef 03          	shr    $0x3,%r15d
     62d:	41 81 e7 00 00 00 10 	and    $0x10000000,%r15d
     634:	41 09 ef             	or     %ebp,%r15d
     637:	4c 8b 40 10          	mov    0x10(%rax),%r8
     63b:	4c 89 bb 10 01 00 00 	mov    %r15,0x110(%rbx)
     642:	44 8b 8b 80 00 00 00 	mov    0x80(%rbx),%r9d
     649:	49 0f af f9          	imul   %r9,%rdi
     64d:	c4 a1 78 10 84 07 00 	vmovups 0x2e00(%rdi,%r8,1),%xmm0
     654:	2e 00 00 
     657:	c5 f8 11 01          	vmovups %xmm0,(%rcx)
     65b:	39 50 08             	cmp    %edx,0x8(%rax)
     65e:	4c 0f 47 de          	cmova  %rsi,%r11
     662:	4d 0f af d9          	imul   %r9,%r11
     666:	4c 03 58 10          	add    0x10(%rax),%r11
     66a:	e9 4f 1d 00 00       	jmp    23be <f_8001161d0+0x23be>
     66f:	81 fa d4 02 00 00    	cmp    $0x2d4,%edx
     675:	4d 89 ca             	mov    %r9,%r10
     678:	0f 8f ba 04 00 00    	jg     b38 <f_8001161d0+0xb38>
     67e:	81 fa b5 02 00 00    	cmp    $0x2b5,%edx
     684:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
     68a:	0f 8f 32 09 00 00    	jg     fc2 <f_8001161d0+0xfc2>
     690:	81 fa 87 02 00 00    	cmp    $0x287,%edx
     696:	0f 84 02 1e 00 00    	je     249e <f_8001161d0+0x249e>
     69c:	bf ff ff ff ff       	mov    $0xffffffff,%edi
     6a1:	81 fa 97 02 00 00    	cmp    $0x297,%edx
     6a7:	0f 85 ed 14 00 00    	jne    1b9a <f_8001161d0+0x1b9a>
     6ad:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
     6b4:	44 89 92 a0 00 00 00 	mov    %r10d,0xa0(%rdx)
     6bb:	48 c7 02 00 00 00 40 	movq   $0x40000000,(%rdx)
     6c2:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
     6c9:	00 40 00 
     6cc:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
     6d0:	48 c7 42 10 ff ff 00 	movq   $0xffff,0x10(%rdx)
     6d7:	00 
     6d8:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
     6df:	ff ff ff 
     6e2:	48 8d 4e 14          	lea    0x14(%rsi),%rcx
     6e6:	48 89 4a 18          	mov    %rcx,0x18(%rdx)
     6ea:	4c 8b 14 24          	mov    (%rsp),%r10
     6ee:	4c 89 53 40          	mov    %r10,0x40(%rbx)
     6f2:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     6f6:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     6fd:	00 
     6fe:	c7 82 bc 00 00 00 00 	movl   $0x0,0xbc(%rdx)
     705:	00 00 00 
     708:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
     70f:	00 00 00 
     712:	48 89 42 20          	mov    %rax,0x20(%rdx)
     716:	48 89 72 28          	mov    %rsi,0x28(%rdx)
     71a:	48 89 7a 30          	mov    %rdi,0x30(%rdx)
     71e:	48 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rsi
     725:	00 80 3f 
     728:	48 89 72 38          	mov    %rsi,0x38(%rdx)
     72c:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
     733:	00 00 00 
     736:	48 8d 80 80 0d 02 00 	lea    0x20d80(%rax),%rax
     73d:	48 89 42 70          	mov    %rax,0x70(%rdx)
     741:	49 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r8
     748:	ff 7f 7f 
     74b:	4c 89 42 78          	mov    %r8,0x78(%rdx)
     74f:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
     756:	ff 7f ff 
     759:	48 89 ba 80 00 00 00 	mov    %rdi,0x80(%rdx)
     760:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
     765:	48 89 82 88 00 00 00 	mov    %rax,0x88(%rdx)
     76c:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 774 <f_8001161d0+0x774>
     773:	00 
     774:	c5 fc 11 43 60       	vmovups %ymm0,0x60(%rbx)
     779:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     780:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
     785:	48 89 88 a4 00 00 00 	mov    %rcx,0xa4(%rax)
     78c:	48 89 72 40          	mov    %rsi,0x40(%rdx)
     790:	48 c7 42 48 00 00 00 	movq   $0x0,0x48(%rdx)
     797:	00 
     798:	4c 89 82 90 00 00 00 	mov    %r8,0x90(%rdx)
     79f:	48 89 ba 98 00 00 00 	mov    %rdi,0x98(%rdx)
     7a6:	48 c7 42 68 00 00 00 	movq   $0x0,0x68(%rdx)
     7ad:	00 
     7ae:	4c 89 52 50          	mov    %r10,0x50(%rdx)
     7b2:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     7b6:	c5 f8 11 42 58       	vmovups %xmm0,0x58(%rdx)
     7bb:	e9 f7 22 00 00       	jmp    2ab7 <f_8001161d0+0x2ab7>
     7c0:	81 fa c8 00 00 00    	cmp    $0xc8,%edx
     7c6:	0f 8f 3f 04 00 00    	jg     c0b <f_8001161d0+0xc0b>
     7cc:	83 fa 70             	cmp    $0x70,%edx
     7cf:	0f 84 e4 16 00 00    	je     1eb9 <f_8001161d0+0x1eb9>
     7d5:	81 fa 80 00 00 00    	cmp    $0x80,%edx
     7db:	0f 85 b9 13 00 00    	jne    1b9a <f_8001161d0+0x1b9a>
     7e1:	49 8b b6 c8 1e 00 00 	mov    0x1ec8(%r14),%rsi
     7e8:	48 89 73 08          	mov    %rsi,0x8(%rbx)
     7ec:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
     7f1:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
     7f5:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
     7fc:	00 
     7fd:	45 0f b6 5b 08       	movzbl 0x8(%r11),%r11d
     802:	4c 89 5b 68          	mov    %r11,0x68(%rbx)
     806:	8b 4e 08             	mov    0x8(%rsi),%ecx
     809:	4c 8b 76 10          	mov    0x10(%rsi),%r14
     80d:	4d 69 c3 e0 3c 00 00 	imul   $0x3ce0,%r11,%r8
     814:	31 d2                	xor    %edx,%edx
     816:	44 39 d9             	cmp    %r11d,%ecx
     819:	b9 00 00 00 00       	mov    $0x0,%ecx
     81e:	49 0f 47 c8          	cmova  %r8,%rcx
     822:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
     829:	00 
     82a:	4a 8b 8c 31 40 3c 00 	mov    0x3c40(%rcx,%r14,1),%rcx
     831:	00 
     832:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
     839:	44 89 90 70 ff ff ff 	mov    %r10d,-0x90(%rax)
     840:	48 89 b8 58 ff ff ff 	mov    %rdi,-0xa8(%rax)
     847:	49 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r9
     84e:	ff 7f 7f 
     851:	4c 89 88 60 ff ff ff 	mov    %r9,-0xa0(%rax)
     858:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     85f:	00 
     860:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     864:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     86b:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     872:	00 00 00 00 
     876:	48 8b 3c 24          	mov    (%rsp),%rdi
     87a:	48 89 b8 20 ff ff ff 	mov    %rdi,-0xe0(%rax)
     881:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     885:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
     88c:	ff 
     88d:	48 c7 80 00 ff ff ff 	movq   $0x5,-0x100(%rax)
     894:	05 00 00 00 
     898:	48 bf 10 00 00 00 03 	movabs $0x300000010,%rdi
     89f:	00 00 00 
     8a2:	48 81 c7 f0 00 00 00 	add    $0xf0,%rdi
     8a9:	48 89 b8 d0 fe ff ff 	mov    %rdi,-0x130(%rax)
     8b0:	48 bf 00 00 00 00 00 	movabs $0x60000000000000,%rdi
     8b7:	00 60 00 
     8ba:	48 89 b8 d8 fe ff ff 	mov    %rdi,-0x128(%rax)
     8c1:	48 89 0b             	mov    %rcx,(%rbx)
     8c4:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     8cb:	ff ff 00 00 
     8cf:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     8d6:	ff ff ff 
     8d9:	48 8d 4d 08          	lea    0x8(%rbp),%rcx
     8dd:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
     8e4:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     8eb:	00 00 00 
     8ee:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
     8f5:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
     8fc:	48 8b 8b c0 00 00 00 	mov    0xc0(%rbx),%rcx
     903:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
     908:	48 89 b9 a4 00 00 00 	mov    %rdi,0xa4(%rcx)
     90f:	48 b9 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rcx
     916:	00 80 3f 
     919:	48 89 88 08 ff ff ff 	mov    %rcx,-0xf8(%rax)
     920:	48 89 88 10 ff ff ff 	mov    %rcx,-0xf0(%rax)
     927:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     92e:	00 00 00 
     931:	49 8d 8d 1d 54 09 00 	lea    0x9541d(%r13),%rcx
     938:	48 89 4b 78          	mov    %rcx,0x78(%rbx)
     93c:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
     943:	ff 7f ff 
     946:	48 89 bb 80 00 00 00 	mov    %rdi,0x80(%rbx)
     94d:	48 89 b8 68 ff ff ff 	mov    %rdi,-0x98(%rax)
     954:	4c 89 88 48 ff ff ff 	mov    %r9,-0xb8(%rax)
     95b:	48 89 b8 50 ff ff ff 	mov    %rdi,-0xb0(%rax)
     962:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
     969:	00 00 00 00 
     96d:	48 89 88 40 ff ff ff 	mov    %rcx,-0xc0(%rax)
     974:	44 39 5e 08          	cmp    %r11d,0x8(%rsi)
     978:	b9 00 00 00 00       	mov    $0x0,%ecx
     97d:	49 0f 47 c8          	cmova  %r8,%rcx
     981:	48 8b 7e 10          	mov    0x10(%rsi),%rdi
     985:	c5 f8 10 84 0f 00 2e 	vmovups 0x2e00(%rdi,%rcx,1),%xmm0
     98c:	00 00 
     98e:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
     995:	ff 
     996:	8b 7e 08             	mov    0x8(%rsi),%edi
     999:	45 31 c9             	xor    %r9d,%r9d
     99c:	31 c9                	xor    %ecx,%ecx
     99e:	41 89 fa             	mov    %edi,%r10d
     9a1:	45 29 da             	sub    %r11d,%r10d
     9a4:	49 0f 47 d0          	cmova  %r8,%rdx
     9a8:	41 0f 94 c1          	sete   %r9b
     9ac:	0f 93 c1             	setae  %cl
     9af:	41 c1 e1 1e          	shl    $0x1e,%r9d
     9b3:	c1 e1 1d             	shl    $0x1d,%ecx
     9b6:	44 09 c9             	or     %r9d,%ecx
     9b9:	c4 e2 28 f2 ff       	andn   %edi,%r10d,%edi
     9be:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
     9c5:	44 09 d1             	or     %r10d,%ecx
     9c8:	48 8b 76 10          	mov    0x10(%rsi),%rsi
     9cc:	c1 ef 03             	shr    $0x3,%edi
     9cf:	81 e7 00 00 00 10    	and    $0x10000000,%edi
     9d5:	09 cf                	or     %ecx,%edi
     9d7:	48 89 bb 10 01 00 00 	mov    %rdi,0x110(%rbx)
     9de:	48 8b 8c 16 80 30 00 	mov    0x3080(%rsi,%rdx,1),%rcx
     9e5:	00 
     9e6:	48 8b bc 16 88 30 00 	mov    0x3088(%rsi,%rdx,1),%rdi
     9ed:	00 
     9ee:	48 89 7b 50          	mov    %rdi,0x50(%rbx)
     9f2:	48 89 88 60 ff ff ff 	mov    %rcx,-0xa0(%rax)
     9f9:	48 89 b8 68 ff ff ff 	mov    %rdi,-0x98(%rax)
     a00:	48 8b 8c 16 90 30 00 	mov    0x3090(%rsi,%rdx,1),%rcx
     a07:	00 
     a08:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
     a0c:	8b 94 16 98 30 00 00 	mov    0x3098(%rsi,%rdx,1),%edx
     a13:	89 90 78 ff ff ff    	mov    %edx,-0x88(%rax)
     a19:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     a20:	48 83 c2 f7          	add    $0xfffffffffffffff7,%rdx
     a24:	48 89 53 40          	mov    %rdx,0x40(%rbx)
     a28:	48 89 88 70 ff ff ff 	mov    %rcx,-0x90(%rax)
     a2f:	49 8d 85 56 08 51 fd 	lea    -0x2aef7aa(%r13),%rax
     a36:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
     a3d:	48 89 df             	mov    %rbx,%rdi
     a40:	c5 f8 77             	vzeroupper
     a43:	e8 00 00 00 00       	call   a48 <f_8001161d0+0xa48>
     a48:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     a4f:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
     a56:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     a5d:	48 89 01             	mov    %rax,(%rcx)
     a60:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     a67:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     a6e:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
     a72:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
     a79:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     a7d:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     a83:	48 89 43 40          	mov    %rax,0x40(%rbx)
     a87:	88 51 08             	mov    %dl,0x8(%rcx)
     a8a:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     a91:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
     a95:	e9 ea 19 00 00       	jmp    2484 <f_8001161d0+0x2484>
     a9a:	81 fa 51 02 00 00    	cmp    $0x251,%edx
     aa0:	0f 8f ba 05 00 00    	jg     1060 <f_8001161d0+0x1060>
     aa6:	81 fa c8 01 00 00    	cmp    $0x1c8,%edx
     aac:	0f 84 6c 1a 00 00    	je     251e <f_8001161d0+0x251e>
     ab2:	81 fa 0f 02 00 00    	cmp    $0x20f,%edx
     ab8:	0f 85 dc 10 00 00    	jne    1b9a <f_8001161d0+0x1b9a>
     abe:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     ac5:	00 
     ac6:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
     acd:	48 c7 02 00 08 00 00 	movq   $0x800,(%rdx)
     ad4:	48 c7 42 08 01 00 00 	movq   $0x1,0x8(%rdx)
     adb:	00 
     adc:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     ae3:	ff ff ff 
     ae6:	48 8d 4d 0b          	lea    0xb(%rbp),%rcx
     aea:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
     aee:	48 c7 42 10 ff ff 00 	movq   $0xffff,0x10(%rdx)
     af5:	00 
     af6:	48 89 4a 18          	mov    %rcx,0x18(%rdx)
     afa:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     b01:	00 00 00 
     b04:	48 89 4a 20          	mov    %rcx,0x20(%rdx)
     b08:	48 89 6a 28          	mov    %rbp,0x28(%rdx)
     b0c:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
     b13:	00 80 3f 
     b16:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
     b1a:	4c 89 62 30          	mov    %r12,0x30(%rdx)
     b1e:	48 89 7a 38          	mov    %rdi,0x38(%rdx)
     b22:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     b29:	00 00 00 
     b2c:	49 8d b5 07 a8 04 00 	lea    0x4a807(%r13),%rsi
     b33:	e9 ab 14 00 00       	jmp    1fe3 <f_8001161d0+0x1fe3>
     b38:	81 fa ac 03 00 00    	cmp    $0x3ac,%edx
     b3e:	41 b8 ff ff ff ff    	mov    $0xffffffff,%r8d
     b44:	0f 8f 79 06 00 00    	jg     11c3 <f_8001161d0+0x11c3>
     b4a:	81 fa d5 02 00 00    	cmp    $0x2d5,%edx
     b50:	0f 84 5d 1c 00 00    	je     27b3 <f_8001161d0+0x27b3>
     b56:	81 fa f3 02 00 00    	cmp    $0x2f3,%edx
     b5c:	0f 85 38 10 00 00    	jne    1b9a <f_8001161d0+0x1b9a>
     b62:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     b69:	00 
     b6a:	48 8b b3 00 01 00 00 	mov    0x100(%rbx),%rsi
     b71:	48 c7 06 00 02 00 00 	movq   $0x200,(%rsi)
     b78:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
     b7f:	00 40 00 
     b82:	48 89 4e 08          	mov    %rcx,0x8(%rsi)
     b86:	48 c7 46 10 ff ff 00 	movq   $0xffff,0x10(%rsi)
     b8d:	00 
     b8e:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     b95:	ff ff ff 
     b98:	48 8d 4a 13          	lea    0x13(%rdx),%rcx
     b9c:	48 89 4e 18          	mov    %rcx,0x18(%rsi)
     ba0:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     ba7:	00 00 00 
     baa:	48 89 4e 20          	mov    %rcx,0x20(%rsi)
     bae:	48 89 56 28          	mov    %rdx,0x28(%rsi)
     bb2:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
     bb8:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
     bbc:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
     bc3:	00 80 3f 
     bc6:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
     bca:	48 8d 56 30          	lea    0x30(%rsi),%rdx
     bce:	48 83 c6 38          	add    $0x38,%rsi
     bd2:	48 b9 ca 5d c0 02 08 	movabs $0x802c05dca,%rcx
     bd9:	00 00 00 
     bdc:	4c 8d 81 f9 7a ff ff 	lea    -0x8507(%rcx),%r8
     be3:	e9 1f 1e 00 00       	jmp    2a07 <f_8001161d0+0x2a07>
     be8:	48 8d 0d 00 00 00 00 	lea    0x0(%rip),%rcx        # bef <f_8001161d0+0xbef>
     bef:	4a 63 14 81          	movslq (%rcx,%r8,4),%rdx
     bf3:	48 01 ca             	add    %rcx,%rdx
     bf6:	ff e2                	jmp    *%rdx
     bf8:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     bff:	00 00 00 
     c02:	4d 8d 5d e0          	lea    -0x20(%r13),%r11
     c06:	e9 1b 09 00 00       	jmp    1526 <f_8001161d0+0x1526>
     c0b:	81 fa c9 00 00 00    	cmp    $0xc9,%edx
     c11:	0f 84 3a 13 00 00    	je     1f51 <f_8001161d0+0x1f51>
     c17:	81 fa d9 00 00 00    	cmp    $0xd9,%edx
     c1d:	0f 85 77 0f 00 00    	jne    1b9a <f_8001161d0+0x1b9a>
     c23:	49 8b b6 c8 1e 00 00 	mov    0x1ec8(%r14),%rsi
     c2a:	48 89 73 08          	mov    %rsi,0x8(%rbx)
     c2e:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
     c33:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
     c37:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
     c3e:	00 
     c3f:	45 0f b6 43 08       	movzbl 0x8(%r11),%r8d
     c44:	4c 89 43 70          	mov    %r8,0x70(%rbx)
     c48:	45 0f b7 9b 14 29 00 	movzwl 0x2914(%r11),%r11d
     c4f:	00 
     c50:	8b 4e 08             	mov    0x8(%rsi),%ecx
     c53:	4c 8b 76 10          	mov    0x10(%rsi),%r14
     c57:	48 c7 43 78 e0 3c 00 	movq   $0x3ce0,0x78(%rbx)
     c5e:	00 
     c5f:	31 d2                	xor    %edx,%edx
     c61:	44 39 c1             	cmp    %r8d,%ecx
     c64:	b9 00 00 00 00       	mov    $0x0,%ecx
     c69:	49 0f 47 c8          	cmova  %r8,%rcx
     c6d:	48 89 8b 88 00 00 00 	mov    %rcx,0x88(%rbx)
     c74:	48 69 c9 e0 3c 00 00 	imul   $0x3ce0,%rcx,%rcx
     c7b:	4a 8b 8c 31 40 3c 00 	mov    0x3c40(%rcx,%r14,1),%rcx
     c82:	00 
     c83:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
     c8a:	4c 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%r14
     c91:	4d 8b b6 b8 1e 00 00 	mov    0x1eb8(%r14),%r14
     c98:	44 89 90 70 ff ff ff 	mov    %r10d,-0x90(%rax)
     c9f:	48 89 b8 58 ff ff ff 	mov    %rdi,-0xa8(%rax)
     ca6:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
     cad:	ff 7f 7f 
     cb0:	4c 89 90 60 ff ff ff 	mov    %r10,-0xa0(%rax)
     cb7:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
     cbe:	00 
     cbf:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
     cc3:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
     cca:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
     cce:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
     cd5:	ff 
     cd6:	41 80 be b0 06 00 00 	cmpb   $0x0,0x6b0(%r14)
     cdd:	00 
     cde:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
     ce5:	00 00 00 00 
     ce9:	48 8b 3c 24          	mov    (%rsp),%rdi
     ced:	48 89 b8 20 ff ff ff 	mov    %rdi,-0xe0(%rax)
     cf4:	48 c7 80 00 ff ff ff 	movq   $0x4,-0x100(%rax)
     cfb:	04 00 00 00 
     cff:	48 89 0b             	mov    %rcx,(%rbx)
     d02:	0f 95 c1             	setne  %cl
     d05:	41 83 e3 40          	and    $0x40,%r11d
     d09:	41 c1 eb 06          	shr    $0x6,%r11d
     d0d:	41 20 cb             	and    %cl,%r11b
     d10:	c7 80 d8 fe ff ff 00 	movl   $0x0,-0x128(%rax)
     d17:	00 00 00 
     d1a:	41 0f b6 cb          	movzbl %r11b,%ecx
     d1e:	c1 e1 1a             	shl    $0x1a,%ecx
     d21:	81 c9 01 00 40 00    	or     $0x400001,%ecx
     d27:	89 88 dc fe ff ff    	mov    %ecx,-0x124(%rax)
     d2d:	48 b9 10 00 00 00 03 	movabs $0x300000010,%rcx
     d34:	00 00 00 
     d37:	48 89 88 d0 fe ff ff 	mov    %rcx,-0x130(%rax)
     d3e:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
     d45:	ff ff 00 00 
     d49:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
     d50:	ff ff ff 
     d53:	48 8d 4d 07          	lea    0x7(%rbp),%rcx
     d57:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
     d5e:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     d65:	00 00 00 
     d68:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
     d6f:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
     d76:	48 b9 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rcx
     d7d:	00 80 3f 
     d80:	48 89 88 08 ff ff ff 	mov    %rcx,-0xf8(%rax)
     d87:	48 89 88 10 ff ff ff 	mov    %rcx,-0xf0(%rax)
     d8e:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
     d95:	00 00 00 
     d98:	49 8d 8d 00 54 09 00 	lea    0x95400(%r13),%rcx
     d9f:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
     da3:	48 8b bb c0 00 00 00 	mov    0xc0(%rbx),%rdi
     daa:	4c 8b 4c 24 08       	mov    0x8(%rsp),%r9
     daf:	4c 89 8f a4 00 00 00 	mov    %r9,0xa4(%rdi)
     db6:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
     dbd:	ff 7f ff 
     dc0:	48 89 bb 80 00 00 00 	mov    %rdi,0x80(%rbx)
     dc7:	4c 89 90 48 ff ff ff 	mov    %r10,-0xb8(%rax)
     dce:	48 89 b8 50 ff ff ff 	mov    %rdi,-0xb0(%rax)
     dd5:	48 89 b8 68 ff ff ff 	mov    %rdi,-0x98(%rax)
     ddc:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
     de3:	00 00 00 00 
     de7:	48 89 88 40 ff ff ff 	mov    %rcx,-0xc0(%rax)
     dee:	49 69 f8 e0 3c 00 00 	imul   $0x3ce0,%r8,%rdi
     df5:	44 39 46 08          	cmp    %r8d,0x8(%rsi)
     df9:	b9 00 00 00 00       	mov    $0x0,%ecx
     dfe:	48 0f 47 cf          	cmova  %rdi,%rcx
     e02:	4c 8b 4e 10          	mov    0x10(%rsi),%r9
     e06:	c4 c1 78 10 84 09 00 	vmovups 0x2e00(%r9,%rcx,1),%xmm0
     e0d:	2e 00 00 
     e10:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
     e17:	ff 
     e18:	44 8b 4e 08          	mov    0x8(%rsi),%r9d
     e1c:	45 31 d2             	xor    %r10d,%r10d
     e1f:	31 c9                	xor    %ecx,%ecx
     e21:	45 89 cb             	mov    %r9d,%r11d
     e24:	45 29 c3             	sub    %r8d,%r11d
     e27:	48 0f 47 d7          	cmova  %rdi,%rdx
     e2b:	41 0f 94 c2          	sete   %r10b
     e2f:	0f 93 c1             	setae  %cl
     e32:	41 c1 e2 1e          	shl    $0x1e,%r10d
     e36:	c1 e1 1d             	shl    $0x1d,%ecx
     e39:	44 09 d1             	or     %r10d,%ecx
     e3c:	c4 c2 20 f2 f9       	andn   %r9d,%r11d,%edi
     e41:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
     e48:	44 09 d9             	or     %r11d,%ecx
     e4b:	48 8b 76 10          	mov    0x10(%rsi),%rsi
     e4f:	c1 ef 03             	shr    $0x3,%edi
     e52:	81 e7 00 00 00 10    	and    $0x10000000,%edi
     e58:	09 cf                	or     %ecx,%edi
     e5a:	48 89 bb 10 01 00 00 	mov    %rdi,0x110(%rbx)
     e61:	48 8b 8c 16 80 30 00 	mov    0x3080(%rsi,%rdx,1),%rcx
     e68:	00 
     e69:	48 8b bc 16 88 30 00 	mov    0x3088(%rsi,%rdx,1),%rdi
     e70:	00 
     e71:	48 89 7b 50          	mov    %rdi,0x50(%rbx)
     e75:	48 89 88 60 ff ff ff 	mov    %rcx,-0xa0(%rax)
     e7c:	48 89 b8 68 ff ff ff 	mov    %rdi,-0x98(%rax)
     e83:	48 8b 8c 16 90 30 00 	mov    0x3090(%rsi,%rdx,1),%rcx
     e8a:	00 
     e8b:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
     e8f:	8b 94 16 98 30 00 00 	mov    0x3098(%rsi,%rdx,1),%edx
     e96:	89 90 78 ff ff ff    	mov    %edx,-0x88(%rax)
     e9c:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     ea3:	48 83 c2 f7          	add    $0xfffffffffffffff7,%rdx
     ea7:	48 89 53 40          	mov    %rdx,0x40(%rbx)
     eab:	48 89 88 70 ff ff ff 	mov    %rcx,-0x90(%rax)
     eb2:	49 8d 85 e6 09 51 fd 	lea    -0x2aef61a(%r13),%rax
     eb9:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
     ec0:	48 89 df             	mov    %rbx,%rdi
     ec3:	c5 f8 77             	vzeroupper
     ec6:	e8 00 00 00 00       	call   ecb <f_8001161d0+0xecb>
     ecb:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
     ed2:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
     ed9:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
     ee0:	48 89 01             	mov    %rax,(%rcx)
     ee3:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
     eea:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
     ef1:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
     ef5:	48 89 53 48          	mov    %rdx,0x48(%rbx)
     ef9:	48 8b b0 f8 15 00 00 	mov    0x15f8(%rax),%rsi
     f00:	48 89 73 50          	mov    %rsi,0x50(%rbx)
     f04:	8b 80 00 16 00 00    	mov    0x1600(%rax),%eax
     f0a:	48 89 43 40          	mov    %rax,0x40(%rbx)
     f0e:	88 51 08             	mov    %dl,0x8(%rcx)
     f11:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
     f18:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
     f1c:	89 41 24             	mov    %eax,0x24(%rcx)
     f1f:	e9 b4 1c 00 00       	jmp    2bd8 <f_8001161d0+0x2bd8>
     f24:	81 fa b2 01 00 00    	cmp    $0x1b2,%edx
     f2a:	0f 84 8e 19 00 00    	je     28be <f_8001161d0+0x28be>
     f30:	81 fa b8 01 00 00    	cmp    $0x1b8,%edx
     f36:	0f 85 5e 0c 00 00    	jne    1b9a <f_8001161d0+0x1b9a>
     f3c:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     f43:	00 
     f44:	48 8b b3 00 01 00 00 	mov    0x100(%rbx),%rsi
     f4b:	48 c7 06 08 00 00 00 	movq   $0x8,(%rsi)
     f52:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
     f59:	00 40 00 
     f5c:	48 89 4e 08          	mov    %rcx,0x8(%rsi)
     f60:	48 c7 46 10 ff ff 00 	movq   $0xffff,0x10(%rsi)
     f67:	00 
     f68:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
     f6f:	ff ff ff 
     f72:	48 8d 4a 15          	lea    0x15(%rdx),%rcx
     f76:	48 89 4e 18          	mov    %rcx,0x18(%rsi)
     f7a:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
     f81:	00 00 00 
     f84:	48 89 4e 20          	mov    %rcx,0x20(%rsi)
     f88:	48 89 56 28          	mov    %rdx,0x28(%rsi)
     f8c:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
     f92:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
     f96:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
     f9d:	00 80 3f 
     fa0:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
     fa4:	48 8d 56 30          	lea    0x30(%rsi),%rdx
     fa8:	48 83 c6 38          	add    $0x38,%rsi
     fac:	48 b9 ca 5d c0 02 08 	movabs $0x802c05dca,%rcx
     fb3:	00 00 00 
     fb6:	4c 8d 81 af 2c 05 00 	lea    0x52caf(%rcx),%r8
     fbd:	e9 45 1a 00 00       	jmp    2a07 <f_8001161d0+0x2a07>
     fc2:	81 fa b6 02 00 00    	cmp    $0x2b6,%edx
     fc8:	0f 84 45 19 00 00    	je     2913 <f_8001161d0+0x2913>
     fce:	81 fa c5 02 00 00    	cmp    $0x2c5,%edx
     fd4:	0f 85 c0 0b 00 00    	jne    1b9a <f_8001161d0+0x1b9a>
     fda:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
     fe1:	00 
     fe2:	48 8b b3 00 01 00 00 	mov    0x100(%rbx),%rsi
     fe9:	48 b9 01 00 00 00 04 	movabs $0x400000001,%rcx
     ff0:	00 00 00 
     ff3:	48 89 0e             	mov    %rcx,(%rsi)
     ff6:	48 b9 00 00 00 00 02 	movabs $0x80200000000,%rcx
     ffd:	08 00 00 
    1000:	48 89 4e 08          	mov    %rcx,0x8(%rsi)
    1004:	48 c7 46 10 ff ff 00 	movq   $0xffff,0x10(%rsi)
    100b:	00 
    100c:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    1013:	ff ff ff 
    1016:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    101a:	48 89 4e 18          	mov    %rcx,0x18(%rsi)
    101e:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    1025:	00 00 00 
    1028:	48 89 4e 20          	mov    %rcx,0x20(%rsi)
    102c:	48 89 56 28          	mov    %rdx,0x28(%rsi)
    1030:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    1034:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
    103b:	00 80 3f 
    103e:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
    1042:	48 8d 56 30          	lea    0x30(%rsi),%rdx
    1046:	48 83 c6 38          	add    $0x38,%rsi
    104a:	48 b9 ca 5d c0 02 08 	movabs $0x802c05dca,%rcx
    1051:	00 00 00 
    1054:	4c 8d 81 88 db 0a 00 	lea    0xadb88(%rcx),%r8
    105b:	e9 a7 19 00 00       	jmp    2a07 <f_8001161d0+0x2a07>
    1060:	81 fa 52 02 00 00    	cmp    $0x252,%edx
    1066:	0f 84 24 19 00 00    	je     2990 <f_8001161d0+0x2990>
    106c:	81 fa 61 02 00 00    	cmp    $0x261,%edx
    1072:	0f 85 22 0b 00 00    	jne    1b9a <f_8001161d0+0x1b9a>
    1078:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    107f:	44 89 92 a0 00 00 00 	mov    %r10d,0xa0(%rdx)
    1086:	48 b9 00 00 00 00 0f 	movabs $0xf00000000,%rcx
    108d:	00 00 00 
    1090:	48 89 4a 14          	mov    %rcx,0x14(%rdx)
    1094:	48 b9 00 00 00 00 ff 	movabs $0xffff00000000,%rcx
    109b:	ff 00 00 
    109e:	48 81 c9 00 00 40 08 	or     $0x8400000,%rcx
    10a5:	48 89 4a 0c          	mov    %rcx,0xc(%rdx)
    10a9:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
    10b0:	be 00 00 02 00       	mov    $0x20000,%esi
    10b5:	23 b1 8c 3a 00 00    	and    0x3a8c(%rcx),%esi
    10bb:	4c 8b 44 24 10       	mov    0x10(%rsp),%r8
    10c0:	4c 89 43 60          	mov    %r8,0x60(%rbx)
    10c4:	48 8b 3c 24          	mov    (%rsp),%rdi
    10c8:	48 89 7b 40          	mov    %rdi,0x40(%rbx)
    10cc:	48 c7 42 04 00 00 00 	movq   $0x0,0x4(%rdx)
    10d3:	00 
    10d4:	48 8b 4b 78          	mov    0x78(%rbx),%rcx
    10d8:	48 89 4a 1c          	mov    %rcx,0x1c(%rdx)
    10dc:	48 c7 43 68 01 00 00 	movq   $0x1,0x68(%rbx)
    10e3:	00 
    10e4:	c7 42 34 00 00 00 00 	movl   $0x0,0x34(%rdx)
    10eb:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    10f2:	00 
    10f3:	48 c7 42 24 01 00 00 	movq   $0x1,0x24(%rdx)
    10fa:	00 
    10fb:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    10ff:	c7 82 bc 00 00 00 00 	movl   $0x0,0xbc(%rdx)
    1106:	00 00 00 
    1109:	89 4a 2c             	mov    %ecx,0x2c(%rdx)
    110c:	c7 42 30 01 00 00 00 	movl   $0x1,0x30(%rdx)
    1113:	c1 ee 08             	shr    $0x8,%esi
    1116:	81 ce 00 00 00 40    	or     $0x40000000,%esi
    111c:	89 32                	mov    %esi,(%rdx)
    111e:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    1125:	00 00 00 
    1128:	48 05 f0 85 00 00    	add    $0x85f0,%rax
    112e:	48 89 43 70          	mov    %rax,0x70(%rbx)
    1132:	48 b9 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rcx
    1139:	00 80 3f 
    113c:	48 89 4a 38          	mov    %rcx,0x38(%rdx)
    1140:	48 89 4a 40          	mov    %rcx,0x40(%rdx)
    1144:	48 8b 8b c0 00 00 00 	mov    0xc0(%rbx),%rcx
    114b:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    1150:	48 89 b1 a4 00 00 00 	mov    %rsi,0xa4(%rcx)
    1157:	48 b9 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rcx
    115e:	ff 7f ff 
    1161:	48 89 8b 80 00 00 00 	mov    %rcx,0x80(%rbx)
    1168:	48 89 8a 98 00 00 00 	mov    %rcx,0x98(%rdx)
    116f:	48 be ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rsi
    1176:	ff 7f 7f 
    1179:	48 89 72 78          	mov    %rsi,0x78(%rdx)
    117d:	48 89 8a 80 00 00 00 	mov    %rcx,0x80(%rdx)
    1184:	4c 89 82 88 00 00 00 	mov    %r8,0x88(%rdx)
    118b:	48 89 b2 90 00 00 00 	mov    %rsi,0x90(%rdx)
    1192:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1196:	c5 f8 11 42 58       	vmovups %xmm0,0x58(%rdx)
    119b:	48 c7 42 68 00 00 00 	movq   $0x0,0x68(%rdx)
    11a2:	00 
    11a3:	48 89 42 70          	mov    %rax,0x70(%rdx)
    11a7:	48 c7 42 48 00 00 00 	movq   $0x0,0x48(%rdx)
    11ae:	00 
    11af:	48 89 7a 50          	mov    %rdi,0x50(%rdx)
    11b3:	48 8b 6b 48          	mov    0x48(%rbx),%rbp
    11b7:	4c 8b ab d0 00 00 00 	mov    0xd0(%rbx),%r13
    11be:	e9 f4 18 00 00       	jmp    2ab7 <f_8001161d0+0x2ab7>
    11c3:	81 fa ad 03 00 00    	cmp    $0x3ad,%edx
    11c9:	0f 84 dd 20 00 00    	je     32ac <f_8001161d0+0x32ac>
    11cf:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    11d5:	81 fa 12 04 00 00    	cmp    $0x412,%edx
    11db:	0f 85 b9 09 00 00    	jne    1b9a <f_8001161d0+0x1b9a>
    11e1:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
    11e8:	48 8b 91 c8 1e 00 00 	mov    0x1ec8(%rcx),%rdx
    11ef:	48 89 53 70          	mov    %rdx,0x70(%rbx)
    11f3:	48 be 00 00 00 00 01 	movabs $0x100000000,%rsi
    11fa:	00 00 00 
    11fd:	48 89 33             	mov    %rsi,(%rbx)
    1200:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1204:	4c 8b 83 00 01 00 00 	mov    0x100(%rbx),%r8
    120b:	49 c7 00 02 00 00 00 	movq   $0x2,(%r8)
    1212:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    1219:	00 40 00 
    121c:	48 ff c1             	inc    %rcx
    121f:	49 89 48 08          	mov    %rcx,0x8(%r8)
    1223:	49 89 70 20          	mov    %rsi,0x20(%r8)
    1227:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    122e:	ff ff ff 
    1231:	49 89 68 28          	mov    %rbp,0x28(%r8)
    1235:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    123c:	00 00 00 
    123f:	4c 89 6b 68          	mov    %r13,0x68(%rbx)
    1243:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    124a:	ff 7f ff 
    124d:	49 89 b8 80 00 00 00 	mov    %rdi,0x80(%r8)
    1254:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
    1259:	49 89 88 88 00 00 00 	mov    %rcx,0x88(%r8)
    1260:	48 8b 8b c0 00 00 00 	mov    0xc0(%rbx),%rcx
    1267:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    126c:	48 89 b1 a4 00 00 00 	mov    %rsi,0xa4(%rcx)
    1273:	48 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rcx
    127a:	ff 7f 7f 
    127d:	49 89 88 90 00 00 00 	mov    %rcx,0x90(%r8)
    1284:	49 89 b8 98 00 00 00 	mov    %rdi,0x98(%r8)
    128b:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 1293 <f_8001161d0+0x1293>
    1292:	00 
    1293:	c5 fc 11 43 78       	vmovups %ymm0,0x78(%rbx)
    1298:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    129f:	00 
    12a0:	45 89 90 a0 00 00 00 	mov    %r10d,0xa0(%r8)
    12a7:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    12ae:	0f b6 70 08          	movzbl 0x8(%rax),%esi
    12b2:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    12b6:	41 c7 80 bc 00 00 00 	movl   $0x3,0xbc(%r8)
    12bd:	03 00 00 00 
    12c1:	49 c7 40 10 ff ff 00 	movq   $0xffff,0x10(%r8)
    12c8:	00 
    12c9:	48 8d 45 16          	lea    0x16(%rbp),%rax
    12cd:	49 89 40 18          	mov    %rax,0x18(%r8)
    12d1:	49 c7 40 68 00 00 00 	movq   $0x0,0x68(%r8)
    12d8:	00 
    12d9:	4d 89 48 30          	mov    %r9,0x30(%r8)
    12dd:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    12e4:	00 80 3f 
    12e7:	49 89 40 38          	mov    %rax,0x38(%r8)
    12eb:	49 89 40 40          	mov    %rax,0x40(%r8)
    12ef:	49 c7 40 48 00 00 00 	movq   $0x0,0x48(%r8)
    12f6:	00 
    12f7:	48 8b 04 24          	mov    (%rsp),%rax
    12fb:	49 89 40 50          	mov    %rax,0x50(%r8)
    12ff:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1303:	c4 c1 78 11 40 58    	vmovups %xmm0,0x58(%r8)
    1309:	4d 89 68 70          	mov    %r13,0x70(%r8)
    130d:	49 89 48 78          	mov    %rcx,0x78(%r8)
    1311:	48 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rax
    1318:	31 ff                	xor    %edi,%edi
    131a:	39 72 08             	cmp    %esi,0x8(%rdx)
    131d:	48 0f 46 c7          	cmovbe %rdi,%rax
    1321:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    1325:	48 8b 94 08 b8 30 00 	mov    0x30b8(%rax,%rcx,1),%rdx
    132c:	00 
    132d:	48 89 53 60          	mov    %rdx,0x60(%rbx)
    1331:	48 8b 84 08 b0 30 00 	mov    0x30b0(%rax,%rcx,1),%rax
    1338:	00 
    1339:	48 8b 4b 48          	mov    0x48(%rbx),%rcx
    133d:	48 89 01             	mov    %rax,(%rcx)
    1340:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    1344:	48 8b 43 70          	mov    0x70(%rbx),%rax
    1348:	44 8b 40 08          	mov    0x8(%rax),%r8d
    134c:	4c 89 43 48          	mov    %r8,0x48(%rbx)
    1350:	48 8b 48 10          	mov    0x10(%rax),%rcx
    1354:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    1358:	8b 53 40             	mov    0x40(%rbx),%edx
    135b:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
    1362:	45 31 d2             	xor    %r10d,%r10d
    1365:	45 31 c9             	xor    %r9d,%r9d
    1368:	45 89 c3             	mov    %r8d,%r11d
    136b:	41 29 f3             	sub    %esi,%r11d
    136e:	48 0f 46 d7          	cmovbe %rdi,%rdx
    1372:	41 0f 94 c2          	sete   %r10b
    1376:	41 0f 93 c1          	setae  %r9b
    137a:	41 c1 e2 1e          	shl    $0x1e,%r10d
    137e:	41 c1 e1 1d          	shl    $0x1d,%r9d
    1382:	45 09 d1             	or     %r10d,%r9d
    1385:	c4 c2 20 f2 f0       	andn   %r8d,%r11d,%esi
    138a:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    1391:	45 09 d9             	or     %r11d,%r9d
    1394:	c1 ee 03             	shr    $0x3,%esi
    1397:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    139d:	44 09 ce             	or     %r9d,%esi
    13a0:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    13a7:	48 8b b4 0a 30 33 00 	mov    0x3330(%rdx,%rcx,1),%rsi
    13ae:	00 
    13af:	48 8b bc 0a 38 33 00 	mov    0x3338(%rdx,%rcx,1),%rdi
    13b6:	00 
    13b7:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    13bb:	4c 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%r8
    13c2:	49 89 30             	mov    %rsi,(%r8)
    13c5:	49 89 78 08          	mov    %rdi,0x8(%r8)
    13c9:	8b b4 0a 48 33 00 00 	mov    0x3348(%rdx,%rcx,1),%esi
    13d0:	48 8b 8c 0a 40 33 00 	mov    0x3340(%rdx,%rcx,1),%rcx
    13d7:	00 
    13d8:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
    13df:	48 89 0a             	mov    %rcx,(%rdx)
    13e2:	89 72 08             	mov    %esi,0x8(%rdx)
    13e5:	8b 48 44             	mov    0x44(%rax),%ecx
    13e8:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    13ec:	48 83 c0 30          	add    $0x30,%rax
    13f0:	e9 8b 0a 00 00       	jmp    1e80 <f_8001161d0+0x1e80>
    13f5:	81 fa 1a 05 00 00    	cmp    $0x51a,%edx
    13fb:	0f 85 99 07 00 00    	jne    1b9a <f_8001161d0+0x1b9a>
    1401:	b8 e8 0a 00 00       	mov    $0xae8,%eax
    1406:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    140d:	48 89 03             	mov    %rax,(%rbx)
    1410:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1417:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    141e:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    1422:	48 89 43 10          	mov    %rax,0x10(%rbx)
    1426:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    142d:	00 00 00 
    1430:	49 8d 85 ca 19 51 fd 	lea    -0x2aee636(%r13),%rax
    1437:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    143e:	48 89 df             	mov    %rbx,%rdi
    1441:	c5 f8 77             	vzeroupper
    1444:	e8 00 00 00 00       	call   1449 <f_8001161d0+0x1449>
    1449:	e9 8a 17 00 00       	jmp    2bd8 <f_8001161d0+0x2bd8>
    144e:	83 fa 61             	cmp    $0x61,%edx
    1451:	0f 85 43 07 00 00    	jne    1b9a <f_8001161d0+0x1b9a>
    1457:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    145e:	00 
    145f:	48 c7 80 d0 fe ff ff 	movq   $0x8,-0x130(%rax)
    1466:	08 00 00 00 
    146a:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    1471:	00 40 00 
    1474:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    147b:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    1482:	ff ff 00 00 
    1486:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    148d:	ff ff ff 
    1490:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    1494:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    149b:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    14a2:	00 00 00 
    14a5:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
    14a9:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    14b0:	48 89 90 f8 fe ff ff 	mov    %rdx,-0x108(%rax)
    14b7:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
    14be:	00 80 3f 
    14c1:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
    14c5:	48 8d 90 00 ff ff ff 	lea    -0x100(%rax),%rdx
    14cc:	48 8d b0 08 ff ff ff 	lea    -0xf8(%rax),%rsi
    14d3:	48 b9 ca 5d c0 02 08 	movabs $0x802c05dca,%rcx
    14da:	00 00 00 
    14dd:	4c 8d 81 ab f2 0c 00 	lea    0xcf2ab(%rcx),%r8
    14e4:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    14ea:	e9 18 15 00 00       	jmp    2a07 <f_8001161d0+0x2a07>
    14ef:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    14f6:	00 00 00 
    14f9:	4d 8d 9d 0b d1 09 00 	lea    0x9d10b(%r13),%r11
    1500:	eb 24                	jmp    1526 <f_8001161d0+0x1526>
    1502:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1509:	00 00 00 
    150c:	4d 8d 9d 2d 8c 01 00 	lea    0x18c2d(%r13),%r11
    1513:	eb 11                	jmp    1526 <f_8001161d0+0x1526>
    1515:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    151c:	00 00 00 
    151f:	4d 8d 9d 4b 4f 0a 00 	lea    0xa4f4b(%r13),%r11
    1526:	4c 89 5b 68          	mov    %r11,0x68(%rbx)
    152a:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    1531:	c7 02 00 00 00 10    	movl   $0x10000000,(%rdx)
    1537:	4c 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%r14
    153e:	49 8b b6 f0 31 00 00 	mov    0x31f0(%r14),%rsi
    1545:	48 89 33             	mov    %rsi,(%rbx)
    1548:	48 b9 10 00 00 00 03 	movabs $0x300000010,%rcx
    154f:	00 00 00 
    1552:	4c 8d 41 f0          	lea    -0x10(%rcx),%r8
    1556:	4c 89 42 14          	mov    %r8,0x14(%rdx)
    155a:	48 c7 43 78 01 00 00 	movq   $0x1,0x78(%rbx)
    1561:	00 
    1562:	48 83 c1 f6          	add    $0xfffffffffffffff6,%rcx
    1566:	48 89 4a 04          	mov    %rcx,0x4(%rdx)
    156a:	48 8b 4b 70          	mov    0x70(%rbx),%rcx
    156e:	48 89 4a 2c          	mov    %rcx,0x2c(%rdx)
    1572:	48 b9 00 00 00 00 ff 	movabs $0xffff00000000,%rcx
    1579:	ff 00 00 
    157c:	48 89 4a 0c          	mov    %rcx,0xc(%rdx)
    1580:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    1587:	ff 7f ff 
    158a:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
    158e:	4c 89 62 1c          	mov    %r12,0x1c(%rdx)
    1592:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    1597:	4c 89 4b 60          	mov    %r9,0x60(%rbx)
    159b:	48 b9 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rcx
    15a2:	00 80 3f 
    15a5:	48 89 4a 38          	mov    %rcx,0x38(%rdx)
    15a9:	48 89 4a 40          	mov    %rcx,0x40(%rdx)
    15ad:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    15b2:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    15b6:	4c 8b 3c 24          	mov    (%rsp),%r15
    15ba:	4c 89 7b 50          	mov    %r15,0x50(%rbx)
    15be:	48 c7 42 24 01 00 00 	movq   $0x1,0x24(%rdx)
    15c5:	00 
    15c6:	c7 42 34 00 00 00 00 	movl   $0x0,0x34(%rdx)
    15cd:	4c 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%r8
    15d4:	49 89 88 a4 00 00 00 	mov    %rcx,0xa4(%r8)
    15db:	48 89 ba 98 00 00 00 	mov    %rdi,0x98(%rdx)
    15e2:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    15e6:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    15ed:	00 
    15ee:	44 89 92 a0 00 00 00 	mov    %r10d,0xa0(%rdx)
    15f5:	c7 82 bc 00 00 00 01 	movl   $0x1,0xbc(%rdx)
    15fc:	00 00 00 
    15ff:	48 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rax
    1606:	ff 7f 7f 
    1609:	48 89 42 78          	mov    %rax,0x78(%rdx)
    160d:	48 89 ba 80 00 00 00 	mov    %rdi,0x80(%rdx)
    1614:	4c 89 8a 88 00 00 00 	mov    %r9,0x88(%rdx)
    161b:	48 89 82 90 00 00 00 	mov    %rax,0x90(%rdx)
    1622:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1626:	c5 f8 11 42 58       	vmovups %xmm0,0x58(%rdx)
    162b:	48 c7 42 68 00 00 00 	movq   $0x0,0x68(%rdx)
    1632:	00 
    1633:	4c 89 5a 70          	mov    %r11,0x70(%rdx)
    1637:	48 c7 42 48 00 00 00 	movq   $0x0,0x48(%rdx)
    163e:	00 
    163f:	4c 89 7a 50          	mov    %r15,0x50(%rdx)
    1643:	48 85 f6             	test   %rsi,%rsi
    1646:	0f 84 8c 15 00 00    	je     2bd8 <f_8001161d0+0x2bd8>
    164c:	49 89 cb             	mov    %rcx,%r11
    164f:	49 8b 8e c8 1e 00 00 	mov    0x1ec8(%r14),%rcx
    1656:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    165d:	0f b6 78 08          	movzbl 0x8(%rax),%edi
    1661:	44 8b 49 08          	mov    0x8(%rcx),%r9d
    1665:	31 c0                	xor    %eax,%eax
    1667:	41 39 f9             	cmp    %edi,%r9d
    166a:	41 b9 00 00 00 00    	mov    $0x0,%r9d
    1670:	4c 0f 47 cf          	cmova  %rdi,%r9
    1674:	48 8b 49 10          	mov    0x10(%rcx),%rcx
    1678:	48 c7 43 60 e0 3c 00 	movq   $0x3ce0,0x60(%rbx)
    167f:	00 
    1680:	4c 89 4b 58          	mov    %r9,0x58(%rbx)
    1684:	49 69 f9 e0 3c 00 00 	imul   $0x3ce0,%r9,%rdi
    168b:	4c 8d 0c 0f          	lea    (%rdi,%rcx,1),%r9
    168f:	4c 89 4b 50          	mov    %r9,0x50(%rbx)
    1693:	c5 fa 10 8c 0f 08 2e 	vmovss 0x2e08(%rdi,%rcx,1),%xmm1
    169a:	00 00 
    169c:	c5 fa 10 9c 0f 0c 2e 	vmovss 0x2e0c(%rdi,%rcx,1),%xmm3
    16a3:	00 00 
    16a5:	c5 f2 5c 94 0f 00 2e 	vsubss 0x2e00(%rdi,%rcx,1),%xmm1,%xmm2
    16ac:	00 00 
    16ae:	c5 e2 5c 9c 0f 04 2e 	vsubss 0x2e04(%rdi,%rcx,1),%xmm3,%xmm3
    16b5:	00 00 
    16b7:	44 89 92 a0 00 00 00 	mov    %r10d,0xa0(%rdx)
    16be:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
    16c5:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
    16c9:	c4 e1 fa 2c fb       	vcvttss2si %xmm3,%rdi
    16ce:	c5 f0 57 c9          	vxorps %xmm1,%xmm1,%xmm1
    16d2:	c5 f8 2e d9          	vucomiss %xmm1,%xmm3
    16d6:	0f 42 f8             	cmovb  %eax,%edi
    16d9:	c5 fa 10 25 00 00 00 	vmovss 0x0(%rip),%xmm4        # 16e1 <f_8001161d0+0x16e1>
    16e0:	00 
    16e1:	c5 f8 2e dc          	vucomiss %xmm4,%xmm3
    16e5:	ba ff ff ff ff       	mov    $0xffffffff,%edx
    16ea:	0f 47 fa             	cmova  %edx,%edi
    16ed:	c4 e1 82 2a df       	vcvtsi2ss %rdi,%xmm15,%xmm3
    16f2:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    16f6:	4d 89 98 a4 00 00 00 	mov    %r11,0xa4(%r8)
    16fd:	c5 e2 59 9e 0c 03 00 	vmulss 0x30c(%rsi),%xmm3,%xmm3
    1704:	00 
    1705:	31 ff                	xor    %edi,%edi
    1707:	c5 f8 2e d9          	vucomiss %xmm1,%xmm3
    170b:	40 0f 96 c7          	setbe  %dil
    170f:	c5 f9 7e d9          	vmovd  %xmm3,%ecx
    1713:	48 0f 47 c8          	cmova  %rax,%rcx
    1717:	c1 e7 1c             	shl    $0x1c,%edi
    171a:	48 81 cf 00 00 00 20 	or     $0x20000000,%rdi
    1721:	49 81 c4 01 00 00 80 	add    $0xffffffff80000001,%r12
    1728:	c5 f8 2e cb          	vucomiss %xmm3,%xmm1
    172c:	4c 0f 46 e7          	cmovbe %rdi,%r12
    1730:	c5 f8 2e d9          	vucomiss %xmm1,%xmm3
    1734:	c4 61 fa 2c c2       	vcvttss2si %xmm2,%r8
    1739:	bf 00 00 00 60       	mov    $0x60000000,%edi
    173e:	49 0f 45 fc          	cmovne %r12,%rdi
    1742:	49 0f 4a fc          	cmovp  %r12,%rdi
    1746:	c5 f8 2e d1          	vucomiss %xmm1,%xmm2
    174a:	44 0f 42 c0          	cmovb  %eax,%r8d
    174e:	c5 f8 2e d4          	vucomiss %xmm4,%xmm2
    1752:	44 0f 47 c2          	cmova  %edx,%r8d
    1756:	c4 c1 82 2a d0       	vcvtsi2ss %r8,%xmm15,%xmm2
    175b:	c5 ea 59 96 08 03 00 	vmulss 0x308(%rsi),%xmm2,%xmm2
    1762:	00 
    1763:	c5 f9 7e d2          	vmovd  %xmm2,%edx
    1767:	c5 f8 29 83 20 02 00 	vmovaps %xmm0,0x220(%rbx)
    176e:	00 
    176f:	c5 f8 2e d1          	vucomiss %xmm1,%xmm2
    1773:	c5 ea 5f c1          	vmaxss %xmm1,%xmm2,%xmm0
    1777:	c5 f9 7e c6          	vmovd  %xmm0,%esi
    177b:	48 89 b3 30 02 00 00 	mov    %rsi,0x230(%rbx)
    1782:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    1789:	00 00 00 00 
    178d:	c5 e2 5f c9          	vmaxss %xmm1,%xmm3,%xmm1
    1791:	c5 f9 7e ce          	vmovd  %xmm1,%esi
    1795:	48 89 b3 40 02 00 00 	mov    %rsi,0x240(%rbx)
    179c:	48 c7 83 48 02 00 00 	movq   $0x0,0x248(%rbx)
    17a3:	00 00 00 00 
    17a7:	48 0f 47 d0          	cmova  %rax,%rdx
    17ab:	48 89 93 00 02 00 00 	mov    %rdx,0x200(%rbx)
    17b2:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    17b9:	00 00 00 00 
    17bd:	48 89 bb 10 01 00 00 	mov    %rdi,0x110(%rbx)
    17c4:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    17cb:	c5 fa 11 80 80 00 00 	vmovss %xmm0,0x80(%rax)
    17d2:	00 
    17d3:	c5 fa 11 88 84 00 00 	vmovss %xmm1,0x84(%rax)
    17da:	00 
    17db:	c5 fa 11 80 98 00 00 	vmovss %xmm0,0x98(%rax)
    17e2:	00 
    17e3:	c5 fa 11 88 9c 00 00 	vmovss %xmm1,0x9c(%rax)
    17ea:	00 
    17eb:	48 89 8b 10 02 00 00 	mov    %rcx,0x210(%rbx)
    17f2:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    17f9:	00 00 00 00 
    17fd:	89 50 78             	mov    %edx,0x78(%rax)
    1800:	89 48 7c             	mov    %ecx,0x7c(%rax)
    1803:	89 90 90 00 00 00    	mov    %edx,0x90(%rax)
    1809:	89 88 94 00 00 00    	mov    %ecx,0x94(%rax)
    180f:	49 8d 85 5e 18 51 fd 	lea    -0x2aee7a2(%r13),%rax
    1816:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    181d:	48 89 df             	mov    %rbx,%rdi
    1820:	c5 f8 77             	vzeroupper
    1823:	e8 00 00 00 00       	call   1828 <f_8001161d0+0x1828>
    1828:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    182f:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    1836:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    183d:	48 89 01             	mov    %rax,(%rcx)
    1840:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    1847:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    184b:	48 89 43 40          	mov    %rax,0x40(%rbx)
    184f:	88 41 08             	mov    %al,0x8(%rcx)
    1852:	e9 81 13 00 00       	jmp    2bd8 <f_8001161d0+0x2bd8>
    1857:	48 8b 53 78          	mov    0x78(%rbx),%rdx
    185b:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
    1862:	00 00 00 00 
    1866:	4c 89 80 20 ff ff ff 	mov    %r8,-0xe0(%rax)
    186d:	4c 8b 9b a0 00 00 00 	mov    0xa0(%rbx),%r11
    1874:	44 8b b3 a8 00 00 00 	mov    0xa8(%rbx),%r14d
    187b:	41 8d 7e 08          	lea    0x8(%r14),%edi
    187f:	48 8b b3 00 01 00 00 	mov    0x100(%rbx),%rsi
    1886:	c4 c2 6b f7 ab fc 0d 	shrx   %edx,0xdfc(%r11),%ebp
    188d:	00 00 
    188f:	89 7e 30             	mov    %edi,0x30(%rsi)
    1892:	4c 8b 63 68          	mov    0x68(%rbx),%r12
    1896:	44 89 66 34          	mov    %r12d,0x34(%rsi)
    189a:	45 31 ed             	xor    %r13d,%r13d
    189d:	41 f7 c7 00 02 00 00 	test   $0x200,%r15d
    18a4:	41 0f 94 c5          	sete   %r13b
    18a8:	41 8b bb 20 0d 00 00 	mov    0xd20(%r11),%edi
    18af:	45 31 c0             	xor    %r8d,%r8d
    18b2:	39 d7                	cmp    %edx,%edi
    18b4:	49 0f 46 d0          	cmovbe %r8,%rdx
    18b8:	31 c9                	xor    %ecx,%ecx
    18ba:	41 f7 c7 00 40 00 00 	test   $0x4000,%r15d
    18c1:	0f 94 c1             	sete   %cl
    18c4:	89 d7                	mov    %edx,%edi
    18c6:	48 69 ff b0 0b 00 00 	imul   $0xbb0,%rdi,%rdi
    18cd:	41 c1 e7 06          	shl    $0x6,%r15d
    18d1:	41 81 e7 00 00 04 00 	and    $0x40000,%r15d
    18d8:	c1 e1 04             	shl    $0x4,%ecx
    18db:	41 85 ed             	test   %ebp,%r13d
    18de:	bd 01 00 00 00       	mov    $0x1,%ebp
    18e3:	c4 62 19 f7 e5       	shlx   %r12d,%ebp,%r12d
    18e8:	48 c7 43 48 01 00 00 	movq   $0x1,0x48(%rbx)
    18ef:	00 
    18f0:	4c 89 63 08          	mov    %r12,0x8(%rbx)
    18f4:	4d 8b 9b 28 0d 00 00 	mov    0xd28(%r11),%r11
    18fb:	4c 89 5b 70          	mov    %r11,0x70(%rbx)
    18ff:	48 89 53 78          	mov    %rdx,0x78(%rbx)
    1903:	42 8d 8c 39 00 00 20 	lea    0x200000(%rcx,%r15,1),%ecx
    190a:	00 
    190b:	ba 0f 00 00 00       	mov    $0xf,%edx
    1910:	41 0f 45 d4          	cmovne %r12d,%edx
    1914:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    191b:	00 
    191c:	48 c7 03 08 00 00 00 	movq   $0x8,(%rbx)
    1923:	89 16                	mov    %edx,(%rsi)
    1925:	c7 46 04 08 00 00 00 	movl   $0x8,0x4(%rsi)
    192c:	41 83 c6 04          	add    $0x4,%r14d
    1930:	44 89 76 08          	mov    %r14d,0x8(%rsi)
    1934:	89 4e 0c             	mov    %ecx,0xc(%rsi)
    1937:	48 c7 46 10 ff ff 00 	movq   $0xffff,0x10(%rsi)
    193e:	00 
    193f:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    1946:	ff ff ff 
    1949:	48 8d 4d 02          	lea    0x2(%rbp),%rcx
    194d:	48 89 4e 18          	mov    %rcx,0x18(%rsi)
    1951:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
    1956:	4c 89 bb 90 00 00 00 	mov    %r15,0x90(%rbx)
    195d:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    1964:	00 00 00 
    1967:	48 89 4e 20          	mov    %rcx,0x20(%rsi)
    196b:	48 89 6e 28          	mov    %rbp,0x28(%rsi)
    196f:	48 b9 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rcx
    1976:	00 80 3f 
    1979:	48 89 4e 38          	mov    %rcx,0x38(%rsi)
    197d:	48 89 4e 40          	mov    %rcx,0x40(%rsi)
    1981:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1988:	00 00 00 
    198b:	49 8d 8d b1 e5 0b 00 	lea    0xbe5b1(%r13),%rcx
    1992:	48 89 8b 80 00 00 00 	mov    %rcx,0x80(%rbx)
    1999:	49 bc ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r12
    19a0:	ff 7f ff 
    19a3:	4c 89 a3 88 00 00 00 	mov    %r12,0x88(%rbx)
    19aa:	48 8b 93 c0 00 00 00 	mov    0xc0(%rbx),%rdx
    19b1:	4c 89 ba a4 00 00 00 	mov    %r15,0xa4(%rdx)
    19b8:	4c 8b 73 58          	mov    0x58(%rbx),%r14
    19bc:	4c 89 76 78          	mov    %r14,0x78(%rsi)
    19c0:	4c 89 a6 80 00 00 00 	mov    %r12,0x80(%rsi)
    19c7:	4c 89 a6 98 00 00 00 	mov    %r12,0x98(%rsi)
    19ce:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    19d3:	4c 89 8e 88 00 00 00 	mov    %r9,0x88(%rsi)
    19da:	4c 89 b6 90 00 00 00 	mov    %r14,0x90(%rsi)
    19e1:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    19e5:	44 89 96 a0 00 00 00 	mov    %r10d,0xa0(%rsi)
    19ec:	c7 86 bc 00 00 00 00 	movl   $0x0,0xbc(%rsi)
    19f3:	00 00 00 
    19f6:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    19fa:	c5 f8 11 46 58       	vmovups %xmm0,0x58(%rsi)
    19ff:	48 c7 46 68 00 00 00 	movq   $0x0,0x68(%rsi)
    1a06:	00 
    1a07:	48 89 4e 70          	mov    %rcx,0x70(%rsi)
    1a0b:	41 8b 84 3b d8 03 00 	mov    0x3d8(%r11,%rdi,1),%eax
    1a12:	00 
    1a13:	89 c1                	mov    %eax,%ecx
    1a15:	c1 f9 1f             	sar    $0x1f,%ecx
    1a18:	c4 e2 70 f2 c8       	andn   %eax,%ecx,%ecx
    1a1d:	85 c0                	test   %eax,%eax
    1a1f:	41 0f 49 c0          	cmovns %r8d,%eax
    1a23:	c5 82 2a c0          	vcvtsi2ss %eax,%xmm15,%xmm0
    1a27:	41 8b 84 3b f8 03 00 	mov    0x3f8(%r11,%rdi,1),%eax
    1a2e:	00 
    1a2f:	41 89 c1             	mov    %eax,%r9d
    1a32:	41 c1 f9 1f          	sar    $0x1f,%r9d
    1a36:	c4 62 30 f2 c8       	andn   %eax,%r9d,%r9d
    1a3b:	85 c0                	test   %eax,%eax
    1a3d:	c4 c1 02 2a c9       	vcvtsi2ss %r9d,%xmm15,%xmm1
    1a42:	41 0f 49 c0          	cmovns %r8d,%eax
    1a46:	c5 82 2a d1          	vcvtsi2ss %ecx,%xmm15,%xmm2
    1a4a:	c5 fa 11 96 80 00 00 	vmovss %xmm2,0x80(%rsi)
    1a51:	00 
    1a52:	c5 fa 11 8e 84 00 00 	vmovss %xmm1,0x84(%rsi)
    1a59:	00 
    1a5a:	c5 82 2a c8          	vcvtsi2ss %eax,%xmm15,%xmm1
    1a5e:	c5 fa 11 46 78       	vmovss %xmm0,0x78(%rsi)
    1a63:	c5 fa 11 4e 7c       	vmovss %xmm1,0x7c(%rsi)
    1a68:	41 8b 8c 3b d8 03 00 	mov    0x3d8(%r11,%rdi,1),%ecx
    1a6f:	00 
    1a70:	41 8b 84 3b f8 03 00 	mov    0x3f8(%r11,%rdi,1),%eax
    1a77:	00 
    1a78:	48 89 43 60          	mov    %rax,0x60(%rbx)
    1a7c:	44 8b 4b 40          	mov    0x40(%rbx),%r9d
    1a80:	44 89 8e a0 00 00 00 	mov    %r9d,0xa0(%rsi)
    1a87:	41 89 c9             	mov    %ecx,%r9d
    1a8a:	41 c1 f9 1f          	sar    $0x1f,%r9d
    1a8e:	c4 62 30 f2 c9       	andn   %ecx,%r9d,%r9d
    1a93:	85 c9                	test   %ecx,%ecx
    1a95:	41 0f 49 c8          	cmovns %r8d,%ecx
    1a99:	c5 82 2a c1          	vcvtsi2ss %ecx,%xmm15,%xmm0
    1a9d:	4c 89 ba a4 00 00 00 	mov    %r15,0xa4(%rdx)
    1aa4:	85 c0                	test   %eax,%eax
    1aa6:	44 0f 4f c0          	cmovg  %eax,%r8d
    1aaa:	c4 c1 02 2a c9       	vcvtsi2ss %r9d,%xmm15,%xmm1
    1aaf:	c4 e3 79 17 c1 00    	vextractps $0x0,%xmm0,%ecx
    1ab5:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    1ab9:	48 89 8b 10 02 00 00 	mov    %rcx,0x210(%rbx)
    1ac0:	c4 e3 79 17 c9 00    	vextractps $0x0,%xmm1,%ecx
    1ac6:	48 89 8b 00 02 00 00 	mov    %rcx,0x200(%rbx)
    1acd:	c4 c1 02 2a d0       	vcvtsi2ss %r8d,%xmm15,%xmm2
    1ad2:	89 c1                	mov    %eax,%ecx
    1ad4:	c1 f9 1f             	sar    $0x1f,%ecx
    1ad7:	21 c1                	and    %eax,%ecx
    1ad9:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    1ae0:	00 00 00 00 
    1ae4:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    1aeb:	00 00 00 00 
    1aef:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    1af3:	c5 82 2a d9          	vcvtsi2ss %ecx,%xmm15,%xmm3
    1af7:	c4 e3 79 17 d8 00    	vextractps $0x0,%xmm3,%eax
    1afd:	48 89 83 30 02 00 00 	mov    %rax,0x230(%rbx)
    1b04:	c4 e3 79 17 d0 00    	vextractps $0x0,%xmm2,%eax
    1b0a:	48 89 83 20 02 00 00 	mov    %rax,0x220(%rbx)
    1b11:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    1b18:	00 00 00 00 
    1b1c:	48 c7 83 28 02 00 00 	movq   $0x0,0x228(%rbx)
    1b23:	00 00 00 00 
    1b27:	c5 fa 11 8e 98 00 00 	vmovss %xmm1,0x98(%rsi)
    1b2e:	00 
    1b2f:	c5 fa 11 96 9c 00 00 	vmovss %xmm2,0x9c(%rsi)
    1b36:	00 
    1b37:	c5 fa 11 86 90 00 00 	vmovss %xmm0,0x90(%rsi)
    1b3e:	00 
    1b3f:	c5 fa 11 9e 94 00 00 	vmovss %xmm3,0x94(%rsi)
    1b46:	00 
    1b47:	31 c0                	xor    %eax,%eax
    1b49:	41 80 bc 3b 58 04 00 	cmpb   $0x0,0x458(%r11,%rdi,1)
    1b50:	00 00 
    1b52:	48 c7 43 50 5b 00 00 	movq   $0x5b,0x50(%rbx)
    1b59:	00 
    1b5a:	48 c7 86 b0 00 00 00 	movq   $0x0,0xb0(%rsi)
    1b61:	00 00 00 00 
    1b65:	c7 86 bc 00 00 00 01 	movl   $0x1,0xbc(%rsi)
    1b6c:	00 00 00 
    1b6f:	0f 94 c0             	sete   %al
    1b72:	48 8d 0c 45 59 00 00 	lea    0x59(,%rax,2),%rcx
    1b79:	00 
    1b7a:	c1 e0 1e             	shl    $0x1e,%eax
    1b7d:	48 0d 00 00 00 20    	or     $0x20000000,%rax
    1b83:	48 89 83 10 01 00 00 	mov    %rax,0x110(%rbx)
    1b8a:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    1b8e:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    1b95:	e9 38 10 00 00       	jmp    2bd2 <f_8001161d0+0x2bd2>
    1b9a:	48 89 b3 08 01 00 00 	mov    %rsi,0x108(%rbx)
    1ba1:	48 89 df             	mov    %rbx,%rdi
    1ba4:	48 83 c4 18          	add    $0x18,%rsp
    1ba8:	5b                   	pop    %rbx
    1ba9:	41 5c                	pop    %r12
    1bab:	41 5d                	pop    %r13
    1bad:	41 5e                	pop    %r14
    1baf:	41 5f                	pop    %r15
    1bb1:	5d                   	pop    %rbp
    1bb2:	c5 f8 77             	vzeroupper
    1bb5:	e9 00 00 00 00       	jmp    1bba <f_8001161d0+0x1bba>
    1bba:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    1bc1:	00 
    1bc2:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1bc9:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    1bd0:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    1bd4:	48 89 43 10          	mov    %rax,0x10(%rbx)
    1bd8:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1bdd:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    1be4:	48 89 03             	mov    %rax,(%rbx)
    1be7:	48 c7 43 18 00 00 00 	movq   $0x0,0x18(%rbx)
    1bee:	00 
    1bef:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1bf6:	00 00 00 
    1bf9:	49 8d 85 ae 18 51 fd 	lea    -0x2aee752(%r13),%rax
    1c00:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    1c07:	48 89 df             	mov    %rbx,%rdi
    1c0a:	c5 f8 77             	vzeroupper
    1c0d:	e8 00 00 00 00       	call   1c12 <f_8001161d0+0x1c12>
    1c12:	e9 c1 0f 00 00       	jmp    2bd8 <f_8001161d0+0x2bd8>
    1c17:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    1c1e:	00 
    1c1f:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1c26:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    1c2d:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    1c31:	48 89 43 10          	mov    %rax,0x10(%rbx)
    1c35:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    1c3a:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    1c41:	48 89 03             	mov    %rax,(%rbx)
    1c44:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1c4b:	00 00 00 
    1c4e:	49 8d 85 ce 18 51 fd 	lea    -0x2aee732(%r13),%rax
    1c55:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    1c5c:	48 89 df             	mov    %rbx,%rdi
    1c5f:	c5 f8 77             	vzeroupper
    1c62:	e8 00 00 00 00       	call   1c67 <f_8001161d0+0x1c67>
    1c67:	e9 6c 0f 00 00       	jmp    2bd8 <f_8001161d0+0x2bd8>
    1c6c:	48 8b 8b a0 00 00 00 	mov    0xa0(%rbx),%rcx
    1c73:	48 8b 91 c8 1e 00 00 	mov    0x1ec8(%rcx),%rdx
    1c7a:	48 89 53 70          	mov    %rdx,0x70(%rbx)
    1c7e:	48 be 00 00 00 00 01 	movabs $0x100000000,%rsi
    1c85:	00 00 00 
    1c88:	48 89 33             	mov    %rsi,(%rbx)
    1c8b:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    1c8f:	4c 8b 83 00 01 00 00 	mov    0x100(%rbx),%r8
    1c96:	49 c7 00 04 00 00 00 	movq   $0x4,(%r8)
    1c9d:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    1ca4:	00 40 00 
    1ca7:	48 ff c1             	inc    %rcx
    1caa:	49 89 48 08          	mov    %rcx,0x8(%r8)
    1cae:	49 89 70 20          	mov    %rsi,0x20(%r8)
    1cb2:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    1cb9:	ff ff ff 
    1cbc:	49 89 68 28          	mov    %rbp,0x28(%r8)
    1cc0:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1cc7:	00 00 00 
    1cca:	49 8d 8d 25 74 0d 00 	lea    0xd7425(%r13),%rcx
    1cd1:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
    1cd5:	49 bb ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r11
    1cdc:	ff 7f ff 
    1cdf:	4d 89 98 80 00 00 00 	mov    %r11,0x80(%r8)
    1ce6:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
    1ceb:	49 89 b0 88 00 00 00 	mov    %rsi,0x88(%r8)
    1cf2:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    1cf9:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    1cfe:	48 89 be a4 00 00 00 	mov    %rdi,0xa4(%rsi)
    1d05:	48 bf ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rdi
    1d0c:	ff 7f 7f 
    1d0f:	49 89 b8 90 00 00 00 	mov    %rdi,0x90(%r8)
    1d16:	4d 89 98 98 00 00 00 	mov    %r11,0x98(%r8)
    1d1d:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 1d25 <f_8001161d0+0x1d25>
    1d24:	00 
    1d25:	c5 fc 11 43 78       	vmovups %ymm0,0x78(%rbx)
    1d2a:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    1d31:	00 
    1d32:	45 89 90 a0 00 00 00 	mov    %r10d,0xa0(%r8)
    1d39:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    1d40:	0f b6 70 08          	movzbl 0x8(%rax),%esi
    1d44:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    1d48:	41 c7 80 bc 00 00 00 	movl   $0x3,0xbc(%r8)
    1d4f:	03 00 00 00 
    1d53:	49 c7 40 10 ff ff 00 	movq   $0xffff,0x10(%r8)
    1d5a:	00 
    1d5b:	48 8d 45 17          	lea    0x17(%rbp),%rax
    1d5f:	49 89 40 18          	mov    %rax,0x18(%r8)
    1d63:	49 c7 40 68 00 00 00 	movq   $0x0,0x68(%r8)
    1d6a:	00 
    1d6b:	4d 89 60 30          	mov    %r12,0x30(%r8)
    1d6f:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    1d76:	00 80 3f 
    1d79:	49 89 40 38          	mov    %rax,0x38(%r8)
    1d7d:	49 89 40 40          	mov    %rax,0x40(%r8)
    1d81:	49 c7 40 48 00 00 00 	movq   $0x0,0x48(%r8)
    1d88:	00 
    1d89:	48 8b 04 24          	mov    (%rsp),%rax
    1d8d:	49 89 40 50          	mov    %rax,0x50(%r8)
    1d91:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    1d95:	c4 c1 78 11 40 58    	vmovups %xmm0,0x58(%r8)
    1d9b:	49 89 48 70          	mov    %rcx,0x70(%r8)
    1d9f:	49 89 78 78          	mov    %rdi,0x78(%r8)
    1da3:	48 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%rax
    1daa:	45 31 c0             	xor    %r8d,%r8d
    1dad:	39 72 08             	cmp    %esi,0x8(%rdx)
    1db0:	49 0f 46 c0          	cmovbe %r8,%rax
    1db4:	48 8b 4a 10          	mov    0x10(%rdx),%rcx
    1db8:	48 8b 94 08 68 33 00 	mov    0x3368(%rax,%rcx,1),%rdx
    1dbf:	00 
    1dc0:	48 89 53 60          	mov    %rdx,0x60(%rbx)
    1dc4:	48 8b 84 08 60 33 00 	mov    0x3360(%rax,%rcx,1),%rax
    1dcb:	00 
    1dcc:	48 8b 4b 48          	mov    0x48(%rbx),%rcx
    1dd0:	48 89 01             	mov    %rax,(%rcx)
    1dd3:	48 89 51 08          	mov    %rdx,0x8(%rcx)
    1dd7:	48 8b 43 70          	mov    0x70(%rbx),%rax
    1ddb:	44 8b 48 08          	mov    0x8(%rax),%r9d
    1ddf:	48 8b 48 10          	mov    0x10(%rax),%rcx
    1de3:	48 89 4b 58          	mov    %rcx,0x58(%rbx)
    1de7:	8b 53 40             	mov    0x40(%rbx),%edx
    1dea:	48 69 d2 e0 3c 00 00 	imul   $0x3ce0,%rdx,%rdx
    1df1:	45 31 d2             	xor    %r10d,%r10d
    1df4:	31 ff                	xor    %edi,%edi
    1df6:	45 89 cb             	mov    %r9d,%r11d
    1df9:	41 29 f3             	sub    %esi,%r11d
    1dfc:	49 0f 46 d0          	cmovbe %r8,%rdx
    1e00:	41 0f 94 c2          	sete   %r10b
    1e04:	40 0f 93 c7          	setae  %dil
    1e08:	41 c1 e2 1e          	shl    $0x1e,%r10d
    1e0c:	c1 e7 1d             	shl    $0x1d,%edi
    1e0f:	44 09 d7             	or     %r10d,%edi
    1e12:	c4 c2 20 f2 f1       	andn   %r9d,%r11d,%esi
    1e17:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    1e1e:	44 09 df             	or     %r11d,%edi
    1e21:	c1 ee 03             	shr    $0x3,%esi
    1e24:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    1e2a:	09 fe                	or     %edi,%esi
    1e2c:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    1e33:	48 8b b4 0a e8 35 00 	mov    0x35e8(%rdx,%rcx,1),%rsi
    1e3a:	00 
    1e3b:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    1e3f:	48 8b bc 0a e0 35 00 	mov    0x35e0(%rdx,%rcx,1),%rdi
    1e46:	00 
    1e47:	48 89 7b 50          	mov    %rdi,0x50(%rbx)
    1e4b:	4c 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%r8
    1e52:	49 89 38             	mov    %rdi,(%r8)
    1e55:	49 89 70 08          	mov    %rsi,0x8(%r8)
    1e59:	8b b4 0a f8 35 00 00 	mov    0x35f8(%rdx,%rcx,1),%esi
    1e60:	48 8b 8c 0a f0 35 00 	mov    0x35f0(%rdx,%rcx,1),%rcx
    1e67:	00 
    1e68:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
    1e6f:	48 89 0a             	mov    %rcx,(%rdx)
    1e72:	89 72 08             	mov    %esi,0x8(%rdx)
    1e75:	8b 48 44             	mov    0x44(%rax),%ecx
    1e78:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    1e7c:	48 83 c0 3c          	add    $0x3c,%rax
    1e80:	8b 00                	mov    (%rax),%eax
    1e82:	48 89 43 48          	mov    %rax,0x48(%rbx)
    1e86:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    1e8d:	88 8a b0 00 00 00    	mov    %cl,0xb0(%rdx)
    1e93:	c7 82 b4 00 00 00 00 	movl   $0x0,0xb4(%rdx)
    1e9a:	00 00 00 
    1e9d:	48 8b 8b c0 00 00 00 	mov    0xc0(%rbx),%rcx
    1ea4:	c7 81 b1 00 00 00 00 	movl   $0x0,0xb1(%rcx)
    1eab:	00 00 00 
    1eae:	88 82 b8 00 00 00    	mov    %al,0xb8(%rdx)
    1eb4:	e9 1f 0d 00 00       	jmp    2bd8 <f_8001161d0+0x2bd8>
    1eb9:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    1ec0:	00 
    1ec1:	48 c7 80 d0 fe ff ff 	movq   $0x100,-0x130(%rax)
    1ec8:	00 01 00 00 
    1ecc:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    1ed3:	00 40 00 
    1ed6:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    1edd:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    1ee4:	ff ff 00 00 
    1ee8:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    1eef:	ff ff ff 
    1ef2:	48 8d 4a 13          	lea    0x13(%rdx),%rcx
    1ef6:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    1efd:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    1f04:	00 00 00 
    1f07:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
    1f0b:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    1f12:	48 89 90 f8 fe ff ff 	mov    %rdx,-0x108(%rax)
    1f19:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
    1f20:	00 80 3f 
    1f23:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
    1f27:	48 8d 90 00 ff ff ff 	lea    -0x100(%rax),%rdx
    1f2e:	48 8d b0 08 ff ff ff 	lea    -0xf8(%rax),%rsi
    1f35:	48 b9 ca 5d c0 02 08 	movabs $0x802c05dca,%rcx
    1f3c:	00 00 00 
    1f3f:	4c 8d 81 a1 6f fe ff 	lea    -0x1905f(%rcx),%r8
    1f46:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    1f4c:	e9 b6 0a 00 00       	jmp    2a07 <f_8001161d0+0x2a07>
    1f51:	48 c7 43 68 00 10 00 	movq   $0x1000,0x68(%rbx)
    1f58:	00 
    1f59:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    1f60:	00 
    1f61:	48 c7 80 d0 fe ff ff 	movq   $0x1000,-0x130(%rax)
    1f68:	00 10 00 00 
    1f6c:	48 c7 80 d8 fe ff ff 	movq   $0x1,-0x128(%rax)
    1f73:	01 00 00 00 
    1f77:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    1f7e:	ff ff 00 00 
    1f82:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    1f89:	ff ff ff 
    1f8c:	48 8d 4d 0c          	lea    0xc(%rbp),%rcx
    1f90:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    1f97:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    1f9e:	00 00 00 
    1fa1:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    1fa8:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
    1faf:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
    1fb6:	00 80 3f 
    1fb9:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
    1fbd:	4c 89 a0 00 ff ff ff 	mov    %r12,-0x100(%rax)
    1fc4:	48 89 b8 08 ff ff ff 	mov    %rdi,-0xf8(%rax)
    1fcb:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    1fd2:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    1fd9:	00 00 00 
    1fdc:	49 8d b5 b2 a4 03 00 	lea    0x3a4b2(%r13),%rsi
    1fe3:	44 89 92 a0 00 00 00 	mov    %r10d,0xa0(%rdx)
    1fea:	4c 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%r8
    1ff1:	4d 8b 90 d0 2f 00 00 	mov    0x2fd0(%r8),%r10
    1ff8:	4c 89 53 40          	mov    %r10,0x40(%rbx)
    1ffc:	4c 8b 4c 24 10       	mov    0x10(%rsp),%r9
    2001:	4c 89 4b 60          	mov    %r9,0x60(%rbx)
    2005:	48 89 72 70          	mov    %rsi,0x70(%rdx)
    2009:	49 be ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r14
    2010:	ff 7f 7f 
    2013:	4c 89 72 78          	mov    %r14,0x78(%rdx)
    2017:	49 bb ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r11
    201e:	ff 7f ff 
    2021:	4c 89 5b 68          	mov    %r11,0x68(%rbx)
    2025:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2029:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2030:	00 
    2031:	c7 82 bc 00 00 00 00 	movl   $0x0,0xbc(%rdx)
    2038:	00 00 00 
    203b:	4c 89 9a 80 00 00 00 	mov    %r11,0x80(%rdx)
    2042:	4c 89 8a 88 00 00 00 	mov    %r9,0x88(%rdx)
    2049:	48 8b 8b c0 00 00 00 	mov    0xc0(%rbx),%rcx
    2050:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
    2055:	48 89 b1 a4 00 00 00 	mov    %rsi,0xa4(%rcx)
    205c:	48 89 7a 40          	mov    %rdi,0x40(%rdx)
    2060:	48 c7 42 48 00 00 00 	movq   $0x0,0x48(%rdx)
    2067:	00 
    2068:	4c 89 b2 90 00 00 00 	mov    %r14,0x90(%rdx)
    206f:	4c 89 9a 98 00 00 00 	mov    %r11,0x98(%rdx)
    2076:	48 c7 42 68 00 00 00 	movq   $0x0,0x68(%rdx)
    207d:	00 
    207e:	48 8b 0c 24          	mov    (%rsp),%rcx
    2082:	48 89 4a 50          	mov    %rcx,0x50(%rdx)
    2086:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    208a:	c5 f8 11 42 58       	vmovups %xmm0,0x58(%rdx)
    208f:	4d 85 d2             	test   %r10,%r10
    2092:	0f 84 f7 13 00 00    	je     348f <f_8001161d0+0x348f>
    2098:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    209f:	0f b6 71 08          	movzbl 0x8(%rcx),%esi
    20a3:	48 c7 43 68 e0 3c 00 	movq   $0x3ce0,0x68(%rbx)
    20aa:	00 
    20ab:	48 69 fe 60 0f 00 00 	imul   $0xf60,%rsi,%rdi
    20b2:	31 c9                	xor    %ecx,%ecx
    20b4:	41 39 72 10          	cmp    %esi,0x10(%r10)
    20b8:	48 0f 46 f9          	cmovbe %rcx,%rdi
    20bc:	4d 8b 4a 18          	mov    0x18(%r10),%r9
    20c0:	41 8b bc 39 9c 02 00 	mov    0x29c(%r9,%rdi,1),%edi
    20c7:	00 
    20c8:	49 b9 00 00 00 00 01 	movabs $0x100000000,%r9
    20cf:	00 00 00 
    20d2:	4c 09 cf             	or     %r9,%rdi
    20d5:	48 89 7a 1c          	mov    %rdi,0x1c(%rdx)
    20d9:	c7 82 bc 00 00 00 02 	movl   $0x2,0xbc(%rdx)
    20e0:	00 00 00 
    20e3:	49 8b 90 c8 1e 00 00 	mov    0x1ec8(%r8),%rdx
    20ea:	44 8b 4a 08          	mov    0x8(%rdx),%r9d
    20ee:	4c 8b 42 10          	mov    0x10(%rdx),%r8
    20f2:	48 69 fe e0 3c 00 00 	imul   $0x3ce0,%rsi,%rdi
    20f9:	45 31 d2             	xor    %r10d,%r10d
    20fc:	45 31 db             	xor    %r11d,%r11d
    20ff:	44 89 cd             	mov    %r9d,%ebp
    2102:	29 f5                	sub    %esi,%ebp
    2104:	41 be 00 00 00 00    	mov    $0x0,%r14d
    210a:	4c 0f 47 f7          	cmova  %rdi,%r14
    210e:	41 0f 94 c2          	sete   %r10b
    2112:	41 0f 93 c3          	setae  %r11b
    2116:	c4 42 50 f2 c9       	andn   %r9d,%ebp,%r9d
    211b:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    2121:	41 c1 e2 1e          	shl    $0x1e,%r10d
    2125:	41 c1 e3 1d          	shl    $0x1d,%r11d
    2129:	45 09 d3             	or     %r10d,%r11d
    212c:	41 09 eb             	or     %ebp,%r11d
    212f:	41 c1 e9 03          	shr    $0x3,%r9d
    2133:	41 81 e1 00 00 00 10 	and    $0x10000000,%r9d
    213a:	45 09 d9             	or     %r11d,%r9d
    213d:	4c 89 8b 10 01 00 00 	mov    %r9,0x110(%rbx)
    2144:	4f 8b 8c 30 b8 30 00 	mov    0x30b8(%r8,%r14,1),%r9
    214b:	00 
    214c:	4c 89 4b 60          	mov    %r9,0x60(%rbx)
    2150:	4f 8b 84 30 b0 30 00 	mov    0x30b0(%r8,%r14,1),%r8
    2157:	00 
    2158:	4c 89 43 58          	mov    %r8,0x58(%rbx)
    215c:	4c 89 80 48 ff ff ff 	mov    %r8,-0xb8(%rax)
    2163:	4c 89 88 50 ff ff ff 	mov    %r9,-0xb0(%rax)
    216a:	39 72 08             	cmp    %esi,0x8(%rdx)
    216d:	48 8b 52 10          	mov    0x10(%rdx),%rdx
    2171:	48 0f 47 cf          	cmova  %rdi,%rcx
    2175:	48 8d 34 11          	lea    (%rcx,%rdx,1),%rsi
    2179:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    217d:	48 8b b4 11 30 33 00 	mov    0x3330(%rcx,%rdx,1),%rsi
    2184:	00 
    2185:	48 8b bc 11 38 33 00 	mov    0x3338(%rcx,%rdx,1),%rdi
    218c:	00 
    218d:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    2191:	48 89 b0 60 ff ff ff 	mov    %rsi,-0xa0(%rax)
    2198:	48 89 b8 68 ff ff ff 	mov    %rdi,-0x98(%rax)
    219f:	8b b4 11 48 33 00 00 	mov    0x3348(%rcx,%rdx,1),%esi
    21a6:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    21aa:	48 8b 8c 11 40 33 00 	mov    0x3340(%rcx,%rdx,1),%rcx
    21b1:	00 
    21b2:	48 89 88 70 ff ff ff 	mov    %rcx,-0x90(%rax)
    21b9:	89 b0 78 ff ff ff    	mov    %esi,-0x88(%rax)
    21bf:	e9 14 0a 00 00       	jmp    2bd8 <f_8001161d0+0x2bd8>
    21c4:	49 8b 96 c8 1e 00 00 	mov    0x1ec8(%r14),%rdx
    21cb:	48 89 53 08          	mov    %rdx,0x8(%rbx)
    21cf:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    21d4:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
    21d8:	41 0f b6 73 08       	movzbl 0x8(%r11),%esi
    21dd:	48 89 73 68          	mov    %rsi,0x68(%rbx)
    21e1:	8b 4a 08             	mov    0x8(%rdx),%ecx
    21e4:	4c 8b 72 10          	mov    0x10(%rdx),%r14
    21e8:	4c 69 c6 e0 3c 00 00 	imul   $0x3ce0,%rsi,%r8
    21ef:	45 31 db             	xor    %r11d,%r11d
    21f2:	39 f1                	cmp    %esi,%ecx
    21f4:	b9 00 00 00 00       	mov    $0x0,%ecx
    21f9:	49 0f 47 c8          	cmova  %r8,%rcx
    21fd:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
    2204:	00 
    2205:	4a 8b 8c 31 40 3c 00 	mov    0x3c40(%rcx,%r14,1),%rcx
    220c:	00 
    220d:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
    2214:	44 89 90 70 ff ff ff 	mov    %r10d,-0x90(%rax)
    221b:	48 89 b8 58 ff ff ff 	mov    %rdi,-0xa8(%rax)
    2222:	49 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r9
    2229:	ff 7f 7f 
    222c:	4c 89 88 60 ff ff ff 	mov    %r9,-0xa0(%rax)
    2233:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    223a:	00 
    223b:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    223f:	c7 40 8c 00 00 00 00 	movl   $0x0,-0x74(%rax)
    2246:	48 c7 80 18 ff ff ff 	movq   $0x0,-0xe8(%rax)
    224d:	00 00 00 00 
    2251:	48 8b 0c 24          	mov    (%rsp),%rcx
    2255:	48 89 88 20 ff ff ff 	mov    %rcx,-0xe0(%rax)
    225c:	48 c7 43 40 06 00 00 	movq   $0x6,0x40(%rbx)
    2263:	00 
    2264:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2268:	c5 f8 11 80 28 ff ff 	vmovups %xmm0,-0xd8(%rax)
    226f:	ff 
    2270:	48 c7 80 00 ff ff ff 	movq   $0x6,-0x100(%rax)
    2277:	06 00 00 00 
    227b:	48 b9 10 00 00 00 03 	movabs $0x300000010,%rcx
    2282:	00 00 00 
    2285:	48 83 c1 10          	add    $0x10,%rcx
    2289:	48 89 88 d0 fe ff ff 	mov    %rcx,-0x130(%rax)
    2290:	48 b9 00 00 00 00 01 	movabs $0x40000100000000,%rcx
    2297:	00 40 00 
    229a:	48 89 88 d8 fe ff ff 	mov    %rcx,-0x128(%rax)
    22a1:	48 c7 80 e0 fe ff ff 	movq   $0xffff,-0x120(%rax)
    22a8:	ff ff 00 00 
    22ac:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    22b3:	ff ff ff 
    22b6:	48 8d 4d 09          	lea    0x9(%rbp),%rcx
    22ba:	48 89 88 e8 fe ff ff 	mov    %rcx,-0x118(%rax)
    22c1:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    22c8:	00 00 00 
    22cb:	48 89 88 f0 fe ff ff 	mov    %rcx,-0x110(%rax)
    22d2:	48 89 a8 f8 fe ff ff 	mov    %rbp,-0x108(%rax)
    22d9:	48 8b 8b c0 00 00 00 	mov    0xc0(%rbx),%rcx
    22e0:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
    22e5:	48 89 b9 a4 00 00 00 	mov    %rdi,0xa4(%rcx)
    22ec:	48 b9 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rcx
    22f3:	00 80 3f 
    22f6:	48 89 88 08 ff ff ff 	mov    %rcx,-0xf8(%rax)
    22fd:	48 89 88 10 ff ff ff 	mov    %rcx,-0xf0(%rax)
    2304:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    230b:	00 00 00 
    230e:	49 8d 8d af c7 07 00 	lea    0x7c7af(%r13),%rcx
    2315:	48 89 4b 78          	mov    %rcx,0x78(%rbx)
    2319:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    2320:	ff 7f ff 
    2323:	48 89 bb 80 00 00 00 	mov    %rdi,0x80(%rbx)
    232a:	48 89 b8 68 ff ff ff 	mov    %rdi,-0x98(%rax)
    2331:	4c 89 88 48 ff ff ff 	mov    %r9,-0xb8(%rax)
    2338:	48 89 b8 50 ff ff ff 	mov    %rdi,-0xb0(%rax)
    233f:	48 c7 80 38 ff ff ff 	movq   $0x0,-0xc8(%rax)
    2346:	00 00 00 00 
    234a:	48 89 88 40 ff ff ff 	mov    %rcx,-0xc0(%rax)
    2351:	8b 4a 08             	mov    0x8(%rdx),%ecx
    2354:	31 ff                	xor    %edi,%edi
    2356:	45 31 c9             	xor    %r9d,%r9d
    2359:	41 89 ca             	mov    %ecx,%r10d
    235c:	41 29 f2             	sub    %esi,%r10d
    235f:	40 0f 94 c7          	sete   %dil
    2363:	41 0f 93 c1          	setae  %r9b
    2367:	41 be 00 00 00 00    	mov    $0x0,%r14d
    236d:	4d 0f 47 f0          	cmova  %r8,%r14
    2371:	c1 e7 1e             	shl    $0x1e,%edi
    2374:	41 c1 e1 1d          	shl    $0x1d,%r9d
    2378:	41 09 f9             	or     %edi,%r9d
    237b:	c4 e2 28 f2 c9       	andn   %ecx,%r10d,%ecx
    2380:	41 81 e2 00 00 00 80 	and    $0x80000000,%r10d
    2387:	45 09 d1             	or     %r10d,%r9d
    238a:	c1 e9 03             	shr    $0x3,%ecx
    238d:	81 e1 00 00 00 10    	and    $0x10000000,%ecx
    2393:	44 09 c9             	or     %r9d,%ecx
    2396:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    239a:	48 89 8b 10 01 00 00 	mov    %rcx,0x110(%rbx)
    23a1:	c4 a1 78 10 84 37 00 	vmovups 0x2e00(%rdi,%r14,1),%xmm0
    23a8:	2e 00 00 
    23ab:	c5 f8 11 80 48 ff ff 	vmovups %xmm0,-0xb8(%rax)
    23b2:	ff 
    23b3:	39 72 08             	cmp    %esi,0x8(%rdx)
    23b6:	4d 0f 47 d8          	cmova  %r8,%r11
    23ba:	4c 03 5a 10          	add    0x10(%rdx),%r11
    23be:	49 8b 83 80 30 00 00 	mov    0x3080(%r11),%rax
    23c5:	48 8b 8b b0 00 00 00 	mov    0xb0(%rbx),%rcx
    23cc:	48 8b 93 d0 00 00 00 	mov    0xd0(%rbx),%rdx
    23d3:	48 89 0b             	mov    %rcx,(%rbx)
    23d6:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
    23dd:	00 
    23de:	49 8b 8b 88 30 00 00 	mov    0x3088(%r11),%rcx
    23e5:	48 89 4b 50          	mov    %rcx,0x50(%rbx)
    23e9:	48 89 02             	mov    %rax,(%rdx)
    23ec:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
    23f0:	49 8b 83 90 30 00 00 	mov    0x3090(%r11),%rax
    23f7:	48 89 43 48          	mov    %rax,0x48(%rbx)
    23fb:	41 8b 8b 98 30 00 00 	mov    0x3098(%r11),%ecx
    2402:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
    2409:	89 4a 08             	mov    %ecx,0x8(%rdx)
    240c:	48 8b 8b e8 00 00 00 	mov    0xe8(%rbx),%rcx
    2413:	48 83 c1 f7          	add    $0xfffffffffffffff7,%rcx
    2417:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    241b:	48 89 02             	mov    %rax,(%rdx)
    241e:	49 8d 85 ea 0b 51 fd 	lea    -0x2aef416(%r13),%rax
    2425:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    242c:	48 89 df             	mov    %rbx,%rdi
    242f:	c5 f8 77             	vzeroupper
    2432:	e8 00 00 00 00       	call   2437 <f_8001161d0+0x2437>
    2437:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    243e:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    2445:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    244c:	48 89 01             	mov    %rax,(%rcx)
    244f:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
    2456:	48 8b 93 e8 00 00 00 	mov    0xe8(%rbx),%rdx
    245d:	48 8b b0 04 16 00 00 	mov    0x1604(%rax),%rsi
    2464:	0f b6 52 ff          	movzbl -0x1(%rdx),%edx
    2468:	48 89 53 50          	mov    %rdx,0x50(%rbx)
    246c:	88 51 08             	mov    %dl,0x8(%rcx)
    246f:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    2476:	48 89 71 1c          	mov    %rsi,0x1c(%rcx)
    247a:	8b 80 0c 16 00 00    	mov    0x160c(%rax),%eax
    2480:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2484:	48 c7 43 48 02 00 00 	movq   $0x2,0x48(%rbx)
    248b:	00 
    248c:	89 41 24             	mov    %eax,0x24(%rcx)
    248f:	c7 81 bc 00 00 00 02 	movl   $0x2,0xbc(%rcx)
    2496:	00 00 00 
    2499:	e9 3a 07 00 00       	jmp    2bd8 <f_8001161d0+0x2bd8>
    249e:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    24a5:	00 
    24a6:	48 8b b3 00 01 00 00 	mov    0x100(%rbx),%rsi
    24ad:	48 c7 06 80 00 00 00 	movq   $0x80,(%rsi)
    24b4:	48 b9 00 00 00 00 00 	movabs $0x60000000000000,%rcx
    24bb:	00 60 00 
    24be:	48 89 4e 08          	mov    %rcx,0x8(%rsi)
    24c2:	48 c7 46 10 ff ff 00 	movq   $0xffff,0x10(%rsi)
    24c9:	00 
    24ca:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    24d1:	ff ff ff 
    24d4:	48 8d 4a 12          	lea    0x12(%rdx),%rcx
    24d8:	48 89 4e 18          	mov    %rcx,0x18(%rsi)
    24dc:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    24e3:	00 00 00 
    24e6:	48 89 4e 20          	mov    %rcx,0x20(%rsi)
    24ea:	48 89 56 28          	mov    %rdx,0x28(%rsi)
    24ee:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    24f2:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
    24f9:	00 80 3f 
    24fc:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
    2500:	48 8d 56 30          	lea    0x30(%rsi),%rdx
    2504:	48 83 c6 38          	add    $0x38,%rsi
    2508:	48 b9 ca 5d c0 02 08 	movabs $0x802c05dca,%rcx
    250f:	00 00 00 
    2512:	4c 8d 81 6d 4f 0a 00 	lea    0xa4f6d(%rcx),%r8
    2519:	e9 e9 04 00 00       	jmp    2a07 <f_8001161d0+0x2a07>
    251e:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    2525:	48 8b 93 a0 00 00 00 	mov    0xa0(%rbx),%rdx
    252c:	48 8b b2 c8 1e 00 00 	mov    0x1ec8(%rdx),%rsi
    2533:	48 89 73 08          	mov    %rsi,0x8(%rbx)
    2537:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
    253c:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
    2540:	48 c7 43 10 00 00 00 	movq   $0x0,0x10(%rbx)
    2547:	00 
    2548:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
    254c:	48 89 4b 68          	mov    %rcx,0x68(%rbx)
    2550:	44 8b 46 08          	mov    0x8(%rsi),%r8d
    2554:	4c 69 d9 e0 3c 00 00 	imul   $0x3ce0,%rcx,%r11
    255b:	31 d2                	xor    %edx,%edx
    255d:	41 39 c8             	cmp    %ecx,%r8d
    2560:	48 8b 4e 10          	mov    0x10(%rsi),%rcx
    2564:	48 c7 43 70 e0 3c 00 	movq   $0x3ce0,0x70(%rbx)
    256b:	00 
    256c:	4c 0f 46 da          	cmovbe %rdx,%r11
    2570:	49 8b 8c 0b 40 3c 00 	mov    0x3c40(%r11,%rcx,1),%rcx
    2577:	00 
    2578:	48 89 0b             	mov    %rcx,(%rbx)
    257b:	48 8b b3 00 01 00 00 	mov    0x100(%rbx),%rsi
    2582:	44 89 96 a0 00 00 00 	mov    %r10d,0xa0(%rsi)
    2589:	48 89 be 88 00 00 00 	mov    %rdi,0x88(%rsi)
    2590:	48 b9 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%rcx
    2597:	ff 7f 7f 
    259a:	48 89 8e 90 00 00 00 	mov    %rcx,0x90(%rsi)
    25a1:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    25a8:	00 
    25a9:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    25ad:	c7 86 bc 00 00 00 00 	movl   $0x0,0xbc(%rsi)
    25b4:	00 00 00 
    25b7:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    25bb:	c5 f8 11 46 58       	vmovups %xmm0,0x58(%rsi)
    25c0:	48 c7 06 20 00 00 00 	movq   $0x20,(%rsi)
    25c7:	48 b8 00 00 00 00 00 	movabs $0x42080000000000,%rax
    25ce:	08 42 00 
    25d1:	48 89 46 08          	mov    %rax,0x8(%rsi)
    25d5:	48 c7 46 48 00 00 00 	movq   $0x0,0x48(%rsi)
    25dc:	00 
    25dd:	48 8b 04 24          	mov    (%rsp),%rax
    25e1:	48 89 46 50          	mov    %rax,0x50(%rsi)
    25e5:	48 c7 46 30 07 00 00 	movq   $0x7,0x30(%rsi)
    25ec:	00 
    25ed:	48 c7 46 10 ff ff 00 	movq   $0xffff,0x10(%rsi)
    25f4:	00 
    25f5:	48 b9 00 00 00 00 ff 	movabs $0xffffffff00000000,%rcx
    25fc:	ff ff ff 
    25ff:	48 8d 41 0a          	lea    0xa(%rcx),%rax
    2603:	48 89 46 18          	mov    %rax,0x18(%rsi)
    2607:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    260e:	00 00 00 
    2611:	48 89 46 20          	mov    %rax,0x20(%rsi)
    2615:	48 89 4e 28          	mov    %rcx,0x28(%rsi)
    2619:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2620:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2625:	48 89 88 a4 00 00 00 	mov    %rcx,0xa4(%rax)
    262c:	48 b8 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rax
    2633:	00 80 3f 
    2636:	48 89 46 38          	mov    %rax,0x38(%rsi)
    263a:	48 89 46 40          	mov    %rax,0x40(%rsi)
    263e:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    2645:	00 00 00 
    2648:	49 8d 85 c5 e4 0b 00 	lea    0xbe4c5(%r13),%rax
    264f:	48 89 43 78          	mov    %rax,0x78(%rbx)
    2653:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    265a:	ff 7f ff 
    265d:	48 89 bb 80 00 00 00 	mov    %rdi,0x80(%rbx)
    2664:	48 89 be 98 00 00 00 	mov    %rdi,0x98(%rsi)
    266b:	48 8b 4b 58          	mov    0x58(%rbx),%rcx
    266f:	48 89 4e 78          	mov    %rcx,0x78(%rsi)
    2673:	48 89 be 80 00 00 00 	mov    %rdi,0x80(%rsi)
    267a:	48 c7 46 68 00 00 00 	movq   $0x0,0x68(%rsi)
    2681:	00 
    2682:	48 89 46 70          	mov    %rax,0x70(%rsi)
    2686:	48 8b 43 08          	mov    0x8(%rbx),%rax
    268a:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
    268e:	41 89 f8             	mov    %edi,%r8d
    2691:	39 78 08             	cmp    %edi,0x8(%rax)
    2694:	be 00 00 00 00       	mov    $0x0,%esi
    2699:	49 0f 47 f0          	cmova  %r8,%rsi
    269d:	4c 8b 4b 48          	mov    0x48(%rbx),%r9
    26a1:	4c 8b 50 10          	mov    0x10(%rax),%r10
    26a5:	8b 4b 70             	mov    0x70(%rbx),%ecx
    26a8:	48 0f af f1          	imul   %rcx,%rsi
    26ac:	c4 a1 78 10 84 16 b0 	vmovups 0x30b0(%rsi,%r10,1),%xmm0
    26b3:	30 00 00 
    26b6:	c4 c1 78 11 01       	vmovups %xmm0,(%r9)
    26bb:	8b 70 08             	mov    0x8(%rax),%esi
    26be:	45 31 c9             	xor    %r9d,%r9d
    26c1:	41 89 f2             	mov    %esi,%r10d
    26c4:	41 31 fa             	xor    %edi,%r10d
    26c7:	41 0f 94 c1          	sete   %r9b
    26cb:	45 31 db             	xor    %r11d,%r11d
    26ce:	89 f5                	mov    %esi,%ebp
    26d0:	29 fd                	sub    %edi,%ebp
    26d2:	49 0f 47 d0          	cmova  %r8,%rdx
    26d6:	41 0f 93 c3          	setae  %r11b
    26da:	31 ee                	xor    %ebp,%esi
    26dc:	44 21 d6             	and    %r10d,%esi
    26df:	41 c1 e1 1e          	shl    $0x1e,%r9d
    26e3:	41 c1 e3 1d          	shl    $0x1d,%r11d
    26e7:	45 09 cb             	or     %r9d,%r11d
    26ea:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    26f0:	41 09 eb             	or     %ebp,%r11d
    26f3:	48 8b 40 10          	mov    0x10(%rax),%rax
    26f7:	c1 ee 03             	shr    $0x3,%esi
    26fa:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    2700:	44 09 de             	or     %r11d,%esi
    2703:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    270a:	48 0f af d1          	imul   %rcx,%rdx
    270e:	48 8b 8c 02 30 33 00 	mov    0x3330(%rdx,%rax,1),%rcx
    2715:	00 
    2716:	48 8b b4 02 38 33 00 	mov    0x3338(%rdx,%rax,1),%rsi
    271d:	00 
    271e:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    2722:	48 8b bb d0 00 00 00 	mov    0xd0(%rbx),%rdi
    2729:	48 89 0f             	mov    %rcx,(%rdi)
    272c:	48 89 77 08          	mov    %rsi,0x8(%rdi)
    2730:	48 8b 8c 02 40 33 00 	mov    0x3340(%rdx,%rax,1),%rcx
    2737:	00 
    2738:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    273c:	8b 84 02 48 33 00 00 	mov    0x3348(%rdx,%rax,1),%eax
    2743:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
    274a:	89 42 08             	mov    %eax,0x8(%rdx)
    274d:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    2754:	48 83 c0 f7          	add    $0xfffffffffffffff7,%rax
    2758:	48 89 43 40          	mov    %rax,0x40(%rbx)
    275c:	48 89 0a             	mov    %rcx,(%rdx)
    275f:	49 8d 85 72 0d 51 fd 	lea    -0x2aef28e(%r13),%rax
    2766:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    276d:	48 89 df             	mov    %rbx,%rdi
    2770:	c5 f8 77             	vzeroupper
    2773:	e8 00 00 00 00       	call   2778 <f_8001161d0+0x2778>
    2778:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    277f:	48 8b 8b d8 00 00 00 	mov    0xd8(%rbx),%rcx
    2786:	48 8b 80 c7 00 00 00 	mov    0xc7(%rax),%rax
    278d:	48 89 01             	mov    %rax,(%rcx)
    2790:	48 8b 83 e8 00 00 00 	mov    0xe8(%rbx),%rax
    2797:	0f b6 40 ff          	movzbl -0x1(%rax),%eax
    279b:	48 89 43 40          	mov    %rax,0x40(%rbx)
    279f:	88 41 08             	mov    %al,0x8(%rcx)
    27a2:	ba bc 00 00 00       	mov    $0xbc,%edx
    27a7:	48 03 93 00 01 00 00 	add    0x100(%rbx),%rdx
    27ae:	e9 e3 0c 00 00       	jmp    3496 <f_8001161d0+0x3496>
    27b3:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    27b7:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    27be:	48 c7 02 01 00 00 00 	movq   $0x1,(%rdx)
    27c5:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    27cc:	00 40 00 
    27cf:	48 89 4a 08          	mov    %rcx,0x8(%rdx)
    27d3:	48 c7 42 10 ff ff 00 	movq   $0xffff,0x10(%rdx)
    27da:	00 
    27db:	48 be 00 00 00 00 ff 	movabs $0xffffffff00000000,%rsi
    27e2:	ff ff ff 
    27e5:	48 8d 4e 15          	lea    0x15(%rsi),%rcx
    27e9:	48 89 4a 18          	mov    %rcx,0x18(%rdx)
    27ed:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    27f4:	00 
    27f5:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    27fc:	00 00 00 
    27ff:	48 89 42 20          	mov    %rax,0x20(%rdx)
    2803:	48 89 72 28          	mov    %rsi,0x28(%rdx)
    2807:	4c 89 42 30          	mov    %r8,0x30(%rdx)
    280b:	48 be 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rsi
    2812:	00 80 3f 
    2815:	48 89 72 38          	mov    %rsi,0x38(%rdx)
    2819:	48 b8 ca 5d c0 02 08 	movabs $0x802c05dca,%rax
    2820:	00 00 00 
    2823:	48 8d 80 7c 4f 0a 00 	lea    0xa4f7c(%rax),%rax
    282a:	48 89 42 70          	mov    %rax,0x70(%rdx)
    282e:	49 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r8
    2835:	ff 7f 7f 
    2838:	4c 89 42 78          	mov    %r8,0x78(%rdx)
    283c:	48 bf ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rdi
    2843:	ff 7f ff 
    2846:	48 89 ba 80 00 00 00 	mov    %rdi,0x80(%rdx)
    284d:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    2852:	48 89 82 88 00 00 00 	mov    %rax,0x88(%rdx)
    2859:	c5 fc 28 05 00 00 00 	vmovaps 0x0(%rip),%ymm0        # 2861 <f_8001161d0+0x2861>
    2860:	00 
    2861:	c5 fc 11 43 60       	vmovups %ymm0,0x60(%rbx)
    2866:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    286d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2872:	48 89 88 a4 00 00 00 	mov    %rcx,0xa4(%rax)
    2879:	48 89 72 40          	mov    %rsi,0x40(%rdx)
    287d:	48 c7 42 48 00 00 00 	movq   $0x0,0x48(%rdx)
    2884:	00 
    2885:	4c 89 82 90 00 00 00 	mov    %r8,0x90(%rdx)
    288c:	48 89 ba 98 00 00 00 	mov    %rdi,0x98(%rdx)
    2893:	48 c7 42 68 00 00 00 	movq   $0x0,0x68(%rdx)
    289a:	00 
    289b:	48 8b 04 24          	mov    (%rsp),%rax
    289f:	48 89 42 50          	mov    %rax,0x50(%rdx)
    28a3:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    28a7:	c5 f8 11 42 58       	vmovups %xmm0,0x58(%rdx)
    28ac:	48 c7 43 50 03 00 00 	movq   $0x3,0x50(%rbx)
    28b3:	00 
    28b4:	b8 03 00 00 00       	mov    $0x3,%eax
    28b9:	e9 ec 01 00 00       	jmp    2aaa <f_8001161d0+0x2aaa>
    28be:	48 c7 43 40 b0 1e 00 	movq   $0x1eb0,0x40(%rbx)
    28c5:	00 
    28c6:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    28cd:	48 8b 8b 00 01 00 00 	mov    0x100(%rbx),%rcx
    28d4:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    28d8:	48 89 43 10          	mov    %rax,0x10(%rbx)
    28dc:	b8 b0 1e 00 00       	mov    $0x1eb0,%eax
    28e1:	48 03 83 a0 00 00 00 	add    0xa0(%rbx),%rax
    28e8:	48 89 03             	mov    %rax,(%rbx)
    28eb:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    28f2:	00 00 00 
    28f5:	49 8d 85 2e 0c 51 fd 	lea    -0x2aef3d2(%r13),%rax
    28fc:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    2903:	48 89 df             	mov    %rbx,%rdi
    2906:	c5 f8 77             	vzeroupper
    2909:	e8 00 00 00 00       	call   290e <f_8001161d0+0x290e>
    290e:	e9 c5 02 00 00       	jmp    2bd8 <f_8001161d0+0x2bd8>
    2913:	48 c7 43 78 ff ff 00 	movq   $0xffff,0x78(%rbx)
    291a:	00 
    291b:	48 8b b3 00 01 00 00 	mov    0x100(%rbx),%rsi
    2922:	48 c7 06 03 00 00 00 	movq   $0x3,(%rsi)
    2929:	48 b9 00 00 00 00 00 	movabs $0x40000000000000,%rcx
    2930:	00 40 00 
    2933:	48 89 4e 08          	mov    %rcx,0x8(%rsi)
    2937:	48 c7 46 10 ff ff 00 	movq   $0xffff,0x10(%rsi)
    293e:	00 
    293f:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    2946:	ff ff ff 
    2949:	48 8d 4a 0f          	lea    0xf(%rdx),%rcx
    294d:	48 89 4e 18          	mov    %rcx,0x18(%rsi)
    2951:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    2958:	00 00 00 
    295b:	48 89 4e 20          	mov    %rcx,0x20(%rsi)
    295f:	48 89 56 28          	mov    %rdx,0x28(%rsi)
    2963:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    2967:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
    296e:	00 80 3f 
    2971:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
    2975:	48 8d 56 30          	lea    0x30(%rsi),%rdx
    2979:	48 83 c6 38          	add    $0x38,%rsi
    297d:	48 b9 ca 5d c0 02 08 	movabs $0x802c05dca,%rcx
    2984:	00 00 00 
    2987:	4c 8d 81 fb b3 05 00 	lea    0x5b3fb(%rcx),%r8
    298e:	eb 77                	jmp    2a07 <f_8001161d0+0x2a07>
    2990:	48 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%rdx
    2997:	ff ff ff 
    299a:	48 8d 4a 0e          	lea    0xe(%rdx),%rcx
    299e:	48 89 4b 78          	mov    %rcx,0x78(%rbx)
    29a2:	48 8b b3 00 01 00 00 	mov    0x100(%rbx),%rsi
    29a9:	48 c7 06 00 04 00 00 	movq   $0x400,(%rsi)
    29b0:	48 c7 46 08 00 00 00 	movq   $0x0,0x8(%rsi)
    29b7:	00 
    29b8:	48 c7 46 10 ff ff 00 	movq   $0xffff,0x10(%rsi)
    29bf:	00 
    29c0:	48 89 4e 18          	mov    %rcx,0x18(%rsi)
    29c4:	48 b9 00 00 00 00 01 	movabs $0x100000000,%rcx
    29cb:	00 00 00 
    29ce:	48 89 4e 20          	mov    %rcx,0x20(%rsi)
    29d2:	48 89 56 28          	mov    %rdx,0x28(%rsi)
    29d6:	41 b9 ff ff ff ff    	mov    $0xffffffff,%r9d
    29dc:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    29e0:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
    29e7:	00 80 3f 
    29ea:	48 89 7b 70          	mov    %rdi,0x70(%rbx)
    29ee:	48 8d 56 30          	lea    0x30(%rsi),%rdx
    29f2:	48 83 c6 38          	add    $0x38,%rsi
    29f6:	48 b9 ca 5d c0 02 08 	movabs $0x802c05dca,%rcx
    29fd:	00 00 00 
    2a00:	4c 8d 81 d9 85 00 00 	lea    0x85d9(%rcx),%r8
    2a07:	4c 89 0a             	mov    %r9,(%rdx)
    2a0a:	48 89 3e             	mov    %rdi,(%rsi)
    2a0d:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    2a14:	4c 89 42 70          	mov    %r8,0x70(%rdx)
    2a18:	49 b8 ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r8
    2a1f:	ff 7f 7f 
    2a22:	4c 89 42 78          	mov    %r8,0x78(%rdx)
    2a26:	48 be ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%rsi
    2a2d:	ff 7f ff 
    2a30:	48 89 73 68          	mov    %rsi,0x68(%rbx)
    2a34:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    2a38:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    2a3f:	00 
    2a40:	48 89 b2 80 00 00 00 	mov    %rsi,0x80(%rdx)
    2a47:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    2a4c:	48 89 82 88 00 00 00 	mov    %rax,0x88(%rdx)
    2a53:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    2a58:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
    2a5c:	48 89 7a 40          	mov    %rdi,0x40(%rdx)
    2a60:	48 c7 42 48 00 00 00 	movq   $0x0,0x48(%rdx)
    2a67:	00 
    2a68:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2a6f:	48 89 88 a4 00 00 00 	mov    %rcx,0xa4(%rax)
    2a76:	48 8b 04 24          	mov    (%rsp),%rax
    2a7a:	48 89 42 50          	mov    %rax,0x50(%rdx)
    2a7e:	48 c7 42 58 00 00 00 	movq   $0x0,0x58(%rdx)
    2a85:	00 
    2a86:	48 c7 43 50 02 00 00 	movq   $0x2,0x50(%rbx)
    2a8d:	00 
    2a8e:	4c 89 82 90 00 00 00 	mov    %r8,0x90(%rdx)
    2a95:	48 89 b2 98 00 00 00 	mov    %rsi,0x98(%rdx)
    2a9c:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2aa0:	c5 f8 11 42 60       	vmovups %xmm0,0x60(%rdx)
    2aa5:	b8 02 00 00 00       	mov    $0x2,%eax
    2aaa:	44 89 92 a0 00 00 00 	mov    %r10d,0xa0(%rdx)
    2ab1:	89 82 bc 00 00 00    	mov    %eax,0xbc(%rdx)
    2ab7:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    2abe:	48 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%rax
    2ac5:	48 8b 80 c8 1e 00 00 	mov    0x1ec8(%rax),%rax
    2acc:	0f b6 71 08          	movzbl 0x8(%rcx),%esi
    2ad0:	48 69 fe e0 3c 00 00 	imul   $0x3ce0,%rsi,%rdi
    2ad7:	31 c9                	xor    %ecx,%ecx
    2ad9:	39 70 08             	cmp    %esi,0x8(%rax)
    2adc:	ba 00 00 00 00       	mov    $0x0,%edx
    2ae1:	48 0f 47 d7          	cmova  %rdi,%rdx
    2ae5:	4c 8b 40 10          	mov    0x10(%rax),%r8
    2ae9:	4e 8b 8c 02 08 2e 00 	mov    0x2e08(%rdx,%r8,1),%r9
    2af0:	00 
    2af1:	4c 89 4b 68          	mov    %r9,0x68(%rbx)
    2af5:	4a 8b 94 02 00 2e 00 	mov    0x2e00(%rdx,%r8,1),%rdx
    2afc:	00 
    2afd:	48 89 55 00          	mov    %rdx,0x0(%rbp)
    2b01:	4c 89 4d 08          	mov    %r9,0x8(%rbp)
    2b05:	44 8b 40 08          	mov    0x8(%rax),%r8d
    2b09:	48 8b 50 10          	mov    0x10(%rax),%rdx
    2b0d:	48 89 53 60          	mov    %rdx,0x60(%rbx)
    2b11:	45 31 c9             	xor    %r9d,%r9d
    2b14:	45 31 d2             	xor    %r10d,%r10d
    2b17:	45 89 c3             	mov    %r8d,%r11d
    2b1a:	41 29 f3             	sub    %esi,%r11d
    2b1d:	48 0f 47 cf          	cmova  %rdi,%rcx
    2b21:	41 0f 94 c1          	sete   %r9b
    2b25:	41 0f 93 c2          	setae  %r10b
    2b29:	c4 c2 20 f2 f0       	andn   %r8d,%r11d,%esi
    2b2e:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    2b35:	41 c1 e1 1e          	shl    $0x1e,%r9d
    2b39:	41 c1 e2 1d          	shl    $0x1d,%r10d
    2b3d:	45 09 ca             	or     %r9d,%r10d
    2b40:	45 09 da             	or     %r11d,%r10d
    2b43:	c1 ee 03             	shr    $0x3,%esi
    2b46:	81 e6 00 00 00 10    	and    $0x10000000,%esi
    2b4c:	44 09 d6             	or     %r10d,%esi
    2b4f:	48 89 b3 10 01 00 00 	mov    %rsi,0x110(%rbx)
    2b56:	48 8b b4 0a 80 30 00 	mov    0x3080(%rdx,%rcx,1),%rsi
    2b5d:	00 
    2b5e:	48 8b bc 0a 88 30 00 	mov    0x3088(%rdx,%rcx,1),%rdi
    2b65:	00 
    2b66:	48 89 73 58          	mov    %rsi,0x58(%rbx)
    2b6a:	49 89 75 00          	mov    %rsi,0x0(%r13)
    2b6e:	49 89 7d 08          	mov    %rdi,0x8(%r13)
    2b72:	8b b4 0a 98 30 00 00 	mov    0x3098(%rdx,%rcx,1),%esi
    2b79:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    2b7d:	48 8b 8c 0a 90 30 00 	mov    0x3090(%rdx,%rcx,1),%rcx
    2b84:	00 
    2b85:	48 8b 93 c8 00 00 00 	mov    0xc8(%rbx),%rdx
    2b8c:	48 89 0a             	mov    %rcx,(%rdx)
    2b8f:	89 72 08             	mov    %esi,0x8(%rdx)
    2b92:	8b 50 20             	mov    0x20(%rax),%edx
    2b95:	8b 48 24             	mov    0x24(%rax),%ecx
    2b98:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    2b9c:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    2ba0:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    2ba7:	c7 80 b4 00 00 00 00 	movl   $0x0,0xb4(%rax)
    2bae:	00 00 00 
    2bb1:	48 8b b3 c0 00 00 00 	mov    0xc0(%rbx),%rsi
    2bb8:	c7 86 b1 00 00 00 00 	movl   $0x0,0xb1(%rsi)
    2bbf:	00 00 00 
    2bc2:	88 90 b0 00 00 00    	mov    %dl,0xb0(%rax)
    2bc8:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    2bcf:	00 00 00 
    2bd2:	88 88 b8 00 00 00    	mov    %cl,0xb8(%rax)
    2bd8:	48 8b bb b8 00 00 00 	mov    0xb8(%rbx),%rdi
    2bdf:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    2be6:	8b 08                	mov    (%rax),%ecx
    2be8:	48 89 4b 50          	mov    %rcx,0x50(%rbx)
    2bec:	48 8d 57 1c          	lea    0x1c(%rdi),%rdx
    2bf0:	8b 77 1c             	mov    0x1c(%rdi),%esi
    2bf3:	48 89 53 40          	mov    %rdx,0x40(%rbx)
    2bf7:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    2bfb:	89 70 48             	mov    %esi,0x48(%rax)
    2bfe:	4c 8d 47 2c          	lea    0x2c(%rdi),%r8
    2c02:	44 8b 4f 2c          	mov    0x2c(%rdi),%r9d
    2c06:	4c 89 83 b0 00 00 00 	mov    %r8,0xb0(%rbx)
    2c0d:	4c 89 4b 60          	mov    %r9,0x60(%rbx)
    2c11:	8b 7f 14             	mov    0x14(%rdi),%edi
    2c14:	45 31 c0             	xor    %r8d,%r8d
    2c17:	85 cf                	test   %ecx,%edi
    2c19:	41 0f 95 c0          	setne  %r8b
    2c1d:	45 31 d2             	xor    %r10d,%r10d
    2c20:	45 85 c9             	test   %r9d,%r9d
    2c23:	41 0f 94 c2          	sete   %r10b
    2c27:	45 89 cb             	mov    %r9d,%r11d
    2c2a:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    2c31:	41 c1 e2 1e          	shl    $0x1e,%r10d
    2c35:	4c 89 43 58          	mov    %r8,0x58(%rbx)
    2c39:	4f 8d 04 1a          	lea    (%r10,%r11,1),%r8
    2c3d:	49 81 c0 00 00 00 20 	add    $0x20000000,%r8
    2c44:	4c 89 83 10 01 00 00 	mov    %r8,0x110(%rbx)
    2c4b:	45 85 c9             	test   %r9d,%r9d
    2c4e:	0f 8e 6a 02 00 00    	jle    2ebe <f_8001161d0+0x2ebe>
    2c54:	85 cf                	test   %ecx,%edi
    2c56:	0f 84 6a 02 00 00    	je     2ec6 <f_8001161d0+0x2ec6>
    2c5c:	4c 8b 83 a0 00 00 00 	mov    0xa0(%rbx),%r8
    2c63:	4c 8b 8b a8 00 00 00 	mov    0xa8(%rbx),%r9
    2c6a:	49 8d b8 40 01 00 00 	lea    0x140(%r8),%rdi
    2c71:	48 89 bb c0 00 00 00 	mov    %rdi,0xc0(%rbx)
    2c78:	44 89 cf             	mov    %r9d,%edi
    2c7b:	4d 63 c9             	movslq %r9d,%r9
    2c7e:	49 c1 f9 1f          	sar    $0x1f,%r9
    2c82:	49 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%r10
    2c89:	ff ff ff 
    2c8c:	4d 21 d1             	and    %r10,%r9
    2c8f:	49 09 f9             	or     %rdi,%r9
    2c92:	4c 89 8b c8 00 00 00 	mov    %r9,0xc8(%rbx)
    2c99:	47 0f b6 84 08 40 01 	movzbl 0x140(%r8,%r9,1),%r8d
    2ca0:	00 00 
    2ca2:	4c 89 43 58          	mov    %r8,0x58(%rbx)
    2ca6:	41 f6 c0 01          	test   $0x1,%r8b
    2caa:	0f 84 16 02 00 00    	je     2ec6 <f_8001161d0+0x2ec6>
    2cb0:	44 0f b6 40 0c       	movzbl 0xc(%rax),%r8d
    2cb5:	4c 89 43 58          	mov    %r8,0x58(%rbx)
    2cb9:	41 f6 c0 01          	test   $0x1,%r8b
    2cbd:	74 09                	je     2cc8 <f_8001161d0+0x2cc8>
    2cbf:	48 09 ce             	or     %rcx,%rsi
    2cc2:	48 89 73 48          	mov    %rsi,0x48(%rbx)
    2cc6:	89 32                	mov    %esi,(%rdx)
    2cc8:	48 c7 43 40 d0 00 00 	movq   $0xd0,0x40(%rbx)
    2ccf:	00 
    2cd0:	48 89 43 08          	mov    %rax,0x8(%rbx)
    2cd4:	48 63 c7             	movslq %edi,%rax
    2cd7:	48 69 c0 d0 00 00 00 	imul   $0xd0,%rax,%rax
    2cde:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    2ce5:	48 8d 14 01          	lea    (%rcx,%rax,1),%rdx
    2ce9:	48 89 93 d0 00 00 00 	mov    %rdx,0xd0(%rbx)
    2cf0:	48 c7 43 10 c0 00 00 	movq   $0xc0,0x10(%rbx)
    2cf7:	00 
    2cf8:	48 8d 84 01 40 0d 00 	lea    0xd40(%rcx,%rax,1),%rax
    2cff:	00 
    2d00:	48 89 83 a8 00 00 00 	mov    %rax,0xa8(%rbx)
    2d07:	48 89 03             	mov    %rax,(%rbx)
    2d0a:	49 8d 85 6e 12 51 fd 	lea    -0x2aeed92(%r13),%rax
    2d11:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    2d18:	48 89 df             	mov    %rbx,%rdi
    2d1b:	c5 f8 77             	vzeroupper
    2d1e:	e8 00 00 00 00       	call   2d23 <f_8001161d0+0x2d23>
    2d23:	48 8b 83 d0 00 00 00 	mov    0xd0(%rbx),%rax
    2d2a:	80 88 38 0d 00 00 01 	orb    $0x1,0xd38(%rax)
    2d31:	48 8b bb a0 00 00 00 	mov    0xa0(%rbx),%rdi
    2d38:	0f b6 87 81 3a 00 00 	movzbl 0x3a81(%rdi),%eax
    2d3f:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2d43:	a8 40                	test   $0x40,%al
    2d45:	0f 84 7b 01 00 00    	je     2ec6 <f_8001161d0+0x2ec6>
    2d4b:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    2d52:	48 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%rcx
    2d59:	0f b6 04 01          	movzbl (%rcx,%rax,1),%eax
    2d5d:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2d61:	a8 02                	test   $0x2,%al
    2d63:	0f 84 5d 01 00 00    	je     2ec6 <f_8001161d0+0x2ec6>
    2d69:	48 8b 87 60 3b 00 00 	mov    0x3b60(%rdi),%rax
    2d70:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2d74:	48 85 c0             	test   %rax,%rax
    2d77:	0f 84 49 01 00 00    	je     2ec6 <f_8001161d0+0x2ec6>
    2d7d:	0f b6 87 85 3a 00 00 	movzbl 0x3a85(%rdi),%eax
    2d84:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2d88:	a8 02                	test   $0x2,%al
    2d8a:	0f 84 36 01 00 00    	je     2ec6 <f_8001161d0+0x2ec6>
    2d90:	48 8b 83 a8 00 00 00 	mov    0xa8(%rbx),%rax
    2d97:	48 8b 8b b8 00 00 00 	mov    0xb8(%rbx),%rcx
    2d9e:	8b 00                	mov    (%rax),%eax
    2da0:	48 89 43 40          	mov    %rax,0x40(%rbx)
    2da4:	8b 49 10             	mov    0x10(%rcx),%ecx
    2da7:	48 89 4b 48          	mov    %rcx,0x48(%rbx)
    2dab:	c4 e2 70 f2 c0       	andn   %eax,%ecx,%eax
    2db0:	0f 85 10 01 00 00    	jne    2ec6 <f_8001161d0+0x2ec6>
    2db6:	48 8b 83 b0 00 00 00 	mov    0xb0(%rbx),%rax
    2dbd:	8b 08                	mov    (%rax),%ecx
    2dbf:	44 8b 87 90 3b 00 00 	mov    0x3b90(%rdi),%r8d
    2dc6:	44 8b 8f 94 3b 00 00 	mov    0x3b94(%rdi),%r9d
    2dcd:	41 83 f8 01          	cmp    $0x1,%r8d
    2dd1:	44 89 c6             	mov    %r8d,%esi
    2dd4:	83 d6 00             	adc    $0x0,%esi
    2dd7:	89 c8                	mov    %ecx,%eax
    2dd9:	31 d2                	xor    %edx,%edx
    2ddb:	f7 f6                	div    %esi
    2ddd:	89 c6                	mov    %eax,%esi
    2ddf:	45 85 c0             	test   %r8d,%r8d
    2de2:	41 0f 44 f0          	cmove  %r8d,%esi
    2de6:	4c 89 4b 48          	mov    %r9,0x48(%rbx)
    2dea:	41 39 f1             	cmp    %esi,%r9d
    2ded:	41 0f 4c f1          	cmovl  %r9d,%esi
    2df1:	48 89 73 40          	mov    %rsi,0x40(%rbx)
    2df5:	85 f6                	test   %esi,%esi
    2df7:	0f 84 c9 00 00 00    	je     2ec6 <f_8001161d0+0x2ec6>
    2dfd:	48 89 8b 88 00 00 00 	mov    %rcx,0x88(%rbx)
    2e04:	31 c0                	xor    %eax,%eax
    2e06:	89 f2                	mov    %esi,%edx
    2e08:	ff ca                	dec    %edx
    2e0a:	0f 94 c0             	sete   %al
    2e0d:	41 b8 00 00 00 80    	mov    $0x80000000,%r8d
    2e13:	45 31 c9             	xor    %r9d,%r9d
    2e16:	4c 39 c6             	cmp    %r8,%rsi
    2e19:	41 0f 94 c1          	sete   %r9b
    2e1d:	41 89 d0             	mov    %edx,%r8d
    2e20:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
    2e27:	c1 e0 1e             	shl    $0x1e,%eax
    2e2a:	41 c1 e1 1c          	shl    $0x1c,%r9d
    2e2e:	45 09 c1             	or     %r8d,%r9d
    2e31:	41 09 c1             	or     %eax,%r9d
    2e34:	49 81 c9 00 00 00 20 	or     $0x20000000,%r9
    2e3b:	4c 89 8b 10 01 00 00 	mov    %r9,0x110(%rbx)
    2e42:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    2e46:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
    2e4a:	85 f6                	test   %esi,%esi
    2e4c:	7e 78                	jle    2ec6 <f_8001161d0+0x2ec6>
    2e4e:	89 c8                	mov    %ecx,%eax
    2e50:	99                   	cltd
    2e51:	f7 fe                	idiv   %esi
    2e53:	48 8d 4b 50          	lea    0x50(%rbx),%rcx
    2e57:	48 8d b7 80 3b 00 00 	lea    0x3b80(%rdi),%rsi
    2e5e:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    2e62:	c5 f8 29 01          	vmovaps %xmm0,(%rcx)
    2e66:	48 89 73 70          	mov    %rsi,0x70(%rbx)
    2e6a:	48 c7 43 78 28 00 00 	movq   $0x28,0x78(%rbx)
    2e71:	00 
    2e72:	48 c7 83 80 00 00 00 	movq   $0x3dcccccd,0x80(%rbx)
    2e79:	cd cc cc 3d 
    2e7d:	48 89 53 60          	mov    %rdx,0x60(%rbx)
    2e81:	48 81 c7 78 3b 00 00 	add    $0x3b78,%rdi
    2e88:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    2e8c:	48 89 83 88 00 00 00 	mov    %rax,0x88(%rbx)
    2e93:	31 c9                	xor    %ecx,%ecx
    2e95:	48 ba 00 00 00 00 f8 	movabs $0xfffffff800000000,%rdx
    2e9c:	ff ff ff 
    2e9f:	c4 e2 79 59 0d 00 00 	vpbroadcastq 0x0(%rip),%xmm1        # 2ea8 <f_8001161d0+0x2ea8>
    2ea6:	00 00 
    2ea8:	c5 e8 57 d2          	vxorps %xmm2,%xmm2,%xmm2
    2eac:	c5 fa 10 1d 00 00 00 	vmovss 0x0(%rip),%xmm3        # 2eb4 <f_8001161d0+0x2eb4>
    2eb3:	00 
    2eb4:	be ff ff ff ff       	mov    $0xffffffff,%esi
    2eb9:	e9 44 01 00 00       	jmp    3002 <f_8001161d0+0x3002>
    2ebe:	48 c7 43 58 00 00 00 	movq   $0x0,0x58(%rbx)
    2ec5:	00 
    2ec6:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    2ecd:	48 8b 88 20 01 00 00 	mov    0x120(%rax),%rcx
    2ed4:	48 8b 90 28 01 00 00 	mov    0x128(%rax),%rdx
    2edb:	48 89 8b a0 00 00 00 	mov    %rcx,0xa0(%rbx)
    2ee2:	48 89 93 98 00 00 00 	mov    %rdx,0x98(%rbx)
    2ee9:	48 8b 88 10 01 00 00 	mov    0x110(%rax),%rcx
    2ef0:	48 8b 90 18 01 00 00 	mov    0x118(%rax),%rdx
    2ef7:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
    2efe:	48 89 93 a8 00 00 00 	mov    %rdx,0xa8(%rbx)
    2f05:	48 8b 88 00 01 00 00 	mov    0x100(%rax),%rcx
    2f0c:	48 8b 90 08 01 00 00 	mov    0x108(%rax),%rdx
    2f13:	48 89 8b c0 00 00 00 	mov    %rcx,0xc0(%rbx)
    2f1a:	48 89 93 b8 00 00 00 	mov    %rdx,0xb8(%rbx)
    2f21:	48 8b 88 f0 00 00 00 	mov    0xf0(%rax),%rcx
    2f28:	48 8b 90 f8 00 00 00 	mov    0xf8(%rax),%rdx
    2f2f:	48 89 8b d0 00 00 00 	mov    %rcx,0xd0(%rbx)
    2f36:	48 89 93 c8 00 00 00 	mov    %rdx,0xc8(%rbx)
    2f3d:	48 8b 88 e0 00 00 00 	mov    0xe0(%rax),%rcx
    2f44:	48 8b 90 e8 00 00 00 	mov    0xe8(%rax),%rdx
    2f4b:	48 89 8b e0 00 00 00 	mov    %rcx,0xe0(%rbx)
    2f52:	48 89 93 d8 00 00 00 	mov    %rdx,0xd8(%rbx)
    2f59:	c5 f8 10 80 d0 00 00 	vmovups 0xd0(%rax),%xmm0
    2f60:	00 
    2f61:	c5 f8 11 83 e8 00 00 	vmovups %xmm0,0xe8(%rbx)
    2f68:	00 
    2f69:	48 05 30 01 00 00    	add    $0x130,%rax
    2f6f:	48 89 83 00 01 00 00 	mov    %rax,0x100(%rbx)
    2f76:	48 83 c4 18          	add    $0x18,%rsp
    2f7a:	5b                   	pop    %rbx
    2f7b:	41 5c                	pop    %r12
    2f7d:	41 5d                	pop    %r13
    2f7f:	41 5e                	pop    %r14
    2f81:	41 5f                	pop    %r15
    2f83:	5d                   	pop    %rbp
    2f84:	c5 f8 77             	vzeroupper
    2f87:	c3                   	ret
    2f88:	c4 e3 f1 22 a3 88 00 	vpinsrq $0x1,0x88(%rbx),%xmm1,%xmm4
    2f8f:	00 00 01 
    2f92:	c5 d9 d4 63 50       	vpaddq 0x50(%rbx),%xmm4,%xmm4
    2f97:	c5 f9 7e e0          	vmovd  %xmm4,%eax
    2f9b:	8b 7b 40             	mov    0x40(%rbx),%edi
    2f9e:	45 31 c0             	xor    %r8d,%r8d
    2fa1:	41 89 c1             	mov    %eax,%r9d
    2fa4:	41 31 f9             	xor    %edi,%r9d
    2fa7:	41 0f 94 c0          	sete   %r8b
    2fab:	45 31 d2             	xor    %r10d,%r10d
    2fae:	41 89 c3             	mov    %eax,%r11d
    2fb1:	41 29 fb             	sub    %edi,%r11d
    2fb4:	41 0f 93 c2          	setae  %r10b
    2fb8:	45 89 de             	mov    %r11d,%r14d
    2fbb:	41 31 c6             	xor    %eax,%r14d
    2fbe:	45 21 ce             	and    %r9d,%r14d
    2fc1:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    2fc8:	41 c1 e0 1e          	shl    $0x1e,%r8d
    2fcc:	41 c1 e2 1d          	shl    $0x1d,%r10d
    2fd0:	45 09 c2             	or     %r8d,%r10d
    2fd3:	45 09 da             	or     %r11d,%r10d
    2fd6:	41 c1 ee 03          	shr    $0x3,%r14d
    2fda:	41 81 e6 00 00 00 10 	and    $0x10000000,%r14d
    2fe1:	45 09 d6             	or     %r10d,%r14d
    2fe4:	31 f8                	xor    %edi,%eax
    2fe6:	c4 e3 59 02 e0 0a    	vpblendd $0xa,%xmm0,%xmm4,%xmm4
    2fec:	c5 f9 7f 63 50       	vmovdqa %xmm4,0x50(%rbx)
    2ff1:	4c 89 b3 10 01 00 00 	mov    %r14,0x110(%rbx)
    2ff8:	0f 84 c8 fe ff ff    	je     2ec6 <f_8001161d0+0x2ec6>
    2ffe:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
    3002:	8b 07                	mov    (%rdi),%eax
    3004:	48 89 83 90 00 00 00 	mov    %rax,0x90(%rbx)
    300b:	8d 78 01             	lea    0x1(%rax),%edi
    300e:	48 89 3b             	mov    %rdi,(%rbx)
    3011:	4c 8b 43 68          	mov    0x68(%rbx),%r8
    3015:	45 31 c9             	xor    %r9d,%r9d
    3018:	f0 41 0f b1 38       	lock cmpxchg %edi,(%r8)
    301d:	41 0f 95 c1          	setne  %r9b
    3021:	4c 89 4b 08          	mov    %r9,0x8(%rbx)
    3025:	75 d7                	jne    2ffe <f_8001161d0+0x2ffe>
    3027:	4c 8b 93 a0 00 00 00 	mov    0xa0(%rbx),%r10
    302e:	8b 43 50             	mov    0x50(%rbx),%eax
    3031:	3b 43 48             	cmp    0x48(%rbx),%eax
    3034:	8b 7b 60             	mov    0x60(%rbx),%edi
    3037:	48 0f 45 f9          	cmovne %rcx,%rdi
    303b:	4d 8b 8a 70 3b 00 00 	mov    0x3b70(%r10),%r9
    3042:	4c 8b 83 90 00 00 00 	mov    0x90(%rbx),%r8
    3049:	b8 00 00 00 00       	mov    $0x0,%eax
    304e:	45 39 82 68 3b 00 00 	cmp    %r8d,0x3b68(%r10)
    3055:	76 1a                	jbe    3071 <f_8001161d0+0x3071>
    3057:	45 89 c0             	mov    %r8d,%r8d
    305a:	49 63 c0             	movslq %r8d,%rax
    305d:	48 c1 f8 1f          	sar    $0x1f,%rax
    3061:	49 ba 00 00 00 00 ff 	movabs $0xffffffff00000000,%r10
    3068:	ff ff ff 
    306b:	4c 21 d0             	and    %r10,%rax
    306e:	4c 09 c0             	or     %r8,%rax
    3071:	48 89 43 08          	mov    %rax,0x8(%rbx)
    3075:	48 03 bb 88 00 00 00 	add    0x88(%rbx),%rdi
    307c:	41 89 f8             	mov    %edi,%r8d
    307f:	4c 89 83 88 00 00 00 	mov    %r8,0x88(%rbx)
    3086:	48 98                	cltq
    3088:	4c 63 53 78          	movslq 0x78(%rbx),%r10
    308c:	4c 0f af d0          	imul   %rax,%r10
    3090:	4b 8d 04 0a          	lea    (%r10,%r9,1),%rax
    3094:	48 89 83 90 00 00 00 	mov    %rax,0x90(%rbx)
    309b:	44 8b 5b 58          	mov    0x58(%rbx),%r11d
    309f:	49 89 fe             	mov    %rdi,%r14
    30a2:	49 c1 e6 20          	shl    $0x20,%r14
    30a6:	4d 09 de             	or     %r11,%r14
    30a9:	4c 8b 9b 98 00 00 00 	mov    0x98(%rbx),%r11
    30b0:	4f 89 1c 0a          	mov    %r11,(%r10,%r9,1)
    30b4:	4c 8b 9b b8 00 00 00 	mov    0xb8(%rbx),%r11
    30bb:	4f 89 5c 0a 08       	mov    %r11,0x8(%r10,%r9,1)
    30c0:	4c 8b 9b a8 00 00 00 	mov    0xa8(%rbx),%r11
    30c7:	4f 89 5c 0a 10       	mov    %r11,0x10(%r10,%r9,1)
    30cc:	4f 89 74 0a 18       	mov    %r14,0x18(%r10,%r9,1)
    30d1:	45 8b 8b bc 00 00 00 	mov    0xbc(%r11),%r9d
    30d8:	45 31 d2             	xor    %r10d,%r10d
    30db:	45 89 cb             	mov    %r9d,%r11d
    30de:	41 83 c3 fe          	add    $0xfffffffe,%r11d
    30e2:	41 0f 94 c2          	sete   %r10b
    30e6:	31 ed                	xor    %ebp,%ebp
    30e8:	41 be 01 00 00 00    	mov    $0x1,%r14d
    30ee:	45 29 ce             	sub    %r9d,%r14d
    30f1:	40 0f 92 c5          	setb   %bpl
    30f5:	45 21 ce             	and    %r9d,%r14d
    30f8:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    30ff:	41 c1 e2 1e          	shl    $0x1e,%r10d
    3103:	c1 e5 1d             	shl    $0x1d,%ebp
    3106:	44 09 dd             	or     %r11d,%ebp
    3109:	44 09 d5             	or     %r10d,%ebp
    310c:	41 c1 ee 03          	shr    $0x3,%r14d
    3110:	41 81 e6 00 00 00 10 	and    $0x10000000,%r14d
    3117:	41 09 ee             	or     %ebp,%r14d
    311a:	4c 89 b3 10 01 00 00 	mov    %r14,0x110(%rbx)
    3121:	41 83 f9 01          	cmp    $0x1,%r9d
    3125:	74 62                	je     3189 <f_8001161d0+0x3189>
    3127:	41 83 f9 02          	cmp    $0x2,%r9d
    312b:	0f 85 9b 00 00 00    	jne    31cc <f_8001161d0+0x31cc>
    3131:	c5 82 2a e7          	vcvtsi2ss %edi,%xmm15,%xmm4
    3135:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
    313c:	41 89 f8             	mov    %edi,%r8d
    313f:	4c 89 83 10 02 00 00 	mov    %r8,0x210(%rbx)
    3146:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    314d:	00 00 00 00 
    3151:	c5 f9 6e ef          	vmovd  %edi,%xmm5
    3155:	c5 da 59 e5          	vmulss %xmm5,%xmm4,%xmm4
    3159:	c5 f9 7e e7          	vmovd  %xmm4,%edi
    315d:	48 89 bb 00 02 00 00 	mov    %rdi,0x200(%rbx)
    3164:	c4 61 fa 2c c4       	vcvttss2si %xmm4,%r8
    3169:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    3170:	00 00 00 00 
    3174:	c5 f8 2e e2          	vucomiss %xmm2,%xmm4
    3178:	44 0f 42 c1          	cmovb  %ecx,%r8d
    317c:	c5 f8 2e e3          	vucomiss %xmm3,%xmm4
    3180:	44 0f 47 c6          	cmova  %esi,%r8d
    3184:	e9 9c 00 00 00       	jmp    3225 <f_8001161d0+0x3225>
    3189:	45 31 c0             	xor    %r8d,%r8d
    318c:	85 ff                	test   %edi,%edi
    318e:	41 0f 94 c0          	sete   %r8b
    3192:	41 89 f9             	mov    %edi,%r9d
    3195:	41 81 e1 00 00 00 80 	and    $0x80000000,%r9d
    319c:	41 c1 e0 1e          	shl    $0x1e,%r8d
    31a0:	4d 01 c8             	add    %r9,%r8
    31a3:	49 81 c0 00 00 00 20 	add    $0x20000000,%r8
    31aa:	4c 89 83 10 01 00 00 	mov    %r8,0x110(%rbx)
    31b1:	41 89 f8             	mov    %edi,%r8d
    31b4:	41 c1 e8 1f          	shr    $0x1f,%r8d
    31b8:	41 01 f8             	add    %edi,%r8d
    31bb:	44 89 c7             	mov    %r8d,%edi
    31be:	d1 ef                	shr    $1,%edi
    31c0:	41 81 e0 00 00 00 80 	and    $0x80000000,%r8d
    31c7:	41 09 f8             	or     %edi,%r8d
    31ca:	eb 59                	jmp    3225 <f_8001161d0+0x3225>
    31cc:	45 31 d2             	xor    %r10d,%r10d
    31cf:	45 89 cb             	mov    %r9d,%r11d
    31d2:	41 83 c3 fd          	add    $0xfffffffd,%r11d
    31d6:	41 0f 94 c2          	sete   %r10b
    31da:	31 ed                	xor    %ebp,%ebp
    31dc:	41 be 02 00 00 00    	mov    $0x2,%r14d
    31e2:	45 29 ce             	sub    %r9d,%r14d
    31e5:	40 0f 92 c5          	setb   %bpl
    31e9:	45 21 ce             	and    %r9d,%r14d
    31ec:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    31f3:	41 c1 e2 1e          	shl    $0x1e,%r10d
    31f7:	c1 e5 1d             	shl    $0x1d,%ebp
    31fa:	44 09 dd             	or     %r11d,%ebp
    31fd:	44 09 d5             	or     %r10d,%ebp
    3200:	41 c1 ee 03          	shr    $0x3,%r14d
    3204:	41 81 e6 00 00 00 10 	and    $0x10000000,%r14d
    320b:	41 09 ee             	or     %ebp,%r14d
    320e:	4c 89 b3 10 01 00 00 	mov    %r14,0x110(%rbx)
    3215:	4c 89 43 10          	mov    %r8,0x10(%rbx)
    3219:	41 83 f9 03          	cmp    $0x3,%r9d
    321d:	75 0a                	jne    3229 <f_8001161d0+0x3229>
    321f:	01 ff                	add    %edi,%edi
    3221:	44 8d 04 bf          	lea    (%rdi,%rdi,4),%r8d
    3225:	4c 89 43 10          	mov    %r8,0x10(%rbx)
    3229:	48 89 03             	mov    %rax,(%rbx)
    322c:	44 89 40 20          	mov    %r8d,0x20(%rax)
    3230:	48 8b 43 70          	mov    0x70(%rbx),%rax
    3234:	8b 00                	mov    (%rax),%eax
    3236:	48 89 03             	mov    %rax,(%rbx)
    3239:	8d 78 01             	lea    0x1(%rax),%edi
    323c:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    3240:	4c 8b 43 70          	mov    0x70(%rbx),%r8
    3244:	45 31 c9             	xor    %r9d,%r9d
    3247:	f0 41 0f b1 38       	lock cmpxchg %edi,(%r8)
    324c:	41 0f 95 c1          	setne  %r9b
    3250:	4c 89 4b 10          	mov    %r9,0x10(%rbx)
    3254:	75 da                	jne    3230 <f_8001161d0+0x3230>
    3256:	48 8b 03             	mov    (%rbx),%rax
    3259:	48 8b bb a0 00 00 00 	mov    0xa0(%rbx),%rdi
    3260:	44 8b 87 84 3b 00 00 	mov    0x3b84(%rdi),%r8d
    3267:	4c 89 43 08          	mov    %r8,0x8(%rbx)
    326b:	41 39 c0             	cmp    %eax,%r8d
    326e:	0f 8e 14 fd ff ff    	jle    2f88 <f_8001161d0+0x2f88>
    3274:	48 8b bf 88 3b 00 00 	mov    0x3b88(%rdi),%rdi
    327b:	48 89 7b 08          	mov    %rdi,0x8(%rbx)
    327f:	4c 8d 04 c5 00 00 00 	lea    0x0(,%rax,8),%r8
    3286:	00 
    3287:	48 98                	cltq
    3289:	48 21 d0             	and    %rdx,%rax
    328c:	4d 8d 8d 2e a2 3f fd 	lea    -0x2c05dd2(%r13),%r9
    3293:	4d 21 c1             	and    %r8,%r9
    3296:	49 09 c1             	or     %rax,%r9
    3299:	4c 89 0b             	mov    %r9,(%rbx)
    329c:	48 8b 83 90 00 00 00 	mov    0x90(%rbx),%rax
    32a3:	4a 89 04 0f          	mov    %rax,(%rdi,%r9,1)
    32a7:	e9 dc fc ff ff       	jmp    2f88 <f_8001161d0+0x2f88>
    32ac:	48 8b b3 a0 00 00 00 	mov    0xa0(%rbx),%rsi
    32b3:	48 8b 8e c8 1e 00 00 	mov    0x1ec8(%rsi),%rcx
    32ba:	48 89 8b b0 00 00 00 	mov    %rcx,0xb0(%rbx)
    32c1:	48 bd 00 00 00 00 ff 	movabs $0xffffffff00000000,%rbp
    32c8:	ff ff ff 
    32cb:	48 8d 4d 1a          	lea    0x1a(%rbp),%rcx
    32cf:	48 89 4b 70          	mov    %rcx,0x70(%rbx)
    32d3:	c6 40 88 00          	movb   $0x0,-0x78(%rax)
    32d7:	48 8b 93 00 01 00 00 	mov    0x100(%rbx),%rdx
    32de:	48 c7 02 00 20 00 00 	movq   $0x2000,(%rdx)
    32e5:	48 c7 42 08 00 00 00 	movq   $0x0,0x8(%rdx)
    32ec:	00 
    32ed:	48 c7 42 10 ff ff 00 	movq   $0xffff,0x10(%rdx)
    32f4:	00 
    32f5:	48 89 4a 18          	mov    %rcx,0x18(%rdx)
    32f9:	48 8b 8b 98 00 00 00 	mov    0x98(%rbx),%rcx
    3300:	48 89 4b 08          	mov    %rcx,0x8(%rbx)
    3304:	48 c7 40 80 00 00 00 	movq   $0x0,-0x80(%rax)
    330b:	00 
    330c:	44 89 92 a0 00 00 00 	mov    %r10d,0xa0(%rdx)
    3313:	48 b8 00 00 00 00 01 	movabs $0x100000000,%rax
    331a:	00 00 00 
    331d:	48 89 42 20          	mov    %rax,0x20(%rdx)
    3321:	48 89 6a 28          	mov    %rbp,0x28(%rdx)
    3325:	48 bf 00 00 80 3f 00 	movabs $0x3f8000003f800000,%rdi
    332c:	00 80 3f 
    332f:	48 89 7b 68          	mov    %rdi,0x68(%rbx)
    3333:	4c 89 42 30          	mov    %r8,0x30(%rdx)
    3337:	48 89 7a 38          	mov    %rdi,0x38(%rdx)
    333b:	49 bd ca 5d c0 02 08 	movabs $0x802c05dca,%r13
    3342:	00 00 00 
    3345:	49 8d 85 95 53 09 00 	lea    0x95395(%r13),%rax
    334c:	48 89 42 70          	mov    %rax,0x70(%rdx)
    3350:	49 ba ff ff 7f 7f ff 	movabs $0x7f7fffff7f7fffff,%r10
    3357:	ff 7f 7f 
    335a:	4c 89 52 78          	mov    %r10,0x78(%rdx)
    335e:	49 b8 ff ff 7f ff ff 	movabs $0xff7fffffff7fffff,%r8
    3365:	ff 7f ff 
    3368:	4c 89 82 80 00 00 00 	mov    %r8,0x80(%rdx)
    336f:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
    3374:	48 89 82 88 00 00 00 	mov    %rax,0x88(%rdx)
    337b:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
    3380:	48 89 4b 60          	mov    %rcx,0x60(%rbx)
    3384:	48 8b 83 c0 00 00 00 	mov    0xc0(%rbx),%rax
    338b:	48 89 88 a4 00 00 00 	mov    %rcx,0xa4(%rax)
    3392:	4c 89 92 90 00 00 00 	mov    %r10,0x90(%rdx)
    3399:	4c 89 82 98 00 00 00 	mov    %r8,0x98(%rdx)
    33a0:	48 c7 43 50 b0 1e 00 	movq   $0x1eb0,0x50(%rbx)
    33a7:	00 
    33a8:	48 81 c6 b0 1e 00 00 	add    $0x1eb0,%rsi
    33af:	48 89 33             	mov    %rsi,(%rbx)
    33b2:	48 8b 04 24          	mov    (%rsp),%rax
    33b6:	48 89 42 50          	mov    %rax,0x50(%rdx)
    33ba:	48 c7 42 58 00 00 00 	movq   $0x0,0x58(%rdx)
    33c1:	00 
    33c2:	48 c7 43 48 03 00 00 	movq   $0x3,0x48(%rbx)
    33c9:	00 
    33ca:	c7 82 bc 00 00 00 03 	movl   $0x3,0xbc(%rdx)
    33d1:	00 00 00 
    33d4:	48 89 7a 40          	mov    %rdi,0x40(%rdx)
    33d8:	48 c7 42 48 00 00 00 	movq   $0x0,0x48(%rdx)
    33df:	00 
    33e0:	c5 f8 57 c0          	vxorps %xmm0,%xmm0,%xmm0
    33e4:	c5 f8 11 42 60       	vmovups %xmm0,0x60(%rdx)
    33e9:	49 8d 85 92 14 51 fd 	lea    -0x2aeeb6e(%r13),%rax
    33f0:	48 89 83 f0 00 00 00 	mov    %rax,0xf0(%rbx)
    33f7:	48 89 df             	mov    %rbx,%rdi
    33fa:	c5 f8 77             	vzeroupper
    33fd:	e8 00 00 00 00       	call   3402 <f_8001161d0+0x3402>
    3402:	48 8b 3b             	mov    (%rbx),%rdi
    3405:	48 8b 83 98 00 00 00 	mov    0x98(%rbx),%rax
    340c:	0f b6 48 08          	movzbl 0x8(%rax),%ecx
    3410:	48 8b 93 b0 00 00 00 	mov    0xb0(%rbx),%rdx
    3417:	44 8b 42 08          	mov    0x8(%rdx),%r8d
    341b:	48 69 f1 e0 3c 00 00 	imul   $0x3ce0,%rcx,%rsi
    3422:	31 c0                	xor    %eax,%eax
    3424:	45 31 c9             	xor    %r9d,%r9d
    3427:	45 31 d2             	xor    %r10d,%r10d
    342a:	45 89 c3             	mov    %r8d,%r11d
    342d:	41 29 cb             	sub    %ecx,%r11d
    3430:	41 0f 94 c1          	sete   %r9b
    3434:	41 0f 93 c2          	setae  %r10b
    3438:	48 0f 47 c6          	cmova  %rsi,%rax
    343c:	c4 42 20 f2 c0       	andn   %r8d,%r11d,%r8d
    3441:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    3448:	41 c1 e1 1e          	shl    $0x1e,%r9d
    344c:	41 c1 e2 1d          	shl    $0x1d,%r10d
    3450:	45 09 ca             	or     %r9d,%r10d
    3453:	45 09 da             	or     %r11d,%r10d
    3456:	41 c1 e8 03          	shr    $0x3,%r8d
    345a:	41 81 e0 00 00 00 10 	and    $0x10000000,%r8d
    3461:	45 09 d0             	or     %r10d,%r8d
    3464:	4c 89 83 10 01 00 00 	mov    %r8,0x110(%rbx)
    346b:	48 03 42 10          	add    0x10(%rdx),%rax
    346f:	40 f6 c7 01          	test   $0x1,%dil
    3473:	75 34                	jne    34a9 <f_8001161d0+0x34a9>
    3475:	41 b8 5c 00 00 00    	mov    $0x5c,%r8d
    347b:	41 b9 58 00 00 00    	mov    $0x58,%r9d
    3481:	41 ba 54 00 00 00    	mov    $0x54,%r10d
    3487:	41 bb 50 00 00 00    	mov    $0x50,%r11d
    348d:	eb 36                	jmp    34c5 <f_8001161d0+0x34c5>
    348f:	48 81 c2 bc 00 00 00 	add    $0xbc,%rdx
    3496:	48 c7 43 40 02 00 00 	movq   $0x2,0x40(%rbx)
    349d:	00 
    349e:	c7 02 02 00 00 00    	movl   $0x2,(%rdx)
    34a4:	e9 2f f7 ff ff       	jmp    2bd8 <f_8001161d0+0x2bd8>
    34a9:	48 89 43 68          	mov    %rax,0x68(%rbx)
    34ad:	41 b8 0c 2e 00 00    	mov    $0x2e0c,%r8d
    34b3:	41 b9 08 2e 00 00    	mov    $0x2e08,%r9d
    34b9:	41 ba 04 2e 00 00    	mov    $0x2e04,%r10d
    34bf:	41 bb 00 2e 00 00    	mov    $0x2e00,%r11d
    34c5:	46 8b 1c 18          	mov    (%rax,%r11,1),%r11d
    34c9:	4c 89 9b 00 02 00 00 	mov    %r11,0x200(%rbx)
    34d0:	48 c7 83 08 02 00 00 	movq   $0x0,0x208(%rbx)
    34d7:	00 00 00 00 
    34db:	46 8b 14 10          	mov    (%rax,%r10,1),%r10d
    34df:	4c 89 93 10 02 00 00 	mov    %r10,0x210(%rbx)
    34e6:	48 c7 83 18 02 00 00 	movq   $0x0,0x218(%rbx)
    34ed:	00 00 00 00 
    34f1:	46 8b 0c 08          	mov    (%rax,%r9,1),%r9d
    34f5:	4c 89 8b 20 02 00 00 	mov    %r9,0x220(%rbx)
    34fc:	48 c7 83 28 02 00 00 	movq   $0x0,0x228(%rbx)
    3503:	00 00 00 00 
    3507:	48 c7 43 58 e0 3c 00 	movq   $0x3ce0,0x58(%rbx)
    350e:	00 
    350f:	46 8b 04 00          	mov    (%rax,%r8,1),%r8d
    3513:	4c 89 83 30 02 00 00 	mov    %r8,0x230(%rbx)
    351a:	48 c7 83 38 02 00 00 	movq   $0x0,0x238(%rbx)
    3521:	00 00 00 00 
    3525:	48 8b 83 00 01 00 00 	mov    0x100(%rbx),%rax
    352c:	44 89 58 78          	mov    %r11d,0x78(%rax)
    3530:	44 89 50 7c          	mov    %r10d,0x7c(%rax)
    3534:	44 89 88 80 00 00 00 	mov    %r9d,0x80(%rax)
    353b:	44 89 80 84 00 00 00 	mov    %r8d,0x84(%rax)
    3542:	45 31 c0             	xor    %r8d,%r8d
    3545:	39 4a 08             	cmp    %ecx,0x8(%rdx)
    3548:	4c 0f 47 c6          	cmova  %rsi,%r8
    354c:	4c 8b 4a 10          	mov    0x10(%rdx),%r9
    3550:	40 f6 c7 01          	test   $0x1,%dil
    3554:	0f 85 90 00 00 00    	jne    35ea <f_8001161d0+0x35ea>
    355a:	4b 8b 7c 08 20       	mov    0x20(%r8,%r9,1),%rdi
    355f:	4f 8b 54 08 28       	mov    0x28(%r8,%r9,1),%r10
    3564:	4c 89 53 60          	mov    %r10,0x60(%rbx)
    3568:	4c 8b 9b d0 00 00 00 	mov    0xd0(%rbx),%r11
    356f:	49 89 3b             	mov    %rdi,(%r11)
    3572:	4d 89 53 08          	mov    %r10,0x8(%r11)
    3576:	4b 8b 7c 08 30       	mov    0x30(%r8,%r9,1),%rdi
    357b:	47 8b 44 08 38       	mov    0x38(%r8,%r9,1),%r8d
    3580:	4c 89 43 48          	mov    %r8,0x48(%rbx)
    3584:	4c 8b 8b c8 00 00 00 	mov    0xc8(%rbx),%r9
    358b:	45 89 41 08          	mov    %r8d,0x8(%r9)
    358f:	49 89 39             	mov    %rdi,(%r9)
    3592:	44 8b 4a 08          	mov    0x8(%rdx),%r9d
    3596:	48 8b 7a 10          	mov    0x10(%rdx),%rdi
    359a:	48 89 7b 50          	mov    %rdi,0x50(%rbx)
    359e:	45 31 c0             	xor    %r8d,%r8d
    35a1:	45 31 d2             	xor    %r10d,%r10d
    35a4:	45 31 db             	xor    %r11d,%r11d
    35a7:	44 89 cd             	mov    %r9d,%ebp
    35aa:	29 cd                	sub    %ecx,%ebp
    35ac:	4c 0f 47 c6          	cmova  %rsi,%r8
    35b0:	41 0f 94 c2          	sete   %r10b
    35b4:	41 0f 93 c3          	setae  %r11b
    35b8:	c4 c2 50 f2 d1       	andn   %r9d,%ebp,%edx
    35bd:	81 e5 00 00 00 80    	and    $0x80000000,%ebp
    35c3:	41 c1 e2 1e          	shl    $0x1e,%r10d
    35c7:	41 c1 e3 1d          	shl    $0x1d,%r11d
    35cb:	45 09 d3             	or     %r10d,%r11d
    35ce:	41 09 eb             	or     %ebp,%r11d
    35d1:	c1 ea 03             	shr    $0x3,%edx
    35d4:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    35da:	44 09 da             	or     %r11d,%edx
    35dd:	4a 8d 0c 07          	lea    (%rdi,%r8,1),%rcx
    35e1:	48 83 c1 40          	add    $0x40,%rcx
    35e5:	e9 a9 00 00 00       	jmp    3693 <f_8001161d0+0x3693>
    35ea:	4b 8b b4 08 80 30 00 	mov    0x3080(%r8,%r9,1),%rsi
    35f1:	00 
    35f2:	4b 8b bc 08 88 30 00 	mov    0x3088(%r8,%r9,1),%rdi
    35f9:	00 
    35fa:	48 89 7b 60          	mov    %rdi,0x60(%rbx)
    35fe:	4c 8b 93 d0 00 00 00 	mov    0xd0(%rbx),%r10
    3605:	49 89 32             	mov    %rsi,(%r10)
    3608:	49 89 7a 08          	mov    %rdi,0x8(%r10)
    360c:	4b 8b b4 08 90 30 00 	mov    0x3090(%r8,%r9,1),%rsi
    3613:	00 
    3614:	43 8b bc 08 98 30 00 	mov    0x3098(%r8,%r9,1),%edi
    361b:	00 
    361c:	4c 8b 83 c8 00 00 00 	mov    0xc8(%rbx),%r8
    3623:	41 89 78 08          	mov    %edi,0x8(%r8)
    3627:	49 89 30             	mov    %rsi,(%r8)
    362a:	44 8b 42 08          	mov    0x8(%rdx),%r8d
    362e:	48 8b 72 10          	mov    0x10(%rdx),%rsi
    3632:	48 89 73 50          	mov    %rsi,0x50(%rbx)
    3636:	31 ff                	xor    %edi,%edi
    3638:	45 31 c9             	xor    %r9d,%r9d
    363b:	45 31 d2             	xor    %r10d,%r10d
    363e:	45 89 c3             	mov    %r8d,%r11d
    3641:	41 29 cb             	sub    %ecx,%r11d
    3644:	41 0f 94 c1          	sete   %r9b
    3648:	41 0f 93 c2          	setae  %r10b
    364c:	48 0f 47 f9          	cmova  %rcx,%rdi
    3650:	c4 c2 20 f2 d0       	andn   %r8d,%r11d,%edx
    3655:	41 81 e3 00 00 00 80 	and    $0x80000000,%r11d
    365c:	41 c1 e1 1e          	shl    $0x1e,%r9d
    3660:	41 c1 e2 1d          	shl    $0x1d,%r10d
    3664:	45 09 ca             	or     %r9d,%r10d
    3667:	45 09 da             	or     %r11d,%r10d
    366a:	c1 ea 03             	shr    $0x3,%edx
    366d:	81 e2 00 00 00 10    	and    $0x10000000,%edx
    3673:	44 09 d2             	or     %r10d,%edx
    3676:	48 c7 43 48 f0 2d 00 	movq   $0x2df0,0x48(%rbx)
    367d:	00 
    367e:	48 89 7b 40          	mov    %rdi,0x40(%rbx)
    3682:	48 69 cf e0 3c 00 00 	imul   $0x3ce0,%rdi,%rcx
    3689:	48 01 f1             	add    %rsi,%rcx
    368c:	48 81 c1 f0 2d 00 00 	add    $0x2df0,%rcx
    3693:	48 89 93 10 01 00 00 	mov    %rdx,0x110(%rbx)
    369a:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    369e:	48 8b 51 20          	mov    0x20(%rcx),%rdx
    36a2:	48 85 d2             	test   %rdx,%rdx
    36a5:	74 0d                	je     36b4 <f_8001161d0+0x36b4>
    36a7:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    36ae:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    36b2:	eb 02                	jmp    36b6 <f_8001161d0+0x36b6>
    36b4:	31 d2                	xor    %edx,%edx
    36b6:	88 90 b0 00 00 00    	mov    %dl,0xb0(%rax)
    36bc:	48 8b 51 28          	mov    0x28(%rcx),%rdx
    36c0:	48 85 d2             	test   %rdx,%rdx
    36c3:	74 09                	je     36ce <f_8001161d0+0x36ce>
    36c5:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    36cc:	eb 02                	jmp    36d0 <f_8001161d0+0x36d0>
    36ce:	31 d2                	xor    %edx,%edx
    36d0:	88 90 b1 00 00 00    	mov    %dl,0xb1(%rax)
    36d6:	48 8b 51 30          	mov    0x30(%rcx),%rdx
    36da:	48 85 d2             	test   %rdx,%rdx
    36dd:	74 0d                	je     36ec <f_8001161d0+0x36ec>
    36df:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    36e6:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    36ea:	eb 02                	jmp    36ee <f_8001161d0+0x36ee>
    36ec:	31 d2                	xor    %edx,%edx
    36ee:	88 90 b2 00 00 00    	mov    %dl,0xb2(%rax)
    36f4:	48 8b 51 38          	mov    0x38(%rcx),%rdx
    36f8:	48 85 d2             	test   %rdx,%rdx
    36fb:	74 09                	je     3706 <f_8001161d0+0x3706>
    36fd:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3704:	eb 02                	jmp    3708 <f_8001161d0+0x3708>
    3706:	31 d2                	xor    %edx,%edx
    3708:	88 90 b3 00 00 00    	mov    %dl,0xb3(%rax)
    370e:	48 8b 51 40          	mov    0x40(%rcx),%rdx
    3712:	48 85 d2             	test   %rdx,%rdx
    3715:	74 0d                	je     3724 <f_8001161d0+0x3724>
    3717:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    371e:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    3722:	eb 02                	jmp    3726 <f_8001161d0+0x3726>
    3724:	31 d2                	xor    %edx,%edx
    3726:	88 90 b4 00 00 00    	mov    %dl,0xb4(%rax)
    372c:	48 8b 51 48          	mov    0x48(%rcx),%rdx
    3730:	48 85 d2             	test   %rdx,%rdx
    3733:	74 09                	je     373e <f_8001161d0+0x373e>
    3735:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    373c:	eb 02                	jmp    3740 <f_8001161d0+0x3740>
    373e:	31 d2                	xor    %edx,%edx
    3740:	88 90 b5 00 00 00    	mov    %dl,0xb5(%rax)
    3746:	48 8b 51 50          	mov    0x50(%rcx),%rdx
    374a:	48 85 d2             	test   %rdx,%rdx
    374d:	74 09                	je     3758 <f_8001161d0+0x3758>
    374f:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3756:	eb 02                	jmp    375a <f_8001161d0+0x375a>
    3758:	31 d2                	xor    %edx,%edx
    375a:	88 90 b6 00 00 00    	mov    %dl,0xb6(%rax)
    3760:	48 8b 51 58          	mov    0x58(%rcx),%rdx
    3764:	48 85 d2             	test   %rdx,%rdx
    3767:	74 0d                	je     3776 <f_8001161d0+0x3776>
    3769:	0f b6 92 c0 00 00 00 	movzbl 0xc0(%rdx),%edx
    3770:	48 89 53 48          	mov    %rdx,0x48(%rbx)
    3774:	eb 02                	jmp    3778 <f_8001161d0+0x3778>
    3776:	31 d2                	xor    %edx,%edx
    3778:	88 90 b7 00 00 00    	mov    %dl,0xb7(%rax)
    377e:	48 8b 49 60          	mov    0x60(%rcx),%rcx
    3782:	48 85 c9             	test   %rcx,%rcx
    3785:	74 10                	je     3797 <f_8001161d0+0x3797>
    3787:	0f b6 89 c0 00 00 00 	movzbl 0xc0(%rcx),%ecx
    378e:	48 89 4b 40          	mov    %rcx,0x40(%rbx)
    3792:	e9 3b f4 ff ff       	jmp    2bd2 <f_8001161d0+0x2bd2>
    3797:	31 c9                	xor    %ecx,%ecx
    3799:	e9 34 f4 ff ff       	jmp    2bd2 <f_8001161d0+0x2bd2>
