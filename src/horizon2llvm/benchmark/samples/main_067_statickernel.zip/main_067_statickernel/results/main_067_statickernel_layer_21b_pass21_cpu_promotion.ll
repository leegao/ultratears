; UltraTears chunk main_067_statickernel: 1 functions [0x8001161d0..0x8001177d8)
; ModuleID = 'main_067_statickernel'
source_filename = "main_067_statickernel"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.Cpu = type { [32 x i64], i64, i64, i64, i64, i64, i64, i64, ptr, i64, i64, [176 x i8], [32 x i128] }

@g_fnprof = external dso_local global i32, align 4
@g_icache_pc = external dso_local global [65536 x i64], align 8
@g_icache_fn = external dso_local global [65536 x ptr], align 8
declare dso_local void @fnprof_hit(i64, i64, i64)
declare dso_local void @rt_dispatch(ptr)
declare dso_local void @rt_svc(ptr, i32, i64)
declare dso_local void @rt_brk(ptr, i32, i64) noreturn
declare dso_local void @rt_udf(ptr, i64) noreturn
declare dso_local i64 @rt_ticks()
declare dso_local i32 @totk_drs_enabled()
declare dso_local void @rt_fpcr_write_ext(ptr, i64)
declare dso_local void @rt_sl_gen(ptr, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i32, i64)
declare dso_local void @rt_sl_addlp(ptr, i32, i32, i32, i32, i32, i32)
declare dso_local void @rt_sl_across(ptr, i32, i32, i32, i32, i32, i32)
declare dso_local void @rt_sl_pmull64(ptr, i32, i32, i32, i32)
declare dso_local void @rt_sv_tbl(ptr, i32, i32, i32, i32, i32, i32)
declare dso_local void @rt_sl_ldm(ptr, i32, i32, i32, i32, i32, i64)
declare dso_local void @rt_sl_stm(ptr, i32, i32, i32, i32, i32, i64)
declare dso_local void @rt_sl_ldr(ptr, i32, i32, i32, i32, i64)
declare dso_local void @rt_sl_lds(ptr, i32, i32, i32, i32, i64)
declare dso_local void @rt_sl_sts(ptr, i32, i32, i32, i32, i64)
declare dso_local void @rt_sv_aes(ptr, i32, i32, i32)
declare dso_local void @rt_sv_sha1hash(ptr, i32, i32, i32, i32)
declare dso_local void @rt_sv_sha256hash(ptr, i32, i32, i32, i32)
declare dso_local void @rt_sv_sha_misc(ptr, i32, i32, i32, i32)
declare dso_local i32 @rt_crc32(i32, i64, i32, i32) nounwind readnone speculatable willreturn
declare dso_local void @rt_fp_op_s(ptr, i32, i32, i32, i32)
declare dso_local void @rt_fp_op_d(ptr, i32, i32, i32, i32)
declare dso_local void @rt_fp_fma_s(ptr, i32, i32, i32, i32, i32, i32)
declare dso_local void @rt_fp_fma_d(ptr, i32, i32, i32, i32, i32, i32)
declare dso_local void @rt_fp_dp1(ptr, i32, i32, i32, i32)
declare dso_local i64 @rt_fp_cmp_s(ptr, i32, i32, i32)
declare dso_local i64 @rt_fp_cmp_d(ptr, i32, i32, i32)
declare dso_local i64 @rt_fp_toint(ptr, i32, i32, i32, i32, i32, i32)
declare dso_local void @rt_fp_fromint(ptr, i32, i32, i64, i32, i32, i32)
declare dso_local void @rt_fp_recpe(ptr, i32, i32, i32, i32)
declare dso_local void @rt_fp_recpx(ptr, i32, i32, i32)
declare dso_local void @rt_vec_fop(ptr, i32, i32, i32, i32, i32, i32, i32, i32)
declare dso_local void @rt_vec_fpair(ptr, i32, i32, i32, i32, i32, i32)
declare dso_local void @rt_vec_fcmp(ptr, i32, i32, i32, i32, i32, i32, i32, i32, i32)
declare dso_local void @rt_vec_frint(ptr, i32, i32, i32, i32, i32)
declare dso_local void @rt_vec_fcvt_int(ptr, i32, i32, i32, i32, i32, i32, i32, i32, i32)
declare dso_local void @rt_vec_frecpe(ptr, i32, i32, i32, i32, i32)
declare dso_local void @rt_vec_fcvtn(ptr, i32, i32, i32, i32, i32)
declare dso_local void @rt_vec_fcvtl(ptr, i32, i32, i32, i32)
declare dso_local void @rt_sv_fred_s(ptr, i32, i32, i32)
declare dso_local void @rt_scalar_fpair(ptr, i32, i32, i32, i32)
declare dso_local void @rt_indexed_fp(ptr, i32, i32, i32, i32, i32, i32, i32, i32, i32)
declare i32 @llvm.ctlz.i32(i32, i1 immarg) nounwind readnone speculatable willreturn
declare i64 @llvm.ctlz.i64(i64, i1 immarg) nounwind readnone speculatable willreturn
declare <16 x i8> @llvm.ctlz.v16i8(<16 x i8>, i1 immarg) nounwind readnone speculatable willreturn
declare <8 x i16> @llvm.ctlz.v8i16(<8 x i16>, i1 immarg) nounwind readnone speculatable willreturn
declare <4 x i32> @llvm.ctlz.v4i32(<4 x i32>, i1 immarg) nounwind readnone speculatable willreturn
declare <16 x i8> @llvm.ctpop.v16i8(<16 x i8>) nounwind readnone speculatable willreturn
declare <8 x i8> @llvm.ctpop.v8i8(<8 x i8>) nounwind readnone speculatable willreturn
declare i32 @llvm.bitreverse.i32(i32) nounwind readnone speculatable willreturn
declare i64 @llvm.bitreverse.i64(i64) nounwind readnone speculatable willreturn
declare <16 x i8> @llvm.bitreverse.v16i8(<16 x i8>) nounwind readnone speculatable willreturn
declare i32 @llvm.bswap.i32(i32) nounwind readnone speculatable willreturn
declare i64 @llvm.bswap.i64(i64) nounwind readnone speculatable willreturn
declare i32 @llvm.fshr.i32(i32, i32, i32) nounwind readnone speculatable willreturn
declare i64 @llvm.fshr.i64(i64, i64, i64) nounwind readnone speculatable willreturn
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) argmemonly nounwind willreturn writeonly
declare float @llvm.fma.f32(float, float, float) nounwind readnone speculatable willreturn
declare double @llvm.fma.f64(double, double, double) nounwind readnone speculatable willreturn
declare <4 x float> @llvm.fma.v4f32(<4 x float>, <4 x float>, <4 x float>) nounwind readnone speculatable willreturn
declare <2 x double> @llvm.fma.v2f64(<2 x double>, <2 x double>, <2 x double>) nounwind readnone speculatable willreturn
declare float @llvm.sqrt.f32(float) nounwind readnone speculatable willreturn
declare double @llvm.sqrt.f64(double) nounwind readnone speculatable willreturn
declare <4 x float> @llvm.sqrt.v4f32(<4 x float>) nounwind readnone speculatable willreturn
declare <2 x double> @llvm.sqrt.v2f64(<2 x double>) nounwind readnone speculatable willreturn
declare float @llvm.fabs.f32(float) nounwind readnone speculatable willreturn
declare double @llvm.fabs.f64(double) nounwind readnone speculatable willreturn
declare <4 x float> @llvm.fabs.v4f32(<4 x float>) nounwind readnone speculatable willreturn
declare <2 x double> @llvm.fabs.v2f64(<2 x double>) nounwind readnone speculatable willreturn
declare float @llvm.maxnum.f32(float, float) nounwind readnone speculatable willreturn
declare double @llvm.maxnum.f64(double, double) nounwind readnone speculatable willreturn
declare <4 x float> @llvm.maxnum.v4f32(<4 x float>, <4 x float>) nounwind readnone speculatable willreturn
declare <2 x double> @llvm.maxnum.v2f64(<2 x double>, <2 x double>) nounwind readnone speculatable willreturn
declare float @llvm.minnum.f32(float, float) nounwind readnone speculatable willreturn
declare double @llvm.minnum.f64(double, double) nounwind readnone speculatable willreturn
declare <4 x float> @llvm.minnum.v4f32(<4 x float>, <4 x float>) nounwind readnone speculatable willreturn
declare <2 x double> @llvm.minnum.v2f64(<2 x double>, <2 x double>) nounwind readnone speculatable willreturn
declare float @llvm.rint.f32(float) nounwind readnone speculatable willreturn
declare double @llvm.rint.f64(double) nounwind readnone speculatable willreturn
declare <4 x float> @llvm.rint.v4f32(<4 x float>) nounwind readnone speculatable willreturn
declare <2 x double> @llvm.rint.v2f64(<2 x double>) nounwind readnone speculatable willreturn
declare float @llvm.nearbyint.f32(float) nounwind readnone speculatable willreturn
declare double @llvm.nearbyint.f64(double) nounwind readnone speculatable willreturn
declare <4 x float> @llvm.nearbyint.v4f32(<4 x float>) nounwind readnone speculatable willreturn
declare <2 x double> @llvm.nearbyint.v2f64(<2 x double>) nounwind readnone speculatable willreturn
declare float @llvm.ceil.f32(float) nounwind readnone speculatable willreturn
declare double @llvm.ceil.f64(double) nounwind readnone speculatable willreturn
declare <4 x float> @llvm.ceil.v4f32(<4 x float>) nounwind readnone speculatable willreturn
declare <2 x double> @llvm.ceil.v2f64(<2 x double>) nounwind readnone speculatable willreturn
declare float @llvm.floor.f32(float) nounwind readnone speculatable willreturn
declare double @llvm.floor.f64(double) nounwind readnone speculatable willreturn
declare <4 x float> @llvm.floor.v4f32(<4 x float>) nounwind readnone speculatable willreturn
declare <2 x double> @llvm.floor.v2f64(<2 x double>) nounwind readnone speculatable willreturn
declare float @llvm.trunc.f32(float) nounwind readnone speculatable willreturn
declare double @llvm.trunc.f64(double) nounwind readnone speculatable willreturn
declare <4 x float> @llvm.trunc.v4f32(<4 x float>) nounwind readnone speculatable willreturn
declare <2 x double> @llvm.trunc.v2f64(<2 x double>) nounwind readnone speculatable willreturn
declare float @llvm.round.f32(float) nounwind readnone speculatable willreturn
declare double @llvm.round.f64(double) nounwind readnone speculatable willreturn
declare <4 x float> @llvm.round.v4f32(<4 x float>) nounwind readnone speculatable willreturn
declare <2 x double> @llvm.round.v2f64(<2 x double>) nounwind readnone speculatable willreturn
declare i32 @llvm.fptosi.sat.i32.f32(float) nounwind readnone speculatable willreturn
declare i64 @llvm.fptosi.sat.i64.f32(float) nounwind readnone speculatable willreturn
declare i32 @llvm.fptosi.sat.i32.f64(double) nounwind readnone speculatable willreturn
declare i64 @llvm.fptosi.sat.i64.f64(double) nounwind readnone speculatable willreturn
declare i32 @llvm.fptoui.sat.i32.f32(float) nounwind readnone speculatable willreturn
declare i64 @llvm.fptoui.sat.i64.f32(float) nounwind readnone speculatable willreturn
declare i32 @llvm.fptoui.sat.i32.f64(double) nounwind readnone speculatable willreturn
declare i64 @llvm.fptoui.sat.i64.f64(double) nounwind readnone speculatable willreturn
declare <4 x i32> @llvm.fptosi.sat.v4i32.v4f32(<4 x float>) nounwind readnone speculatable willreturn
declare <2 x i64> @llvm.fptosi.sat.v2i64.v2f64(<2 x double>) nounwind readnone speculatable willreturn
declare <4 x i32> @llvm.fptoui.sat.v4i32.v4f32(<4 x float>) nounwind readnone speculatable willreturn
declare <2 x i64> @llvm.fptoui.sat.v2i64.v2f64(<2 x double>) nounwind readnone speculatable willreturn
declare <16 x i8> @llvm.sadd.sat.v16i8(<16 x i8>, <16 x i8>) nounwind readnone speculatable willreturn
declare <8 x i16> @llvm.sadd.sat.v8i16(<8 x i16>, <8 x i16>) nounwind readnone speculatable willreturn
declare <4 x i32> @llvm.sadd.sat.v4i32(<4 x i32>, <4 x i32>) nounwind readnone speculatable willreturn
declare <2 x i64> @llvm.sadd.sat.v2i64(<2 x i64>, <2 x i64>) nounwind readnone speculatable willreturn
declare <16 x i8> @llvm.uadd.sat.v16i8(<16 x i8>, <16 x i8>) nounwind readnone speculatable willreturn
declare <8 x i16> @llvm.uadd.sat.v8i16(<8 x i16>, <8 x i16>) nounwind readnone speculatable willreturn
declare <4 x i32> @llvm.uadd.sat.v4i32(<4 x i32>, <4 x i32>) nounwind readnone speculatable willreturn
declare <2 x i64> @llvm.uadd.sat.v2i64(<2 x i64>, <2 x i64>) nounwind readnone speculatable willreturn
declare <16 x i8> @llvm.ssub.sat.v16i8(<16 x i8>, <16 x i8>) nounwind readnone speculatable willreturn
declare <8 x i16> @llvm.ssub.sat.v8i16(<8 x i16>, <8 x i16>) nounwind readnone speculatable willreturn
declare <4 x i32> @llvm.ssub.sat.v4i32(<4 x i32>, <4 x i32>) nounwind readnone speculatable willreturn
declare <2 x i64> @llvm.ssub.sat.v2i64(<2 x i64>, <2 x i64>) nounwind readnone speculatable willreturn
declare <16 x i8> @llvm.usub.sat.v16i8(<16 x i8>, <16 x i8>) nounwind readnone speculatable willreturn
declare <8 x i16> @llvm.usub.sat.v8i16(<8 x i16>, <8 x i16>) nounwind readnone speculatable willreturn
declare <4 x i32> @llvm.usub.sat.v4i32(<4 x i32>, <4 x i32>) nounwind readnone speculatable willreturn
declare <2 x i64> @llvm.usub.sat.v2i64(<2 x i64>, <2 x i64>) nounwind readnone speculatable willreturn
declare <16 x i8> @llvm.smax.v16i8(<16 x i8>, <16 x i8>) nounwind readnone speculatable willreturn
declare <8 x i16> @llvm.smax.v8i16(<8 x i16>, <8 x i16>) nounwind readnone speculatable willreturn
declare <4 x i32> @llvm.smax.v4i32(<4 x i32>, <4 x i32>) nounwind readnone speculatable willreturn
declare <16 x i8> @llvm.smin.v16i8(<16 x i8>, <16 x i8>) nounwind readnone speculatable willreturn
declare <8 x i16> @llvm.smin.v8i16(<8 x i16>, <8 x i16>) nounwind readnone speculatable willreturn
declare <4 x i32> @llvm.smin.v4i32(<4 x i32>, <4 x i32>) nounwind readnone speculatable willreturn
declare <16 x i8> @llvm.umax.v16i8(<16 x i8>, <16 x i8>) nounwind readnone speculatable willreturn
declare <8 x i16> @llvm.umax.v8i16(<8 x i16>, <8 x i16>) nounwind readnone speculatable willreturn
declare <4 x i32> @llvm.umax.v4i32(<4 x i32>, <4 x i32>) nounwind readnone speculatable willreturn
declare <16 x i8> @llvm.umin.v16i8(<16 x i8>, <16 x i8>) nounwind readnone speculatable willreturn
declare <8 x i16> @llvm.umin.v8i16(<8 x i16>, <8 x i16>) nounwind readnone speculatable willreturn
declare <4 x i32> @llvm.umin.v4i32(<4 x i32>, <4 x i32>) nounwind readnone speculatable willreturn
declare i8 @llvm.vector.reduce.add.v16i8(<16 x i8>) nounwind readnone speculatable willreturn
declare i8 @llvm.vector.reduce.add.v8i8(<8 x i8>) nounwind readnone speculatable willreturn
declare i16 @llvm.vector.reduce.add.v16i16(<16 x i16>) nounwind readnone speculatable willreturn
declare i16 @llvm.vector.reduce.add.v8i16(<8 x i16>) nounwind readnone speculatable willreturn
declare i16 @llvm.vector.reduce.add.v4i16(<4 x i16>) nounwind readnone speculatable willreturn
declare i32 @llvm.vector.reduce.add.v8i32(<8 x i32>) nounwind readnone speculatable willreturn
declare i32 @llvm.vector.reduce.add.v4i32(<4 x i32>) nounwind readnone speculatable willreturn
declare i64 @llvm.vector.reduce.add.v4i64(<4 x i64>) nounwind readnone speculatable willreturn
declare i8 @llvm.vector.reduce.smax.v16i8(<16 x i8>) nounwind readnone speculatable willreturn
declare i8 @llvm.vector.reduce.smax.v8i8(<8 x i8>) nounwind readnone speculatable willreturn
declare i16 @llvm.vector.reduce.smax.v8i16(<8 x i16>) nounwind readnone speculatable willreturn
declare i16 @llvm.vector.reduce.smax.v4i16(<4 x i16>) nounwind readnone speculatable willreturn
declare i32 @llvm.vector.reduce.smax.v4i32(<4 x i32>) nounwind readnone speculatable willreturn
declare i8 @llvm.vector.reduce.umax.v16i8(<16 x i8>) nounwind readnone speculatable willreturn
declare i8 @llvm.vector.reduce.umax.v8i8(<8 x i8>) nounwind readnone speculatable willreturn
declare i16 @llvm.vector.reduce.umax.v8i16(<8 x i16>) nounwind readnone speculatable willreturn
declare i16 @llvm.vector.reduce.umax.v4i16(<4 x i16>) nounwind readnone speculatable willreturn
declare i32 @llvm.vector.reduce.umax.v4i32(<4 x i32>) nounwind readnone speculatable willreturn
declare i8 @llvm.vector.reduce.smin.v16i8(<16 x i8>) nounwind readnone speculatable willreturn
declare i8 @llvm.vector.reduce.smin.v8i8(<8 x i8>) nounwind readnone speculatable willreturn
declare i16 @llvm.vector.reduce.smin.v8i16(<8 x i16>) nounwind readnone speculatable willreturn
declare i16 @llvm.vector.reduce.smin.v4i16(<4 x i16>) nounwind readnone speculatable willreturn
declare i32 @llvm.vector.reduce.smin.v4i32(<4 x i32>) nounwind readnone speculatable willreturn
declare i8 @llvm.vector.reduce.umin.v16i8(<16 x i8>) nounwind readnone speculatable willreturn
declare i8 @llvm.vector.reduce.umin.v8i8(<8 x i8>) nounwind readnone speculatable willreturn
declare i16 @llvm.vector.reduce.umin.v8i16(<8 x i16>) nounwind readnone speculatable willreturn
declare i16 @llvm.vector.reduce.umin.v4i16(<4 x i16>) nounwind readnone speculatable willreturn
declare i32 @llvm.vector.reduce.umin.v4i32(<4 x i32>) nounwind readnone speculatable willreturn

declare dso_local void @f_8000ef570(ptr)
declare dso_local void @f_8001177d8(ptr)
declare dso_local void @f_800117868(ptr)
declare dso_local void @f_802843244(ptr)
declare dso_local void @f_802844c70(ptr)
declare dso_local void @f_802844d84(ptr)
declare dso_local void @f_802855d74(ptr)
declare dso_local void @f_802ba41d0(ptr)

define dso_local void @f_8001161d0(ptr noalias noundef nonnull align 16 dereferenceable(1024) %c) nounwind {
entry:
  %loc_x27 = alloca i64, align 8
  %loc_x29 = alloca i64, align 8
  %loc_sp = alloca i64, align 8
  %ldp7591 = getelementptr inbounds i8, ptr %c, i64 216
  %ldv7592 = load i64, ptr %ldp7591, align 8, !alias.scope !3, !noalias !4
  store i64 %ldv7592, ptr %loc_x27, align 8
  %ldp7593 = getelementptr inbounds i8, ptr %c, i64 232
  %ldv7594 = load i64, ptr %ldp7593, align 8, !alias.scope !3, !noalias !4
  store i64 %ldv7594, ptr %loc_x29, align 8
  %ldp7595 = getelementptr inbounds i8, ptr %c, i64 256
  %ldv7596 = load i64, ptr %ldp7595, align 8, !alias.scope !3, !noalias !4
  store i64 %ldv7596, ptr %loc_sp, align 8
  ; [ProfileGuidedEntryHookElimPass] elided @g_fnprof hook
  br label %L_8001161d0
L_8001161d0:
  ; @pc 0x8001161d0 word 0xd104c3ff
  %r5 = load i64, ptr %loc_sp, align 8
  %t6 = sub i64 %r5, 304
  %wp7 = getelementptr inbounds i8, ptr %c, i64 256
  store i64 %t6, ptr %wp7, align 8, !alias.scope !3, !noalias !4
  store i64 %t6, ptr %loc_sp, align 8
  ; @pc 0x8001161d4 word 0xa90d7bfd
  %t9 = add i64 %t6, 208
  %t10 = add i64 %t9, 8
  %r11 = load i64, ptr %loc_x29, align 8
  %gmp12 = inttoptr i64 %t9 to ptr
  store i64 %r11, ptr %gmp12, align 8, !alias.scope !6, !noalias !3
  %r13.p = getelementptr inbounds i8, ptr %c, i64 240
  %r13 = load i64, ptr %r13.p, align 8, !alias.scope !3, !noalias !4
  %gmp14 = inttoptr i64 %t10 to ptr
  store i64 %r13, ptr %gmp14, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001161d8 word 0xa90e6ffc
  %t16 = add i64 %t6, 224
  %t17 = add i64 %t16, 8
  %r18.p = getelementptr inbounds i8, ptr %c, i64 224
  %r18 = load i64, ptr %r18.p, align 8, !alias.scope !3, !noalias !4
  %gmp19 = inttoptr i64 %t16 to ptr
  store i64 %r18, ptr %gmp19, align 8, !alias.scope !6, !noalias !3
  %r20 = load i64, ptr %loc_x27, align 8
  %gmp21 = inttoptr i64 %t17 to ptr
  store i64 %r20, ptr %gmp21, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001161dc word 0xa90f67fa
  %t23 = add i64 %t6, 240
  %t24 = add i64 %t23, 8
  %r25.p = getelementptr inbounds i8, ptr %c, i64 208
  %r25 = load i64, ptr %r25.p, align 8, !alias.scope !3, !noalias !4
  %gmp26 = inttoptr i64 %t23 to ptr
  store i64 %r25, ptr %gmp26, align 8, !alias.scope !6, !noalias !3
  %r27.p = getelementptr inbounds i8, ptr %c, i64 200
  %r27 = load i64, ptr %r27.p, align 8, !alias.scope !3, !noalias !4
  %gmp28 = inttoptr i64 %t24 to ptr
  store i64 %r27, ptr %gmp28, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001161e0 word 0xa9105ff8
  %t30 = add i64 %t6, 256
  %t31 = add i64 %t30, 8
  %r32.p = getelementptr inbounds i8, ptr %c, i64 192
  %r32 = load i64, ptr %r32.p, align 8, !alias.scope !3, !noalias !4
  %gmp33 = inttoptr i64 %t30 to ptr
  store i64 %r32, ptr %gmp33, align 8, !alias.scope !6, !noalias !3
  %r34.p = getelementptr inbounds i8, ptr %c, i64 184
  %r34 = load i64, ptr %r34.p, align 8, !alias.scope !3, !noalias !4
  %gmp35 = inttoptr i64 %t31 to ptr
  store i64 %r34, ptr %gmp35, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001161e4 word 0xa91157f6
  %t37 = add i64 %t6, 272
  %t38 = add i64 %t37, 8
  %r39.p = getelementptr inbounds i8, ptr %c, i64 176
  %r39 = load i64, ptr %r39.p, align 8, !alias.scope !3, !noalias !4
  %gmp40 = inttoptr i64 %t37 to ptr
  store i64 %r39, ptr %gmp40, align 8, !alias.scope !6, !noalias !3
  %r41.p = getelementptr inbounds i8, ptr %c, i64 168
  %r41 = load i64, ptr %r41.p, align 8, !alias.scope !3, !noalias !4
  %gmp42 = inttoptr i64 %t38 to ptr
  store i64 %r41, ptr %gmp42, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001161e8 word 0xa9124ff4
  %t44 = add i64 %t6, 288
  %t45 = add i64 %t44, 8
  %r46.p = getelementptr inbounds i8, ptr %c, i64 160
  %r46 = load i64, ptr %r46.p, align 8, !alias.scope !3, !noalias !4
  %gmp47 = inttoptr i64 %t44 to ptr
  store i64 %r46, ptr %gmp47, align 8, !alias.scope !6, !noalias !3
  %r48.p = getelementptr inbounds i8, ptr %c, i64 152
  %r48 = load i64, ptr %r48.p, align 8, !alias.scope !3, !noalias !4
  %gmp49 = inttoptr i64 %t45 to ptr
  store i64 %r48, ptr %gmp49, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001161ec word 0x910343fd
  %t51 = add i64 %t6, 208
  %wp52 = getelementptr inbounds i8, ptr %c, i64 232
  store i64 %t51, ptr %wp52, align 8, !alias.scope !3, !noalias !4
  store i64 %t51, ptr %loc_x29, align 8
  ; @pc 0x8001161f0 word 0xaa0203f5
  %r53.p = getelementptr inbounds i8, ptr %c, i64 16
  %r53 = load i64, ptr %r53.p, align 8, !alias.scope !3, !noalias !4
  %wp55 = getelementptr inbounds i8, ptr %c, i64 168
  store i64 %r53, ptr %wp55, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001161f4 word 0x52852288
  ; @pc 0x8001161f8 word 0xaa0103f3
  %r58.p = getelementptr inbounds i8, ptr %c, i64 8
  %r58 = load i64, ptr %r58.p, align 8, !alias.scope !3, !noalias !4
  %wp60 = getelementptr inbounds i8, ptr %c, i64 152
  store i64 %r58, ptr %wp60, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001161fc word 0xaa0003f4
  %r61.p = getelementptr inbounds i8, ptr %c, i64 0
  %r61 = load i64, ptr %r61.p, align 8, !alias.scope !3, !noalias !4
  %wp63 = getelementptr inbounds i8, ptr %c, i64 160
  store i64 %r61, ptr %wp63, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116200 word 0x8b08002d
  %t66 = add i64 %r58, 10516
  %wp67 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 %t66, ptr %wp67, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116204 word 0x710082bf
  %c69 = trunc i64 %r53 to i32
  ; @pc 0x800116208 word 0x540000a2
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond91 = icmp uge i32 %c69, 32
  br i1 %cond91, label %L_80011621c, label %L_80011620c_ft
L_80011621c:
  ; @pc 0x80011621c word 0x71004abf
  %r112.p = getelementptr inbounds i8, ptr %c, i64 168
  %r112 = load i64, ptr %r112.p, align 8, !alias.scope !3, !noalias !4
  %c113 = trunc i64 %r112 to i32
  ; @pc 0x800116220 word 0x5400abc0
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond135 = icmp eq i32 %c113, 18
  br i1 %cond135, label %L_800117798, label %L_800116224_ft
L_800116228:
  ; @pc 0x800116228 word 0x39800daa
  %r139.p = getelementptr inbounds i8, ptr %c, i64 104
  %r139 = load i64, ptr %r139.p, align 8, !alias.scope !3, !noalias !4
  %t140 = add i64 %r139, 3
  %gmp141 = inttoptr i64 %t140 to ptr
  %gml142 = load i8, ptr %gmp141, align 1, !alias.scope !4, !noalias !3
  %c143 = sext i8 %gml142 to i64
  %wp144 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 %c143, ptr %wp144, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011622c word 0x910003f8
  %r145 = load i64, ptr %loc_sp, align 8
  %t146 = add i64 %r145, 0
  %wp147 = getelementptr inbounds i8, ptr %c, i64 192
  store i64 %t146, ptr %wp147, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116230 word 0xb973928b
  %r148.p = getelementptr inbounds i8, ptr %c, i64 160
  %r148 = load i64, ptr %r148.p, align 8, !alias.scope !3, !noalias !4
  %t149 = add i64 %r148, 13200
  %gmp150 = inttoptr i64 %t149 to ptr
  %gml151 = load i32, ptr %gmp150, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116234 word 0x6b0a017f
  %c157 = trunc i64 %c143 to i32
  ; @pc 0x800116238 word 0xf959ce89
  %t179 = add i64 %r148, 13208
  %gmp180 = inttoptr i64 %t179 to ptr
  %gml181 = load i64, ptr %gmp180, align 1, !alias.scope !4, !noalias !3
  %wp182 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %gml181, ptr %wp182, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011623c word 0x5400a009
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond184 = icmp ule i32 %gml151, %c157
  br i1 %cond184, label %L_80011763c, label %L_800116240
L_800116240:
  ; @pc 0x800116240 word 0x5280e90b
  ; @pc 0x800116244 word 0xd2c002ec
  ; @pc 0x800116248 word 0x9b2b2549
  %r194.p = getelementptr inbounds i8, ptr %c, i64 80
  %r194 = load i64, ptr %r194.p, align 8, !alias.scope !3, !noalias !4
  %c195 = trunc i64 %r194 to i32
  %c196 = sext i32 %c195 to i64
  %c198 = trunc i64 1864 to i32
  %c199 = sext i32 %c198 to i64
  %t200 = mul i64 %c196, %c199
  %r201.p = getelementptr inbounds i8, ptr %c, i64 72
  %r201 = load i64, ptr %r201.p, align 8, !alias.scope !3, !noalias !4
  %t202 = add i64 %r201, %t200
  ; @pc 0x80011624c word 0x529fffef
  ; @pc 0x800116250 word 0x9280000e
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7279 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 18446744073709551615, ptr %cwp7279, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116254 word 0xb2607ff0
  ; @pc 0x800116258 word 0xa9007fec
  %r209 = load i64, ptr %loc_sp, align 8
  %t210 = add i64 %r209, 8
  %gmp212 = inttoptr i64 %r209 to ptr
  store i64 98784247808, ptr %gmp212, align 8, !alias.scope !6, !noalias !3
  %gmp213 = inttoptr i64 %t210 to ptr
  store i64 0, ptr %gmp213, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x80011625c word 0xd2c0002c
  ; @pc 0x800116260 word 0xa9013bef
  %t216 = add i64 %r209, 16
  %t217 = add i64 %t216, 8
  %gmp219 = inttoptr i64 %t216 to ptr
  store i64 65535, ptr %gmp219, align 8, !alias.scope !6, !noalias !3
  %gmp221 = inttoptr i64 %t217 to ptr
  store i64 18446744073709551615, ptr %gmp221, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116264 word 0x1280000f
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7281 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 4294967295, ptr %cwp7281, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116268 word 0xb2091bea
  ; @pc 0x80011626c word 0xa90243ec
  %t227 = add i64 %r209, 32
  %t228 = add i64 %t227, 8
  %gmp230 = inttoptr i64 %t227 to ptr
  store i64 4294967296, ptr %gmp230, align 8, !alias.scope !6, !noalias !3
  %gmp232 = inttoptr i64 %t228 to ptr
  store i64 18446744069414584320, ptr %gmp232, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116270 word 0x9107a129
  %t234 = add i64 %t202, 488
  ; @pc 0x800116274 word 0x8b082137
  %r237.p = getelementptr inbounds i8, ptr %c, i64 64
  %r237 = load i64, ptr %r237.p, align 8, !alias.scope !3, !noalias !4
  %t238 = shl i64 %r237, 8
  %t239 = add i64 %t234, %t238
  %wp240 = getelementptr inbounds i8, ptr %c, i64 184
  store i64 %t239, ptr %wp240, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116278 word 0xb001c1a9
  ; @pc 0x80011627c word 0xa9032bef
  %t243 = add i64 %r209, 48
  %t244 = add i64 %t243, 8
  %gmp246 = inttoptr i64 %t243 to ptr
  store i64 4294967295, ptr %gmp246, align 8, !alias.scope !6, !noalias !3
  %gmp248 = inttoptr i64 %t244 to ptr
  store i64 4575657222473777152, ptr %gmp248, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116280 word 0x92b0100b
  ; @pc 0x800116284 word 0xf2efefeb
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7284 = getelementptr inbounds i8, ptr %c, i64 88
  store i64 9187343237679939583, ptr %cwp7284, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116288 word 0xf001c22c
  ; @pc 0x80011628c word 0x710086bf
  %r255.p = getelementptr inbounds i8, ptr %c, i64 168
  %r255 = load i64, ptr %r255.p, align 8, !alias.scope !3, !noalias !4
  %c256 = trunc i64 %r255 to i32
  ; @pc 0x800116290 word 0xa9047fea
  %t278 = add i64 %r209, 64
  %t279 = add i64 %t278, 8
  %gmp281 = inttoptr i64 %t278 to ptr
  store i64 4575657222473777152, ptr %gmp281, align 8, !alias.scope !6, !noalias !3
  %gmp282 = inttoptr i64 %t279 to ptr
  store i64 0, ptr %gmp282, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116294 word 0x9001c24a
  ; @pc 0x800116298 word 0xf942254a
  %t285 = add i64 34419892224, 1096
  %gmp286 = inttoptr i64 %t285 to ptr
  %gml287 = load i64, ptr %gmp286, align 8, !alias.scope !4, !noalias !3
  %wp288 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 %gml287, ptr %wp288, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011629c word 0xf945bd29
  %t290 = add i64 34419814400, 2936
  %gmp291 = inttoptr i64 %t290 to ptr
  %gml292 = load i64, ptr %gmp291, align 8, !alias.scope !4, !noalias !3
  ; @pc 0x8001162a0 word 0x91004148
  %t295 = add i64 %gml287, 16
  ; @pc 0x8001162a4 word 0xf9002be8
  %t298 = add i64 %r209, 80
  %gmp300 = inttoptr i64 %t298 to ptr
  store i64 %t295, ptr %gmp300, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001162a8 word 0xd2e7f008
  ; @pc 0x8001162ac word 0xf9003be9
  %t303 = add i64 %r209, 112
  %gmp305 = inttoptr i64 %t303 to ptr
  store i64 %gml292, ptr %gmp305, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001162b0 word 0xb2087be9
  ; @pc 0x8001162b4 word 0xf946418c
  %t309 = add i64 34419888128, 3200
  %gmp310 = inttoptr i64 %t309 to ptr
  %gml311 = load i64, ptr %gmp310, align 8, !alias.scope !4, !noalias !3
  %wp312 = getelementptr inbounds i8, ptr %c, i64 96
  store i64 %gml311, ptr %wp312, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001162b8 word 0x91004190
  %t314 = add i64 %gml311, 16
  %wp315 = getelementptr inbounds i8, ptr %c, i64 128
  store i64 %t314, ptr %wp315, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001162bc word 0xa907a7eb
  %t317 = add i64 %r209, 120
  %t318 = add i64 %t317, 8
  %gmp320 = inttoptr i64 %t317 to ptr
  store i64 9187343237679939583, ptr %gmp320, align 8, !alias.scope !6, !noalias !3
  %gmp322 = inttoptr i64 %t318 to ptr
  store i64 18410715276682199039, ptr %gmp322, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001162c0 word 0xf80a4308
  %r323.p = getelementptr inbounds i8, ptr %c, i64 192
  %r323 = load i64, ptr %r323.p, align 8, !alias.scope !3, !noalias !4
  %t324 = add i64 %r323, 164
  %gmp326 = inttoptr i64 %t324 to ptr
  store i64 4575657221408423936, ptr %gmp326, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001162c4 word 0xf001c228
  ; @pc 0x8001162c8 word 0xf945c908
  %t329 = add i64 34419888128, 2960
  %gmp330 = inttoptr i64 %t329 to ptr
  %gml331 = load i64, ptr %gmp330, align 8, !alias.scope !4, !noalias !3
  ; @pc 0x8001162cc word 0xf9004fe9
  %t334 = add i64 %r209, 152
  %gmp336 = inttoptr i64 %t334 to ptr
  store i64 18410715276682199039, ptr %gmp336, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001162d0 word 0xb9400108
  %gmp338 = inttoptr i64 %gml331 to ptr
  %gml339 = load i32, ptr %gmp338, align 1, !alias.scope !4, !noalias !3
  %c340 = zext i32 %gml339 to i64
  %wp341 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %c340, ptr %wp341, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001162d4 word 0xa908aff0
  %t343 = add i64 %r209, 136
  %t344 = add i64 %t343, 8
  %gmp346 = inttoptr i64 %t343 to ptr
  store i64 %t314, ptr %gmp346, align 8, !alias.scope !6, !noalias !3
  %gmp348 = inttoptr i64 %t344 to ptr
  store i64 9187343237679939583, ptr %gmp348, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001162d8 word 0xf9005bff
  %t350 = add i64 %r209, 176
  %gmp351 = inttoptr i64 %t350 to ptr
  store i64 0, ptr %gmp351, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001162dc word 0x3902e3ff
  %t353 = add i64 %r209, 184
  %gmp355 = inttoptr i64 %t353 to ptr
  store i8 0, ptr %gmp355, align 1, !alias.scope !6, !noalias !3
  ; @pc 0x8001162e0 word 0xb900bfff
  %t357 = add i64 %r209, 188
  %gmp358 = inttoptr i64 %t357 to ptr
  store i32 0, ptr %gmp358, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001162e4 word 0xb900a3e8
  %t360 = add i64 %r209, 160
  %gmp363 = inttoptr i64 %t360 to ptr
  store i32 %gml339, ptr %gmp363, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001162e8 word 0x54006768
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond365 = icmp ugt i32 %c256, 33
  br i1 %cond365, label %L_800116fd4, label %L_8001162ec_ft
L_80011631c:
  ; @pc 0x80011631c word 0x7959ca92
  %r410.p = getelementptr inbounds i8, ptr %c, i64 160
  %r410 = load i64, ptr %r410.p, align 8, !alias.scope !3, !noalias !4
  %t411 = add i64 %r410, 3300
  %gmp412 = inttoptr i64 %t411 to ptr
  %gml413 = load i16, ptr %gmp412, align 1, !alias.scope !4, !noalias !3
  %c414 = zext i16 %gml413 to i64
  %wp415 = getelementptr inbounds i8, ptr %c, i64 144
  store i64 %c414, ptr %wp415, align 8, !alias.scope !3, !noalias !4
  br label %L_800116320
L_800116320:
  ; @pc 0x800116320 word 0x510006ad
  %r416.p = getelementptr inbounds i8, ptr %c, i64 168
  %r416 = load i64, ptr %r416.p, align 8, !alias.scope !3, !noalias !4
  %c417 = trunc i64 %r416 to i32
  %t418 = sub i32 %c417, 1
  %c419 = zext i32 %t418 to i64
  %wp420 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 %c419, ptr %wp420, align 8, !alias.scope !3, !noalias !4
  br label %L_800116324
L_800116324:
  ; @pc 0x800116324 word 0x9100414a
  %r421.p = getelementptr inbounds i8, ptr %c, i64 80
  %r421 = load i64, ptr %r421.p, align 8, !alias.scope !3, !noalias !4
  %t422 = add i64 %r421, 16
  %wp423 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 %t422, ptr %wp423, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116328 word 0x3940226f
  %r424.p = getelementptr inbounds i8, ptr %c, i64 152
  %r424 = load i64, ptr %r424.p, align 8, !alias.scope !3, !noalias !4
  %t425 = add i64 %r424, 8
  %gmp426 = inttoptr i64 %t425 to ptr
  %gml427 = load i8, ptr %gmp426, align 1, !alias.scope !4, !noalias !3
  %c428 = zext i8 %gml427 to i64
  %wp429 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 %c428, ptr %wp429, align 8, !alias.scope !3, !noalias !4
  br label %L_80011632c
L_80011632c:
  ; @pc 0x80011632c word 0xa904abff
  %r430 = load i64, ptr %loc_sp, align 8
  %t431 = add i64 %r430, 72
  %t432 = add i64 %t431, 8
  %gmp433 = inttoptr i64 %t431 to ptr
  store i64 0, ptr %gmp433, align 8, !alias.scope !6, !noalias !3
  %r434.p = getelementptr inbounds i8, ptr %c, i64 80
  %r434 = load i64, ptr %r434.p, align 8, !alias.scope !3, !noalias !4
  %gmp435 = inttoptr i64 %t432 to ptr
  store i64 %r434, ptr %gmp435, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116330 word 0xb94dfe89
  %r436.p = getelementptr inbounds i8, ptr %c, i64 160
  %r436 = load i64, ptr %r436.p, align 8, !alias.scope !3, !noalias !4
  %t437 = add i64 %r436, 3580
  %gmp438 = inttoptr i64 %t437 to ptr
  %gml439 = load i32, ptr %gmp438, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116334 word 0x110022aa
  %r442.p = getelementptr inbounds i8, ptr %c, i64 168
  %r442 = load i64, ptr %r442.p, align 8, !alias.scope !3, !noalias !4
  %c443 = trunc i64 %r442 to i32
  %t444 = add i32 %c443, 8
  ; @pc 0x800116338 word 0x290637ea
  %t448 = add i64 %r430, 48
  %t449 = add i64 %t448, 4
  %gmp452 = inttoptr i64 %t448 to ptr
  store i32 %t444, ptr %gmp452, align 4, !alias.scope !6, !noalias !3
  %r453.p = getelementptr inbounds i8, ptr %c, i64 104
  %r453 = load i64, ptr %r453.p, align 8, !alias.scope !3, !noalias !4
  %c454 = trunc i64 %r453 to i32
  %gmp455 = inttoptr i64 %t449 to ptr
  store i32 %c454, ptr %gmp455, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x80011633c word 0xb94d2290
  %t457 = add i64 %r436, 3360
  %gmp458 = inttoptr i64 %t457 to ptr
  %gml459 = load i32, ptr %gmp458, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116340 word 0x5281760a
  ; @pc 0x800116344 word 0x9100418c
  %r464.p = getelementptr inbounds i8, ptr %c, i64 96
  %r464 = load i64, ptr %r464.p, align 8, !alias.scope !3, !noalias !4
  %t465 = add i64 %r464, 16
  ; @pc 0x800116348 word 0x7217025f
  %r467.p = getelementptr inbounds i8, ptr %c, i64 144
  %r467 = load i64, ptr %r467.p, align 8, !alias.scope !3, !noalias !4
  %c468 = trunc i64 %r467 to i32
  %t469 = and i32 %c468, 512
  ; @pc 0x80011634c word 0x1acf2531
  %r480.p = getelementptr inbounds i8, ptr %c, i64 120
  %r480 = load i64, ptr %r480.p, align 8, !alias.scope !3, !noalias !4
  %c481 = trunc i64 %r480 to i32
  %t482 = and i32 %c481, 31
  %t483 = lshr i32 %gml439, %t482
  ; @pc 0x800116350 word 0x52800029
  ; @pc 0x800116354 word 0x1a9f17e0
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond490 = icmp ne i32 %t469, 0
  %sel493 = select i1 %cond490, i32 0, i32 1
  ; @pc 0x800116358 word 0x1acd2121
  %c497 = trunc i64 1 to i32
  %t500 = and i32 %c454, 31
  %t501 = shl i32 %c497, %t500
  %c502 = zext i32 %t501 to i64
  %wp503 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %c502, ptr %wp503, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011635c word 0xf946968e
  %t505 = add i64 %r436, 3368
  %gmp506 = inttoptr i64 %t505 to ptr
  %gml507 = load i64, ptr %gmp506, align 1, !alias.scope !4, !noalias !3
  %wp508 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 %gml507, ptr %wp508, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116360 word 0x6a00023f
  %t513 = and i32 %t483, %sel493
  ; @pc 0x800116364 word 0x528001f1
  ; @pc 0x800116368 word 0x52800200
  ; @pc 0x80011636c word 0x72a00400
  ; @pc 0x800116370 word 0x1a911031
  %c535 = trunc i64 15 to i32
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond537 = icmp ne i32 %t513, 0
  %sel540 = select i1 %cond537, i32 %t501, i32 %c535
  ; @pc 0x800116374 word 0x6b0f021f
  ; @pc 0x800116378 word 0x9a9f81ef
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond569 = icmp ugt i32 %gml459, %c481
  %sel575 = select i1 %cond569, i64 %r480, i64 0
  %wp576 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 %sel575, ptr %wp576, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011637c word 0x7212025f
  %t579 = and i32 %c468, 16384
  ; @pc 0x800116380 word 0xf900037f
  %r588 = load i64, ptr %loc_x27, align 8
  %gmp589 = inttoptr i64 %r588 to ptr
  store i64 0, ptr %gmp589, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116384 word 0x52a00410
  ; @pc 0x800116388 word 0x12140252
  %t594 = and i32 %c468, 4096
  ; @pc 0x80011638c word 0x9baa39ea
  %c598 = trunc i64 %sel575 to i32
  %c599 = zext i32 %c598 to i64
  %c601 = trunc i64 2992 to i32
  %c602 = zext i32 %c601 to i64
  %t603 = mul i64 %c599, %c602
  %t605 = add i64 %gml507, %t603
  ; @pc 0x800116390 word 0x1a900010
  %c608 = trunc i64 2097168 to i32
  %c610 = trunc i64 2097152 to i32
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond612 = icmp eq i32 %t579, 0
  %sel614 = select i1 %cond612, i32 %c608, i32 %c610
  ; @pc 0x800116394 word 0x530c7e52
  %ror619 = call i32 @llvm.fshr.i32(i32 %t594, i32 %t594, i32 12)
  %t620 = and i32 %ror619, 1048575
  ; @pc 0x800116398 word 0x330e0250
  %ror625 = call i32 @llvm.fshr.i32(i32 %t620, i32 %t620, i32 14)
  %t628 = and i32 %ror625, 262144
  %t629 = and i32 %sel614, -262145
  %t630 = or i32 %t629, %t628
  %t631 = and i32 %t630, 524287
  %t632 = and i32 %sel614, -524288
  %t633 = or i32 %t632, %t631
  ; @pc 0x80011639c word 0x52800100
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7292 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 8, ptr %cwp7292, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001163a0 word 0x110012b2
  %t640 = add i32 %c443, 4
  ; @pc 0x8001163a4 word 0x290003f1
  %t644 = add i64 %r430, 4
  %gmp647 = inttoptr i64 %r430 to ptr
  store i32 %sel540, ptr %gmp647, align 4, !alias.scope !6, !noalias !3
  %gmp650 = inttoptr i64 %t644 to ptr
  store i32 8, ptr %gmp650, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001163a8 word 0x929fffb1
  ; @pc 0x8001163ac word 0x290143f2
  %t653 = add i64 %r430, 8
  %t654 = add i64 %t653, 4
  %gmp657 = inttoptr i64 %t653 to ptr
  store i32 %t640, ptr %gmp657, align 4, !alias.scope !6, !noalias !3
  %gmp660 = inttoptr i64 %t654 to ptr
  store i32 %t633, ptr %gmp660, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001163b0 word 0x529ffff0
  ; @pc 0x8001163b4 word 0xf2a00011
  ; @pc 0x8001163b8 word 0xa90147f0
  %t668 = add i64 %r430, 16
  %t669 = add i64 %t668, 8
  %gmp671 = inttoptr i64 %t668 to ptr
  store i64 65535, ptr %gmp671, align 8, !alias.scope !6, !noalias !3
  %gmp673 = inttoptr i64 %t669 to ptr
  store i64 18446744069414584322, ptr %gmp673, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001163bc word 0xd2c00030
  ; @pc 0x8001163c0 word 0xb2607ff1
  ; @pc 0x8001163c4 word 0xd2e7f012
  %wp677 = getelementptr inbounds i8, ptr %c, i64 144
  store i64 4575657221408423936, ptr %wp677, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001163c8 word 0xa90247f0
  %t679 = add i64 %r430, 32
  %t680 = add i64 %t679, 8
  %gmp682 = inttoptr i64 %t679 to ptr
  store i64 4294967296, ptr %gmp682, align 8, !alias.scope !6, !noalias !3
  %gmp684 = inttoptr i64 %t680 to ptr
  store i64 18446744069414584320, ptr %gmp684, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001163cc word 0xb2091bf0
  ; @pc 0x8001163d0 word 0xa903c3f0
  %t688 = add i64 %r430, 56
  %t689 = add i64 %t688, 8
  %gmp691 = inttoptr i64 %t688 to ptr
  store i64 4575657222473777152, ptr %gmp691, align 8, !alias.scope !6, !noalias !3
  %gmp693 = inttoptr i64 %t689 to ptr
  store i64 4575657222473777152, ptr %gmp693, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001163d4 word 0xd0015d70
  ; @pc 0x8001163d8 word 0x910dee10
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7298 = getelementptr inbounds i8, ptr %c, i64 128
  store i64 34406679419, ptr %cwp7298, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001163dc word 0xb2087bf1
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7299 = getelementptr inbounds i8, ptr %c, i64 136
  store i64 18410715276682199039, ptr %cwp7299, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001163e0 word 0xf80a4312
  %r700.p = getelementptr inbounds i8, ptr %c, i64 192
  %r700 = load i64, ptr %r700.p, align 8, !alias.scope !3, !noalias !4
  %t701 = add i64 %r700, 164
  %gmp703 = inttoptr i64 %t701 to ptr
  store i64 4575657221408423936, ptr %gmp703, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001163e4 word 0xa907c7eb
  %t705 = add i64 %r430, 120
  %t706 = add i64 %t705, 8
  %r707.p = getelementptr inbounds i8, ptr %c, i64 88
  %r707 = load i64, ptr %r707.p, align 8, !alias.scope !3, !noalias !4
  %gmp708 = inttoptr i64 %t705 to ptr
  store i64 %r707, ptr %gmp708, align 8, !alias.scope !6, !noalias !3
  %gmp710 = inttoptr i64 %t706 to ptr
  store i64 18410715276682199039, ptr %gmp710, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001163e8 word 0xf9004ff1
  %t712 = add i64 %r430, 152
  %gmp714 = inttoptr i64 %t712 to ptr
  store i64 18410715276682199039, ptr %gmp714, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001163ec word 0xa908afec
  %t716 = add i64 %r430, 136
  %t717 = add i64 %t716, 8
  %gmp719 = inttoptr i64 %t716 to ptr
  store i64 %t465, ptr %gmp719, align 8, !alias.scope !6, !noalias !3
  %gmp721 = inttoptr i64 %t717 to ptr
  store i64 %r707, ptr %gmp721, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001163f0 word 0x3900237f
  %t723 = add i64 %r588, 8
  %gmp725 = inttoptr i64 %t723 to ptr
  store i8 0, ptr %gmp725, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001163f4 word 0xb900a3e8
  %t727 = add i64 %r430, 160
  %r728.p = getelementptr inbounds i8, ptr %c, i64 64
  %r728 = load i64, ptr %r728.p, align 8, !alias.scope !3, !noalias !4
  %c729 = trunc i64 %r728 to i32
  %gmp730 = inttoptr i64 %t727 to ptr
  store i32 %c729, ptr %gmp730, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001163f8 word 0xb900bfff
  %t732 = add i64 %r430, 188
  %gmp733 = inttoptr i64 %t732 to ptr
  store i32 0, ptr %gmp733, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001163fc word 0xa905ffff
  %t735 = add i64 %r430, 88
  ; [AArch64IdiomDeconstructPass] coalesced paired 64-bit zero stores -> i128
  %stpp7300 = inttoptr i64 %t735 to ptr
  store i128 0, ptr %stpp7300, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116400 word 0xa906c3ff
  %t740 = add i64 %r430, 104
  %t741 = add i64 %t740, 8
  %gmp742 = inttoptr i64 %t740 to ptr
  store i64 0, ptr %gmp742, align 8, !alias.scope !6, !noalias !3
  %gmp744 = inttoptr i64 %t741 to ptr
  store i64 34406679419, ptr %gmp744, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116404 word 0xb943d94b
  %t746 = add i64 %t605, 984
  %gmp747 = inttoptr i64 %t746 to ptr
  %gml748 = load i32, ptr %gmp747, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116408 word 0xb943f94c
  %t752 = add i64 %t605, 1016
  %gmp753 = inttoptr i64 %t752 to ptr
  %gml754 = load i32, ptr %gmp753, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011640c word 0x0aab7d6d
  %t759 = ashr i32 %gml748, 31
  %t760 = xor i32 %t759, -1
  %t763 = and i32 %gml748, %t760
  ; @pc 0x800116410 word 0x0a8b7d6b
  %t768 = ashr i32 %gml748, 31
  %t771 = and i32 %gml748, %t768
  ; @pc 0x800116414 word 0x1e220161
  ; [SIMDPairwiseAndConversionInlinePass] inline scalar SCVTF/UCVTF
  %itff7203 = sitofp i32 %t771 to float
  %itfi7204 = bitcast float %itff7203 to i32
  ; @pc 0x800116418 word 0x0aac7d8b
  %t779 = ashr i32 %gml754, 31
  %t780 = xor i32 %t779, -1
  %t783 = and i32 %gml754, %t780
  ; @pc 0x80011641c word 0x1e220162
  ; [SIMDPairwiseAndConversionInlinePass] inline scalar SCVTF/UCVTF
  %itff7208 = sitofp i32 %t783 to float
  %itfi7209 = bitcast float %itff7208 to i32
  ; @pc 0x800116420 word 0x0a8c7d8b
  %t791 = ashr i32 %gml754, 31
  %t794 = and i32 %gml754, %t791
  ; @pc 0x800116424 word 0x1e2201a0
  ; [SIMDPairwiseAndConversionInlinePass] inline scalar SCVTF/UCVTF
  %itff7213 = sitofp i32 %t763 to float
  %itfi7214 = bitcast float %itff7213 to i32
  ; @pc 0x800116428 word 0x2d100be0
  %t801 = add i64 %r430, 128
  %t802 = add i64 %t801, 4
  %gmp807 = inttoptr i64 %t801 to ptr
  store i32 %itfi7214, ptr %gmp807, align 4, !alias.scope !6, !noalias !3
  %gmp808 = inttoptr i64 %t802 to ptr
  store i32 %itfi7209, ptr %gmp808, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x80011642c word 0x1e220163
  ; [SIMDPairwiseAndConversionInlinePass] inline scalar SCVTF/UCVTF
  %itff7218 = sitofp i32 %t794 to float
  %itfi7219 = bitcast float %itff7218 to i32
  ; @pc 0x800116430 word 0x2d0f0fe1
  %t813 = add i64 %r430, 120
  %t814 = add i64 %t813, 4
  %gmp819 = inttoptr i64 %t813 to ptr
  store i32 %itfi7204, ptr %gmp819, align 4, !alias.scope !6, !noalias !3
  %gmp820 = inttoptr i64 %t814 to ptr
  store i32 %itfi7219, ptr %gmp820, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116434 word 0xb943d94b
  %t822 = add i64 %t605, 984
  %gmp823 = inttoptr i64 %t822 to ptr
  %gml824 = load i32, ptr %gmp823, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116438 word 0xb943f94c
  %t828 = add i64 %t605, 1016
  %gmp829 = inttoptr i64 %t828 to ptr
  %gml830 = load i32, ptr %gmp829, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011643c word 0xb900a3e8
  %t834 = add i64 %r430, 160
  %gmp837 = inttoptr i64 %t834 to ptr
  store i32 %c729, ptr %gmp837, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116440 word 0xf80a4312
  %t839 = add i64 %r700, 164
  %gmp841 = inttoptr i64 %t839 to ptr
  store i64 4575657221408423936, ptr %gmp841, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116444 word 0x0aab7d6d
  %t844 = ashr i32 %gml824, 31
  %t845 = xor i32 %t844, -1
  %t848 = and i32 %gml824, %t845
  %c849 = zext i32 %t848 to i64
  %wp850 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 %c849, ptr %wp850, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116448 word 0x0a8b7d6b
  %t853 = ashr i32 %gml824, 31
  %t856 = and i32 %gml824, %t853
  ; @pc 0x80011644c word 0x1e220161
  ; [SIMDPairwiseAndConversionInlinePass] inline scalar SCVTF/UCVTF
  %itff7223 = sitofp i32 %t856 to float
  %itfi7224 = bitcast float %itff7223 to i32
  %itfq7225 = zext i32 %itfi7224 to i128
  %svw7227 = getelementptr inbounds i8, ptr %c, i64 528
  store i128 %itfq7225, ptr %svw7227, align 16, !alias.scope !3, !noalias !4
  ; @pc 0x800116450 word 0x0aac7d8b
  %t864 = ashr i32 %gml830, 31
  %t865 = xor i32 %t864, -1
  %t868 = and i32 %gml830, %t865
  ; @pc 0x800116454 word 0x1e2201a0
  ; [SIMDPairwiseAndConversionInlinePass] inline scalar SCVTF/UCVTF
  %itff7228 = sitofp i32 %t848 to float
  %itfi7229 = bitcast float %itff7228 to i32
  %itfq7230 = zext i32 %itfi7229 to i128
  %svw7232 = getelementptr inbounds i8, ptr %c, i64 512
  store i128 %itfq7230, ptr %svw7232, align 16, !alias.scope !3, !noalias !4
  ; @pc 0x800116458 word 0x1e220162
  ; [SIMDPairwiseAndConversionInlinePass] inline scalar SCVTF/UCVTF
  %itff7233 = sitofp i32 %t868 to float
  %itfi7234 = bitcast float %itff7233 to i32
  %itfq7235 = zext i32 %itfi7234 to i128
  %svw7237 = getelementptr inbounds i8, ptr %c, i64 544
  store i128 %itfq7235, ptr %svw7237, align 16, !alias.scope !3, !noalias !4
  ; @pc 0x80011645c word 0x0a8c7d8b
  %t879 = ashr i32 %gml830, 31
  %t882 = and i32 %gml830, %t879
  ; @pc 0x800116460 word 0x1e220163
  ; [SIMDPairwiseAndConversionInlinePass] inline scalar SCVTF/UCVTF
  %itff7238 = sitofp i32 %t882 to float
  %itfi7239 = bitcast float %itff7238 to i32
  %itfq7240 = zext i32 %itfi7239 to i128
  %svw7242 = getelementptr inbounds i8, ptr %c, i64 560
  store i128 %itfq7240, ptr %svw7242, align 16, !alias.scope !3, !noalias !4
  ; @pc 0x800116464 word 0x2d130be0
  %t889 = add i64 %r430, 152
  %t890 = add i64 %t889, 4
  %gmp895 = inttoptr i64 %t889 to ptr
  store i32 %itfi7229, ptr %gmp895, align 4, !alias.scope !6, !noalias !3
  %gmp896 = inttoptr i64 %t890 to ptr
  store i32 %itfi7234, ptr %gmp896, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116468 word 0x2d120fe1
  %t898 = add i64 %r430, 144
  %t899 = add i64 %t898, 4
  %gmp904 = inttoptr i64 %t898 to ptr
  store i32 %itfi7224, ptr %gmp904, align 4, !alias.scope !6, !noalias !3
  %gmp905 = inttoptr i64 %t899 to ptr
  store i32 %itfi7239, ptr %gmp905, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x80011646c word 0x39516148
  %t907 = add i64 %t605, 1112
  %gmp908 = inttoptr i64 %t907 to ptr
  %gml909 = load i8, ptr %gmp908, align 1, !alias.scope !4, !noalias !3
  %c910 = zext i8 %gml909 to i64
  ; @pc 0x800116470 word 0x52800b6a
  ; @pc 0x800116474 word 0xf9005bff
  %t915 = add i64 %r430, 176
  %gmp916 = inttoptr i64 %t915 to ptr
  store i64 0, ptr %gmp916, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116478 word 0xb900bfe9
  %t918 = add i64 %r430, 188
  %gmp921 = inttoptr i64 %t918 to ptr
  store i32 1, ptr %gmp921, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x80011647c word 0x7100011f
  %c923 = trunc i64 %c910 to i32
  ; @pc 0x800116480 word 0x52800b28
  ; @pc 0x800116484 word 0x1a880148
  %c947 = trunc i64 91 to i32
  %c949 = trunc i64 89 to i32
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond951 = icmp eq i32 %c923, 0
  %sel953 = select i1 %cond951, i32 %c947, i32 %c949
  %c954 = zext i32 %sel953 to i64
  %wp955 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %c954, ptr %wp955, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116488 word 0x140002d2
  br label %L_800116fd0
L_80011648c:
  ; @pc 0x80011648c word 0xd00162a8
  ; @pc 0x800116490 word 0x91262108
  ; @pc 0x800116494 word 0x937d7ea9
  %r960.p = getelementptr inbounds i8, ptr %c, i64 168
  %r960 = load i64, ptr %r960.p, align 8, !alias.scope !3, !noalias !4
  %ror961 = call i64 @llvm.fshr.i64(i64 %r960, i64 %r960, i64 61)
  %t962 = lshr i64 %r960, 31
  %t963 = and i64 %t962, 1
  %t964 = sub i64 0, %t963
  %t965 = and i64 %t964, -34359738368
  %t966 = and i64 %ror961, 34359738360
  %t967 = or i64 %t965, %t966
  ; @pc 0x800116498 word 0xf8696908
  %t971 = add i64 34407369096, %t967
  %gmp972 = inttoptr i64 %t971 to ptr
  %gml973 = load i64, ptr %gmp972, align 1, !alias.scope !4, !noalias !3
  %wp974 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %gml973, ptr %wp974, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011649c word 0x17ffff63
  br label %L_800116228
L_8001164a0:
  ; @pc 0x8001164a0 word 0x5280010d
  ; @pc 0x8001164a4 word 0xd2e0080e
  ; @pc 0x8001164a8 word 0x529fffef
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7305 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 65535, ptr %cwp7305, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001164ac word 0xa9003bed
  %r980 = load i64, ptr %loc_sp, align 8
  %t981 = add i64 %r980, 8
  %gmp983 = inttoptr i64 %r980 to ptr
  store i64 8, ptr %gmp983, align 8, !alias.scope !6, !noalias !3
  %gmp985 = inttoptr i64 %t981 to ptr
  store i64 18014398509481984, ptr %gmp985, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001164b0 word 0xb2608fed
  ; @pc 0x8001164b4 word 0xa90137ef
  %t989 = add i64 %r980, 16
  %t990 = add i64 %t989, 8
  %gmp992 = inttoptr i64 %t989 to ptr
  store i64 65535, ptr %gmp992, align 8, !alias.scope !6, !noalias !3
  %gmp994 = inttoptr i64 %t990 to ptr
  store i64 18446744069414584335, ptr %gmp994, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001164b8 word 0xd2c0002d
  ; @pc 0x8001164bc word 0xb2607fee
  ; @pc 0x8001164c0 word 0xa9023bed
  %t999 = add i64 %r980, 32
  %t1000 = add i64 %t999, 8
  %gmp1002 = inttoptr i64 %t999 to ptr
  store i64 4294967296, ptr %gmp1002, align 8, !alias.scope !6, !noalias !3
  %gmp1004 = inttoptr i64 %t1000 to ptr
  store i64 18446744069414584320, ptr %gmp1004, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001164c4 word 0x1280000d
  ; @pc 0x8001164c8 word 0xb2091bee
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7309 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 4575657222473777152, ptr %cwp7309, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001164cc word 0xa9033bed
  %t1010 = add i64 %r980, 48
  %t1011 = add i64 %t1010, 8
  %gmp1013 = inttoptr i64 %t1010 to ptr
  store i64 4294967295, ptr %gmp1013, align 8, !alias.scope !6, !noalias !3
  %gmp1015 = inttoptr i64 %t1011 to ptr
  store i64 4575657222473777152, ptr %gmp1015, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001164d0 word 0xf0015ded
  ; @pc 0x8001164d4 word 0x9101d5ad
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7310 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 34406748277, ptr %cwp7310, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001164d8 word 0x14000293
  br label %L_800116f24
L_8001164dc:
  ; @pc 0x8001164dc word 0x5280200d
  ; @pc 0x8001164e0 word 0xd2e0080e
  ; @pc 0x8001164e4 word 0x529fffef
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7312 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 65535, ptr %cwp7312, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001164e8 word 0xa9003bed
  %r1025 = load i64, ptr %loc_sp, align 8
  %t1026 = add i64 %r1025, 8
  %gmp1028 = inttoptr i64 %r1025 to ptr
  store i64 256, ptr %gmp1028, align 8, !alias.scope !6, !noalias !3
  %gmp1030 = inttoptr i64 %t1026 to ptr
  store i64 18014398509481984, ptr %gmp1030, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001164ec word 0x929ffd8d
  ; @pc 0x8001164f0 word 0xf2a0000d
  ; @pc 0x8001164f4 word 0xb2607fee
  ; @pc 0x8001164f8 word 0xa90137ef
  %t1039 = add i64 %r1025, 16
  %t1040 = add i64 %t1039, 8
  %gmp1042 = inttoptr i64 %t1039 to ptr
  store i64 65535, ptr %gmp1042, align 8, !alias.scope !6, !noalias !3
  %gmp1044 = inttoptr i64 %t1040 to ptr
  store i64 18446744069414584339, ptr %gmp1044, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001164fc word 0xd2c0002d
  ; @pc 0x800116500 word 0xa9023bed
  %t1047 = add i64 %r1025, 32
  %t1048 = add i64 %t1047, 8
  %gmp1050 = inttoptr i64 %t1047 to ptr
  store i64 4294967296, ptr %gmp1050, align 8, !alias.scope !6, !noalias !3
  %gmp1052 = inttoptr i64 %t1048 to ptr
  store i64 18446744069414584320, ptr %gmp1052, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116504 word 0x1280000d
  ; @pc 0x800116508 word 0xb2091bee
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7317 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 4575657222473777152, ptr %cwp7317, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011650c word 0xa9033bed
  %t1058 = add i64 %r1025, 48
  %t1059 = add i64 %t1058, 8
  %gmp1061 = inttoptr i64 %t1058 to ptr
  store i64 4294967295, ptr %gmp1061, align 8, !alias.scope !6, !noalias !3
  %gmp1063 = inttoptr i64 %t1059 to ptr
  store i64 4575657222473777152, ptr %gmp1063, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116510 word 0xd00156ad
  ; @pc 0x800116514 word 0x9135adad
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7318 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 34405797227, ptr %cwp7318, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116518 word 0x14000283
  br label %L_800116f24
L_80011651c:
  ; @pc 0x80011651c word 0xf94f6681
  %r1068.p = getelementptr inbounds i8, ptr %c, i64 160
  %r1068 = load i64, ptr %r1068.p, align 8, !alias.scope !3, !noalias !4
  %t1069 = add i64 %r1068, 7880
  %gmp1070 = inttoptr i64 %t1069 to ptr
  %gml1071 = load i64, ptr %gmp1070, align 1, !alias.scope !4, !noalias !3
  %wp1072 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %gml1071, ptr %wp1072, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116520 word 0x9100418c
  %r1073.p = getelementptr inbounds i8, ptr %c, i64 96
  %r1073 = load i64, ptr %r1073.p, align 8, !alias.scope !3, !noalias !4
  %t1074 = add i64 %r1073, 16
  %wp1075 = getelementptr inbounds i8, ptr %c, i64 96
  store i64 %t1074, ptr %wp1075, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116524 word 0x2a1f03e2
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7319 = getelementptr inbounds i8, ptr %c, i64 16
  store i64 0, ptr %cwp7319, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116528 word 0x3940226d
  %r1079.p = getelementptr inbounds i8, ptr %c, i64 152
  %r1079 = load i64, ptr %r1079.p, align 8, !alias.scope !3, !noalias !4
  %t1080 = add i64 %r1079, 8
  %gmp1081 = inttoptr i64 %t1080 to ptr
  %gml1082 = load i8, ptr %gmp1081, align 1, !alias.scope !4, !noalias !3
  %c1083 = zext i8 %gml1082 to i64
  %wp1084 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 %c1083, ptr %wp1084, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011652c word 0xb940082e
  %t1086 = add i64 %gml1071, 8
  %gmp1087 = inttoptr i64 %t1086 to ptr
  %gml1088 = load i32, ptr %gmp1087, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116530 word 0xf940082f
  %t1092 = add i64 %gml1071, 16
  %gmp1093 = inttoptr i64 %t1092 to ptr
  %gml1094 = load i64, ptr %gmp1093, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116534 word 0x6b0d01df
  %c1099 = trunc i64 %c1083 to i32
  ; @pc 0x800116538 word 0x52879c0e
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7320 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 15584, ptr %cwp7320, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011653c word 0x9a9f81b0
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond1124 = icmp ugt i32 %gml1088, %c1099
  %sel1130 = select i1 %cond1124, i64 %c1083, i64 0
  ; @pc 0x800116540 word 0x9bae3e0f
  %c1133 = trunc i64 %sel1130 to i32
  %c1134 = zext i32 %c1133 to i64
  %c1136 = trunc i64 15584 to i32
  %c1137 = zext i32 %c1136 to i64
  %t1138 = mul i64 %c1134, %c1137
  %t1140 = add i64 %gml1094, %t1138
  ; @pc 0x800116544 word 0xd2e00c10
  ; @pc 0x800116548 word 0xf95e21f6
  %t1144 = add i64 %t1140, 15424
  %gmp1145 = inttoptr i64 %t1144 to ptr
  %gml1146 = load i64, ptr %gmp1145, align 1, !alias.scope !4, !noalias !3
  %wp1147 = getelementptr inbounds i8, ptr %c, i64 176
  store i64 %gml1146, ptr %wp1147, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011654c word 0xd280200f
  ; @pc 0x800116550 word 0xb900a3e8
  %r1149 = load i64, ptr %loc_sp, align 8
  %t1150 = add i64 %r1149, 160
  %r1151.p = getelementptr inbounds i8, ptr %c, i64 64
  %r1151 = load i64, ptr %r1151.p, align 8, !alias.scope !3, !noalias !4
  %c1152 = trunc i64 %r1151 to i32
  %gmp1153 = inttoptr i64 %t1150 to ptr
  store i32 %c1152, ptr %gmp1153, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116554 word 0x91004148
  %r1154.p = getelementptr inbounds i8, ptr %c, i64 80
  %r1154 = load i64, ptr %r1154.p, align 8, !alias.scope !3, !noalias !4
  %t1155 = add i64 %r1154, 16
  ; @pc 0x800116558 word 0xa908afec
  %t1158 = add i64 %r1149, 136
  %t1159 = add i64 %t1158, 8
  %gmp1161 = inttoptr i64 %t1158 to ptr
  store i64 %t1074, ptr %gmp1161, align 8, !alias.scope !6, !noalias !3
  %r1162.p = getelementptr inbounds i8, ptr %c, i64 88
  %r1162 = load i64, ptr %r1162.p, align 8, !alias.scope !3, !noalias !4
  %gmp1163 = inttoptr i64 %t1159 to ptr
  store i64 %r1162, ptr %gmp1163, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x80011655c word 0xf900037f
  %r1164 = load i64, ptr %loc_x27, align 8
  %gmp1165 = inttoptr i64 %r1164 to ptr
  store i64 0, ptr %gmp1165, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116560 word 0x3900237f
  %t1167 = add i64 %r1164, 8
  %gmp1169 = inttoptr i64 %t1167 to ptr
  store i8 0, ptr %gmp1169, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116564 word 0xb900bfff
  %t1171 = add i64 %r1149, 188
  %gmp1172 = inttoptr i64 %t1171 to ptr
  store i32 0, ptr %gmp1172, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116568 word 0xf2c0006f
  ; @pc 0x80011656c word 0xa904a3ff
  %t1178 = add i64 %r1149, 72
  %t1179 = add i64 %t1178, 8
  %gmp1180 = inttoptr i64 %t1178 to ptr
  store i64 0, ptr %gmp1180, align 8, !alias.scope !6, !noalias !3
  %gmp1182 = inttoptr i64 %t1179 to ptr
  store i64 %t1155, ptr %gmp1182, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116570 word 0x528000a8
  ; @pc 0x800116574 word 0xa905ffff
  %t1186 = add i64 %r1149, 88
  ; [AArch64IdiomDeconstructPass] coalesced paired 64-bit zero stores -> i128
  %stpp7323 = inttoptr i64 %t1186 to ptr
  store i128 0, ptr %stpp7323, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116578 word 0x29067fe8
  %t1191 = add i64 %r1149, 48
  %t1192 = add i64 %t1191, 4
  %gmp1195 = inttoptr i64 %t1191 to ptr
  store i32 5, ptr %gmp1195, align 4, !alias.scope !6, !noalias !3
  %gmp1196 = inttoptr i64 %t1192 to ptr
  store i32 0, ptr %gmp1196, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x80011657c word 0xa90043ef
  %t1198 = add i64 %r1149, 8
  %gmp1200 = inttoptr i64 %r1149 to ptr
  store i64 12884902144, ptr %gmp1200, align 8, !alias.scope !6, !noalias !3
  %gmp1202 = inttoptr i64 %t1198 to ptr
  store i64 27021597764222976, ptr %gmp1202, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116580 word 0x929ffef0
  ; @pc 0x800116584 word 0x529fffef
  ; @pc 0x800116588 word 0xf2a00010
  ; @pc 0x80011658c word 0xaa1603e0
  %wp1212 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 %gml1146, ptr %wp1212, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116590 word 0xa90143ef
  %t1214 = add i64 %r1149, 16
  %t1215 = add i64 %t1214, 8
  %gmp1217 = inttoptr i64 %t1214 to ptr
  store i64 65535, ptr %gmp1217, align 8, !alias.scope !6, !noalias !3
  %gmp1219 = inttoptr i64 %t1215 to ptr
  store i64 18446744069414584328, ptr %gmp1219, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116594 word 0xd2c0002f
  ; @pc 0x800116598 word 0xb2607ff0
  ; @pc 0x80011659c word 0xa90243ef
  %t1224 = add i64 %r1149, 32
  %t1225 = add i64 %t1224, 8
  %gmp1227 = inttoptr i64 %t1224 to ptr
  store i64 4294967296, ptr %gmp1227, align 8, !alias.scope !6, !noalias !3
  %gmp1229 = inttoptr i64 %t1225 to ptr
  store i64 18446744069414584320, ptr %gmp1229, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001165a0 word 0xb2091bef
  ; @pc 0x8001165a4 word 0xd2e7f010
  ; @pc 0x8001165a8 word 0xf80a4310
  %r1233.p = getelementptr inbounds i8, ptr %c, i64 192
  %r1233 = load i64, ptr %r1233.p, align 8, !alias.scope !3, !noalias !4
  %t1234 = add i64 %r1233, 164
  %gmp1236 = inttoptr i64 %t1234 to ptr
  store i64 4575657221408423936, ptr %gmp1236, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001165ac word 0xa903bfef
  %t1238 = add i64 %r1149, 56
  %t1239 = add i64 %t1238, 8
  %gmp1241 = inttoptr i64 %t1238 to ptr
  store i64 4575657222473777152, ptr %gmp1241, align 8, !alias.scope !6, !noalias !3
  %gmp1243 = inttoptr i64 %t1239 to ptr
  store i64 4575657222473777152, ptr %gmp1243, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001165b0 word 0xb0015c2f
  ; @pc 0x8001165b4 word 0x91079def
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7329 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 34406511079, ptr %cwp7329, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001165b8 word 0xb2087bf0
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7330 = getelementptr inbounds i8, ptr %c, i64 128
  store i64 18410715276682199039, ptr %cwp7330, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001165bc word 0xf9004ff0
  %t1251 = add i64 %r1149, 152
  %gmp1253 = inttoptr i64 %t1251 to ptr
  store i64 18410715276682199039, ptr %gmp1253, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001165c0 word 0xa907c3eb
  %t1255 = add i64 %r1149, 120
  %t1256 = add i64 %t1255, 8
  %gmp1258 = inttoptr i64 %t1255 to ptr
  store i64 %r1162, ptr %gmp1258, align 8, !alias.scope !6, !noalias !3
  %gmp1260 = inttoptr i64 %t1256 to ptr
  store i64 18410715276682199039, ptr %gmp1260, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001165c4 word 0xa906bfff
  %t1262 = add i64 %r1149, 104
  %t1263 = add i64 %t1262, 8
  %gmp1264 = inttoptr i64 %t1262 to ptr
  store i64 0, ptr %gmp1264, align 8, !alias.scope !6, !noalias !3
  %gmp1266 = inttoptr i64 %t1263 to ptr
  store i64 34406511079, ptr %gmp1266, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001165c8 word 0xb9400828
  %t1268 = add i64 %gml1071, 8
  %gmp1269 = inttoptr i64 %t1268 to ptr
  %gml1270 = load i32, ptr %gmp1269, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001165cc word 0xf940082a
  %t1274 = add i64 %gml1071, 16
  %gmp1275 = inttoptr i64 %t1274 to ptr
  %gml1276 = load i64, ptr %gmp1275, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001165d0 word 0x6b0d011f
  ; @pc 0x8001165d4 word 0x9a9f81a8
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond1304 = icmp ugt i32 %gml1270, %c1099
  %sel1310 = select i1 %cond1304, i64 %c1083, i64 0
  ; @pc 0x8001165d8 word 0x9bae2908
  %c1313 = trunc i64 %sel1310 to i32
  %c1314 = zext i32 %c1313 to i64
  %c1317 = zext i32 %c1136 to i64
  %t1318 = mul i64 %c1314, %c1317
  %t1320 = add i64 %gml1276, %t1318
  ; @pc 0x8001165dc word 0xf957010a
  %t1323 = add i64 %t1320, 11776
  %gmp1324 = inttoptr i64 %t1323 to ptr
  %gml1325 = load i64, ptr %gmp1324, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001165e0 word 0xf9570508
  %t1328 = add i64 %t1320, 11784
  %gmp1329 = inttoptr i64 %t1328 to ptr
  %gml1330 = load i64, ptr %gmp1329, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001165e4 word 0xa900212a
  %r1332.p = getelementptr inbounds i8, ptr %c, i64 72
  %r1332 = load i64, ptr %r1332.p, align 8, !alias.scope !3, !noalias !4
  %t1333 = add i64 %r1332, 8
  %gmp1335 = inttoptr i64 %r1332 to ptr
  store i64 %gml1325, ptr %gmp1335, align 1, !alias.scope !4, !noalias !3
  %gmp1337 = inttoptr i64 %t1333 to ptr
  store i64 %gml1330, ptr %gmp1337, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001165e8 word 0xb9400828
  %t1339 = add i64 %gml1071, 8
  %gmp1340 = inttoptr i64 %t1339 to ptr
  %gml1341 = load i32, ptr %gmp1340, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001165ec word 0xf9400829
  %t1345 = add i64 %gml1071, 16
  %gmp1346 = inttoptr i64 %t1345 to ptr
  %gml1347 = load i64, ptr %gmp1346, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001165f0 word 0x6b0d011f
  ; @pc 0x8001165f4 word 0x9a9f81a8
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond1375 = icmp ugt i32 %gml1341, %c1099
  %sel1381 = select i1 %cond1375, i64 %c1083, i64 0
  ; @pc 0x8001165f8 word 0x9bae2508
  %c1384 = trunc i64 %sel1381 to i32
  %c1385 = zext i32 %c1384 to i64
  %c1388 = zext i32 %c1136 to i64
  %t1389 = mul i64 %c1385, %c1388
  %t1391 = add i64 %gml1347, %t1389
  ; @pc 0x8001165fc word 0xf9584109
  %t1394 = add i64 %t1391, 12416
  %gmp1395 = inttoptr i64 %t1394 to ptr
  %gml1396 = load i64, ptr %gmp1395, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116600 word 0xf958450a
  %t1399 = add i64 %t1391, 12424
  %gmp1400 = inttoptr i64 %t1399 to ptr
  %gml1401 = load i64, ptr %gmp1400, align 1, !alias.scope !4, !noalias !3
  %wp1402 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 %gml1401, ptr %wp1402, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116604 word 0xa9002b49
  %r1403.p = getelementptr inbounds i8, ptr %c, i64 208
  %r1403 = load i64, ptr %r1403.p, align 8, !alias.scope !3, !noalias !4
  %t1404 = add i64 %r1403, 8
  %gmp1406 = inttoptr i64 %r1403 to ptr
  store i64 %gml1396, ptr %gmp1406, align 1, !alias.scope !4, !noalias !3
  %gmp1408 = inttoptr i64 %t1404 to ptr
  store i64 %gml1401, ptr %gmp1408, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116608 word 0xf9584909
  %t1410 = add i64 %t1391, 12432
  %gmp1411 = inttoptr i64 %t1410 to ptr
  %gml1412 = load i64, ptr %gmp1411, align 1, !alias.scope !4, !noalias !3
  %wp1413 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %gml1412, ptr %wp1413, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011660c word 0xb9709908
  %t1415 = add i64 %t1391, 12440
  %gmp1416 = inttoptr i64 %t1415 to ptr
  %gml1417 = load i32, ptr %gmp1416, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116610 word 0xb9000b28
  %r1420.p = getelementptr inbounds i8, ptr %c, i64 200
  %r1420 = load i64, ptr %r1420.p, align 8, !alias.scope !3, !noalias !4
  %t1421 = add i64 %r1420, 8
  %gmp1424 = inttoptr i64 %t1421 to ptr
  store i32 %gml1417, ptr %gmp1424, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116614 word 0xd10027a8
  %r1425 = load i64, ptr %loc_x29, align 8
  %t1426 = sub i64 %r1425, 9
  %wp1427 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %t1426, ptr %wp1427, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116618 word 0xf9000329
  %gmp1430 = inttoptr i64 %r1420 to ptr
  store i64 %gml1412, ptr %gmp1430, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011661c word 0x9400046f
  %wp1431 = getelementptr inbounds i8, ptr %c, i64 240
  store i64 34360878624, ptr %wp1431, align 8, !alias.scope !3, !noalias !4
  call void @f_8001177d8(ptr %c)
  ; @pc 0x800116620 word 0xf84c7308
  %r1432.p = getelementptr inbounds i8, ptr %c, i64 192
  %r1432 = load i64, ptr %r1432.p, align 8, !alias.scope !3, !noalias !4
  %t1433 = add i64 %r1432, 199
  %gmp1434 = inttoptr i64 %t1433 to ptr
  %gml1435 = load i64, ptr %gmp1434, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116624 word 0xf9000368
  %r1437 = load i64, ptr %loc_x27, align 8
  %gmp1439 = inttoptr i64 %r1437 to ptr
  store i64 %gml1435, ptr %gmp1439, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116628 word 0x385ff3a9
  %r1440 = load i64, ptr %loc_x29, align 8
  %t1441 = add i64 %r1440, -1
  %gmp1442 = inttoptr i64 %t1441 to ptr
  %gml1443 = load i8, ptr %gmp1442, align 1, !alias.scope !6, !noalias !3
  %c1444 = zext i8 %gml1443 to i64
  ; @pc 0x80011662c word 0xf94afeca
  %r1446.p = getelementptr inbounds i8, ptr %c, i64 176
  %r1446 = load i64, ptr %r1446.p, align 8, !alias.scope !3, !noalias !4
  %t1447 = add i64 %r1446, 5624
  %gmp1448 = inttoptr i64 %t1447 to ptr
  %gml1449 = load i64, ptr %gmp1448, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116630 word 0xb95602c8
  %t1452 = add i64 %r1446, 5632
  %gmp1453 = inttoptr i64 %t1452 to ptr
  %gml1454 = load i32, ptr %gmp1453, align 1, !alias.scope !4, !noalias !3
  %c1455 = zext i32 %gml1454 to i64
  %wp1456 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %c1455, ptr %wp1456, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116634 word 0x39002369
  %t1458 = add i64 %r1437, 8
  %c1460 = trunc i64 %c1444 to i32
  %c1461 = trunc i32 %c1460 to i8
  %gmp1462 = inttoptr i64 %t1458 to ptr
  store i8 %c1461, ptr %gmp1462, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116638 word 0xf801c3ea
  %r1463 = load i64, ptr %loc_sp, align 8
  %t1464 = add i64 %r1463, 28
  %gmp1466 = inttoptr i64 %t1464 to ptr
  store i64 %gml1449, ptr %gmp1466, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x80011663c word 0x140000e6
  br label %L_8001169d4
L_800116640:
  ; @pc 0x800116640 word 0x5282000d
  ; @pc 0x800116644 word 0x5280002e
  ; @pc 0x800116648 word 0x529fffef
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7333 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 65535, ptr %cwp7333, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011664c word 0xa9003bed
  %r1473 = load i64, ptr %loc_sp, align 8
  %t1474 = add i64 %r1473, 8
  %gmp1476 = inttoptr i64 %r1473 to ptr
  store i64 4096, ptr %gmp1476, align 8, !alias.scope !6, !noalias !3
  %gmp1478 = inttoptr i64 %t1474 to ptr
  store i64 1, ptr %gmp1478, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116650 word 0x929ffe6d
  ; @pc 0x800116654 word 0xf2a0000d
  ; @pc 0x800116658 word 0xb2607fee
  ; @pc 0x80011665c word 0xa90137ef
  %t1487 = add i64 %r1473, 16
  %t1488 = add i64 %t1487, 8
  %gmp1490 = inttoptr i64 %t1487 to ptr
  store i64 65535, ptr %gmp1490, align 8, !alias.scope !6, !noalias !3
  %gmp1492 = inttoptr i64 %t1488 to ptr
  store i64 18446744069414584332, ptr %gmp1492, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116660 word 0xd2c0002d
  ; @pc 0x800116664 word 0xa9023bed
  %t1495 = add i64 %r1473, 32
  %t1496 = add i64 %t1495, 8
  %gmp1498 = inttoptr i64 %t1495 to ptr
  store i64 4294967296, ptr %gmp1498, align 8, !alias.scope !6, !noalias !3
  %gmp1500 = inttoptr i64 %t1496 to ptr
  store i64 18446744069414584320, ptr %gmp1500, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116668 word 0x1280000d
  ; @pc 0x80011666c word 0xb2091bee
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7338 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 4575657222473777152, ptr %cwp7338, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116670 word 0xa9033bed
  %t1506 = add i64 %r1473, 48
  %t1507 = add i64 %t1506, 8
  %gmp1509 = inttoptr i64 %t1506 to ptr
  store i64 4294967295, ptr %gmp1509, align 8, !alias.scope !6, !noalias !3
  %gmp1511 = inttoptr i64 %t1507 to ptr
  store i64 4575657222473777152, ptr %gmp1511, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116674 word 0xd001594d
  ; @pc 0x800116678 word 0x9109f1ad
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7339 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 34406138492, ptr %cwp7339, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011667c word 0x14000146
  br label %L_800116b94
L_800116680:
  ; @pc 0x800116680 word 0xf94f6681
  %r1516.p = getelementptr inbounds i8, ptr %c, i64 160
  %r1516 = load i64, ptr %r1516.p, align 8, !alias.scope !3, !noalias !4
  %t1517 = add i64 %r1516, 7880
  %gmp1518 = inttoptr i64 %t1517 to ptr
  %gml1519 = load i64, ptr %gmp1518, align 1, !alias.scope !4, !noalias !3
  %wp1520 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %gml1519, ptr %wp1520, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116684 word 0x9100418c
  %r1521.p = getelementptr inbounds i8, ptr %c, i64 96
  %r1521 = load i64, ptr %r1521.p, align 8, !alias.scope !3, !noalias !4
  %t1522 = add i64 %r1521, 16
  %wp1523 = getelementptr inbounds i8, ptr %c, i64 96
  store i64 %t1522, ptr %wp1523, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116688 word 0x2a1f03e2
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7340 = getelementptr inbounds i8, ptr %c, i64 16
  store i64 0, ptr %cwp7340, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011668c word 0x3940226e
  %r1527.p = getelementptr inbounds i8, ptr %c, i64 152
  %r1527 = load i64, ptr %r1527.p, align 8, !alias.scope !3, !noalias !4
  %t1528 = add i64 %r1527, 8
  %gmp1529 = inttoptr i64 %t1528 to ptr
  %gml1530 = load i8, ptr %gmp1529, align 1, !alias.scope !4, !noalias !3
  %c1531 = zext i8 %gml1530 to i64
  %wp1532 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 %c1531, ptr %wp1532, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116690 word 0x794001ad
  %r1533.p = getelementptr inbounds i8, ptr %c, i64 104
  %r1533 = load i64, ptr %r1533.p, align 8, !alias.scope !3, !noalias !4
  %gmp1534 = inttoptr i64 %r1533 to ptr
  %gml1535 = load i16, ptr %gmp1534, align 1, !alias.scope !4, !noalias !3
  %c1536 = zext i16 %gml1535 to i64
  ; @pc 0x800116694 word 0x121a01ad
  %c1539 = trunc i64 %c1536 to i32
  %t1540 = and i32 %c1539, 64
  ; @pc 0x800116698 word 0xb940082f
  %t1544 = add i64 %gml1519, 8
  %gmp1545 = inttoptr i64 %t1544 to ptr
  %gml1546 = load i32, ptr %gmp1545, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011669c word 0xf9400830
  %t1550 = add i64 %gml1519, 16
  %gmp1551 = inttoptr i64 %t1550 to ptr
  %gml1552 = load i64, ptr %gmp1551, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001166a0 word 0x6b0e01ff
  %c1557 = trunc i64 %c1531 to i32
  ; @pc 0x8001166a4 word 0x52879c0f
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7341 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 15584, ptr %cwp7341, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001166a8 word 0x9a9f81d1
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond1582 = icmp ugt i32 %gml1546, %c1557
  %sel1588 = select i1 %cond1582, i64 %c1531, i64 0
  %wp1589 = getelementptr inbounds i8, ptr %c, i64 136
  store i64 %sel1588, ptr %wp1589, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001166ac word 0x9baf4230
  %c1591 = trunc i64 %sel1588 to i32
  %c1592 = zext i32 %c1591 to i64
  %c1594 = trunc i64 15584 to i32
  %c1595 = zext i32 %c1594 to i64
  %t1596 = mul i64 %c1592, %c1595
  %t1598 = add i64 %gml1552, %t1596
  ; @pc 0x8001166b0 word 0xf95e2216
  %t1601 = add i64 %t1598, 15424
  %gmp1602 = inttoptr i64 %t1601 to ptr
  %gml1603 = load i64, ptr %gmp1602, align 1, !alias.scope !4, !noalias !3
  %wp1604 = getelementptr inbounds i8, ptr %c, i64 176
  store i64 %gml1603, ptr %wp1604, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001166b4 word 0xf94f5e90
  %t1606 = add i64 %r1516, 7864
  %gmp1607 = inttoptr i64 %t1606 to ptr
  %gml1608 = load i64, ptr %gmp1607, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001166b8 word 0xb900a3e8
  %r1610 = load i64, ptr %loc_sp, align 8
  %t1611 = add i64 %r1610, 160
  %r1612.p = getelementptr inbounds i8, ptr %c, i64 64
  %r1612 = load i64, ptr %r1612.p, align 8, !alias.scope !3, !noalias !4
  %c1613 = trunc i64 %r1612 to i32
  %gmp1614 = inttoptr i64 %t1611 to ptr
  store i32 %c1613, ptr %gmp1614, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001166bc word 0x91004148
  %r1615.p = getelementptr inbounds i8, ptr %c, i64 80
  %r1615 = load i64, ptr %r1615.p, align 8, !alias.scope !3, !noalias !4
  %t1616 = add i64 %r1615, 16
  ; @pc 0x8001166c0 word 0xa908afec
  %t1619 = add i64 %r1610, 136
  %t1620 = add i64 %t1619, 8
  %gmp1622 = inttoptr i64 %t1619 to ptr
  store i64 %t1522, ptr %gmp1622, align 8, !alias.scope !6, !noalias !3
  %r1623.p = getelementptr inbounds i8, ptr %c, i64 88
  %r1623 = load i64, ptr %r1623.p, align 8, !alias.scope !3, !noalias !4
  %gmp1624 = inttoptr i64 %t1620 to ptr
  store i64 %r1623, ptr %gmp1624, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001166c4 word 0xf900037f
  %r1625 = load i64, ptr %loc_x27, align 8
  %gmp1626 = inttoptr i64 %r1625 to ptr
  store i64 0, ptr %gmp1626, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001166c8 word 0x3900237f
  %t1628 = add i64 %r1625, 8
  %gmp1630 = inttoptr i64 %t1628 to ptr
  store i8 0, ptr %gmp1630, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001166cc word 0xb900bfff
  %t1632 = add i64 %r1610, 188
  %gmp1633 = inttoptr i64 %t1632 to ptr
  store i32 0, ptr %gmp1633, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001166d0 word 0xa905ffff
  %t1635 = add i64 %r1610, 88
  ; [AArch64IdiomDeconstructPass] coalesced paired 64-bit zero stores -> i128
  %stpp7342 = inttoptr i64 %t1635 to ptr
  store i128 0, ptr %stpp7342, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001166d4 word 0x395ac210
  %t1640 = add i64 %gml1608, 1712
  %gmp1641 = inttoptr i64 %t1640 to ptr
  %gml1642 = load i8, ptr %gmp1641, align 1, !alias.scope !4, !noalias !3
  %c1643 = zext i8 %gml1642 to i64
  ; @pc 0x8001166d8 word 0xa904a3ff
  %t1646 = add i64 %r1610, 72
  %t1647 = add i64 %t1646, 8
  %gmp1648 = inttoptr i64 %t1646 to ptr
  store i64 0, ptr %gmp1648, align 8, !alias.scope !6, !noalias !3
  %gmp1650 = inttoptr i64 %t1647 to ptr
  store i64 %t1616, ptr %gmp1650, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001166dc word 0x52800088
  ; @pc 0x8001166e0 word 0x29067fe8
  %t1654 = add i64 %r1610, 48
  %t1655 = add i64 %t1654, 4
  %gmp1658 = inttoptr i64 %t1654 to ptr
  store i32 4, ptr %gmp1658, align 4, !alias.scope !6, !noalias !3
  %gmp1659 = inttoptr i64 %t1655 to ptr
  store i32 0, ptr %gmp1659, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001166e4 word 0xaa1603e0
  %wp1662 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 %gml1603, ptr %wp1662, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001166e8 word 0x7100021f
  %c1664 = trunc i64 %c1643 to i32
  ; @pc 0x8001166ec word 0x1a9f07f0
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond1687 = icmp eq i32 %c1664, 0
  %sel1689 = select i1 %cond1687, i32 0, i32 1
  ; @pc 0x8001166f0 word 0x6a4d1a1f
  %t1694 = lshr i32 %t1540, 6
  %t1697 = and i32 %sel1689, %t1694
  ; @pc 0x8001166f4 word 0x5280002d
  ; @pc 0x8001166f8 word 0x72a0080d
  ; @pc 0x8001166fc word 0x52800030
  ; @pc 0x800116700 word 0x72a08810
  ; @pc 0x800116704 word 0x1a8d120d
  %c1723 = trunc i64 71303169 to i32
  %c1725 = trunc i64 4194305 to i32
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond1727 = icmp ne i32 %t1697, 0
  %sel1730 = select i1 %cond1727, i32 %c1723, i32 %c1725
  ; @pc 0x800116708 word 0xd2800210
  ; @pc 0x80011670c word 0xf2c00070
  ; @pc 0x800116710 word 0x290137ff
  %t1739 = add i64 %r1610, 8
  %t1740 = add i64 %t1739, 4
  %gmp1741 = inttoptr i64 %t1739 to ptr
  store i32 0, ptr %gmp1741, align 4, !alias.scope !6, !noalias !3
  %gmp1744 = inttoptr i64 %t1740 to ptr
  store i32 %sel1730, ptr %gmp1744, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116714 word 0x529fffed
  ; @pc 0x800116718 word 0xf90003f0
  %gmp1749 = inttoptr i64 %r1610 to ptr
  store i64 12884901904, ptr %gmp1749, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x80011671c word 0xb2608bf0
  ; @pc 0x800116720 word 0xa90143ed
  %t1753 = add i64 %r1610, 16
  %t1754 = add i64 %t1753, 8
  %gmp1756 = inttoptr i64 %t1753 to ptr
  store i64 65535, ptr %gmp1756, align 8, !alias.scope !6, !noalias !3
  %gmp1758 = inttoptr i64 %t1754 to ptr
  store i64 18446744069414584327, ptr %gmp1758, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116724 word 0xd2c0002d
  ; @pc 0x800116728 word 0xb2607ff0
  ; @pc 0x80011672c word 0xa90243ed
  %t1763 = add i64 %r1610, 32
  %t1764 = add i64 %t1763, 8
  %gmp1766 = inttoptr i64 %t1763 to ptr
  store i64 4294967296, ptr %gmp1766, align 8, !alias.scope !6, !noalias !3
  %gmp1768 = inttoptr i64 %t1764 to ptr
  store i64 18446744069414584320, ptr %gmp1768, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116730 word 0xb2091bed
  ; @pc 0x800116734 word 0xd2e7f010
  ; @pc 0x800116738 word 0xa903b7ed
  %t1773 = add i64 %r1610, 56
  %t1774 = add i64 %t1773, 8
  %gmp1776 = inttoptr i64 %t1773 to ptr
  store i64 4575657222473777152, ptr %gmp1776, align 8, !alias.scope !6, !noalias !3
  %gmp1778 = inttoptr i64 %t1774 to ptr
  store i64 4575657222473777152, ptr %gmp1778, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x80011673c word 0xb0015c2d
  ; @pc 0x800116740 word 0x910729ad
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7353 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 34406511050, ptr %cwp7353, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116744 word 0xf80a4310
  %r1783.p = getelementptr inbounds i8, ptr %c, i64 192
  %r1783 = load i64, ptr %r1783.p, align 8, !alias.scope !3, !noalias !4
  %t1784 = add i64 %r1783, 164
  %gmp1786 = inttoptr i64 %t1784 to ptr
  store i64 4575657221408423936, ptr %gmp1786, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116748 word 0xb2087bf0
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7354 = getelementptr inbounds i8, ptr %c, i64 128
  store i64 18410715276682199039, ptr %cwp7354, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011674c word 0xa907c3eb
  %t1790 = add i64 %r1610, 120
  %t1791 = add i64 %t1790, 8
  %gmp1793 = inttoptr i64 %t1790 to ptr
  store i64 %r1623, ptr %gmp1793, align 8, !alias.scope !6, !noalias !3
  %gmp1795 = inttoptr i64 %t1791 to ptr
  store i64 18410715276682199039, ptr %gmp1795, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116750 word 0xf9004ff0
  %t1797 = add i64 %r1610, 152
  %gmp1799 = inttoptr i64 %t1797 to ptr
  store i64 18410715276682199039, ptr %gmp1799, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116754 word 0xa906b7ff
  %t1801 = add i64 %r1610, 104
  %t1802 = add i64 %t1801, 8
  %gmp1803 = inttoptr i64 %t1801 to ptr
  store i64 0, ptr %gmp1803, align 8, !alias.scope !6, !noalias !3
  %gmp1805 = inttoptr i64 %t1802 to ptr
  store i64 34406511050, ptr %gmp1805, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116758 word 0xb9400828
  %t1807 = add i64 %gml1519, 8
  %gmp1808 = inttoptr i64 %t1807 to ptr
  %gml1809 = load i32, ptr %gmp1808, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011675c word 0xf940082a
  %t1813 = add i64 %gml1519, 16
  %gmp1814 = inttoptr i64 %t1813 to ptr
  %gml1815 = load i64, ptr %gmp1814, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116760 word 0x6b0e011f
  ; @pc 0x800116764 word 0x9a9f81c8
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond1843 = icmp ugt i32 %gml1809, %c1557
  %sel1849 = select i1 %cond1843, i64 %c1531, i64 0
  ; @pc 0x800116768 word 0x9baf2908
  %c1852 = trunc i64 %sel1849 to i32
  %c1853 = zext i32 %c1852 to i64
  %c1856 = zext i32 %c1594 to i64
  %t1857 = mul i64 %c1853, %c1856
  %t1859 = add i64 %gml1815, %t1857
  ; @pc 0x80011676c word 0xf957010a
  %t1862 = add i64 %t1859, 11776
  %gmp1863 = inttoptr i64 %t1862 to ptr
  %gml1864 = load i64, ptr %gmp1863, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116770 word 0xf9570508
  %t1867 = add i64 %t1859, 11784
  %gmp1868 = inttoptr i64 %t1867 to ptr
  %gml1869 = load i64, ptr %gmp1868, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116774 word 0xa900212a
  %r1871.p = getelementptr inbounds i8, ptr %c, i64 72
  %r1871 = load i64, ptr %r1871.p, align 8, !alias.scope !3, !noalias !4
  %t1872 = add i64 %r1871, 8
  %gmp1874 = inttoptr i64 %r1871 to ptr
  store i64 %gml1864, ptr %gmp1874, align 1, !alias.scope !4, !noalias !3
  %gmp1876 = inttoptr i64 %t1872 to ptr
  store i64 %gml1869, ptr %gmp1876, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116778 word 0xb9400828
  %t1878 = add i64 %gml1519, 8
  %gmp1879 = inttoptr i64 %t1878 to ptr
  %gml1880 = load i32, ptr %gmp1879, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011677c word 0xf9400829
  %t1884 = add i64 %gml1519, 16
  %gmp1885 = inttoptr i64 %t1884 to ptr
  %gml1886 = load i64, ptr %gmp1885, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116780 word 0x6b0e011f
  ; @pc 0x800116784 word 0x9a9f81c8
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond1914 = icmp ugt i32 %gml1880, %c1557
  %sel1920 = select i1 %cond1914, i64 %c1531, i64 0
  ; @pc 0x800116788 word 0x9baf2508
  %c1923 = trunc i64 %sel1920 to i32
  %c1924 = zext i32 %c1923 to i64
  %c1927 = zext i32 %c1594 to i64
  %t1928 = mul i64 %c1924, %c1927
  %t1930 = add i64 %gml1886, %t1928
  ; @pc 0x80011678c word 0xf9584109
  %t1933 = add i64 %t1930, 12416
  %gmp1934 = inttoptr i64 %t1933 to ptr
  %gml1935 = load i64, ptr %gmp1934, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116790 word 0xf958450a
  %t1938 = add i64 %t1930, 12424
  %gmp1939 = inttoptr i64 %t1938 to ptr
  %gml1940 = load i64, ptr %gmp1939, align 1, !alias.scope !4, !noalias !3
  %wp1941 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 %gml1940, ptr %wp1941, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116794 word 0xa9002b49
  %r1942.p = getelementptr inbounds i8, ptr %c, i64 208
  %r1942 = load i64, ptr %r1942.p, align 8, !alias.scope !3, !noalias !4
  %t1943 = add i64 %r1942, 8
  %gmp1945 = inttoptr i64 %r1942 to ptr
  store i64 %gml1935, ptr %gmp1945, align 1, !alias.scope !4, !noalias !3
  %gmp1947 = inttoptr i64 %t1943 to ptr
  store i64 %gml1940, ptr %gmp1947, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116798 word 0xf9584909
  %t1949 = add i64 %t1930, 12432
  %gmp1950 = inttoptr i64 %t1949 to ptr
  %gml1951 = load i64, ptr %gmp1950, align 1, !alias.scope !4, !noalias !3
  %wp1952 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %gml1951, ptr %wp1952, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011679c word 0xb9709908
  %t1954 = add i64 %t1930, 12440
  %gmp1955 = inttoptr i64 %t1954 to ptr
  %gml1956 = load i32, ptr %gmp1955, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001167a0 word 0xb9000b28
  %r1959.p = getelementptr inbounds i8, ptr %c, i64 200
  %r1959 = load i64, ptr %r1959.p, align 8, !alias.scope !3, !noalias !4
  %t1960 = add i64 %r1959, 8
  %gmp1963 = inttoptr i64 %t1960 to ptr
  store i32 %gml1956, ptr %gmp1963, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001167a4 word 0xd10027a8
  %r1964 = load i64, ptr %loc_x29, align 8
  %t1965 = sub i64 %r1964, 9
  %wp1966 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %t1965, ptr %wp1966, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001167a8 word 0xf9000329
  %gmp1969 = inttoptr i64 %r1959 to ptr
  store i64 %gml1951, ptr %gmp1969, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001167ac word 0x9400040b
  %wp1970 = getelementptr inbounds i8, ptr %c, i64 240
  store i64 34360879024, ptr %wp1970, align 8, !alias.scope !3, !noalias !4
  call void @f_8001177d8(ptr %c)
  ; @pc 0x8001167b0 word 0xf84c7308
  %r1971.p = getelementptr inbounds i8, ptr %c, i64 192
  %r1971 = load i64, ptr %r1971.p, align 8, !alias.scope !3, !noalias !4
  %t1972 = add i64 %r1971, 199
  %gmp1973 = inttoptr i64 %t1972 to ptr
  %gml1974 = load i64, ptr %gmp1973, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001167b4 word 0xf9000368
  %r1976 = load i64, ptr %loc_x27, align 8
  %gmp1978 = inttoptr i64 %r1976 to ptr
  store i64 %gml1974, ptr %gmp1978, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001167b8 word 0x385ff3a9
  %r1979 = load i64, ptr %loc_x29, align 8
  %t1980 = add i64 %r1979, -1
  %gmp1981 = inttoptr i64 %t1980 to ptr
  %gml1982 = load i8, ptr %gmp1981, align 1, !alias.scope !6, !noalias !3
  %c1983 = zext i8 %gml1982 to i64
  ; @pc 0x8001167bc word 0xf94afeca
  %r1985.p = getelementptr inbounds i8, ptr %c, i64 176
  %r1985 = load i64, ptr %r1985.p, align 8, !alias.scope !3, !noalias !4
  %t1986 = add i64 %r1985, 5624
  %gmp1987 = inttoptr i64 %t1986 to ptr
  %gml1988 = load i64, ptr %gmp1987, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001167c0 word 0xb95602c8
  %t1991 = add i64 %r1985, 5632
  %gmp1992 = inttoptr i64 %t1991 to ptr
  %gml1993 = load i32, ptr %gmp1992, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001167c4 word 0x39002369
  %t1997 = add i64 %r1976, 8
  %c1999 = trunc i64 %c1983 to i32
  %c2000 = trunc i32 %c1999 to i8
  %gmp2001 = inttoptr i64 %t1997 to ptr
  store i8 %c2000, ptr %gmp2001, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001167c8 word 0xf801c3ea
  %r2002 = load i64, ptr %loc_sp, align 8
  %t2003 = add i64 %r2002, 28
  %gmp2005 = inttoptr i64 %t2003 to ptr
  store i64 %gml1988, ptr %gmp2005, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001167cc word 0xb90027e8
  %t2007 = add i64 %r2002, 36
  %gmp2010 = inttoptr i64 %t2007 to ptr
  store i32 %gml1993, ptr %gmp2010, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001167d0 word 0x14000201
  br label %L_800116fd4
L_8001167d4:
  ; @pc 0x8001167d4 word 0xf94f6681
  %r2011.p = getelementptr inbounds i8, ptr %c, i64 160
  %r2011 = load i64, ptr %r2011.p, align 8, !alias.scope !3, !noalias !4
  %t2012 = add i64 %r2011, 7880
  %gmp2013 = inttoptr i64 %t2012 to ptr
  %gml2014 = load i64, ptr %gmp2013, align 1, !alias.scope !4, !noalias !3
  %wp2015 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %gml2014, ptr %wp2015, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001167d8 word 0x9100418c
  %r2016.p = getelementptr inbounds i8, ptr %c, i64 96
  %r2016 = load i64, ptr %r2016.p, align 8, !alias.scope !3, !noalias !4
  %t2017 = add i64 %r2016, 16
  %wp2018 = getelementptr inbounds i8, ptr %c, i64 96
  store i64 %t2017, ptr %wp2018, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001167dc word 0x3940226d
  %r2019.p = getelementptr inbounds i8, ptr %c, i64 152
  %r2019 = load i64, ptr %r2019.p, align 8, !alias.scope !3, !noalias !4
  %t2020 = add i64 %r2019, 8
  %gmp2021 = inttoptr i64 %t2020 to ptr
  %gml2022 = load i8, ptr %gmp2021, align 1, !alias.scope !4, !noalias !3
  %c2023 = zext i8 %gml2022 to i64
  %wp2024 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 %c2023, ptr %wp2024, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001167e0 word 0xb940082e
  %t2026 = add i64 %gml2014, 8
  %gmp2027 = inttoptr i64 %t2026 to ptr
  %gml2028 = load i32, ptr %gmp2027, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001167e4 word 0xf940082f
  %t2032 = add i64 %gml2014, 16
  %gmp2033 = inttoptr i64 %t2032 to ptr
  %gml2034 = load i64, ptr %gmp2033, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001167e8 word 0x6b0d01df
  %c2039 = trunc i64 %c2023 to i32
  ; @pc 0x8001167ec word 0x52879c0e
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7355 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 15584, ptr %cwp7355, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001167f0 word 0x9a9f81b0
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond2064 = icmp ugt i32 %gml2028, %c2039
  %sel2070 = select i1 %cond2064, i64 %c2023, i64 0
  ; @pc 0x8001167f4 word 0x9bae3e0f
  %c2073 = trunc i64 %sel2070 to i32
  %c2074 = zext i32 %c2073 to i64
  %c2076 = trunc i64 15584 to i32
  %c2077 = zext i32 %c2076 to i64
  %t2078 = mul i64 %c2074, %c2077
  %t2080 = add i64 %gml2034, %t2078
  ; @pc 0x8001167f8 word 0xd2c00030
  ; @pc 0x8001167fc word 0xf2e00810
  ; @pc 0x800116800 word 0xf95e21f6
  %t2088 = add i64 %t2080, 15424
  %gmp2089 = inttoptr i64 %t2088 to ptr
  %gml2090 = load i64, ptr %gmp2089, align 1, !alias.scope !4, !noalias !3
  %wp2091 = getelementptr inbounds i8, ptr %c, i64 176
  store i64 %gml2090, ptr %wp2091, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116804 word 0xd280040f
  ; @pc 0x800116808 word 0xb900a3e8
  %r2093 = load i64, ptr %loc_sp, align 8
  %t2094 = add i64 %r2093, 160
  %r2095.p = getelementptr inbounds i8, ptr %c, i64 64
  %r2095 = load i64, ptr %r2095.p, align 8, !alias.scope !3, !noalias !4
  %c2096 = trunc i64 %r2095 to i32
  %gmp2097 = inttoptr i64 %t2094 to ptr
  store i32 %c2096, ptr %gmp2097, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x80011680c word 0x91004148
  %r2098.p = getelementptr inbounds i8, ptr %c, i64 80
  %r2098 = load i64, ptr %r2098.p, align 8, !alias.scope !3, !noalias !4
  %t2099 = add i64 %r2098, 16
  ; @pc 0x800116810 word 0xa908afec
  %t2102 = add i64 %r2093, 136
  %t2103 = add i64 %t2102, 8
  %gmp2105 = inttoptr i64 %t2102 to ptr
  store i64 %t2017, ptr %gmp2105, align 8, !alias.scope !6, !noalias !3
  %r2106.p = getelementptr inbounds i8, ptr %c, i64 88
  %r2106 = load i64, ptr %r2106.p, align 8, !alias.scope !3, !noalias !4
  %gmp2107 = inttoptr i64 %t2103 to ptr
  store i64 %r2106, ptr %gmp2107, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116814 word 0xf900037f
  %r2108 = load i64, ptr %loc_x27, align 8
  %gmp2109 = inttoptr i64 %r2108 to ptr
  store i64 0, ptr %gmp2109, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116818 word 0x3900237f
  %t2111 = add i64 %r2108, 8
  %gmp2113 = inttoptr i64 %t2111 to ptr
  store i8 0, ptr %gmp2113, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011681c word 0xb900bfff
  %t2115 = add i64 %r2093, 188
  %gmp2116 = inttoptr i64 %t2115 to ptr
  store i32 0, ptr %gmp2116, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116820 word 0xf2c0006f
  ; @pc 0x800116824 word 0xa904a3ff
  %t2122 = add i64 %r2093, 72
  %t2123 = add i64 %t2122, 8
  %gmp2124 = inttoptr i64 %t2122 to ptr
  store i64 0, ptr %gmp2124, align 8, !alias.scope !6, !noalias !3
  %gmp2126 = inttoptr i64 %t2123 to ptr
  store i64 %t2099, ptr %gmp2126, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116828 word 0x528000c8
  ; @pc 0x80011682c word 0xa905ffff
  %t2130 = add i64 %r2093, 88
  ; [AArch64IdiomDeconstructPass] coalesced paired 64-bit zero stores -> i128
  %stpp7359 = inttoptr i64 %t2130 to ptr
  store i128 0, ptr %stpp7359, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116830 word 0x29067fe8
  %t2135 = add i64 %r2093, 48
  %t2136 = add i64 %t2135, 4
  %gmp2139 = inttoptr i64 %t2135 to ptr
  store i32 6, ptr %gmp2139, align 4, !alias.scope !6, !noalias !3
  %gmp2140 = inttoptr i64 %t2136 to ptr
  store i32 0, ptr %gmp2140, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116834 word 0xa90043ef
  %t2142 = add i64 %r2093, 8
  %gmp2144 = inttoptr i64 %r2093 to ptr
  store i64 12884901920, ptr %gmp2144, align 8, !alias.scope !6, !noalias !3
  %gmp2146 = inttoptr i64 %t2142 to ptr
  store i64 18014402804449280, ptr %gmp2146, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116838 word 0x929ffed0
  ; @pc 0x80011683c word 0x529fffef
  ; @pc 0x800116840 word 0xf2a00010
  ; @pc 0x800116844 word 0xa90143ef
  %t2155 = add i64 %r2093, 16
  %t2156 = add i64 %t2155, 8
  %gmp2158 = inttoptr i64 %t2155 to ptr
  store i64 65535, ptr %gmp2158, align 8, !alias.scope !6, !noalias !3
  %gmp2160 = inttoptr i64 %t2156 to ptr
  store i64 18446744069414584329, ptr %gmp2160, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116848 word 0xd2c0002f
  ; @pc 0x80011684c word 0xb2607ff0
  ; @pc 0x800116850 word 0xa90243ef
  %t2165 = add i64 %r2093, 32
  %t2166 = add i64 %t2165, 8
  %gmp2168 = inttoptr i64 %t2165 to ptr
  store i64 4294967296, ptr %gmp2168, align 8, !alias.scope !6, !noalias !3
  %gmp2170 = inttoptr i64 %t2166 to ptr
  store i64 18446744069414584320, ptr %gmp2170, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116854 word 0xb2091bef
  ; @pc 0x800116858 word 0xd2e7f010
  ; @pc 0x80011685c word 0xf80a4310
  %r2174.p = getelementptr inbounds i8, ptr %c, i64 192
  %r2174 = load i64, ptr %r2174.p, align 8, !alias.scope !3, !noalias !4
  %t2175 = add i64 %r2174, 164
  %gmp2177 = inttoptr i64 %t2175 to ptr
  store i64 4575657221408423936, ptr %gmp2177, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116860 word 0xa903bfef
  %t2179 = add i64 %r2093, 56
  %t2180 = add i64 %t2179, 8
  %gmp2182 = inttoptr i64 %t2179 to ptr
  store i64 4575657222473777152, ptr %gmp2182, align 8, !alias.scope !6, !noalias !3
  %gmp2184 = inttoptr i64 %t2180 to ptr
  store i64 4575657222473777152, ptr %gmp2184, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116864 word 0x90015b6f
  ; @pc 0x800116868 word 0x9115e5ef
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7365 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 34406409593, ptr %cwp7365, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011686c word 0xb2087bf0
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7366 = getelementptr inbounds i8, ptr %c, i64 128
  store i64 18410715276682199039, ptr %cwp7366, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116870 word 0xf9004ff0
  %t2192 = add i64 %r2093, 152
  %gmp2194 = inttoptr i64 %t2192 to ptr
  store i64 18410715276682199039, ptr %gmp2194, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116874 word 0xa907c3eb
  %t2196 = add i64 %r2093, 120
  %t2197 = add i64 %t2196, 8
  %gmp2199 = inttoptr i64 %t2196 to ptr
  store i64 %r2106, ptr %gmp2199, align 8, !alias.scope !6, !noalias !3
  %gmp2201 = inttoptr i64 %t2197 to ptr
  store i64 18410715276682199039, ptr %gmp2201, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116878 word 0xa906bfff
  %t2203 = add i64 %r2093, 104
  %t2204 = add i64 %t2203, 8
  %gmp2205 = inttoptr i64 %t2203 to ptr
  store i64 0, ptr %gmp2205, align 8, !alias.scope !6, !noalias !3
  %gmp2207 = inttoptr i64 %t2204 to ptr
  store i64 34406409593, ptr %gmp2207, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x80011687c word 0xb9400828
  %t2209 = add i64 %gml2014, 8
  %gmp2210 = inttoptr i64 %t2209 to ptr
  %gml2211 = load i32, ptr %gmp2210, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116880 word 0xf940082a
  %t2215 = add i64 %gml2014, 16
  %gmp2216 = inttoptr i64 %t2215 to ptr
  %gml2217 = load i64, ptr %gmp2216, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116884 word 0x6b0d011f
  ; @pc 0x800116888 word 0x9a9f81a8
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond2245 = icmp ugt i32 %gml2211, %c2039
  %sel2251 = select i1 %cond2245, i64 %c2023, i64 0
  ; @pc 0x80011688c word 0x9bae2908
  %c2254 = trunc i64 %sel2251 to i32
  %c2255 = zext i32 %c2254 to i64
  %c2258 = zext i32 %c2076 to i64
  %t2259 = mul i64 %c2255, %c2258
  %t2261 = add i64 %gml2217, %t2259
  ; @pc 0x800116890 word 0xf957010a
  %t2264 = add i64 %t2261, 11776
  %gmp2265 = inttoptr i64 %t2264 to ptr
  %gml2266 = load i64, ptr %gmp2265, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116894 word 0xf9570508
  %t2269 = add i64 %t2261, 11784
  %gmp2270 = inttoptr i64 %t2269 to ptr
  %gml2271 = load i64, ptr %gmp2270, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116898 word 0xa900212a
  %r2273.p = getelementptr inbounds i8, ptr %c, i64 72
  %r2273 = load i64, ptr %r2273.p, align 8, !alias.scope !3, !noalias !4
  %t2274 = add i64 %r2273, 8
  %gmp2276 = inttoptr i64 %r2273 to ptr
  store i64 %gml2266, ptr %gmp2276, align 1, !alias.scope !4, !noalias !3
  %gmp2278 = inttoptr i64 %t2274 to ptr
  store i64 %gml2271, ptr %gmp2278, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011689c word 0xb9400828
  %t2280 = add i64 %gml2014, 8
  %gmp2281 = inttoptr i64 %t2280 to ptr
  %gml2282 = load i32, ptr %gmp2281, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001168a0 word 0xf9400829
  %t2286 = add i64 %gml2014, 16
  %gmp2287 = inttoptr i64 %t2286 to ptr
  %gml2288 = load i64, ptr %gmp2287, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001168a4 word 0x6b0d011f
  ; @pc 0x8001168a8 word 0x9a9f81a8
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond2316 = icmp ugt i32 %gml2282, %c2039
  %sel2322 = select i1 %cond2316, i64 %c2023, i64 0
  ; @pc 0x8001168ac word 0x9bae2508
  %c2325 = trunc i64 %sel2322 to i32
  %c2326 = zext i32 %c2325 to i64
  %c2329 = zext i32 %c2076 to i64
  %t2330 = mul i64 %c2326, %c2329
  %t2332 = add i64 %gml2288, %t2330
  %wp2333 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %t2332, ptr %wp2333, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001168b0 word 0x14000036
  br label %L_800116988
L_8001168b4:
  ; @pc 0x8001168b4 word 0xf94f6681
  %r2334.p = getelementptr inbounds i8, ptr %c, i64 160
  %r2334 = load i64, ptr %r2334.p, align 8, !alias.scope !3, !noalias !4
  %t2335 = add i64 %r2334, 7880
  %gmp2336 = inttoptr i64 %t2335 to ptr
  %gml2337 = load i64, ptr %gmp2336, align 1, !alias.scope !4, !noalias !3
  %wp2338 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %gml2337, ptr %wp2338, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001168b8 word 0x52879c10
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7367 = getelementptr inbounds i8, ptr %c, i64 128
  store i64 15584, ptr %cwp7367, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001168bc word 0x9100418c
  %r2341.p = getelementptr inbounds i8, ptr %c, i64 96
  %r2341 = load i64, ptr %r2341.p, align 8, !alias.scope !3, !noalias !4
  %t2342 = add i64 %r2341, 16
  %wp2343 = getelementptr inbounds i8, ptr %c, i64 96
  store i64 %t2342, ptr %wp2343, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001168c0 word 0x3940226d
  %r2344.p = getelementptr inbounds i8, ptr %c, i64 152
  %r2344 = load i64, ptr %r2344.p, align 8, !alias.scope !3, !noalias !4
  %t2345 = add i64 %r2344, 8
  %gmp2346 = inttoptr i64 %t2345 to ptr
  %gml2347 = load i8, ptr %gmp2346, align 1, !alias.scope !4, !noalias !3
  %c2348 = zext i8 %gml2347 to i64
  %wp2349 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 %c2348, ptr %wp2349, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001168c4 word 0xb940082e
  %t2351 = add i64 %gml2337, 8
  %gmp2352 = inttoptr i64 %t2351 to ptr
  %gml2353 = load i32, ptr %gmp2352, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001168c8 word 0xf940082f
  %t2357 = add i64 %gml2337, 16
  %gmp2358 = inttoptr i64 %t2357 to ptr
  %gml2359 = load i64, ptr %gmp2358, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001168cc word 0x6b0d01df
  %c2364 = trunc i64 %c2348 to i32
  ; @pc 0x8001168d0 word 0x9a9f81ae
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond2387 = icmp ugt i32 %gml2353, %c2364
  %sel2393 = select i1 %cond2387, i64 %c2348, i64 0
  ; @pc 0x8001168d4 word 0x9bb03dce
  %c2396 = trunc i64 %sel2393 to i32
  %c2397 = zext i32 %c2396 to i64
  %c2399 = trunc i64 15584 to i32
  %c2400 = zext i32 %c2399 to i64
  %t2401 = mul i64 %c2397, %c2400
  %t2403 = add i64 %gml2359, %t2401
  ; @pc 0x8001168d8 word 0x929ffe4f
  ; @pc 0x8001168dc word 0xf2a0000f
  ; @pc 0x8001168e0 word 0xf95e21d6
  %t2411 = add i64 %t2403, 15424
  %gmp2412 = inttoptr i64 %t2411 to ptr
  %gml2413 = load i64, ptr %gmp2412, align 1, !alias.scope !4, !noalias !3
  %wp2414 = getelementptr inbounds i8, ptr %c, i64 176
  store i64 %gml2413, ptr %wp2414, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001168e4 word 0xd280020e
  ; @pc 0x8001168e8 word 0xb900a3e8
  %r2416 = load i64, ptr %loc_sp, align 8
  %t2417 = add i64 %r2416, 160
  %r2418.p = getelementptr inbounds i8, ptr %c, i64 64
  %r2418 = load i64, ptr %r2418.p, align 8, !alias.scope !3, !noalias !4
  %c2419 = trunc i64 %r2418 to i32
  %gmp2420 = inttoptr i64 %t2417 to ptr
  store i32 %c2419, ptr %gmp2420, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001168ec word 0x91004148
  %r2421.p = getelementptr inbounds i8, ptr %c, i64 80
  %r2421 = load i64, ptr %r2421.p, align 8, !alias.scope !3, !noalias !4
  %t2422 = add i64 %r2421, 16
  ; @pc 0x8001168f0 word 0xa908afec
  %t2425 = add i64 %r2416, 136
  %t2426 = add i64 %t2425, 8
  %gmp2428 = inttoptr i64 %t2425 to ptr
  store i64 %t2342, ptr %gmp2428, align 8, !alias.scope !6, !noalias !3
  %r2429.p = getelementptr inbounds i8, ptr %c, i64 88
  %r2429 = load i64, ptr %r2429.p, align 8, !alias.scope !3, !noalias !4
  %gmp2430 = inttoptr i64 %t2426 to ptr
  store i64 %r2429, ptr %gmp2430, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001168f4 word 0xf900037f
  %r2431 = load i64, ptr %loc_x27, align 8
  %gmp2432 = inttoptr i64 %r2431 to ptr
  store i64 0, ptr %gmp2432, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001168f8 word 0x3900237f
  %t2434 = add i64 %r2431, 8
  %gmp2436 = inttoptr i64 %t2434 to ptr
  store i8 0, ptr %gmp2436, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001168fc word 0xb900bfff
  %t2438 = add i64 %r2416, 188
  %gmp2439 = inttoptr i64 %t2438 to ptr
  store i32 0, ptr %gmp2439, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116900 word 0xf2c0006e
  ; @pc 0x800116904 word 0xa904a3ff
  %t2445 = add i64 %r2416, 72
  %t2446 = add i64 %t2445, 8
  %gmp2447 = inttoptr i64 %t2445 to ptr
  store i64 0, ptr %gmp2447, align 8, !alias.scope !6, !noalias !3
  %gmp2449 = inttoptr i64 %t2446 to ptr
  store i64 %t2422, ptr %gmp2449, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116908 word 0x52800108
  ; @pc 0x80011690c word 0xa905ffff
  %t2453 = add i64 %r2416, 88
  ; [AArch64IdiomDeconstructPass] coalesced paired 64-bit zero stores -> i128
  %stpp7372 = inttoptr i64 %t2453 to ptr
  store i128 0, ptr %stpp7372, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116910 word 0x29067fe8
  %t2458 = add i64 %r2416, 48
  %t2459 = add i64 %t2458, 4
  %gmp2462 = inttoptr i64 %t2458 to ptr
  store i32 8, ptr %gmp2462, align 4, !alias.scope !6, !noalias !3
  %gmp2463 = inttoptr i64 %t2459 to ptr
  store i32 0, ptr %gmp2463, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116914 word 0xa9007fee
  %t2465 = add i64 %r2416, 8
  %gmp2467 = inttoptr i64 %r2416 to ptr
  store i64 12884901904, ptr %gmp2467, align 8, !alias.scope !6, !noalias !3
  %gmp2468 = inttoptr i64 %t2465 to ptr
  store i64 0, ptr %gmp2468, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116918 word 0x529fffee
  ; @pc 0x80011691c word 0xa9013fee
  %t2472 = add i64 %r2416, 16
  %t2473 = add i64 %t2472, 8
  %gmp2475 = inttoptr i64 %t2472 to ptr
  store i64 65535, ptr %gmp2475, align 8, !alias.scope !6, !noalias !3
  %gmp2477 = inttoptr i64 %t2473 to ptr
  store i64 18446744069414584333, ptr %gmp2477, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116920 word 0xd2c0002e
  ; @pc 0x800116924 word 0xb2607fef
  ; @pc 0x800116928 word 0xa9023fee
  %t2482 = add i64 %r2416, 32
  %t2483 = add i64 %t2482, 8
  %gmp2485 = inttoptr i64 %t2482 to ptr
  store i64 4294967296, ptr %gmp2485, align 8, !alias.scope !6, !noalias !3
  %gmp2487 = inttoptr i64 %t2483 to ptr
  store i64 18446744069414584320, ptr %gmp2487, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x80011692c word 0xb2091bee
  ; @pc 0x800116930 word 0xd2e7f00f
  ; @pc 0x800116934 word 0xf80a430f
  %r2491.p = getelementptr inbounds i8, ptr %c, i64 192
  %r2491 = load i64, ptr %r2491.p, align 8, !alias.scope !3, !noalias !4
  %t2492 = add i64 %r2491, 164
  %gmp2494 = inttoptr i64 %t2492 to ptr
  store i64 4575657221408423936, ptr %gmp2494, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116938 word 0xa903bbee
  %t2496 = add i64 %r2416, 56
  %t2497 = add i64 %t2496, 8
  %gmp2499 = inttoptr i64 %t2496 to ptr
  store i64 4575657222473777152, ptr %gmp2499, align 8, !alias.scope !6, !noalias !3
  %gmp2501 = inttoptr i64 %t2497 to ptr
  store i64 4575657222473777152, ptr %gmp2501, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x80011693c word 0x9001588e
  ; @pc 0x800116940 word 0x912d55ce
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7376 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 34406034261, ptr %cwp7376, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116944 word 0xb2087bef
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7377 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 18410715276682199039, ptr %cwp7377, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116948 word 0xf9004fef
  %t2509 = add i64 %r2416, 152
  %gmp2511 = inttoptr i64 %t2509 to ptr
  store i64 18410715276682199039, ptr %gmp2511, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x80011694c word 0xa907bfeb
  %t2513 = add i64 %r2416, 120
  %t2514 = add i64 %t2513, 8
  %gmp2516 = inttoptr i64 %t2513 to ptr
  store i64 %r2429, ptr %gmp2516, align 8, !alias.scope !6, !noalias !3
  %gmp2518 = inttoptr i64 %t2514 to ptr
  store i64 18410715276682199039, ptr %gmp2518, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116950 word 0xa906bbff
  %t2520 = add i64 %r2416, 104
  %t2521 = add i64 %t2520, 8
  %gmp2522 = inttoptr i64 %t2520 to ptr
  store i64 0, ptr %gmp2522, align 8, !alias.scope !6, !noalias !3
  %gmp2524 = inttoptr i64 %t2521 to ptr
  store i64 34406034261, ptr %gmp2524, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116954 word 0xb9400828
  %t2526 = add i64 %gml2337, 8
  %gmp2527 = inttoptr i64 %t2526 to ptr
  %gml2528 = load i32, ptr %gmp2527, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116958 word 0xf940082a
  %t2532 = add i64 %gml2337, 16
  %gmp2533 = inttoptr i64 %t2532 to ptr
  %gml2534 = load i64, ptr %gmp2533, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011695c word 0x6b0d011f
  ; @pc 0x800116960 word 0x9a9f81a8
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond2562 = icmp ugt i32 %gml2528, %c2364
  %sel2568 = select i1 %cond2562, i64 %c2348, i64 0
  ; @pc 0x800116964 word 0x9bb02908
  %c2571 = trunc i64 %sel2568 to i32
  %c2572 = zext i32 %c2571 to i64
  %c2575 = zext i32 %c2399 to i64
  %t2576 = mul i64 %c2572, %c2575
  %t2578 = add i64 %gml2534, %t2576
  ; @pc 0x800116968 word 0xf957010a
  %t2581 = add i64 %t2578, 11776
  %gmp2582 = inttoptr i64 %t2581 to ptr
  %gml2583 = load i64, ptr %gmp2582, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011696c word 0xf9570508
  %t2586 = add i64 %t2578, 11784
  %gmp2587 = inttoptr i64 %t2586 to ptr
  %gml2588 = load i64, ptr %gmp2587, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116970 word 0xa900212a
  %r2590.p = getelementptr inbounds i8, ptr %c, i64 72
  %r2590 = load i64, ptr %r2590.p, align 8, !alias.scope !3, !noalias !4
  %t2591 = add i64 %r2590, 8
  %gmp2593 = inttoptr i64 %r2590 to ptr
  store i64 %gml2583, ptr %gmp2593, align 1, !alias.scope !4, !noalias !3
  %gmp2595 = inttoptr i64 %t2591 to ptr
  store i64 %gml2588, ptr %gmp2595, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116974 word 0xb9400828
  %t2597 = add i64 %gml2337, 8
  %gmp2598 = inttoptr i64 %t2597 to ptr
  %gml2599 = load i32, ptr %gmp2598, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116978 word 0xf9400829
  %t2603 = add i64 %gml2337, 16
  %gmp2604 = inttoptr i64 %t2603 to ptr
  %gml2605 = load i64, ptr %gmp2604, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011697c word 0x6b0d011f
  ; @pc 0x800116980 word 0x9a9f81a8
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond2633 = icmp ugt i32 %gml2599, %c2364
  %sel2639 = select i1 %cond2633, i64 %c2348, i64 0
  ; @pc 0x800116984 word 0x9bb02508
  %c2642 = trunc i64 %sel2639 to i32
  %c2643 = zext i32 %c2642 to i64
  %c2646 = zext i32 %c2399 to i64
  %t2647 = mul i64 %c2643, %c2646
  %t2649 = add i64 %gml2605, %t2647
  %wp2650 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %t2649, ptr %wp2650, align 8, !alias.scope !3, !noalias !4
  br label %L_800116988
L_800116988:
  ; @pc 0x800116988 word 0xf9584109
  %r2651.p = getelementptr inbounds i8, ptr %c, i64 64
  %r2651 = load i64, ptr %r2651.p, align 8, !alias.scope !3, !noalias !4
  %t2652 = add i64 %r2651, 12416
  %gmp2653 = inttoptr i64 %t2652 to ptr
  %gml2654 = load i64, ptr %gmp2653, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011698c word 0xaa1603e0
  %r2656.p = getelementptr inbounds i8, ptr %c, i64 176
  %r2656 = load i64, ptr %r2656.p, align 8, !alias.scope !3, !noalias !4
  %wp2658 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 %r2656, ptr %wp2658, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116990 word 0x2a1f03e2
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7378 = getelementptr inbounds i8, ptr %c, i64 16
  store i64 0, ptr %cwp7378, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116994 word 0xf958450a
  %t2663 = add i64 %r2651, 12424
  %gmp2664 = inttoptr i64 %t2663 to ptr
  %gml2665 = load i64, ptr %gmp2664, align 1, !alias.scope !4, !noalias !3
  %wp2666 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 %gml2665, ptr %wp2666, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116998 word 0xa9002b49
  %r2667.p = getelementptr inbounds i8, ptr %c, i64 208
  %r2667 = load i64, ptr %r2667.p, align 8, !alias.scope !3, !noalias !4
  %t2668 = add i64 %r2667, 8
  %gmp2670 = inttoptr i64 %r2667 to ptr
  store i64 %gml2654, ptr %gmp2670, align 1, !alias.scope !4, !noalias !3
  %gmp2672 = inttoptr i64 %t2668 to ptr
  store i64 %gml2665, ptr %gmp2672, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011699c word 0xf9584909
  %t2674 = add i64 %r2651, 12432
  %gmp2675 = inttoptr i64 %t2674 to ptr
  %gml2676 = load i64, ptr %gmp2675, align 1, !alias.scope !4, !noalias !3
  %wp2677 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %gml2676, ptr %wp2677, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001169a0 word 0xb9709908
  %t2679 = add i64 %r2651, 12440
  %gmp2680 = inttoptr i64 %t2679 to ptr
  %gml2681 = load i32, ptr %gmp2680, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001169a4 word 0xb9000b28
  %r2684.p = getelementptr inbounds i8, ptr %c, i64 200
  %r2684 = load i64, ptr %r2684.p, align 8, !alias.scope !3, !noalias !4
  %t2685 = add i64 %r2684, 8
  %gmp2688 = inttoptr i64 %t2685 to ptr
  store i32 %gml2681, ptr %gmp2688, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001169a8 word 0xd10027a8
  %r2689 = load i64, ptr %loc_x29, align 8
  %t2690 = sub i64 %r2689, 9
  %wp2691 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %t2690, ptr %wp2691, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001169ac word 0xf9000329
  %gmp2694 = inttoptr i64 %r2684 to ptr
  store i64 %gml2676, ptr %gmp2694, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001169b0 word 0x9400038a
  %wp2695 = getelementptr inbounds i8, ptr %c, i64 240
  store i64 34360879540, ptr %wp2695, align 8, !alias.scope !3, !noalias !4
  call void @f_8001177d8(ptr %c)
  ; @pc 0x8001169b4 word 0x5282c088
  ; @pc 0x8001169b8 word 0xf84c7309
  %r2698.p = getelementptr inbounds i8, ptr %c, i64 192
  %r2698 = load i64, ptr %r2698.p, align 8, !alias.scope !3, !noalias !4
  %t2699 = add i64 %r2698, 199
  %gmp2700 = inttoptr i64 %t2699 to ptr
  %gml2701 = load i64, ptr %gmp2700, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001169bc word 0xf9000369
  %r2703 = load i64, ptr %loc_x27, align 8
  %gmp2705 = inttoptr i64 %r2703 to ptr
  store i64 %gml2701, ptr %gmp2705, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001169c0 word 0xf8686ac8
  %r2706.p = getelementptr inbounds i8, ptr %c, i64 176
  %r2706 = load i64, ptr %r2706.p, align 8, !alias.scope !3, !noalias !4
  %t2708 = add i64 %r2706, 5636
  %gmp2709 = inttoptr i64 %t2708 to ptr
  %gml2710 = load i64, ptr %gmp2709, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001169c4 word 0x385ff3aa
  %r2712 = load i64, ptr %loc_x29, align 8
  %t2713 = add i64 %r2712, -1
  %gmp2714 = inttoptr i64 %t2713 to ptr
  %gml2715 = load i8, ptr %gmp2714, align 1, !alias.scope !6, !noalias !3
  %c2716 = zext i8 %gml2715 to i64
  ; @pc 0x8001169c8 word 0x3900236a
  %t2719 = add i64 %r2703, 8
  %c2721 = trunc i64 %c2716 to i32
  %c2722 = trunc i32 %c2721 to i8
  %gmp2723 = inttoptr i64 %t2719 to ptr
  store i8 %c2722, ptr %gmp2723, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001169cc word 0xf801c3e8
  %r2724 = load i64, ptr %loc_sp, align 8
  %t2725 = add i64 %r2724, 28
  %gmp2727 = inttoptr i64 %t2725 to ptr
  store i64 %gml2710, ptr %gmp2727, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001169d0 word 0xb9560ec8
  %t2729 = add i64 %r2706, 5644
  %gmp2730 = inttoptr i64 %t2729 to ptr
  %gml2731 = load i32, ptr %gmp2730, align 1, !alias.scope !4, !noalias !3
  %c2732 = zext i32 %gml2731 to i64
  %wp2733 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %c2732, ptr %wp2733, align 8, !alias.scope !3, !noalias !4
  br label %L_8001169d4
L_8001169d4:
  ; @pc 0x8001169d4 word 0x52800049
  ; @pc 0x8001169d8 word 0xb90027e8
  %r2736 = load i64, ptr %loc_sp, align 8
  %t2737 = add i64 %r2736, 36
  %r2738.p = getelementptr inbounds i8, ptr %c, i64 64
  %r2738 = load i64, ptr %r2738.p, align 8, !alias.scope !3, !noalias !4
  %c2739 = trunc i64 %r2738 to i32
  %gmp2740 = inttoptr i64 %t2737 to ptr
  store i32 %c2739, ptr %gmp2740, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001169dc word 0xb900bfe9
  %t2742 = add i64 %r2736, 188
  %gmp2745 = inttoptr i64 %t2742 to ptr
  store i32 2, ptr %gmp2745, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001169e0 word 0x1400017d
  br label %L_800116fd4
L_8001169e4:
  ; @pc 0x8001169e4 word 0x5283d608
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7381 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 7856, ptr %cwp7381, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001169e8 word 0x910003e1
  %r2748 = load i64, ptr %loc_sp, align 8
  %t2749 = add i64 %r2748, 0
  %wp2750 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %t2749, ptr %wp2750, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001169ec word 0xaa1303e2
  %r2751.p = getelementptr inbounds i8, ptr %c, i64 152
  %r2751 = load i64, ptr %r2751.p, align 8, !alias.scope !3, !noalias !4
  %wp2753 = getelementptr inbounds i8, ptr %c, i64 16
  store i64 %r2751, ptr %wp2753, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001169f0 word 0x8b080280
  %r2754.p = getelementptr inbounds i8, ptr %c, i64 160
  %r2754 = load i64, ptr %r2754.p, align 8, !alias.scope !3, !noalias !4
  %t2756 = add i64 %r2754, 7856
  %wp2757 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 %t2756, ptr %wp2757, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001169f4 word 0x9400039d
  %wp2758 = getelementptr inbounds i8, ptr %c, i64 240
  store i64 34360879608, ptr %wp2758, align 8, !alias.scope !3, !noalias !4
  call void @f_800117868(ptr %c)
  ; @pc 0x8001169f8 word 0x14000177
  br label %L_800116fd4
L_8001169fc:
  ; @pc 0x8001169fc word 0x5280010d
  ; @pc 0x800116a00 word 0xd2e0080e
  ; @pc 0x800116a04 word 0x529fffef
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7383 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 65535, ptr %cwp7383, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116a08 word 0xa9003bed
  %r2764 = load i64, ptr %loc_sp, align 8
  %t2765 = add i64 %r2764, 8
  %gmp2767 = inttoptr i64 %r2764 to ptr
  store i64 8, ptr %gmp2767, align 8, !alias.scope !6, !noalias !3
  %gmp2769 = inttoptr i64 %t2765 to ptr
  store i64 18014398509481984, ptr %gmp2769, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116a0c word 0x929ffd4d
  ; @pc 0x800116a10 word 0xf2a0000d
  ; @pc 0x800116a14 word 0xb2607fee
  ; @pc 0x800116a18 word 0xa90137ef
  %t2778 = add i64 %r2764, 16
  %t2779 = add i64 %t2778, 8
  %gmp2781 = inttoptr i64 %t2778 to ptr
  store i64 65535, ptr %gmp2781, align 8, !alias.scope !6, !noalias !3
  %gmp2783 = inttoptr i64 %t2779 to ptr
  store i64 18446744069414584341, ptr %gmp2783, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116a1c word 0xd2c0002d
  ; @pc 0x800116a20 word 0xa9023bed
  %t2786 = add i64 %r2764, 32
  %t2787 = add i64 %t2786, 8
  %gmp2789 = inttoptr i64 %t2786 to ptr
  store i64 4294967296, ptr %gmp2789, align 8, !alias.scope !6, !noalias !3
  %gmp2791 = inttoptr i64 %t2787 to ptr
  store i64 18446744069414584320, ptr %gmp2791, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116a24 word 0x1280000d
  ; @pc 0x800116a28 word 0xb2091bee
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7388 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 4575657222473777152, ptr %cwp7388, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116a2c word 0xa9033bed
  %t2797 = add i64 %r2764, 48
  %t2798 = add i64 %t2797, 8
  %gmp2800 = inttoptr i64 %t2797 to ptr
  store i64 4294967295, ptr %gmp2800, align 8, !alias.scope !6, !noalias !3
  %gmp2802 = inttoptr i64 %t2798 to ptr
  store i64 4575657222473777152, ptr %gmp2802, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116a30 word 0xd0015a0d
  ; @pc 0x800116a34 word 0x9129e5ad
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7389 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 34406238841, ptr %cwp7389, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116a38 word 0x1400013b
  br label %L_800116f24
L_800116a3c:
  ; @pc 0x800116a3c word 0xf94f6681
  %r2807.p = getelementptr inbounds i8, ptr %c, i64 160
  %r2807 = load i64, ptr %r2807.p, align 8, !alias.scope !3, !noalias !4
  %t2808 = add i64 %r2807, 7880
  %gmp2809 = inttoptr i64 %t2808 to ptr
  %gml2810 = load i64, ptr %gmp2809, align 1, !alias.scope !4, !noalias !3
  %wp2811 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %gml2810, ptr %wp2811, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116a40 word 0x9100418c
  %r2812.p = getelementptr inbounds i8, ptr %c, i64 96
  %r2812 = load i64, ptr %r2812.p, align 8, !alias.scope !3, !noalias !4
  %t2813 = add i64 %r2812, 16
  %wp2814 = getelementptr inbounds i8, ptr %c, i64 96
  store i64 %t2813, ptr %wp2814, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116a44 word 0x2a1f03e2
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7390 = getelementptr inbounds i8, ptr %c, i64 16
  store i64 0, ptr %cwp7390, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116a48 word 0x3940226d
  %r2818.p = getelementptr inbounds i8, ptr %c, i64 152
  %r2818 = load i64, ptr %r2818.p, align 8, !alias.scope !3, !noalias !4
  %t2819 = add i64 %r2818, 8
  %gmp2820 = inttoptr i64 %t2819 to ptr
  %gml2821 = load i8, ptr %gmp2820, align 1, !alias.scope !4, !noalias !3
  %c2822 = zext i8 %gml2821 to i64
  %wp2823 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 %c2822, ptr %wp2823, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116a4c word 0xb940082e
  %t2825 = add i64 %gml2810, 8
  %gmp2826 = inttoptr i64 %t2825 to ptr
  %gml2827 = load i32, ptr %gmp2826, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116a50 word 0xf940082f
  %t2831 = add i64 %gml2810, 16
  %gmp2832 = inttoptr i64 %t2831 to ptr
  %gml2833 = load i64, ptr %gmp2832, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116a54 word 0x6b0d01df
  %c2838 = trunc i64 %c2822 to i32
  ; @pc 0x800116a58 word 0x52879c0e
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7391 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 15584, ptr %cwp7391, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116a5c word 0x9a9f81b0
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond2863 = icmp ugt i32 %gml2827, %c2838
  %sel2869 = select i1 %cond2863, i64 %c2822, i64 0
  ; @pc 0x800116a60 word 0x9bae3e0f
  %c2872 = trunc i64 %sel2869 to i32
  %c2873 = zext i32 %c2872 to i64
  %c2875 = trunc i64 15584 to i32
  %c2876 = zext i32 %c2875 to i64
  %t2877 = mul i64 %c2873, %c2876
  %t2879 = add i64 %gml2833, %t2877
  ; @pc 0x800116a64 word 0xd2c10010
  ; @pc 0x800116a68 word 0xf2e00850
  ; @pc 0x800116a6c word 0xf95e21e0
  %t2887 = add i64 %t2879, 15424
  %gmp2888 = inttoptr i64 %t2887 to ptr
  %gml2889 = load i64, ptr %gmp2888, align 1, !alias.scope !4, !noalias !3
  %wp2890 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 %gml2889, ptr %wp2890, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116a70 word 0x5280040f
  ; @pc 0x800116a74 word 0xb900a3e8
  %r2893 = load i64, ptr %loc_sp, align 8
  %t2894 = add i64 %r2893, 160
  %r2895.p = getelementptr inbounds i8, ptr %c, i64 64
  %r2895 = load i64, ptr %r2895.p, align 8, !alias.scope !3, !noalias !4
  %c2896 = trunc i64 %r2895 to i32
  %gmp2897 = inttoptr i64 %t2894 to ptr
  store i32 %c2896, ptr %gmp2897, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116a78 word 0x91004148
  %r2898.p = getelementptr inbounds i8, ptr %c, i64 80
  %r2898 = load i64, ptr %r2898.p, align 8, !alias.scope !3, !noalias !4
  %t2899 = add i64 %r2898, 16
  ; @pc 0x800116a7c word 0xa908afec
  %t2902 = add i64 %r2893, 136
  %t2903 = add i64 %t2902, 8
  %gmp2905 = inttoptr i64 %t2902 to ptr
  store i64 %t2813, ptr %gmp2905, align 8, !alias.scope !6, !noalias !3
  %r2906.p = getelementptr inbounds i8, ptr %c, i64 88
  %r2906 = load i64, ptr %r2906.p, align 8, !alias.scope !3, !noalias !4
  %gmp2907 = inttoptr i64 %t2903 to ptr
  store i64 %r2906, ptr %gmp2907, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116a80 word 0xf900037f
  %r2908 = load i64, ptr %loc_x27, align 8
  %gmp2909 = inttoptr i64 %r2908 to ptr
  store i64 0, ptr %gmp2909, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116a84 word 0x3900237f
  %t2911 = add i64 %r2908, 8
  %gmp2913 = inttoptr i64 %t2911 to ptr
  store i8 0, ptr %gmp2913, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116a88 word 0xb900bfff
  %t2915 = add i64 %r2893, 188
  %gmp2916 = inttoptr i64 %t2915 to ptr
  store i32 0, ptr %gmp2916, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116a8c word 0xa905ffff
  %t2918 = add i64 %r2893, 88
  ; [AArch64IdiomDeconstructPass] coalesced paired 64-bit zero stores -> i128
  %stpp7394 = inttoptr i64 %t2918 to ptr
  store i128 0, ptr %stpp7394, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116a90 word 0xa90043ef
  %t2923 = add i64 %r2893, 8
  %gmp2925 = inttoptr i64 %r2893 to ptr
  store i64 32, ptr %gmp2925, align 8, !alias.scope !6, !noalias !3
  %gmp2927 = inttoptr i64 %t2923 to ptr
  store i64 18586144555925504, ptr %gmp2927, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116a94 word 0x929ffeb0
  ; @pc 0x800116a98 word 0x529fffef
  ; @pc 0x800116a9c word 0xa904a3ff
  %t2932 = add i64 %r2893, 72
  %t2933 = add i64 %t2932, 8
  %gmp2934 = inttoptr i64 %t2932 to ptr
  store i64 0, ptr %gmp2934, align 8, !alias.scope !6, !noalias !3
  %gmp2936 = inttoptr i64 %t2933 to ptr
  store i64 %t2899, ptr %gmp2936, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116aa0 word 0x528000e8
  ; @pc 0x800116aa4 word 0xf2a00010
  ; @pc 0x800116aa8 word 0x29067fe8
  %t2944 = add i64 %r2893, 48
  %t2945 = add i64 %t2944, 4
  %gmp2948 = inttoptr i64 %t2944 to ptr
  store i32 7, ptr %gmp2948, align 4, !alias.scope !6, !noalias !3
  %gmp2949 = inttoptr i64 %t2945 to ptr
  store i32 0, ptr %gmp2949, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116aac word 0xa90143ef
  %t2951 = add i64 %r2893, 16
  %t2952 = add i64 %t2951, 8
  %gmp2954 = inttoptr i64 %t2951 to ptr
  store i64 65535, ptr %gmp2954, align 8, !alias.scope !6, !noalias !3
  %gmp2956 = inttoptr i64 %t2952 to ptr
  store i64 18446744069414584330, ptr %gmp2956, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116ab0 word 0xd2c0002f
  ; @pc 0x800116ab4 word 0xb2607ff0
  ; @pc 0x800116ab8 word 0xa90243ef
  %t2961 = add i64 %r2893, 32
  %t2962 = add i64 %t2961, 8
  %gmp2964 = inttoptr i64 %t2961 to ptr
  store i64 4294967296, ptr %gmp2964, align 8, !alias.scope !6, !noalias !3
  %gmp2966 = inttoptr i64 %t2962 to ptr
  store i64 18446744069414584320, ptr %gmp2966, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116abc word 0xb2091bef
  ; @pc 0x800116ac0 word 0xd2e7f010
  ; @pc 0x800116ac4 word 0xf80a4310
  %r2970.p = getelementptr inbounds i8, ptr %c, i64 192
  %r2970 = load i64, ptr %r2970.p, align 8, !alias.scope !3, !noalias !4
  %t2971 = add i64 %r2970, 164
  %gmp2973 = inttoptr i64 %t2971 to ptr
  store i64 4575657221408423936, ptr %gmp2973, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116ac8 word 0xa903bfef
  %t2975 = add i64 %r2893, 56
  %t2976 = add i64 %t2975, 8
  %gmp2978 = inttoptr i64 %t2975 to ptr
  store i64 4575657222473777152, ptr %gmp2978, align 8, !alias.scope !6, !noalias !3
  %gmp2980 = inttoptr i64 %t2976 to ptr
  store i64 4575657222473777152, ptr %gmp2980, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116acc word 0xd0015d6f
  ; @pc 0x800116ad0 word 0x910a3def
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7401 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 34406679183, ptr %cwp7401, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116ad4 word 0xb2087bf0
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7402 = getelementptr inbounds i8, ptr %c, i64 128
  store i64 18410715276682199039, ptr %cwp7402, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116ad8 word 0xf9004ff0
  %t2988 = add i64 %r2893, 152
  %gmp2990 = inttoptr i64 %t2988 to ptr
  store i64 18410715276682199039, ptr %gmp2990, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116adc word 0xa907c3eb
  %t2992 = add i64 %r2893, 120
  %t2993 = add i64 %t2992, 8
  %gmp2995 = inttoptr i64 %t2992 to ptr
  store i64 %r2906, ptr %gmp2995, align 8, !alias.scope !6, !noalias !3
  %gmp2997 = inttoptr i64 %t2993 to ptr
  store i64 18410715276682199039, ptr %gmp2997, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116ae0 word 0xa906bfff
  %t2999 = add i64 %r2893, 104
  %t3000 = add i64 %t2999, 8
  %gmp3001 = inttoptr i64 %t2999 to ptr
  store i64 0, ptr %gmp3001, align 8, !alias.scope !6, !noalias !3
  %gmp3003 = inttoptr i64 %t3000 to ptr
  store i64 34406679183, ptr %gmp3003, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116ae4 word 0xb9400828
  %t3005 = add i64 %gml2810, 8
  %gmp3006 = inttoptr i64 %t3005 to ptr
  %gml3007 = load i32, ptr %gmp3006, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116ae8 word 0xf940082a
  %t3011 = add i64 %gml2810, 16
  %gmp3012 = inttoptr i64 %t3011 to ptr
  %gml3013 = load i64, ptr %gmp3012, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116aec word 0x6b0d011f
  ; @pc 0x800116af0 word 0x9a9f81a8
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond3041 = icmp ugt i32 %gml3007, %c2838
  %sel3047 = select i1 %cond3041, i64 %c2822, i64 0
  ; @pc 0x800116af4 word 0x9bae2908
  %c3050 = trunc i64 %sel3047 to i32
  %c3051 = zext i32 %c3050 to i64
  %c3054 = zext i32 %c2875 to i64
  %t3055 = mul i64 %c3051, %c3054
  %t3057 = add i64 %gml3013, %t3055
  ; @pc 0x800116af8 word 0xf958590a
  %t3060 = add i64 %t3057, 12464
  %gmp3061 = inttoptr i64 %t3060 to ptr
  %gml3062 = load i64, ptr %gmp3061, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116afc word 0xf9585d08
  %t3065 = add i64 %t3057, 12472
  %gmp3066 = inttoptr i64 %t3065 to ptr
  %gml3067 = load i64, ptr %gmp3066, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116b00 word 0xa900212a
  %r3069.p = getelementptr inbounds i8, ptr %c, i64 72
  %r3069 = load i64, ptr %r3069.p, align 8, !alias.scope !3, !noalias !4
  %t3070 = add i64 %r3069, 8
  %gmp3072 = inttoptr i64 %r3069 to ptr
  store i64 %gml3062, ptr %gmp3072, align 1, !alias.scope !4, !noalias !3
  %gmp3074 = inttoptr i64 %t3070 to ptr
  store i64 %gml3067, ptr %gmp3074, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116b04 word 0xb9400828
  %t3076 = add i64 %gml2810, 8
  %gmp3077 = inttoptr i64 %t3076 to ptr
  %gml3078 = load i32, ptr %gmp3077, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116b08 word 0xf9400829
  %t3082 = add i64 %gml2810, 16
  %gmp3083 = inttoptr i64 %t3082 to ptr
  %gml3084 = load i64, ptr %gmp3083, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116b0c word 0x6b0d011f
  ; @pc 0x800116b10 word 0x9a9f81a8
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond3112 = icmp ugt i32 %gml3078, %c2838
  %sel3118 = select i1 %cond3112, i64 %c2822, i64 0
  ; @pc 0x800116b14 word 0x9bae2508
  %c3121 = trunc i64 %sel3118 to i32
  %c3122 = zext i32 %c3121 to i64
  %c3125 = zext i32 %c2875 to i64
  %t3126 = mul i64 %c3122, %c3125
  %t3128 = add i64 %gml3084, %t3126
  ; @pc 0x800116b18 word 0xf9599909
  %t3131 = add i64 %t3128, 13104
  %gmp3132 = inttoptr i64 %t3131 to ptr
  %gml3133 = load i64, ptr %gmp3132, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116b1c word 0xf9599d0a
  %t3136 = add i64 %t3128, 13112
  %gmp3137 = inttoptr i64 %t3136 to ptr
  %gml3138 = load i64, ptr %gmp3137, align 1, !alias.scope !4, !noalias !3
  %wp3139 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 %gml3138, ptr %wp3139, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116b20 word 0xa9002b49
  %r3140.p = getelementptr inbounds i8, ptr %c, i64 208
  %r3140 = load i64, ptr %r3140.p, align 8, !alias.scope !3, !noalias !4
  %t3141 = add i64 %r3140, 8
  %gmp3143 = inttoptr i64 %r3140 to ptr
  store i64 %gml3133, ptr %gmp3143, align 1, !alias.scope !4, !noalias !3
  %gmp3145 = inttoptr i64 %t3141 to ptr
  store i64 %gml3138, ptr %gmp3145, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116b24 word 0xf959a109
  %t3147 = add i64 %t3128, 13120
  %gmp3148 = inttoptr i64 %t3147 to ptr
  %gml3149 = load i64, ptr %gmp3148, align 1, !alias.scope !4, !noalias !3
  %wp3150 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %gml3149, ptr %wp3150, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116b28 word 0xb9734908
  %t3152 = add i64 %t3128, 13128
  %gmp3153 = inttoptr i64 %t3152 to ptr
  %gml3154 = load i32, ptr %gmp3153, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116b2c word 0xb9000b28
  %r3157.p = getelementptr inbounds i8, ptr %c, i64 200
  %r3157 = load i64, ptr %r3157.p, align 8, !alias.scope !3, !noalias !4
  %t3158 = add i64 %r3157, 8
  %gmp3161 = inttoptr i64 %t3158 to ptr
  store i32 %gml3154, ptr %gmp3161, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116b30 word 0xd10027a8
  %r3162 = load i64, ptr %loc_x29, align 8
  %t3163 = sub i64 %r3162, 9
  %wp3164 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %t3163, ptr %wp3164, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116b34 word 0xf9000329
  %gmp3167 = inttoptr i64 %r3157 to ptr
  store i64 %gml3149, ptr %gmp3167, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116b38 word 0x94000328
  %wp3168 = getelementptr inbounds i8, ptr %c, i64 240
  store i64 34360879932, ptr %wp3168, align 8, !alias.scope !3, !noalias !4
  call void @f_8001177d8(ptr %c)
  ; @pc 0x800116b3c word 0xf84c7308
  %r3169.p = getelementptr inbounds i8, ptr %c, i64 192
  %r3169 = load i64, ptr %r3169.p, align 8, !alias.scope !3, !noalias !4
  %t3170 = add i64 %r3169, 199
  %gmp3171 = inttoptr i64 %t3170 to ptr
  %gml3172 = load i64, ptr %gmp3171, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116b40 word 0xf9000368
  %r3174 = load i64, ptr %loc_x27, align 8
  %gmp3176 = inttoptr i64 %r3174 to ptr
  store i64 %gml3172, ptr %gmp3176, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116b44 word 0x385ff3a8
  %r3177 = load i64, ptr %loc_x29, align 8
  %t3178 = add i64 %r3177, -1
  %gmp3179 = inttoptr i64 %t3178 to ptr
  %gml3180 = load i8, ptr %gmp3179, align 1, !alias.scope !6, !noalias !3
  %c3181 = zext i8 %gml3180 to i64
  ; @pc 0x800116b48 word 0x39002368
  %t3184 = add i64 %r3174, 8
  %c3186 = trunc i64 %c3181 to i32
  %c3187 = trunc i32 %c3186 to i8
  %gmp3188 = inttoptr i64 %t3184 to ptr
  store i8 %c3187, ptr %gmp3188, align 1, !alias.scope !4, !noalias !3
  br label %L_800116b4c
L_800116b4c:
  ; @pc 0x800116b4c word 0x52800048
  ; @pc 0x800116b50 word 0xb900bfe8
  %r3191 = load i64, ptr %loc_sp, align 8
  %t3192 = add i64 %r3191, 188
  %gmp3195 = inttoptr i64 %t3192 to ptr
  store i32 2, ptr %gmp3195, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116b54 word 0x14000120
  br label %L_800116fd4
L_800116b58:
  ; @pc 0x800116b58 word 0x5281000d
  ; @pc 0x800116b5c word 0x5280002e
  ; @pc 0x800116b60 word 0x529fffef
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7406 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 65535, ptr %cwp7406, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116b64 word 0xa9003bed
  %r3202 = load i64, ptr %loc_sp, align 8
  %t3203 = add i64 %r3202, 8
  %gmp3205 = inttoptr i64 %r3202 to ptr
  store i64 2048, ptr %gmp3205, align 8, !alias.scope !6, !noalias !3
  %gmp3207 = inttoptr i64 %t3203 to ptr
  store i64 1, ptr %gmp3207, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116b68 word 0x929ffe8d
  ; @pc 0x800116b6c word 0xf2a0000d
  ; @pc 0x800116b70 word 0xb2607fee
  ; @pc 0x800116b74 word 0xa90137ef
  %t3216 = add i64 %r3202, 16
  %t3217 = add i64 %t3216, 8
  %gmp3219 = inttoptr i64 %t3216 to ptr
  store i64 65535, ptr %gmp3219, align 8, !alias.scope !6, !noalias !3
  %gmp3221 = inttoptr i64 %t3217 to ptr
  store i64 18446744069414584331, ptr %gmp3221, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116b78 word 0xd2c0002d
  ; @pc 0x800116b7c word 0xa9023bed
  %t3224 = add i64 %r3202, 32
  %t3225 = add i64 %t3224, 8
  %gmp3227 = inttoptr i64 %t3224 to ptr
  store i64 4294967296, ptr %gmp3227, align 8, !alias.scope !6, !noalias !3
  %gmp3229 = inttoptr i64 %t3225 to ptr
  store i64 18446744069414584320, ptr %gmp3229, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116b80 word 0x1280000d
  ; @pc 0x800116b84 word 0xb2091bee
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7411 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 4575657222473777152, ptr %cwp7411, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116b88 word 0xa9033bed
  %t3235 = add i64 %r3202, 48
  %t3236 = add i64 %t3235, 8
  %gmp3238 = inttoptr i64 %t3235 to ptr
  store i64 4294967295, ptr %gmp3238, align 8, !alias.scope !6, !noalias !3
  %gmp3240 = inttoptr i64 %t3236 to ptr
  store i64 4575657222473777152, ptr %gmp3240, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116b8c word 0xd00159cd
  ; @pc 0x800116b90 word 0x911745ad
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7412 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 34406204881, ptr %cwp7412, align 8, !alias.scope !3, !noalias !4
  br label %L_800116b94
L_800116b94:
  ; @pc 0x800116b94 word 0xb900a3e8
  %r3245 = load i64, ptr %loc_sp, align 8
  %t3246 = add i64 %r3245, 160
  %r3247.p = getelementptr inbounds i8, ptr %c, i64 64
  %r3247 = load i64, ptr %r3247.p, align 8, !alias.scope !3, !noalias !4
  %c3248 = trunc i64 %r3247 to i32
  %gmp3249 = inttoptr i64 %t3246 to ptr
  store i32 %c3248, ptr %gmp3249, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116b98 word 0xf957ea88
  %r3250.p = getelementptr inbounds i8, ptr %c, i64 160
  %r3250 = load i64, ptr %r3250.p, align 8, !alias.scope !3, !noalias !4
  %t3251 = add i64 %r3250, 12240
  %gmp3252 = inttoptr i64 %t3251 to ptr
  %gml3253 = load i64, ptr %gmp3252, align 1, !alias.scope !4, !noalias !3
  %wp3254 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %gml3253, ptr %wp3254, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116b9c word 0x9100418c
  %r3255.p = getelementptr inbounds i8, ptr %c, i64 96
  %r3255 = load i64, ptr %r3255.p, align 8, !alias.scope !3, !noalias !4
  %t3256 = add i64 %r3255, 16
  ; @pc 0x800116ba0 word 0xa9072fed
  %t3259 = add i64 %r3245, 112
  %t3260 = add i64 %t3259, 8
  %r3261.p = getelementptr inbounds i8, ptr %c, i64 104
  %r3261 = load i64, ptr %r3261.p, align 8, !alias.scope !3, !noalias !4
  %gmp3262 = inttoptr i64 %t3259 to ptr
  store i64 %r3261, ptr %gmp3262, align 8, !alias.scope !6, !noalias !3
  %r3263.p = getelementptr inbounds i8, ptr %c, i64 88
  %r3263 = load i64, ptr %r3263.p, align 8, !alias.scope !3, !noalias !4
  %gmp3264 = inttoptr i64 %t3260 to ptr
  store i64 %r3263, ptr %gmp3264, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116ba4 word 0xb2087bed
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7413 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 18410715276682199039, ptr %cwp7413, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116ba8 word 0x9100414a
  %r3267.p = getelementptr inbounds i8, ptr %c, i64 80
  %r3267 = load i64, ptr %r3267.p, align 8, !alias.scope !3, !noalias !4
  %t3268 = add i64 %r3267, 16
  ; @pc 0x800116bac word 0x3900237f
  %r3270 = load i64, ptr %loc_x27, align 8
  %t3271 = add i64 %r3270, 8
  %gmp3273 = inttoptr i64 %t3271 to ptr
  store i8 0, ptr %gmp3273, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116bb0 word 0xf900037f
  %gmp3275 = inttoptr i64 %r3270 to ptr
  store i64 0, ptr %gmp3275, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116bb4 word 0xb900bfff
  %t3277 = add i64 %r3245, 188
  %gmp3278 = inttoptr i64 %t3277 to ptr
  store i32 0, ptr %gmp3278, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116bb8 word 0xa90833ed
  %t3280 = add i64 %r3245, 128
  %t3281 = add i64 %t3280, 8
  %gmp3283 = inttoptr i64 %t3280 to ptr
  store i64 18410715276682199039, ptr %gmp3283, align 8, !alias.scope !6, !noalias !3
  %gmp3285 = inttoptr i64 %t3281 to ptr
  store i64 %t3256, ptr %gmp3285, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116bbc word 0xd2e7f00c
  ; @pc 0x800116bc0 word 0xf80a430c
  %r3287.p = getelementptr inbounds i8, ptr %c, i64 192
  %r3287 = load i64, ptr %r3287.p, align 8, !alias.scope !3, !noalias !4
  %t3288 = add i64 %r3287, 164
  %gmp3290 = inttoptr i64 %t3288 to ptr
  store i64 4575657221408423936, ptr %gmp3290, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116bc4 word 0xa9047fee
  %t3292 = add i64 %r3245, 64
  %t3293 = add i64 %t3292, 8
  %r3294.p = getelementptr inbounds i8, ptr %c, i64 112
  %r3294 = load i64, ptr %r3294.p, align 8, !alias.scope !3, !noalias !4
  %gmp3295 = inttoptr i64 %t3292 to ptr
  store i64 %r3294, ptr %gmp3295, align 8, !alias.scope !6, !noalias !3
  %gmp3296 = inttoptr i64 %t3293 to ptr
  store i64 0, ptr %gmp3296, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116bc8 word 0xa90937eb
  %t3298 = add i64 %r3245, 144
  %t3299 = add i64 %t3298, 8
  %gmp3301 = inttoptr i64 %t3298 to ptr
  store i64 %r3263, ptr %gmp3301, align 8, !alias.scope !6, !noalias !3
  %gmp3303 = inttoptr i64 %t3299 to ptr
  store i64 18410715276682199039, ptr %gmp3303, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116bcc word 0xa9067fff
  %t3305 = add i64 %r3245, 96
  ; [AArch64IdiomDeconstructPass] coalesced paired 64-bit zero stores -> i128
  %stpp7414 = inttoptr i64 %t3305 to ptr
  store i128 0, ptr %stpp7414, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116bd0 word 0xa9057fea
  %t3310 = add i64 %r3245, 80
  %t3311 = add i64 %t3310, 8
  %gmp3313 = inttoptr i64 %t3310 to ptr
  store i64 %t3268, ptr %gmp3313, align 8, !alias.scope !6, !noalias !3
  %gmp3314 = inttoptr i64 %t3311 to ptr
  store i64 0, ptr %gmp3314, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116bd4 word 0xb4fffbc8
  %cmp3316 = icmp eq i64 %gml3253, 0
  br i1 %cmp3316, label %L_800116b4c, label %L_800116bd8_ft
L_800116c64:
  ; @pc 0x800116c64 word 0x929ffe2f
  ; @pc 0x800116c68 word 0x5280800d
  ; @pc 0x800116c6c word 0x529fffee
  ; @pc 0x800116c70 word 0xf2a0000f
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7418 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 18446744069414584334, ptr %cwp7418, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116c74 word 0xa9007fed
  %r3577 = load i64, ptr %loc_sp, align 8
  %t3578 = add i64 %r3577, 8
  %gmp3580 = inttoptr i64 %r3577 to ptr
  store i64 1024, ptr %gmp3580, align 8, !alias.scope !6, !noalias !3
  %gmp3581 = inttoptr i64 %t3578 to ptr
  store i64 0, ptr %gmp3581, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116c78 word 0xa9013fee
  %t3583 = add i64 %r3577, 16
  %t3584 = add i64 %t3583, 8
  %gmp3586 = inttoptr i64 %t3583 to ptr
  store i64 65535, ptr %gmp3586, align 8, !alias.scope !6, !noalias !3
  %gmp3588 = inttoptr i64 %t3584 to ptr
  store i64 18446744069414584334, ptr %gmp3588, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116c7c word 0xd2c0002d
  ; @pc 0x800116c80 word 0xb2607fee
  ; @pc 0x800116c84 word 0xa9023bed
  %t3593 = add i64 %r3577, 32
  %t3594 = add i64 %t3593, 8
  %gmp3596 = inttoptr i64 %t3593 to ptr
  store i64 4294967296, ptr %gmp3596, align 8, !alias.scope !6, !noalias !3
  %gmp3598 = inttoptr i64 %t3594 to ptr
  store i64 18446744069414584320, ptr %gmp3598, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116c88 word 0x1280000d
  ; @pc 0x800116c8c word 0xb2091bee
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7421 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 4575657222473777152, ptr %cwp7421, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116c90 word 0xa9033bed
  %t3604 = add i64 %r3577, 48
  %t3605 = add i64 %t3604, 8
  %gmp3607 = inttoptr i64 %t3604 to ptr
  store i64 4294967295, ptr %gmp3607, align 8, !alias.scope !6, !noalias !3
  %gmp3609 = inttoptr i64 %t3605 to ptr
  store i64 4575657222473777152, ptr %gmp3609, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116c94 word 0x900157cd
  ; @pc 0x800116c98 word 0x910e8dad
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7422 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 34405933987, ptr %cwp7422, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116c9c word 0x140000a2
  br label %L_800116f24
L_800116ca0:
  ; @pc 0x800116ca0 word 0xd2a1080d
  ; @pc 0x800116ca4 word 0xd2c001ee
  ; @pc 0x800116ca8 word 0xb900a3e8
  %r3616 = load i64, ptr %loc_sp, align 8
  %t3617 = add i64 %r3616, 160
  %r3618.p = getelementptr inbounds i8, ptr %c, i64 64
  %r3618 = load i64, ptr %r3618.p, align 8, !alias.scope !3, !noalias !4
  %c3619 = trunc i64 %r3618 to i32
  %gmp3620 = inttoptr i64 %t3617 to ptr
  store i32 %c3619, ptr %gmp3620, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116cac word 0xf2dfffed
  ; @pc 0x800116cb0 word 0xf80143ee
  %t3626 = add i64 %r3616, 20
  %gmp3628 = inttoptr i64 %t3626 to ptr
  store i64 64424509440, ptr %gmp3628, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116cb4 word 0x5280400e
  ; @pc 0x800116cb8 word 0x72a8000e
  ; @pc 0x800116cbc word 0xf800c3ed
  %t3638 = add i64 %r3616, 12
  %gmp3640 = inttoptr i64 %t3638 to ptr
  store i64 281470820155392, ptr %gmp3640, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116cc0 word 0xb97a8e8d
  %r3641.p = getelementptr inbounds i8, ptr %c, i64 160
  %r3641 = load i64, ptr %r3641.p, align 8, !alias.scope !3, !noalias !4
  %t3642 = add i64 %r3641, 14988
  %gmp3643 = inttoptr i64 %t3642 to ptr
  %gml3644 = load i32, ptr %gmp3643, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116cc4 word 0x52a80010
  ; @pc 0x800116cc8 word 0x9100418c
  %r3649.p = getelementptr inbounds i8, ptr %c, i64 96
  %r3649 = load i64, ptr %r3649.p, align 8, !alias.scope !3, !noalias !4
  %t3650 = add i64 %r3649, 16
  ; @pc 0x800116ccc word 0x91004148
  %r3652.p = getelementptr inbounds i8, ptr %c, i64 80
  %r3652 = load i64, ptr %r3652.p, align 8, !alias.scope !3, !noalias !4
  %t3653 = add i64 %r3652, 16
  ; @pc 0x800116cd0 word 0xf80043ff
  %t3656 = add i64 %r3616, 4
  %gmp3657 = inttoptr i64 %t3656 to ptr
  store i64 0, ptr %gmp3657, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116cd4 word 0xf801c3ef
  %t3659 = add i64 %r3616, 28
  %r3660.p = getelementptr inbounds i8, ptr %c, i64 120
  %r3660 = load i64, ptr %r3660.p, align 8, !alias.scope !3, !noalias !4
  %gmp3661 = inttoptr i64 %t3659 to ptr
  store i64 %r3660, ptr %gmp3661, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116cd8 word 0x720f01bf
  %t3664 = and i32 %gml3644, 131072
  ; @pc 0x800116cdc word 0x5280002d
  ; @pc 0x800116ce0 word 0xb90037ff
  %t3676 = add i64 %r3616, 52
  %gmp3677 = inttoptr i64 %t3676 to ptr
  store i32 0, ptr %gmp3677, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116ce4 word 0xf900037f
  %r3678 = load i64, ptr %loc_x27, align 8
  %gmp3679 = inttoptr i64 %r3678 to ptr
  store i64 0, ptr %gmp3679, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116ce8 word 0x1a8e020e
  %c3681 = trunc i64 1073741824 to i32
  %c3683 = trunc i64 1073742336 to i32
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond3685 = icmp eq i32 %t3664, 0
  %sel3687 = select i1 %cond3685, i32 %c3681, i32 %c3683
  ; @pc 0x800116cec word 0xb2091bf0
  ; @pc 0x800116cf0 word 0xf80243ed
  %t3693 = add i64 %r3616, 36
  %gmp3695 = inttoptr i64 %t3693 to ptr
  store i64 1, ptr %gmp3695, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116cf4 word 0x3900237f
  %t3697 = add i64 %r3678, 8
  %gmp3699 = inttoptr i64 %t3697 to ptr
  store i8 0, ptr %gmp3699, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116cf8 word 0xb900bfff
  %t3701 = add i64 %r3616, 188
  %gmp3702 = inttoptr i64 %t3701 to ptr
  store i32 0, ptr %gmp3702, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116cfc word 0x2905b7ef
  %t3704 = add i64 %r3616, 44
  %t3705 = add i64 %t3704, 4
  %c3707 = trunc i64 %r3660 to i32
  %gmp3708 = inttoptr i64 %t3704 to ptr
  store i32 %c3707, ptr %gmp3708, align 4, !alias.scope !6, !noalias !3
  %gmp3711 = inttoptr i64 %t3705 to ptr
  store i32 1, ptr %gmp3711, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116d00 word 0xb90003ee
  %gmp3715 = inttoptr i64 %r3616 to ptr
  store i32 %sel3687, ptr %gmp3715, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116d04 word 0x900157ce
  ; @pc 0x800116d08 word 0x910ee9ce
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7429 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 34405934010, ptr %cwp7429, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116d0c word 0xa903c3f0
  %t3721 = add i64 %r3616, 56
  %t3722 = add i64 %t3721, 8
  %gmp3724 = inttoptr i64 %t3721 to ptr
  store i64 4575657222473777152, ptr %gmp3724, align 8, !alias.scope !6, !noalias !3
  %gmp3726 = inttoptr i64 %t3722 to ptr
  store i64 4575657222473777152, ptr %gmp3726, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116d10 word 0xd2e7f010
  ; @pc 0x800116d14 word 0xf80a4310
  %r3728.p = getelementptr inbounds i8, ptr %c, i64 192
  %r3728 = load i64, ptr %r3728.p, align 8, !alias.scope !3, !noalias !4
  %t3729 = add i64 %r3728, 164
  %gmp3731 = inttoptr i64 %t3729 to ptr
  store i64 4575657221408423936, ptr %gmp3731, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116d18 word 0xb2087bf0
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7430 = getelementptr inbounds i8, ptr %c, i64 128
  store i64 18410715276682199039, ptr %cwp7430, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116d1c word 0xf9004ff0
  %t3735 = add i64 %r3616, 152
  %gmp3737 = inttoptr i64 %t3735 to ptr
  store i64 18410715276682199039, ptr %gmp3737, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116d20 word 0xa907c3eb
  %t3739 = add i64 %r3616, 120
  %t3740 = add i64 %t3739, 8
  %r3741.p = getelementptr inbounds i8, ptr %c, i64 88
  %r3741 = load i64, ptr %r3741.p, align 8, !alias.scope !3, !noalias !4
  %gmp3742 = inttoptr i64 %t3739 to ptr
  store i64 %r3741, ptr %gmp3742, align 8, !alias.scope !6, !noalias !3
  %gmp3744 = inttoptr i64 %t3740 to ptr
  store i64 18410715276682199039, ptr %gmp3744, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116d24 word 0xa908afec
  %t3746 = add i64 %r3616, 136
  %t3747 = add i64 %t3746, 8
  %gmp3749 = inttoptr i64 %t3746 to ptr
  store i64 %t3650, ptr %gmp3749, align 8, !alias.scope !6, !noalias !3
  %gmp3751 = inttoptr i64 %t3747 to ptr
  store i64 %r3741, ptr %gmp3751, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116d28 word 0xa905ffff
  %t3753 = add i64 %r3616, 88
  ; [AArch64IdiomDeconstructPass] coalesced paired 64-bit zero stores -> i128
  %stpp7431 = inttoptr i64 %t3753 to ptr
  store i128 0, ptr %stpp7431, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116d2c word 0xa906bbff
  %t3758 = add i64 %r3616, 104
  %t3759 = add i64 %t3758, 8
  %gmp3760 = inttoptr i64 %t3758 to ptr
  store i64 0, ptr %gmp3760, align 8, !alias.scope !6, !noalias !3
  %gmp3762 = inttoptr i64 %t3759 to ptr
  store i64 34405934010, ptr %gmp3762, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116d30 word 0xa904a3ff
  %t3764 = add i64 %r3616, 72
  %t3765 = add i64 %t3764, 8
  %gmp3766 = inttoptr i64 %t3764 to ptr
  store i64 0, ptr %gmp3766, align 8, !alias.scope !6, !noalias !3
  %gmp3768 = inttoptr i64 %t3765 to ptr
  store i64 %t3653, ptr %gmp3768, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116d34 word 0x1400008c
  br label %L_800116f64
L_800116d38:
  ; @pc 0x800116d38 word 0x5280100d
  ; @pc 0x800116d3c word 0xd2e00c0e
  ; @pc 0x800116d40 word 0x529fffef
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7433 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 65535, ptr %cwp7433, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116d44 word 0xa9003bed
  %r3774 = load i64, ptr %loc_sp, align 8
  %t3775 = add i64 %r3774, 8
  %gmp3777 = inttoptr i64 %r3774 to ptr
  store i64 128, ptr %gmp3777, align 8, !alias.scope !6, !noalias !3
  %gmp3779 = inttoptr i64 %t3775 to ptr
  store i64 27021597764222976, ptr %gmp3779, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116d48 word 0x929ffdad
  ; @pc 0x800116d4c word 0xf2a0000d
  ; @pc 0x800116d50 word 0xb2607fee
  ; @pc 0x800116d54 word 0xa90137ef
  %t3788 = add i64 %r3774, 16
  %t3789 = add i64 %t3788, 8
  %gmp3791 = inttoptr i64 %t3788 to ptr
  store i64 65535, ptr %gmp3791, align 8, !alias.scope !6, !noalias !3
  %gmp3793 = inttoptr i64 %t3789 to ptr
  store i64 18446744069414584338, ptr %gmp3793, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116d58 word 0xd2c0002d
  ; @pc 0x800116d5c word 0xa9023bed
  %t3796 = add i64 %r3774, 32
  %t3797 = add i64 %t3796, 8
  %gmp3799 = inttoptr i64 %t3796 to ptr
  store i64 4294967296, ptr %gmp3799, align 8, !alias.scope !6, !noalias !3
  %gmp3801 = inttoptr i64 %t3797 to ptr
  store i64 18446744069414584320, ptr %gmp3801, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116d60 word 0x1280000d
  ; @pc 0x800116d64 word 0xb2091bee
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7438 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 4575657222473777152, ptr %cwp7438, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116d68 word 0xa9033bed
  %t3807 = add i64 %r3774, 48
  %t3808 = add i64 %t3807, 8
  %gmp3810 = inttoptr i64 %t3807 to ptr
  store i64 4294967295, ptr %gmp3810, align 8, !alias.scope !6, !noalias !3
  %gmp3812 = inttoptr i64 %t3808 to ptr
  store i64 4575657222473777152, ptr %gmp3812, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116d6c word 0x90015cad
  ; @pc 0x800116d70 word 0x9134ddad
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7439 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 34406575415, ptr %cwp7439, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116d74 word 0x1400006c
  br label %L_800116f24
L_800116d78:
  ; @pc 0x800116d78 word 0x52a8000d
  ; @pc 0x800116d7c word 0xd2e0080e
  ; @pc 0x800116d80 word 0xb900a3e8
  %r3820 = load i64, ptr %loc_sp, align 8
  %t3821 = add i64 %r3820, 160
  %r3822.p = getelementptr inbounds i8, ptr %c, i64 64
  %r3822 = load i64, ptr %r3822.p, align 8, !alias.scope !3, !noalias !4
  %c3823 = trunc i64 %r3822 to i32
  %gmp3824 = inttoptr i64 %t3821 to ptr
  store i32 %c3823, ptr %gmp3824, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116d84 word 0xa9003bed
  %t3826 = add i64 %r3820, 8
  %gmp3828 = inttoptr i64 %r3820 to ptr
  store i64 1073741824, ptr %gmp3828, align 8, !alias.scope !6, !noalias !3
  %gmp3830 = inttoptr i64 %t3826 to ptr
  store i64 18014398509481984, ptr %gmp3830, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116d88 word 0x929ffd6d
  ; @pc 0x800116d8c word 0x529fffef
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7442 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 65535, ptr %cwp7442, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116d90 word 0xf2a0000d
  ; @pc 0x800116d94 word 0xb2607fee
  ; @pc 0x800116d98 word 0xa90137ef
  %t3841 = add i64 %r3820, 16
  %t3842 = add i64 %t3841, 8
  %gmp3844 = inttoptr i64 %t3841 to ptr
  store i64 65535, ptr %gmp3844, align 8, !alias.scope !6, !noalias !3
  %gmp3846 = inttoptr i64 %t3842 to ptr
  store i64 18446744069414584340, ptr %gmp3846, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116d9c word 0xd2c0002d
  ; @pc 0x800116da0 word 0x9100418c
  %r3848.p = getelementptr inbounds i8, ptr %c, i64 96
  %r3848 = load i64, ptr %r3848.p, align 8, !alias.scope !3, !noalias !4
  %t3849 = add i64 %r3848, 16
  ; @pc 0x800116da4 word 0x91004148
  %r3851.p = getelementptr inbounds i8, ptr %c, i64 80
  %r3851 = load i64, ptr %r3851.p, align 8, !alias.scope !3, !noalias !4
  %t3852 = add i64 %r3851, 16
  ; @pc 0x800116da8 word 0x3900237f
  %r3854 = load i64, ptr %loc_x27, align 8
  %t3855 = add i64 %r3854, 8
  %gmp3857 = inttoptr i64 %t3855 to ptr
  store i8 0, ptr %gmp3857, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116dac word 0xf900037f
  %gmp3859 = inttoptr i64 %r3854 to ptr
  store i64 0, ptr %gmp3859, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116db0 word 0xb900bfff
  %t3861 = add i64 %r3820, 188
  %gmp3862 = inttoptr i64 %t3861 to ptr
  store i32 0, ptr %gmp3862, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116db4 word 0xa9023bed
  %t3864 = add i64 %r3820, 32
  %t3865 = add i64 %t3864, 8
  %gmp3867 = inttoptr i64 %t3864 to ptr
  store i64 4294967296, ptr %gmp3867, align 8, !alias.scope !6, !noalias !3
  %gmp3869 = inttoptr i64 %t3865 to ptr
  store i64 18446744069414584320, ptr %gmp3869, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116db8 word 0x1280000d
  ; @pc 0x800116dbc word 0xb2091bee
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7446 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 4575657222473777152, ptr %cwp7446, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116dc0 word 0xa9033bed
  %t3875 = add i64 %r3820, 48
  %t3876 = add i64 %t3875, 8
  %gmp3878 = inttoptr i64 %t3875 to ptr
  store i64 4294967295, ptr %gmp3878, align 8, !alias.scope !6, !noalias !3
  %gmp3880 = inttoptr i64 %t3876 to ptr
  store i64 4575657222473777152, ptr %gmp3880, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116dc4 word 0x9001588d
  ; @pc 0x800116dc8 word 0x912d29ad
  ; @pc 0x800116dcc word 0xa9072fed
  %t3886 = add i64 %r3820, 112
  %t3887 = add i64 %t3886, 8
  %gmp3889 = inttoptr i64 %t3886 to ptr
  store i64 34406034250, ptr %gmp3889, align 8, !alias.scope !6, !noalias !3
  %r3890.p = getelementptr inbounds i8, ptr %c, i64 88
  %r3890 = load i64, ptr %r3890.p, align 8, !alias.scope !3, !noalias !4
  %gmp3891 = inttoptr i64 %t3887 to ptr
  store i64 %r3890, ptr %gmp3891, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116dd0 word 0xb2087bed
  ; @pc 0x800116dd4 word 0xa90833ed
  %t3895 = add i64 %r3820, 128
  %t3896 = add i64 %t3895, 8
  %gmp3898 = inttoptr i64 %t3895 to ptr
  store i64 18410715276682199039, ptr %gmp3898, align 8, !alias.scope !6, !noalias !3
  %gmp3900 = inttoptr i64 %t3896 to ptr
  store i64 %t3849, ptr %gmp3900, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116dd8 word 0xd2e7f00c
  ; @pc 0x800116ddc word 0xf80a430c
  %r3902.p = getelementptr inbounds i8, ptr %c, i64 192
  %r3902 = load i64, ptr %r3902.p, align 8, !alias.scope !3, !noalias !4
  %t3903 = add i64 %r3902, 164
  %gmp3905 = inttoptr i64 %t3903 to ptr
  store i64 4575657221408423936, ptr %gmp3905, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116de0 word 0xa9047fee
  %t3907 = add i64 %r3820, 64
  %t3908 = add i64 %t3907, 8
  %gmp3910 = inttoptr i64 %t3907 to ptr
  store i64 4575657222473777152, ptr %gmp3910, align 8, !alias.scope !6, !noalias !3
  %gmp3911 = inttoptr i64 %t3908 to ptr
  store i64 0, ptr %gmp3911, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116de4 word 0xa90937eb
  %t3913 = add i64 %r3820, 144
  %t3914 = add i64 %t3913, 8
  %gmp3916 = inttoptr i64 %t3913 to ptr
  store i64 %r3890, ptr %gmp3916, align 8, !alias.scope !6, !noalias !3
  %gmp3918 = inttoptr i64 %t3914 to ptr
  store i64 18410715276682199039, ptr %gmp3918, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116de8 word 0xa9067fff
  %t3920 = add i64 %r3820, 96
  ; [AArch64IdiomDeconstructPass] coalesced paired 64-bit zero stores -> i128
  %stpp7449 = inttoptr i64 %t3920 to ptr
  store i128 0, ptr %stpp7449, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116dec word 0xa9057fe8
  %t3925 = add i64 %r3820, 80
  %t3926 = add i64 %t3925, 8
  %gmp3928 = inttoptr i64 %t3925 to ptr
  store i64 %t3852, ptr %gmp3928, align 8, !alias.scope !6, !noalias !3
  %gmp3929 = inttoptr i64 %t3926 to ptr
  store i64 0, ptr %gmp3929, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116df0 word 0x1400005d
  br label %L_800116f64
L_800116df4:
  ; @pc 0x800116df4 word 0x5280006d
  ; @pc 0x800116df8 word 0xd2e0080e
  ; @pc 0x800116dfc word 0x529fffef
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7451 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 65535, ptr %cwp7451, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116e00 word 0xa9003bed
  %r3935 = load i64, ptr %loc_sp, align 8
  %t3936 = add i64 %r3935, 8
  %gmp3938 = inttoptr i64 %r3935 to ptr
  store i64 3, ptr %gmp3938, align 8, !alias.scope !6, !noalias !3
  %gmp3940 = inttoptr i64 %t3936 to ptr
  store i64 18014398509481984, ptr %gmp3940, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116e04 word 0xb2608fed
  ; @pc 0x800116e08 word 0xa90137ef
  %t3944 = add i64 %r3935, 16
  %t3945 = add i64 %t3944, 8
  %gmp3947 = inttoptr i64 %t3944 to ptr
  store i64 65535, ptr %gmp3947, align 8, !alias.scope !6, !noalias !3
  %gmp3949 = inttoptr i64 %t3945 to ptr
  store i64 18446744069414584335, ptr %gmp3949, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116e0c word 0xd2c0002d
  ; @pc 0x800116e10 word 0xb2607fee
  ; @pc 0x800116e14 word 0xa9023bed
  %t3954 = add i64 %r3935, 32
  %t3955 = add i64 %t3954, 8
  %gmp3957 = inttoptr i64 %t3954 to ptr
  store i64 4294967296, ptr %gmp3957, align 8, !alias.scope !6, !noalias !3
  %gmp3959 = inttoptr i64 %t3955 to ptr
  store i64 18446744069414584320, ptr %gmp3959, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116e18 word 0x1280000d
  ; @pc 0x800116e1c word 0xb2091bee
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7455 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 4575657222473777152, ptr %cwp7455, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116e20 word 0xa9033bed
  %t3965 = add i64 %r3935, 48
  %t3966 = add i64 %t3965, 8
  %gmp3968 = inttoptr i64 %t3965 to ptr
  store i64 4294967295, ptr %gmp3968, align 8, !alias.scope !6, !noalias !3
  %gmp3970 = inttoptr i64 %t3966 to ptr
  store i64 4575657222473777152, ptr %gmp3970, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116e24 word 0xf0015a4d
  ; @pc 0x800116e28 word 0x910715ad
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7456 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 34406273477, ptr %cwp7456, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116e2c word 0x1400003e
  br label %L_800116f24
L_800116e30:
  ; @pc 0x800116e30 word 0xd280002d
  ; @pc 0x800116e34 word 0xd2c1004e
  ; @pc 0x800116e38 word 0x529fffef
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7457 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 65535, ptr %cwp7457, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116e3c word 0xf2c0008d
  ; @pc 0x800116e40 word 0xa9003bed
  %r3983 = load i64, ptr %loc_sp, align 8
  %t3984 = add i64 %r3983, 8
  %gmp3986 = inttoptr i64 %r3983 to ptr
  store i64 17179869185, ptr %gmp3986, align 8, !alias.scope !6, !noalias !3
  %gmp3988 = inttoptr i64 %t3984 to ptr
  store i64 8804682956800, ptr %gmp3988, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116e44 word 0xb2608fed
  ; @pc 0x800116e48 word 0xb2607fee
  ; @pc 0x800116e4c word 0xa90137ef
  %t3994 = add i64 %r3983, 16
  %t3995 = add i64 %t3994, 8
  %gmp3997 = inttoptr i64 %t3994 to ptr
  store i64 65535, ptr %gmp3997, align 8, !alias.scope !6, !noalias !3
  %gmp3999 = inttoptr i64 %t3995 to ptr
  store i64 18446744069414584335, ptr %gmp3999, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116e50 word 0xd2c0002d
  ; @pc 0x800116e54 word 0xa9023bed
  %t4002 = add i64 %r3983, 32
  %t4003 = add i64 %t4002, 8
  %gmp4005 = inttoptr i64 %t4002 to ptr
  store i64 4294967296, ptr %gmp4005, align 8, !alias.scope !6, !noalias !3
  %gmp4007 = inttoptr i64 %t4003 to ptr
  store i64 18446744069414584320, ptr %gmp4007, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116e58 word 0x1280000d
  ; @pc 0x800116e5c word 0xb2091bee
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7462 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 4575657222473777152, ptr %cwp7462, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116e60 word 0xa9033bed
  %t4013 = add i64 %r3983, 48
  %t4014 = add i64 %t4013, 8
  %gmp4016 = inttoptr i64 %t4013 to ptr
  store i64 4294967295, ptr %gmp4016, align 8, !alias.scope !6, !noalias !3
  %gmp4018 = inttoptr i64 %t4014 to ptr
  store i64 4575657222473777152, ptr %gmp4018, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116e64 word 0xb0015ced
  ; @pc 0x800116e68 word 0x912549ad
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7463 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 34406611282, ptr %cwp7463, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116e6c word 0x1400002e
  br label %L_800116f24
L_800116e70:
  ; @pc 0x800116e70 word 0x5280002d
  ; @pc 0x800116e74 word 0xd2e0080e
  ; @pc 0x800116e78 word 0x3900237f
  %r4026 = load i64, ptr %loc_x27, align 8
  %t4027 = add i64 %r4026, 8
  %gmp4029 = inttoptr i64 %t4027 to ptr
  store i8 0, ptr %gmp4029, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116e7c word 0xa9003bed
  %r4030 = load i64, ptr %loc_sp, align 8
  %t4031 = add i64 %r4030, 8
  %gmp4033 = inttoptr i64 %r4030 to ptr
  store i64 1, ptr %gmp4033, align 8, !alias.scope !6, !noalias !3
  %gmp4035 = inttoptr i64 %t4031 to ptr
  store i64 18014398509481984, ptr %gmp4035, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116e80 word 0x929ffd4d
  ; @pc 0x800116e84 word 0x529fffef
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7466 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 65535, ptr %cwp7466, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116e88 word 0xf2a0000d
  ; @pc 0x800116e8c word 0xb2607fee
  ; @pc 0x800116e90 word 0xa90137ef
  %t4046 = add i64 %r4030, 16
  %t4047 = add i64 %t4046, 8
  %gmp4049 = inttoptr i64 %t4046 to ptr
  store i64 65535, ptr %gmp4049, align 8, !alias.scope !6, !noalias !3
  %gmp4051 = inttoptr i64 %t4047 to ptr
  store i64 18446744069414584341, ptr %gmp4051, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116e94 word 0xd2c0002d
  ; @pc 0x800116e98 word 0x9100418c
  %r4053.p = getelementptr inbounds i8, ptr %c, i64 96
  %r4053 = load i64, ptr %r4053.p, align 8, !alias.scope !3, !noalias !4
  %t4054 = add i64 %r4053, 16
  ; @pc 0x800116e9c word 0x9100414a
  %r4056.p = getelementptr inbounds i8, ptr %c, i64 80
  %r4056 = load i64, ptr %r4056.p, align 8, !alias.scope !3, !noalias !4
  %t4057 = add i64 %r4056, 16
  ; @pc 0x800116ea0 word 0xf900037f
  %gmp4060 = inttoptr i64 %r4026 to ptr
  store i64 0, ptr %gmp4060, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116ea4 word 0xa9023bed
  %t4062 = add i64 %r4030, 32
  %t4063 = add i64 %t4062, 8
  %gmp4065 = inttoptr i64 %t4062 to ptr
  store i64 4294967296, ptr %gmp4065, align 8, !alias.scope !6, !noalias !3
  %gmp4067 = inttoptr i64 %t4063 to ptr
  store i64 18446744069414584320, ptr %gmp4067, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116ea8 word 0x1280000d
  ; @pc 0x800116eac word 0xb2091bee
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7470 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 4575657222473777152, ptr %cwp7470, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116eb0 word 0xa9033bed
  %t4073 = add i64 %r4030, 48
  %t4074 = add i64 %t4073, 8
  %gmp4076 = inttoptr i64 %t4073 to ptr
  store i64 4294967295, ptr %gmp4076, align 8, !alias.scope !6, !noalias !3
  %gmp4078 = inttoptr i64 %t4074 to ptr
  store i64 4575657222473777152, ptr %gmp4078, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116eb4 word 0x90015cad
  ; @pc 0x800116eb8 word 0x913519ad
  ; @pc 0x800116ebc word 0xa9072fed
  %t4084 = add i64 %r4030, 112
  %t4085 = add i64 %t4084, 8
  %gmp4087 = inttoptr i64 %t4084 to ptr
  store i64 34406575430, ptr %gmp4087, align 8, !alias.scope !6, !noalias !3
  %r4088.p = getelementptr inbounds i8, ptr %c, i64 88
  %r4088 = load i64, ptr %r4088.p, align 8, !alias.scope !3, !noalias !4
  %gmp4089 = inttoptr i64 %t4085 to ptr
  store i64 %r4088, ptr %gmp4089, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116ec0 word 0xb2087bed
  ; @pc 0x800116ec4 word 0xa90833ed
  %t4093 = add i64 %r4030, 128
  %t4094 = add i64 %t4093, 8
  %gmp4096 = inttoptr i64 %t4093 to ptr
  store i64 18410715276682199039, ptr %gmp4096, align 8, !alias.scope !6, !noalias !3
  %gmp4098 = inttoptr i64 %t4094 to ptr
  store i64 %t4054, ptr %gmp4098, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116ec8 word 0xd2e7f00c
  ; @pc 0x800116ecc word 0xf80a430c
  %r4100.p = getelementptr inbounds i8, ptr %c, i64 192
  %r4100 = load i64, ptr %r4100.p, align 8, !alias.scope !3, !noalias !4
  %t4101 = add i64 %r4100, 164
  %gmp4103 = inttoptr i64 %t4101 to ptr
  store i64 4575657221408423936, ptr %gmp4103, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116ed0 word 0xa9047fee
  %t4105 = add i64 %r4030, 64
  %t4106 = add i64 %t4105, 8
  %gmp4108 = inttoptr i64 %t4105 to ptr
  store i64 4575657222473777152, ptr %gmp4108, align 8, !alias.scope !6, !noalias !3
  %gmp4109 = inttoptr i64 %t4106 to ptr
  store i64 0, ptr %gmp4109, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116ed4 word 0xa90937eb
  %t4111 = add i64 %r4030, 144
  %t4112 = add i64 %t4111, 8
  %gmp4114 = inttoptr i64 %t4111 to ptr
  store i64 %r4088, ptr %gmp4114, align 8, !alias.scope !6, !noalias !3
  %gmp4116 = inttoptr i64 %t4112 to ptr
  store i64 18410715276682199039, ptr %gmp4116, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116ed8 word 0xa9067fff
  %t4118 = add i64 %r4030, 96
  ; [AArch64IdiomDeconstructPass] coalesced paired 64-bit zero stores -> i128
  %stpp7473 = inttoptr i64 %t4118 to ptr
  store i128 0, ptr %stpp7473, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116edc word 0xa9057fea
  %t4123 = add i64 %r4030, 80
  %t4124 = add i64 %t4123, 8
  %gmp4126 = inttoptr i64 %t4123 to ptr
  store i64 %t4057, ptr %gmp4126, align 8, !alias.scope !6, !noalias !3
  %gmp4127 = inttoptr i64 %t4124 to ptr
  store i64 0, ptr %gmp4127, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116ee0 word 0x5280006a
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7474 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 3, ptr %cwp7474, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116ee4 word 0x1400001e
  br label %L_800116f5c
L_800116ee8:
  ; @pc 0x800116ee8 word 0x5280400d
  ; @pc 0x800116eec word 0xd2e0080e
  ; @pc 0x800116ef0 word 0x529fffef
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7476 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 65535, ptr %cwp7476, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116ef4 word 0xa9003bed
  %r4135 = load i64, ptr %loc_sp, align 8
  %t4136 = add i64 %r4135, 8
  %gmp4138 = inttoptr i64 %r4135 to ptr
  store i64 512, ptr %gmp4138, align 8, !alias.scope !6, !noalias !3
  %gmp4140 = inttoptr i64 %t4136 to ptr
  store i64 18014398509481984, ptr %gmp4140, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116ef8 word 0x929ffd8d
  ; @pc 0x800116efc word 0xf2a0000d
  ; @pc 0x800116f00 word 0xb2607fee
  ; @pc 0x800116f04 word 0xa90137ef
  %t4149 = add i64 %r4135, 16
  %t4150 = add i64 %t4149, 8
  %gmp4152 = inttoptr i64 %t4149 to ptr
  store i64 65535, ptr %gmp4152, align 8, !alias.scope !6, !noalias !3
  %gmp4154 = inttoptr i64 %t4150 to ptr
  store i64 18446744069414584339, ptr %gmp4154, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116f08 word 0xd2c0002d
  ; @pc 0x800116f0c word 0xa9023bed
  %t4157 = add i64 %r4135, 32
  %t4158 = add i64 %t4157, 8
  %gmp4160 = inttoptr i64 %t4157 to ptr
  store i64 4294967296, ptr %gmp4160, align 8, !alias.scope !6, !noalias !3
  %gmp4162 = inttoptr i64 %t4158 to ptr
  store i64 18446744069414584320, ptr %gmp4162, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116f10 word 0x1280000d
  ; @pc 0x800116f14 word 0xb2091bee
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7481 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 4575657222473777152, ptr %cwp7481, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116f18 word 0xa9033bed
  %t4168 = add i64 %r4135, 48
  %t4169 = add i64 %t4168, 8
  %gmp4171 = inttoptr i64 %t4168 to ptr
  store i64 4294967295, ptr %gmp4171, align 8, !alias.scope !6, !noalias !3
  %gmp4173 = inttoptr i64 %t4169 to ptr
  store i64 4575657222473777152, ptr %gmp4173, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116f1c word 0xf001572d
  ; @pc 0x800116f20 word 0x91230dad
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7482 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 34405865667, ptr %cwp7482, align 8, !alias.scope !3, !noalias !4
  br label %L_800116f24
L_800116f24:
  ; @pc 0x800116f24 word 0xa9072fed
  %r4178 = load i64, ptr %loc_sp, align 8
  %t4179 = add i64 %r4178, 112
  %t4180 = add i64 %t4179, 8
  %r4181.p = getelementptr inbounds i8, ptr %c, i64 104
  %r4181 = load i64, ptr %r4181.p, align 8, !alias.scope !3, !noalias !4
  %gmp4182 = inttoptr i64 %t4179 to ptr
  store i64 %r4181, ptr %gmp4182, align 8, !alias.scope !6, !noalias !3
  %r4183.p = getelementptr inbounds i8, ptr %c, i64 88
  %r4183 = load i64, ptr %r4183.p, align 8, !alias.scope !3, !noalias !4
  %gmp4184 = inttoptr i64 %t4180 to ptr
  store i64 %r4183, ptr %gmp4184, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116f28 word 0xb2087bed
  ; @pc 0x800116f2c word 0x9100418c
  %r4187.p = getelementptr inbounds i8, ptr %c, i64 96
  %r4187 = load i64, ptr %r4187.p, align 8, !alias.scope !3, !noalias !4
  %t4188 = add i64 %r4187, 16
  ; @pc 0x800116f30 word 0x9100414a
  %r4190.p = getelementptr inbounds i8, ptr %c, i64 80
  %r4190 = load i64, ptr %r4190.p, align 8, !alias.scope !3, !noalias !4
  %t4191 = add i64 %r4190, 16
  ; @pc 0x800116f34 word 0x3900237f
  %r4193 = load i64, ptr %loc_x27, align 8
  %t4194 = add i64 %r4193, 8
  %gmp4196 = inttoptr i64 %t4194 to ptr
  store i8 0, ptr %gmp4196, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116f38 word 0xf900037f
  %gmp4198 = inttoptr i64 %r4193 to ptr
  store i64 0, ptr %gmp4198, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116f3c word 0xa90833ed
  %t4200 = add i64 %r4178, 128
  %t4201 = add i64 %t4200, 8
  %gmp4203 = inttoptr i64 %t4200 to ptr
  store i64 18410715276682199039, ptr %gmp4203, align 8, !alias.scope !6, !noalias !3
  %gmp4205 = inttoptr i64 %t4201 to ptr
  store i64 %t4188, ptr %gmp4205, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116f40 word 0xd2e7f00c
  ; @pc 0x800116f44 word 0xa9047fee
  %t4208 = add i64 %r4178, 64
  %t4209 = add i64 %t4208, 8
  %r4210.p = getelementptr inbounds i8, ptr %c, i64 112
  %r4210 = load i64, ptr %r4210.p, align 8, !alias.scope !3, !noalias !4
  %gmp4211 = inttoptr i64 %t4208 to ptr
  store i64 %r4210, ptr %gmp4211, align 8, !alias.scope !6, !noalias !3
  %gmp4212 = inttoptr i64 %t4209 to ptr
  store i64 0, ptr %gmp4212, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116f48 word 0xf80a430c
  %r4213.p = getelementptr inbounds i8, ptr %c, i64 192
  %r4213 = load i64, ptr %r4213.p, align 8, !alias.scope !3, !noalias !4
  %t4214 = add i64 %r4213, 164
  %gmp4216 = inttoptr i64 %t4214 to ptr
  store i64 4575657221408423936, ptr %gmp4216, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116f4c word 0xa9057fea
  %t4218 = add i64 %r4178, 80
  %t4219 = add i64 %t4218, 8
  %gmp4221 = inttoptr i64 %t4218 to ptr
  store i64 %t4191, ptr %gmp4221, align 8, !alias.scope !6, !noalias !3
  %gmp4222 = inttoptr i64 %t4219 to ptr
  store i64 0, ptr %gmp4222, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116f50 word 0x5280004a
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7484 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 2, ptr %cwp7484, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116f54 word 0xa90937eb
  %t4226 = add i64 %r4178, 144
  %t4227 = add i64 %t4226, 8
  %gmp4229 = inttoptr i64 %t4226 to ptr
  store i64 %r4183, ptr %gmp4229, align 8, !alias.scope !6, !noalias !3
  %gmp4231 = inttoptr i64 %t4227 to ptr
  store i64 18410715276682199039, ptr %gmp4231, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800116f58 word 0xa9067fff
  %t4233 = add i64 %r4178, 96
  ; [AArch64IdiomDeconstructPass] coalesced paired 64-bit zero stores -> i128
  %stpp7485 = inttoptr i64 %t4233 to ptr
  store i128 0, ptr %stpp7485, align 8, !alias.scope !6, !noalias !3
  br label %L_800116f5c
L_800116f5c:
  ; @pc 0x800116f5c word 0xb900a3e8
  %r4237 = load i64, ptr %loc_sp, align 8
  %t4238 = add i64 %r4237, 160
  %r4239.p = getelementptr inbounds i8, ptr %c, i64 64
  %r4239 = load i64, ptr %r4239.p, align 8, !alias.scope !3, !noalias !4
  %c4240 = trunc i64 %r4239 to i32
  %gmp4241 = inttoptr i64 %t4238 to ptr
  store i32 %c4240, ptr %gmp4241, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116f60 word 0xb900bfea
  %t4243 = add i64 %r4237, 188
  %r4244.p = getelementptr inbounds i8, ptr %c, i64 80
  %r4244 = load i64, ptr %r4244.p, align 8, !alias.scope !3, !noalias !4
  %c4245 = trunc i64 %r4244 to i32
  %gmp4246 = inttoptr i64 %t4243 to ptr
  store i32 %c4245, ptr %gmp4246, align 4, !alias.scope !6, !noalias !3
  br label %L_800116f64
L_800116f64:
  ; @pc 0x800116f64 word 0xf94f6688
  %r4247.p = getelementptr inbounds i8, ptr %c, i64 160
  %r4247 = load i64, ptr %r4247.p, align 8, !alias.scope !3, !noalias !4
  %t4248 = add i64 %r4247, 7880
  %gmp4249 = inttoptr i64 %t4248 to ptr
  %gml4250 = load i64, ptr %gmp4249, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116f68 word 0x3940226a
  %r4252.p = getelementptr inbounds i8, ptr %c, i64 152
  %r4252 = load i64, ptr %r4252.p, align 8, !alias.scope !3, !noalias !4
  %t4253 = add i64 %r4252, 8
  %gmp4254 = inttoptr i64 %t4253 to ptr
  %gml4255 = load i8, ptr %gmp4254, align 1, !alias.scope !4, !noalias !3
  %c4256 = zext i8 %gml4255 to i64
  ; @pc 0x800116f6c word 0xb940090b
  %t4259 = add i64 %gml4250, 8
  %gmp4260 = inttoptr i64 %t4259 to ptr
  %gml4261 = load i32, ptr %gmp4260, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116f70 word 0xf940090c
  %t4265 = add i64 %gml4250, 16
  %gmp4266 = inttoptr i64 %t4265 to ptr
  %gml4267 = load i64, ptr %gmp4266, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116f74 word 0x6b0a017f
  %c4272 = trunc i64 %c4256 to i32
  ; @pc 0x800116f78 word 0x52879c0b
  ; @pc 0x800116f7c word 0x9a9f814d
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond4297 = icmp ugt i32 %gml4261, %c4272
  %sel4303 = select i1 %cond4297, i64 %c4256, i64 0
  ; @pc 0x800116f80 word 0x9bab31ac
  %c4306 = trunc i64 %sel4303 to i32
  %c4307 = zext i32 %c4306 to i64
  %c4309 = trunc i64 15584 to i32
  %c4310 = zext i32 %c4309 to i64
  %t4311 = mul i64 %c4307, %c4310
  %t4313 = add i64 %gml4267, %t4311
  ; @pc 0x800116f84 word 0xf957058d
  %t4316 = add i64 %t4313, 11784
  %gmp4317 = inttoptr i64 %t4316 to ptr
  %gml4318 = load i64, ptr %gmp4317, align 1, !alias.scope !4, !noalias !3
  %wp4319 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 %gml4318, ptr %wp4319, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116f88 word 0xf957018c
  %t4321 = add i64 %t4313, 11776
  %gmp4322 = inttoptr i64 %t4321 to ptr
  %gml4323 = load i64, ptr %gmp4322, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116f8c word 0xa900352c
  %r4325.p = getelementptr inbounds i8, ptr %c, i64 72
  %r4325 = load i64, ptr %r4325.p, align 8, !alias.scope !3, !noalias !4
  %t4326 = add i64 %r4325, 8
  %gmp4328 = inttoptr i64 %r4325 to ptr
  store i64 %gml4323, ptr %gmp4328, align 1, !alias.scope !4, !noalias !3
  %gmp4330 = inttoptr i64 %t4326 to ptr
  store i64 %gml4318, ptr %gmp4330, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116f90 word 0xb9400909
  %t4332 = add i64 %gml4250, 8
  %gmp4333 = inttoptr i64 %t4332 to ptr
  %gml4334 = load i32, ptr %gmp4333, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116f94 word 0xf940090c
  %t4338 = add i64 %gml4250, 16
  %gmp4339 = inttoptr i64 %t4338 to ptr
  %gml4340 = load i64, ptr %gmp4339, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116f98 word 0x6b0a013f
  ; @pc 0x800116f9c word 0x9a9f8149
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond4368 = icmp ugt i32 %gml4334, %c4272
  %sel4374 = select i1 %cond4368, i64 %c4256, i64 0
  ; @pc 0x800116fa0 word 0x9bab3129
  %c4377 = trunc i64 %sel4374 to i32
  %c4378 = zext i32 %c4377 to i64
  %c4381 = zext i32 %c4309 to i64
  %t4382 = mul i64 %c4378, %c4381
  %t4384 = add i64 %gml4340, %t4382
  ; @pc 0x800116fa4 word 0xf958452a
  %t4387 = add i64 %t4384, 12424
  %gmp4388 = inttoptr i64 %t4387 to ptr
  %gml4389 = load i64, ptr %gmp4388, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116fa8 word 0xf958412b
  %t4392 = add i64 %t4384, 12416
  %gmp4393 = inttoptr i64 %t4392 to ptr
  %gml4394 = load i64, ptr %gmp4393, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116fac word 0xa9002b4b
  %r4396.p = getelementptr inbounds i8, ptr %c, i64 208
  %r4396 = load i64, ptr %r4396.p, align 8, !alias.scope !3, !noalias !4
  %t4397 = add i64 %r4396, 8
  %gmp4399 = inttoptr i64 %r4396 to ptr
  store i64 %gml4394, ptr %gmp4399, align 1, !alias.scope !4, !noalias !3
  %gmp4401 = inttoptr i64 %t4397 to ptr
  store i64 %gml4389, ptr %gmp4401, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116fb0 word 0xb970992a
  %t4403 = add i64 %t4384, 12440
  %gmp4404 = inttoptr i64 %t4403 to ptr
  %gml4405 = load i32, ptr %gmp4404, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116fb4 word 0xf9584929
  %t4409 = add i64 %t4384, 12432
  %gmp4410 = inttoptr i64 %t4409 to ptr
  %gml4411 = load i64, ptr %gmp4410, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116fb8 word 0xf9000329
  %r4413.p = getelementptr inbounds i8, ptr %c, i64 200
  %r4413 = load i64, ptr %r4413.p, align 8, !alias.scope !3, !noalias !4
  %gmp4415 = inttoptr i64 %r4413 to ptr
  store i64 %gml4411, ptr %gmp4415, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116fbc word 0xb9000b2a
  %t4417 = add i64 %r4413, 8
  %gmp4420 = inttoptr i64 %t4417 to ptr
  store i32 %gml4405, ptr %gmp4420, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116fc0 word 0x29442109
  %t4422 = add i64 %gml4250, 32
  %t4423 = add i64 %t4422, 4
  %gmp4424 = inttoptr i64 %t4422 to ptr
  %gml4425 = load i32, ptr %gmp4424, align 1, !alias.scope !4, !noalias !3
  %gmp4427 = inttoptr i64 %t4423 to ptr
  %gml4428 = load i32, ptr %gmp4427, align 1, !alias.scope !4, !noalias !3
  %c4429 = zext i32 %gml4428 to i64
  %wp4431 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %c4429, ptr %wp4431, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116fc4 word 0xb900b7ff
  %r4432 = load i64, ptr %loc_sp, align 8
  %t4433 = add i64 %r4432, 180
  %gmp4434 = inttoptr i64 %t4433 to ptr
  store i32 0, ptr %gmp4434, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116fc8 word 0xb80b131f
  %r4435.p = getelementptr inbounds i8, ptr %c, i64 192
  %r4435 = load i64, ptr %r4435.p, align 8, !alias.scope !3, !noalias !4
  %t4436 = add i64 %r4435, 177
  %gmp4437 = inttoptr i64 %t4436 to ptr
  store i32 0, ptr %gmp4437, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116fcc word 0x3902c3e9
  %t4439 = add i64 %r4432, 176
  %c4442 = trunc i32 %gml4425 to i8
  %gmp4443 = inttoptr i64 %t4439 to ptr
  store i8 %c4442, ptr %gmp4443, align 1, !alias.scope !6, !noalias !3
  br label %L_800116fd0
L_800116fd0:
  ; @pc 0x800116fd0 word 0x3902e3e8
  %r4444 = load i64, ptr %loc_sp, align 8
  %t4445 = add i64 %r4444, 184
  %r4446.p = getelementptr inbounds i8, ptr %c, i64 64
  %r4446 = load i64, ptr %r4446.p, align 8, !alias.scope !3, !noalias !4
  %c4447 = trunc i64 %r4446 to i32
  %c4448 = trunc i32 %c4447 to i8
  %gmp4449 = inttoptr i64 %t4445 to ptr
  store i8 %c4448, ptr %gmp4449, align 1, !alias.scope !6, !noalias !3
  br label %L_800116fd4
L_800116fd4:
  ; @pc 0x800116fd4 word 0xaa1703e8
  %r4450.p = getelementptr inbounds i8, ptr %c, i64 184
  %r4450 = load i64, ptr %r4450.p, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116fd8 word 0xaa1703f6
  ; @pc 0x800116fdc word 0xb94003ea
  %r4456 = load i64, ptr %loc_sp, align 8
  %gmp4457 = inttoptr i64 %r4456 to ptr
  %gml4458 = load i32, ptr %gmp4457, align 4, !alias.scope !6, !noalias !3
  %c4459 = zext i32 %gml4458 to i64
  %wp4460 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 %c4459, ptr %wp4460, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116fe0 word 0xb841cd09
  %t4462 = add i64 %r4450, 28
  %gmp4463 = inttoptr i64 %t4462 to ptr
  %gml4464 = load i32, ptr %gmp4463, align 1, !alias.scope !4, !noalias !3
  %c4465 = zext i32 %gml4464 to i64
  %wp4466 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %t4462, ptr %wp4466, align 8, !alias.scope !3, !noalias !4
  %wp4467 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %c4465, ptr %wp4467, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116fe4 word 0xb9004be9
  %t4469 = add i64 %r4456, 72
  %gmp4472 = inttoptr i64 %t4469 to ptr
  store i32 %gml4464, ptr %gmp4472, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116fe8 word 0xb842cecc
  %t4474 = add i64 %r4450, 44
  %gmp4475 = inttoptr i64 %t4474 to ptr
  %gml4476 = load i32, ptr %gmp4475, align 1, !alias.scope !4, !noalias !3
  %c4477 = zext i32 %gml4476 to i64
  %wp4478 = getelementptr inbounds i8, ptr %c, i64 176
  store i64 %t4474, ptr %wp4478, align 8, !alias.scope !3, !noalias !4
  %wp4479 = getelementptr inbounds i8, ptr %c, i64 96
  store i64 %c4477, ptr %wp4479, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116fec word 0xb85e82cb
  %t4481 = add i64 %t4474, -24
  %gmp4482 = inttoptr i64 %t4481 to ptr
  %gml4483 = load i32, ptr %gmp4482, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116ff0 word 0x6a0a017f
  %t4490 = and i32 %gml4483, %gml4458
  ; @pc 0x800116ff4 word 0x1a9f07eb
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond4501 = icmp eq i32 %t4490, 0
  %sel4503 = select i1 %cond4501, i32 0, i32 1
  %c4504 = zext i32 %sel4503 to i64
  %wp4505 = getelementptr inbounds i8, ptr %c, i64 88
  store i64 %c4504, ptr %wp4505, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116ff8 word 0x7100019f
  ; @pc 0x800116ffc word 0x5400340d
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond4529 = icmp sle i32 %gml4476, 0
  br i1 %cond4529, label %L_80011767c, label %L_800117000
L_800117000:
  ; @pc 0x800117000 word 0x34000d2b
  %r4539.p = getelementptr inbounds i8, ptr %c, i64 88
  %r4539 = load i64, ptr %r4539.p, align 8, !alias.scope !3, !noalias !4
  %c4540 = trunc i64 %r4539 to i32
  %cmp4541 = icmp eq i32 %c4540, 0
  br i1 %cmp4541, label %L_8001171a4, label %L_800117004_ft
L_80011701c:
  ; @pc 0x80011701c word 0x52801a08
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7487 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 208, ptr %cwp7487, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117020 word 0x910003e1
  %r4574 = load i64, ptr %loc_sp, align 8
  %t4575 = add i64 %r4574, 0
  %wp4576 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %t4575, ptr %wp4576, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117024 word 0x9b284f3a
  %r4577.p = getelementptr inbounds i8, ptr %c, i64 200
  %r4577 = load i64, ptr %r4577.p, align 8, !alias.scope !3, !noalias !4
  %c4578 = trunc i64 %r4577 to i32
  %c4579 = sext i32 %c4578 to i64
  %c4581 = trunc i64 208 to i32
  %c4582 = sext i32 %c4581 to i64
  %t4583 = mul i64 %c4579, %c4582
  %r4584.p = getelementptr inbounds i8, ptr %c, i64 152
  %r4584 = load i64, ptr %r4584.p, align 8, !alias.scope !3, !noalias !4
  %t4585 = add i64 %r4584, %t4583
  %wp4586 = getelementptr inbounds i8, ptr %c, i64 208
  store i64 %t4585, ptr %wp4586, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117028 word 0x52801802
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7488 = getelementptr inbounds i8, ptr %c, i64 16
  store i64 192, ptr %cwp7488, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011702c word 0x91350355
  %t4590 = add i64 %t4585, 3392
  %wp4591 = getelementptr inbounds i8, ptr %c, i64 168
  store i64 %t4590, ptr %wp4591, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117030 word 0xaa1503e0
  %wp4594 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 %t4590, ptr %wp4594, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117034 word 0x94aa3467
  %wp4595 = getelementptr inbounds i8, ptr %c, i64 240
  store i64 34360881208, ptr %wp4595, align 8, !alias.scope !3, !noalias !4
  call void @f_802ba41d0(ptr %c)
  ; @pc 0x800117038 word 0x3974e348
  %r4596.p = getelementptr inbounds i8, ptr %c, i64 208
  %r4596 = load i64, ptr %r4596.p, align 8, !alias.scope !3, !noalias !4
  %t4597 = add i64 %r4596, 3384
  %gmp4598 = inttoptr i64 %t4597 to ptr
  %gml4599 = load i8, ptr %gmp4598, align 1, !alias.scope !4, !noalias !3
  %c4600 = zext i8 %gml4599 to i64
  ; @pc 0x80011703c word 0x32000108
  %c4603 = trunc i64 %c4600 to i32
  %t4604 = or i32 %c4603, 1
  ; @pc 0x800117040 word 0x3934e348
  %t4608 = add i64 %r4596, 3384
  %c4611 = trunc i32 %t4604 to i8
  %gmp4612 = inttoptr i64 %t4608 to ptr
  store i8 %c4611, ptr %gmp4612, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117044 word 0x52875028
  ; @pc 0x800117048 word 0x38686a88
  %r4615.p = getelementptr inbounds i8, ptr %c, i64 160
  %r4615 = load i64, ptr %r4615.p, align 8, !alias.scope !3, !noalias !4
  %t4617 = add i64 %r4615, 14977
  %gmp4618 = inttoptr i64 %t4617 to ptr
  %gml4619 = load i8, ptr %gmp4618, align 1, !alias.scope !4, !noalias !3
  %c4620 = zext i8 %gml4619 to i64
  %wp4621 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %c4620, ptr %wp4621, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011704c word 0x36300ac8
  %t4623 = and i64 %c4620, 64
  %cmp4624 = icmp eq i64 %t4623, 0
  br i1 %cmp4624, label %L_8001171a4, label %L_800117050_ft
L_8001170d8:
  ; @pc 0x8001170d8 word 0x885f7db2
  %r4858.p = getelementptr inbounds i8, ptr %c, i64 104
  %r4858 = load i64, ptr %r4858.p, align 8, !alias.scope !3, !noalias !4
  %atp4859 = inttoptr i64 %r4858 to ptr
  %ldx4860 = load atomic i32, ptr %atp4859 acquire, align 4, !alias.scope !4, !noalias !3
  %c4861 = zext i32 %ldx4860 to i64
  %wp4864 = getelementptr inbounds i8, ptr %c, i64 144
  store i64 %c4861, ptr %wp4864, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001170dc word 0x11000640
  %t4867 = add i32 %ldx4860, 1
  ; @pc 0x8001170e0 word 0x88017da0
  %atp4871 = inttoptr i64 %r4858 to ptr
  ; [ExclusiveMonitorLSEFastPathPass] elided software exclusive monitor
  %cmp4877 = icmp eq i64 0, 0
  %cx4881 = cmpxchg ptr %atp4871, i32 %ldx4860, i32 %t4867 seq_cst seq_cst, align 4
  %cxok4882 = extractvalue { i32, i1 } %cx4881, 1
  %t4883 = and i1 %cmp4877, %cxok4882
  %sel4884 = select i1 %t4883, i32 0, i32 1
  ; @pc 0x8001170e4 word 0x35ffffa1
  %cmp4889 = icmp ne i32 %sel4884, 0
  br i1 %cmp4889, label %L_8001170d8, label %L_8001170e8_ft
L_800117104:
  ; @pc 0x800117104 word 0x0b110051
  %r4973.p = getelementptr inbounds i8, ptr %c, i64 16
  %r4973 = load i64, ptr %r4973.p, align 8, !alias.scope !3, !noalias !4
  %c4974 = trunc i64 %r4973 to i32
  %r4975.p = getelementptr inbounds i8, ptr %c, i64 136
  %r4975 = load i64, ptr %r4975.p, align 8, !alias.scope !3, !noalias !4
  %c4976 = trunc i64 %r4975 to i32
  %t4977 = add i32 %c4974, %c4976
  %c4978 = zext i32 %t4977 to i64
  %wp4979 = getelementptr inbounds i8, ptr %c, i64 136
  store i64 %c4978, ptr %wp4979, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117108 word 0x9b2f0032
  %r4980.p = getelementptr inbounds i8, ptr %c, i64 8
  %r4980 = load i64, ptr %r4980.p, align 8, !alias.scope !3, !noalias !4
  %c4981 = trunc i64 %r4980 to i32
  %c4982 = sext i32 %c4981 to i64
  %r4983.p = getelementptr inbounds i8, ptr %c, i64 120
  %r4983 = load i64, ptr %r4983.p, align 8, !alias.scope !3, !noalias !4
  %c4984 = trunc i64 %r4983 to i32
  %c4985 = sext i32 %c4984 to i64
  %t4986 = mul i64 %c4982, %c4985
  %r4987.p = getelementptr inbounds i8, ptr %c, i64 0
  %r4987 = load i64, ptr %r4987.p, align 8, !alias.scope !3, !noalias !4
  %t4988 = add i64 %r4987, %t4986
  %wp4989 = getelementptr inbounds i8, ptr %c, i64 144
  store i64 %t4988, ptr %wp4989, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011710c word 0x2a0b03e2
  %r4990.p = getelementptr inbounds i8, ptr %c, i64 88
  %r4990 = load i64, ptr %r4990.p, align 8, !alias.scope !3, !noalias !4
  %c4991 = trunc i64 %r4990 to i32
  %c4993 = zext i32 %c4991 to i64
  ; @pc 0x800117110 word 0xaa118042
  %t4996 = shl i64 %c4978, 32
  %t4998 = or i64 %c4993, %t4996
  ; @pc 0x800117114 word 0xa9005e53
  %t5001 = add i64 %t4988, 8
  %r5002.p = getelementptr inbounds i8, ptr %c, i64 152
  %r5002 = load i64, ptr %r5002.p, align 8, !alias.scope !3, !noalias !4
  %gmp5003 = inttoptr i64 %t4988 to ptr
  store i64 %r5002, ptr %gmp5003, align 1, !alias.scope !4, !noalias !3
  %r5004.p = getelementptr inbounds i8, ptr %c, i64 184
  %r5004 = load i64, ptr %r5004.p, align 8, !alias.scope !3, !noalias !4
  %gmp5005 = inttoptr i64 %t5001 to ptr
  store i64 %r5004, ptr %gmp5005, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117118 word 0xa9010a55
  %t5007 = add i64 %t4988, 16
  %t5008 = add i64 %t5007, 8
  %r5009.p = getelementptr inbounds i8, ptr %c, i64 168
  %r5009 = load i64, ptr %r5009.p, align 8, !alias.scope !3, !noalias !4
  %gmp5010 = inttoptr i64 %t5007 to ptr
  store i64 %r5009, ptr %gmp5010, align 1, !alias.scope !4, !noalias !3
  %gmp5012 = inttoptr i64 %t5008 to ptr
  store i64 %t4998, ptr %gmp5012, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011711c word 0xb940bea2
  %t5014 = add i64 %r5009, 188
  %gmp5015 = inttoptr i64 %t5014 to ptr
  %gml5016 = load i32, ptr %gmp5015, align 1, !alias.scope !4, !noalias !3
  %c5017 = zext i32 %gml5016 to i64
  %wp5018 = getelementptr inbounds i8, ptr %c, i64 16
  store i64 %c5017, ptr %wp5018, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117120 word 0x7100085f
  ; @pc 0x800117124 word 0x540000e0
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond5042 = icmp eq i32 %gml5016, 2
  br i1 %cond5042, label %L_800117140, label %L_800117128_ft
L_800117140:
  ; @pc 0x800117140 word 0x1e220220
  %r5100.p = getelementptr inbounds i8, ptr %c, i64 136
  %r5100 = load i64, ptr %r5100.p, align 8, !alias.scope !3, !noalias !4
  %c5101 = trunc i64 %r5100 to i32
  ; [SIMDPairwiseAndConversionInlinePass] inline scalar SCVTF/UCVTF
  %itff7243 = sitofp i32 %c5101 to float
  ; @pc 0x800117144 word 0x1e270201
  %r5103.p = getelementptr inbounds i8, ptr %c, i64 128
  %r5103 = load i64, ptr %r5103.p, align 8, !alias.scope !3, !noalias !4
  %c5104 = trunc i64 %r5103 to i32
  %c5105 = zext i32 %c5104 to i128
  %wp5106 = getelementptr inbounds i8, ptr %c, i64 528
  store i128 %c5105, ptr %wp5106, align 16, !alias.scope !3, !noalias !4
  ; @pc 0x800117148 word 0x1e210800
  ; [FPCRFastFPLoweringPass] inline scalar FP op
  %fmf7138 = bitcast i32 %c5104 to float
  %frf7139 = fmul float %itff7243, %fmf7138
  %fri7140 = bitcast float %frf7139 to i32
  %frq7141 = zext i32 %fri7140 to i128
  %vw7142 = getelementptr inbounds i8, ptr %c, i64 512
  store i128 %frq7141, ptr %vw7142, align 16, !alias.scope !3, !noalias !4
  ; @pc 0x80011714c word 0x1e390002
  ; [SIMDPairwiseAndConversionInlinePass] inline scalar FCVTZS/FCVTZU
  %ftis327251 = call i32 @llvm.fptoui.sat.i32.f32(float %frf7139)
  %c5109 = zext i32 %ftis327251 to i64
  %wp5110 = getelementptr inbounds i8, ptr %c, i64 16
  store i64 %c5109, ptr %wp5110, align 8, !alias.scope !3, !noalias !4
  br label %L_800117150
L_800117150:
  ; @pc 0x800117150 word 0x9b2f0020
  %r5111.p = getelementptr inbounds i8, ptr %c, i64 8
  %r5111 = load i64, ptr %r5111.p, align 8, !alias.scope !3, !noalias !4
  %c5112 = trunc i64 %r5111 to i32
  %c5113 = sext i32 %c5112 to i64
  %r5114.p = getelementptr inbounds i8, ptr %c, i64 120
  %r5114 = load i64, ptr %r5114.p, align 8, !alias.scope !3, !noalias !4
  %c5115 = trunc i64 %r5114 to i32
  %c5116 = sext i32 %c5115 to i64
  %t5117 = mul i64 %c5113, %c5116
  %r5118.p = getelementptr inbounds i8, ptr %c, i64 0
  %r5118 = load i64, ptr %r5118.p, align 8, !alias.scope !3, !noalias !4
  %t5119 = add i64 %r5118, %t5117
  ; @pc 0x800117154 word 0xb9002002
  %t5122 = add i64 %t5119, 32
  %r5123.p = getelementptr inbounds i8, ptr %c, i64 16
  %r5123 = load i64, ptr %r5123.p, align 8, !alias.scope !3, !noalias !4
  %c5124 = trunc i64 %r5123 to i32
  %gmp5125 = inttoptr i64 %t5122 to ptr
  store i32 %c5124, ptr %gmp5125, align 1, !alias.scope !4, !noalias !3
  br label %L_800117158
L_800117158:
  ; @pc 0x800117158 word 0x885f7dc0
  %r5126.p = getelementptr inbounds i8, ptr %c, i64 112
  %r5126 = load i64, ptr %r5126.p, align 8, !alias.scope !3, !noalias !4
  %atp5127 = inttoptr i64 %r5126 to ptr
  %ldx5128 = load atomic i32, ptr %atp5127 acquire, align 4, !alias.scope !4, !noalias !3
  %c5129 = zext i32 %ldx5128 to i64
  %wp5132 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 %c5129, ptr %wp5132, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011715c word 0x11000401
  %t5135 = add i32 %ldx5128, 1
  ; @pc 0x800117160 word 0x88027dc1
  %atp5139 = inttoptr i64 %r5126 to ptr
  ; [ExclusiveMonitorLSEFastPathPass] elided software exclusive monitor
  %cmp5145 = icmp eq i64 0, 0
  %cx5149 = cmpxchg ptr %atp5139, i32 %ldx5128, i32 %t5135 seq_cst seq_cst, align 4
  %cxok5150 = extractvalue { i32, i1 } %cx5149, 1
  %t5151 = and i1 %cmp5145, %cxok5150
  %sel5152 = select i1 %t5151, i32 0, i32 1
  %c5153 = zext i32 %sel5152 to i64
  %wp5154 = getelementptr inbounds i8, ptr %c, i64 16
  store i64 %c5153, ptr %wp5154, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117164 word 0x35ffffa2
  %cmp5157 = icmp ne i32 %sel5152, 0
  br i1 %cmp5157, label %L_800117158, label %L_800117168_ft
L_800117180:
  ; @pc 0x800117180 word 0x1100054a
  %r5218.p = getelementptr inbounds i8, ptr %c, i64 80
  %r5218 = load i64, ptr %r5218.p, align 8, !alias.scope !3, !noalias !4
  %c5219 = trunc i64 %r5218 to i32
  %t5220 = add i32 %c5219, 1
  %c5221 = zext i32 %t5220 to i64
  %wp5222 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 %c5221, ptr %wp5222, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117184 word 0x0b0b022b
  %r5223.p = getelementptr inbounds i8, ptr %c, i64 136
  %r5223 = load i64, ptr %r5223.p, align 8, !alias.scope !3, !noalias !4
  %c5224 = trunc i64 %r5223 to i32
  %r5225.p = getelementptr inbounds i8, ptr %c, i64 88
  %r5225 = load i64, ptr %r5225.p, align 8, !alias.scope !3, !noalias !4
  %c5226 = trunc i64 %r5225 to i32
  %t5227 = add i32 %c5224, %c5226
  %c5228 = zext i32 %t5227 to i64
  %wp5229 = getelementptr inbounds i8, ptr %c, i64 88
  store i64 %c5228, ptr %wp5229, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117188 word 0x6b08015f
  %r5232.p = getelementptr inbounds i8, ptr %c, i64 64
  %r5232 = load i64, ptr %r5232.p, align 8, !alias.scope !3, !noalias !4
  %c5233 = trunc i64 %r5232 to i32
  ; @pc 0x80011718c word 0x54fffa61
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond5255 = icmp ne i32 %t5220, %c5233
  br i1 %cond5255, label %L_8001170d8, label %L_800117190_ft
L_800117194:
  ; @pc 0x800117194 word 0x7100023f
  %r5258.p = getelementptr inbounds i8, ptr %c, i64 136
  %r5258 = load i64, ptr %r5258.p, align 8, !alias.scope !3, !noalias !4
  %c5259 = trunc i64 %r5258 to i32
  ; @pc 0x800117198 word 0x1a91a622
  %t5284 = add i32 %c5259, 1
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond5286 = icmp sge i32 %c5259, 0
  %sel5291 = select i1 %cond5286, i32 %c5259, i32 %t5284
  ; @pc 0x80011719c word 0x13017c42
  %ror5296 = call i32 @llvm.fshr.i32(i32 %sel5291, i32 %sel5291, i32 1)
  %t5297 = lshr i32 %sel5291, 31
  %t5298 = and i32 %t5297, 1
  %t5299 = sub i32 0, %t5298
  %t5300 = and i32 %t5299, -2147483648
  %t5301 = and i32 %ror5296, 2147483647
  %t5302 = or i32 %t5300, %t5301
  %c5303 = zext i32 %t5302 to i64
  %wp5304 = getelementptr inbounds i8, ptr %c, i64 16
  store i64 %c5303, ptr %wp5304, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001171a0 word 0x17ffffec
  br label %L_800117150
L_8001171a4:
  ; @pc 0x8001171a4 word 0xa9524ff4
  %r5305 = load i64, ptr %loc_sp, align 8
  %t5306 = add i64 %r5305, 288
  %t5307 = add i64 %t5306, 8
  %gmp5308 = inttoptr i64 %t5306 to ptr
  %gml5309 = load i64, ptr %gmp5308, align 8, !alias.scope !6, !noalias !3
  %gmp5310 = inttoptr i64 %t5307 to ptr
  %gml5311 = load i64, ptr %gmp5310, align 8, !alias.scope !6, !noalias !3
  %wp5312 = getelementptr inbounds i8, ptr %c, i64 160
  store i64 %gml5309, ptr %wp5312, align 8, !alias.scope !3, !noalias !4
  %wp5313 = getelementptr inbounds i8, ptr %c, i64 152
  store i64 %gml5311, ptr %wp5313, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001171a8 word 0xa95157f6
  %t5315 = add i64 %r5305, 272
  %t5316 = add i64 %t5315, 8
  %gmp5317 = inttoptr i64 %t5315 to ptr
  %gml5318 = load i64, ptr %gmp5317, align 8, !alias.scope !6, !noalias !3
  %gmp5319 = inttoptr i64 %t5316 to ptr
  %gml5320 = load i64, ptr %gmp5319, align 8, !alias.scope !6, !noalias !3
  %wp5321 = getelementptr inbounds i8, ptr %c, i64 176
  store i64 %gml5318, ptr %wp5321, align 8, !alias.scope !3, !noalias !4
  %wp5322 = getelementptr inbounds i8, ptr %c, i64 168
  store i64 %gml5320, ptr %wp5322, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001171ac word 0xa9505ff8
  %t5324 = add i64 %r5305, 256
  %t5325 = add i64 %t5324, 8
  %gmp5326 = inttoptr i64 %t5324 to ptr
  %gml5327 = load i64, ptr %gmp5326, align 8, !alias.scope !6, !noalias !3
  %gmp5328 = inttoptr i64 %t5325 to ptr
  %gml5329 = load i64, ptr %gmp5328, align 8, !alias.scope !6, !noalias !3
  %wp5330 = getelementptr inbounds i8, ptr %c, i64 192
  store i64 %gml5327, ptr %wp5330, align 8, !alias.scope !3, !noalias !4
  %wp5331 = getelementptr inbounds i8, ptr %c, i64 184
  store i64 %gml5329, ptr %wp5331, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001171b0 word 0xa94f67fa
  %t5333 = add i64 %r5305, 240
  %t5334 = add i64 %t5333, 8
  %gmp5335 = inttoptr i64 %t5333 to ptr
  %gml5336 = load i64, ptr %gmp5335, align 8, !alias.scope !6, !noalias !3
  %gmp5337 = inttoptr i64 %t5334 to ptr
  %gml5338 = load i64, ptr %gmp5337, align 8, !alias.scope !6, !noalias !3
  %wp5339 = getelementptr inbounds i8, ptr %c, i64 208
  store i64 %gml5336, ptr %wp5339, align 8, !alias.scope !3, !noalias !4
  %wp5340 = getelementptr inbounds i8, ptr %c, i64 200
  store i64 %gml5338, ptr %wp5340, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001171b4 word 0xa94e6ffc
  %t5342 = add i64 %r5305, 224
  %t5343 = add i64 %t5342, 8
  %gmp5344 = inttoptr i64 %t5342 to ptr
  %gml5345 = load i64, ptr %gmp5344, align 8, !alias.scope !6, !noalias !3
  %gmp5346 = inttoptr i64 %t5343 to ptr
  %gml5347 = load i64, ptr %gmp5346, align 8, !alias.scope !6, !noalias !3
  %wp5348 = getelementptr inbounds i8, ptr %c, i64 224
  store i64 %gml5345, ptr %wp5348, align 8, !alias.scope !3, !noalias !4
  %wp5349 = getelementptr inbounds i8, ptr %c, i64 216
  store i64 %gml5347, ptr %wp5349, align 8, !alias.scope !3, !noalias !4
  store i64 %gml5347, ptr %loc_x27, align 8
  ; @pc 0x8001171b8 word 0xa94d7bfd
  %t5351 = add i64 %r5305, 208
  %t5352 = add i64 %t5351, 8
  %gmp5353 = inttoptr i64 %t5351 to ptr
  %gml5354 = load i64, ptr %gmp5353, align 8, !alias.scope !6, !noalias !3
  %gmp5355 = inttoptr i64 %t5352 to ptr
  %gml5356 = load i64, ptr %gmp5355, align 8, !alias.scope !6, !noalias !3
  %wp5357 = getelementptr inbounds i8, ptr %c, i64 232
  store i64 %gml5354, ptr %wp5357, align 8, !alias.scope !3, !noalias !4
  store i64 %gml5354, ptr %loc_x29, align 8
  %wp5358 = getelementptr inbounds i8, ptr %c, i64 240
  store i64 %gml5356, ptr %wp5358, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001171bc word 0x9104c3ff
  %t5360 = add i64 %r5305, 304
  %wp5361 = getelementptr inbounds i8, ptr %c, i64 256
  store i64 %t5360, ptr %wp5361, align 8, !alias.scope !3, !noalias !4
  store i64 %t5360, ptr %loc_sp, align 8
  ; @pc 0x8001171c0 word 0xd65f03c0
  ret void
L_8001171c4:
  ; @pc 0x8001171c4 word 0x2a090149
  %r5362.p = getelementptr inbounds i8, ptr %c, i64 72
  %r5362 = load i64, ptr %r5362.p, align 8, !alias.scope !3, !noalias !4
  %c5363 = trunc i64 %r5362 to i32
  %r5364.p = getelementptr inbounds i8, ptr %c, i64 80
  %r5364 = load i64, ptr %r5364.p, align 8, !alias.scope !3, !noalias !4
  %c5365 = trunc i64 %r5364 to i32
  %t5366 = or i32 %c5365, %c5363
  %c5367 = zext i32 %t5366 to i64
  %wp5368 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %c5367, ptr %wp5368, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001171c8 word 0xb9000109
  %r5369.p = getelementptr inbounds i8, ptr %c, i64 64
  %r5369 = load i64, ptr %r5369.p, align 8, !alias.scope !3, !noalias !4
  %gmp5372 = inttoptr i64 %r5369 to ptr
  store i32 %t5366, ptr %gmp5372, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001171cc word 0x17ffff94
  br label %L_80011701c
L_8001171d0:
  ; @pc 0x8001171d0 word 0x929ffcae
  ; @pc 0x8001171d4 word 0x52840009
  ; @pc 0x8001171d8 word 0xf94f6696
  %r5376.p = getelementptr inbounds i8, ptr %c, i64 160
  %r5376 = load i64, ptr %r5376.p, align 8, !alias.scope !3, !noalias !4
  %t5377 = add i64 %r5376, 7880
  %gmp5378 = inttoptr i64 %t5377 to ptr
  %gml5379 = load i64, ptr %gmp5378, align 1, !alias.scope !4, !noalias !3
  %wp5380 = getelementptr inbounds i8, ptr %c, i64 176
  store i64 %gml5379, ptr %wp5380, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001171dc word 0x529fffed
  ; @pc 0x8001171e0 word 0xf2a0000e
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7493 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 18446744069414584346, ptr %cwp7493, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001171e4 word 0x3900237f
  %r5387 = load i64, ptr %loc_x27, align 8
  %t5388 = add i64 %r5387, 8
  %gmp5390 = inttoptr i64 %t5388 to ptr
  store i8 0, ptr %gmp5390, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001171e8 word 0xa9007fe9
  %r5391 = load i64, ptr %loc_sp, align 8
  %t5392 = add i64 %r5391, 8
  %gmp5394 = inttoptr i64 %r5391 to ptr
  store i64 8192, ptr %gmp5394, align 8, !alias.scope !6, !noalias !3
  %gmp5395 = inttoptr i64 %t5392 to ptr
  store i64 0, ptr %gmp5395, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001171ec word 0xd2c00029
  ; @pc 0x8001171f0 word 0xa9013bed
  %t5398 = add i64 %r5391, 16
  %t5399 = add i64 %t5398, 8
  %gmp5401 = inttoptr i64 %t5398 to ptr
  store i64 65535, ptr %gmp5401, align 8, !alias.scope !6, !noalias !3
  %gmp5403 = inttoptr i64 %t5399 to ptr
  store i64 18446744069414584346, ptr %gmp5403, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001171f4 word 0xb2607fed
  ; @pc 0x8001171f8 word 0x9100418c
  %r5406.p = getelementptr inbounds i8, ptr %c, i64 96
  %r5406 = load i64, ptr %r5406.p, align 8, !alias.scope !3, !noalias !4
  %t5407 = add i64 %r5406, 16
  ; @pc 0x8001171fc word 0xaa1303e1
  %r5409.p = getelementptr inbounds i8, ptr %c, i64 152
  %r5409 = load i64, ptr %r5409.p, align 8, !alias.scope !3, !noalias !4
  %wp5411 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %r5409, ptr %wp5411, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117200 word 0xf900037f
  %gmp5413 = inttoptr i64 %r5387 to ptr
  store i64 0, ptr %gmp5413, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117204 word 0xb900a3e8
  %t5415 = add i64 %r5391, 160
  %r5416.p = getelementptr inbounds i8, ptr %c, i64 64
  %r5416 = load i64, ptr %r5416.p, align 8, !alias.scope !3, !noalias !4
  %c5417 = trunc i64 %r5416 to i32
  %gmp5418 = inttoptr i64 %t5415 to ptr
  store i32 %c5417, ptr %gmp5418, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800117208 word 0xa90237e9
  %t5420 = add i64 %r5391, 32
  %t5421 = add i64 %t5420, 8
  %gmp5423 = inttoptr i64 %t5420 to ptr
  store i64 4294967296, ptr %gmp5423, align 8, !alias.scope !6, !noalias !3
  %gmp5425 = inttoptr i64 %t5421 to ptr
  store i64 18446744069414584320, ptr %gmp5425, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x80011720c word 0x12800009
  ; @pc 0x800117210 word 0xb2091bed
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7496 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 4575657222473777152, ptr %cwp7496, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117214 word 0xa90337e9
  %t5431 = add i64 %r5391, 48
  %t5432 = add i64 %t5431, 8
  %gmp5434 = inttoptr i64 %t5431 to ptr
  store i64 4294967295, ptr %gmp5434, align 8, !alias.scope !6, !noalias !3
  %gmp5436 = inttoptr i64 %t5432 to ptr
  store i64 4575657222473777152, ptr %gmp5436, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117218 word 0x90015c29
  ; @pc 0x80011721c word 0x91057d29
  ; @pc 0x800117220 word 0xa9072fe9
  %t5442 = add i64 %r5391, 112
  %t5443 = add i64 %t5442, 8
  %gmp5445 = inttoptr i64 %t5442 to ptr
  store i64 34406510943, ptr %gmp5445, align 8, !alias.scope !6, !noalias !3
  %r5446.p = getelementptr inbounds i8, ptr %c, i64 88
  %r5446 = load i64, ptr %r5446.p, align 8, !alias.scope !3, !noalias !4
  %gmp5447 = inttoptr i64 %t5443 to ptr
  store i64 %r5446, ptr %gmp5447, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117224 word 0xb2087be9
  ; @pc 0x800117228 word 0xa90833e9
  %t5451 = add i64 %r5391, 128
  %t5452 = add i64 %t5451, 8
  %gmp5454 = inttoptr i64 %t5451 to ptr
  store i64 18410715276682199039, ptr %gmp5454, align 8, !alias.scope !6, !noalias !3
  %gmp5456 = inttoptr i64 %t5452 to ptr
  store i64 %t5407, ptr %gmp5456, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x80011722c word 0xd2e7f00c
  %wp5457 = getelementptr inbounds i8, ptr %c, i64 96
  store i64 4575657221408423936, ptr %wp5457, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117230 word 0xf80a430c
  %r5458.p = getelementptr inbounds i8, ptr %c, i64 192
  %r5458 = load i64, ptr %r5458.p, align 8, !alias.scope !3, !noalias !4
  %t5459 = add i64 %r5458, 164
  %gmp5461 = inttoptr i64 %t5459 to ptr
  store i64 4575657221408423936, ptr %gmp5461, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117234 word 0xa90927eb
  %t5463 = add i64 %r5391, 144
  %t5464 = add i64 %t5463, 8
  %gmp5466 = inttoptr i64 %t5463 to ptr
  store i64 %r5446, ptr %gmp5466, align 8, !alias.scope !6, !noalias !3
  %gmp5468 = inttoptr i64 %t5464 to ptr
  store i64 18410715276682199039, ptr %gmp5468, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117238 word 0x91004149
  %r5469.p = getelementptr inbounds i8, ptr %c, i64 80
  %r5469 = load i64, ptr %r5469.p, align 8, !alias.scope !3, !noalias !4
  %t5470 = add i64 %r5469, 16
  ; @pc 0x80011723c word 0x5283d60a
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7499 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 7856, ptr %cwp7499, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117240 word 0x8b0a0280
  %t5476 = add i64 %r5376, 7856
  %wp5477 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 %t5476, ptr %wp5477, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117244 word 0xa9057fe9
  %t5479 = add i64 %r5391, 80
  %t5480 = add i64 %t5479, 8
  %gmp5482 = inttoptr i64 %t5479 to ptr
  store i64 %t5470, ptr %gmp5482, align 8, !alias.scope !6, !noalias !3
  %gmp5483 = inttoptr i64 %t5480 to ptr
  store i64 0, ptr %gmp5483, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117248 word 0x52800069
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7500 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 3, ptr %cwp7500, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011724c word 0xb900bfe9
  %t5487 = add i64 %r5391, 188
  %gmp5490 = inttoptr i64 %t5487 to ptr
  store i32 3, ptr %gmp5490, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800117250 word 0xa9047fed
  %t5492 = add i64 %r5391, 64
  %t5493 = add i64 %t5492, 8
  %gmp5495 = inttoptr i64 %t5492 to ptr
  store i64 4575657222473777152, ptr %gmp5495, align 8, !alias.scope !6, !noalias !3
  %gmp5496 = inttoptr i64 %t5493 to ptr
  store i64 0, ptr %gmp5496, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117254 word 0xa9067fff
  %t5498 = add i64 %r5391, 96
  ; [AArch64IdiomDeconstructPass] coalesced paired 64-bit zero stores -> i128
  %stpp7501 = inttoptr i64 %t5498 to ptr
  store i128 0, ptr %stpp7501, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117258 word 0x97ff60c6
  %wp5502 = getelementptr inbounds i8, ptr %c, i64 240
  store i64 34360881756, ptr %wp5502, align 8, !alias.scope !3, !noalias !4
  call void @f_8000ef570(ptr %c)
  ; @pc 0x80011725c word 0x39402268
  %r5503.p = getelementptr inbounds i8, ptr %c, i64 152
  %r5503 = load i64, ptr %r5503.p, align 8, !alias.scope !3, !noalias !4
  %t5504 = add i64 %r5503, 8
  %gmp5505 = inttoptr i64 %t5504 to ptr
  %gml5506 = load i8, ptr %gmp5505, align 1, !alias.scope !4, !noalias !3
  %c5507 = zext i8 %gml5506 to i64
  %wp5508 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %c5507, ptr %wp5508, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117260 word 0x52879c0b
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7502 = getelementptr inbounds i8, ptr %c, i64 88
  store i64 15584, ptr %cwp7502, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117264 word 0xb9400aca
  %r5511.p = getelementptr inbounds i8, ptr %c, i64 176
  %r5511 = load i64, ptr %r5511.p, align 8, !alias.scope !3, !noalias !4
  %t5512 = add i64 %r5511, 8
  %gmp5513 = inttoptr i64 %t5512 to ptr
  %gml5514 = load i32, ptr %gmp5513, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117268 word 0x6b08015f
  %c5520 = trunc i64 %c5507 to i32
  ; @pc 0x80011726c word 0xf9400ac9
  %t5542 = add i64 %r5511, 16
  %gmp5543 = inttoptr i64 %t5542 to ptr
  %gml5544 = load i64, ptr %gmp5543, align 1, !alias.scope !4, !noalias !3
  %wp5545 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %gml5544, ptr %wp5545, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117270 word 0x9a9f810a
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond5548 = icmp ugt i32 %gml5514, %c5520
  %sel5554 = select i1 %cond5548, i64 %c5507, i64 0
  %wp5555 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 %sel5554, ptr %wp5555, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117274 word 0x37000fa0
  %r5556.p = getelementptr inbounds i8, ptr %c, i64 0
  %r5556 = load i64, ptr %r5556.p, align 8, !alias.scope !3, !noalias !4
  %t5557 = and i64 %r5556, 1
  %cmp5558 = icmp ne i64 %t5557, 0
  br i1 %cmp5558, label %L_800117468, label %L_800117278_ft
L_80011728c:
  ; @pc 0x80011728c word 0xbd400120
  %r5581.p = getelementptr inbounds i8, ptr %c, i64 72
  %r5581 = load i64, ptr %r5581.p, align 8, !alias.scope !3, !noalias !4
  %gmp5582 = inttoptr i64 %r5581 to ptr
  %gml5583 = load i32, ptr %gmp5582, align 1, !alias.scope !4, !noalias !3
  %c5584 = zext i32 %gml5583 to i128
  %wp5585 = getelementptr inbounds i8, ptr %c, i64 512
  store i128 %c5584, ptr %wp5585, align 16, !alias.scope !3, !noalias !4
  ; @pc 0x800117290 word 0xbd400141
  %r5586.p = getelementptr inbounds i8, ptr %c, i64 80
  %r5586 = load i64, ptr %r5586.p, align 8, !alias.scope !3, !noalias !4
  %gmp5587 = inttoptr i64 %r5586 to ptr
  %gml5588 = load i32, ptr %gmp5587, align 1, !alias.scope !4, !noalias !3
  %c5589 = zext i32 %gml5588 to i128
  %wp5590 = getelementptr inbounds i8, ptr %c, i64 528
  store i128 %c5589, ptr %wp5590, align 16, !alias.scope !3, !noalias !4
  ; @pc 0x800117294 word 0xbd400162
  %r5591.p = getelementptr inbounds i8, ptr %c, i64 88
  %r5591 = load i64, ptr %r5591.p, align 8, !alias.scope !3, !noalias !4
  %gmp5592 = inttoptr i64 %r5591 to ptr
  %gml5593 = load i32, ptr %gmp5592, align 1, !alias.scope !4, !noalias !3
  %c5594 = zext i32 %gml5593 to i128
  %wp5595 = getelementptr inbounds i8, ptr %c, i64 544
  store i128 %c5594, ptr %wp5595, align 16, !alias.scope !3, !noalias !4
  ; @pc 0x800117298 word 0x52879c0b
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7503 = getelementptr inbounds i8, ptr %c, i64 88
  store i64 15584, ptr %cwp7503, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011729c word 0xbd400183
  %r5598.p = getelementptr inbounds i8, ptr %c, i64 96
  %r5598 = load i64, ptr %r5598.p, align 8, !alias.scope !3, !noalias !4
  %gmp5599 = inttoptr i64 %r5598 to ptr
  %gml5600 = load i32, ptr %gmp5599, align 1, !alias.scope !4, !noalias !3
  %c5601 = zext i32 %gml5600 to i128
  %wp5602 = getelementptr inbounds i8, ptr %c, i64 560
  store i128 %c5601, ptr %wp5602, align 16, !alias.scope !3, !noalias !4
  ; @pc 0x8001172a0 word 0x2d0f07e0
  %r5603 = load i64, ptr %loc_sp, align 8
  %t5604 = add i64 %r5603, 120
  %t5605 = add i64 %t5604, 4
  ; [AArch64IdiomDeconstructPass] forwarded scalar V-register value
  ; [AArch64IdiomDeconstructPass] forwarded scalar V-register value
  %gmp5610 = inttoptr i64 %t5604 to ptr
  store i32 %gml5583, ptr %gmp5610, align 4, !alias.scope !6, !noalias !3
  %gmp5611 = inttoptr i64 %t5605 to ptr
  store i32 %gml5588, ptr %gmp5611, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001172a4 word 0x2d100fe2
  %t5613 = add i64 %r5603, 128
  %t5614 = add i64 %t5613, 4
  ; [AArch64IdiomDeconstructPass] forwarded scalar V-register value
  ; [AArch64IdiomDeconstructPass] forwarded scalar V-register value
  %gmp5619 = inttoptr i64 %t5613 to ptr
  store i32 %gml5593, ptr %gmp5619, align 4, !alias.scope !6, !noalias !3
  %gmp5620 = inttoptr i64 %t5614 to ptr
  store i32 %gml5600, ptr %gmp5620, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001172a8 word 0xb9400aca
  %r5621.p = getelementptr inbounds i8, ptr %c, i64 176
  %r5621 = load i64, ptr %r5621.p, align 8, !alias.scope !3, !noalias !4
  %t5622 = add i64 %r5621, 8
  %gmp5623 = inttoptr i64 %t5622 to ptr
  %gml5624 = load i32, ptr %gmp5623, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001172ac word 0xf9400ac9
  %t5628 = add i64 %r5621, 16
  %gmp5629 = inttoptr i64 %t5628 to ptr
  %gml5630 = load i64, ptr %gmp5629, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001172b0 word 0x6b08015f
  %r5634.p = getelementptr inbounds i8, ptr %c, i64 64
  %r5634 = load i64, ptr %r5634.p, align 8, !alias.scope !3, !noalias !4
  %c5635 = trunc i64 %r5634 to i32
  ; @pc 0x8001172b4 word 0x9a9f810a
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond5658 = icmp ugt i32 %gml5624, %c5635
  %sel5664 = select i1 %cond5658, i64 %r5634, i64 0
  ; @pc 0x8001172b8 word 0x9bab2549
  %c5667 = trunc i64 %sel5664 to i32
  %c5668 = zext i32 %c5667 to i64
  %c5670 = trunc i64 15584 to i32
  %c5671 = zext i32 %c5670 to i64
  %t5672 = mul i64 %c5668, %c5671
  %t5674 = add i64 %gml5630, %t5672
  %wp5675 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %t5674, ptr %wp5675, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001172bc word 0x37000ea0
  %r5676.p = getelementptr inbounds i8, ptr %c, i64 0
  %r5676 = load i64, ptr %r5676.p, align 8, !alias.scope !3, !noalias !4
  %t5677 = and i64 %r5676, 1
  %cmp5678 = icmp ne i64 %t5677, 0
  br i1 %cmp5678, label %L_800117490, label %L_8001172c0_ft
L_8001172f0:
  ; @pc 0x8001172f0 word 0xf9401109
  %r5771.p = getelementptr inbounds i8, ptr %c, i64 64
  %r5771 = load i64, ptr %r5771.p, align 8, !alias.scope !3, !noalias !4
  %t5772 = add i64 %r5771, 32
  %gmp5773 = inttoptr i64 %t5772 to ptr
  %gml5774 = load i64, ptr %gmp5773, align 1, !alias.scope !4, !noalias !3
  %wp5775 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %gml5774, ptr %wp5775, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001172f4 word 0xb4000049
  %cmp5777 = icmp eq i64 %gml5774, 0
  br i1 %cmp5777, label %L_8001172fc, label %L_8001172f8_ft
L_8001172fc:
  ; @pc 0x8001172fc word 0x3902c3e9
  %r5784 = load i64, ptr %loc_sp, align 8
  %t5785 = add i64 %r5784, 176
  %r5786.p = getelementptr inbounds i8, ptr %c, i64 72
  %r5786 = load i64, ptr %r5786.p, align 8, !alias.scope !3, !noalias !4
  %c5787 = trunc i64 %r5786 to i32
  %c5788 = trunc i32 %c5787 to i8
  %gmp5789 = inttoptr i64 %t5785 to ptr
  store i8 %c5788, ptr %gmp5789, align 1, !alias.scope !6, !noalias !3
  ; @pc 0x800117300 word 0xf9401509
  %r5790.p = getelementptr inbounds i8, ptr %c, i64 64
  %r5790 = load i64, ptr %r5790.p, align 8, !alias.scope !3, !noalias !4
  %t5791 = add i64 %r5790, 40
  %gmp5792 = inttoptr i64 %t5791 to ptr
  %gml5793 = load i64, ptr %gmp5792, align 1, !alias.scope !4, !noalias !3
  %wp5794 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %gml5793, ptr %wp5794, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117304 word 0xb50024e9
  %cmp5796 = icmp ne i64 %gml5793, 0
  br i1 %cmp5796, label %L_8001177a0, label %L_800117308
L_800117308:
  ; @pc 0x800117308 word 0x3902c7e9
  %r5797 = load i64, ptr %loc_sp, align 8
  %t5798 = add i64 %r5797, 177
  %r5799.p = getelementptr inbounds i8, ptr %c, i64 72
  %r5799 = load i64, ptr %r5799.p, align 8, !alias.scope !3, !noalias !4
  %c5800 = trunc i64 %r5799 to i32
  %c5801 = trunc i32 %c5800 to i8
  %gmp5802 = inttoptr i64 %t5798 to ptr
  store i8 %c5801, ptr %gmp5802, align 1, !alias.scope !6, !noalias !3
  ; @pc 0x80011730c word 0xf9401909
  %r5803.p = getelementptr inbounds i8, ptr %c, i64 64
  %r5803 = load i64, ptr %r5803.p, align 8, !alias.scope !3, !noalias !4
  %t5804 = add i64 %r5803, 48
  %gmp5805 = inttoptr i64 %t5804 to ptr
  %gml5806 = load i64, ptr %gmp5805, align 1, !alias.scope !4, !noalias !3
  %wp5807 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %gml5806, ptr %wp5807, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117310 word 0xb50024c9
  %cmp5809 = icmp ne i64 %gml5806, 0
  br i1 %cmp5809, label %L_8001177a8, label %L_800117314
L_800117314:
  ; @pc 0x800117314 word 0x3902cbe9
  %r5810 = load i64, ptr %loc_sp, align 8
  %t5811 = add i64 %r5810, 178
  %r5812.p = getelementptr inbounds i8, ptr %c, i64 72
  %r5812 = load i64, ptr %r5812.p, align 8, !alias.scope !3, !noalias !4
  %c5813 = trunc i64 %r5812 to i32
  %c5814 = trunc i32 %c5813 to i8
  %gmp5815 = inttoptr i64 %t5811 to ptr
  store i8 %c5814, ptr %gmp5815, align 1, !alias.scope !6, !noalias !3
  ; @pc 0x800117318 word 0xf9401d09
  %r5816.p = getelementptr inbounds i8, ptr %c, i64 64
  %r5816 = load i64, ptr %r5816.p, align 8, !alias.scope !3, !noalias !4
  %t5817 = add i64 %r5816, 56
  %gmp5818 = inttoptr i64 %t5817 to ptr
  %gml5819 = load i64, ptr %gmp5818, align 1, !alias.scope !4, !noalias !3
  %wp5820 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %gml5819, ptr %wp5820, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011731c word 0xb50024a9
  %cmp5822 = icmp ne i64 %gml5819, 0
  br i1 %cmp5822, label %L_8001177b0, label %L_800117320
L_800117320:
  ; @pc 0x800117320 word 0x3902cfe9
  %r5823 = load i64, ptr %loc_sp, align 8
  %t5824 = add i64 %r5823, 179
  %r5825.p = getelementptr inbounds i8, ptr %c, i64 72
  %r5825 = load i64, ptr %r5825.p, align 8, !alias.scope !3, !noalias !4
  %c5826 = trunc i64 %r5825 to i32
  %c5827 = trunc i32 %c5826 to i8
  %gmp5828 = inttoptr i64 %t5824 to ptr
  store i8 %c5827, ptr %gmp5828, align 1, !alias.scope !6, !noalias !3
  ; @pc 0x800117324 word 0xf9402109
  %r5829.p = getelementptr inbounds i8, ptr %c, i64 64
  %r5829 = load i64, ptr %r5829.p, align 8, !alias.scope !3, !noalias !4
  %t5830 = add i64 %r5829, 64
  %gmp5831 = inttoptr i64 %t5830 to ptr
  %gml5832 = load i64, ptr %gmp5831, align 1, !alias.scope !4, !noalias !3
  %wp5833 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %gml5832, ptr %wp5833, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117328 word 0xb5002489
  %cmp5835 = icmp ne i64 %gml5832, 0
  br i1 %cmp5835, label %L_8001177b8, label %L_80011732c
L_80011732c:
  ; @pc 0x80011732c word 0x3902d3e9
  %r5836 = load i64, ptr %loc_sp, align 8
  %t5837 = add i64 %r5836, 180
  %r5838.p = getelementptr inbounds i8, ptr %c, i64 72
  %r5838 = load i64, ptr %r5838.p, align 8, !alias.scope !3, !noalias !4
  %c5839 = trunc i64 %r5838 to i32
  %c5840 = trunc i32 %c5839 to i8
  %gmp5841 = inttoptr i64 %t5837 to ptr
  store i8 %c5840, ptr %gmp5841, align 1, !alias.scope !6, !noalias !3
  ; @pc 0x800117330 word 0xf9402509
  %r5842.p = getelementptr inbounds i8, ptr %c, i64 64
  %r5842 = load i64, ptr %r5842.p, align 8, !alias.scope !3, !noalias !4
  %t5843 = add i64 %r5842, 72
  %gmp5844 = inttoptr i64 %t5843 to ptr
  %gml5845 = load i64, ptr %gmp5844, align 1, !alias.scope !4, !noalias !3
  %wp5846 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %gml5845, ptr %wp5846, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117334 word 0xb5002469
  %cmp5848 = icmp ne i64 %gml5845, 0
  br i1 %cmp5848, label %L_8001177c0, label %L_800117338
L_800117338:
  ; @pc 0x800117338 word 0x3902d7e9
  %r5849 = load i64, ptr %loc_sp, align 8
  %t5850 = add i64 %r5849, 181
  %r5851.p = getelementptr inbounds i8, ptr %c, i64 72
  %r5851 = load i64, ptr %r5851.p, align 8, !alias.scope !3, !noalias !4
  %c5852 = trunc i64 %r5851 to i32
  %c5853 = trunc i32 %c5852 to i8
  %gmp5854 = inttoptr i64 %t5850 to ptr
  store i8 %c5853, ptr %gmp5854, align 1, !alias.scope !6, !noalias !3
  ; @pc 0x80011733c word 0xf9402909
  %r5855.p = getelementptr inbounds i8, ptr %c, i64 64
  %r5855 = load i64, ptr %r5855.p, align 8, !alias.scope !3, !noalias !4
  %t5856 = add i64 %r5855, 80
  %gmp5857 = inttoptr i64 %t5856 to ptr
  %gml5858 = load i64, ptr %gmp5857, align 1, !alias.scope !4, !noalias !3
  %wp5859 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %gml5858, ptr %wp5859, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117340 word 0xb5002449
  %cmp5861 = icmp ne i64 %gml5858, 0
  br i1 %cmp5861, label %L_8001177c8, label %L_800117344
L_800117344:
  ; @pc 0x800117344 word 0x3902dbe9
  %r5862 = load i64, ptr %loc_sp, align 8
  %t5863 = add i64 %r5862, 182
  %r5864.p = getelementptr inbounds i8, ptr %c, i64 72
  %r5864 = load i64, ptr %r5864.p, align 8, !alias.scope !3, !noalias !4
  %c5865 = trunc i64 %r5864 to i32
  %c5866 = trunc i32 %c5865 to i8
  %gmp5867 = inttoptr i64 %t5863 to ptr
  store i8 %c5866, ptr %gmp5867, align 1, !alias.scope !6, !noalias !3
  ; @pc 0x800117348 word 0xf9402d09
  %r5868.p = getelementptr inbounds i8, ptr %c, i64 64
  %r5868 = load i64, ptr %r5868.p, align 8, !alias.scope !3, !noalias !4
  %t5869 = add i64 %r5868, 88
  %gmp5870 = inttoptr i64 %t5869 to ptr
  %gml5871 = load i64, ptr %gmp5870, align 1, !alias.scope !4, !noalias !3
  %wp5872 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %gml5871, ptr %wp5872, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011734c word 0xb5002429
  %cmp5874 = icmp ne i64 %gml5871, 0
  br i1 %cmp5874, label %L_8001177d0, label %L_800117350
L_800117350:
  ; @pc 0x800117350 word 0x3902dfe9
  %r5875 = load i64, ptr %loc_sp, align 8
  %t5876 = add i64 %r5875, 183
  %r5877.p = getelementptr inbounds i8, ptr %c, i64 72
  %r5877 = load i64, ptr %r5877.p, align 8, !alias.scope !3, !noalias !4
  %c5878 = trunc i64 %r5877 to i32
  %c5879 = trunc i32 %c5878 to i8
  %gmp5880 = inttoptr i64 %t5876 to ptr
  store i8 %c5879, ptr %gmp5880, align 1, !alias.scope !6, !noalias !3
  ; @pc 0x800117354 word 0xf9403108
  %r5881.p = getelementptr inbounds i8, ptr %c, i64 64
  %r5881 = load i64, ptr %r5881.p, align 8, !alias.scope !3, !noalias !4
  %t5882 = add i64 %r5881, 96
  %gmp5883 = inttoptr i64 %t5882 to ptr
  %gml5884 = load i64, ptr %gmp5883, align 1, !alias.scope !4, !noalias !3
  %wp5885 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %gml5884, ptr %wp5885, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117358 word 0xb4ffe3c8
  %cmp5887 = icmp eq i64 %gml5884, 0
  br i1 %cmp5887, label %L_800116fd0, label %L_80011735c_ft
L_800117364:
  ; @pc 0x800117364 word 0xd2800030
  ; @pc 0x800117368 word 0x5280004f
  ; @pc 0x80011736c word 0xf94f668e
  %r5897.p = getelementptr inbounds i8, ptr %c, i64 160
  %r5897 = load i64, ptr %r5897.p, align 8, !alias.scope !3, !noalias !4
  %t5898 = add i64 %r5897, 7880
  %gmp5899 = inttoptr i64 %t5898 to ptr
  %gml5900 = load i64, ptr %gmp5899, align 1, !alias.scope !4, !noalias !3
  %wp5901 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 %gml5900, ptr %wp5901, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117370 word 0xf2e00810
  ; @pc 0x800117374 word 0xd2c00020
  %wp5906 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 4294967296, ptr %wp5906, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117378 word 0x3900237f
  %r5907 = load i64, ptr %loc_x27, align 8
  %t5908 = add i64 %r5907, 8
  %gmp5910 = inttoptr i64 %t5908 to ptr
  store i8 0, ptr %gmp5910, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011737c word 0xa90043ef
  %r5911 = load i64, ptr %loc_sp, align 8
  %t5912 = add i64 %r5911, 8
  %gmp5914 = inttoptr i64 %r5911 to ptr
  store i64 2, ptr %gmp5914, align 8, !alias.scope !6, !noalias !3
  %gmp5916 = inttoptr i64 %t5912 to ptr
  store i64 18014398509481985, ptr %gmp5916, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117380 word 0xb2607fef
  ; @pc 0x800117384 word 0xa9023fe0
  %t5920 = add i64 %r5911, 32
  %t5921 = add i64 %t5920, 8
  %gmp5923 = inttoptr i64 %t5920 to ptr
  store i64 4294967296, ptr %gmp5923, align 8, !alias.scope !6, !noalias !3
  %gmp5925 = inttoptr i64 %t5921 to ptr
  store i64 18446744069414584320, ptr %gmp5925, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117388 word 0xb2087bef
  ; @pc 0x80011738c word 0x9100418c
  %r5928.p = getelementptr inbounds i8, ptr %c, i64 96
  %r5928 = load i64, ptr %r5928.p, align 8, !alias.scope !3, !noalias !4
  %t5929 = add i64 %r5928, 16
  ; @pc 0x800117390 word 0x929ffd32
  ; @pc 0x800117394 word 0xd001576d
  ; @pc 0x800117398 word 0x913729ad
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7509 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 34405899722, ptr %cwp7509, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011739c word 0xa90833ef
  %t5937 = add i64 %r5911, 128
  %t5938 = add i64 %t5937, 8
  %gmp5940 = inttoptr i64 %t5937 to ptr
  store i64 18410715276682199039, ptr %gmp5940, align 8, !alias.scope !6, !noalias !3
  %gmp5942 = inttoptr i64 %t5938 to ptr
  store i64 %t5929, ptr %gmp5942, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001173a0 word 0xd2e7f00c
  ; @pc 0x8001173a4 word 0x529ffff1
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7510 = getelementptr inbounds i8, ptr %c, i64 136
  store i64 65535, ptr %cwp7510, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001173a8 word 0xf2a00012
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7511 = getelementptr inbounds i8, ptr %c, i64 144
  store i64 18446744069414584342, ptr %cwp7511, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001173ac word 0x12800010
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7512 = getelementptr inbounds i8, ptr %c, i64 128
  store i64 4294967295, ptr %cwp7512, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001173b0 word 0xf80a430c
  %r5952.p = getelementptr inbounds i8, ptr %c, i64 192
  %r5952 = load i64, ptr %r5952.p, align 8, !alias.scope !3, !noalias !4
  %t5953 = add i64 %r5952, 164
  %gmp5955 = inttoptr i64 %t5953 to ptr
  store i64 4575657221408423936, ptr %gmp5955, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001173b4 word 0xb2091bec
  ; @pc 0x8001173b8 word 0x9100414a
  %r5958.p = getelementptr inbounds i8, ptr %c, i64 80
  %r5958 = load i64, ptr %r5958.p, align 8, !alias.scope !3, !noalias !4
  %t5959 = add i64 %r5958, 16
  ; @pc 0x8001173bc word 0xa9093feb
  %t5962 = add i64 %r5911, 144
  %t5963 = add i64 %t5962, 8
  %r5964.p = getelementptr inbounds i8, ptr %c, i64 88
  %r5964 = load i64, ptr %r5964.p, align 8, !alias.scope !3, !noalias !4
  %gmp5965 = inttoptr i64 %t5962 to ptr
  store i64 %r5964, ptr %gmp5965, align 8, !alias.scope !6, !noalias !3
  %gmp5967 = inttoptr i64 %t5963 to ptr
  store i64 18410715276682199039, ptr %gmp5967, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001173c0 word 0x5280006f
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7514 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 3, ptr %cwp7514, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001173c4 word 0xf900037f
  %gmp5971 = inttoptr i64 %r5907 to ptr
  store i64 0, ptr %gmp5971, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001173c8 word 0xb900a3e8
  %t5973 = add i64 %r5911, 160
  %r5974.p = getelementptr inbounds i8, ptr %c, i64 64
  %r5974 = load i64, ptr %r5974.p, align 8, !alias.scope !3, !noalias !4
  %c5975 = trunc i64 %r5974 to i32
  %gmp5976 = inttoptr i64 %t5973 to ptr
  store i32 %c5975, ptr %gmp5976, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001173cc word 0x39402268
  %r5977.p = getelementptr inbounds i8, ptr %c, i64 152
  %r5977 = load i64, ptr %r5977.p, align 8, !alias.scope !3, !noalias !4
  %t5978 = add i64 %r5977, 8
  %gmp5979 = inttoptr i64 %t5978 to ptr
  %gml5980 = load i8, ptr %gmp5979, align 1, !alias.scope !4, !noalias !3
  %c5981 = zext i8 %gml5980 to i64
  ; @pc 0x8001173d0 word 0xb900bfef
  %t5984 = add i64 %r5911, 188
  %gmp5987 = inttoptr i64 %t5984 to ptr
  store i32 3, ptr %gmp5987, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001173d4 word 0xa9014bf1
  %t5989 = add i64 %r5911, 16
  %t5990 = add i64 %t5989, 8
  %gmp5992 = inttoptr i64 %t5989 to ptr
  store i64 65535, ptr %gmp5992, align 8, !alias.scope !6, !noalias !3
  %gmp5994 = inttoptr i64 %t5990 to ptr
  store i64 18446744069414584342, ptr %gmp5994, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001173d8 word 0xa9067fff
  %t5996 = add i64 %r5911, 96
  ; [AArch64IdiomDeconstructPass] coalesced paired 64-bit zero stores -> i128
  %stpp7515 = inttoptr i64 %t5996 to ptr
  store i128 0, ptr %stpp7515, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001173dc word 0xa90333f0
  %t6001 = add i64 %r5911, 48
  %t6002 = add i64 %t6001, 8
  %gmp6004 = inttoptr i64 %t6001 to ptr
  store i64 4294967295, ptr %gmp6004, align 8, !alias.scope !6, !noalias !3
  %gmp6006 = inttoptr i64 %t6002 to ptr
  store i64 4575657222473777152, ptr %gmp6006, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001173e0 word 0xa9047fec
  %t6008 = add i64 %r5911, 64
  %t6009 = add i64 %t6008, 8
  %gmp6011 = inttoptr i64 %t6008 to ptr
  store i64 4575657222473777152, ptr %gmp6011, align 8, !alias.scope !6, !noalias !3
  %gmp6012 = inttoptr i64 %t6009 to ptr
  store i64 0, ptr %gmp6012, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001173e4 word 0xa9057fea
  %t6014 = add i64 %r5911, 80
  %t6015 = add i64 %t6014, 8
  %gmp6017 = inttoptr i64 %t6014 to ptr
  store i64 %t5959, ptr %gmp6017, align 8, !alias.scope !6, !noalias !3
  %gmp6018 = inttoptr i64 %t6015 to ptr
  store i64 0, ptr %gmp6018, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001173e8 word 0xa9072fed
  %t6020 = add i64 %r5911, 112
  %t6021 = add i64 %t6020, 8
  %gmp6023 = inttoptr i64 %t6020 to ptr
  store i64 34405899722, ptr %gmp6023, align 8, !alias.scope !6, !noalias !3
  %gmp6025 = inttoptr i64 %t6021 to ptr
  store i64 %r5964, ptr %gmp6025, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001173ec word 0xb94009ca
  %t6027 = add i64 %gml5900, 8
  %gmp6028 = inttoptr i64 %t6027 to ptr
  %gml6029 = load i32, ptr %gmp6028, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001173f0 word 0xf94009cb
  %t6033 = add i64 %gml5900, 16
  %gmp6034 = inttoptr i64 %t6033 to ptr
  %gml6035 = load i64, ptr %gmp6034, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001173f4 word 0x6b08015f
  %c6040 = trunc i64 %c5981 to i32
  ; @pc 0x8001173f8 word 0x52879c0a
  ; @pc 0x8001173fc word 0x9a9f810c
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond6065 = icmp ugt i32 %gml6029, %c6040
  %sel6071 = select i1 %cond6065, i64 %c5981, i64 0
  ; @pc 0x800117400 word 0x9baa2d8b
  %c6074 = trunc i64 %sel6071 to i32
  %c6075 = zext i32 %c6074 to i64
  %c6077 = trunc i64 15584 to i32
  %c6078 = zext i32 %c6077 to i64
  %t6079 = mul i64 %c6075, %c6078
  %t6081 = add i64 %gml6035, %t6079
  ; @pc 0x800117404 word 0xf9585d6c
  %t6084 = add i64 %t6081, 12472
  %gmp6085 = inttoptr i64 %t6084 to ptr
  %gml6086 = load i64, ptr %gmp6085, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117408 word 0xf958596b
  %t6089 = add i64 %t6081, 12464
  %gmp6090 = inttoptr i64 %t6089 to ptr
  %gml6091 = load i64, ptr %gmp6090, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011740c word 0xa900312b
  %r6093.p = getelementptr inbounds i8, ptr %c, i64 72
  %r6093 = load i64, ptr %r6093.p, align 8, !alias.scope !3, !noalias !4
  %t6094 = add i64 %r6093, 8
  %gmp6096 = inttoptr i64 %r6093 to ptr
  store i64 %gml6091, ptr %gmp6096, align 1, !alias.scope !4, !noalias !3
  %gmp6098 = inttoptr i64 %t6094 to ptr
  store i64 %gml6086, ptr %gmp6098, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117410 word 0xb94009c9
  %t6100 = add i64 %gml5900, 8
  %gmp6101 = inttoptr i64 %t6100 to ptr
  %gml6102 = load i32, ptr %gmp6101, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117414 word 0xf94009cb
  %t6106 = add i64 %gml5900, 16
  %gmp6107 = inttoptr i64 %t6106 to ptr
  %gml6108 = load i64, ptr %gmp6107, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117418 word 0x6b08013f
  ; @pc 0x80011741c word 0x9a9f8108
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond6136 = icmp ugt i32 %gml6102, %c6040
  %sel6142 = select i1 %cond6136, i64 %c5981, i64 0
  ; @pc 0x800117420 word 0x9baa2d08
  %c6145 = trunc i64 %sel6142 to i32
  %c6146 = zext i32 %c6145 to i64
  %c6149 = zext i32 %c6077 to i64
  %t6150 = mul i64 %c6146, %c6149
  %t6152 = add i64 %gml6108, %t6150
  ; @pc 0x800117424 word 0xf9599d09
  %t6155 = add i64 %t6152, 13112
  %gmp6156 = inttoptr i64 %t6155 to ptr
  %gml6157 = load i64, ptr %gmp6156, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117428 word 0xf959990a
  %t6160 = add i64 %t6152, 13104
  %gmp6161 = inttoptr i64 %t6160 to ptr
  %gml6162 = load i64, ptr %gmp6161, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011742c word 0xa900274a
  %r6164.p = getelementptr inbounds i8, ptr %c, i64 208
  %r6164 = load i64, ptr %r6164.p, align 8, !alias.scope !3, !noalias !4
  %t6165 = add i64 %r6164, 8
  %gmp6167 = inttoptr i64 %r6164 to ptr
  store i64 %gml6162, ptr %gmp6167, align 1, !alias.scope !4, !noalias !3
  %gmp6169 = inttoptr i64 %t6165 to ptr
  store i64 %gml6157, ptr %gmp6169, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117430 word 0xb9734909
  %t6171 = add i64 %t6152, 13128
  %gmp6172 = inttoptr i64 %t6171 to ptr
  %gml6173 = load i32, ptr %gmp6172, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117434 word 0xf959a108
  %t6177 = add i64 %t6152, 13120
  %gmp6178 = inttoptr i64 %t6177 to ptr
  %gml6179 = load i64, ptr %gmp6178, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117438 word 0xf9000328
  %r6181.p = getelementptr inbounds i8, ptr %c, i64 200
  %r6181 = load i64, ptr %r6181.p, align 8, !alias.scope !3, !noalias !4
  %gmp6183 = inttoptr i64 %r6181 to ptr
  store i64 %gml6179, ptr %gmp6183, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011743c word 0xb9000b29
  %t6185 = add i64 %r6181, 8
  %gmp6188 = inttoptr i64 %t6185 to ptr
  store i32 %gml6173, ptr %gmp6188, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117440 word 0xb94045c8
  %t6190 = add i64 %gml5900, 68
  %gmp6191 = inttoptr i64 %t6190 to ptr
  %gml6192 = load i32, ptr %gmp6191, align 1, !alias.scope !4, !noalias !3
  %c6193 = zext i32 %gml6192 to i64
  %wp6194 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %c6193, ptr %wp6194, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117444 word 0xb94031c9
  %t6196 = add i64 %gml5900, 48
  %gmp6197 = inttoptr i64 %t6196 to ptr
  %gml6198 = load i32, ptr %gmp6197, align 1, !alias.scope !4, !noalias !3
  %c6199 = zext i32 %gml6198 to i64
  %wp6200 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %c6199, ptr %wp6200, align 8, !alias.scope !3, !noalias !4
  br label %L_800117448
L_800117448:
  ; @pc 0x800117448 word 0x3902c3e8
  %r6201 = load i64, ptr %loc_sp, align 8
  %t6202 = add i64 %r6201, 176
  %r6203.p = getelementptr inbounds i8, ptr %c, i64 64
  %r6203 = load i64, ptr %r6203.p, align 8, !alias.scope !3, !noalias !4
  %c6204 = trunc i64 %r6203 to i32
  %c6205 = trunc i32 %c6204 to i8
  %gmp6206 = inttoptr i64 %t6202 to ptr
  store i8 %c6205, ptr %gmp6206, align 1, !alias.scope !6, !noalias !3
  ; @pc 0x80011744c word 0xb900b7ff
  %t6208 = add i64 %r6201, 180
  %gmp6209 = inttoptr i64 %t6208 to ptr
  store i32 0, ptr %gmp6209, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800117450 word 0xb80b131f
  %r6210.p = getelementptr inbounds i8, ptr %c, i64 192
  %r6210 = load i64, ptr %r6210.p, align 8, !alias.scope !3, !noalias !4
  %t6211 = add i64 %r6210, 177
  %gmp6212 = inttoptr i64 %t6211 to ptr
  store i32 0, ptr %gmp6212, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117454 word 0x3902e3e9
  %t6214 = add i64 %r6201, 184
  %r6215.p = getelementptr inbounds i8, ptr %c, i64 72
  %r6215 = load i64, ptr %r6215.p, align 8, !alias.scope !3, !noalias !4
  %c6216 = trunc i64 %r6215 to i32
  %c6217 = trunc i32 %c6216 to i8
  %gmp6218 = inttoptr i64 %t6214 to ptr
  store i8 %c6217, ptr %gmp6218, align 1, !alias.scope !6, !noalias !3
  ; @pc 0x800117458 word 0x17fffedf
  br label %L_800116fd4
L_80011745c:
  ; @pc 0x80011745c word 0x0b110a22
  %r6219.p = getelementptr inbounds i8, ptr %c, i64 136
  %r6219 = load i64, ptr %r6219.p, align 8, !alias.scope !3, !noalias !4
  %c6220 = trunc i64 %r6219 to i32
  %t6223 = shl i32 %c6220, 2
  %t6224 = add i32 %c6220, %t6223
  ; @pc 0x800117460 word 0x531f7842
  %ror6229 = call i32 @llvm.fshr.i32(i32 %t6224, i32 %t6224, i32 31)
  %t6230 = and i32 %ror6229, -2
  %c6231 = zext i32 %t6230 to i64
  %wp6232 = getelementptr inbounds i8, ptr %c, i64 16
  store i64 %c6231, ptr %wp6232, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117464 word 0x17ffff3b
  br label %L_800117150
L_800117468:
  ; @pc 0x800117468 word 0x9bab254d
  %r6233.p = getelementptr inbounds i8, ptr %c, i64 80
  %r6233 = load i64, ptr %r6233.p, align 8, !alias.scope !3, !noalias !4
  %c6234 = trunc i64 %r6233 to i32
  %c6235 = zext i32 %c6234 to i64
  %r6236.p = getelementptr inbounds i8, ptr %c, i64 88
  %r6236 = load i64, ptr %r6236.p, align 8, !alias.scope !3, !noalias !4
  %c6237 = trunc i64 %r6236 to i32
  %c6238 = zext i32 %c6237 to i64
  %t6239 = mul i64 %c6235, %c6238
  %r6240.p = getelementptr inbounds i8, ptr %c, i64 72
  %r6240 = load i64, ptr %r6240.p, align 8, !alias.scope !3, !noalias !4
  %t6241 = add i64 %r6240, %t6239
  %wp6242 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 %t6241, ptr %wp6242, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011746c word 0x5285c00c
  ; @pc 0x800117470 word 0x5285c08a
  ; @pc 0x800117474 word 0x5285c10b
  ; @pc 0x800117478 word 0x8b0c01a9
  %t6251 = add i64 %t6241, 11776
  %wp6252 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %t6251, ptr %wp6252, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011747c word 0x5285c18c
  ; @pc 0x800117480 word 0x8b0a01aa
  %t6257 = add i64 %t6241, 11780
  %wp6258 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 %t6257, ptr %wp6258, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117484 word 0x8b0b01ab
  %t6261 = add i64 %t6241, 11784
  %wp6262 = getelementptr inbounds i8, ptr %c, i64 88
  store i64 %t6261, ptr %wp6262, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117488 word 0x8b0c01ac
  %t6265 = add i64 %t6241, 11788
  %wp6266 = getelementptr inbounds i8, ptr %c, i64 96
  store i64 %t6265, ptr %wp6266, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011748c word 0x17ffff80
  br label %L_80011728c
L_800117490:
  ; @pc 0x800117490 word 0xf958412a
  %r6267.p = getelementptr inbounds i8, ptr %c, i64 72
  %r6267 = load i64, ptr %r6267.p, align 8, !alias.scope !3, !noalias !4
  %t6268 = add i64 %r6267, 12416
  %gmp6269 = inttoptr i64 %t6268 to ptr
  %gml6270 = load i64, ptr %gmp6269, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117494 word 0xf958452c
  %t6273 = add i64 %r6267, 12424
  %gmp6274 = inttoptr i64 %t6273 to ptr
  %gml6275 = load i64, ptr %gmp6274, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117498 word 0xa900334a
  %r6277.p = getelementptr inbounds i8, ptr %c, i64 208
  %r6277 = load i64, ptr %r6277.p, align 8, !alias.scope !3, !noalias !4
  %t6278 = add i64 %r6277, 8
  %gmp6280 = inttoptr i64 %r6277 to ptr
  store i64 %gml6270, ptr %gmp6280, align 1, !alias.scope !4, !noalias !3
  %gmp6282 = inttoptr i64 %t6278 to ptr
  store i64 %gml6275, ptr %gmp6282, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011749c word 0xf958492a
  %t6284 = add i64 %r6267, 12432
  %gmp6285 = inttoptr i64 %t6284 to ptr
  %gml6286 = load i64, ptr %gmp6285, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001174a0 word 0xb9709929
  %t6289 = add i64 %r6267, 12440
  %gmp6290 = inttoptr i64 %t6289 to ptr
  %gml6291 = load i32, ptr %gmp6290, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001174a4 word 0xb9000b29
  %r6294.p = getelementptr inbounds i8, ptr %c, i64 200
  %r6294 = load i64, ptr %r6294.p, align 8, !alias.scope !3, !noalias !4
  %t6295 = add i64 %r6294, 8
  %gmp6298 = inttoptr i64 %t6295 to ptr
  store i32 %gml6291, ptr %gmp6298, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001174a8 word 0xf900032a
  %gmp6301 = inttoptr i64 %r6294 to ptr
  store i64 %gml6286, ptr %gmp6301, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001174ac word 0xb9400ac9
  %r6302.p = getelementptr inbounds i8, ptr %c, i64 176
  %r6302 = load i64, ptr %r6302.p, align 8, !alias.scope !3, !noalias !4
  %t6303 = add i64 %r6302, 8
  %gmp6304 = inttoptr i64 %t6303 to ptr
  %gml6305 = load i32, ptr %gmp6304, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001174b0 word 0xf9400aca
  %t6309 = add i64 %r6302, 16
  %gmp6310 = inttoptr i64 %t6309 to ptr
  %gml6311 = load i64, ptr %gmp6310, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001174b4 word 0x6b08013f
  %r6315.p = getelementptr inbounds i8, ptr %c, i64 64
  %r6315 = load i64, ptr %r6315.p, align 8, !alias.scope !3, !noalias !4
  %c6316 = trunc i64 %r6315 to i32
  ; @pc 0x8001174b8 word 0x5285be09
  ; @pc 0x8001174bc word 0x9a9f8108
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond6341 = icmp ugt i32 %gml6305, %c6316
  %sel6347 = select i1 %cond6341, i64 %r6315, i64 0
  ; @pc 0x8001174c0 word 0x9bab2908
  %c6350 = trunc i64 %sel6347 to i32
  %c6351 = zext i32 %c6350 to i64
  %r6352.p = getelementptr inbounds i8, ptr %c, i64 88
  %r6352 = load i64, ptr %r6352.p, align 8, !alias.scope !3, !noalias !4
  %c6353 = trunc i64 %r6352 to i32
  %c6354 = zext i32 %c6353 to i64
  %t6355 = mul i64 %c6351, %c6354
  %t6357 = add i64 %gml6311, %t6355
  ; @pc 0x8001174c4 word 0x8b090108
  %t6361 = add i64 %t6357, 11760
  %wp6362 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %t6361, ptr %wp6362, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001174c8 word 0x17ffff8a
  br label %L_8001172f0
L_8001174cc:
  ; @pc 0x8001174cc word 0xaa1f03e1
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7522 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 0, ptr %cwp7522, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001174d0 word 0x17ffff0d
  br label %L_800117104
L_8001174d4:
  ; @pc 0x8001174d4 word 0x52a20009
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7523 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 268435456, ptr %cwp7523, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001174d8 word 0xd001576d
  ; @pc 0x8001174dc word 0x9136a9ad
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7524 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 34405899690, ptr %cwp7524, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001174e0 word 0x1400000c
  br label %L_800117510
L_8001174e4:
  ; @pc 0x8001174e4 word 0x52a20009
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7525 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 268435456, ptr %cwp7525, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001174e8 word 0xf0015c4d
  ; @pc 0x8001174ec word 0x913b55ad
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7526 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 34406543061, ptr %cwp7526, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001174f0 word 0x14000008
  br label %L_800117510
L_8001174f4:
  ; @pc 0x8001174f4 word 0x52a20009
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7527 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 268435456, ptr %cwp7527, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001174f8 word 0xf001582d
  ; @pc 0x8001174fc word 0x9127ddad
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7528 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 34406001143, ptr %cwp7528, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117500 word 0x14000004
  br label %L_800117510
L_800117504:
  ; @pc 0x800117504 word 0x52a20009
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7529 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 268435456, ptr %cwp7529, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117508 word 0xf0015c8d
  ; @pc 0x80011750c word 0x913455ad
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7530 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 34406575381, ptr %cwp7530, align 8, !alias.scope !3, !noalias !4
  br label %L_800117510
L_800117510:
  ; @pc 0x800117510 word 0xb90003e9
  %r6389 = load i64, ptr %loc_sp, align 8
  %r6390.p = getelementptr inbounds i8, ptr %c, i64 72
  %r6390 = load i64, ptr %r6390.p, align 8, !alias.scope !3, !noalias !4
  %c6391 = trunc i64 %r6390 to i32
  %gmp6392 = inttoptr i64 %r6389 to ptr
  store i32 %c6391, ptr %gmp6392, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800117514 word 0xd28000c9
  ; @pc 0x800117518 word 0xf958fa80
  %r6394.p = getelementptr inbounds i8, ptr %c, i64 160
  %r6394 = load i64, ptr %r6394.p, align 8, !alias.scope !3, !noalias !4
  %t6395 = add i64 %r6394, 12784
  %gmp6396 = inttoptr i64 %t6395 to ptr
  %gml6397 = load i64, ptr %gmp6396, align 1, !alias.scope !4, !noalias !3
  %wp6398 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 %gml6397, ptr %wp6398, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011751c word 0xd2c0006f
  ; @pc 0x800117520 word 0xf2c00069
  ; @pc 0x800117524 word 0xf80143ef
  %t6405 = add i64 %r6389, 20
  %gmp6407 = inttoptr i64 %t6405 to ptr
  store i64 12884901888, ptr %gmp6407, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800117528 word 0x5280002f
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7532 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 1, ptr %cwp7532, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011752c word 0xf80043e9
  %t6411 = add i64 %r6389, 4
  %gmp6413 = inttoptr i64 %t6411 to ptr
  store i64 12884901894, ptr %gmp6413, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800117530 word 0xd2dfffe9
  ; @pc 0x800117534 word 0xf802c3ee
  %t6416 = add i64 %r6389, 44
  %r6417.p = getelementptr inbounds i8, ptr %c, i64 112
  %r6417 = load i64, ptr %r6417.p, align 8, !alias.scope !3, !noalias !4
  %gmp6418 = inttoptr i64 %t6416 to ptr
  store i64 %r6417, ptr %gmp6418, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800117538 word 0xf800c3e9
  %t6420 = add i64 %r6389, 12
  %gmp6422 = inttoptr i64 %t6420 to ptr
  store i64 281470681743360, ptr %gmp6422, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x80011753c word 0x12800009
  ; @pc 0x800117540 word 0xb2087bee
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7534 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 18410715276682199039, ptr %cwp7534, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117544 word 0xf801c3e9
  %t6428 = add i64 %r6389, 28
  %gmp6430 = inttoptr i64 %t6428 to ptr
  store i64 4294967295, ptr %gmp6430, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800117548 word 0xb2091be9
  ; @pc 0x80011754c word 0x9100418c
  %r6433.p = getelementptr inbounds i8, ptr %c, i64 96
  %r6433 = load i64, ptr %r6433.p, align 8, !alias.scope !3, !noalias !4
  %t6434 = add i64 %r6433, 16
  ; @pc 0x800117550 word 0xa903a7e9
  %t6437 = add i64 %r6389, 56
  %t6438 = add i64 %t6437, 8
  %gmp6440 = inttoptr i64 %t6437 to ptr
  store i64 4575657222473777152, ptr %gmp6440, align 8, !alias.scope !6, !noalias !3
  %gmp6442 = inttoptr i64 %t6438 to ptr
  store i64 4575657222473777152, ptr %gmp6442, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117554 word 0xd2e7f009
  %wp6443 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 4575657221408423936, ptr %wp6443, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117558 word 0x9100414a
  %r6444.p = getelementptr inbounds i8, ptr %c, i64 80
  %r6444 = load i64, ptr %r6444.p, align 8, !alias.scope !3, !noalias !4
  %t6445 = add i64 %r6444, 16
  ; @pc 0x80011755c word 0xf80243ef
  %t6448 = add i64 %r6389, 36
  %gmp6450 = inttoptr i64 %t6448 to ptr
  store i64 1, ptr %gmp6450, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800117560 word 0xb90037ff
  %t6452 = add i64 %r6389, 52
  %gmp6453 = inttoptr i64 %t6452 to ptr
  store i32 0, ptr %gmp6453, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800117564 word 0xf80a4309
  %r6454.p = getelementptr inbounds i8, ptr %c, i64 192
  %r6454 = load i64, ptr %r6454.p, align 8, !alias.scope !3, !noalias !4
  %t6455 = add i64 %r6454, 164
  %gmp6457 = inttoptr i64 %t6455 to ptr
  store i64 4575657221408423936, ptr %gmp6457, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117568 word 0xf9004fee
  %t6459 = add i64 %r6389, 152
  %gmp6461 = inttoptr i64 %t6459 to ptr
  store i64 18410715276682199039, ptr %gmp6461, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x80011756c word 0x3900237f
  %r6462 = load i64, ptr %loc_x27, align 8
  %t6463 = add i64 %r6462, 8
  %gmp6465 = inttoptr i64 %t6463 to ptr
  store i8 0, ptr %gmp6465, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117570 word 0xf900037f
  %gmp6467 = inttoptr i64 %r6462 to ptr
  store i64 0, ptr %gmp6467, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117574 word 0xb900a3e8
  %t6469 = add i64 %r6389, 160
  %r6470.p = getelementptr inbounds i8, ptr %c, i64 64
  %r6470 = load i64, ptr %r6470.p, align 8, !alias.scope !3, !noalias !4
  %c6471 = trunc i64 %r6470 to i32
  %gmp6472 = inttoptr i64 %t6469 to ptr
  store i32 %c6471, ptr %gmp6472, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800117578 word 0xb900bfef
  %t6474 = add i64 %r6389, 188
  %gmp6477 = inttoptr i64 %t6474 to ptr
  store i32 1, ptr %gmp6477, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x80011757c word 0xa907bbeb
  %t6479 = add i64 %r6389, 120
  %t6480 = add i64 %t6479, 8
  %r6481.p = getelementptr inbounds i8, ptr %c, i64 88
  %r6481 = load i64, ptr %r6481.p, align 8, !alias.scope !3, !noalias !4
  %gmp6482 = inttoptr i64 %t6479 to ptr
  store i64 %r6481, ptr %gmp6482, align 8, !alias.scope !6, !noalias !3
  %gmp6484 = inttoptr i64 %t6480 to ptr
  store i64 18410715276682199039, ptr %gmp6484, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117580 word 0xa908afec
  %t6486 = add i64 %r6389, 136
  %t6487 = add i64 %t6486, 8
  %gmp6489 = inttoptr i64 %t6486 to ptr
  store i64 %t6434, ptr %gmp6489, align 8, !alias.scope !6, !noalias !3
  %gmp6491 = inttoptr i64 %t6487 to ptr
  store i64 %r6481, ptr %gmp6491, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117584 word 0xa905ffff
  %t6493 = add i64 %r6389, 88
  ; [AArch64IdiomDeconstructPass] coalesced paired 64-bit zero stores -> i128
  %stpp7536 = inttoptr i64 %t6493 to ptr
  store i128 0, ptr %stpp7536, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117588 word 0xa906b7ff
  %t6498 = add i64 %r6389, 104
  %t6499 = add i64 %t6498, 8
  %gmp6500 = inttoptr i64 %t6498 to ptr
  store i64 0, ptr %gmp6500, align 8, !alias.scope !6, !noalias !3
  %r6501.p = getelementptr inbounds i8, ptr %c, i64 104
  %r6501 = load i64, ptr %r6501.p, align 8, !alias.scope !3, !noalias !4
  %gmp6502 = inttoptr i64 %t6499 to ptr
  store i64 %r6501, ptr %gmp6502, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x80011758c word 0xa904abff
  %t6504 = add i64 %r6389, 72
  %t6505 = add i64 %t6504, 8
  %gmp6506 = inttoptr i64 %t6504 to ptr
  store i64 0, ptr %gmp6506, align 8, !alias.scope !6, !noalias !3
  %gmp6508 = inttoptr i64 %t6505 to ptr
  store i64 %t6445, ptr %gmp6508, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117590 word 0xb4ffd220
  %cmp6510 = icmp eq i64 %gml6397, 0
  br i1 %cmp6510, label %L_800116fd4, label %L_800117594_ft
L_80011763c:
  ; @pc 0x80011763c word 0xaa1f03ea
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7537 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 0, ptr %cwp7537, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117640 word 0x17fffb00
  br label %L_800116240
L_800117644:
  ; @pc 0x800117644 word 0x5283d608
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7538 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 7856, ptr %cwp7538, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117648 word 0x910003e1
  %r6727 = load i64, ptr %loc_sp, align 8
  %t6728 = add i64 %r6727, 0
  %wp6729 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %t6728, ptr %wp6729, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011764c word 0xaa1303e2
  %r6730.p = getelementptr inbounds i8, ptr %c, i64 152
  %r6730 = load i64, ptr %r6730.p, align 8, !alias.scope !3, !noalias !4
  %wp6732 = getelementptr inbounds i8, ptr %c, i64 16
  store i64 %r6730, ptr %wp6732, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117650 word 0x8b080280
  %r6733.p = getelementptr inbounds i8, ptr %c, i64 160
  %r6733 = load i64, ptr %r6733.p, align 8, !alias.scope !3, !noalias !4
  %t6735 = add i64 %r6733, 7856
  %wp6736 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 %t6735, ptr %wp6736, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117654 word 0x52800023
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7539 = getelementptr inbounds i8, ptr %c, i64 24
  store i64 1, ptr %cwp7539, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117658 word 0x949cb586
  %wp6739 = getelementptr inbounds i8, ptr %c, i64 240
  store i64 34360882780, ptr %wp6739, align 8, !alias.scope !3, !noalias !4
  call void @f_802844c70(ptr %c)
  ; @pc 0x80011765c word 0x17fffe5e
  br label %L_800116fd4
L_800117660:
  ; @pc 0x800117660 word 0x5283d608
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7540 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 7856, ptr %cwp7540, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117664 word 0x910003e1
  %r6742 = load i64, ptr %loc_sp, align 8
  %t6743 = add i64 %r6742, 0
  %wp6744 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %t6743, ptr %wp6744, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117668 word 0xaa1303e2
  %r6745.p = getelementptr inbounds i8, ptr %c, i64 152
  %r6745 = load i64, ptr %r6745.p, align 8, !alias.scope !3, !noalias !4
  %wp6747 = getelementptr inbounds i8, ptr %c, i64 16
  store i64 %r6745, ptr %wp6747, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011766c word 0x8b080280
  %r6748.p = getelementptr inbounds i8, ptr %c, i64 160
  %r6748 = load i64, ptr %r6748.p, align 8, !alias.scope !3, !noalias !4
  %t6750 = add i64 %r6748, 7856
  %wp6751 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 %t6750, ptr %wp6751, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117670 word 0x2a1f03e3
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7541 = getelementptr inbounds i8, ptr %c, i64 24
  store i64 0, ptr %cwp7541, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117674 word 0x949cb57f
  %wp6755 = getelementptr inbounds i8, ptr %c, i64 240
  store i64 34360882808, ptr %wp6755, align 8, !alias.scope !3, !noalias !4
  call void @f_802844c70(ptr %c)
  ; @pc 0x800117678 word 0x17fffe57
  br label %L_800116fd4
L_80011767c:
  ; @pc 0x80011767c word 0x2a1f03eb
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7542 = getelementptr inbounds i8, ptr %c, i64 88
  store i64 0, ptr %cwp7542, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117680 word 0x17fffe60
  br label %L_800117000
L_800117684:
  ; @pc 0x800117684 word 0x5283d608
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7543 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 7856, ptr %cwp7543, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117688 word 0x910003e1
  %r6761 = load i64, ptr %loc_sp, align 8
  %t6762 = add i64 %r6761, 0
  %wp6763 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %t6762, ptr %wp6763, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011768c word 0xaa1303e2
  %r6764.p = getelementptr inbounds i8, ptr %c, i64 152
  %r6764 = load i64, ptr %r6764.p, align 8, !alias.scope !3, !noalias !4
  %wp6766 = getelementptr inbounds i8, ptr %c, i64 16
  store i64 %r6764, ptr %wp6766, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117690 word 0x8b080280
  %r6767.p = getelementptr inbounds i8, ptr %c, i64 160
  %r6767 = load i64, ptr %r6767.p, align 8, !alias.scope !3, !noalias !4
  %t6769 = add i64 %r6767, 7856
  %wp6770 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 %t6769, ptr %wp6770, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117694 word 0x949cb5bc
  %wp6771 = getelementptr inbounds i8, ptr %c, i64 240
  store i64 34360882840, ptr %wp6771, align 8, !alias.scope !3, !noalias !4
  call void @f_802844d84(ptr %c)
  ; @pc 0x800117698 word 0x17fffe4f
  br label %L_800116fd4
L_80011769c:
  ; @pc 0x80011769c word 0xd2800030
  ; @pc 0x8001176a0 word 0x5280008f
  ; @pc 0x8001176a4 word 0xf94f668e
  %r6775.p = getelementptr inbounds i8, ptr %c, i64 160
  %r6775 = load i64, ptr %r6775.p, align 8, !alias.scope !3, !noalias !4
  %t6776 = add i64 %r6775, 7880
  %gmp6777 = inttoptr i64 %t6776 to ptr
  %gml6778 = load i64, ptr %gmp6777, align 1, !alias.scope !4, !noalias !3
  %wp6779 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 %gml6778, ptr %wp6779, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001176a8 word 0xf2e00810
  ; @pc 0x8001176ac word 0xd2c00020
  %wp6784 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 4294967296, ptr %wp6784, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001176b0 word 0x3900237f
  %r6785 = load i64, ptr %loc_x27, align 8
  %t6786 = add i64 %r6785, 8
  %gmp6788 = inttoptr i64 %t6786 to ptr
  store i8 0, ptr %gmp6788, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001176b4 word 0xa90043ef
  %r6789 = load i64, ptr %loc_sp, align 8
  %t6790 = add i64 %r6789, 8
  %gmp6792 = inttoptr i64 %r6789 to ptr
  store i64 4, ptr %gmp6792, align 8, !alias.scope !6, !noalias !3
  %gmp6794 = inttoptr i64 %t6790 to ptr
  store i64 18014398509481985, ptr %gmp6794, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001176b8 word 0xb2607fef
  ; @pc 0x8001176bc word 0xa9023fe0
  %t6798 = add i64 %r6789, 32
  %t6799 = add i64 %t6798, 8
  %gmp6801 = inttoptr i64 %t6798 to ptr
  store i64 4294967296, ptr %gmp6801, align 8, !alias.scope !6, !noalias !3
  %gmp6803 = inttoptr i64 %t6799 to ptr
  store i64 18446744069414584320, ptr %gmp6803, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001176c0 word 0xb2087bef
  ; @pc 0x8001176c4 word 0x9100418c
  %r6806.p = getelementptr inbounds i8, ptr %c, i64 96
  %r6806 = load i64, ptr %r6806.p, align 8, !alias.scope !3, !noalias !4
  %t6807 = add i64 %r6806, 16
  ; @pc 0x8001176c8 word 0x929ffd12
  ; @pc 0x8001176cc word 0xd0015e2d
  ; @pc 0x8001176d0 word 0x9107bdad
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7549 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 34406781423, ptr %cwp7549, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001176d4 word 0xa90833ef
  %t6815 = add i64 %r6789, 128
  %t6816 = add i64 %t6815, 8
  %gmp6818 = inttoptr i64 %t6815 to ptr
  store i64 18410715276682199039, ptr %gmp6818, align 8, !alias.scope !6, !noalias !3
  %gmp6820 = inttoptr i64 %t6816 to ptr
  store i64 %t6807, ptr %gmp6820, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001176d8 word 0xd2e7f00c
  ; @pc 0x8001176dc word 0x529ffff1
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7550 = getelementptr inbounds i8, ptr %c, i64 136
  store i64 65535, ptr %cwp7550, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001176e0 word 0xf2a00012
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7551 = getelementptr inbounds i8, ptr %c, i64 144
  store i64 18446744069414584343, ptr %cwp7551, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001176e4 word 0x12800010
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7552 = getelementptr inbounds i8, ptr %c, i64 128
  store i64 4294967295, ptr %cwp7552, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001176e8 word 0xf80a430c
  %r6830.p = getelementptr inbounds i8, ptr %c, i64 192
  %r6830 = load i64, ptr %r6830.p, align 8, !alias.scope !3, !noalias !4
  %t6831 = add i64 %r6830, 164
  %gmp6833 = inttoptr i64 %t6831 to ptr
  store i64 4575657221408423936, ptr %gmp6833, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001176ec word 0xb2091bec
  ; @pc 0x8001176f0 word 0x9100414a
  %r6836.p = getelementptr inbounds i8, ptr %c, i64 80
  %r6836 = load i64, ptr %r6836.p, align 8, !alias.scope !3, !noalias !4
  %t6837 = add i64 %r6836, 16
  ; @pc 0x8001176f4 word 0xa9093feb
  %t6840 = add i64 %r6789, 144
  %t6841 = add i64 %t6840, 8
  %r6842.p = getelementptr inbounds i8, ptr %c, i64 88
  %r6842 = load i64, ptr %r6842.p, align 8, !alias.scope !3, !noalias !4
  %gmp6843 = inttoptr i64 %t6840 to ptr
  store i64 %r6842, ptr %gmp6843, align 8, !alias.scope !6, !noalias !3
  %gmp6845 = inttoptr i64 %t6841 to ptr
  store i64 18410715276682199039, ptr %gmp6845, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x8001176f8 word 0x5280006f
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7554 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 3, ptr %cwp7554, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001176fc word 0xf900037f
  %gmp6849 = inttoptr i64 %r6785 to ptr
  store i64 0, ptr %gmp6849, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117700 word 0xb900a3e8
  %t6851 = add i64 %r6789, 160
  %r6852.p = getelementptr inbounds i8, ptr %c, i64 64
  %r6852 = load i64, ptr %r6852.p, align 8, !alias.scope !3, !noalias !4
  %c6853 = trunc i64 %r6852 to i32
  %gmp6854 = inttoptr i64 %t6851 to ptr
  store i32 %c6853, ptr %gmp6854, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800117704 word 0x39402268
  %r6855.p = getelementptr inbounds i8, ptr %c, i64 152
  %r6855 = load i64, ptr %r6855.p, align 8, !alias.scope !3, !noalias !4
  %t6856 = add i64 %r6855, 8
  %gmp6857 = inttoptr i64 %t6856 to ptr
  %gml6858 = load i8, ptr %gmp6857, align 1, !alias.scope !4, !noalias !3
  %c6859 = zext i8 %gml6858 to i64
  ; @pc 0x800117708 word 0xb900bfef
  %t6862 = add i64 %r6789, 188
  %gmp6865 = inttoptr i64 %t6862 to ptr
  store i32 3, ptr %gmp6865, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x80011770c word 0xa9014bf1
  %t6867 = add i64 %r6789, 16
  %t6868 = add i64 %t6867, 8
  %gmp6870 = inttoptr i64 %t6867 to ptr
  store i64 65535, ptr %gmp6870, align 8, !alias.scope !6, !noalias !3
  %gmp6872 = inttoptr i64 %t6868 to ptr
  store i64 18446744069414584343, ptr %gmp6872, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117710 word 0xa9067fff
  %t6874 = add i64 %r6789, 96
  ; [AArch64IdiomDeconstructPass] coalesced paired 64-bit zero stores -> i128
  %stpp7555 = inttoptr i64 %t6874 to ptr
  store i128 0, ptr %stpp7555, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117714 word 0xa90333f0
  %t6879 = add i64 %r6789, 48
  %t6880 = add i64 %t6879, 8
  %gmp6882 = inttoptr i64 %t6879 to ptr
  store i64 4294967295, ptr %gmp6882, align 8, !alias.scope !6, !noalias !3
  %gmp6884 = inttoptr i64 %t6880 to ptr
  store i64 4575657222473777152, ptr %gmp6884, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117718 word 0xa9047fec
  %t6886 = add i64 %r6789, 64
  %t6887 = add i64 %t6886, 8
  %gmp6889 = inttoptr i64 %t6886 to ptr
  store i64 4575657222473777152, ptr %gmp6889, align 8, !alias.scope !6, !noalias !3
  %gmp6890 = inttoptr i64 %t6887 to ptr
  store i64 0, ptr %gmp6890, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x80011771c word 0xa9057fea
  %t6892 = add i64 %r6789, 80
  %t6893 = add i64 %t6892, 8
  %gmp6895 = inttoptr i64 %t6892 to ptr
  store i64 %t6837, ptr %gmp6895, align 8, !alias.scope !6, !noalias !3
  %gmp6896 = inttoptr i64 %t6893 to ptr
  store i64 0, ptr %gmp6896, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117720 word 0xa9072fed
  %t6898 = add i64 %r6789, 112
  %t6899 = add i64 %t6898, 8
  %gmp6901 = inttoptr i64 %t6898 to ptr
  store i64 34406781423, ptr %gmp6901, align 8, !alias.scope !6, !noalias !3
  %gmp6903 = inttoptr i64 %t6899 to ptr
  store i64 %r6842, ptr %gmp6903, align 8, !alias.scope !6, !noalias !3
  ; @pc 0x800117724 word 0xb94009ca
  %t6905 = add i64 %gml6778, 8
  %gmp6906 = inttoptr i64 %t6905 to ptr
  %gml6907 = load i32, ptr %gmp6906, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117728 word 0xf94009cb
  %t6911 = add i64 %gml6778, 16
  %gmp6912 = inttoptr i64 %t6911 to ptr
  %gml6913 = load i64, ptr %gmp6912, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011772c word 0x6b08015f
  %c6918 = trunc i64 %c6859 to i32
  ; @pc 0x800117730 word 0x52879c0a
  ; @pc 0x800117734 word 0x9a9f810c
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond6943 = icmp ugt i32 %gml6907, %c6918
  %sel6949 = select i1 %cond6943, i64 %c6859, i64 0
  ; @pc 0x800117738 word 0x9baa2d8b
  %c6952 = trunc i64 %sel6949 to i32
  %c6953 = zext i32 %c6952 to i64
  %c6955 = trunc i64 15584 to i32
  %c6956 = zext i32 %c6955 to i64
  %t6957 = mul i64 %c6953, %c6956
  %t6959 = add i64 %gml6913, %t6957
  ; @pc 0x80011773c word 0xf959b56c
  %t6962 = add i64 %t6959, 13160
  %gmp6963 = inttoptr i64 %t6962 to ptr
  %gml6964 = load i64, ptr %gmp6963, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117740 word 0xf959b16b
  %t6967 = add i64 %t6959, 13152
  %gmp6968 = inttoptr i64 %t6967 to ptr
  %gml6969 = load i64, ptr %gmp6968, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117744 word 0xa900312b
  %r6971.p = getelementptr inbounds i8, ptr %c, i64 72
  %r6971 = load i64, ptr %r6971.p, align 8, !alias.scope !3, !noalias !4
  %t6972 = add i64 %r6971, 8
  %gmp6974 = inttoptr i64 %r6971 to ptr
  store i64 %gml6969, ptr %gmp6974, align 1, !alias.scope !4, !noalias !3
  %gmp6976 = inttoptr i64 %t6972 to ptr
  store i64 %gml6964, ptr %gmp6976, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117748 word 0xb94009c9
  %t6978 = add i64 %gml6778, 8
  %gmp6979 = inttoptr i64 %t6978 to ptr
  %gml6980 = load i32, ptr %gmp6979, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011774c word 0xf94009cb
  %t6984 = add i64 %gml6778, 16
  %gmp6985 = inttoptr i64 %t6984 to ptr
  %gml6986 = load i64, ptr %gmp6985, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117750 word 0x6b08013f
  ; @pc 0x800117754 word 0x9a9f8108
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond7014 = icmp ugt i32 %gml6980, %c6918
  %sel7020 = select i1 %cond7014, i64 %c6859, i64 0
  ; @pc 0x800117758 word 0x9baa2d08
  %c7023 = trunc i64 %sel7020 to i32
  %c7024 = zext i32 %c7023 to i64
  %c7027 = zext i32 %c6955 to i64
  %t7028 = mul i64 %c7024, %c7027
  %t7030 = add i64 %gml6986, %t7028
  ; @pc 0x80011775c word 0xf95af509
  %t7033 = add i64 %t7030, 13800
  %gmp7034 = inttoptr i64 %t7033 to ptr
  %gml7035 = load i64, ptr %gmp7034, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117760 word 0xf95af10a
  %t7038 = add i64 %t7030, 13792
  %gmp7039 = inttoptr i64 %t7038 to ptr
  %gml7040 = load i64, ptr %gmp7039, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117764 word 0xa900274a
  %r7042.p = getelementptr inbounds i8, ptr %c, i64 208
  %r7042 = load i64, ptr %r7042.p, align 8, !alias.scope !3, !noalias !4
  %t7043 = add i64 %r7042, 8
  %gmp7045 = inttoptr i64 %r7042 to ptr
  store i64 %gml7040, ptr %gmp7045, align 1, !alias.scope !4, !noalias !3
  %gmp7047 = inttoptr i64 %t7043 to ptr
  store i64 %gml7035, ptr %gmp7047, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117768 word 0xb975f909
  %t7049 = add i64 %t7030, 13816
  %gmp7050 = inttoptr i64 %t7049 to ptr
  %gml7051 = load i32, ptr %gmp7050, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011776c word 0xf95af908
  %t7055 = add i64 %t7030, 13808
  %gmp7056 = inttoptr i64 %t7055 to ptr
  %gml7057 = load i64, ptr %gmp7056, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117770 word 0xf9000328
  %r7059.p = getelementptr inbounds i8, ptr %c, i64 200
  %r7059 = load i64, ptr %r7059.p, align 8, !alias.scope !3, !noalias !4
  %gmp7061 = inttoptr i64 %r7059 to ptr
  store i64 %gml7057, ptr %gmp7061, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117774 word 0xb9000b29
  %t7063 = add i64 %r7059, 8
  %gmp7066 = inttoptr i64 %t7063 to ptr
  store i32 %gml7051, ptr %gmp7066, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117778 word 0xb94045c8
  %t7068 = add i64 %gml6778, 68
  %gmp7069 = inttoptr i64 %t7068 to ptr
  %gml7070 = load i32, ptr %gmp7069, align 1, !alias.scope !4, !noalias !3
  %c7071 = zext i32 %gml7070 to i64
  %wp7072 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %c7071, ptr %wp7072, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011777c word 0xb9403dc9
  %t7074 = add i64 %gml6778, 60
  %gmp7075 = inttoptr i64 %t7074 to ptr
  %gml7076 = load i32, ptr %gmp7075, align 1, !alias.scope !4, !noalias !3
  %c7077 = zext i32 %gml7076 to i64
  %wp7078 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %c7077, ptr %wp7078, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117780 word 0x17ffff32
  br label %L_800117448
L_800117784:
  ; @pc 0x800117784 word 0x912ba280
  %r7079.p = getelementptr inbounds i8, ptr %c, i64 160
  %r7079 = load i64, ptr %r7079.p, align 8, !alias.scope !3, !noalias !4
  %t7080 = add i64 %r7079, 2792
  %wp7081 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 %t7080, ptr %wp7081, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117788 word 0x910003e1
  %r7082 = load i64, ptr %loc_sp, align 8
  %t7083 = add i64 %r7082, 0
  %wp7084 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %t7083, ptr %wp7084, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011778c word 0xaa1303e2
  %r7085.p = getelementptr inbounds i8, ptr %c, i64 152
  %r7085 = load i64, ptr %r7085.p, align 8, !alias.scope !3, !noalias !4
  %wp7087 = getelementptr inbounds i8, ptr %c, i64 16
  store i64 %r7085, ptr %wp7087, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117790 word 0x949cf979
  %wp7088 = getelementptr inbounds i8, ptr %c, i64 240
  store i64 34360883092, ptr %wp7088, align 8, !alias.scope !3, !noalias !4
  call void @f_802855d74(ptr %c)
  ; @pc 0x800117794 word 0x17fffe10
  br label %L_800116fd4
L_800117798:
  ; @pc 0x800117798 word 0x52800068
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7557 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 3, ptr %cwp7557, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011779c word 0x17fffaa3
  br label %L_800116228
L_8001177a0:
  ; @pc 0x8001177a0 word 0x39430129
  %r7091.p = getelementptr inbounds i8, ptr %c, i64 72
  %r7091 = load i64, ptr %r7091.p, align 8, !alias.scope !3, !noalias !4
  %t7092 = add i64 %r7091, 192
  %gmp7093 = inttoptr i64 %t7092 to ptr
  %gml7094 = load i8, ptr %gmp7093, align 1, !alias.scope !4, !noalias !3
  %c7095 = zext i8 %gml7094 to i64
  %wp7096 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %c7095, ptr %wp7096, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001177a4 word 0x17fffed9
  br label %L_800117308
L_8001177a8:
  ; @pc 0x8001177a8 word 0x39430129
  %r7097.p = getelementptr inbounds i8, ptr %c, i64 72
  %r7097 = load i64, ptr %r7097.p, align 8, !alias.scope !3, !noalias !4
  %t7098 = add i64 %r7097, 192
  %gmp7099 = inttoptr i64 %t7098 to ptr
  %gml7100 = load i8, ptr %gmp7099, align 1, !alias.scope !4, !noalias !3
  %c7101 = zext i8 %gml7100 to i64
  %wp7102 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %c7101, ptr %wp7102, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001177ac word 0x17fffeda
  br label %L_800117314
L_8001177b0:
  ; @pc 0x8001177b0 word 0x39430129
  %r7103.p = getelementptr inbounds i8, ptr %c, i64 72
  %r7103 = load i64, ptr %r7103.p, align 8, !alias.scope !3, !noalias !4
  %t7104 = add i64 %r7103, 192
  %gmp7105 = inttoptr i64 %t7104 to ptr
  %gml7106 = load i8, ptr %gmp7105, align 1, !alias.scope !4, !noalias !3
  %c7107 = zext i8 %gml7106 to i64
  %wp7108 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %c7107, ptr %wp7108, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001177b4 word 0x17fffedb
  br label %L_800117320
L_8001177b8:
  ; @pc 0x8001177b8 word 0x39430129
  %r7109.p = getelementptr inbounds i8, ptr %c, i64 72
  %r7109 = load i64, ptr %r7109.p, align 8, !alias.scope !3, !noalias !4
  %t7110 = add i64 %r7109, 192
  %gmp7111 = inttoptr i64 %t7110 to ptr
  %gml7112 = load i8, ptr %gmp7111, align 1, !alias.scope !4, !noalias !3
  %c7113 = zext i8 %gml7112 to i64
  %wp7114 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %c7113, ptr %wp7114, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001177bc word 0x17fffedc
  br label %L_80011732c
L_8001177c0:
  ; @pc 0x8001177c0 word 0x39430129
  %r7115.p = getelementptr inbounds i8, ptr %c, i64 72
  %r7115 = load i64, ptr %r7115.p, align 8, !alias.scope !3, !noalias !4
  %t7116 = add i64 %r7115, 192
  %gmp7117 = inttoptr i64 %t7116 to ptr
  %gml7118 = load i8, ptr %gmp7117, align 1, !alias.scope !4, !noalias !3
  %c7119 = zext i8 %gml7118 to i64
  %wp7120 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %c7119, ptr %wp7120, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001177c4 word 0x17fffedd
  br label %L_800117338
L_8001177c8:
  ; @pc 0x8001177c8 word 0x39430129
  %r7121.p = getelementptr inbounds i8, ptr %c, i64 72
  %r7121 = load i64, ptr %r7121.p, align 8, !alias.scope !3, !noalias !4
  %t7122 = add i64 %r7121, 192
  %gmp7123 = inttoptr i64 %t7122 to ptr
  %gml7124 = load i8, ptr %gmp7123, align 1, !alias.scope !4, !noalias !3
  %c7125 = zext i8 %gml7124 to i64
  %wp7126 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %c7125, ptr %wp7126, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001177cc word 0x17fffede
  br label %L_800117344
L_8001177d0:
  ; @pc 0x8001177d0 word 0x39430129
  %r7127.p = getelementptr inbounds i8, ptr %c, i64 72
  %r7127 = load i64, ptr %r7127.p, align 8, !alias.scope !3, !noalias !4
  %t7128 = add i64 %r7127, 192
  %gmp7129 = inttoptr i64 %t7128 to ptr
  %gml7130 = load i8, ptr %gmp7129, align 1, !alias.scope !4, !noalias !3
  %c7131 = zext i8 %gml7130 to i64
  %wp7132 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %c7131, ptr %wp7132, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001177d4 word 0x17fffedf
  br label %L_800117350
L_80011620c_ft:
  ; @pc 0x80011620c word 0x528fa3e8
  ; @pc 0x800116210 word 0x72bed868
  ; @pc 0x800116214 word 0x1ad52508
  %c102 = trunc i64 4140006687 to i32
  %r103.p = getelementptr inbounds i8, ptr %c, i64 168
  %r103 = load i64, ptr %r103.p, align 8, !alias.scope !3, !noalias !4
  %c104 = trunc i64 %r103 to i32
  %t105 = and i32 %c104, 31
  %t106 = lshr i32 %c102, %t105
  %c107 = zext i32 %t106 to i64
  ; @pc 0x800116218 word 0x370013a8
  %t110 = and i64 %c107, 1
  %cmp111 = icmp ne i64 %t110, 0
  br i1 %cmp111, label %L_80011648c, label %L_80011621c
L_800116224_ft:
  ; @pc 0x800116224 word 0xaa1f03e8
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7560 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 0, ptr %cwp7560, align 8, !alias.scope !3, !noalias !4
  br label %L_800116228
L_8001162ec_ft:
  ; @pc 0x8001162ec word 0xd00162b1
  ; @pc 0x8001162f0 word 0x91250231
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7561 = getelementptr inbounds i8, ptr %c, i64 136
  store i64 34407369024, ptr %cwp7561, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001162f4 word 0x2a1503f2
  %r375.p = getelementptr inbounds i8, ptr %c, i64 168
  %r375 = load i64, ptr %r375.p, align 8, !alias.scope !3, !noalias !4
  %c376 = trunc i64 %r375 to i32
  %c378 = zext i32 %c376 to i64
  %wp379 = getelementptr inbounds i8, ptr %c, i64 144
  store i64 %c378, ptr %wp379, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001162f8 word 0x910003f0
  %r380 = load i64, ptr %loc_sp, align 8
  %t381 = add i64 %r380, 0
  %wp382 = getelementptr inbounds i8, ptr %c, i64 128
  store i64 %t381, ptr %wp382, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001162fc word 0x10000100
  ; @pc 0x800116300 word 0x78727a21
  %t386 = shl i64 %c378, 1
  %t387 = add i64 34407369024, %t386
  %gmp388 = inttoptr i64 %t387 to ptr
  %gml389 = load i16, ptr %gmp388, align 1, !alias.scope !4, !noalias !3
  %c390 = zext i16 %gml389 to i64
  %wp391 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %c390, ptr %wp391, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116304 word 0x8b010800
  %t394 = shl i64 %c390, 2
  %t395 = add i64 34360877852, %t394
  %wp396 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 %t395, ptr %wp396, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116308 word 0x9101e209
  %t398 = add i64 %t381, 120
  %wp399 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %t398, ptr %wp399, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011630c word 0x9102421a
  %t401 = add i64 %t381, 144
  %wp402 = getelementptr inbounds i8, ptr %c, i64 208
  store i64 %t401, ptr %wp402, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116310 word 0x91028219
  %t404 = add i64 %t381, 160
  %wp405 = getelementptr inbounds i8, ptr %c, i64 200
  store i64 %t404, ptr %wp405, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116314 word 0x9102c21b
  %t407 = add i64 %t381, 176
  %wp408 = getelementptr inbounds i8, ptr %c, i64 216
  store i64 %t407, ptr %wp408, align 8, !alias.scope !3, !noalias !4
  store i64 %t407, ptr %loc_x27, align 8
  ; @pc 0x800116318 word 0xd61f0000
  switch i64 %t395, label %L_800116318_jt_def [
  i64 34360877852, label %L_80011631c
  i64 34360877856, label %L_800116320
  i64 34360877860, label %L_800116324
  i64 34360877868, label %L_80011632c
  i64 34360878240, label %L_8001164a0
  i64 34360878300, label %L_8001164dc
  i64 34360878364, label %L_80011651c
  i64 34360878656, label %L_800116640
  i64 34360878720, label %L_800116680
  i64 34360879060, label %L_8001167d4
  i64 34360879284, label %L_8001168b4
  i64 34360879588, label %L_8001169e4
  i64 34360879612, label %L_8001169fc
  i64 34360879676, label %L_800116a3c
  i64 34360879960, label %L_800116b58
  i64 34360880228, label %L_800116c64
  i64 34360880288, label %L_800116ca0
  i64 34360880440, label %L_800116d38
  i64 34360880504, label %L_800116d78
  i64 34360880628, label %L_800116df4
  i64 34360880688, label %L_800116e30
  i64 34360880752, label %L_800116e70
  i64 34360880872, label %L_800116ee8
  i64 34360881616, label %L_8001171d0
  i64 34360882020, label %L_800117364
  i64 34360882388, label %L_8001174d4
  i64 34360882404, label %L_8001174e4
  i64 34360882420, label %L_8001174f4
  i64 34360882436, label %L_800117504
  i64 34360882756, label %L_800117644
  i64 34360882784, label %L_800117660
  i64 34360882820, label %L_800117684
  i64 34360882844, label %L_80011769c
  i64 34360883076, label %L_800117784
  ]
  ret void
L_800116bd8_ft:
  ; @pc 0x800116bd8 word 0x3940226a
  %r3317.p = getelementptr inbounds i8, ptr %c, i64 152
  %r3317 = load i64, ptr %r3317.p, align 8, !alias.scope !3, !noalias !4
  %t3318 = add i64 %r3317, 8
  %gmp3319 = inttoptr i64 %t3318 to ptr
  %gml3320 = load i8, ptr %gmp3319, align 1, !alias.scope !4, !noalias !3
  %c3321 = zext i8 %gml3320 to i64
  ; @pc 0x800116bdc word 0x5281ec0c
  ; @pc 0x800116be0 word 0x52879c0d
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7563 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 15584, ptr %cwp7563, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800116be4 word 0xb940110b
  %r3327.p = getelementptr inbounds i8, ptr %c, i64 64
  %r3327 = load i64, ptr %r3327.p, align 8, !alias.scope !3, !noalias !4
  %t3328 = add i64 %r3327, 16
  %gmp3329 = inttoptr i64 %t3328 to ptr
  %gml3330 = load i32, ptr %gmp3329, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116be8 word 0x6b0a017f
  %c3336 = trunc i64 %c3321 to i32
  ; @pc 0x800116bec word 0xf9400d08
  %t3358 = add i64 %r3327, 24
  %gmp3359 = inttoptr i64 %t3358 to ptr
  %gml3360 = load i64, ptr %gmp3359, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116bf0 word 0x9a9f814b
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond3364 = icmp ugt i32 %gml3330, %c3336
  %sel3370 = select i1 %cond3364, i64 %c3321, i64 0
  ; @pc 0x800116bf4 word 0x9bac2168
  %c3373 = trunc i64 %sel3370 to i32
  %c3374 = zext i32 %c3373 to i64
  %c3376 = trunc i64 3936 to i32
  %c3377 = zext i32 %c3376 to i64
  %t3378 = mul i64 %c3374, %c3377
  %t3380 = add i64 %gml3360, %t3378
  ; @pc 0x800116bf8 word 0xb9429d08
  %t3383 = add i64 %t3380, 668
  %gmp3384 = inttoptr i64 %t3383 to ptr
  %gml3385 = load i32, ptr %gmp3384, align 1, !alias.scope !4, !noalias !3
  %c3386 = zext i32 %gml3385 to i64
  ; @pc 0x800116bfc word 0xb2600108
  %t3389 = or i64 %c3386, 4294967296
  ; @pc 0x800116c00 word 0xf801c3e8
  %r3391 = load i64, ptr %loc_sp, align 8
  %t3392 = add i64 %r3391, 28
  %gmp3394 = inttoptr i64 %t3392 to ptr
  store i64 %t3389, ptr %gmp3394, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116c04 word 0x52800048
  ; @pc 0x800116c08 word 0xb900bfe8
  %t3398 = add i64 %r3391, 188
  %gmp3401 = inttoptr i64 %t3398 to ptr
  store i32 2, ptr %gmp3401, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800116c0c word 0xf94f6688
  %r3402.p = getelementptr inbounds i8, ptr %c, i64 160
  %r3402 = load i64, ptr %r3402.p, align 8, !alias.scope !3, !noalias !4
  %t3403 = add i64 %r3402, 7880
  %gmp3404 = inttoptr i64 %t3403 to ptr
  %gml3405 = load i64, ptr %gmp3404, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116c10 word 0xb940090b
  %t3408 = add i64 %gml3405, 8
  %gmp3409 = inttoptr i64 %t3408 to ptr
  %gml3410 = load i32, ptr %gmp3409, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116c14 word 0xf940090c
  %t3414 = add i64 %gml3405, 16
  %gmp3415 = inttoptr i64 %t3414 to ptr
  %gml3416 = load i64, ptr %gmp3415, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116c18 word 0x6b0a017f
  ; @pc 0x800116c1c word 0x9a9f814b
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond3444 = icmp ugt i32 %gml3410, %c3336
  %sel3450 = select i1 %cond3444, i64 %c3321, i64 0
  ; @pc 0x800116c20 word 0x9bad316b
  %c3453 = trunc i64 %sel3450 to i32
  %c3454 = zext i32 %c3453 to i64
  %c3456 = trunc i64 15584 to i32
  %c3457 = zext i32 %c3456 to i64
  %t3458 = mul i64 %c3454, %c3457
  %t3460 = add i64 %gml3416, %t3458
  ; @pc 0x800116c24 word 0xf9585d6c
  %t3463 = add i64 %t3460, 12472
  %gmp3464 = inttoptr i64 %t3463 to ptr
  %gml3465 = load i64, ptr %gmp3464, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116c28 word 0xf958596b
  %t3468 = add i64 %t3460, 12464
  %gmp3469 = inttoptr i64 %t3468 to ptr
  %gml3470 = load i64, ptr %gmp3469, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116c2c word 0xa900312b
  %r3472.p = getelementptr inbounds i8, ptr %c, i64 72
  %r3472 = load i64, ptr %r3472.p, align 8, !alias.scope !3, !noalias !4
  %t3473 = add i64 %r3472, 8
  %gmp3475 = inttoptr i64 %r3472 to ptr
  store i64 %gml3470, ptr %gmp3475, align 1, !alias.scope !4, !noalias !3
  %gmp3477 = inttoptr i64 %t3473 to ptr
  store i64 %gml3465, ptr %gmp3477, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116c30 word 0xb9400909
  %t3479 = add i64 %gml3405, 8
  %gmp3480 = inttoptr i64 %t3479 to ptr
  %gml3481 = load i32, ptr %gmp3480, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116c34 word 0xf9400908
  %t3485 = add i64 %gml3405, 16
  %gmp3486 = inttoptr i64 %t3485 to ptr
  %gml3487 = load i64, ptr %gmp3486, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116c38 word 0x6b0a013f
  ; @pc 0x800116c3c word 0x9a9f8149
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond3515 = icmp ugt i32 %gml3481, %c3336
  %sel3521 = select i1 %cond3515, i64 %c3321, i64 0
  ; @pc 0x800116c40 word 0x9bad2128
  %c3524 = trunc i64 %sel3521 to i32
  %c3525 = zext i32 %c3524 to i64
  %c3528 = zext i32 %c3456 to i64
  %t3529 = mul i64 %c3525, %c3528
  %t3531 = add i64 %gml3487, %t3529
  ; @pc 0x800116c44 word 0xf9599d09
  %t3534 = add i64 %t3531, 13112
  %gmp3535 = inttoptr i64 %t3534 to ptr
  %gml3536 = load i64, ptr %gmp3535, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116c48 word 0xf959990a
  %t3539 = add i64 %t3531, 13104
  %gmp3540 = inttoptr i64 %t3539 to ptr
  %gml3541 = load i64, ptr %gmp3540, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116c4c word 0xa900274a
  %r3543.p = getelementptr inbounds i8, ptr %c, i64 208
  %r3543 = load i64, ptr %r3543.p, align 8, !alias.scope !3, !noalias !4
  %t3544 = add i64 %r3543, 8
  %gmp3546 = inttoptr i64 %r3543 to ptr
  store i64 %gml3541, ptr %gmp3546, align 1, !alias.scope !4, !noalias !3
  %gmp3548 = inttoptr i64 %t3544 to ptr
  store i64 %gml3536, ptr %gmp3548, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116c50 word 0xb9734909
  %t3550 = add i64 %t3531, 13128
  %gmp3551 = inttoptr i64 %t3550 to ptr
  %gml3552 = load i32, ptr %gmp3551, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116c54 word 0xf959a108
  %t3556 = add i64 %t3531, 13120
  %gmp3557 = inttoptr i64 %t3556 to ptr
  %gml3558 = load i64, ptr %gmp3557, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116c58 word 0xf9000328
  %r3560.p = getelementptr inbounds i8, ptr %c, i64 200
  %r3560 = load i64, ptr %r3560.p, align 8, !alias.scope !3, !noalias !4
  %gmp3562 = inttoptr i64 %r3560 to ptr
  store i64 %gml3558, ptr %gmp3562, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116c5c word 0xb9000b29
  %t3564 = add i64 %r3560, 8
  %gmp3567 = inttoptr i64 %t3564 to ptr
  store i32 %gml3552, ptr %gmp3567, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800116c60 word 0x140000dd
  br label %L_800116fd4
L_800117004_ft:
  ; @pc 0x800117004 word 0x91050298
  %r4542.p = getelementptr inbounds i8, ptr %c, i64 160
  %r4542 = load i64, ptr %r4542.p, align 8, !alias.scope !3, !noalias !4
  %t4543 = add i64 %r4542, 320
  %wp4544 = getelementptr inbounds i8, ptr %c, i64 192
  store i64 %t4543, ptr %wp4544, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117008 word 0x93407eb9
  %r4545.p = getelementptr inbounds i8, ptr %c, i64 168
  %r4545 = load i64, ptr %r4545.p, align 8, !alias.scope !3, !noalias !4
  %t4546 = lshr i64 %r4545, 31
  %t4547 = and i64 %t4546, 1
  %t4548 = sub i64 0, %t4547
  %t4549 = and i64 %t4548, -4294967296
  %t4550 = and i64 %r4545, 4294967295
  %t4551 = or i64 %t4549, %t4550
  %wp4552 = getelementptr inbounds i8, ptr %c, i64 200
  store i64 %t4551, ptr %wp4552, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011700c word 0x38796b0b
  %t4555 = add i64 %t4543, %t4551
  %gmp4556 = inttoptr i64 %t4555 to ptr
  %gml4557 = load i8, ptr %gmp4556, align 1, !alias.scope !4, !noalias !3
  %c4558 = zext i8 %gml4557 to i64
  %wp4559 = getelementptr inbounds i8, ptr %c, i64 88
  store i64 %c4558, ptr %wp4559, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117010 word 0x36000cab
  %t4561 = and i64 %c4558, 1
  %cmp4562 = icmp eq i64 %t4561, 0
  br i1 %cmp4562, label %L_8001171a4, label %L_800117014_ft
L_800117014_ft:
  ; @pc 0x800117014 word 0x394033eb
  %r4563 = load i64, ptr %loc_sp, align 8
  %t4564 = add i64 %r4563, 12
  %gmp4565 = inttoptr i64 %t4564 to ptr
  %gml4566 = load i8, ptr %gmp4565, align 1, !alias.scope !6, !noalias !3
  %c4567 = zext i8 %gml4566 to i64
  %wp4568 = getelementptr inbounds i8, ptr %c, i64 88
  store i64 %c4567, ptr %wp4568, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117018 word 0x37000d6b
  %t4570 = and i64 %c4567, 1
  %cmp4571 = icmp ne i64 %t4570, 0
  br i1 %cmp4571, label %L_8001171c4, label %L_80011701c
L_800117050_ft:
  ; @pc 0x800117050 word 0x38796b08
  %r4625.p = getelementptr inbounds i8, ptr %c, i64 192
  %r4625 = load i64, ptr %r4625.p, align 8, !alias.scope !3, !noalias !4
  %r4626.p = getelementptr inbounds i8, ptr %c, i64 200
  %r4626 = load i64, ptr %r4626.p, align 8, !alias.scope !3, !noalias !4
  %t4627 = add i64 %r4625, %r4626
  %gmp4628 = inttoptr i64 %t4627 to ptr
  %gml4629 = load i8, ptr %gmp4628, align 1, !alias.scope !4, !noalias !3
  %c4630 = zext i8 %gml4629 to i64
  %wp4631 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %c4630, ptr %wp4631, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117054 word 0x36080a88
  %t4633 = and i64 %c4630, 2
  %cmp4634 = icmp eq i64 %t4633, 0
  br i1 %cmp4634, label %L_8001171a4, label %L_800117058_ft
L_800117058_ft:
  ; @pc 0x800117058 word 0xf95db288
  %r4635.p = getelementptr inbounds i8, ptr %c, i64 160
  %r4635 = load i64, ptr %r4635.p, align 8, !alias.scope !3, !noalias !4
  %t4636 = add i64 %r4635, 15200
  %gmp4637 = inttoptr i64 %t4636 to ptr
  %gml4638 = load i64, ptr %gmp4637, align 1, !alias.scope !4, !noalias !3
  %wp4639 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %gml4638, ptr %wp4639, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011705c word 0xb4000a48
  %cmp4641 = icmp eq i64 %gml4638, 0
  br i1 %cmp4641, label %L_8001171a4, label %L_800117060_ft
L_800117060_ft:
  ; @pc 0x800117060 word 0x528750a8
  ; @pc 0x800117064 word 0x38686a88
  %r4644.p = getelementptr inbounds i8, ptr %c, i64 160
  %r4644 = load i64, ptr %r4644.p, align 8, !alias.scope !3, !noalias !4
  %t4646 = add i64 %r4644, 14981
  %gmp4647 = inttoptr i64 %t4646 to ptr
  %gml4648 = load i8, ptr %gmp4647, align 1, !alias.scope !4, !noalias !3
  %c4649 = zext i8 %gml4648 to i64
  %wp4650 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %c4649, ptr %wp4650, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117068 word 0x360809e8
  %t4652 = and i64 %c4649, 2
  %cmp4653 = icmp eq i64 %t4652, 0
  br i1 %cmp4653, label %L_8001171a4, label %L_80011706c_ft
L_80011706c_ft:
  ; @pc 0x80011706c word 0xb94002a8
  %r4654.p = getelementptr inbounds i8, ptr %c, i64 168
  %r4654 = load i64, ptr %r4654.p, align 8, !alias.scope !3, !noalias !4
  %gmp4655 = inttoptr i64 %r4654 to ptr
  %gml4656 = load i32, ptr %gmp4655, align 1, !alias.scope !4, !noalias !3
  %c4657 = zext i32 %gml4656 to i64
  %wp4658 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %c4657, ptr %wp4658, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117070 word 0xb94012e9
  %r4659.p = getelementptr inbounds i8, ptr %c, i64 184
  %r4659 = load i64, ptr %r4659.p, align 8, !alias.scope !3, !noalias !4
  %t4660 = add i64 %r4659, 16
  %gmp4661 = inttoptr i64 %t4660 to ptr
  %gml4662 = load i32, ptr %gmp4661, align 1, !alias.scope !4, !noalias !3
  %c4663 = zext i32 %gml4662 to i64
  %wp4664 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %c4663, ptr %wp4664, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117074 word 0x6a29011f
  %t4667 = xor i32 %gml4662, -1
  %t4670 = and i32 %gml4656, %t4667
  ; @pc 0x800117078 word 0x54000961
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond4680 = icmp ne i32 %t4670, 0
  br i1 %cond4680, label %L_8001171a4, label %L_80011707c_ft
L_80011707c_ft:
  ; @pc 0x80011707c word 0xb94002c8
  %r4683.p = getelementptr inbounds i8, ptr %c, i64 176
  %r4683 = load i64, ptr %r4683.p, align 8, !alias.scope !3, !noalias !4
  %gmp4684 = inttoptr i64 %r4683 to ptr
  %gml4685 = load i32, ptr %gmp4684, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117080 word 0xb97b9289
  %r4688.p = getelementptr inbounds i8, ptr %c, i64 160
  %r4688 = load i64, ptr %r4688.p, align 8, !alias.scope !3, !noalias !4
  %t4689 = add i64 %r4688, 15248
  %gmp4690 = inttoptr i64 %t4689 to ptr
  %gml4691 = load i32, ptr %gmp4690, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117084 word 0x1ac90908
  %cmp4698 = icmp eq i32 %gml4691, 0
  %sel4699 = select i1 %cmp4698, i32 1, i32 %gml4691
  %t4700 = udiv i32 %gml4685, %sel4699
  %sel4701 = select i1 %cmp4698, i32 0, i32 %t4700
  ; @pc 0x800117088 word 0xb97b9689
  %t4705 = add i64 %r4688, 15252
  %gmp4706 = inttoptr i64 %t4705 to ptr
  %gml4707 = load i32, ptr %gmp4706, align 1, !alias.scope !4, !noalias !3
  %c4708 = zext i32 %gml4707 to i64
  %wp4709 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %c4708, ptr %wp4709, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011708c word 0x6b09011f
  ; @pc 0x800117090 word 0x1a89b108
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond4739 = icmp slt i32 %sel4701, %gml4707
  %sel4744 = select i1 %cond4739, i32 %sel4701, i32 %gml4707
  %c4745 = zext i32 %sel4744 to i64
  %wp4746 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %c4745, ptr %wp4746, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117094 word 0x34000888
  %cmp4749 = icmp eq i32 %sel4744, 0
  br i1 %cmp4749, label %L_8001171a4, label %L_800117098_ft
L_800117098_ft:
  ; @pc 0x800117098 word 0xb94002d1
  %r4750.p = getelementptr inbounds i8, ptr %c, i64 176
  %r4750 = load i64, ptr %r4750.p, align 8, !alias.scope !3, !noalias !4
  %gmp4751 = inttoptr i64 %r4750 to ptr
  %gml4752 = load i32, ptr %gmp4751, align 1, !alias.scope !4, !noalias !3
  %c4753 = zext i32 %gml4752 to i64
  %wp4754 = getelementptr inbounds i8, ptr %c, i64 136
  store i64 %c4753, ptr %wp4754, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011709c word 0x71000509
  %r4755.p = getelementptr inbounds i8, ptr %c, i64 64
  %r4755 = load i64, ptr %r4755.p, align 8, !alias.scope !3, !noalias !4
  %c4756 = trunc i64 %r4755 to i32
  %t4757 = sub i32 %c4756, 1
  %c4777 = zext i32 %t4757 to i64
  %wp4778 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %c4777, ptr %wp4778, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001170a0 word 0xb94002cc
  %gmp4780 = inttoptr i64 %r4750 to ptr
  %gml4781 = load i32, ptr %gmp4780, align 1, !alias.scope !4, !noalias !3
  %c4782 = zext i32 %gml4781 to i64
  %wp4783 = getelementptr inbounds i8, ptr %c, i64 96
  store i64 %c4782, ptr %wp4783, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001170a4 word 0x5400080b
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond4785 = icmp slt i32 %c4756, 1
  br i1 %cond4785, label %L_8001171a4, label %L_8001170a8_ft
L_8001170a8_ft:
  ; @pc 0x8001170a8 word 0x1ac80d8d
  %r4790.p = getelementptr inbounds i8, ptr %c, i64 96
  %r4790 = load i64, ptr %r4790.p, align 8, !alias.scope !3, !noalias !4
  %c4791 = trunc i64 %r4790 to i32
  %r4792.p = getelementptr inbounds i8, ptr %c, i64 64
  %r4792 = load i64, ptr %r4792.p, align 8, !alias.scope !3, !noalias !4
  %c4793 = trunc i64 %r4792 to i32
  %cmp4794 = icmp eq i32 %c4793, 0
  %cmp4795 = icmp eq i32 %c4793, -1
  %cmp4796 = icmp eq i32 %c4791, -2147483648
  %t4797 = and i1 %cmp4796, %cmp4795
  %t4798 = or i1 %cmp4794, %t4797
  %sel4799 = select i1 %t4798, i32 1, i32 %c4793
  %t4800 = sdiv i32 %c4791, %sel4799
  %sel4801 = select i1 %t4797, i32 %c4791, i32 %t4800
  %sel4802 = select i1 %cmp4794, i32 0, i32 %sel4801
  ; @pc 0x8001170ac word 0x5287700e
  ; @pc 0x8001170b0 word 0x2a1f03ea
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7567 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 0, ptr %cwp7567, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001170b4 word 0x2a1f03eb
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7568 = getelementptr inbounds i8, ptr %c, i64 88
  store i64 0, ptr %cwp7568, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001170b8 word 0x8b0e028e
  %r4813.p = getelementptr inbounds i8, ptr %c, i64 160
  %r4813 = load i64, ptr %r4813.p, align 8, !alias.scope !3, !noalias !4
  %t4815 = add i64 %r4813, 15232
  %wp4816 = getelementptr inbounds i8, ptr %c, i64 112
  store i64 %t4815, ptr %wp4816, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001170bc word 0x5280050f
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7569 = getelementptr inbounds i8, ptr %c, i64 120
  store i64 40, ptr %cwp7569, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001170c0 word 0x529999b0
  ; @pc 0x8001170c4 word 0x72a7b990
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7571 = getelementptr inbounds i8, ptr %c, i64 128
  store i64 1036831949, ptr %cwp7571, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001170c8 word 0x1b08b1ac
  %t4831 = mul i32 %sel4802, %c4793
  %t4834 = sub i32 %c4791, %t4831
  %c4835 = zext i32 %t4834 to i64
  %wp4836 = getelementptr inbounds i8, ptr %c, i64 96
  store i64 %c4835, ptr %wp4836, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001170cc word 0x52876f0d
  ; @pc 0x8001170d0 word 0x8b0d028d
  %t4841 = add i64 %r4813, 15224
  %wp4842 = getelementptr inbounds i8, ptr %c, i64 104
  store i64 %t4841, ptr %wp4842, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001170d4 word 0x1ac80e31
  %r4843.p = getelementptr inbounds i8, ptr %c, i64 136
  %r4843 = load i64, ptr %r4843.p, align 8, !alias.scope !3, !noalias !4
  %c4844 = trunc i64 %r4843 to i32
  %cmp4847 = icmp eq i32 %c4793, 0
  %cmp4848 = icmp eq i32 %c4793, -1
  %cmp4849 = icmp eq i32 %c4844, -2147483648
  %t4850 = and i1 %cmp4849, %cmp4848
  %t4851 = or i1 %cmp4847, %t4850
  %sel4852 = select i1 %t4851, i32 1, i32 %c4793
  %t4853 = sdiv i32 %c4844, %sel4852
  %sel4854 = select i1 %t4850, i32 %c4844, i32 %t4853
  %sel4855 = select i1 %cmp4847, i32 0, i32 %sel4854
  %c4856 = zext i32 %sel4855 to i64
  %wp4857 = getelementptr inbounds i8, ptr %c, i64 136
  store i64 %c4856, ptr %wp4857, align 8, !alias.scope !3, !noalias !4
  br label %L_8001170d8
L_8001170e8_ft:
  ; @pc 0x8001170e8 word 0xb97b6a81
  %r4890.p = getelementptr inbounds i8, ptr %c, i64 160
  %r4890 = load i64, ptr %r4890.p, align 8, !alias.scope !3, !noalias !4
  %t4891 = add i64 %r4890, 15208
  %gmp4892 = inttoptr i64 %t4891 to ptr
  %gml4893 = load i32, ptr %gmp4892, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001170ec word 0x6b09015f
  %r4896.p = getelementptr inbounds i8, ptr %c, i64 80
  %r4896 = load i64, ptr %r4896.p, align 8, !alias.scope !3, !noalias !4
  %c4897 = trunc i64 %r4896 to i32
  %r4898.p = getelementptr inbounds i8, ptr %c, i64 72
  %r4898 = load i64, ptr %r4898.p, align 8, !alias.scope !3, !noalias !4
  %c4899 = trunc i64 %r4898 to i32
  ; @pc 0x8001170f0 word 0x1a9f0182
  %r4920.p = getelementptr inbounds i8, ptr %c, i64 96
  %r4920 = load i64, ptr %r4920.p, align 8, !alias.scope !3, !noalias !4
  %c4921 = trunc i64 %r4920 to i32
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond4923 = icmp eq i32 %c4897, %c4899
  %sel4925 = select i1 %cond4923, i32 %c4921, i32 0
  %c4926 = zext i32 %sel4925 to i64
  %wp4927 = getelementptr inbounds i8, ptr %c, i64 16
  store i64 %c4926, ptr %wp4927, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001170f4 word 0xf95dba80
  %t4929 = add i64 %r4890, 15216
  %gmp4930 = inttoptr i64 %t4929 to ptr
  %gml4931 = load i64, ptr %gmp4930, align 1, !alias.scope !4, !noalias !3
  %wp4932 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 %gml4931, ptr %wp4932, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001170f8 word 0x6b12003f
  %r4935.p = getelementptr inbounds i8, ptr %c, i64 144
  %r4935 = load i64, ptr %r4935.p, align 8, !alias.scope !3, !noalias !4
  %c4936 = trunc i64 %r4935 to i32
  ; @pc 0x8001170fc word 0x54001e89
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond4958 = icmp ule i32 %gml4893, %c4936
  br i1 %cond4958, label %L_8001174cc, label %L_800117100_ft
L_800117100_ft:
  ; @pc 0x800117100 word 0x93407e41
  %r4965.p = getelementptr inbounds i8, ptr %c, i64 144
  %r4965 = load i64, ptr %r4965.p, align 8, !alias.scope !3, !noalias !4
  %t4966 = lshr i64 %r4965, 31
  %t4967 = and i64 %t4966, 1
  %t4968 = sub i64 0, %t4967
  %t4969 = and i64 %t4968, -4294967296
  %t4970 = and i64 %r4965, 4294967295
  %t4971 = or i64 %t4969, %t4970
  %wp4972 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %t4971, ptr %wp4972, align 8, !alias.scope !3, !noalias !4
  br label %L_800117104
L_800117128_ft:
  ; @pc 0x800117128 word 0x7100045f
  %r5044.p = getelementptr inbounds i8, ptr %c, i64 16
  %r5044 = load i64, ptr %r5044.p, align 8, !alias.scope !3, !noalias !4
  %c5045 = trunc i64 %r5044 to i32
  ; @pc 0x80011712c word 0x54000340
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond5067 = icmp eq i32 %c5045, 1
  br i1 %cond5067, label %L_800117194, label %L_800117130_ft
L_800117130_ft:
  ; @pc 0x800117130 word 0x71000c5f
  %r5069.p = getelementptr inbounds i8, ptr %c, i64 16
  %r5069 = load i64, ptr %r5069.p, align 8, !alias.scope !3, !noalias !4
  %c5070 = trunc i64 %r5069 to i32
  ; @pc 0x800117134 word 0x2a1103e2
  %r5091.p = getelementptr inbounds i8, ptr %c, i64 136
  %r5091 = load i64, ptr %r5091.p, align 8, !alias.scope !3, !noalias !4
  %c5092 = trunc i64 %r5091 to i32
  %c5094 = zext i32 %c5092 to i64
  %wp5095 = getelementptr inbounds i8, ptr %c, i64 16
  store i64 %c5094, ptr %wp5095, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117138 word 0x540000c1
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond5097 = icmp ne i32 %c5070, 3
  br i1 %cond5097, label %L_800117150, label %L_80011713c_ft
L_80011713c_ft:
  ; @pc 0x80011713c word 0x140000c8
  br label %L_80011745c
L_800117168_ft:
  ; @pc 0x800117168 word 0xb97b8681
  %r5158.p = getelementptr inbounds i8, ptr %c, i64 160
  %r5158 = load i64, ptr %r5158.p, align 8, !alias.scope !3, !noalias !4
  %t5159 = add i64 %r5158, 15236
  %gmp5160 = inttoptr i64 %t5159 to ptr
  %gml5161 = load i32, ptr %gmp5160, align 1, !alias.scope !4, !noalias !3
  %c5162 = zext i32 %gml5161 to i64
  %wp5163 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %c5162, ptr %wp5163, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011716c word 0x6b00003f
  %r5166.p = getelementptr inbounds i8, ptr %c, i64 0
  %r5166 = load i64, ptr %r5166.p, align 8, !alias.scope !3, !noalias !4
  %c5167 = trunc i64 %r5166 to i32
  ; @pc 0x800117170 word 0x5400008d
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond5189 = icmp sle i32 %gml5161, %c5167
  br i1 %cond5189, label %L_800117180, label %L_800117174_ft
L_800117174_ft:
  ; @pc 0x800117174 word 0xf95dc681
  %r5199.p = getelementptr inbounds i8, ptr %c, i64 160
  %r5199 = load i64, ptr %r5199.p, align 8, !alias.scope !3, !noalias !4
  %t5200 = add i64 %r5199, 15240
  %gmp5201 = inttoptr i64 %t5200 to ptr
  %gml5202 = load i64, ptr %gmp5201, align 1, !alias.scope !4, !noalias !3
  %wp5203 = getelementptr inbounds i8, ptr %c, i64 8
  store i64 %gml5202, ptr %wp5203, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117178 word 0x937d7c00
  %r5204.p = getelementptr inbounds i8, ptr %c, i64 0
  %r5204 = load i64, ptr %r5204.p, align 8, !alias.scope !3, !noalias !4
  %ror5205 = call i64 @llvm.fshr.i64(i64 %r5204, i64 %r5204, i64 61)
  %t5206 = lshr i64 %r5204, 31
  %t5207 = and i64 %t5206, 1
  %t5208 = sub i64 0, %t5207
  %t5209 = and i64 %t5208, -34359738368
  %t5210 = and i64 %ror5205, 34359738360
  %t5211 = or i64 %t5209, %t5210
  %wp5212 = getelementptr inbounds i8, ptr %c, i64 0
  store i64 %t5211, ptr %wp5212, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x80011717c word 0xf8206832
  %t5215 = add i64 %gml5202, %t5211
  %r5216.p = getelementptr inbounds i8, ptr %c, i64 144
  %r5216 = load i64, ptr %r5216.p, align 8, !alias.scope !3, !noalias !4
  %gmp5217 = inttoptr i64 %t5215 to ptr
  store i64 %r5216, ptr %gmp5217, align 1, !alias.scope !4, !noalias !3
  br label %L_800117180
L_800117190_ft:
  ; @pc 0x800117190 word 0x14000005
  br label %L_8001171a4
L_800117278_ft:
  ; @pc 0x800117278 word 0x9bab254c
  %r5559.p = getelementptr inbounds i8, ptr %c, i64 80
  %r5559 = load i64, ptr %r5559.p, align 8, !alias.scope !3, !noalias !4
  %c5560 = trunc i64 %r5559 to i32
  %c5561 = zext i32 %c5560 to i64
  %r5562.p = getelementptr inbounds i8, ptr %c, i64 88
  %r5562 = load i64, ptr %r5562.p, align 8, !alias.scope !3, !noalias !4
  %c5563 = trunc i64 %r5562 to i32
  %c5564 = zext i32 %c5563 to i64
  %t5565 = mul i64 %c5561, %c5564
  %r5566.p = getelementptr inbounds i8, ptr %c, i64 72
  %r5566 = load i64, ptr %r5566.p, align 8, !alias.scope !3, !noalias !4
  %t5567 = add i64 %r5566, %t5565
  ; @pc 0x80011727c word 0x91014189
  %t5570 = add i64 %t5567, 80
  %wp5571 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %t5570, ptr %wp5571, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117280 word 0x9101518a
  %t5573 = add i64 %t5567, 84
  %wp5574 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 %t5573, ptr %wp5574, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117284 word 0x9101618b
  %t5576 = add i64 %t5567, 88
  %wp5577 = getelementptr inbounds i8, ptr %c, i64 88
  store i64 %t5576, ptr %wp5577, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117288 word 0x9101718c
  %t5579 = add i64 %t5567, 92
  %wp5580 = getelementptr inbounds i8, ptr %c, i64 96
  store i64 %t5579, ptr %wp5580, align 8, !alias.scope !3, !noalias !4
  br label %L_80011728c
L_8001172c0_ft:
  ; @pc 0x8001172c0 word 0xa942312a
  %r5679.p = getelementptr inbounds i8, ptr %c, i64 72
  %r5679 = load i64, ptr %r5679.p, align 8, !alias.scope !3, !noalias !4
  %t5680 = add i64 %r5679, 32
  %t5681 = add i64 %t5680, 8
  %gmp5682 = inttoptr i64 %t5680 to ptr
  %gml5683 = load i64, ptr %gmp5682, align 1, !alias.scope !4, !noalias !3
  %gmp5684 = inttoptr i64 %t5681 to ptr
  %gml5685 = load i64, ptr %gmp5684, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001172c4 word 0xa900334a
  %r5688.p = getelementptr inbounds i8, ptr %c, i64 208
  %r5688 = load i64, ptr %r5688.p, align 8, !alias.scope !3, !noalias !4
  %t5689 = add i64 %r5688, 8
  %gmp5691 = inttoptr i64 %r5688 to ptr
  store i64 %gml5683, ptr %gmp5691, align 1, !alias.scope !4, !noalias !3
  %gmp5693 = inttoptr i64 %t5689 to ptr
  store i64 %gml5685, ptr %gmp5693, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001172c8 word 0xf940192a
  %t5695 = add i64 %r5679, 48
  %gmp5696 = inttoptr i64 %t5695 to ptr
  %gml5697 = load i64, ptr %gmp5696, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001172cc word 0xb9403929
  %t5700 = add i64 %r5679, 56
  %gmp5701 = inttoptr i64 %t5700 to ptr
  %gml5702 = load i32, ptr %gmp5701, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001172d0 word 0xb9000b29
  %r5705.p = getelementptr inbounds i8, ptr %c, i64 200
  %r5705 = load i64, ptr %r5705.p, align 8, !alias.scope !3, !noalias !4
  %t5706 = add i64 %r5705, 8
  %gmp5709 = inttoptr i64 %t5706 to ptr
  store i32 %gml5702, ptr %gmp5709, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001172d4 word 0xf900032a
  %gmp5712 = inttoptr i64 %r5705 to ptr
  store i64 %gml5697, ptr %gmp5712, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001172d8 word 0xb9400ac9
  %r5713.p = getelementptr inbounds i8, ptr %c, i64 176
  %r5713 = load i64, ptr %r5713.p, align 8, !alias.scope !3, !noalias !4
  %t5714 = add i64 %r5713, 8
  %gmp5715 = inttoptr i64 %t5714 to ptr
  %gml5716 = load i32, ptr %gmp5715, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001172dc word 0xf9400aca
  %t5720 = add i64 %r5713, 16
  %gmp5721 = inttoptr i64 %t5720 to ptr
  %gml5722 = load i64, ptr %gmp5721, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001172e0 word 0x6b08013f
  %r5726.p = getelementptr inbounds i8, ptr %c, i64 64
  %r5726 = load i64, ptr %r5726.p, align 8, !alias.scope !3, !noalias !4
  %c5727 = trunc i64 %r5726 to i32
  ; @pc 0x8001172e4 word 0x9a9f8108
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond5750 = icmp ugt i32 %gml5716, %c5727
  %sel5756 = select i1 %cond5750, i64 %r5726, i64 0
  ; @pc 0x8001172e8 word 0x9bab2908
  %c5759 = trunc i64 %sel5756 to i32
  %c5760 = zext i32 %c5759 to i64
  %r5761.p = getelementptr inbounds i8, ptr %c, i64 88
  %r5761 = load i64, ptr %r5761.p, align 8, !alias.scope !3, !noalias !4
  %c5762 = trunc i64 %r5761 to i32
  %c5763 = zext i32 %c5762 to i64
  %t5764 = mul i64 %c5760, %c5763
  %t5766 = add i64 %gml5722, %t5764
  ; @pc 0x8001172ec word 0x91010108
  %t5769 = add i64 %t5766, 64
  %wp5770 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %t5769, ptr %wp5770, align 8, !alias.scope !3, !noalias !4
  br label %L_8001172f0
L_8001172f8_ft:
  ; @pc 0x8001172f8 word 0x39430129
  %r5778.p = getelementptr inbounds i8, ptr %c, i64 72
  %r5778 = load i64, ptr %r5778.p, align 8, !alias.scope !3, !noalias !4
  %t5779 = add i64 %r5778, 192
  %gmp5780 = inttoptr i64 %t5779 to ptr
  %gml5781 = load i8, ptr %gmp5780, align 1, !alias.scope !4, !noalias !3
  %c5782 = zext i8 %gml5781 to i64
  %wp5783 = getelementptr inbounds i8, ptr %c, i64 72
  store i64 %c5782, ptr %wp5783, align 8, !alias.scope !3, !noalias !4
  br label %L_8001172fc
L_80011735c_ft:
  ; @pc 0x80011735c word 0x39430108
  %r5888.p = getelementptr inbounds i8, ptr %c, i64 64
  %r5888 = load i64, ptr %r5888.p, align 8, !alias.scope !3, !noalias !4
  %t5889 = add i64 %r5888, 192
  %gmp5890 = inttoptr i64 %t5889 to ptr
  %gml5891 = load i8, ptr %gmp5890, align 1, !alias.scope !4, !noalias !3
  %c5892 = zext i8 %gml5891 to i64
  %wp5893 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %c5892, ptr %wp5893, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x800117360 word 0x17ffff1c
  br label %L_800116fd0
L_800117594_ft:
  ; @pc 0x800117594 word 0xf94f668a
  %r6511.p = getelementptr inbounds i8, ptr %c, i64 160
  %r6511 = load i64, ptr %r6511.p, align 8, !alias.scope !3, !noalias !4
  %t6512 = add i64 %r6511, 7880
  %gmp6513 = inttoptr i64 %t6512 to ptr
  %gml6514 = load i64, ptr %gmp6513, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117598 word 0x3940226b
  %r6516.p = getelementptr inbounds i8, ptr %c, i64 152
  %r6516 = load i64, ptr %r6516.p, align 8, !alias.scope !3, !noalias !4
  %t6517 = add i64 %r6516, 8
  %gmp6518 = inttoptr i64 %t6517 to ptr
  %gml6519 = load i8, ptr %gmp6518, align 1, !alias.scope !4, !noalias !3
  %c6520 = zext i8 %gml6519 to i64
  ; @pc 0x80011759c word 0xb940094c
  %t6523 = add i64 %gml6514, 8
  %gmp6524 = inttoptr i64 %t6523 to ptr
  %gml6525 = load i32, ptr %gmp6524, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001175a0 word 0xf940094a
  %t6529 = add i64 %gml6514, 16
  %gmp6530 = inttoptr i64 %t6529 to ptr
  %gml6531 = load i64, ptr %gmp6530, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001175a4 word 0x6b0b019f
  %c6536 = trunc i64 %c6520 to i32
  ; @pc 0x8001175a8 word 0x52879c0c
  ; [AArch64IdiomDeconstructPass] collapsed constant chain -> immediate store
  %cwp7573 = getelementptr inbounds i8, ptr %c, i64 96
  store i64 15584, ptr %cwp7573, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001175ac word 0x9a9f816b
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct icmp
  %cond6561 = icmp ugt i32 %gml6525, %c6536
  %sel6567 = select i1 %cond6561, i64 %c6520, i64 0
  %wp6568 = getelementptr inbounds i8, ptr %c, i64 88
  store i64 %sel6567, ptr %wp6568, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001175b0 word 0x9bac296a
  %c6570 = trunc i64 %sel6567 to i32
  %c6571 = zext i32 %c6570 to i64
  %c6573 = trunc i64 15584 to i32
  %c6574 = zext i32 %c6573 to i64
  %t6575 = mul i64 %c6571, %c6574
  %t6577 = add i64 %gml6531, %t6575
  %wp6578 = getelementptr inbounds i8, ptr %c, i64 80
  store i64 %t6577, ptr %wp6578, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001175b4 word 0xbd6e0140
  %t6580 = add i64 %t6577, 11776
  %gmp6581 = inttoptr i64 %t6580 to ptr
  %gml6582 = load i32, ptr %gmp6581, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001175b8 word 0xbd6e0941
  %t6586 = add i64 %t6577, 11784
  %gmp6587 = inttoptr i64 %t6586 to ptr
  %gml6588 = load i32, ptr %gmp6587, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001175bc word 0xbd6e0542
  %t6592 = add i64 %t6577, 11780
  %gmp6593 = inttoptr i64 %t6592 to ptr
  %gml6594 = load i32, ptr %gmp6593, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001175c0 word 0xbd6e0d43
  %t6598 = add i64 %t6577, 11788
  %gmp6599 = inttoptr i64 %t6598 to ptr
  %gml6600 = load i32, ptr %gmp6599, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001175c4 word 0xb900a3e8
  %r6603 = load i64, ptr %loc_sp, align 8
  %t6604 = add i64 %r6603, 160
  %r6605.p = getelementptr inbounds i8, ptr %c, i64 64
  %r6605 = load i64, ptr %r6605.p, align 8, !alias.scope !3, !noalias !4
  %c6606 = trunc i64 %r6605 to i32
  %gmp6607 = inttoptr i64 %t6604 to ptr
  store i32 %c6606, ptr %gmp6607, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x8001175c8 word 0xd10027a8
  %r6608 = load i64, ptr %loc_x29, align 8
  %t6609 = sub i64 %r6608, 9
  %wp6610 = getelementptr inbounds i8, ptr %c, i64 64
  store i64 %t6609, ptr %wp6610, align 8, !alias.scope !3, !noalias !4
  ; @pc 0x8001175cc word 0xf80a4309
  %r6611.p = getelementptr inbounds i8, ptr %c, i64 192
  %r6611 = load i64, ptr %r6611.p, align 8, !alias.scope !3, !noalias !4
  %t6612 = add i64 %r6611, 164
  %r6613.p = getelementptr inbounds i8, ptr %c, i64 72
  %r6613 = load i64, ptr %r6613.p, align 8, !alias.scope !3, !noalias !4
  %gmp6614 = inttoptr i64 %t6612 to ptr
  store i64 %r6613, ptr %gmp6614, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001175d0 word 0x1e203820
  ; [FPCRFastFPLoweringPass] inline scalar FP op
  %fnf7146 = bitcast i32 %gml6588 to float
  %fmf7148 = bitcast i32 %gml6582 to float
  %frf7149 = fsub float %fnf7146, %fmf7148
  ; @pc 0x8001175d4 word 0x1e223861
  ; [FPCRFastFPLoweringPass] inline scalar FP op
  %fnf7156 = bitcast i32 %gml6600 to float
  %fmf7158 = bitcast i32 %gml6594 to float
  %frf7159 = fsub float %fnf7156, %fmf7158
  ; @pc 0x8001175d8 word 0xbd430802
  %r6615.p = getelementptr inbounds i8, ptr %c, i64 0
  %r6615 = load i64, ptr %r6615.p, align 8, !alias.scope !3, !noalias !4
  %t6616 = add i64 %r6615, 776
  %gmp6617 = inttoptr i64 %t6616 to ptr
  %gml6618 = load i32, ptr %gmp6617, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001175dc word 0xbd430c03
  %t6622 = add i64 %r6615, 780
  %gmp6623 = inttoptr i64 %t6622 to ptr
  %gml6624 = load i32, ptr %gmp6623, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x8001175e0 word 0x7ea1b800
  ; [SIMDPairwiseAndConversionInlinePass] inline vector/scalar FP<->Int conversion
  %vciri7256 = call i32 @llvm.fptoui.sat.i32.f32(float %frf7149)
  ; @pc 0x8001175e4 word 0x7ea1b821
  ; [SIMDPairwiseAndConversionInlinePass] inline vector/scalar FP<->Int conversion
  %vciri7262 = call i32 @llvm.fptoui.sat.i32.f32(float %frf7159)
  ; @pc 0x8001175e8 word 0x7e21d800
  ; [SIMDPairwiseAndConversionInlinePass] inline vector/scalar FP<->Int conversion
  %vcirf7267 = uitofp i32 %vciri7256 to float
  ; @pc 0x8001175ec word 0x1e200840
  ; [FPCRFastFPLoweringPass] inline scalar FP op
  %fnf7166 = bitcast i32 %gml6618 to float
  %frf7169 = fmul float %fnf7166, %vcirf7267
  %fri7170 = bitcast float %frf7169 to i32
  ; @pc 0x8001175f0 word 0x7e21d821
  ; [SIMDPairwiseAndConversionInlinePass] inline vector/scalar FP<->Int conversion
  %vcirf7273 = uitofp i32 %vciri7262 to float
  ; @pc 0x8001175f4 word 0x1e210861
  ; [FPCRFastFPLoweringPass] inline scalar FP op
  %fnf7176 = bitcast i32 %gml6624 to float
  %frf7179 = fmul float %fnf7176, %vcirf7273
  %fri7180 = bitcast float %frf7179 to i32
  ; @pc 0x8001175f8 word 0x2f00e402
  %wp6627 = getelementptr inbounds i8, ptr %c, i64 544
  store i128 0, ptr %wp6627, align 16, !alias.scope !3, !noalias !4
  ; @pc 0x8001175fc word 0x1e202008
  ; [FCMPPredicateFusionPass] devirtualized @rt_fp_cmp_s
  ; @pc 0x800117600 word 0x1e226803
  ; [FPCRFastFPLoweringPass] inline scalar FP op
  %fmi7187 = trunc i128 0 to i32
  %fmf7188 = bitcast i32 %fmi7187 to float
  %frf7189 = call float @llvm.maxnum.f32(float %frf7169, float %fmf7188)
  %fri7190 = bitcast float %frf7189 to i32
  %frq7191 = zext i32 %fri7190 to i128
  %vw7192 = getelementptr inbounds i8, ptr %c, i64 560
  store i128 %frq7191, ptr %vw7192, align 16, !alias.scope !3, !noalias !4
  ; @pc 0x800117604 word 0x1e226824
  ; [FPCRFastFPLoweringPass] inline scalar FP op
  %frf7199 = call float @llvm.maxnum.f32(float %frf7179, float %fmf7188)
  %fri7200 = bitcast float %frf7199 to i32
  %frq7201 = zext i32 %fri7200 to i128
  %vw7202 = getelementptr inbounds i8, ptr %c, i64 576
  store i128 %frq7201, ptr %vw7202, align 16, !alias.scope !3, !noalias !4
  ; @pc 0x800117608 word 0x1e20cc40
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct fcmp
  %cond6635 = fcmp ogt float %frf7169, 0.000000e+00
  %sel6644 = select i1 %cond6635, i32 %fmi7187, i32 %fri7170
  %c6645 = zext i32 %sel6644 to i128
  %wp6646 = getelementptr inbounds i8, ptr %c, i64 512
  store i128 %c6645, ptr %wp6646, align 16, !alias.scope !3, !noalias !4
  ; @pc 0x80011760c word 0x1e202028
  ; [FCMPPredicateFusionPass] devirtualized @rt_fp_cmp_s
  ; @pc 0x800117610 word 0x2d1013e3
  %t6650 = add i64 %r6603, 128
  %t6651 = add i64 %t6650, 4
  %gmp6656 = inttoptr i64 %t6650 to ptr
  store i32 %fri7190, ptr %gmp6656, align 4, !alias.scope !6, !noalias !3
  %gmp6657 = inttoptr i64 %t6651 to ptr
  store i32 %fri7200, ptr %gmp6657, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800117614 word 0x2d1313e3
  %t6659 = add i64 %r6603, 152
  %t6660 = add i64 %t6659, 4
  %gmp6665 = inttoptr i64 %t6659 to ptr
  store i32 %fri7190, ptr %gmp6665, align 4, !alias.scope !6, !noalias !3
  %gmp6666 = inttoptr i64 %t6660 to ptr
  store i32 %fri7200, ptr %gmp6666, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800117618 word 0x1e21cc41
  ; [NZCVPredicateFusionPass] fused NZCV condition -> direct fcmp
  %cond6672 = fcmp ogt float %frf7179, 0.000000e+00
  %sel6681 = select i1 %cond6672, i32 %fmi7187, i32 %fri7180
  %c6682 = zext i32 %sel6681 to i128
  %wp6683 = getelementptr inbounds i8, ptr %c, i64 528
  store i128 %c6682, ptr %wp6683, align 16, !alias.scope !3, !noalias !4
  ; @pc 0x80011761c word 0x2d0f07e0
  %t6685 = add i64 %r6603, 120
  %t6686 = add i64 %t6685, 4
  ; [AArch64IdiomDeconstructPass] forwarded scalar V-register value
  %gmp6691 = inttoptr i64 %t6685 to ptr
  store i32 %sel6644, ptr %gmp6691, align 4, !alias.scope !6, !noalias !3
  %gmp6692 = inttoptr i64 %t6686 to ptr
  store i32 %sel6681, ptr %gmp6692, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800117620 word 0x2d1207e0
  %t6694 = add i64 %r6603, 144
  %t6695 = add i64 %t6694, 4
  ; [AArch64IdiomDeconstructPass] forwarded scalar V-register value
  %gmp6700 = inttoptr i64 %t6694 to ptr
  store i32 %sel6644, ptr %gmp6700, align 4, !alias.scope !6, !noalias !3
  %gmp6701 = inttoptr i64 %t6695 to ptr
  store i32 %sel6681, ptr %gmp6701, align 4, !alias.scope !6, !noalias !3
  ; @pc 0x800117624 word 0x949caf08
  %wp6702 = getelementptr inbounds i8, ptr %c, i64 240
  store i64 34360882728, ptr %wp6702, align 8, !alias.scope !3, !noalias !4
  call void @f_802843244(ptr %c)
  ; @pc 0x800117628 word 0xf84c7308
  %r6703.p = getelementptr inbounds i8, ptr %c, i64 192
  %r6703 = load i64, ptr %r6703.p, align 8, !alias.scope !3, !noalias !4
  %t6704 = add i64 %r6703, 199
  %gmp6705 = inttoptr i64 %t6704 to ptr
  %gml6706 = load i64, ptr %gmp6705, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x80011762c word 0xf9000368
  %r6708 = load i64, ptr %loc_x27, align 8
  %gmp6710 = inttoptr i64 %r6708 to ptr
  store i64 %gml6706, ptr %gmp6710, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117630 word 0x385ff3a8
  %r6711 = load i64, ptr %loc_x29, align 8
  %t6712 = add i64 %r6711, -1
  %gmp6713 = inttoptr i64 %t6712 to ptr
  %gml6714 = load i8, ptr %gmp6713, align 1, !alias.scope !6, !noalias !3
  %c6715 = zext i8 %gml6714 to i64
  ; @pc 0x800117634 word 0x39002368
  %t6718 = add i64 %r6708, 8
  %c6720 = trunc i64 %c6715 to i32
  %c6721 = trunc i32 %c6720 to i8
  %gmp6722 = inttoptr i64 %t6718 to ptr
  store i8 %c6721, ptr %gmp6722, align 1, !alias.scope !4, !noalias !3
  ; @pc 0x800117638 word 0x17fffe67
  br label %L_800116fd4
L_800116318_jt_def:
  %fp7574 = getelementptr inbounds i8, ptr %c, i64 264
  store i64 %t395, ptr %fp7574, align 8, !alias.scope !3, !noalias !4
  musttail call void @rt_dispatch(ptr %c)
  ret void
}

!0 = !{!"ultratears.aa.domain"}
!1 = !{!"ultratears.aa.cpu_state", !0}
!2 = !{!"ultratears.aa.guest_mem", !0}
!3 = !{!1}
!4 = !{!2}
!5 = !{!"ultratears.aa.guest_stack", !0}
!6 = !{!5}
!ultratears.chunk = !{!7}
!7 = !{!"main_067_statickernel", i64 1, i64 34360877520, i64 34360883160}
